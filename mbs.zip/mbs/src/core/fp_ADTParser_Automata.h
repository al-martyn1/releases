#ifndef FP_ADTPARSER_AUTOMATA_H
#define FP_ADTPARSER_AUTOMATA_H

/* Warning! Automaticaly generated file, do not edit */

#include <stack>
#include "dateTimeHlp.h"


#ifndef CLI_FORMAT_IMPL_CDTFORMATPARSER_STACK_USED
#define CLI_FORMAT_IMPL_CDTFORMATPARSER_STACK_USED
#endif

#ifndef CLI_FORMAT_IMPL_CDTFORMATPARSER_NO_OVERFLOW_CALLS
#define CLI_FORMAT_IMPL_CDTFORMATPARSER_NO_OVERFLOW_CALLS
#endif




namespace cli {
namespace format {
namespace impl {

class CDTFormatParser {

    public:     ::std::wstring       formatedOut ;
    protected:  UINT                 _dtField    ;
    protected:  int                  _width      ;
    protected:  int                  curState    ; //!< Automaticaly added member for saving current automata state
    public:     static const int     ST_adtparser0Day1 = 0x00000001; //!< ADTParser:DAY1
    public:     static const int     ST_adtparser0Eday1 = 0x00000002; //!< ADTParser:EDAY1
    public:     static const int     ST_adtparser0Emon1 = 0x00000003; //!< ADTParser:EMON1
    public:     static const int     ST_adtparser0Eod = 0x80000004; //!< ADTParser:EOD
    public:     static const int     ST_adtparser0Hour1 = 0x00000005; //!< ADTParser:HOUR1
    public:     static const int     ST_adtparser0Hour2 = 0x00000006; //!< ADTParser:HOUR2
    public:     static const int     ST_adtparser0Min1 = 0x00000007; //!< ADTParser:MIN1
    public:     static const int     ST_adtparser0Mon1 = 0x00000008; //!< ADTParser:MON1
    public:     static const int     ST_adtparser0Msec1 = 0x00000009; //!< ADTParser:MSEC1
    public:     static const int     ST_adtparser0Msec2 = 0x0000000A; //!< ADTParser:MSEC2
    public:     static const int     ST_adtparser0Msec3 = 0x0000000B; //!< ADTParser:MSEC3
    public:     static const int     ST_adtparser0Msec4 = 0x0000000C; //!< ADTParser:MSEC4
    public:     static const int     ST_adtparser0Quot1 = 0x0000000D; //!< ADTParser:QUOT1
    public:     static const int     ST_adtparser0Quot2 = 0x0000000E; //!< ADTParser:QUOT2
    public:     static const int     ST_adtparser0Sec1 = 0x0000000F; //!< ADTParser:SEC1
    public:     static const int     ST_adtparser0Spawn1 = 0x00000010; //!< ADTParser:SPAWN1
    public:     static const int     ST_adtparser0Spawn2 = 0x00000011; //!< ADTParser:SPAWN2
    public:     static const int     ST_adtparser0Start = 0x00000012; //!< ADTParser:START
    public:     static const int     ST_adtparser0Ttl = 0x00000013; //!< ADTParser:TTL
    public:     static const int     ST_adtparser0Ttu = 0x00000014; //!< ADTParser:TTU
    public:     static const int     ST_adtparser0U1 = 0x00000015; //!< ADTParser:U1
    public:     static const int     ST_adtparser0U2 = 0x00000016; //!< ADTParser:U2
    public:     static const int     ST_adtparser0Year1 = 0x00000017; //!< ADTParser:YEAR1
    public:     static const int     ST_dAY1      = 0x00000018; //!< ADTParser:DAY1
    public:     static const int     ST_eDAY1     = 0x00000019; //!< ADTParser:EDAY1
    public:     static const int     ST_eMON1     = 0x0000001A; //!< ADTParser:EMON1
    public:     static const int     ST_eOD       = 0x8000001B; //!< ADTParser:EOD
    public:     static const int     ST_hOUR1     = 0x0000001C; //!< ADTParser:HOUR1
    public:     static const int     ST_hOUR2     = 0x0000001D; //!< ADTParser:HOUR2
    public:     static const int     ST_mIN1      = 0x0000001E; //!< ADTParser:MIN1
    public:     static const int     ST_mON1      = 0x0000001F; //!< ADTParser:MON1
    public:     static const int     ST_mSEC1     = 0x00000020; //!< ADTParser:MSEC1
    public:     static const int     ST_mSEC2     = 0x00000021; //!< ADTParser:MSEC2
    public:     static const int     ST_mSEC3     = 0x00000022; //!< ADTParser:MSEC3
    public:     static const int     ST_mSEC4     = 0x00000023; //!< ADTParser:MSEC4
    public:     static const int     ST_qUOT1     = 0x00000024; //!< ADTParser:QUOT1
    public:     static const int     ST_qUOT2     = 0x00000025; //!< ADTParser:QUOT2
    public:     static const int     ST_sEC1      = 0x00000026; //!< ADTParser:SEC1
    public:     static const int     ST_sPAWN1    = 0x00000027; //!< ADTParser:SPAWN1
    public:     static const int     ST_sPAWN2    = 0x00000028; //!< ADTParser:SPAWN2
    public:     static const int     ST_sTART     = 0x00000029; //!< ADTParser:START
    public:     static const int     ST_tTL       = 0x0000002A; //!< ADTParser:TTL
    public:     static const int     ST_tTU       = 0x0000002B; //!< ADTParser:TTU
    public:     static const int     ST_u1        = 0x0000002C; //!< ADTParser:U1
    public:     static const int     ST_u2        = 0x0000002D; //!< ADTParser:U2
    public:     static const int     ST_yEAR1     = 0x0000002E; //!< ADTParser:YEAR1
    public:     static const int     ST_intStatefinalmask = 0x80000000; //!< __int_stateFinalMask__
    public:     static const int     ST_intStateinadmissibleend                                   = 0x8000002F; //!< :
    public:     static const int     LIM_stackSizeMax = 256; //!< Automaticaly generated stack size limit constant
    protected:  std::stack<int>      stateStack  ; //!< Automaticaly generated state stack


    public:     
        void
        putChar
               ( WCHAR  ch          
               )
           {
            /* guard variable - ch */
            switch(this->curState)
               {
                case ST_adtparser0Day1:    /* ADTParser:DAY1 */
                        if (ch==L'e') /* Guard: ['e'] */
                           {
                               /* State ADTParser_0_DAY1 - exit_action empty */
                               /* Transition from ADTParser_0_DAY1 to ADTParser_0_START actions */
                               { ++_width; _dtField=DTF_EWDAY; aF(); }
                               /* State ADTParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adtparser0Start;
                           }
                        else if ((ch==L'd') && (_width<3)) /* Guard: ['d',(_width<3)] */
                           {
                               /* Transition from ADTParser_0_DAY1 to ADTParser_0_DAY1 actions */
                               { ++_width; }
                               /* State ADTParser_0_DAY1 - do_action empty */
                            this->curState = ST_adtparser0Day1;
                           }
                        else
                           {
                               /* State ADTParser_0_DAY1 - exit_action empty */
                               /* Transition from ADTParser_0_DAY1 to ADTParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADTParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adtparser0Eday1:    /* ADTParser:EDAY1 */
                        if ((ch==L'e') && (_width<3)) /* Guard: ['e',(_width<3)] */
                           {
                               /* Transition from ADTParser_0_EDAY1 to ADTParser_0_EDAY1 actions */
                               { ++_width; }
                               /* State ADTParser_0_EDAY1 - do_action empty */
                            this->curState = ST_adtparser0Eday1;
                           }
                        else
                           {
                               /* State ADTParser_0_EDAY1 - exit_action empty */
                               /* Transition from ADTParser_0_EDAY1 to ADTParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADTParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adtparser0Emon1:    /* ADTParser:EMON1 */
                        if ((ch==L'E') && (_width<3)) /* Guard: ['E',(_width<3)] */
                           {
                               /* Transition from ADTParser_0_EMON1 to ADTParser_0_EMON1 actions */
                               { ++_width; }
                               /* State ADTParser_0_EMON1 - do_action empty */
                            this->curState = ST_adtparser0Emon1;
                           }
                        else
                           {
                               /* State ADTParser_0_EMON1 - exit_action empty */
                               /* Transition from ADTParser_0_EMON1 to ADTParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADTParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adtparser0Hour1:    /* ADTParser:HOUR1 */
                        if (ch==L'h') /* Guard: ['h'] */
                           {
                               /* State ADTParser_0_HOUR1 - exit_action empty */
                               /* Transition from ADTParser_0_HOUR1 to ADTParser_0_START actions */
                               { ++_width; aF(); }
                               /* State ADTParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adtparser0Start;
                           }
                        else
                           {
                               /* State ADTParser_0_HOUR1 - exit_action empty */
                               /* Transition from ADTParser_0_HOUR1 to ADTParser_0_SPAWN2 actions */
                               { aF(); }
                               /* State ADTParser_0_SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adtparser0Hour2:    /* ADTParser:HOUR2 */
                        if (ch==L'H') /* Guard: ['H'] */
                           {
                               /* State ADTParser_0_HOUR2 - exit_action empty */
                               /* Transition from ADTParser_0_HOUR2 to ADTParser_0_START actions */
                               { ++_width; aF(); }
                               /* State ADTParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adtparser0Start;
                           }
                        else
                           {
                               /* State ADTParser_0_HOUR2 - exit_action empty */
                               /* Transition from ADTParser_0_HOUR2 to ADTParser_0_SPAWN2 actions */
                               { aF(); }
                               /* State ADTParser_0_SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adtparser0Min1:    /* ADTParser:MIN1 */
                        if (ch==L'm') /* Guard: ['m'] */
                           {
                               /* State ADTParser_0_MIN1 - exit_action empty */
                               /* Transition from ADTParser_0_MIN1 to ADTParser_0_START actions */
                               { ++_width; aF(); }
                               /* State ADTParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adtparser0Start;
                           }
                        else
                           {
                               /* State ADTParser_0_MIN1 - exit_action empty */
                               /* Transition from ADTParser_0_MIN1 to ADTParser_0_SPAWN2 actions */
                               { aF(); }
                               /* State ADTParser_0_SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adtparser0Mon1:    /* ADTParser:MON1 */
                        if ((ch==L'M') && (_width<3)) /* Guard: ['M',(_width<3)] */
                           {
                               /* Transition from ADTParser_0_MON1 to ADTParser_0_MON1 actions */
                               { ++_width; }
                               /* State ADTParser_0_MON1 - do_action empty */
                            this->curState = ST_adtparser0Mon1;
                           }
                        else if (ch==L'E') /* Guard: ['E'] */
                           {
                               /* State ADTParser_0_MON1 - exit_action empty */
                               /* Transition from ADTParser_0_MON1 to ADTParser_0_START actions */
                               { ++_width; _dtField=DTF_EMONTH; aF(); }
                               /* State ADTParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adtparser0Start;
                           }
                        else
                           {
                               /* State ADTParser_0_MON1 - exit_action empty */
                               /* Transition from ADTParser_0_MON1 to ADTParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADTParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adtparser0Msec1:    /* ADTParser:MSEC1 */
                        if ((ch==L'c') && (_width<5)) /* Guard: ['c',(_width<5)] */
                           {
                               /* Transition from ADTParser_0_MSEC1 to ADTParser_0_MSEC1 actions */
                               { ++_width; }
                               /* State ADTParser_0_MSEC1 - do_action empty */
                            this->curState = ST_adtparser0Msec1;
                           }
                        else
                           {
                               /* State ADTParser_0_MSEC1 - exit_action empty */
                               /* Transition from ADTParser_0_MSEC1 to ADTParser_0_SPAWN2 actions */
                               { aF(); }
                               /* State ADTParser_0_SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adtparser0Msec2:    /* ADTParser:MSEC2 */
                        if ((ch==L'z') && (_width<5)) /* Guard: ['z',(_width<5)] */
                           {
                               /* Transition from ADTParser_0_MSEC2 to ADTParser_0_MSEC2 actions */
                               { ++_width; }
                               /* State ADTParser_0_MSEC2 - do_action empty */
                            this->curState = ST_adtparser0Msec2;
                           }
                        else
                           {
                               /* State ADTParser_0_MSEC2 - exit_action empty */
                               /* Transition from ADTParser_0_MSEC2 to ADTParser_0_SPAWN2 actions */
                               { aF(); }
                               /* State ADTParser_0_SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adtparser0Msec3:    /* ADTParser:MSEC3 */
                        if ((ch==L'C') && (_width<5)) /* Guard: ['C',(_width<5)] */
                           {
                               /* Transition from ADTParser_0_MSEC3 to ADTParser_0_MSEC3 actions */
                               { ++_width; }
                               /* State ADTParser_0_MSEC3 - do_action empty */
                            this->curState = ST_adtparser0Msec3;
                           }
                        else
                           {
                               /* State ADTParser_0_MSEC3 - exit_action empty */
                               /* Transition from ADTParser_0_MSEC3 to ADTParser_0_SPAWN2 actions */
                               { aF(); }
                               /* State ADTParser_0_SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adtparser0Msec4:    /* ADTParser:MSEC4 */
                        if ((ch==L'Z') && (_width<5)) /* Guard: ['Z',(_width<5)] */
                           {
                               /* Transition from ADTParser_0_MSEC4 to ADTParser_0_MSEC4 actions */
                               { ++_width; }
                               /* State ADTParser_0_MSEC4 - do_action empty */
                            this->curState = ST_adtparser0Msec4;
                           }
                        else
                           {
                               /* State ADTParser_0_MSEC4 - exit_action empty */
                               /* Transition from ADTParser_0_MSEC4 to ADTParser_0_SPAWN2 actions */
                               { aF(); }
                               /* State ADTParser_0_SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adtparser0Quot1:    /* ADTParser:QUOT1 */
                        if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State ADTParser_0_QUOT1 - exit_action empty */
                               /* Transition from ADTParser_0_QUOT1 to ADTParser_0_QUOT2 actions */
                               /* State ADTParser_0_QUOT2 - entry_action empty */
                            this->curState = ST_adtparser0Quot2;
                           }
                        else
                           {
                               /* Transition from ADTParser_0_QUOT1 to ADTParser_0_QUOT1 actions */
                               { aI(ch); }
                               /* State ADTParser_0_QUOT1 - do_action empty */
                            this->curState = ST_adtparser0Quot1;
                           }
                     break;
                case ST_adtparser0Quot2:    /* ADTParser:QUOT2 */
                        if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State ADTParser_0_QUOT2 - exit_action empty */
                               /* Transition from ADTParser_0_QUOT2 to ADTParser_0_QUOT1 actions */
                               { aI(ch); }
                               /* State ADTParser_0_QUOT1 - entry_action empty */
                            this->curState = ST_adtparser0Quot1;
                           }
                        else
                           {
                               /* State ADTParser_0_QUOT2 - exit_action empty */
                               /* Transition from ADTParser_0_QUOT2 to ADTParser_0_SPAWN2 actions */
                               { aFE(DTF_EQ); }
                               /* State ADTParser_0_SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adtparser0Sec1:    /* ADTParser:SEC1 */
                        if (ch==L's') /* Guard: ['s'] */
                           {
                               /* State ADTParser_0_SEC1 - exit_action empty */
                               /* Transition from ADTParser_0_SEC1 to ADTParser_0_START actions */
                               { ++_width; aF(); }
                               /* State ADTParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adtparser0Start;
                           }
                        else
                           {
                               /* State ADTParser_0_SEC1 - exit_action empty */
                               /* Transition from ADTParser_0_SEC1 to ADTParser_0_SPAWN2 actions */
                               { aF(); }
                               /* State ADTParser_0_SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adtparser0Start:    /* ADTParser:START */
                        if (ch==L'z') /* Guard: ['z'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_MSEC2 actions */
                               { _dtField=DTF_MSEC|DTF_ZEROS; }
                               /* State ADTParser_0_MSEC2 - entry_action empty */
                            this->curState = ST_adtparser0Msec2;
                           }
                        else if (ch==L'y') /* Guard: ['y'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_YEAR1 actions */
                               { _dtField=DTF_YEAR; }
                               /* State ADTParser_0_YEAR1 - entry_action empty */
                            this->curState = ST_adtparser0Year1;
                           }
                        else if (ch==L'u') /* Guard: ['u'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_U1 actions */
                               { _dtField=DTF_GM; }
                               /* State ADTParser_0_U1 - entry_action empty */
                            this->curState = ST_adtparser0U1;
                           }
                        else if (ch==L't') /* Guard: ['t'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_TTU actions */
                               { _dtField=DTF_APU; }
                               /* State ADTParser_0_TTU - entry_action empty */
                            this->curState = ST_adtparser0Ttu;
                           }
                        else if (ch==L's') /* Guard: ['s'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_SEC1 actions */
                               { _dtField=DTF_SEC; }
                               /* State ADTParser_0_SEC1 - entry_action empty */
                            this->curState = ST_adtparser0Sec1;
                           }
                        else if (ch==L'm') /* Guard: ['m'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_MIN1 actions */
                               { _dtField=DTF_MIN; }
                               /* State ADTParser_0_MIN1 - entry_action empty */
                            this->curState = ST_adtparser0Min1;
                           }
                        else if (ch==L'h') /* Guard: ['h'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_HOUR1 actions */
                               { _dtField=DTF_HOUR12; }
                               /* State ADTParser_0_HOUR1 - entry_action empty */
                            this->curState = ST_adtparser0Hour1;
                           }
                        else if (ch==L'e') /* Guard: ['e'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_EDAY1 actions */
                               { _dtField=DTF_EMDAY; }
                               /* State ADTParser_0_EDAY1 - entry_action empty */
                            this->curState = ST_adtparser0Eday1;
                           }
                        else if (ch==L'c') /* Guard: ['c'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_MSEC1 actions */
                               { _dtField=DTF_MSEC|DTF_ZEROS; }
                               /* State ADTParser_0_MSEC1 - entry_action empty */
                            this->curState = ST_adtparser0Msec1;
                           }
                        else if (ch==L'_') /* Guard: ['_'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_START actions */
                               { aFE(DTF_DATESEP); }
                               /* State ADTParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adtparser0Start;
                           }
                        else if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_QUOT1 actions */
                               { aFE(DTF_SQ); }
                               /* State ADTParser_0_QUOT1 - entry_action empty */
                            this->curState = ST_adtparser0Quot1;
                           }
                        else if (ch==L'Z') /* Guard: ['Z'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_MSEC4 actions */
                               { _dtField=DTF_MSEC; }
                               /* State ADTParser_0_MSEC4 - entry_action empty */
                            this->curState = ST_adtparser0Msec4;
                           }
                        else if (ch==L'U') /* Guard: ['U'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_U2 actions */
                               { _dtField=DTF_GML; }
                               /* State ADTParser_0_U2 - entry_action empty */
                            this->curState = ST_adtparser0U2;
                           }
                        else if (ch==L'T') /* Guard: ['T'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_TTL actions */
                               { _dtField=DTF_AP; }
                               /* State ADTParser_0_TTL - entry_action empty */
                            this->curState = ST_adtparser0Ttl;
                           }
                        else if (ch==L'M') /* Guard: ['M'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_MON1 actions */
                               { _dtField=DTF_MONTH; }
                               /* State ADTParser_0_MON1 - entry_action empty */
                            this->curState = ST_adtparser0Mon1;
                           }
                        else if (ch==L'H') /* Guard: ['H'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_HOUR2 actions */
                               { _dtField=DTF_HOUR; }
                               /* State ADTParser_0_HOUR2 - entry_action empty */
                            this->curState = ST_adtparser0Hour2;
                           }
                        else if (ch==L'E') /* Guard: ['E'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_EMON1 actions */
                               { _dtField=DTF_EMONTH; }
                               /* State ADTParser_0_EMON1 - entry_action empty */
                            this->curState = ST_adtparser0Emon1;
                           }
                        else if (ch==L'D' || ch==L'd') /* Guard: ['D','d'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_DAY1 actions */
                               { _dtField=DTF_MDAY; }
                               /* State ADTParser_0_DAY1 - entry_action empty */
                            this->curState = ST_adtparser0Day1;
                           }
                        else if (ch==L'C') /* Guard: ['C'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_MSEC3 actions */
                               { _dtField=DTF_MSEC; }
                               /* State ADTParser_0_MSEC3 - entry_action empty */
                            this->curState = ST_adtparser0Msec3;
                           }
                        else if (ch==L'?') /* Guard: ['?'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_START actions */
                               { aFE(DTF_IGNORE); }
                               /* State ADTParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adtparser0Start;
                           }
                        else if (ch==L'=') /* Guard: ['='] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_START actions */
                               { aFE(DTF_TIMESEP); }
                               /* State ADTParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adtparser0Start;
                           }
                        else if (ch==L'#') /* Guard: ['#'] */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_START actions */
                               { aFE(DTF_SIGNORE); }
                               /* State ADTParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adtparser0Start;
                           }
                        else
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_START actions */
                               { aI(ch); }
                               /* State ADTParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adtparser0Start;
                           }
                     break;
                case ST_adtparser0Ttl:    /* ADTParser:TTL */
                        if ((ch==L'T') && (_width<1)) /* Guard: ['T',(_width<1)] */
                           {
                               /* Transition from ADTParser_0_TTL to ADTParser_0_TTL actions */
                               { ++_width; }
                               /* State ADTParser_0_TTL - do_action empty */
                            this->curState = ST_adtparser0Ttl;
                           }
                        else
                           {
                               /* State ADTParser_0_TTL - exit_action empty */
                               /* Transition from ADTParser_0_TTL to ADTParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADTParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adtparser0Ttu:    /* ADTParser:TTU */
                        if ((ch==L't') && (_width<1)) /* Guard: ['t',(_width<1)] */
                           {
                               /* Transition from ADTParser_0_TTU to ADTParser_0_TTU actions */
                               { ++_width; }
                               /* State ADTParser_0_TTU - do_action empty */
                            this->curState = ST_adtparser0Ttu;
                           }
                        else
                           {
                               /* State ADTParser_0_TTU - exit_action empty */
                               /* Transition from ADTParser_0_TTU to ADTParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADTParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adtparser0U1:    /* ADTParser:U1 */
                        if ((ch==L'u') && (_width<3)) /* Guard: ['u',(_width<3)] */
                           {
                               /* Transition from ADTParser_0_U1 to ADTParser_0_U1 actions */
                               { ++_width; }
                               /* State ADTParser_0_U1 - do_action empty */
                            this->curState = ST_adtparser0U1;
                           }
                        else
                           {
                               /* State ADTParser_0_U1 - exit_action empty */
                               /* Transition from ADTParser_0_U1 to ADTParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADTParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adtparser0U2:    /* ADTParser:U2 */
                        if ((ch==L'U') && (_width<3)) /* Guard: ['U',(_width<3)] */
                           {
                               /* Transition from ADTParser_0_U2 to ADTParser_0_U2 actions */
                               { ++_width; }
                               /* State ADTParser_0_U2 - do_action empty */
                            this->curState = ST_adtparser0U2;
                           }
                        else
                           {
                               /* State ADTParser_0_U2 - exit_action empty */
                               /* Transition from ADTParser_0_U2 to ADTParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADTParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adtparser0Year1:    /* ADTParser:YEAR1 */
                        if ((ch==L'y') && (_width<3)) /* Guard: ['y',(_width<3)] */
                           {
                               /* Transition from ADTParser_0_YEAR1 to ADTParser_0_YEAR1 actions */
                               { ++_width; }
                               /* State ADTParser_0_YEAR1 - do_action empty */
                            this->curState = ST_adtparser0Year1;
                           }
                        else
                           {
                               /* State ADTParser_0_YEAR1 - exit_action empty */
                               /* Transition from ADTParser_0_YEAR1 to ADTParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADTParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_dAY1:    /* ADTParser:DAY1 */
                        if (ch==L'e') /* Guard: ['e'] */
                           {
                               /* State DAY1 - exit_action empty */
                               /* Transition from DAY1 to START actions */
                               { ++_width; _dtField=DTF_EWDAY; aF(); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else if ((ch==L'd') && (_width<3)) /* Guard: ['d',(_width<3)] */
                           {
                               /* Transition from DAY1 to DAY1 actions */
                               { ++_width; }
                               /* State DAY1 - do_action empty */
                            this->curState = ST_dAY1;
                           }
                        else
                           {
                               /* State DAY1 - exit_action empty */
                               /* Transition from DAY1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_eDAY1:    /* ADTParser:EDAY1 */
                        if ((ch==L'e') && (_width<3)) /* Guard: ['e',(_width<3)] */
                           {
                               /* Transition from EDAY1 to EDAY1 actions */
                               { ++_width; }
                               /* State EDAY1 - do_action empty */
                            this->curState = ST_eDAY1;
                           }
                        else
                           {
                               /* State EDAY1 - exit_action empty */
                               /* Transition from EDAY1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_eMON1:    /* ADTParser:EMON1 */
                        if ((ch==L'E') && (_width<3)) /* Guard: ['E',(_width<3)] */
                           {
                               /* Transition from EMON1 to EMON1 actions */
                               { ++_width; }
                               /* State EMON1 - do_action empty */
                            this->curState = ST_eMON1;
                           }
                        else
                           {
                               /* State EMON1 - exit_action empty */
                               /* Transition from EMON1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_hOUR1:    /* ADTParser:HOUR1 */
                        if (ch==L'h') /* Guard: ['h'] */
                           {
                               /* State HOUR1 - exit_action empty */
                               /* Transition from HOUR1 to START actions */
                               { ++_width; aF(); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else
                           {
                               /* State HOUR1 - exit_action empty */
                               /* Transition from HOUR1 to SPAWN2 actions */
                               { aF(); }
                               /* State SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_hOUR2:    /* ADTParser:HOUR2 */
                        if (ch==L'H') /* Guard: ['H'] */
                           {
                               /* State HOUR2 - exit_action empty */
                               /* Transition from HOUR2 to START actions */
                               { ++_width; aF(); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else
                           {
                               /* State HOUR2 - exit_action empty */
                               /* Transition from HOUR2 to SPAWN2 actions */
                               { aF(); }
                               /* State SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mIN1:    /* ADTParser:MIN1 */
                        if (ch==L'm') /* Guard: ['m'] */
                           {
                               /* State MIN1 - exit_action empty */
                               /* Transition from MIN1 to START actions */
                               { ++_width; aF(); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else
                           {
                               /* State MIN1 - exit_action empty */
                               /* Transition from MIN1 to SPAWN2 actions */
                               { aF(); }
                               /* State SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mON1:    /* ADTParser:MON1 */
                        if ((ch==L'M') && (_width<3)) /* Guard: ['M',(_width<3)] */
                           {
                               /* Transition from MON1 to MON1 actions */
                               { ++_width; }
                               /* State MON1 - do_action empty */
                            this->curState = ST_mON1;
                           }
                        else if (ch==L'E') /* Guard: ['E'] */
                           {
                               /* State MON1 - exit_action empty */
                               /* Transition from MON1 to START actions */
                               { ++_width; _dtField=DTF_EMONTH; aF(); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else
                           {
                               /* State MON1 - exit_action empty */
                               /* Transition from MON1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mSEC1:    /* ADTParser:MSEC1 */
                        if ((ch==L'c') && (_width<5)) /* Guard: ['c',(_width<5)] */
                           {
                               /* Transition from MSEC1 to MSEC1 actions */
                               { ++_width; }
                               /* State MSEC1 - do_action empty */
                            this->curState = ST_mSEC1;
                           }
                        else
                           {
                               /* State MSEC1 - exit_action empty */
                               /* Transition from MSEC1 to SPAWN2 actions */
                               { aF(); }
                               /* State SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mSEC2:    /* ADTParser:MSEC2 */
                        if ((ch==L'z') && (_width<5)) /* Guard: ['z',(_width<5)] */
                           {
                               /* Transition from MSEC2 to MSEC2 actions */
                               { ++_width; }
                               /* State MSEC2 - do_action empty */
                            this->curState = ST_mSEC2;
                           }
                        else
                           {
                               /* State MSEC2 - exit_action empty */
                               /* Transition from MSEC2 to SPAWN2 actions */
                               { aF(); }
                               /* State SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mSEC3:    /* ADTParser:MSEC3 */
                        if ((ch==L'C') && (_width<5)) /* Guard: ['C',(_width<5)] */
                           {
                               /* Transition from MSEC3 to MSEC3 actions */
                               { ++_width; }
                               /* State MSEC3 - do_action empty */
                            this->curState = ST_mSEC3;
                           }
                        else
                           {
                               /* State MSEC3 - exit_action empty */
                               /* Transition from MSEC3 to SPAWN2 actions */
                               { aF(); }
                               /* State SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mSEC4:    /* ADTParser:MSEC4 */
                        if ((ch==L'Z') && (_width<5)) /* Guard: ['Z',(_width<5)] */
                           {
                               /* Transition from MSEC4 to MSEC4 actions */
                               { ++_width; }
                               /* State MSEC4 - do_action empty */
                            this->curState = ST_mSEC4;
                           }
                        else
                           {
                               /* State MSEC4 - exit_action empty */
                               /* Transition from MSEC4 to SPAWN2 actions */
                               { aF(); }
                               /* State SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_qUOT1:    /* ADTParser:QUOT1 */
                        if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State QUOT1 - exit_action empty */
                               /* Transition from QUOT1 to QUOT2 actions */
                               /* State QUOT2 - entry_action empty */
                            this->curState = ST_qUOT2;
                           }
                        else
                           {
                               /* Transition from QUOT1 to QUOT1 actions */
                               { aI(ch); }
                               /* State QUOT1 - do_action empty */
                            this->curState = ST_qUOT1;
                           }
                     break;
                case ST_qUOT2:    /* ADTParser:QUOT2 */
                        if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State QUOT2 - exit_action empty */
                               /* Transition from QUOT2 to QUOT1 actions */
                               { aI(ch); }
                               /* State QUOT1 - entry_action empty */
                            this->curState = ST_qUOT1;
                           }
                        else
                           {
                               /* State QUOT2 - exit_action empty */
                               /* Transition from QUOT2 to SPAWN2 actions */
                               { aFE(DTF_EQ); }
                               /* State SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_sEC1:    /* ADTParser:SEC1 */
                        if (ch==L's') /* Guard: ['s'] */
                           {
                               /* State SEC1 - exit_action empty */
                               /* Transition from SEC1 to START actions */
                               { ++_width; aF(); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else
                           {
                               /* State SEC1 - exit_action empty */
                               /* Transition from SEC1 to SPAWN2 actions */
                               { aF(); }
                               /* State SPAWN2 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_sTART:    /* ADTParser:START */
                        if (ch==L'z') /* Guard: ['z'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MSEC2 actions */
                               { _dtField=DTF_MSEC|DTF_ZEROS; }
                               /* State MSEC2 - entry_action empty */
                            this->curState = ST_mSEC2;
                           }
                        else if (ch==L'y') /* Guard: ['y'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to YEAR1 actions */
                               { _dtField=DTF_YEAR; }
                               /* State YEAR1 - entry_action empty */
                            this->curState = ST_yEAR1;
                           }
                        else if (ch==L'u') /* Guard: ['u'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to U1 actions */
                               { _dtField=DTF_GM; }
                               /* State U1 - entry_action empty */
                            this->curState = ST_u1;
                           }
                        else if (ch==L't') /* Guard: ['t'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to TTU actions */
                               { _dtField=DTF_APU; }
                               /* State TTU - entry_action empty */
                            this->curState = ST_tTU;
                           }
                        else if (ch==L's') /* Guard: ['s'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to SEC1 actions */
                               { _dtField=DTF_SEC; }
                               /* State SEC1 - entry_action empty */
                            this->curState = ST_sEC1;
                           }
                        else if (ch==L'm') /* Guard: ['m'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MIN1 actions */
                               { _dtField=DTF_MIN; }
                               /* State MIN1 - entry_action empty */
                            this->curState = ST_mIN1;
                           }
                        else if (ch==L'h') /* Guard: ['h'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to HOUR1 actions */
                               { _dtField=DTF_HOUR12; }
                               /* State HOUR1 - entry_action empty */
                            this->curState = ST_hOUR1;
                           }
                        else if (ch==L'e') /* Guard: ['e'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to EDAY1 actions */
                               { _dtField=DTF_EMDAY; }
                               /* State EDAY1 - entry_action empty */
                            this->curState = ST_eDAY1;
                           }
                        else if (ch==L'c') /* Guard: ['c'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MSEC1 actions */
                               { _dtField=DTF_MSEC|DTF_ZEROS; }
                               /* State MSEC1 - entry_action empty */
                            this->curState = ST_mSEC1;
                           }
                        else if (ch==L'_') /* Guard: ['_'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_DATESEP); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to QUOT1 actions */
                               { aFE(DTF_SQ); }
                               /* State QUOT1 - entry_action empty */
                            this->curState = ST_qUOT1;
                           }
                        else if (ch==L'Z') /* Guard: ['Z'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MSEC4 actions */
                               { _dtField=DTF_MSEC; }
                               /* State MSEC4 - entry_action empty */
                            this->curState = ST_mSEC4;
                           }
                        else if (ch==L'U') /* Guard: ['U'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to U2 actions */
                               { _dtField=DTF_GML; }
                               /* State U2 - entry_action empty */
                            this->curState = ST_u2;
                           }
                        else if (ch==L'T') /* Guard: ['T'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to TTL actions */
                               { _dtField=DTF_AP; }
                               /* State TTL - entry_action empty */
                            this->curState = ST_tTL;
                           }
                        else if (ch==L'M') /* Guard: ['M'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MON1 actions */
                               { _dtField=DTF_MONTH; }
                               /* State MON1 - entry_action empty */
                            this->curState = ST_mON1;
                           }
                        else if (ch==L'H') /* Guard: ['H'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to HOUR2 actions */
                               { _dtField=DTF_HOUR; }
                               /* State HOUR2 - entry_action empty */
                            this->curState = ST_hOUR2;
                           }
                        else if (ch==L'E') /* Guard: ['E'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to EMON1 actions */
                               { _dtField=DTF_EMONTH; }
                               /* State EMON1 - entry_action empty */
                            this->curState = ST_eMON1;
                           }
                        else if (ch==L'D' || ch==L'd') /* Guard: ['D','d'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to DAY1 actions */
                               { _dtField=DTF_MDAY; }
                               /* State DAY1 - entry_action empty */
                            this->curState = ST_dAY1;
                           }
                        else if (ch==L'C') /* Guard: ['C'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MSEC3 actions */
                               { _dtField=DTF_MSEC; }
                               /* State MSEC3 - entry_action empty */
                            this->curState = ST_mSEC3;
                           }
                        else if (ch==L'?') /* Guard: ['?'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_IGNORE); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else if (ch==L'=') /* Guard: ['='] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_TIMESEP); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else if (ch==L'#') /* Guard: ['#'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_SIGNORE); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aI(ch); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                     break;
                case ST_tTL:    /* ADTParser:TTL */
                        if ((ch==L'T') && (_width<1)) /* Guard: ['T',(_width<1)] */
                           {
                               /* Transition from TTL to TTL actions */
                               { ++_width; }
                               /* State TTL - do_action empty */
                            this->curState = ST_tTL;
                           }
                        else
                           {
                               /* State TTL - exit_action empty */
                               /* Transition from TTL to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_tTU:    /* ADTParser:TTU */
                        if ((ch==L't') && (_width<1)) /* Guard: ['t',(_width<1)] */
                           {
                               /* Transition from TTU to TTU actions */
                               { ++_width; }
                               /* State TTU - do_action empty */
                            this->curState = ST_tTU;
                           }
                        else
                           {
                               /* State TTU - exit_action empty */
                               /* Transition from TTU to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_u1:    /* ADTParser:U1 */
                        if ((ch==L'u') && (_width<3)) /* Guard: ['u',(_width<3)] */
                           {
                               /* Transition from U1 to U1 actions */
                               { ++_width; }
                               /* State U1 - do_action empty */
                            this->curState = ST_u1;
                           }
                        else
                           {
                               /* State U1 - exit_action empty */
                               /* Transition from U1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_u2:    /* ADTParser:U2 */
                        if ((ch==L'U') && (_width<3)) /* Guard: ['U',(_width<3)] */
                           {
                               /* Transition from U2 to U2 actions */
                               { ++_width; }
                               /* State U2 - do_action empty */
                            this->curState = ST_u2;
                           }
                        else
                           {
                               /* State U2 - exit_action empty */
                               /* Transition from U2 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_yEAR1:    /* ADTParser:YEAR1 */
                        if ((ch==L'y') && (_width<3)) /* Guard: ['y',(_width<3)] */
                           {
                               /* Transition from YEAR1 to YEAR1 actions */
                               { ++_width; }
                               /* State YEAR1 - do_action empty */
                            this->curState = ST_yEAR1;
                           }
                        else
                           {
                               /* State YEAR1 - exit_action empty */
                               /* Transition from YEAR1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADTParser_0_START - call_entry_action empty */
                               /* Called State ADTParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adtparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
               };

           }

    public:     
        void
        eod
           ( 
           )
           {
            /* there is no guard variable */
            switch(this->curState)
               {
                case ST_adtparser0Day1:    /* ADTParser:DAY1 */
                           {
                               /* State ADTParser_0_DAY1 - exit_action empty */
                               /* Transition from ADTParser_0_DAY1 to ADTParser_0_EOD actions */
                               { aF(); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0Eday1:    /* ADTParser:EDAY1 */
                           {
                               /* State ADTParser_0_EDAY1 - exit_action empty */
                               /* Transition from ADTParser_0_EDAY1 to ADTParser_0_EOD actions */
                               { aF(); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0Emon1:    /* ADTParser:EMON1 */
                           {
                               /* State ADTParser_0_EMON1 - exit_action empty */
                               /* Transition from ADTParser_0_EMON1 to ADTParser_0_EOD actions */
                               { aF(); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0Hour1:    /* ADTParser:HOUR1 */
                           {
                               /* State ADTParser_0_HOUR1 - exit_action empty */
                               /* Transition from ADTParser_0_HOUR1 to ADTParser_0_EOD actions */
                               { aF(); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0Hour2:    /* ADTParser:HOUR2 */
                           {
                               /* State ADTParser_0_HOUR2 - exit_action empty */
                               /* Transition from ADTParser_0_HOUR2 to ADTParser_0_EOD actions */
                               { aF(); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0Min1:    /* ADTParser:MIN1 */
                           {
                               /* State ADTParser_0_MIN1 - exit_action empty */
                               /* Transition from ADTParser_0_MIN1 to ADTParser_0_EOD actions */
                               { aF(); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0Mon1:    /* ADTParser:MON1 */
                           {
                               /* State ADTParser_0_MON1 - exit_action empty */
                               /* Transition from ADTParser_0_MON1 to ADTParser_0_EOD actions */
                               { aF(); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0Msec1:    /* ADTParser:MSEC1 */
                           {
                               /* State ADTParser_0_MSEC1 - exit_action empty */
                               /* Transition from ADTParser_0_MSEC1 to ADTParser_0_EOD actions */
                               { aF(); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0Msec2:    /* ADTParser:MSEC2 */
                           {
                               /* State ADTParser_0_MSEC2 - exit_action empty */
                               /* Transition from ADTParser_0_MSEC2 to ADTParser_0_EOD actions */
                               { aF(); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0Msec3:    /* ADTParser:MSEC3 */
                           {
                               /* State ADTParser_0_MSEC3 - exit_action empty */
                               /* Transition from ADTParser_0_MSEC3 to ADTParser_0_EOD actions */
                               { aF(); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0Msec4:    /* ADTParser:MSEC4 */
                           {
                               /* State ADTParser_0_MSEC4 - exit_action empty */
                               /* Transition from ADTParser_0_MSEC4 to ADTParser_0_EOD actions */
                               { aF(); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0Quot1:    /* ADTParser:QUOT1 */
                           {
                               /* State ADTParser_0_QUOT1 - exit_action empty */
                               /* Transition from ADTParser_0_QUOT1 to ADTParser_0_EOD actions */
                               { aFE(DTF_EQ); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0Quot2:    /* ADTParser:QUOT2 */
                           {
                               /* State ADTParser_0_QUOT2 - exit_action empty */
                               /* Transition from ADTParser_0_QUOT2 to ADTParser_0_EOD actions */
                               { aFE(DTF_EQ); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0Sec1:    /* ADTParser:SEC1 */
                           {
                               /* State ADTParser_0_SEC1 - exit_action empty */
                               /* Transition from ADTParser_0_SEC1 to ADTParser_0_EOD actions */
                               { aF(); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0Start:    /* ADTParser:START */
                           {
                               /* State ADTParser_0_START - exit_action empty */
                               /* Transition from ADTParser_0_START to ADTParser_0_EOD actions */
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0Ttl:    /* ADTParser:TTL */
                           {
                               /* State ADTParser_0_TTL - exit_action empty */
                               /* Transition from ADTParser_0_TTL to ADTParser_0_EOD actions */
                               { aF(); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0Ttu:    /* ADTParser:TTU */
                           {
                               /* State ADTParser_0_TTU - exit_action empty */
                               /* Transition from ADTParser_0_TTU to ADTParser_0_EOD actions */
                               { aF(); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0U1:    /* ADTParser:U1 */
                           {
                               /* State ADTParser_0_U1 - exit_action empty */
                               /* Transition from ADTParser_0_U1 to ADTParser_0_EOD actions */
                               { aF(); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0U2:    /* ADTParser:U2 */
                           {
                               /* State ADTParser_0_U2 - exit_action empty */
                               /* Transition from ADTParser_0_U2 to ADTParser_0_EOD actions */
                               { aF(); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adtparser0Year1:    /* ADTParser:YEAR1 */
                           {
                               /* State ADTParser_0_YEAR1 - exit_action empty */
                               /* Transition from ADTParser_0_YEAR1 to ADTParser_0_EOD actions */
                               { aF(); }
                               /* End state ADTParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_dAY1:    /* ADTParser:DAY1 */
                           {
                               /* State DAY1 - exit_action empty */
                               /* Transition from DAY1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_eDAY1:    /* ADTParser:EDAY1 */
                           {
                               /* State EDAY1 - exit_action empty */
                               /* Transition from EDAY1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_eMON1:    /* ADTParser:EMON1 */
                           {
                               /* State EMON1 - exit_action empty */
                               /* Transition from EMON1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_hOUR1:    /* ADTParser:HOUR1 */
                           {
                               /* State HOUR1 - exit_action empty */
                               /* Transition from HOUR1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_hOUR2:    /* ADTParser:HOUR2 */
                           {
                               /* State HOUR2 - exit_action empty */
                               /* Transition from HOUR2 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mIN1:    /* ADTParser:MIN1 */
                           {
                               /* State MIN1 - exit_action empty */
                               /* Transition from MIN1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mON1:    /* ADTParser:MON1 */
                           {
                               /* State MON1 - exit_action empty */
                               /* Transition from MON1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mSEC1:    /* ADTParser:MSEC1 */
                           {
                               /* State MSEC1 - exit_action empty */
                               /* Transition from MSEC1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mSEC2:    /* ADTParser:MSEC2 */
                           {
                               /* State MSEC2 - exit_action empty */
                               /* Transition from MSEC2 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mSEC3:    /* ADTParser:MSEC3 */
                           {
                               /* State MSEC3 - exit_action empty */
                               /* Transition from MSEC3 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mSEC4:    /* ADTParser:MSEC4 */
                           {
                               /* State MSEC4 - exit_action empty */
                               /* Transition from MSEC4 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_qUOT1:    /* ADTParser:QUOT1 */
                           {
                               /* State QUOT1 - exit_action empty */
                               /* Transition from QUOT1 to EOD actions */
                               { aFE(DTF_EQ); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_qUOT2:    /* ADTParser:QUOT2 */
                           {
                               /* State QUOT2 - exit_action empty */
                               /* Transition from QUOT2 to EOD actions */
                               { aFE(DTF_EQ); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_sEC1:    /* ADTParser:SEC1 */
                           {
                               /* State SEC1 - exit_action empty */
                               /* Transition from SEC1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_sTART:    /* ADTParser:START */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to EOD actions */
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_tTL:    /* ADTParser:TTL */
                           {
                               /* State TTL - exit_action empty */
                               /* Transition from TTL to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_tTU:    /* ADTParser:TTU */
                           {
                               /* State TTU - exit_action empty */
                               /* Transition from TTU to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_u1:    /* ADTParser:U1 */
                           {
                               /* State U1 - exit_action empty */
                               /* Transition from U1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_u2:    /* ADTParser:U2 */
                           {
                               /* State U2 - exit_action empty */
                               /* Transition from U2 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_yEAR1:    /* ADTParser:YEAR1 */
                           {
                               /* State YEAR1 - exit_action empty */
                               /* Transition from YEAR1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
               };

           }

    protected:  
        virtual
        void
        appendToOut
                   ( WCHAR  ch          
                   , UINT   dtField     
                   , int    width       
                   ) = 0;

    protected:  
        void
        aI
          ( WCHAR  ch          
          )
           {
            appendToOut(ch, 0, 0);
           }

    protected:  
        void
        aF
          ( 
          )
           {
            appendToOut(0, _dtField, _width);
           }

    protected:  
        void
        aFI
           ( WCHAR  ch          
           )
           {
            aF(); aI(ch);
           }

    protected:  
        void
        aFE
           ( unsigned  f           
           )
           {
            appendToOut(0, f, 0);
           }

    public:     
        int
        getCurState
                   ( 
                   ) const
           {
            return this->curState;
           }

    public:     
        int
        isInFinalState
                      ( 
                      ) const
           {
            return (this->curState & ST_intStatefinalmask) ? 1 : 0;
           }

    protected:  
        virtual
        void
        customResetAutomata
                           ( 
                           )
           {
            return;
           }

    public:     
        void
        resetAutomata
                     ( 
                     )
           {
            this->clearStateStack(  );
            this->customResetAutomata(  );
            this->curState = ST_sTART;
           }

    public:     
        int
        isInInadmissibleFinalState
                                  ( 
                                  )
           {
            return this->curState==ST_intStateinadmissibleend ? 1 : 0;
           }

    protected:  
        int
        callState
                 ( int  newState     //!< new state code
                 )
           {
            try{
                this->stateStack.push(this->curState);
                this->curState = newState;
               }
            catch(...)
               {
                /* calling stackOverflow disabled by generator options */
               }
            return this->curState;
           }

    protected:  
        int
        spawnState
                  ( int  newState     //!< new state code
                  )
           {
                this->curState = newState;
                return this->curState;

           }

    protected:  
        int
        returnFromState
                       ( 
                       )
           {
            if (this->stateStack.empty())
               {
                /* calling stackUnderflow disabled by generator options */
               }
            else
               {
                this->curState = this->stateStack.top();
                this->stateStack.pop();
               }
            return this->curState;
           }

    protected:  
        void
        clearStateStack
                       ( 
                       )
           {
            while(!this->stateStack.empty()) this->stateStack.pop();
           }


};


}; // namespace impl {
}; // namespace format {
}; // namespace cli {

#endif /* FP_ADTPARSER_AUTOMATA_H */
