
#ifndef SRC_CORE_CLRCONV_H
#define SRC_CORE_CLRCONV_H

/* add this lines to your src
#ifndef SRC_CORE_CLRCONV_H
    #include "clrconv.h"
#endif
*/

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#ifndef CLI_FMTUTIL_H
    //#error "include fmtutil"
    #include <cli/fmtutil.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#if !defined(_UTILITY_) && !defined(_STLP_UTILITY) && !defined(__STD_UTILITY__) && !defined(_CPP_UTILITY) && !defined(_GLIBCXX_UTILITY)
    #include <utility>
#endif

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_IARGLIST_H
    #include <cli/iarglist.h>
#endif

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif

struct CColorrefConverter
{
    typedef ::std::pair< COLORREF, ::std::wstring > color_name_pair;
    typedef ::std::pair< ::std::wstring, COLORREF > name_color_pair;
    typedef ::cli::util::CAutoSortVector< color_name_pair, ::cli::util::pair_first_less< color_name_pair > >  color_name_vector;
    typedef ::cli::util::CAutoSortVector< name_color_pair, ::cli::util::pair_first_less< name_color_pair > >  name_color_vector;
    static color_name_vector colorToName;
    static name_color_vector nameToColor;

    CColorrefConverter()
       {
        // http://ru.wikipedia.org/wiki/Web-%D1%86%D0%B2%D0%B5%D1%82%D0%B0
        if (colorToName.empty())
           {
            colorToName.push_back( ::std::make_pair( RGB(0x00,0x00,0x00), L"black") );
            colorToName.push_back( ::std::make_pair( RGB(0xC0,0xC0,0xC0), L"silver") );
            colorToName.push_back( ::std::make_pair( RGB(0x80,0x80,0x80), L"gray") );
            colorToName.push_back( ::std::make_pair( RGB(0xFF,0xFF,0xFF), L"white") );
            colorToName.push_back( ::std::make_pair( RGB(0x80,0x00,0x00), L"maroon") );
            colorToName.push_back( ::std::make_pair( RGB(0xFF,0x00,0x00), L"red") );
            colorToName.push_back( ::std::make_pair( RGB(0x80,0x00,0x80), L"purple") );
            colorToName.push_back( ::std::make_pair( RGB(0xFF,0x00,0xFF), L"fuchsia") );
            colorToName.push_back( ::std::make_pair( RGB(0x00,0x80,0x00), L"green") );
            colorToName.push_back( ::std::make_pair( RGB(0x00,0xFF,0x00), L"lime") );
            colorToName.push_back( ::std::make_pair( RGB(0x80,0x80,0x00), L"olive") );
            colorToName.push_back( ::std::make_pair( RGB(0xFF,0xFF,0x00), L"yellow") );
            colorToName.push_back( ::std::make_pair( RGB(0x00,0x00,0x80), L"navy") );
            colorToName.push_back( ::std::make_pair( RGB(0x00,0x00,0xFF), L"blue") );
            colorToName.push_back( ::std::make_pair( RGB(0x00,0x80,0x80), L"teal") );
            colorToName.push_back( ::std::make_pair( RGB(0x00,0xFF,0xFF), L"aqua") );
            //colorToName.push_back( ::std::make_pair( RGB(0x00,0x00,0x00), L"") );
           }
        if (nameToColor.empty())
           {
            color_name_vector::const_iterator cit = colorToName.begin();
            for(; cit != colorToName.end(); ++cit)
               {
                nameToColor.push_back( ::std::make_pair(cit->second, cit->first) );
               }
           }
       }

    // there is next forms
    // #RGB
    // #RRGGBB
    // clrname
    // RGB(rrr,ggg,bbb)
    COLORREF convertFromString( const ::std::wstring &_str )
       {
        ::std::wstring str = _str;
        ::cli::fmtutil::toLowerCase(str);
        if (!str.empty() && str[0]==L'#') // numeric hex representation
           {
            while(str.size()<4) str.append(1, L'0');
            if (str.size()==4)
               {
                ::std::wstring tmp = L"#";
                tmp.append(2, str[1]);
                tmp.append(2, str[2]);
                tmp.append(2, str[3]);
                tmp.swap(str);
               }
            while(str.size()<7) str.append(1, L'0');
            COLORREF color = (COLORREF)-1;
            ::cli::fmtutil::convertFromString( str, 1, &color, (COLORREF)16 );
            return color;
           }
        if (str.size()>3 && ::cli::util::startsWith(str, L"rgb"))
           {
            SIZE_T pos = ::cli::fmtutil::skipWhitespaces( str, 3 );
            if (pos>=str.size()) return (COLORREF)-1;
            if (str[pos]!=L'(') return (COLORREF)-1;
            pos = ::cli::fmtutil::skipWhitespaces( str, pos+1 );
            UINT r = 0, g = 0, b = 0;
            pos = ::cli::fmtutil::convertFromString( str, pos  , &r, (UINT)10 );
            pos = ::cli::fmtutil::skipWhitespaces( str, pos );
            pos = ::cli::fmtutil::convertFromString( str, pos+1, &g, (UINT)10 );
            pos = ::cli::fmtutil::skipWhitespaces( str, pos );
            pos = ::cli::fmtutil::convertFromString( str, pos+1, &b, (UINT)10 );
            return RGB(r,g,b);
           }

        name_color_vector::const_iterator it = nameToColor.find( ::std::make_pair( str, (COLORREF)0 ) );
        if (it != nameToColor.end()) return it->second;
        return (COLORREF)-1;
       }


    ::std::wstring convertToNumeric( COLORREF clr, bool bUpper = true )
       {
        ::std::wstring str;
        ::cli::fmtutil::convertIntToStringEx( str, clr&0xFFFFFF, (COLORREF)16, 6, L'0', bUpper ? L'A' : L'a' );
        return ::std::wstring(L"#") + str;
       }

    ::std::wstring convertToRgb( COLORREF clr, bool bUpper = true)
       {
        ::std::wstring strRed, strGreen, strBlue;
        ::cli::fmtutil::convertIntToString( strRed  , COLORREF_GET_RED(clr)  , 10 );
        ::cli::fmtutil::convertIntToString( strGreen, COLORREF_GET_GREEN(clr), 10 );
        ::cli::fmtutil::convertIntToString( strBlue , COLORREF_GET_BLUE(clr) , 10 );
        return ::std::wstring(bUpper ? L"RGB(" : L"rgb") + strRed + ::std::wstring(L",") + strGreen + ::std::wstring(L",") + strBlue + ::std::wstring(L")");
       }

    ::std::wstring convertToName( COLORREF clr, bool bUpperName = false, bool bUpperNumeric = true )
       {
        ::cli::util::CAutoSortVector< ::std::pair< COLORREF, ::std::wstring > >::const_iterator it = colorToName.find( ::std::make_pair(clr,L"") );
        if (it==colorToName.end()) return convertToNumeric( clr, bUpperNumeric );
        ::std::wstring strRes = it->second;
        if (bUpperName) ::cli::fmtutil::toUpperCase(strRes);
        else ::cli::fmtutil::toLowerCase(strRes);
        return strRes;
       }

}; // struct CColorrefConverter


COLORREF convertColorrefFromString( const ::std::wstring &_str );
::std::wstring convertColorrefToNumeric( COLORREF clr, bool bUpper = true );
::std::wstring convertColorrefToRgb( COLORREF clr, bool bUpper = true);
::std::wstring convertColorrefToName( COLORREF clr, bool bUpperName = false, bool bUpperNumeric = true );


namespace cli
{
namespace format
{
namespace impl
{
SIZE_T
CLICALL colorrefFormaterImpl( WCHAR*    charBuf
                        , SIZE_T    charBufSize
                        , const WCHAR*    fmtStrChars
                        , SIZE_T    fmtStrCharsSize
                        , INTERFACE_CLI_IARGLIST*    arglist
                        , SIZE_T    argNo
                        );
}; // namespace impl
}; // namespace format
}; // namespace cli


/*
        HTML_COLOUR("black",   0x00,0x00,0x00)
        HTML_COLOUR("silver",  0xC0,0xC0,0xC0)
        HTML_COLOUR("gray",    0x80,0x80,0x80)
        HTML_COLOUR("white",   0xFF,0xFF,0xFF)
        HTML_COLOUR("maroon",  0x80,0x00,0x00)
        HTML_COLOUR("red",     0xFF,0x00,0x00)
        HTML_COLOUR("purple",  0x80,0x00,0x80)
        HTML_COLOUR("fuchsia", 0xFF,0x00,0xFF)
        HTML_COLOUR("green",   0x00,0x80,0x00)
        HTML_COLOUR("lime",    0x00,0xFF,0x00)
        HTML_COLOUR("olive",   0x80,0x80,0x00)
        HTML_COLOUR("yellow",  0xFF,0xFF,0x00)
        HTML_COLOUR("navy",    0x00,0x00,0x80)
        HTML_COLOUR("blue",    0x00,0x00,0xFF)
        HTML_COLOUR("teal",    0x00,0x80,0x80)
        HTML_COLOUR("aqua",    0x00,0xFF,0xFF)
*/


#endif /* SRC_CORE_CLRCONV_H */

