struct CXmlTextEntityProcessing : public CEntityProcessingBase {

    static  wchar_t entityChars[22];
    static  unsigned charToEntity[22];
    static  const wchar_t *entities[22];
    static  wchar_t entityToChar[22];


    const wchar_t* getEntitiesCharString() const
       {
        return &entityChars[0];
       }


    // convert entiry name to char
    bool convertEntityToChar( const std::wstring &entityName, std::wstring &val ) const
       {
        const wchar_t ** pBegin = &entities[0];
        const wchar_t ** pEnd   = pBegin + 21;
        const wchar_t **pFoundEntityName = (const wchar_t **)util::binary_find( pBegin, pEnd, entityName.c_str(), wstringLess );
        if (pFoundEntityName!=pEnd)
           {
            SIZE_T entityIdx = pFoundEntityName - &entities[0];
            val.assign(1,entityToChar[entityIdx]);
            return true;
           }
        return false;
       }


    // convert entiry char to entity name
    bool convertCharToEntity( wchar_t ch, std::wstring &entityNameAppendTo ) const
       {
        const wchar_t* pEntityChar = util::binary_find( entityChars, entityChars+21, ch );
        if (pEntityChar!=(entityChars+21))
           {
            SIZE_T charIdx = (pEntityChar - entityChars);
            SIZE_T entityIdx = charToEntity[charIdx];
            entityNameAppendTo.append(entities[entityIdx]);
            return true;
           }
        return false;
       }


}; // struct CXmlTextEntityProcessing

wchar_t CXmlTextEntityProcessing::entityChars[22] = {
  0x0E, // 0  (#x0E)
  0x0F, // 1  (#x0F)
  0x10, // 2  (#x10)
  0x11, // 3  (#x11)
  0x12, // 4  (#x12)
  0x13, // 5  (#x13)
  0x14, // 6  (#x14)
  0x15, // 7  (#x15)
  0x16, // 8  (#x16)
  0x17, // 9  (#x17)
  0x18, // 10  (#x18)
  0x19, // 11  (#x19)
  0x1A, // 12  (#x1A)
  0x1B, // 13  (#x1B)
  0x1C, // 14  (#x1C)
  0x1D, // 15  (#x1D)
  0x1E, // 16  (#x1E)
  0x1F, // 17  (#x1F)
  0x27, // 18  (apos)
  0x3C, // 19  (lt)
  0x3E, // 20  (gt)
  0
};

unsigned CXmlTextEntityProcessing::charToEntity[22] = {
  0, // 0  (#x0E)
  1, // 1  (#x0F)
  2, // 2  (#x10)
  3, // 3  (#x11)
  4, // 4  (#x12)
  5, // 5  (#x13)
  6, // 6  (#x14)
  7, // 7  (#x15)
  8, // 8  (#x16)
  9, // 9  (#x17)
  10, // 10  (#x18)
  11, // 11  (#x19)
  12, // 12  (#x1A)
  13, // 13  (#x1B)
  14, // 14  (#x1C)
  15, // 15  (#x1D)
  16, // 16  (#x1E)
  17, // 17  (#x1F)
  18, // 18  (apos)
  20, // 19  (lt)
  19, // 20  (gt)
  0xFA
};

const wchar_t* CXmlTextEntityProcessing::entities[22] = {
  L"#x0E", // 0 (0x0E)
  L"#x0F", // 1 (0x0F)
  L"#x10", // 2 (0x10)
  L"#x11", // 3 (0x11)
  L"#x12", // 4 (0x12)
  L"#x13", // 5 (0x13)
  L"#x14", // 6 (0x14)
  L"#x15", // 7 (0x15)
  L"#x16", // 8 (0x16)
  L"#x17", // 9 (0x17)
  L"#x18", // 10 (0x18)
  L"#x19", // 11 (0x19)
  L"#x1A", // 12 (0x1A)
  L"#x1B", // 13 (0x1B)
  L"#x1C", // 14 (0x1C)
  L"#x1D", // 15 (0x1D)
  L"#x1E", // 16 (0x1E)
  L"#x1F", // 17 (0x1F)
  L"apos", // 18 (0x27)
  L"gt", // 19 (0x3E)
  L"lt", // 20 (0x3C)
  L"END"
};

wchar_t CXmlTextEntityProcessing::entityToChar[22] = {
  0x0E, // 0 (#x0E)
  0x0F, // 1 (#x0F)
  0x10, // 2 (#x10)
  0x11, // 3 (#x11)
  0x12, // 4 (#x12)
  0x13, // 5 (#x13)
  0x14, // 6 (#x14)
  0x15, // 7 (#x15)
  0x16, // 8 (#x16)
  0x17, // 9 (#x17)
  0x18, // 10 (#x18)
  0x19, // 11 (#x19)
  0x1A, // 12 (#x1A)
  0x1B, // 13 (#x1B)
  0x1C, // 14 (#x1C)
  0x1D, // 15 (#x1D)
  0x1E, // 16 (#x1E)
  0x1F, // 17 (#x1F)
  0x27, // 18 (apos)
  0x3E, // 19 (gt)
  0x3C, // 20 (lt)
  0xFA
};

