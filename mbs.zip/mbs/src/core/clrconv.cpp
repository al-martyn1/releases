#define CLI_INTERNAL

#ifndef SRC_CORE_CLRCONV_H
    #include "clrconv.h"
#endif

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_IARGLIST_H
    #include <cli/iarglist.h>
#endif

CColorrefConverter::color_name_vector  CColorrefConverter::colorToName;
CColorrefConverter::name_color_vector  CColorrefConverter::nameToColor;

static CColorrefConverter colorrefConverter;

COLORREF convertColorrefFromString( const ::std::wstring &_str )
   {
    return colorrefConverter.convertFromString(_str);
   }

::std::wstring convertColorrefToNumeric( COLORREF clr, bool bUpper )
   {
    return colorrefConverter.convertToNumeric( clr, bUpper );
   }

::std::wstring convertColorrefToRgb( COLORREF clr, bool bUpper )
   {
    return colorrefConverter.convertToRgb( clr, bUpper );
   }

::std::wstring convertColorrefToName( COLORREF clr, bool bUpperName, bool bUpperNumeric )
   {
    return colorrefConverter.convertToName( clr, bUpperName, bUpperNumeric );
   }



namespace cli
{
namespace format
{
namespace impl
{

struct CColorrefFormaterImpl
{
    void operator()( std::wstring &resStr, const std::wstring &formatString, INTERFACE_CLI_IARGLIST* arglist, SIZE_T argNo) const
       {
        if (!arglist) return; // no value for formating
        COLORREF clr;
        arglist->getColorref( argNo, &clr );
        std::wstring formatStringUpper = formatString;

        if (formatStringUpper == L"RGB")
           {
            resStr = convertColorrefToRgb( clr, formatString[0]==L'R' );
            return;
           }
        else if (formatStringUpper == L"NUM" || formatStringUpper == L"NUMERIC")
           {
            resStr = convertColorrefToNumeric( clr, formatString[0]==L'N' );
            return;
           }
        else if (formatStringUpper == L"NAME" || formatStringUpper == L"ALPHA")
           {
            resStr = convertColorrefToName( clr, (formatString[0]==L'N' || formatString[0]==L'A'), (formatString[0]==L'N' || formatString[0]==L'A') );
            return;
           }
        resStr = convertColorrefToName( clr, false, true );
       }
};


SIZE_T
CLICALL colorrefFormaterImpl( WCHAR*    charBuf
                        , SIZE_T    charBufSize
                        , const WCHAR*    fmtStrChars
                        , SIZE_T    fmtStrCharsSize
                        , INTERFACE_CLI_IARGLIST*    arglist
                        , SIZE_T    argNo
                        )
   {
    return ::cli::format::cliFormaterImplementationHelper( CColorrefFormaterImpl(), charBuf, charBufSize, fmtStrChars, fmtStrCharsSize, arglist, argNo );
    //return 0;
   }

}; // namespace impl
}; // namespace format
}; // namespace cli


