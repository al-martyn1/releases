#ifndef FP_ADGPARSER_AUTOMATA_H
#define FP_ADGPARSER_AUTOMATA_H

/* Warning! Automaticaly generated file, do not edit */

#include <stack>
#include "dateTimeHlp.h"


#ifndef CLI_FORMAT_IMPL_CDGFORMATPARSER_STACK_USED
#define CLI_FORMAT_IMPL_CDGFORMATPARSER_STACK_USED
#endif

#ifndef CLI_FORMAT_IMPL_CDGFORMATPARSER_NO_OVERFLOW_CALLS
#define CLI_FORMAT_IMPL_CDGFORMATPARSER_NO_OVERFLOW_CALLS
#endif




namespace cli {
namespace format {
namespace impl {

class CDGFormatParser {

    public:     ::std::wstring       formatedOut ;
    protected:  UINT                 _dtField    ;
    protected:  int                  _width      ;
    protected:  int                  curState    ; //!< Automaticaly added member for saving current automata state
    public:     static const int     ST_adgparser0Deg1 = 0x00000001; //!< ADGParser:DEG1
    public:     static const int     ST_adgparser0Eod = 0x80000002; //!< ADGParser:EOD
    public:     static const int     ST_adgparser0Mdeg1 = 0x00000003; //!< ADGParser:MDEG1
    public:     static const int     ST_adgparser0Mdeg2 = 0x00000004; //!< ADGParser:MDEG2
    public:     static const int     ST_adgparser0Min1 = 0x00000005; //!< ADGParser:MIN1
    public:     static const int     ST_adgparser0Mmin1 = 0x00000006; //!< ADGParser:MMIN1
    public:     static const int     ST_adgparser0Mmin2 = 0x00000007; //!< ADGParser:MMIN2
    public:     static const int     ST_adgparser0Msec1 = 0x00000008; //!< ADGParser:MSEC1
    public:     static const int     ST_adgparser0Msec2 = 0x00000009; //!< ADGParser:MSEC2
    public:     static const int     ST_adgparser0Msec3 = 0x0000000A; //!< ADGParser:MSEC3
    public:     static const int     ST_adgparser0Msec4 = 0x0000000B; //!< ADGParser:MSEC4
    public:     static const int     ST_adgparser0Quot1 = 0x0000000C; //!< ADGParser:QUOT1
    public:     static const int     ST_adgparser0Quot2 = 0x0000000D; //!< ADGParser:QUOT2
    public:     static const int     ST_adgparser0Sec1 = 0x0000000E; //!< ADGParser:SEC1
    public:     static const int     ST_adgparser0Spawn1 = 0x0000000F; //!< ADGParser:SPAWN1
    public:     static const int     ST_adgparser0Start = 0x00000010; //!< ADGParser:START
    public:     static const int     ST_dEG1      = 0x00000011; //!< ADGParser:DEG1
    public:     static const int     ST_eOD       = 0x80000012; //!< ADGParser:EOD
    public:     static const int     ST_mDEG1     = 0x00000013; //!< ADGParser:MDEG1
    public:     static const int     ST_mDEG2     = 0x00000014; //!< ADGParser:MDEG2
    public:     static const int     ST_mIN1      = 0x00000015; //!< ADGParser:MIN1
    public:     static const int     ST_mMIN1     = 0x00000016; //!< ADGParser:MMIN1
    public:     static const int     ST_mMIN2     = 0x00000017; //!< ADGParser:MMIN2
    public:     static const int     ST_mSEC1     = 0x00000018; //!< ADGParser:MSEC1
    public:     static const int     ST_mSEC2     = 0x00000019; //!< ADGParser:MSEC2
    public:     static const int     ST_mSEC3     = 0x0000001A; //!< ADGParser:MSEC3
    public:     static const int     ST_mSEC4     = 0x0000001B; //!< ADGParser:MSEC4
    public:     static const int     ST_qUOT1     = 0x0000001C; //!< ADGParser:QUOT1
    public:     static const int     ST_qUOT2     = 0x0000001D; //!< ADGParser:QUOT2
    public:     static const int     ST_sEC1      = 0x0000001E; //!< ADGParser:SEC1
    public:     static const int     ST_sPAWN1    = 0x0000001F; //!< ADGParser:SPAWN1
    public:     static const int     ST_sTART     = 0x00000020; //!< ADGParser:START
    public:     static const int     ST_intStatefinalmask = 0x80000000; //!< __int_stateFinalMask__
    public:     static const int     ST_intStateinadmissibleend                                   = 0x80000021; //!< :
    public:     static const int     LIM_stackSizeMax = 256; //!< Automaticaly generated stack size limit constant
    protected:  std::stack<int>      stateStack  ; //!< Automaticaly generated state stack


    public:     
        void
        putChar
               ( WCHAR  ch          
               )
           {
            /* guard variable - ch */
            switch(this->curState)
               {
                case ST_adgparser0Deg1:    /* ADGParser:DEG1 */
                        if ((ch==L'd') && (_width<2)) /* Guard: ['d',(_width<2)] */
                           {
                               /* Transition from ADGParser_0_DEG1 to ADGParser_0_DEG1 actions */
                               { ++_width; }
                               /* State ADGParser_0_DEG1 - do_action empty */
                            this->curState = ST_adgparser0Deg1;
                           }
                        else
                           {
                               /* State ADGParser_0_DEG1 - exit_action empty */
                               /* Transition from ADGParser_0_DEG1 to ADGParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADGParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adgparser0Mdeg1:    /* ADGParser:MDEG1 */
                        if ((ch==L'g') && (_width<5)) /* Guard: ['g',(_width<5)] */
                           {
                               /* Transition from ADGParser_0_MDEG1 to ADGParser_0_MDEG1 actions */
                               { ++_width; }
                               /* State ADGParser_0_MDEG1 - do_action empty */
                            this->curState = ST_adgparser0Mdeg1;
                           }
                        else
                           {
                               /* State ADGParser_0_MDEG1 - exit_action empty */
                               /* Transition from ADGParser_0_MDEG1 to ADGParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADGParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adgparser0Mdeg2:    /* ADGParser:MDEG2 */
                        if ((ch==L'G') && (_width<5)) /* Guard: ['G',(_width<5)] */
                           {
                               /* Transition from ADGParser_0_MDEG2 to ADGParser_0_MDEG2 actions */
                               { ++_width; }
                               /* State ADGParser_0_MDEG2 - do_action empty */
                            this->curState = ST_adgparser0Mdeg2;
                           }
                        else
                           {
                               /* State ADGParser_0_MDEG2 - exit_action empty */
                               /* Transition from ADGParser_0_MDEG2 to ADGParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADGParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adgparser0Min1:    /* ADGParser:MIN1 */
                        if (ch==L'm') /* Guard: ['m'] */
                           {
                               /* State ADGParser_0_MIN1 - exit_action empty */
                               /* Transition from ADGParser_0_MIN1 to ADGParser_0_START actions */
                               { ++_width; aF(); }
                               /* State ADGParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adgparser0Start;
                           }
                        else
                           {
                               /* State ADGParser_0_MIN1 - exit_action empty */
                               /* Transition from ADGParser_0_MIN1 to ADGParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADGParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adgparser0Mmin1:    /* ADGParser:MMIN1 */
                        if ((ch==L't') && (_width<5)) /* Guard: ['t',(_width<5)] */
                           {
                               /* Transition from ADGParser_0_MMIN1 to ADGParser_0_MMIN1 actions */
                               { ++_width; }
                               /* State ADGParser_0_MMIN1 - do_action empty */
                            this->curState = ST_adgparser0Mmin1;
                           }
                        else
                           {
                               /* State ADGParser_0_MMIN1 - exit_action empty */
                               /* Transition from ADGParser_0_MMIN1 to ADGParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADGParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adgparser0Mmin2:    /* ADGParser:MMIN2 */
                        if ((ch==L'T') && (_width<5)) /* Guard: ['T',(_width<5)] */
                           {
                               /* Transition from ADGParser_0_MMIN2 to ADGParser_0_MMIN2 actions */
                               { ++_width; }
                               /* State ADGParser_0_MMIN2 - do_action empty */
                            this->curState = ST_adgparser0Mmin2;
                           }
                        else
                           {
                               /* State ADGParser_0_MMIN2 - exit_action empty */
                               /* Transition from ADGParser_0_MMIN2 to ADGParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADGParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adgparser0Msec1:    /* ADGParser:MSEC1 */
                        if ((ch==L'c') && (_width<5)) /* Guard: ['c',(_width<5)] */
                           {
                               /* Transition from ADGParser_0_MSEC1 to ADGParser_0_MSEC1 actions */
                               { ++_width; }
                               /* State ADGParser_0_MSEC1 - do_action empty */
                            this->curState = ST_adgparser0Msec1;
                           }
                        else
                           {
                               /* State ADGParser_0_MSEC1 - exit_action empty */
                               /* Transition from ADGParser_0_MSEC1 to ADGParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADGParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adgparser0Msec2:    /* ADGParser:MSEC2 */
                        if ((ch==L'z') && (_width<5)) /* Guard: ['z',(_width<5)] */
                           {
                               /* Transition from ADGParser_0_MSEC2 to ADGParser_0_MSEC2 actions */
                               { ++_width; }
                               /* State ADGParser_0_MSEC2 - do_action empty */
                            this->curState = ST_adgparser0Msec2;
                           }
                        else
                           {
                               /* State ADGParser_0_MSEC2 - exit_action empty */
                               /* Transition from ADGParser_0_MSEC2 to ADGParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADGParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adgparser0Msec3:    /* ADGParser:MSEC3 */
                        if ((ch==L'C') && (_width<5)) /* Guard: ['C',(_width<5)] */
                           {
                               /* Transition from ADGParser_0_MSEC3 to ADGParser_0_MSEC3 actions */
                               { ++_width; }
                               /* State ADGParser_0_MSEC3 - do_action empty */
                            this->curState = ST_adgparser0Msec3;
                           }
                        else
                           {
                               /* State ADGParser_0_MSEC3 - exit_action empty */
                               /* Transition from ADGParser_0_MSEC3 to ADGParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADGParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adgparser0Msec4:    /* ADGParser:MSEC4 */
                        if ((ch==L'Z') && (_width<5)) /* Guard: ['Z',(_width<5)] */
                           {
                               /* Transition from ADGParser_0_MSEC4 to ADGParser_0_MSEC4 actions */
                               { ++_width; }
                               /* State ADGParser_0_MSEC4 - do_action empty */
                            this->curState = ST_adgparser0Msec4;
                           }
                        else
                           {
                               /* State ADGParser_0_MSEC4 - exit_action empty */
                               /* Transition from ADGParser_0_MSEC4 to ADGParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADGParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adgparser0Quot1:    /* ADGParser:QUOT1 */
                        if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State ADGParser_0_QUOT1 - exit_action empty */
                               /* Transition from ADGParser_0_QUOT1 to ADGParser_0_QUOT2 actions */
                               /* State ADGParser_0_QUOT2 - entry_action empty */
                            this->curState = ST_adgparser0Quot2;
                           }
                        else
                           {
                               /* Transition from ADGParser_0_QUOT1 to ADGParser_0_QUOT1 actions */
                               { aI(ch); }
                               /* State ADGParser_0_QUOT1 - do_action empty */
                            this->curState = ST_adgparser0Quot1;
                           }
                     break;
                case ST_adgparser0Quot2:    /* ADGParser:QUOT2 */
                        if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State ADGParser_0_QUOT2 - exit_action empty */
                               /* Transition from ADGParser_0_QUOT2 to ADGParser_0_QUOT1 actions */
                               { aI(ch); }
                               /* State ADGParser_0_QUOT1 - entry_action empty */
                            this->curState = ST_adgparser0Quot1;
                           }
                        else
                           {
                               /* State ADGParser_0_QUOT2 - exit_action empty */
                               /* Transition from ADGParser_0_QUOT2 to ADGParser_0_SPAWN1 actions */
                               { aFE(DTF_EQ); }
                               /* State ADGParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adgparser0Sec1:    /* ADGParser:SEC1 */
                        if (ch==L's') /* Guard: ['s'] */
                           {
                               /* State ADGParser_0_SEC1 - exit_action empty */
                               /* Transition from ADGParser_0_SEC1 to ADGParser_0_START actions */
                               { ++_width; aF(); }
                               /* State ADGParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adgparser0Start;
                           }
                        else
                           {
                               /* State ADGParser_0_SEC1 - exit_action empty */
                               /* Transition from ADGParser_0_SEC1 to ADGParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ADGParser_0_SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_adgparser0Start:    /* ADGParser:START */
                        if (ch==L'z') /* Guard: ['z'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_MSEC2 actions */
                               { _dtField=DTF_MSEC|DTF_ZEROS; }
                               /* State ADGParser_0_MSEC2 - entry_action empty */
                            this->curState = ST_adgparser0Msec2;
                           }
                        else if (ch==L't') /* Guard: ['t'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_MMIN1 actions */
                               { _dtField=DTF_MMIN|DTF_ZEROS; }
                               /* State ADGParser_0_MMIN1 - entry_action empty */
                            this->curState = ST_adgparser0Mmin1;
                           }
                        else if (ch==L's') /* Guard: ['s'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_SEC1 actions */
                               { _dtField=DTF_SEC; }
                               /* State ADGParser_0_SEC1 - entry_action empty */
                            this->curState = ST_adgparser0Sec1;
                           }
                        else if (ch==L'm') /* Guard: ['m'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_MIN1 actions */
                               { _dtField=DTF_MIN; }
                               /* State ADGParser_0_MIN1 - entry_action empty */
                            this->curState = ST_adgparser0Min1;
                           }
                        else if (ch==L'g') /* Guard: ['g'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_MDEG1 actions */
                               { _dtField=DTF_MDEG|DTF_ZEROS; }
                               /* State ADGParser_0_MDEG1 - entry_action empty */
                            this->curState = ST_adgparser0Mdeg1;
                           }
                        else if (ch==L'd') /* Guard: ['d'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_DEG1 actions */
                               { _dtField=DTF_DEGREE; }
                               /* State ADGParser_0_DEG1 - entry_action empty */
                            this->curState = ST_adgparser0Deg1;
                           }
                        else if (ch==L'c') /* Guard: ['c'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_MSEC1 actions */
                               { _dtField=DTF_MSEC|DTF_ZEROS; }
                               /* State ADGParser_0_MSEC1 - entry_action empty */
                            this->curState = ST_adgparser0Msec1;
                           }
                        else if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_QUOT1 actions */
                               { aFE(DTF_SQ); }
                               /* State ADGParser_0_QUOT1 - entry_action empty */
                            this->curState = ST_adgparser0Quot1;
                           }
                        else if (ch==L'Z') /* Guard: ['Z'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_MSEC4 actions */
                               { _dtField=DTF_MSEC; }
                               /* State ADGParser_0_MSEC4 - entry_action empty */
                            this->curState = ST_adgparser0Msec4;
                           }
                        else if (ch==L'T') /* Guard: ['T'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_MMIN2 actions */
                               { _dtField=DTF_MMIN; }
                               /* State ADGParser_0_MMIN2 - entry_action empty */
                            this->curState = ST_adgparser0Mmin2;
                           }
                        else if (ch==L'O') /* Guard: ['O'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_START actions */
                               { aFE(DTF_SSTR); }
                               /* State ADGParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adgparser0Start;
                           }
                        else if (ch==L'N' || ch==L'S') /* Guard: ['N','S'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_START actions */
                               { aFE(DTF_LAT); }
                               /* State ADGParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adgparser0Start;
                           }
                        else if (ch==L'M') /* Guard: ['M'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_START actions */
                               { aFE(DTF_MSTR); }
                               /* State ADGParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adgparser0Start;
                           }
                        else if (ch==L'G') /* Guard: ['G'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_MDEG2 actions */
                               { _dtField=DTF_MDEG; }
                               /* State ADGParser_0_MDEG2 - entry_action empty */
                            this->curState = ST_adgparser0Mdeg2;
                           }
                        else if (ch==L'E' || ch==L'W') /* Guard: ['E','W'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_START actions */
                               { aFE(DTF_LONG); }
                               /* State ADGParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adgparser0Start;
                           }
                        else if (ch==L'D') /* Guard: ['D'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_START actions */
                               { aFE(DTF_DSTR); }
                               /* State ADGParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adgparser0Start;
                           }
                        else if (ch==L'C') /* Guard: ['C'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_MSEC3 actions */
                               { _dtField=DTF_MSEC; }
                               /* State ADGParser_0_MSEC3 - entry_action empty */
                            this->curState = ST_adgparser0Msec3;
                           }
                        else if (ch==L'?') /* Guard: ['?'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_START actions */
                               { aFE(DTF_IGNORE); }
                               /* State ADGParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adgparser0Start;
                           }
                        else if (ch==L'+') /* Guard: ['+'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_START actions */
                               { aFE(DTF_SIGN); }
                               /* State ADGParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adgparser0Start;
                           }
                        else if (ch==L'#') /* Guard: ['#'] */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_START actions */
                               { aFE(DTF_SIGNORE); }
                               /* State ADGParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_adgparser0Start;
                           }
                        else
                           {
                               /* Transition from ADGParser_0_START to ADGParser_0_START actions */
                               { aI(ch); }
                               /* State ADGParser_0_START - do_action empty */
                            this->curState = ST_adgparser0Start;
                           }
                     break;
                case ST_dEG1:    /* ADGParser:DEG1 */
                        if ((ch==L'd') && (_width<2)) /* Guard: ['d',(_width<2)] */
                           {
                               /* Transition from DEG1 to DEG1 actions */
                               { ++_width; }
                               /* State DEG1 - do_action empty */
                            this->curState = ST_dEG1;
                           }
                        else
                           {
                               /* State DEG1 - exit_action empty */
                               /* Transition from DEG1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mDEG1:    /* ADGParser:MDEG1 */
                        if ((ch==L'g') && (_width<5)) /* Guard: ['g',(_width<5)] */
                           {
                               /* Transition from MDEG1 to MDEG1 actions */
                               { ++_width; }
                               /* State MDEG1 - do_action empty */
                            this->curState = ST_mDEG1;
                           }
                        else
                           {
                               /* State MDEG1 - exit_action empty */
                               /* Transition from MDEG1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mDEG2:    /* ADGParser:MDEG2 */
                        if ((ch==L'G') && (_width<5)) /* Guard: ['G',(_width<5)] */
                           {
                               /* Transition from MDEG2 to MDEG2 actions */
                               { ++_width; }
                               /* State MDEG2 - do_action empty */
                            this->curState = ST_mDEG2;
                           }
                        else
                           {
                               /* State MDEG2 - exit_action empty */
                               /* Transition from MDEG2 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mIN1:    /* ADGParser:MIN1 */
                        if (ch==L'm') /* Guard: ['m'] */
                           {
                               /* State MIN1 - exit_action empty */
                               /* Transition from MIN1 to START actions */
                               { ++_width; aF(); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else
                           {
                               /* State MIN1 - exit_action empty */
                               /* Transition from MIN1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mMIN1:    /* ADGParser:MMIN1 */
                        if ((ch==L't') && (_width<5)) /* Guard: ['t',(_width<5)] */
                           {
                               /* Transition from MMIN1 to MMIN1 actions */
                               { ++_width; }
                               /* State MMIN1 - do_action empty */
                            this->curState = ST_mMIN1;
                           }
                        else
                           {
                               /* State MMIN1 - exit_action empty */
                               /* Transition from MMIN1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mMIN2:    /* ADGParser:MMIN2 */
                        if ((ch==L'T') && (_width<5)) /* Guard: ['T',(_width<5)] */
                           {
                               /* Transition from MMIN2 to MMIN2 actions */
                               { ++_width; }
                               /* State MMIN2 - do_action empty */
                            this->curState = ST_mMIN2;
                           }
                        else
                           {
                               /* State MMIN2 - exit_action empty */
                               /* Transition from MMIN2 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mSEC1:    /* ADGParser:MSEC1 */
                        if ((ch==L'c') && (_width<5)) /* Guard: ['c',(_width<5)] */
                           {
                               /* Transition from MSEC1 to MSEC1 actions */
                               { ++_width; }
                               /* State MSEC1 - do_action empty */
                            this->curState = ST_mSEC1;
                           }
                        else
                           {
                               /* State MSEC1 - exit_action empty */
                               /* Transition from MSEC1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mSEC2:    /* ADGParser:MSEC2 */
                        if ((ch==L'z') && (_width<5)) /* Guard: ['z',(_width<5)] */
                           {
                               /* Transition from MSEC2 to MSEC2 actions */
                               { ++_width; }
                               /* State MSEC2 - do_action empty */
                            this->curState = ST_mSEC2;
                           }
                        else
                           {
                               /* State MSEC2 - exit_action empty */
                               /* Transition from MSEC2 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mSEC3:    /* ADGParser:MSEC3 */
                        if ((ch==L'C') && (_width<5)) /* Guard: ['C',(_width<5)] */
                           {
                               /* Transition from MSEC3 to MSEC3 actions */
                               { ++_width; }
                               /* State MSEC3 - do_action empty */
                            this->curState = ST_mSEC3;
                           }
                        else
                           {
                               /* State MSEC3 - exit_action empty */
                               /* Transition from MSEC3 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mSEC4:    /* ADGParser:MSEC4 */
                        if ((ch==L'Z') && (_width<5)) /* Guard: ['Z',(_width<5)] */
                           {
                               /* Transition from MSEC4 to MSEC4 actions */
                               { ++_width; }
                               /* State MSEC4 - do_action empty */
                            this->curState = ST_mSEC4;
                           }
                        else
                           {
                               /* State MSEC4 - exit_action empty */
                               /* Transition from MSEC4 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_qUOT1:    /* ADGParser:QUOT1 */
                        if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State QUOT1 - exit_action empty */
                               /* Transition from QUOT1 to QUOT2 actions */
                               /* State QUOT2 - entry_action empty */
                            this->curState = ST_qUOT2;
                           }
                        else
                           {
                               /* Transition from QUOT1 to QUOT1 actions */
                               { aI(ch); }
                               /* State QUOT1 - do_action empty */
                            this->curState = ST_qUOT1;
                           }
                     break;
                case ST_qUOT2:    /* ADGParser:QUOT2 */
                        if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State QUOT2 - exit_action empty */
                               /* Transition from QUOT2 to QUOT1 actions */
                               { aI(ch); }
                               /* State QUOT1 - entry_action empty */
                            this->curState = ST_qUOT1;
                           }
                        else
                           {
                               /* State QUOT2 - exit_action empty */
                               /* Transition from QUOT2 to SPAWN1 actions */
                               { aFE(DTF_EQ); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_sEC1:    /* ADGParser:SEC1 */
                        if (ch==L's') /* Guard: ['s'] */
                           {
                               /* State SEC1 - exit_action empty */
                               /* Transition from SEC1 to START actions */
                               { ++_width; aF(); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else
                           {
                               /* State SEC1 - exit_action empty */
                               /* Transition from SEC1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ADGParser_0_START - call_entry_action empty */
                               /* Called State ADGParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_adgparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_sTART:    /* ADGParser:START */
                        if (ch==L'z') /* Guard: ['z'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MSEC2 actions */
                               { _dtField=DTF_MSEC|DTF_ZEROS; }
                               /* State MSEC2 - entry_action empty */
                            this->curState = ST_mSEC2;
                           }
                        else if (ch==L't') /* Guard: ['t'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MMIN1 actions */
                               { _dtField=DTF_MMIN|DTF_ZEROS; }
                               /* State MMIN1 - entry_action empty */
                            this->curState = ST_mMIN1;
                           }
                        else if (ch==L's') /* Guard: ['s'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to SEC1 actions */
                               { _dtField=DTF_SEC; }
                               /* State SEC1 - entry_action empty */
                            this->curState = ST_sEC1;
                           }
                        else if (ch==L'm') /* Guard: ['m'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MIN1 actions */
                               { _dtField=DTF_MIN; }
                               /* State MIN1 - entry_action empty */
                            this->curState = ST_mIN1;
                           }
                        else if (ch==L'g') /* Guard: ['g'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MDEG1 actions */
                               { _dtField=DTF_MDEG|DTF_ZEROS; }
                               /* State MDEG1 - entry_action empty */
                            this->curState = ST_mDEG1;
                           }
                        else if (ch==L'd') /* Guard: ['d'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to DEG1 actions */
                               { _dtField=DTF_DEGREE; }
                               /* State DEG1 - entry_action empty */
                            this->curState = ST_dEG1;
                           }
                        else if (ch==L'c') /* Guard: ['c'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MSEC1 actions */
                               { _dtField=DTF_MSEC|DTF_ZEROS; }
                               /* State MSEC1 - entry_action empty */
                            this->curState = ST_mSEC1;
                           }
                        else if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to QUOT1 actions */
                               { aFE(DTF_SQ); }
                               /* State QUOT1 - entry_action empty */
                            this->curState = ST_qUOT1;
                           }
                        else if (ch==L'Z') /* Guard: ['Z'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MSEC4 actions */
                               { _dtField=DTF_MSEC; }
                               /* State MSEC4 - entry_action empty */
                            this->curState = ST_mSEC4;
                           }
                        else if (ch==L'T') /* Guard: ['T'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MMIN2 actions */
                               { _dtField=DTF_MMIN; }
                               /* State MMIN2 - entry_action empty */
                            this->curState = ST_mMIN2;
                           }
                        else if (ch==L'O') /* Guard: ['O'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_SSTR); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else if (ch==L'N' || ch==L'S') /* Guard: ['N','S'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_LAT); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else if (ch==L'M') /* Guard: ['M'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_MSTR); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else if (ch==L'G') /* Guard: ['G'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MDEG2 actions */
                               { _dtField=DTF_MDEG; }
                               /* State MDEG2 - entry_action empty */
                            this->curState = ST_mDEG2;
                           }
                        else if (ch==L'E' || ch==L'W') /* Guard: ['E','W'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_LONG); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else if (ch==L'D') /* Guard: ['D'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_DSTR); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else if (ch==L'C') /* Guard: ['C'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MSEC3 actions */
                               { _dtField=DTF_MSEC; }
                               /* State MSEC3 - entry_action empty */
                            this->curState = ST_mSEC3;
                           }
                        else if (ch==L'?') /* Guard: ['?'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_IGNORE); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else if (ch==L'+') /* Guard: ['+'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_SIGN); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else if (ch==L'#') /* Guard: ['#'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_SIGNORE); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else
                           {
                               /* Transition from START to START actions */
                               { aI(ch); }
                               /* State START - do_action empty */
                            this->curState = ST_sTART;
                           }
                     break;
               };

           }

    public:     
        void
        eod
           ( 
           )
           {
            /* there is no guard variable */
            switch(this->curState)
               {
                case ST_adgparser0Deg1:    /* ADGParser:DEG1 */
                           {
                               /* State ADGParser_0_DEG1 - exit_action empty */
                               /* Transition from ADGParser_0_DEG1 to ADGParser_0_EOD actions */
                               { aF(); }
                               /* End state ADGParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adgparser0Mdeg1:    /* ADGParser:MDEG1 */
                           {
                               /* State ADGParser_0_MDEG1 - exit_action empty */
                               /* Transition from ADGParser_0_MDEG1 to ADGParser_0_EOD actions */
                               { aF(); }
                               /* End state ADGParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adgparser0Mdeg2:    /* ADGParser:MDEG2 */
                           {
                               /* State ADGParser_0_MDEG2 - exit_action empty */
                               /* Transition from ADGParser_0_MDEG2 to ADGParser_0_EOD actions */
                               { aF(); }
                               /* End state ADGParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adgparser0Min1:    /* ADGParser:MIN1 */
                           {
                               /* State ADGParser_0_MIN1 - exit_action empty */
                               /* Transition from ADGParser_0_MIN1 to ADGParser_0_EOD actions */
                               { aF(); }
                               /* End state ADGParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adgparser0Mmin1:    /* ADGParser:MMIN1 */
                           {
                               /* State ADGParser_0_MMIN1 - exit_action empty */
                               /* Transition from ADGParser_0_MMIN1 to ADGParser_0_EOD actions */
                               { aF(); }
                               /* End state ADGParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adgparser0Mmin2:    /* ADGParser:MMIN2 */
                           {
                               /* State ADGParser_0_MMIN2 - exit_action empty */
                               /* Transition from ADGParser_0_MMIN2 to ADGParser_0_EOD actions */
                               { aF(); }
                               /* End state ADGParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adgparser0Msec1:    /* ADGParser:MSEC1 */
                           {
                               /* State ADGParser_0_MSEC1 - exit_action empty */
                               /* Transition from ADGParser_0_MSEC1 to ADGParser_0_EOD actions */
                               { aF(); }
                               /* End state ADGParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adgparser0Msec2:    /* ADGParser:MSEC2 */
                           {
                               /* State ADGParser_0_MSEC2 - exit_action empty */
                               /* Transition from ADGParser_0_MSEC2 to ADGParser_0_EOD actions */
                               { aF(); }
                               /* End state ADGParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adgparser0Msec3:    /* ADGParser:MSEC3 */
                           {
                               /* State ADGParser_0_MSEC3 - exit_action empty */
                               /* Transition from ADGParser_0_MSEC3 to ADGParser_0_EOD actions */
                               { aF(); }
                               /* End state ADGParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adgparser0Msec4:    /* ADGParser:MSEC4 */
                           {
                               /* State ADGParser_0_MSEC4 - exit_action empty */
                               /* Transition from ADGParser_0_MSEC4 to ADGParser_0_EOD actions */
                               { aF(); }
                               /* End state ADGParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adgparser0Quot1:    /* ADGParser:QUOT1 */
                           {
                               /* State ADGParser_0_QUOT1 - exit_action empty */
                               /* Transition from ADGParser_0_QUOT1 to ADGParser_0_EOD actions */
                               { aFE(DTF_EQ); }
                               /* End state ADGParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adgparser0Quot2:    /* ADGParser:QUOT2 */
                           {
                               /* State ADGParser_0_QUOT2 - exit_action empty */
                               /* Transition from ADGParser_0_QUOT2 to ADGParser_0_EOD actions */
                               { aFE(DTF_EQ); }
                               /* End state ADGParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adgparser0Sec1:    /* ADGParser:SEC1 */
                           {
                               /* State ADGParser_0_SEC1 - exit_action empty */
                               /* Transition from ADGParser_0_SEC1 to ADGParser_0_EOD actions */
                               { aF(); }
                               /* End state ADGParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_adgparser0Start:    /* ADGParser:START */
                           {
                               /* State ADGParser_0_START - exit_action empty */
                               /* Transition from ADGParser_0_START to ADGParser_0_EOD actions */
                               /* End state ADGParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_dEG1:    /* ADGParser:DEG1 */
                           {
                               /* State DEG1 - exit_action empty */
                               /* Transition from DEG1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mDEG1:    /* ADGParser:MDEG1 */
                           {
                               /* State MDEG1 - exit_action empty */
                               /* Transition from MDEG1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mDEG2:    /* ADGParser:MDEG2 */
                           {
                               /* State MDEG2 - exit_action empty */
                               /* Transition from MDEG2 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mIN1:    /* ADGParser:MIN1 */
                           {
                               /* State MIN1 - exit_action empty */
                               /* Transition from MIN1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mMIN1:    /* ADGParser:MMIN1 */
                           {
                               /* State MMIN1 - exit_action empty */
                               /* Transition from MMIN1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mMIN2:    /* ADGParser:MMIN2 */
                           {
                               /* State MMIN2 - exit_action empty */
                               /* Transition from MMIN2 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mSEC1:    /* ADGParser:MSEC1 */
                           {
                               /* State MSEC1 - exit_action empty */
                               /* Transition from MSEC1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mSEC2:    /* ADGParser:MSEC2 */
                           {
                               /* State MSEC2 - exit_action empty */
                               /* Transition from MSEC2 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mSEC3:    /* ADGParser:MSEC3 */
                           {
                               /* State MSEC3 - exit_action empty */
                               /* Transition from MSEC3 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mSEC4:    /* ADGParser:MSEC4 */
                           {
                               /* State MSEC4 - exit_action empty */
                               /* Transition from MSEC4 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_qUOT1:    /* ADGParser:QUOT1 */
                           {
                               /* State QUOT1 - exit_action empty */
                               /* Transition from QUOT1 to EOD actions */
                               { aFE(DTF_EQ); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_qUOT2:    /* ADGParser:QUOT2 */
                           {
                               /* State QUOT2 - exit_action empty */
                               /* Transition from QUOT2 to EOD actions */
                               { aFE(DTF_EQ); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_sEC1:    /* ADGParser:SEC1 */
                           {
                               /* State SEC1 - exit_action empty */
                               /* Transition from SEC1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_sTART:    /* ADGParser:START */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to EOD actions */
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
               };

           }

    protected:  
        virtual
        void
        appendToOut
                   ( WCHAR  ch          
                   , UINT   dtField     
                   , int    width       
                   ) = 0;

    protected:  
        void
        aI
          ( WCHAR  ch          
          )
           {
            appendToOut(ch, 0, 0);
           }

    protected:  
        void
        aF
          ( 
          )
           {
            appendToOut(0, _dtField, _width);
           }

    protected:  
        void
        aFI
           ( WCHAR  ch          
           )
           {
            aF(); aI(ch);
           }

    protected:  
        void
        aFE
           ( unsigned  f           
           )
           {
            appendToOut(0, f, 0);
           }

    public:     
        int
        getCurState
                   ( 
                   ) const
           {
            return this->curState;
           }

    public:     
        int
        isInFinalState
                      ( 
                      ) const
           {
            return (this->curState & ST_intStatefinalmask) ? 1 : 0;
           }

    protected:  
        virtual
        void
        customResetAutomata
                           ( 
                           )
           {
            return;
           }

    public:     
        void
        resetAutomata
                     ( 
                     )
           {
            this->clearStateStack(  );
            this->customResetAutomata(  );
            this->curState = ST_sTART;
           }

    public:     
        int
        isInInadmissibleFinalState
                                  ( 
                                  )
           {
            return this->curState==ST_intStateinadmissibleend ? 1 : 0;
           }

    protected:  
        int
        callState
                 ( int  newState     //!< new state code
                 )
           {
            try{
                this->stateStack.push(this->curState);
                this->curState = newState;
               }
            catch(...)
               {
                /* calling stackOverflow disabled by generator options */
               }
            return this->curState;
           }

    protected:  
        int
        spawnState
                  ( int  newState     //!< new state code
                  )
           {
                this->curState = newState;
                return this->curState;

           }

    protected:  
        int
        returnFromState
                       ( 
                       )
           {
            if (this->stateStack.empty())
               {
                /* calling stackUnderflow disabled by generator options */
               }
            else
               {
                this->curState = this->stateStack.top();
                this->stateStack.pop();
               }
            return this->curState;
           }

    protected:  
        void
        clearStateStack
                       ( 
                       )
           {
            while(!this->stateStack.empty()) this->stateStack.pop();
           }


};


}; // namespace impl {
}; // namespace format {
}; // namespace cli {

#endif /* FP_ADGPARSER_AUTOMATA_H */
