#define CLI_INTERNAL
#define CLI_INTERNAL_DONT_LINK_CLI_LIB

#include "io/factory.h"
#include "io/fileios.h"
#include "io/serialImpl.h"
#include "io/pipeImpl.h"
#include "io/sockImpl.h"
#include "io/rcImpl.h"
#include "variantImpl.h"
#include "datadom.h"
#include "varmapimpl.h"
#include "strsetimpl.h"
#include "objlist.h"
#include "cacheManImpl.h"
#include "strenc.h"
#include "coreservices.h"
#include "clircimpl.h"
#include "guidgen.h"


// NOTE: if not works under W2K, disable resolver by uncommenting preprocessor directives below
//#if defined(WIN32_WINNT) && WIN32_WINNT>=0x0501
    #include "inet/resolvImpl.h"
//#endif



#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif

#ifndef TLSIMPL_H
    #include "tlsimpl.h"
#endif


#if defined(WIN32) || defined(_WIN32)
    #ifdef WIN32_ON_DYN_MODULE_THREAD_DETACH
        #undef WIN32_ON_DYN_MODULE_THREAD_DETACH
    #endif
    #define WIN32_ON_DYN_MODULE_THREAD_DETACH() cliCallTlsDestructorFunction( )
#endif


#include "taggedStream.h"

/*
#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif
*/


struct CUnknownImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                    , public INTERFACE_CLI_IUNKNOWN
{


    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    CUnknownImpl() : base_impl(DEF_MODULE)
       {
       }
    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP(CUnknownImpl)
        //CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IDATANODELIST )
    CLI_END_INTERFACE_MAP(CUnknownImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }
}; // CUnknownImpl


DECLARE_COMPONENT_CREATION_PROC( create_cli_io_factory, ::cli::io::impl::CIOFactoryImpl, INTERFACE_CLI_IO_IIOFACTORY)
DECLARE_COMPONENT_CREATION_PROC( create_cli_file_ios_impl, ::cli::io::impl::CFileIosImpl, INTERFACE_CLI_IO_IIOSTREAM)
DECLARE_COMPONENT_CREATION_PROC( create_cli_rc_ios_impl,::cli::io::impl::CRcIosImpl, INTERFACE_CLI_IO_IIOSTREAM)
DECLARE_COMPONENT_CREATION_PROC( create_cli_serial_helper_impl, ::cli::io::impl::CSerialHelperImpl, INTERFACE_CLI_IO_ISERIALHELPER)
DECLARE_COMPONENT_CREATION_PROC( create_cli_serial_ios_impl, ::cli::io::impl::CSerialImpl, INTERFACE_CLI_IO_IIOSTREAM)
DECLARE_COMPONENT_CREATION_PROC( create_cli_anon_pipe_impl, ::cli::io::impl::CPipeImplBase, INTERFACE_CLI_IO_IIOSTREAM)
DECLARE_COMPONENT_CREATION_PROC( create_cli_tcp_impl, ::cli::io::impl::CTcpClientSocket , INTERFACE_CLI_IO_IIOSTREAM)
/*
// NOTE: if not works under W2K, disable resolver by uncommenting preprocessor directives below
//#if defined(WIN32_WINNT) && WIN32_WINNT>=0x0501
static 
RCODE create_cli_inet_resolver_impl_aux(CLI_IUNKNOWN_PTR *piu)
   {
    CLI_TRY{
            *piu = CAST_TO_INKNOWN_TROUTH( INTERFACE_CLI_INET_IRESOLVER , new ::cli::inet::impl::CResolverImpl() );
           }
    CLI_CATCH_RETURN_CLI_EXCEPTION()
    CLI_CATCH_RETURN_STD_EXCEPTIONS()
    return EC_OK;
   }


static
CLI_IUNKNOWN_PTR CLICALL create_cli_inet_resolver_impl(CLI_IUNKNOWN_PTR outer)
   {
    CLI_IUNKNOWN_PTR resultPtr = 0;
    RCODE res = create_cli_inet_resolver_impl_aux( &resultPtr );
    if (res) return 0;
    return resultPtr;
   }
//#endif
*/
DECLARE_COMPONENT_CREATION_PROC( create_cli_inet_resolver_impl, ::cli::inet::impl::CResolverImpl , INTERFACE_CLI_INET_IRESOLVER)

DECLARE_COMPONENT_CREATION_PROC( create_cli_inet_tcpserver_impl, ::cli::inet::impl::CTcpServerImpl  , INTERFACE_CLI_INET_ITCPSERVER)
DECLARE_COMPONENT_CREATION_PROC( create_cli_inet_udpserver_impl, ::cli::inet::impl::CUdpServerImpl  , INTERFACE_CLI_INET_IUDPSERVER)
DECLARE_COMPONENT_CREATION_PROC( create_cli_udp_impl           , ::cli::io::impl::CUdpClientSocket  , INTERFACE_CLI_IO_IIOSTREAM)

DECLARE_COMPONENT_CREATION_PROC( create_cli_variant            , ::cli::impl::CVariantFreeImpl      , INTERFACE_CLI_IVARIANT )

#ifdef CLI_BUILTIN_CLIPONENTS_DATADOM
DECLARE_COMPONENT_CREATION_PROC( create_cli_datanodelist       , ::cli::impl::CDataNodeListImpl     , INTERFACE_CLI_IDATANODELIST )
DECLARE_COMPONENT_CREATION_PROC( create_cli_datanode           , ::cli::impl::CDataNodeImpl         , INTERFACE_CLI_IDATANODE )
DECLARE_COMPONENT_CREATION_PROC( create_cli_dataxpathquery     , ::cli::impl::CDataXPathQueryImpl   , INTERFACE_CLI_IDATAXPATHQUERY )
DECLARE_COMPONENT_CREATION_PROC( create_cli_dataroot           , ::cli::impl::CDataRootImpl         , INTERFACE_CLI_IDATAROOT )
#endif

DECLARE_COMPONENT_CREATION_PROC( create_cli_encman             , ::cli::impl::CEncoderManagerImpl   , INTERFACE_CLI_ISTRINGENCODERMANAGER )

DECLARE_COMPONENT_CREATION_PROC( create_CStringSpecialEncoderHtmlTextImpl, ::cli::impl::CStringSpecialEncoderHtmlTextImpl, INTERFACE_CLI_ISTRINGSPECIALENCODER )
DECLARE_COMPONENT_CREATION_PROC( create_CStringSpecialEncoderHtmlAttrImpl, ::cli::impl::CStringSpecialEncoderHtmlAttrImpl, INTERFACE_CLI_ISTRINGSPECIALENCODER )
DECLARE_COMPONENT_CREATION_PROC( create_CStringSpecialEncoderXmlTextImpl , ::cli::impl::CStringSpecialEncoderXmlTextImpl , INTERFACE_CLI_ISTRINGSPECIALENCODER )
DECLARE_COMPONENT_CREATION_PROC( create_CStringSpecialEncoderXmlAttrImpl , ::cli::impl::CStringSpecialEncoderXmlAttrImpl , INTERFACE_CLI_ISTRINGSPECIALENCODER )



DECLARE_COMPONENT_CREATION_PROC( create_cli_unknown            , CUnknownImpl                       , INTERFACE_CLI_IUNKNOWN )

DECLARE_COMPONENT_CREATION_PROC( create_cli_varmapmap          , ::cli::impl::CVariantMapImplMap    , INTERFACE_CLI_IVARIANTMAP )
DECLARE_COMPONENT_CREATION_PROC( create_cli_objlist            , ::cli::impl::CObjListImpl          , INTERFACE_CLI_IOBJECTLIST )

DECLARE_COMPONENT_CREATION_PROC( create_cli_io_taggedstream    , ::cli::io::impl::CIOTaggedStreamImpl, INTERFACE_CLI_IO_IIOSTREAM )

DECLARE_COMPONENT_CREATION_PROC( create_cli_components_cache_man, ::cli::impl::CComponentCacheManagerImpl, INTERFACE_CLI_ICOMPONENTCACHEMANAGER )

DECLARE_COMPONENT_CREATION_PROC( create_CComponentManagerImpl  , ::cli::impl::CComponentManagerImpl, INTERFACE_CLI_ICOMPONENTMANAGER )
DECLARE_COMPONENT_CREATION_PROC( create_CResourceManagerImpl   , ::cli::impl::CResourceManagerImpl , INTERFACE_CLI_IRESOURCEMANAGER )

DECLARE_COMPONENT_CREATION_PROC( create_CStringSetImpl         , ::cli::impl::CStringSetImpl       , INTERFACE_CLI_ISTRINGSET )

DECLARE_COMPONENT_CREATION_PROC( create_cli_guidgen            , ::cli::impl::CGuidGenImpl         , INTERFACE_CLI_IGUID)


CLI_BEGIN_COMPONENT_TABLE()
      CLI_COMPONENT_TABLE_ENTRY1("/cli/core/component-manager"  , create_CComponentManagerImpl, INTERFACE_CLI_ICOMPONENTMANAGER_IID, "en:CLI CoreServices Component Manager;"),
      CLI_COMPONENT_TABLE_ENTRY1("/cli/core/resource-manager"   , create_CResourceManagerImpl , INTERFACE_CLI_IRESOURCEMANAGER_IID, "en:CLI CoreServices Resources Manager;"),
      CLI_COMPONENT_TABLE_ENTRY1("/cli/variant"                 , create_cli_variant, INTERFACE_CLI_IVARIANT_IID, "en:variant type object;"),
      CLI_COMPONENT_TABLE_ENTRY1("/cli/io-factory"              , create_cli_io_factory, INTERFACE_CLI_IO_IIOFACTORY_IID, "en:IO Factrory object;"),
      CLI_COMPONENT_TABLE_ENTRY1("/cli/io-stream-helpers/serial", create_cli_serial_helper_impl, INTERFACE_CLI_IO_ISERIALHELPER_IID, "en:IO - Serial communication port info helper;"),
      CLI_COMPONENT_TABLE_ENTRY4("/cli/io-stream/file"          , create_cli_file_ios_impl, INTERFACE_CLI_IO_IISTREAM_IID, INTERFACE_CLI_IO_IOSTREAM_IID, INTERFACE_CLI_IO_IIOSTREAM_IID, INTERFACE_CLI_IO_ISEEKABLE_IID, "en:IO - File stream;"),
      CLI_COMPONENT_TABLE_ENTRY4("/cli/io-stream/rc"            , create_cli_rc_ios_impl  , INTERFACE_CLI_IO_IISTREAM_IID, INTERFACE_CLI_IO_IOSTREAM_IID, INTERFACE_CLI_IO_IIOSTREAM_IID, INTERFACE_CLI_IO_ISEEKABLE_IID, "en:IO - Resource stream;"),
      CLI_COMPONENT_TABLE_ENTRY5("/cli/io-stream/serial"        , create_cli_serial_ios_impl, INTERFACE_CLI_IO_IISTREAM_IID, INTERFACE_CLI_IO_IOSTREAM_IID, INTERFACE_CLI_IO_IIOSTREAM_IID, INTERFACE_CLI_IO_ISERIAL_IID, INTERFACE_CLI_IO_ISERIALHELPER_IID, "en:IO - Serial (COM) stream;"),
      CLI_COMPONENT_TABLE_ENTRY4("/cli/io-stream/anon-pipe"     , create_cli_anon_pipe_impl, INTERFACE_CLI_IO_IISTREAM_IID, INTERFACE_CLI_IO_IOSTREAM_IID, INTERFACE_CLI_IO_IIOSTREAM_IID, IIDSEP INTERFACE_CLI_IO_IPIPE_IID, "en:IO - Anonimous pipe stream;"),
      CLI_COMPONENT_TABLE_ENTRY4("/cli/io-stream/tcp"           , create_cli_tcp_impl, INTERFACE_CLI_IO_IISTREAM_IID, INTERFACE_CLI_IO_IOSTREAM_IID, INTERFACE_CLI_IO_IIOSTREAM_IID, INTERFACE_CLI_INET_ISOCKET_IID, "en:IO - TCP socket stream;"),
      CLI_COMPONENT_TABLE_ENTRY4("/cli/io-stream/udp"           , create_cli_udp_impl, INTERFACE_CLI_IO_IISTREAM_IID, INTERFACE_CLI_IO_IOSTREAM_IID, INTERFACE_CLI_IO_IIOSTREAM_IID, INTERFACE_CLI_INET_ISOCKET_IID, "en:IO - UDP socket stream;"),
      CLI_COMPONENT_TABLE_ENTRY5("/cli/taggedstream"            , create_cli_io_taggedstream, INTERFACE_CLI_IO_IISTREAM_IID, INTERFACE_CLI_IO_IOSTREAM_IID, INTERFACE_CLI_IO_IIOSTREAM_IID, INTERFACE_CLI_ISTRINGTAG_IID, INTERFACE_CLI_IO_IIOSTREAMHOLDER_IID, "en:Generic IO stream holder with tag;"),
      /*
      */
      // NOTE: if not works under W2K, disable resolver by uncommenting preprocessor directives below
      //#if defined(WIN32_WINNT) && WIN32_WINNT>=0x0501
      CLI_COMPONENT_TABLE_ENTRY1("/cli/inet/std-resolver", create_cli_inet_resolver_impl, INTERFACE_CLI_INET_IRESOLVER_IID, "en:Inet - resolver/DNS client;"),
      //#endif

      CLI_COMPONENT_TABLE_ENTRY1("/cli/inet/tcp-server", create_cli_inet_tcpserver_impl, INTERFACE_CLI_INET_ITCPSERVER_IID, "en:Inet - TCP server;"),
      CLI_COMPONENT_TABLE_ENTRY1("/cli/inet/udp-server", create_cli_inet_udpserver_impl, INTERFACE_CLI_INET_IUDPSERVER_IID, "en:Inet - UDP server;"),

      #ifdef CLI_BUILTIN_CLIPONENTS_DATADOM
      CLI_COMPONENT_TABLE_ENTRY1("/cli/datanodelist"  , create_cli_datanodelist  , INTERFACE_CLI_IDATANODELIST_IID, "en:DataDom - DataDom/DataNodeList - a list of data nodes;"),
      CLI_COMPONENT_TABLE_ENTRY1("/cli/datanode"      , create_cli_datanode      , INTERFACE_CLI_IDATANODE_IID, "en:DataDom - DataDom node;"),
      CLI_COMPONENT_TABLE_ENTRY1("/cli/dataxpathquery", create_cli_dataxpathquery, INTERFACE_CLI_IDATAXPATHQUERY_IID, "en:DataDom - XPath Query;"),
      CLI_COMPONENT_TABLE_ENTRY2("/cli/dataroot"      , create_cli_dataroot      , INTERFACE_CLI_IDATAROOT_IID, INTERFACE_CLI_IDATANODE_IID, "en:DataDom - Data root;"),
      #endif // CLI_BUILTIN_CLIPONENTS_DATADOM

      CLI_COMPONENT_TABLE_ENTRY1("/cli/string-encman", create_cli_encman, INTERFACE_CLI_ISTRINGENCODERMANAGER_IID, "en:String Encoder Manager - creates string encoders;"),
      CLI_COMPONENT_TABLE_ENTRY2("/cli/string-special-encoder/html-text", create_CStringSpecialEncoderHtmlTextImpl, INTERFACE_CLI_ISTRINGSPECIALENCODER_IID, INTERFACE_CLI_ISTRINGENCODERCALLBACK_IID, "en:HTML Text encoder;"),
      CLI_COMPONENT_TABLE_ENTRY2("/cli/string-special-encoder/html-attr", create_CStringSpecialEncoderHtmlAttrImpl, INTERFACE_CLI_ISTRINGSPECIALENCODER_IID, INTERFACE_CLI_ISTRINGENCODERCALLBACK_IID, "en:HTML Attr encoder;"),
      CLI_COMPONENT_TABLE_ENTRY2("/cli/string-special-encoder/xml-text" , create_CStringSpecialEncoderXmlTextImpl , INTERFACE_CLI_ISTRINGSPECIALENCODER_IID, INTERFACE_CLI_ISTRINGENCODERCALLBACK_IID, "en:XML Text encoder;"),
      CLI_COMPONENT_TABLE_ENTRY2("/cli/string-special-encoder/xml-attr" , create_CStringSpecialEncoderXmlAttrImpl , INTERFACE_CLI_ISTRINGSPECIALENCODER_IID, INTERFACE_CLI_ISTRINGENCODERCALLBACK_IID, "en:XML Attr encoder;"),

      CLI_COMPONENT_TABLE_ENTRY1("/cli/guidgen"   , create_cli_guidgen, INTERFACE_CLI_IGUID_IID, "en:GuidGen;"),

      CLI_COMPONENT_TABLE_ENTRY1("/cli/varmap"    , create_cli_varmapmap, INTERFACE_CLI_IVARIANTMAP_IID, "en:Variant map - faster insert, slower search;"),
      CLI_COMPONENT_TABLE_ENTRY1("/cli/string-set", create_CStringSetImpl,INTERFACE_CLI_ISTRINGSET_IID , "en:String set;"),
      CLI_COMPONENT_TABLE_ENTRY1("/cli/objlist"   , create_cli_objlist  , INTERFACE_CLI_IOBJECTLIST_IID, "en:Object list;"),
      CLI_COMPONENT_TABLE_ENTRY1("/cli/objectlist", create_cli_objlist  , INTERFACE_CLI_IOBJECTLIST_IID, "en:Object list;"),
      CLI_COMPONENT_TABLE_ENTRY1("/cli/unknown"   , create_cli_unknown  , INTERFACE_CLI_IUNKNOWN_IID   , "en:Unknown - implments only cli::iUnknown;"),
      CLI_COMPONENT_TABLE_ENTRY1("/cli/component-cache-mgr", create_cli_components_cache_man , INTERFACE_CLI_ICOMPONENTCACHEMANAGER_IID, "en:Components Cache Manager;")



CLI_END_COMPONENT_TABLE(registerCliModule, "cli")

