#ifndef SRC_CORE_FLATSTRUTILS_H
#define SRC_CORE_FLATSTRUTILS_H

/* add this lines to your scr
#ifndef SRC_CORE_FLATSTRUTILS_H
    #include "flatStrUtils.h"
#endif
*/

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif


namespace cli
{
namespace impl
{
namespace flat_str_utils
{

template <typename CharType>
CharType toUpperCase( CharType ch )
   {
    if (ch>=(CharType)'a' && ch<=(CharType)'z') return ch - (CharType)'a' + (CharType)'A';
    return ch;
   }

template <typename CharType>
CharType toLowerCase( CharType ch )
   {
    if (ch>=(CharType)'A' && ch<=(CharType)'Z') return ch - (CharType)'A' + (CharType)'a';
    return ch;
   }

template <typename CharType, typename Traits, typename Allocator>
void toUpperCase( ::std::basic_string<CharType, Traits, Allocator> &str )
   {
    typename ::std::basic_string< CharType, Traits, Allocator>::iterator it = str.begin(), end = str.end();
    for( ; it != end; ++it )
       {
        *it = toUpperCase(*it);
       }
   }

template <typename CharType, typename Traits, typename Allocator>
void toLowerCase( ::std::basic_string<CharType, Traits, Allocator> &str )
   {
    typename ::std::basic_string< CharType, Traits, Allocator>::iterator it = str.begin(), end = str.end();
    for( ; it != end; ++it )
       {
        *it = toLowerCase(*it);
       }
   }

template <typename CharType, typename Traits, typename Allocator>
::std::basic_string<CharType, Traits, Allocator> toUpperCaseCopy( const ::std::basic_string<CharType, Traits, Allocator> &_str )
   {
    ::std::basic_string<CharType, Traits, Allocator> str = _str;
    toUpperCase(str); return str;
   }

template <typename CharType, typename Traits, typename Allocator>
::std::basic_string<CharType, Traits, Allocator> toLowerCaseCopy( const ::std::basic_string<CharType, Traits, Allocator> &_str )
   {
    ::std::basic_string<CharType, Traits, Allocator> str = _str;
    toLowerCase(str); return str;
   }

inline
std::string fromWidePlain( const std::wstring &str)
{
    std::string res; res.reserve(str.size());
    std::wstring::size_type i = 0, size = str.size();
    for(; i!=size; ++i)
       {
        res.append(1, (char)(unsigned char)(unsigned)str[i]);
       }
    return res;
}

inline
std::wstring toWidePlain( const std::string &str)
{
    std::wstring res; res.reserve(str.size());
    std::string::size_type i = 0, size = str.size();
    for(; i!=size; ++i)
       {
        res.append(1, (wchar_t)(unsigned char)str[i]);
       }
    return res;
}

}; // namespace flat_str_utils
}; // namespace impl
}; // namespace cli


#endif /* SRC_CORE_FLATSTRUTILS_H */

