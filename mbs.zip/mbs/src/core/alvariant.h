#ifndef CORE_ALVARIANT_H
#define CORE_ALVARIANT_H

// ArgList variant
/*
#ifndef CORE_ALVARIANT_H
    #include "alvariant.h"
#endif
*/

#ifndef CLI_IARGLIST_H
    #include <cli/iarglist.h>
#endif

#if !defined(_INC_STDLIB) && !defined(_STDLIB_H_) && !defined(_STDLIB_H)
    #include <stdlib.h>
#endif

#if !defined(_INC_WCHAR) && !defined(_WCHAR_H_) && !defined(_WCHAR_H)
    #include <wchar.h>
#endif

#ifndef CLI_DATETIME_H
    #include <cli/dateTime.h>
#endif

#ifndef CLI_DATETIMEFORMAT_H
    #include <cli/dateTimeFormat.h>
#endif

#ifndef CLI_NUMERIC_H
    #include <cli/numeric.h>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#ifndef SRC_CORE_CLRCONV_H
    #include "clrconv.h"
#endif

#ifndef CLI_FMTUTIL_H
    #include <cli/fmtutil.h>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif


namespace cli
{
//namespace arglist
//{
namespace impl
{


inline
UINT64 wcsToUInt( const WCHAR *pstr )
   {
    #if defined(_WIN32) && !defined(__GNUC__) // defined(_MSC_VER)
    // msvc, borland, intel or other msvc compatible
    return _wcstoui64( pstr, 0, 0 );
    #else
       #if defined __USE_GNU
       return wcstoll(pstr, 0, 0);
       #else
       return wcstol(pstr, 0, 0); // long ints strints truncated
       #endif   
    #endif
   }

inline
INT64 wcsToInt( const WCHAR *pstr )
   {
    #if defined(_WIN32) && !defined(__GNUC__) // defined(_MSC_VER)
    // msvc, borland, intel or other msvc compatible
    return _wcstoi64( pstr, 0, 0 );
    #else
       #if defined __USE_GNU
       return wcstoull(pstr, 0, 0);
       #else
       return wcstoul(pstr, 0, 0); // long ints strints truncated
       #endif   
    #endif
   }

inline
::std::wstring toStr(INT64 i)
   {
    WCHAR buf[128];
    #ifdef _WIN32
    _snwprintf(buf, sizeof(buf)/sizeof(buf[0]), L"%lld", i );
    #else
    swprintf  (buf, sizeof(buf)/sizeof(buf[0]), L"%lld", i );
    #endif
    return ::std::wstring(buf);
   }

inline
::std::wstring toStr(UINT64 i)
   {
    WCHAR buf[128];
    #ifdef _WIN32
    _snwprintf(buf, sizeof(buf)/sizeof(buf[0]), L"%llu", i );
    #else
    swprintf  (buf, sizeof(buf)/sizeof(buf[0]), L"%llu", i );
    #endif
    return ::std::wstring(buf);
   }

inline
::std::wstring toStr(void *p)
   {
    WCHAR buf[128];
    #ifdef _WIN32
    _snwprintf(buf, sizeof(buf)/sizeof(buf[0]), L"%p", p );
    #else
    swprintf  (buf, sizeof(buf)/sizeof(buf[0]), L"%p", p );
    #endif
    return ::std::wstring(buf);
   }

inline
::std::wstring toStr(double d)
   {
    WCHAR buf[128];
    #ifdef _WIN32
    _snwprintf(buf, sizeof(buf)/sizeof(buf[0]), L"%.10f", d );
    #else
    swprintf  (buf, sizeof(buf)/sizeof(buf[0]), L"%.10f", d );
    #endif
    ::std::wstring tmp = buf;
    //if (tmp.empty()) return tmp;
    ::std::wstring::size_type i = tmp.size();
    for(; i!=0; --i)
       {
        if (tmp[i-1]!='0') break;
       }
    return ::std::wstring(tmp, 0, i);
   }

inline
::std::wstring byteToStr(BYTE b)
   {
    WCHAR buf[128];
    #ifdef _WIN32
    _snwprintf(buf, sizeof(buf)/sizeof(buf[0]), L"%02X", b );
    #else
    swprintf  (buf, sizeof(buf)/sizeof(buf[0]), L"%02X", b );
    #endif
    return ::std::wstring(buf);
   }

inline
::std::wstring toStr(WCHAR ch)
   {
    return ::std::wstring(1, ch);
   }

inline
::std::wstring toStr(CHAR ch)
   {
    return ::std::wstring(1, WCHAR(ch));
   }

inline
::std::wstring toStr(CLIPSTR str)
   {
    if (!str) return ::std::wstring();
    return ::std::wstring( clipstr_data(str), clipstr_size(str) );
   }



//#include <stdlib.h>

// using namespace ::cli::arlist::VariantType;
/*
const DWORD vt_char          = CONSTANT_DWORD(0);
const DWORD vt_wchar         = CONSTANT_DWORD(1);
const DWORD vt_int           = CONSTANT_DWORD(2);
const DWORD vt_uint          = CONSTANT_DWORD(3);
const DWORD vt_int64         = CONSTANT_DWORD(4);
const DWORD vt_uint64        = CONSTANT_DWORD(5);
const DWORD vt_int_ptr       = CONSTANT_DWORD(6);
const DWORD vt_uint_ptr      = CONSTANT_DWORD(7);
const DWORD vt_float         = CONSTANT_DWORD(8);
const DWORD vt_double        = CONSTANT_DWORD(9);
const DWORD vt_pstring       = CONSTANT_DWORD(10);
const DWORD vt_ptr           = CONSTANT_DWORD(11);


STRUCT_CLI_ARLIST_VARIANT
                DWORD                       valType ;
                CHAR                        vChar   ;
                WCHAR                       vWChar  ;
                INT                         vInt    ;
                UINT                        vUInt   ;
                INT64                       vInt64  ;
                UINT64                      vUInt64 ;
                INT_PTR                     vIntPtr ;
                UINT_PTR                    vUIntPtr;
                FLOAT                       vFloat  ;
                DOUBLE                      vDouble ;
                CLIPSTR                     vStr    ;
                VOID                      * vPtr    ;
*/


//    using namespace ::cli::arlgist::VariantType;

    using ::cli::VariantType::vt_empty   ;
    using ::cli::VariantType::vt_none    ;
    using ::cli::VariantType::vt_char    ;
    using ::cli::VariantType::vt_wchar   ;
    using ::cli::VariantType::vt_short   ;
    using ::cli::VariantType::vt_ushort  ;
    using ::cli::VariantType::vt_int     ;
    using ::cli::VariantType::vt_uint    ;
    using ::cli::VariantType::vt_int64   ;
    using ::cli::VariantType::vt_uint64  ;
    using ::cli::VariantType::vt_int_ptr ;
    using ::cli::VariantType::vt_uint_ptr;
    using ::cli::VariantType::vt_float   ;
    using ::cli::VariantType::vt_double  ;
    using ::cli::VariantType::vt_pstring ;
    using ::cli::VariantType::vt_ptr     ;
    using ::cli::VariantType::vt_dump    ;
    using ::cli::VariantType::vt_datetime;
    using ::cli::VariantType::vt_bool;
    using ::cli::VariantType::vt_colorref;
    using ::cli::VariantType::vt_iUnknown;
    using ::cli::VariantType::vt_bigint  ;
    using ::cli::VariantType::vt_rational;
    
 


struct CVariant : public ::cli::Variant
{
    typedef INT64   most_wide_int_type;
    typedef UINT64  most_wide_uint_type;
    typedef double  most_wide_double_type;

/*
    template <typename T1, typename T2>
    void swap(T1 &t1, T2 &t2)
       {
        T1 tmp = t1;
        t1 = T1(t2);
        t2 = T2(tmp);
       }
*/
    template <typename T>
    void swap(T &t1, T &t2)
       {
        T tmp = t1;
        t1 = T(t2);
        t2 = T(tmp);
       }

    ::std::string typeName(CHAR dummy) const
        {
         switch(valType)
            {
             case vt_empty   :  return ::std::string("none");
             case vt_char    :  return ::std::string("char");
             case vt_wchar   :  return ::std::string("wchar");
             case vt_short   :  return ::std::string("short");
             case vt_ushort  :  return ::std::string("ushort");
             case vt_int     :  return ::std::string("int");
             case vt_uint    :  return ::std::string("uint");
             case vt_int64   :  return ::std::string("int64");
             case vt_uint64  :  return ::std::string("uint64");
             case vt_int_ptr :  return ::std::string("int_ptr");
             case vt_uint_ptr:  return ::std::string("uint_ptr");
             case vt_float   :  return ::std::string("float");
             case vt_double  :  return ::std::string("double");
             case vt_pstring :  return ::std::string("string");
             case vt_ptr     :  return ::std::string("void*");
             case vt_dump    :  return ::std::string("dump");
             case vt_datetime:  return ::std::string("::cli::CLISYSTEMTIME");
             case vt_bool    :  return ::std::string("bool");
             case vt_colorref:  return ::std::string("colorref");
             case vt_iUnknown:  return ::std::string("iUnknown");
             case vt_bigint  :  return ::std::string("bigint");
             case vt_rational:  return ::std::string("rational");
             default:           return ::std::string("<UNKNOWN>");
            }
        }

    ::std::wstring typeName(WCHAR dummy) const
        {
         switch(valType)
            {
             case vt_empty   :  return ::std::wstring(L"none");
             case vt_char    :  return ::std::wstring(L"char");
             case vt_wchar   :  return ::std::wstring(L"wchar");
             case vt_short   :  return ::std::wstring(L"short");
             case vt_ushort  :  return ::std::wstring(L"ushort");
             case vt_int     :  return ::std::wstring(L"int");
             case vt_uint    :  return ::std::wstring(L"uint");
             case vt_int64   :  return ::std::wstring(L"int64");
             case vt_uint64  :  return ::std::wstring(L"uin64");
             case vt_int_ptr :  return ::std::wstring(L"int_ptr");
             case vt_uint_ptr:  return ::std::wstring(L"uint_ptr");
             case vt_float   :  return ::std::wstring(L"float");
             case vt_double  :  return ::std::wstring(L"double");
             case vt_pstring :  return ::std::wstring(L"string");
             case vt_ptr     :  return ::std::wstring(L"void*");
             case vt_dump    :  return ::std::wstring(L"dump");
             case vt_datetime:  return ::std::wstring(L"::cli::CLISYSTEMTIME");
             case vt_bool    :  return ::std::wstring(L"bool");
             case vt_colorref:  return ::std::wstring(L"colorref");
             case vt_iUnknown:  return ::std::wstring(L"iUnknown");
             case vt_bigint  :  return ::std::wstring(L"::cli::BigInteger");
             case vt_rational:  return ::std::wstring(L"::cli::RationalNumber");
             default:           return ::std::wstring(L"<UNKNOWN>");
            }
        }


    void swap(CVariant &v)
       {
         swap( valType , v.valType );
         swap( value   , v.value   );
       }

    CVariant() { valType = vt_none; }

    static CVariant makeBool( BOOL b) { CVariant res; res.valType = vt_bool; res.value.vBool = b; return res; }
    //CVariant(BOOL     b) { valType = vt_bool    ; value.vBool    = v; }

    CVariant(CHAR     v) { valType = vt_char    ; value.vChar    = v; }
    CVariant(WCHAR    v) { valType = vt_wchar   ; value.vWChar   = v; }

    CVariant(INT      v) { valType = vt_int     ; value.vInt     = v; }
    CVariant(UINT     v) { valType = vt_uint    ; value.vUInt    = v; }

    CVariant(SHORT    v) { valType = vt_short   ; value.vShort   = v; }
    CVariant(USHORT   v) { valType = vt_ushort  ; value.vUShort  = v; }

    CVariant(INT64    v) { valType = vt_int64   ; value.vInt64   = v; }
    CVariant(UINT64   v) { valType = vt_uint64  ; value.vUInt64  = v; }

    CVariant(INT_PTR  v, bool bPtr) { valType = vt_int_ptr ; value.vIntPtr  = v; }
    CVariant(UINT_PTR v, bool bPtr) { valType = vt_uint_ptr; value.vUIntPtr = v; }

    CVariant(FLOAT    v) { valType = vt_float   ; value.vFloat   = v; }
    CVariant(DOUBLE   v) { valType = vt_double  ; value.vDouble  = v; }
    CVariant(CLIPSTR  v) { valType = vt_pstring ; value.vStr     = v; } // get owns of str
    CVariant(VOID*    v) { valType = vt_ptr     ; value.vPtr     = v; }
    CVariant(INTERFACE_CLI_IUNKNOWN* v) 
       { 
        valType = vt_iUnknown;
        value.vUnknown     = v;
        if (value.vUnknown) value.vUnknown->addRef();
       }

    CVariant(COLORREF clr, ENUM_CLI_VARIANTTYPE vtType /* set to vt_colorref */)
       {
        valType = vtType  ; value.vUInt = clr;
       }

    CVariant(const ::cli::BigInteger &bigint) { valType = vt_bigint; value.vBigint  = bigint; }
    CVariant(const ::cli::numeric::extended_int128_t &int128)
        {
         valType = vt_bigint; 
         ::cli::numeric::toCliBigInteger(int128, value.vBigint);
        }

    CVariant(const ::cli::RationalNumber &rational) { valType = vt_rational; value.vRational  = rational; }
    CVariant(const ::cli::numeric::rational_number_t &rational) 
        { 
         valType = vt_rational; 
         ::cli::numeric::toCliRational(rational, value.vRational);
        }

    CVariant(CLIPCSTR v) 
       { 
        valType = vt_dump    ; 
        value.vDump    = v;
       }
    CVariant(const STRUCT_CLI_CLISYSTEMTIME &datetime ) { valType = vt_datetime; value.vDatetime = datetime; }

    CVariant(const ::std::wstring &v) 
       {
        valType = vt_pstring;
        value.vStr = 0; 
        clipstr_alloc( &value.vStr, v.data(), v.size() );
       }

    CVariant(const CVariant &v)
        {
         valType  = v.valType ;

         switch(valType)
            {
             case vt_empty   :                                       break;
             case vt_bool    :  value.vBool     = v.value.vBool    ; break;
             case vt_char    :  value.vChar     = v.value.vChar    ; break;
             case vt_wchar   :  value.vWChar    = v.value.vWChar   ; break;
             case vt_short   :  value.vShort    = v.value.vShort   ; break;
             case vt_ushort  :  value.vUShort   = v.value.vUShort  ; break;
             case vt_int     :  value.vInt      = v.value.vInt     ; break;
             case vt_colorref:
             case vt_uint    :  value.vUInt     = v.value.vUInt    ; break;
             case vt_int64   :  value.vInt64    = v.value.vInt64   ; break;
             case vt_uint64  :  value.vUInt64   = v.value.vUInt64  ; break;
             case vt_int_ptr :  value.vIntPtr   = v.value.vIntPtr  ; break;
             case vt_uint_ptr:  value.vUIntPtr  = v.value.vUIntPtr ; break;
             case vt_float   :  value.vFloat    = v.value.vFloat   ; break;
             case vt_double  :  value.vDouble   = v.value.vDouble  ; break;
             case vt_pstring :  //value.vStr      = v.value.vStr     ; break;
                                { // make copy
                                 clipstr_alloc( &value.vStr , clipstr_data(v.value.vStr) , clipstr_size(v.value.vStr) ); 
                                }
                                break;
             case vt_dump    :  //value.vDump     = v.value.vDump    ; break;
                                { // make copy
                                 clipstr_alloc( &value.vDump, clipstr_data(v.value.vDump), clipstr_size(v.value.vDump) );
                                } 
                                break;
             case vt_ptr     :  value.vPtr      = v.value.vPtr     ; break;
             case vt_datetime:  value.vDatetime = v.value.vDatetime; break;
             case vt_iUnknown:  value.vUnknown  = v.value.vUnknown ; 
                                if (value.vUnknown) value.vUnknown->addRef();
                                break;
             case vt_bigint:    value.vBigint   = v.value.vBigint; break;
             case vt_rational:  value.vRational = v.value.vRational; break;
             //default:           
            }
        }


    CVariant(const ::cli::Variant &v)
        {
         valType  = v.valType ;

         switch(valType)
            {
             case vt_empty   :                                       break;
             case vt_bool    :  value.vBool     = v.value.vBool    ; break;
             case vt_char    :  value.vChar     = v.value.vChar    ; break;
             case vt_wchar   :  value.vWChar    = v.value.vWChar   ; break;
             case vt_short   :  value.vShort    = v.value.vShort   ; break;
             case vt_ushort  :  value.vUShort   = v.value.vUShort  ; break;
             case vt_int     :  value.vInt      = v.value.vInt     ; break;
             case vt_colorref:
             case vt_uint    :  value.vUInt     = v.value.vUInt    ; break;
             case vt_int64   :  value.vInt64    = v.value.vInt64   ; break;
             case vt_uint64  :  value.vUInt64   = v.value.vUInt64  ; break;
             case vt_int_ptr :  value.vIntPtr   = v.value.vIntPtr  ; break;
             case vt_uint_ptr:  value.vUIntPtr  = v.value.vUIntPtr ; break;
             case vt_float   :  value.vFloat    = v.value.vFloat   ; break;
             case vt_double  :  value.vDouble   = v.value.vDouble  ; break;
             case vt_pstring :  //value.vStr      = v.value.vStr     ; break;
                                { // make copy
                                 clipstr_alloc( &value.vStr , clipstr_data(v.value.vStr) , clipstr_size(v.value.vStr) ); 
                                }
                                break;
             case vt_dump    :  //value.vDump     = v.value.vDump    ; break;
                                { // make copy
                                 clipstr_alloc( &value.vDump, clipstr_data(v.value.vDump), clipstr_size(v.value.vDump) );
                                } 
                                break;
             case vt_ptr     :  value.vPtr      = v.value.vPtr     ; break;
             case vt_datetime:  value.vDatetime = v.value.vDatetime; break;
             case vt_iUnknown:  value.vUnknown  = v.value.vUnknown ; 
                                if (value.vUnknown) value.vUnknown->addRef();
                                break;
             case vt_bigint:    value.vBigint   = v.value.vBigint; break;
             case vt_rational:  value.vRational = v.value.vRational; break;
             //default:           
            }
        }

    ~CVariant()
        { 
         if (valType == vt_pstring) { clipstr_free(&value.vStr); }
         if (valType == vt_dump)    { clipstr_free(&value.vDump); }
         if (valType == vt_iUnknown) 
            { 
             if (value.vUnknown) value.vUnknown->release();
            }
        }

    CVariant& operator=(const CVariant &v)
        {
         if (&v==this) return *this;
         CVariant tmp(v);
         swap(tmp);
         return *this;
        }

    most_wide_int_type toWideInt() const
        {
         switch(valType)
            {
             case vt_empty   :  return  most_wide_int_type(0);
             case vt_bool    :  if (value.vBool==0) return most_wide_int_type(0);
                                else if (value.vBool>0) return most_wide_int_type(1);
                                else return most_wide_int_type(-1);
             case vt_char    :  return  most_wide_int_type(value.vChar);
             case vt_wchar   :  return  most_wide_int_type(value.vWChar);
             case vt_short   :  return  most_wide_int_type(value.vShort);
             case vt_ushort  :  return  most_wide_int_type(value.vUShort);
             case vt_int     :  return  most_wide_int_type(value.vInt);
             case vt_colorref:
             case vt_uint    :  return  most_wide_int_type(value.vUInt);
             case vt_int64   :  return  most_wide_int_type(value.vInt64);
             case vt_uint64  :  return  most_wide_int_type(value.vUInt64);
             case vt_int_ptr :  return  most_wide_int_type(value.vIntPtr);
             case vt_uint_ptr:  return  most_wide_int_type(value.vUIntPtr);
             case vt_float   :  return  most_wide_int_type(value.vFloat);
             case vt_double  :  return  most_wide_int_type(value.vDouble);
             case vt_pstring :  if (!value.vStr) return 0;
                                {
                                 COLORREF clr = convertColorrefFromString( clipstr_c_str(value.vStr) );
                                 if (clr!=(COLORREF)-1)
                                    return most_wide_int_type(clr);
                                }
                                return wcsToInt(clipstr_c_str(value.vStr));

             case vt_dump    :  if (!value.vDump) return 0;
                                if (!clipstr_size(value.vDump)) return 0;
                                return *clipstr_data(value.vDump);

             case vt_ptr     :  return  most_wide_int_type((most_wide_uint_type)value.vPtr);
             case vt_datetime:  
                                try{
                                    ::cli::CDateTime dt(value.vDatetime);
                                    return most_wide_int_type((CLI_TIME_T)dt);
                                   }
                                catch(...)
                                   {
                                    return most_wide_int_type(0);
                                   }

             case vt_iUnknown:  if (value.vUnknown)
                                   {
                                    CiVariantConvert vconv;
                                    value.vUnknown->queryInterface( INTERFACE_CLI_IVARIANTCONVERT_IID, (VOID**)vconv.getPP() );
                                    if (!!vconv)
                                       {
                                        ::std::wstring str;
                                        if (!vconv.objectValueToString( str ))
                                           {
                                            return wcsToInt(str.c_str());
                                           }
                                       }
                                   }
                                return most_wide_int_type(value.vUnknown);

             case vt_bigint:    {
                                 ::cli::numeric::extended_int128_t int128;
                                 fromCliBigInteger( value.vBigint, int128 );
                                 return most_wide_int_type(int128.to_int_type());
                                }

             case vt_rational:  {
                                 ::cli::numeric::rational_number_t r;
                                 fromCliRational( value.vRational, r );
                                 ::cli::numeric::extended_int128_t int128 = r.to_int_type();
                                 return most_wide_int_type(int128.to_int_type());
                                }

             default:           return 0;
            }
        }

    most_wide_uint_type toWideUInt() const
        {
         switch(valType)
            {
             case vt_empty   :  return  most_wide_uint_type((unsigned char)0);
             case vt_bool    :  if (value.vBool==0) return most_wide_uint_type(0);
                                else if (value.vBool>0) return most_wide_uint_type(1);
                                else return most_wide_uint_type(-1);
             case vt_char    :  return  most_wide_uint_type((unsigned char)value.vChar);
             case vt_wchar   :  return  most_wide_uint_type(value.vWChar);
             case vt_short   :  return  most_wide_uint_type((unsigned short int)value.vShort);
             case vt_ushort  :  return  most_wide_uint_type((unsigned short int)value.vUShort);
             case vt_int     :  return  most_wide_uint_type((unsigned int)value.vInt);
             case vt_colorref:
             case vt_uint    :  return  most_wide_uint_type(value.vUInt);
             case vt_int64   :  return  most_wide_uint_type(value.vInt64);
             case vt_uint64  :  return  most_wide_uint_type(value.vUInt64);
             case vt_int_ptr :  return  most_wide_uint_type(value.vIntPtr);
             case vt_uint_ptr:  return  most_wide_uint_type(value.vUIntPtr);
             case vt_float   :  return  most_wide_uint_type((most_wide_int_type)value.vFloat);
             case vt_double  :  return  most_wide_uint_type((most_wide_int_type)value.vDouble);
             case vt_pstring :  if (!value.vStr) return 0;
                                {
                                 COLORREF clr = convertColorrefFromString( clipstr_c_str(value.vStr) );
                                 if (clr!=(COLORREF)-1)
                                    return most_wide_uint_type(clr);
                                }
                                return wcsToUInt(clipstr_c_str(value.vStr));
             case vt_dump    :  if (!value.vDump) return 0;
                                if (!clipstr_size(value.vDump)) return 0;
                                return *((unsigned char*)clipstr_data(value.vDump));
             case vt_ptr     :  return  most_wide_uint_type(value.vPtr);
             case vt_datetime:  
                                try{
                                    ::cli::CDateTime dt(value.vDatetime);
                                    return most_wide_uint_type((CLI_TIME_T)dt);
                                   }
                                catch(...)
                                   {
                                    return most_wide_uint_type(0);
                                   }
             case vt_iUnknown:  if (value.vUnknown)
                                   {
                                    CiVariantConvert vconv;
                                    value.vUnknown->queryInterface( INTERFACE_CLI_IVARIANTCONVERT_IID, (VOID**)vconv.getPP() );
                                    if (!!vconv)
                                       {
                                        ::std::wstring str;
                                        if (!vconv.objectValueToString( str ))
                                           {
                                            return wcsToUInt(str.c_str());
                                           }
                                       }
                                   }
                                return most_wide_uint_type(value.vUnknown);

             case vt_bigint:    {
                                 ::cli::numeric::extended_int128_t int128;
                                 fromCliBigInteger( value.vBigint, int128 );
                                 return most_wide_uint_type(int128.to_unsigned_type());
                                }

             case vt_rational:  {
                                 ::cli::numeric::rational_number_t r;
                                 fromCliRational( value.vRational, r );
                                 ::cli::numeric::extended_int128_t int128 = r.to_int_type();
                                 return most_wide_uint_type(int128.to_unsigned_type());
                                }

             default:           return 0;
            }
        }

    most_wide_double_type toDouble() const
        {
         switch(valType)
            {
             case vt_empty   :  return  most_wide_double_type(0.0);
             case vt_bool    :
             case vt_char    :  case vt_wchar   :  
             case vt_short   :  case vt_int     :  case vt_int64   :  case vt_int_ptr :  
                                return  most_wide_double_type(toWideInt());
             case vt_ushort  :  case vt_uint    :  case vt_uint64  :  case vt_uint_ptr:  case vt_colorref:
                                return  most_wide_double_type(toWideUInt());

             case vt_float   :  return  value.vFloat;
             case vt_double  :  return  value.vDouble;
             case vt_pstring :  if (!value.vStr) return 0.0;
                                {
                                 COLORREF clr = convertColorrefFromString( clipstr_c_str(value.vStr) );
                                 if (clr!=(COLORREF)-1)
                                    return most_wide_double_type(clr);
                                }
                                return wcstod(clipstr_c_str(value.vStr), 0);
             case vt_dump    :  return most_wide_double_type(toWideUInt());
             case vt_ptr     :  return  most_wide_double_type(toWideUInt());
             case vt_datetime:  
                                try{
                                    ::cli::CDateTime dt(value.vDatetime);
                                    return most_wide_double_type((CLI_TIME_T)dt);
                                   }
                                catch(...)
                                   {
                                    return most_wide_double_type(0);
                                   }

             case vt_iUnknown:  if (value.vUnknown)
                                   {
                                    CiVariantConvert vconv;
                                    value.vUnknown->queryInterface( INTERFACE_CLI_IVARIANTCONVERT_IID, (VOID**)vconv.getPP() );
                                    if (!!vconv)
                                       {
                                        ::std::wstring str;
                                        if (!vconv.objectValueToString( str ))
                                           {
                                            return wcstod(str.c_str(), 0);
                                           }
                                       }
                                   }
                                return most_wide_double_type(toWideInt());

             case vt_bigint:    {
                                 ::cli::numeric::extended_int128_t int128;
                                 fromCliBigInteger( value.vBigint, int128 );
                                 return most_wide_double_type(int128.to_int_type());
                                }

             case vt_rational:  {
                                 ::cli::numeric::rational_number_t r;
                                 fromCliRational( value.vRational, r );
                                 return r.to_double();
                                }
 
             default:           return 0.0;
            }
        }
/*
::std::wstring toStr(CHAR ch)
::std::wstring toStr(WCHAR ch)
::std::wstring toStr(double d)
::std::wstring toStr(UINT64 i)
::std::wstring toStr(INT64 i)
::std::wstring toStr(void *p)
::std::wstring toStr(CLIPSTR str)
*/
    ::std::wstring toString(bool forDisplay = true) const
        {
         switch(valType)
            {
             case vt_empty   :  return ::std::wstring();
                                // UNDONE: is invalid bool value need to be converted not as true?
             case vt_bool    :  if (forDisplay) return ::std::wstring( value.vBool ? L"true" : L"false");
                                else            return ::std::wstring( value.vBool ? L"1" : L"0");

             case vt_char    :  return toStr(value.vChar);
             case vt_wchar   :  return toStr(value.vWChar);

             case vt_short   :  case vt_int     :  case vt_int64   :  case vt_int_ptr :  
                                return toStr(toWideInt());

             case vt_ushort  :  case vt_uint    :  case vt_uint64  :  case vt_uint_ptr:  
                                return toStr(toWideUInt());
             case vt_colorref:
                                return convertColorrefToName( value.vUInt, false, true ); // name: lower, numeric: upper

             case vt_float   :  case vt_double  :  
                                return  toStr(toDouble());

             case vt_pstring :  return toStr(value.vStr);
             case vt_ptr     :  return toStr(value.vPtr);
             case vt_dump    :  
                                {
                                 ::std::wstring str;
                                 SIZE_T size = clipstr_size(value.vDump);
                                 const BYTE* pb = (const BYTE*)clipstr_data(value.vDump);
                                 for(SIZE_T i=0; i<size; ++i)
                                    {
                                     if (i) str.append(1, L' ');
                                     str.append(byteToStr(pb[i]));
                                    }
                                 return str;
                                }
             case vt_datetime:  
                                {
                                 if (forDisplay || !value.vDatetime.microsec) return ::cli::format::formatDateTime(L"dd/MM/yyyy, HH:mm:ss", value.vDatetime );
                                 else            return ::cli::format::formatDateTime(L"dd/MM/yyyy, HH:mm:ss.zzzzzz", value.vDatetime );
                                }
                                
             case vt_iUnknown:  if (value.vUnknown)
                                   {
                                    CiVariantConvert vconv;
                                    value.vUnknown->queryInterface( INTERFACE_CLI_IVARIANTCONVERT_IID, (VOID**)vconv.getPP() );
                                    if (!!vconv)
                                       {
                                        ::std::wstring str;
                                        if (!vconv.objectValueToString( str ))
                                           {
                                            return str;
                                           }
                                       }
                                   }
                                return ::std::wstring();

             case vt_bigint:    {
                                 ::cli::numeric::extended_int128_t int128;
                                 fromCliBigInteger( value.vBigint, int128 );
                                 std::wstring str;
                                 return ::cli::numeric::format_extended_size_int_dec( str, int128 );
                                }

             case vt_rational:  {
                                 ::cli::numeric::rational_number_t r;
                                 fromCliRational( value.vRational, r );
                                 std::wstring str;
                                 return ::cli::numeric::format_rational_number( str, r );
                                }

             default:           return ::std::wstring();
            }        
        }

    // 24/12/2010, 18:16:12
    bool tryConvertToDateTimeHelper( const ::std::wstring &str, STRUCT_CLI_CLISYSTEMTIME &dt, wchar_t chSep ) const
       {
        //if ( ::std::count( str.begin(), str.end(), chSep )!=2 ) return false;
        ::std::vector< INT > ints;
        ::cli::fmtutil::convertStringToInts( str, ints );
        if (chSep==L':') // time
           {
            if (ints.size()<3) return false;
            dt.hour   = ints[0];
            dt.minute = ints[1];
            dt.second = ints[2];
            if (ints.size()>3)
              dt.microsec = ints[3];
           }
        else
           {
            if (ints.size()!=3) return false;
            dt.year   = ints[2];
            dt.month  = ints[1];
            dt.day    = ints[0];
            //if (dt.year<50) dt.year += 2000;
           }
        return true;
       }

    bool tryConvertToDateTime( const ::std::wstring &str, STRUCT_CLI_CLISYSTEMTIME &_dt ) const
       {
        ::std::wstring::size_type sepLen = 0;
        ::std::wstring::size_type pos = str.find(L", ");
        if (pos!=str.npos)
           {
            sepLen = 2;
           }
        else
           {
            sepLen = 1;
            pos = str.find(L",");
            if (pos==str.npos)
               {
                pos = str.find(L" ");
               }
           }

        ::std::wstring strFirst, strSecond;
        if (pos==str.npos)
           {
            strFirst = str;
           }
        else
           {
            strFirst  = ::std::wstring( str, 0, pos);
            strSecond = ::std::wstring( str, pos+sepLen, str.npos );
           }

        STRUCT_CLI_CLISYSTEMTIME dt;
        dt.year      = 0;
        dt.month     = 0;
        dt.dayOfWeek = 0;
        dt.day       = 0;
        dt.hour      = 0;
        dt.minute    = 0;
        dt.second    = 0;
        dt.microsec  = 0;
        dt.gmOffset  = 0;

        if ( ::std::count( strFirst.begin(), strFirst.end(), L'/' )!=2 )
           { // strFirst is not a date
            if ( ::std::count( strFirst.begin(), strFirst.end(), L':' )!=2 )
               return false; // strFirst is not a time also
            if (!tryConvertToDateTimeHelper( strFirst, dt, L':' )) return false; // time convert failed
            if (!strSecond.empty())
               { // try to convert date part
                if (::std::count( strSecond.begin(), strSecond.end(), L'/' )!=2) return false;
                if (!tryConvertToDateTimeHelper( strSecond, dt, L'/' )) return false; // date convert failed
               }
           }

        if (!tryConvertToDateTimeHelper( strFirst, dt, L'/' )) return false; // date convert failed
        if (!strSecond.empty())
           { // try to convert time part
            if (::std::count( strSecond.begin(), strSecond.end(), L':' )!=2) return false;
            if (!tryConvertToDateTimeHelper( strSecond, dt, L':' )) return false; // date convert failed
           }
        _dt = dt;
        return true;
       }

// 24/12/2010, 18:16:12

    STRUCT_CLI_CLISYSTEMTIME toDatetime() const
       {
        if (valType==vt_datetime)
           {
            return value.vDatetime; // return untouched
           }
        else if (valType==vt_pstring)
           {
            STRUCT_CLI_CLISYSTEMTIME dt;
            if (tryConvertToDateTime( toStr(value.vStr), dt )) return dt;
            else
               {
                ::cli::CDateTime dt( (CLI_TIME_T)toWideInt() );
                return dt;           
               }
           }
        else if (valType==vt_iUnknown)
           {
            STRUCT_CLI_CLISYSTEMTIME dt;
            if (tryConvertToDateTime( toString(), dt )) return dt;
            else
               {
                ::cli::CDateTime dt( (CLI_TIME_T)toWideInt() );
                return dt;           
               }
           }

        ::cli::CDateTime dt( (CLI_TIME_T)toWideInt() );
        return dt;
       }

    static 
    ::std::wstring upperCopy(const ::std::wstring& str)
        {
         return MARTY_FILENAME::utils::upperCaseCopy( str );
        }


    CVariant convertCopy(DWORD newType, bool forDisplay = true) const
        {
         switch(newType)
            {
             case vt_empty   :  return CVariant();
             case vt_bool    :  {
                                 if (valType==vt_empty)
                                    return makeBool(BOOL(-1));

                                 if (valType==vt_bool)
                                    return makeBool(BOOL(value.vBool));
                                    
                                 if (valType==vt_pstring)
                                    {
                                     ::std::wstring str = upperCopy(toString(true));
                                     if (str==L"1" || str==L"T" || str==L"Y" || str==L"TRUE" || str==L"YES" || str==L"ON")
                                        return makeBool(BOOL(1));
                                     else if (str==L"0" || str==L"F" || str==L"N" || str==L"FALSE" || str==L"NO" || str==L"OFF")
                                        return makeBool(BOOL(0));
                                     else
                                        return makeBool(BOOL(-1));
                                    }
                                 else
                                    {
                                     most_wide_int_type i = toWideInt();
                                     if (i>0) return makeBool(BOOL(1));
                                     else if (i<0) return makeBool(BOOL(-1));
                                     return makeBool(BOOL(0));
                                    }
                                }

             case vt_char    :  return CVariant(CHAR(toWideInt()));
             case vt_wchar   :  return CVariant(WCHAR(toWideInt()));
             case vt_short   :  return CVariant(SHORT(toWideInt()));
             case vt_ushort  :  return CVariant(USHORT(toWideUInt()));
             case vt_int     :  return CVariant(INT(toWideInt()));
             case vt_colorref:  if (valType==vt_pstring)
                                   {
                                    COLORREF clr = convertColorrefFromString( clipstr_c_str(value.vStr) );
                                    if (clr!=(COLORREF)-1)
                                       return CVariant(clr, vt_colorref);
                                   }
                                return CVariant((COLORREF)(toWideUInt()), vt_colorref);

             case vt_uint    :  return CVariant(UINT(toWideUInt()));
             case vt_int64   :  return CVariant(INT64(toWideInt()));
             case vt_uint64  :  return CVariant(UINT64(toWideUInt()));
             case vt_int_ptr :  return CVariant(INT_PTR(toWideInt()), true);
             case vt_uint_ptr:  return CVariant(UINT_PTR(toWideUInt()), true);
             case vt_float   :  return CVariant(FLOAT(toDouble()));
             case vt_double  :  return CVariant(DOUBLE(toDouble()));
             case vt_pstring :  
                                //if (valType==vt_colorref)
                                //   return CVariant(toString());
                                return CVariant(toString(forDisplay));
             case vt_ptr     :  
                                return CVariant((void*)(toWideUInt()));

             case vt_dump    :  return CVariant(UINT(toWideUInt()));
             case vt_datetime:  return CVariant( toDatetime() );
             case vt_iUnknown:
                                if (valType==vt_iUnknown)
                                   { // no conversion
                                    return CVariant( value.vUnknown );
                                   }
                                return CVariant(UINT(0));

             case vt_bigint:    { // try to convert from string
                                 if (valType==vt_pstring)
                                    {
                                     std::wstring str = toString(false /* forDisplay */ );
                                     ::cli::numeric::extended_int128_t int128(0);
                                     ::cli::numeric::extended_size_int_from_string_auto(str.c_str(), int128);
                                     return CVariant(int128);
                                    }
                                 if (valType==vt_bigint)
                                    return CVariant(value.vBigint);
                                 if (valType==vt_rational)
                                    {
                                     ::cli::numeric::rational_number_t r;
                                     ::cli::numeric::fromCliRational( value.vRational, r );
                                     return CVariant(r.to_int_type());
                                    }
                                 return CVariant( ::cli::numeric::extended_int128_t(toWideInt()) );
                                }

             case vt_rational:  {
                                 if (valType==vt_float || valType==vt_double)
                                    {
                                     double d = toDouble();
                                     int sign = (d<0.0) ? -1 : 1;
                                     if (sign<0) d = -d;
                                     double dScale = 1000.0;
                                     UINT64 iScale = 1000;
                                     if (     d>   1000000000.0)
                                        {
                                         dScale =        1000.0;
                                         iScale =        1000;
                                        }
                                     else if (d>      1000000.0)
                                        {
                                         dScale =     1000000.0;
                                         iScale =     1000000;
                                        }
                                     else if (d>         1000.0)
                                        {
                                         dScale =  1000000000.0;
                                         iScale =  1000000000;
                                        }
                                     else
                                        {
                                         dScale =  1000000000.0; //000.0;
                                         iScale =  1000000000; //000;
                                        }

                                     //::cli::numeric::rational_number_t nom((UINT64)(d*dScale));
                                     ::cli::numeric::extended_int128_t nom((UINT64)(d*dScale));
                                     while((nom%(INT64)10).to_int_type()==0 && iScale>1)
                                        {
                                         nom    /= 10;
                                         iScale /= 10;
                                        }
                                     return CVariant( ::cli::numeric::rational_number_t(nom, ::cli::numeric::extended_int128_t(iScale)) );
                                    }
                                 if (valType==vt_pstring)
                                    {
                                     std::wstring str = toString(false /* forDisplay */ );
                                     ::cli::numeric::rational_number_t r(0);
                                     ::cli::numeric::rational_number_from_string(str.c_str(), r);
                                     return CVariant(r);
                                    }
                                 if (valType==vt_rational)
                                    return CVariant(value.vRational);
                                 if (valType==vt_bigint)
                                    {
                                     ::cli::numeric::extended_int128_t int128;
                                     ::cli::numeric::fromCliBigInteger( value.vBigint, int128 );
                                     return CVariant( ::cli::numeric::rational_number_t(int128) );
                                    }
                                 return CVariant( ::cli::numeric::rational_number_t(toWideInt()) );
                                }

             default:           return CVariant(INT(0));
            }
        }

/*
    CVariant(CHAR     v) { valType = vt_char    ; vChar    = v; }
    CVariant(WCHAR    v) { valType = vt_wchar   ; vWChar   = v; }
    CVariant(INT      v) { valType = vt_int     ; vInt     = v; }
    CVariant(UINT     v) { valType = vt_uint    ; vUInt    = v; }
    CVariant(INT64    v) { valType = vt_int64   ; vInt64   = v; }
    CVariant(UINT64   v) { valType = vt_uint64  ; vUInt64  = v; }
    CVariant(INT_PTR  v) { valType = vt_int_ptr ; vIntPtr  = v; }
    CVariant(UINT_PTR v) { valType = vt_uint_ptr; vUIntPtr = v; }
    CVariant(FLOAT    v) { valType = vt_float   ; vFloat   = v; }
    CVariant(DOUBLE   v) { valType = vt_double  ; vDouble  = v; }
    CVariant(CLIPSTR  v) { valType = vt_pstring ; vStr     = v; }
    CVariant(VOID     v) { valType = vt_ptr     ; vPtr     = v; }
*/
    void convert(DWORD newType, bool forDisplay = true)
        {
         CVariant tmp = convertCopy(newType, forDisplay);
         swap(tmp);
        }

    BOOL asBool() const { return convertCopy(vt_bool).value.vBool; }
    CHAR asChar() const { return convertCopy(vt_char).value.vChar; }
    WCHAR asWChar() const { return convertCopy(vt_wchar).value.vWChar; }
    INT asShort() const { return convertCopy(vt_short).value.vShort; }
    INT asUShort() const { return convertCopy(vt_ushort).value.vUShort; }
    INT asInt() const { return convertCopy(vt_int).value.vInt; }
    UINT asUInt() const { return convertCopy(vt_uint).value.vUInt; }
    COLORREF asColorref() const { return convertCopy(vt_colorref).value.vUInt; }
    INT64 asInt64() const { return convertCopy(vt_int64).value.vInt64; }
    UINT64 asUInt64() const { return convertCopy(vt_uint64).value.vUInt64; }
    INT_PTR asIntPtr() const { return convertCopy(vt_int_ptr).value.vIntPtr; }
    UINT_PTR asUIntPtr() const { return convertCopy(vt_uint_ptr).value.vUIntPtr; }
    FLOAT asFloat() const { return convertCopy(vt_float).value.vFloat; }
    DOUBLE asDouble() const { return convertCopy(vt_double).value.vDouble; }
    VOID* asPtr() const { return convertCopy(vt_ptr).value.vPtr; }
    STRUCT_CLI_CLISYSTEMTIME asDatetime() const { return convertCopy(vt_datetime).value.vDatetime; }
    INTERFACE_CLI_IUNKNOWN* asUnknown() const 
       {
        if (valType==vt_iUnknown) return value.vUnknown;
        return 0;
       }
    STRUCT_CLI_BIGINTEGER     asBigInteger() const { return convertCopy(vt_bigint).value.vBigint; }
    STRUCT_CLI_RATIONALNUMBER asRational() const { return convertCopy(vt_rational).value.vRational; }



    ::std::wstring asString(bool forDisplay = true) const { return toString(forDisplay); }
#ifdef MARTY_UTF_H
    ::std::string  asCharString() const { return MARTY_UTF_NS toUtf8( toString() ); }
#endif

    //operator BOOL() const { return asBool(); }
    operator CHAR() const { return asChar(); }
    operator WCHAR() const { return asWChar(); }
    operator SHORT() const { return asShort(); }
    operator USHORT() const { return asUShort(); }
    operator INT() const { return asInt(); }
    operator UINT() const { return asUInt(); }
    operator INT64() const { return asInt64(); }
    operator UINT64() const { return asUInt64(); }
    //operator INT_PTR() const { return asIntPtr(); }
    //operator UINT_PTR() const { return asUIntPtr(); }
    operator DOUBLE() const { return asDouble(); }
    operator FLOAT() const { return asFloat(); }
    operator VOID*() const { return asPtr(); }

    operator ::std::wstring() const { return asString(); }
#ifdef MARTY_UTF_H
    operator ::std::string()  const { return asCharString(); }
#endif
    operator STRUCT_CLI_CLISYSTEMTIME() const { return asDatetime(); }
    operator STRUCT_CLI_BIGINTEGER() const { return asBigInteger(); }
    operator STRUCT_CLI_RATIONALNUMBER() const { return asRational(); }

/*
    CVariant convertCopy(DWORD newType) const
        {
         switch(newType)
            {
             case vt_char    :  return CVariant(CHAR(toWideInt()));
             case vt_wchar   :  return CVariant(WCHAR(toWideInt()));
             case vt_int     :  return CVariant(INT(toWideInt()));
             case vt_uint    :  return CVariant(UINT(toWideUInt()));
             case vt_int64   :  return CVariant(INT64(toWideInt()));
             case vt_uint64  :  return CVariant(UINT64(toWideUInt()));
             case vt_int_ptr :  return CVariant(INT_PTR(toWideInt()));
             case vt_uint_ptr:  return CVariant(UINT_PTR(toWideUInt()));
             case vt_float   :  return CVariant(FLOAT(toDouble()));
             case vt_double  :  return CVariant(DOUBLE(toDouble()));
             case vt_pstring :  return CVariant(toString());
             case vt_ptr     :  return CVariant((void*)(toWideUInt()));
             default:           return CVariant(INT(0));
            }
        }
*/

}; // struct CVariant

}; // namespace impl
//}; // namespace arglist
}; // namespace cli



#endif /* CORE_ALVARIANT_H */

