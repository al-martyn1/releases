#define CLI_INTERNAL

#ifndef CLI_CLIRC_H
    #include <cli/clirc.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#include <cli/csec.h>

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CORE_OBJLIST_H
    #include "objlist.h"
#endif

#ifndef CLI_IO_IO_H
    #include <cli/io/io.h>
#endif

#ifndef CLI_IO_MSTREAMS_H
    #include <cli/io/mstreams.h>
#endif

#ifndef CLI_IO_SSTREAMS_H
    #include <cli/io/sstreams.h>
#endif

#if !defined(_MEMORY_) && !defined(_STLP_MEMORY) && !defined(__STD_MEMORY__) && !defined(_CPP_MEMORY) && !defined(_GLIBCXX_MEMORY)
    #include <memory>
#endif

#if !defined(_UTILITY_) && !defined(_STLP_UTILITY) && !defined(__STD_UTILITY__) && !defined(_CPP_UTILITY) && !defined(_GLIBCXX_UTILITY)
    #include <utility>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#include <marty/libapi.h>

#ifndef MARTY_FILESYS_H
    #include <marty/filesys.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif

#ifndef CLI_UNKNOWN_H
    #include <cli/unknown.h>
#endif

#ifndef CLI_FMTUTIL_H
    #include <cli/fmtutil.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif


#include "taggedStream.h"

#ifndef SRC_CORE_CLIRC_H
    #include "clircimpl.h"
#endif

// http://doc.crossplatform.ru/qt/4.6.x/resources.html

static ::cli::CCriticalSection rcCs(1000, false);
static INTERFACE_CLI_IRESOURCEMANAGER* pRcMan = 0;


CLIAPIENTRY
INTERFACE_CLI_IRESOURCEMANAGER*
CLICALL
cliGetRcMan( )
   {
    CLI_SCOPED_LOCK(rcCs);
    if (pRcMan) return pRcMan;
    
    try{
        pRcMan = static_cast< INTERFACE_CLI_IRESOURCEMANAGER* >(new ::cli::impl::CResourceManagerImpl());
       }
    catch(...)
       {
       }

    CLIASSERT(pRcMan);
    return pRcMan;
   }

CLIAPIENTRY
INTERFACE_CLI_IRESOURCEMANAGER*
CLICALL
cliChangeRcMan( INTERFACE_CLI_IRESOURCEMANAGER* pRcManNew )
   {
    CLI_SCOPED_LOCK(rcCs);
    INTERFACE_CLI_IRESOURCEMANAGER* retRcMan = pRcMan;
    pRcMan = pRcManNew;
    if (!pRcMan)
       {
        try{
            pRcMan = static_cast< INTERFACE_CLI_IRESOURCEMANAGER* >(new ::cli::impl::CResourceManagerImpl());
           }
        catch(...)
           {
           }
       }
    else
       {
        pRcMan->addRef();
       }
    CLIASSERT(pRcMan);
    return retRcMan;
   }

CLIAPIENTRY
VOID
CLICALL
cliSetRcMan( INTERFACE_CLI_IRESOURCEMANAGER* pRcManNew )
   {
    INTERFACE_CLI_IRESOURCEMANAGER* prevRcMan = cliChangeRcMan( pRcManNew );
    if (prevRcMan) prevRcMan->release();
   }


RCODE
clircUnpackRleImpl( const ::std::string &strPacked, ::std::string &strTo )
   {
    SIZE_T i=0;
    for(; i<=(SIZE_T)strPacked.size(); )
       {
        if (strPacked[i]&(unsigned char)0x80)
           {
            SIZE_T j, rpt = (size_t)(strPacked[i]&(unsigned char)0x7F);
            for(j=0; j!=rpt; ++j)
               { 
                //strAppendTo.append(1,(char)data[i+1]);
                //pfs_str_append_char(pStrAppendTo, (char)data[i+1]);
                //*appendTo++ = data[i+1];
                strTo.append(1,strPacked[i+1]);
               }
            i += 2;
           }
        else
           {
            size_t j, rpt = (size_t)(strPacked[i++]&(unsigned char)0x7F);
            for(j=0; j!=rpt; ++j, ++i)
               {
                //strAppendTo.append(1,(char)data[i]);
                //pfs_str_append_char(pStrAppendTo, (char)data[i]);
                //*appendTo++ = data[i];
                strTo.append(1,strPacked[i]);
               }
           }
       }
    return 0;
   }

CLIAPIENTRY
RCODE
CLICALL
clircUnpackRle( const CLICSTR* strPacked, CLICSTR* strUnpackTo )
   {
    CLI_TRY{
            ::std::string strTo;
            RCODE res = clircUnpackRleImpl( stdstr(strPacked), strTo );
            if (res) return res;
            return ::cli::propertyGetImpl( strUnpackTo, strTo );
           }
    CLI_CATCH_RETURN_CLI_EXCEPTION()
    CLI_CATCH_RETURN_STD_EXCEPTIONS()
    return EC_OK;
   }


namespace cli {
namespace impl {

ENUM_CLI_ERCMANFINDFLAGS        CResourceManagerImpl :: defFindFlags(0);
::cli::CCriticalSection         CResourceManagerImpl :: builtinsRcCs(1000, false);
CResourceManagerImpl::CRcVector                       CResourceManagerImpl :: builtinsRc;
::cli::CCriticalSection         CResourceManagerImpl :: pathListCs(1000, false);
::std::vector< ::std::wstring>  CResourceManagerImpl :: userPathList;
::cli::CCriticalSection         CResourceManagerImpl :: stringResourceGlobalCs;
::std::map< ::std::wstring, CResourceManagerImpl::CStringResourceCache* >  CResourceManagerImpl :: stringResourceGlobal;
::std::wstring                  CResourceManagerImpl :: rcLocale;
::std::set< ::std::wstring >    CResourceManagerImpl :: cachedFiles;

}; // namespace impl
}; // namespace cli


#include <cli/cli2_msg.cpp>

//static ::cli::CRcAutoReg cli2_msg_reg( &cli2_msg[0], sizeof_cli2_msg, L"cli2.msg" );
