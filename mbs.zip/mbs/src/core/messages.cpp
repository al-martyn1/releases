#define CLI_INTERNAL

#include <cli/messages.h>

#include <locale.h>


#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif

#include <cli/clistr.h>
#include <cli/csec.h>
#include <marty/libapi.h>
#include <marty/filename.h>
#include <cli/formatx.h>

#include <marty/utf.h>
#include <marty/filename.h>
#include <marty/filesys.h>
#include <marty/util.h>



#if !defined(_INC_STDLIB) && !defined(_STDLIB_H_) && !defined(_STDLIB_H)
    #include <stdlib.h>
#endif

#if !defined(_INC_WCHAR) && !defined(_WCHAR_H_) && !defined(_WCHAR_H)
    #include <wchar.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif


#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_INC_LOCALE) && !defined(_LOCALE_H_) && !defined(_LOCALE_H)
    #include <locale.h>
#endif

#ifndef CLI_MONOLITHIC
    #include <cli/climod.h>
    extern ::cli::CModule cliModule;
#endif

#ifndef _WIN32
    #include <marty/env.h>
#endif

#include <marty/filesys.cpp>

#ifndef CLI_CLIRC_H
    #include <cli/clirc.h>
#endif

#ifndef CLI_ARGLIST_H
    #include <cli/arglist.h>
#endif


#include "cli2init.h"


// http://rus-linux.net/MyLDP/HOWTO-ru/Cyr-HOWTO-ru/Cyrillic-HOWTO-russian-11.html

//-----------------------------------------------------------------------------

#ifndef CLI_MONOLITHIC
    //extern ABSTRACT_MODULE_HANDLE  hCliDll;
    #define hCliDll cliModule.getModuleHandle()
#endif

//-----------------------------------------------------------------------------
//::cli::messages::impl::
namespace cli
{
namespace messages
{
namespace impl
{

//-----------------------------------------------------------------------------
#ifdef _WIN32

// ::std::wstring win32StrToWide(const std::string &str, int codePage = CP_ACP)
// ::std::string win32StrToAnsi(const ::std::wstring &str, int codePage = CP_ACP)

inline
::std::wstring win32StrToWide(const std::string &str, int codePage = CP_ACP)
   {
    DWORD flags = MB_PRECOMPOSED;
    switch(codePage)
       {
        case 50220: case 50221: case 50222: case 50225: case 50227: case 50229: case 52936: case 54936:
        case 57002: case 57003: case 57004: case 57005: case 57006: case 57007: case 57008: case 57009:
        case 57010: case 57011: case 65000: case 65001: case 42   :
            flags = 0; break;
       };

    int res = ::MultiByteToWideChar( codePage,
                                     flags,
                                     str.c_str(),
                                     //str.size(),
                                     -1,
                                     0, 0);
    wchar_t *pRes = (wchar_t*)_alloca((size_t)(res+1)*sizeof(wchar_t));
    if (::MultiByteToWideChar( codePage,
                         flags,
                         str.c_str(),
                         //str.size(),
                         -1,
                         pRes, res))
       {
        pRes[res] = 0;
        return std::wstring(pRes); 
       }
    return std::wstring();
    //pRes[res] = 0;
   }

inline
::std::string win32StrToAnsi(const ::std::wstring &str, int codePage = CP_ACP)
   {
    int res = ::WideCharToMultiByte( codePage,
                                     WC_COMPOSITECHECK,
                                     str.c_str(),
                                     //str.size(),
                                     -1,
                                     0, 0,
                                     0, 0
                                     );
    char *pRes = (char*)_alloca((size_t)(res+1)*sizeof(char));
    if (::WideCharToMultiByte( codePage,
                           WC_COMPOSITECHECK,
                           str.c_str(),
                           //str.size(),
                           -1,
                           pRes, res,
                           0, 0
                           ))
       {
        pRes[res] = 0;
        return ::std::string(pRes); 
       }
    //pRes[res] = 0;
    return ::std::string();
   }
#endif

//-----------------------------------------------------------------------------
inline
::std::wstring toStr(RCODE rc)
   {
    WCHAR buf[128];
    #ifdef _WIN32
    _snwprintf(buf, sizeof(buf)/sizeof(buf[0]), L"0x%08X", rc );
    #else
    swprintf  (buf, sizeof(buf)/sizeof(buf[0]), L"0x%08X", rc );
    #endif
    return ::std::wstring(buf);
   }

//-----------------------------------------------------------------------------
inline
::std::wstring uintToStr(unsigned i)
   {
    WCHAR buf[128];
    #ifdef _WIN32
    _snwprintf(buf, sizeof(buf)/sizeof(buf[0]), L"%u", i );
    #else
    swprintf  (buf, sizeof(buf)/sizeof(buf[0]), L"%u", i );
    #endif
    return ::std::wstring(buf);
   }

//-----------------------------------------------------------------------------
#ifdef _WIN32

inline
::std::wstring getLocaleInfo(LCID lcid, LCTYPE lctype)
   {
    WCHAR buf[256];
    buf[ ::GetLocaleInfoW(lcid, lctype, buf, sizeof(buf)/sizeof(buf[0])-1) ] = 0;
    return ::std::wstring(buf);
   }

inline 
::std::wstring getDefLocaleName( DWORD flags )
   {
    LCID lcid = (flags&FIND_MESSAGE_USE_USER_LOCALE) ? LOCALE_USER_DEFAULT : LOCALE_SYSTEM_DEFAULT;

    ::std::wstring res = getLocaleInfo(lcid, LOCALE_SISO639LANGNAME);
    
    if (res.empty()) return ::std::wstring();

    ::std::wstring country = getLocaleInfo(lcid, LOCALE_SISO3166CTRYNAME);
    if (!country.empty())
       {
        res.append(L"_");
        res.append(country);
       }
    return res;
   }

#else

inline
::std::wstring getDefLocaleNameAux()
   {
    ::std::wstring localeName;
    if (!::marty::env::getVar(::std::wstring(L"LC_MESSAGES"), localeName))
       ::marty::env::getVar(::std::wstring(L"LANG"), localeName);
    return localeName;
   }

inline
::std::wstring getDefLocaleName(DWORD  /* flags */ ) // remove encoding part
   {
    ::std::wstring lname = getDefLocaleNameAux();
    if (lname.empty()) return lname;
    ::std::wstring::size_type pos = lname.find('.');
    if (pos!=::std::wstring::npos) return ::std::wstring(lname, 0, pos);
    return lname;
   }

#endif

//-----------------------------------------------------------------------------




// #define CLI_MESSAGES_USE_OLD_VERSION


//-----------------------------------------------------------------------------
template <typename CacheMap, typename CSec>
::std::wstring findString( CacheMap &cacheMap
                         , CSec &csec
                         , const ::std::wstring &fromModule
                         , const ::std::wstring &suffix
                         , const ::std::wstring &id
                         , const ::std::wstring &lang
                         , DWORD flags
                         )
   {
    #ifndef CLI_MESSAGES_USE_OLD_VERSION
    
    ::cli::CiResourceManager_tmp rcMan = cliGetRcMan( );
    ::std::wstring resStr;

    if ( rcMan.findGenericString( resStr, id, lang, flags, fromModule, suffix ))
       return ::std::wstring();
    return resStr;

    #else    

    ::std::vector< ::std::wstring > langs;
    if (!lang.empty()) langs.push_back(lang);
    ::std::wstring::size_type pos = lang.find('_');
    if (pos!=::std::wstring::npos) langs.push_back(::std::wstring(lang, 0, pos));
    langs.push_back(::std::wstring(L"en_US"));
    langs.push_back(::std::wstring(L"en_GB"));
    langs.push_back(::std::wstring(L"en"));
    langs.push_back(::std::wstring());

     {
      CLI_SCOPED_LOCK(csec);
      for(::std::vector< ::std::wstring >::const_iterator lit = langs.begin(); lit!=langs.end(); ++lit)
         {
          //::std::wstring fullStrId = id; fullStrId.append(1, L'_'); fullStrId.append(*lit);
          ::std::wstring fullStrId = *lit; fullStrId.append(1, L'_'); fullStrId.append(id);
          typename CacheMap::const_iterator it = cacheMap.find(fullStrId);
          if (it!=cacheMap.end()) return it->second;
         }
     }

    using MARTY_FILENAME_NS appendPath;
    using MARTY_FILENAME_NS getPath;
    using MARTY_FILENAME_NS getName;
    using MARTY_FILENAME_NS appendExtention;
    using MARTY_FILENAME_NS makeCanonical;

    ::std::wstring basename;
    if (flags&FIND_MESSAGE_FROM_MODULE && !fromModule.empty())
       {
        #ifndef CLI_MONOLITHIC
        basename = fromModule;
        #else
        MARTY_LIBAPI_NS getModuleFileName( 0, basename );
        basename = appendPath (getPath(basename), fromModule);
        #endif
       }
    #ifndef CLI_MONOLITHIC
    else if (!(flags&FIND_MESSAGE_FROM_APP))
       { // from cli
        MARTY_LIBAPI_NS getModuleFileName( hCliDll, basename );
       }
    #endif
    else
       {
        MARTY_LIBAPI_NS getModuleFileName( 0, basename );
       }

    ::std::wstring basePath = getPath(basename);
    ::std::wstring baseFile = getName(basename);
    ::std::vector< ::std::pair< ::std::wstring, ::std::wstring> > files;

    for(::std::vector< ::std::wstring >::const_iterator lit = langs.begin(); lit!=langs.end(); ++lit)
       {
        ::std::wstring root1 = appendPath(basePath, L"../conf/locale/");
        ::std::wstring root2 = appendPath(basePath, L"../rc/locale/");
        ::std::wstring root3 = appendPath(basePath, L"conf/locale/");
        ::std::wstring root4 = appendPath(basePath, L"rc/locale/");
        root1 = appendPath(root1, *lit);
        root2 = appendPath(root2, *lit);
        root3 = appendPath(root3, *lit);
        root4 = appendPath(root4, *lit);
        root1 = appendPath(root1, baseFile);
        root2 = appendPath(root2, baseFile);
        root3 = appendPath(root3, baseFile);
        root4 = appendPath(root4, baseFile);

        files.push_back( ::std::make_pair(makeCanonical(appendExtention(root1, suffix)), *lit ));
        files.push_back( ::std::make_pair(makeCanonical(appendExtention(root2, suffix)), *lit ));
        files.push_back( ::std::make_pair(makeCanonical(appendExtention(root3, suffix)), *lit ));
        files.push_back( ::std::make_pair(makeCanonical(appendExtention(root4, suffix)), *lit ));

        ::std::wstring tmpBaseFile = baseFile;
        if (!lit->empty())
           {
            tmpBaseFile.append(1,'_');
            tmpBaseFile.append(*lit);
           }
        ::std::wstring buddyFile = appendPath(basePath, tmpBaseFile);
        files.push_back( ::std::make_pair(makeCanonical(appendExtention(buddyFile, suffix)), *lit ));
       }


    //::cli::format::cli_log::message( L"\n---\nLookup for %2 for %1, id: %3\n"
    //                  , ::cli::format::arg(fromModule) % suffix % id
    //                  );


    ::std::wstring foundStr;
    ::std::vector< ::std::pair< ::std::wstring, ::std::wstring> >::const_iterator fit = files.begin();
    for(; fit!=files.end(); ++fit)
       {
        /*
        ::cli::format::cli_log::message( L"try %1\n"
                          , ::cli::format::arg(*fit)
                          );
        */

        #if defined(UNICODE) || defined(_UNICODE)
        MARTY_FILESYSTEM_NS handle_t hFile = MARTY_FILESYSTEM_NS openFile( fit->first, MARTY_FILESYSTEM_NS o_rdonly);
        #else
            #ifdef _WIN32
                MARTY_FILESYSTEM_NS handle_t hFile = MARTY_FILESYSTEM_NS openFile( win32StrToAnsi(fit->first), MARTY_FILESYSTEM_NS o_rdonly);
            #else
                ::std::string tmpFilename; MARTY_FILESYSTEM_NS filenameEncode(tmpFilename, fit->first);
                MARTY_FILESYSTEM_NS handle_t hFile = MARTY_FILESYSTEM_NS openFile( tmpFilename, MARTY_FILESYSTEM_NS o_rdonly);
            #endif
        #endif
        if (hFile == MARTY_FILESYSTEM_NS hInvalidHandle)
           {
            /*
            ::cli::format::cli_log::message( L"Can't open %1\n"
                          , ::cli::format::arg(fit->first)
                          );
            */
            continue;
           }
        /*
        ::cli::format::cli_log::message( L"File opened ok - %1\n"
                      , ::cli::format::arg(fit->first)
                      );
        */

        ::std::wstring fileText;
        //res.reserve(utfStr.size());
        MARTY_UTF_NS CCharsCollector<wchar_t> collector(fileText);
        MARTY_UTF_NS CUtfToWcharDecoder<MARTY_UTF_NS CCharsCollector<wchar_t> > decoder(collector); // use auto detect feature - default parameter 2 value

        char buf[4096];
        int readed = MARTY_FILESYSTEM_NS readFile(hFile, buf, sizeof(buf));
        while(readed>0)
           {
            decoder(buf, readed);
            readed = MARTY_FILESYSTEM_NS readFile(hFile, buf, sizeof(buf));
           }
    
        //std::cout<<"File: "<<argv[i]<<"\n"<<MARTY_UTF_NS toUtf8(fileText)<<"\n";

        MARTY_FILESYSTEM_NS closeFile(hFile);

        std::vector< ::std::wstring > lines;

        ::marty::util::split(lines, fileText, ::marty::util::CIsExactChar<'\n'>(), ::marty::util::token_compress_on);

        std::vector< ::std::wstring >::const_iterator lineIt = lines.begin();
        for(; lineIt!=lines.end(); ++lineIt)
           {
            /*
            ::cli::format::cli_log::message( L"Pare line - %1\n"
                          , ::cli::format::arg(*lineIt)
                          );
            */
            ::std::wstring line = ::marty::util::trim_copy( *lineIt, ::marty::util::CIsSpace<wchar_t>());
            if (line.empty()) continue;

            ::std::wstring::size_type spacePos = lineIt->find(' ');
            if (spacePos == ::std::wstring::npos) continue; // space separator not found

            ::std::wstring key(*lineIt, 0, spacePos);
            if (key.empty())  continue;
            if (key[0]==L'#') continue;
            if (key.size()>1 && key[0]==L'\"' && key[key.size()-1]==L'\"')
               {
                key.erase(key.size()-1); // remove trailing quot
                key.erase(0, 1);         // remove leading quot
               }

            ::std::wstring val = ::marty::util::trim_copy( ::std::wstring(*lineIt, spacePos, ::std::wstring::npos ), ::marty::util::CIsSpace<wchar_t>());
            if (val.size()>1 && val[0]==L'\"' && val[val.size()-1]==L'\"')
               {
                val.erase(val.size()-1); // remove trailing quot
                val.erase(0, 1);         // remove leading quot
               }

            if (key == id && foundStr.empty()) foundStr = val;

            key.append(1, L'_'); key.append(fit->second);
            CLI_SCOPED_LOCK(csec);
            cacheMap[key] = val;
           }
       }

    if (foundStr.empty())
       {
        #ifdef _DEBUG
        ::cli::format::cli_log::message( L"\n---\nMessage/string '%1' (module: %2) not found in files:\n"
                                       , ::cli::format::arg(id) % fromModule
                                       );

        //::std::vector< ::std::pair< ::std::wstring, ::std::wstring> >::const_iterator 
        fit = files.begin();
        for(; fit!=files.end(); ++fit)
           {
            ::cli::format::cli_log::message( L"%1 - %2\n"
                              , ::cli::format::arg(fit->second) % fit->first
                              );
           }       
        #endif
       }
    return foundStr;
    #endif
   }

//-----------------------------------------------------------------------------
}; // namespace impl
}; // namespace messages
}; // namespace cli
//-----------------------------------------------------------------------------



//-----------------------------------------------------------------------------
static ::std::map< ::std::wstring, ::std::wstring> messages;
static ::std::map< ::std::wstring, ::std::wstring> strings;
static ::cli::CCriticalSection                     msgLocker;
static ::cli::CCriticalSection                     strLocker;

//-----------------------------------------------------------------------------
CLIAPIENTRY
RCODE
CLICALL
cliFindMessage( CLIPSTR *msgFound
              , const WCHAR *moduleName
              , RCODE code
              , const WCHAR *langAndLocale
              , DWORD flags
              )
   {
    #ifndef CLI_MESSAGES_USE_OLD_VERSION

    ::cli::CiResourceManager_tmp rcMan = cliGetRcMan( );
    ::std::wstring resStr;

    if ( !rcMan.findMessageEx( resStr, code, stdstr(langAndLocale), flags, stdstr(moduleName) ))
       {
        clipstr_alloc( msgFound, resStr.c_str() );
        return EC_OK;
       }
    return EC_RESOURCE_NOT_FOUND;

    #else

    ::std::wstring lcname   = langAndLocale ? ::std::wstring(langAndLocale) : ::cli::messages::impl::getDefLocaleName(flags);
    ::std::wstring modname  = moduleName ? ::std::wstring(moduleName) : ::std::wstring();
    ::std::wstring strFound = ::cli::messages::impl::findString( messages
                                                               , msgLocker
                                                               , modname
                                                               , ::std::wstring(L".msg")
                                                               , ::cli::messages::impl::toStr(code)
                                                               , lcname
                                                               , flags
                                                               );
    if (strFound.empty())
       {
        //if (msgFound) *msgFound = 0;
        return EC_RESOURCE_NOT_FOUND;
       }

    if (msgFound)
       clipstr_alloc( msgFound, strFound.c_str() );

    return EC_OK;
    #endif
   }

//-----------------------------------------------------------------------------
CLIAPIENTRY
RCODE
CLICALL
cliFindString( CLIPSTR *msgFound
             , const WCHAR *moduleName
             , const WCHAR *strId
             , const WCHAR *langAndLocale
              , DWORD flags
             )
   {

    ::cli::CCliOptions* pOpts = ::cli::getCliRuntimeOptions();

    //pOpts->log()<<"-------\nInitializing CLI2\n-------\n";

    #ifndef CLI_MESSAGES_USE_OLD_VERSION

    ::cli::CiResourceManager_tmp rcMan = cliGetRcMan( );
    ::std::wstring resStr;

    if ( !rcMan.findStringEx( resStr, stdstr(strId), stdstr(langAndLocale), flags, stdstr(moduleName) ))
       {
        clipstr_alloc( msgFound, resStr.c_str() );
        return EC_OK;
       }

    pOpts->log()<<"cliFindString: fail: "<< stdstr(strId).c_str() << "\n";

    return EC_RESOURCE_NOT_FOUND;

    #else

    if (!strId) return EC_RESOURCE_NOT_FOUND;
    ::std::wstring lcname   = langAndLocale ? ::std::wstring(langAndLocale) : ::cli::messages::impl::getDefLocaleName(flags);
    ::std::wstring modname  = moduleName ? ::std::wstring(moduleName) : ::std::wstring();
    ::std::wstring strFound = ::cli::messages::impl::findString( strings
                                                               , strLocker
                                                               , modname
                                                               , ::std::wstring(L".str")
                                                               , ::std::wstring(strId)
                                                               , lcname
                                                               , flags
                                                               );
    if (strFound.empty())
       {
        //if (msgFound) *msgFound = 0;

        pOpts->log()<<"cliFindString: fail: " << stdstr(strId).c_str() << "\n";

        return EC_RESOURCE_NOT_FOUND;
       }

    if (msgFound)
       clipstr_alloc( msgFound, strFound.c_str() );

    return EC_OK;

    #endif
   }

//-----------------------------------------------------------------------------
#ifdef _WIN32

namespace win32
{


static ::std::map< ::std::wstring, WORD > lcidNamesToLangId;
static ::std::map< WORD, ::std::wstring > lcidNamesByLangId;
static ::cli::CCriticalSection            lcidNamesLocker;

//-----------------------------------------------------------------------------
//inline
/*
::std::wstring getLocaleInfo(LCID lcid, LCTYPE lctype)
   {
    WCHAR buf[256];
    buf[ ::GetLocaleInfoW(lcid, lctype, buf, sizeof(buf)/sizeof(buf[0])-1) ] = 0;
    return ::std::wstring(buf);
   }
*/
// inline 

::std::wstring getLocaleCrtName( LCID lcid, int t /* type 0 - full name, 1 - abb long, 2 - abbr short */
                               , ::std::wstring &langStr
                               , ::std::wstring &countryStr
                               )
   {
    LCTYPE lct = LOCALE_SENGLANGUAGE;
    if (t==1) lct = LOCALE_SABBREVLANGNAME;  // two-letter language abbreviation from the ISO Standard 639, and adding a third letter, as appropriate, to indicate the sublanguage
    if (t==2) lct = LOCALE_SISO639LANGNAME;  // of the language based entirely on the ISO Standard 639

    langStr = ::cli::messages::impl::getLocaleInfo(lcid, lct);

    ::std::wstring res = langStr;
    
    if (res.empty()) { langStr = L"C"; return res; }

    lct = LOCALE_SENGCOUNTRY;
    if (t==1) lct = LOCALE_SABBREVCTRYNAME;  // // mostly based on the ISO Standard 3166
    if (t==2) lct = LOCALE_SISO3166CTRYNAME; // Country/region name, based on ISO Standard 3166. 

    countryStr = ::cli::messages::impl::getLocaleInfo(lcid, lct);
    if (!countryStr.empty())
       {
        res.append(L"_");
        res.append(countryStr);
       }
    return res;
   }

void fillLcidMaps()
   {
    CLI_SCOPED_LOCK(lcidNamesLocker);
    if (lcidNamesToLangId.empty())
       { // 
        //if (!lcidNamesToLangId.empty()) return;
        for(WORD langId=0; langId<512 /* 9 bits */; ++langId)
           {
            for(WORD subLangId=0; subLangId<64; ++subLangId)
               {
                WORD langSublang = MAKELANGID(langId, subLangId);
                for(int type = 0; type<3; ++type)
                   {
                    ::std::wstring langStr, countryStr;
                    ::std::wstring fullName = getLocaleCrtName( MAKELCID( langSublang, SORT_DEFAULT)
                                                              , type, langStr, countryStr
                                                              );
                    if (fullName.empty()) continue;
                    if (subLangId==SUBLANG_NEUTRAL)
                       {
                        lcidNamesToLangId[langStr] = langSublang;
                       }
                    lcidNamesToLangId[fullName]    = langSublang;
                    lcidNamesByLangId[langSublang] = fullName;
                   }
               }
           }        
       }
   }

::std::wstring lcidToLocaleName(LCID lcid)
   {
    fillLcidMaps();
    
    ::std::map< WORD, ::std::wstring >::const_iterator it = lcidNamesByLangId.find( LANGIDFROMLCID(lcid) );
    if (it==lcidNamesByLangId.end()) return ::std::wstring(L"C");
    return it->second;
   }

LCID lcidFromLocaleName(const ::std::wstring &name)
   {
    fillLcidMaps();
    
    ::std::map< ::std::wstring, WORD >::const_iterator it = lcidNamesToLangId.find( name );
    if (it==lcidNamesToLangId.end()) return MAKELCID(LANG_USER_DEFAULT, SORT_DEFAULT);
    return MAKELCID(it->second, SORT_DEFAULT);
   }

::std::wstring getLocaleFullName( const ::std::wstring &shortName)
   {
    ::std::wstring langStr;
    ::std::wstring countryStr;
    return getLocaleCrtName( lcidFromLocaleName(shortName), 0, langStr, countryStr ) + ::std::wstring(L".ACP");
   }




//  A language ID is a 16 bit value which is the combination of a
//  primary language ID and a secondary language ID.  The bits are
//  allocated as follows:
//
//       +-----------------------+-------------------------+
//       |     Sublanguage ID    |   Primary Language ID   |
//       +-----------------------+-------------------------+
//        15                   10 9                       0   bit
//
//
//  Language ID creation/extraction macros:
//
//    MAKELANGID    - construct language id from a primary language id and
//                    a sublanguage id.
//    PRIMARYLANGID - extract primary language id from a language id.
//    SUBLANGID     - extract sublanguage id from a language id.
//

// #define MAKELANGID(p, s)       ((((WORD  )(s)) << 10) | (WORD  )(p))
// #define PRIMARYLANGID(lgid)    ((WORD  )(lgid) & 0x3ff)
// #define SUBLANGID(lgid)        ((WORD  )(lgid) >> 10)


//
//  A locale ID is a 32 bit value which is the combination of a
//  language ID, a sort ID, and a reserved area.  The bits are
//  allocated as follows:
//
//       +-------------+---------+-------------------------+
//       |   Reserved  | Sort ID |      Language ID        |
//       +-------------+---------+-------------------------+
//        31         20 19     16 15                      0   bit
//
//
//  Locale ID creation/extraction macros:
//
//    MAKELCID            - construct the locale id from a language id and a sort id.
//    MAKESORTLCID        - construct the locale id from a language id, sort id, and sort version.
//    LANGIDFROMLCID      - extract the language id from a locale id.
//    SORTIDFROMLCID      - extract the sort id from a locale id.
//    SORTVERSIONFROMLCID - extract the sort version from a locale id.
//

// #define NLS_VALID_LOCALE_MASK  0x000fffff
//  
// #define MAKELCID(lgid, srtid)  ((DWORD)((((DWORD)((WORD  )(srtid))) << 16) |  
//                                          ((DWORD)((WORD  )(lgid)))))
// #define MAKESORTLCID(lgid, srtid, ver)                                        
//                                ((DWORD)((MAKELCID(lgid, srtid)) |             
//                                     (((DWORD)((WORD  )(ver))) << 20)))
// #define LANGIDFROMLCID(lcid)   ((WORD  )(lcid))
// #define SORTIDFROMLCID(lcid)   ((WORD  )((((DWORD)(lcid)) >> 16) & 0xf))
// #define SORTVERSIONFROMLCID(lcid)  ((WORD  )((((DWORD)(lcid)) >> 20) & 0xf))


//
//  Default System and User IDs for language and locale.
//

// #define LANG_SYSTEM_DEFAULT    (MAKELANGID(LANG_NEUTRAL, SUBLANG_SYS_DEFAULT))
// #define LANG_USER_DEFAULT      (MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT))


inline
size_t getMessageStringAux(unsigned err, wchar_t *buf, size_t bufSize, LCID lcid) // MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT)
{
    DWORD dwChars = ::FormatMessageW( FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS
                                    , 0, err
                                    , lcid
                                    , buf, (DWORD)bufSize, NULL 
                                    );
    return (size_t)dwChars;
}

bool getMessageString(DWORD err, ::std::wstring &msg, LCID lcid)
{
    WCHAR buf[4096];
    size_t copiedChars = getMessageStringAux(err, buf, (sizeof(buf)/sizeof(buf[0]))-1, lcid);
    if (!copiedChars) return false;
    buf[copiedChars] = 0;
    msg = buf;
    return true;
    //size_t needChars = getMessageStringAux(err, 0, size_t bufSize, LCID lcid) // MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT)
    //char *pRes = (char*)_alloca((size_t)(res+1)*sizeof(char));
}
//win32GetMessageStringAux






}; // namespace win32

#endif

// POSIX/CRT error message
namespace posix
{

static ::cli::CCriticalSection            strerrorLocker;

::std::wstring getErrorMessage(unsigned err, const WCHAR *localeName, DWORD flags)
{
    CLI_SCOPED_LOCK(strerrorLocker);
    char *prevLocale = 0;
    if (localeName)
       {
        #ifdef _WIN32
        prevLocale = setlocale( LC_ALL
                              , ::cli::messages::impl::win32StrToAnsi( win32::getLocaleFullName(localeName)).c_str()
                              );
        #else
        prevLocale = setlocale( LC_MESSAGES
                              , MARTY_UTF_NS toUtf8(localeName + ::std::wstring(L".UTF-8")).c_str()
                              );
        #endif
       }
    else // default locale used
       {
        #ifdef _WIN32
        prevLocale = setlocale( LC_ALL
                              , ::cli::messages::impl::win32StrToAnsi( win32::getLocaleFullName( ::cli::messages::impl::getDefLocaleName(flags) )).c_str()
                              );
        #else
        prevLocale = setlocale( LC_MESSAGES
                              , MARTY_UTF_NS toUtf8(::cli::messages::impl::getDefLocaleName(flags) + ::std::wstring(L".UTF-8")).c_str()
                              );
        #endif
       }

    std::string msg = strerror(err);

    if (prevLocale)
       {
        #ifdef _WIN32
        setlocale( LC_ALL, prevLocale );
        #else
        setlocale( LC_MESSAGES, prevLocale );
        #endif
       }
    #ifdef _WIN32
    return ::cli::messages::impl::win32StrToWide(msg);
    #else
    return MARTY_UTF_NS fromUtf8(msg);
    #endif
}

}; // namespace posix



namespace cli
{
namespace format
{
namespace impl
{
void
cliFormatMessage( ::std::wstring &strBuf
                , const WCHAR *fmtString
                , INTERFACE_CLI_IARGLIST* pArgs
                , DWORD flags /* FMF_* */
                , const INT *tabs
                , SIZE_T tabsSize
                );

}; // namespace impl
}; // namespace format
}; // namespace cli


CLIAPIENTRY
RCODE
CLICALL
cliFormatErrorMessage( CLIPSTR *msgFormatted
              , const WCHAR *moduleName
              , RCODE code
              , const WCHAR *langAndLocale
              , DWORD flags
              , INTERFACE_CLI_IARGLIST* pArgs
              )
   {

    ::std::wstring strFormat;
    DWORD platformCode;
    bool bw32 = false;

    RCODE resCode = EC_OK;

    switch(code&EC_SOURCE_MASK)
       {
        case EC_SOURCE_GENERIC:
        case EC_SOURCE_CLI:
                {
                 if (code==EC_GENERIC_ERROR) code &= ~(EC_CUSTOM_FLAG|EC_RESERVED_FLAG); // code = EC_GENERIC_ERROR_NO_FLAGS;

                 DWORD findMessageFlags = flags;
                 if ((code&EC_CUSTOM_FLAG) && moduleName)
                     findMessageFlags |= FIND_MESSAGE_FROM_MODULE;
                 else
                     findMessageFlags &= ~FIND_MESSAGE_FROM_MODULE;

                 findMessageFlags &= ~FMF_MASK; // clear format flags

                 #ifndef CLI_MESSAGES_USE_OLD_VERSION
                 
                 ::cli::CiResourceManager_tmp rcMan = cliGetRcMan( );
             
                 if ( rcMan.findMessageEx( strFormat, code, langAndLocale ? ::std::wstring(langAndLocale) : ::std::wstring()
                                         , findMessageFlags, moduleName ? ::std::wstring(moduleName) : ::std::wstring()
                                         )
                    )
                    strFormat.clear();


                 #else    

                 ::std::wstring lcname   = langAndLocale ? ::std::wstring(langAndLocale) : ::cli::messages::impl::getDefLocaleName(flags);
                 ::std::wstring modname  = moduleName ? ::std::wstring(moduleName) : ::std::wstring();

                 strFormat = ::cli::messages::impl::findString( messages
                                                              , msgLocker
                                                              , modname
                                                              , ::std::wstring(L".msg")
                                                              , ::cli::messages::impl::toStr(code)
                                                              , lcname
                                                              , flags
                                                              );
                 #endif
                }
                break;

        case EC_SOURCE_WIN32:  
                platformCode = RC2WIN(code);
                bw32 = true;

        case EC_SOURCE_COM:  
                #ifdef _WIN32
                if (!bw32)
                   platformCode = RC2HR(code);

                {
                 ::std::vector< LCID > lcids;
                 if (langAndLocale)
                    lcids.push_back( ::win32::lcidFromLocaleName(langAndLocale) );

                 if (flags&FIND_MESSAGE_USE_USER_LOCALE)
                    lcids.push_back( LANG_USER_DEFAULT );
                 else
                    lcids.push_back(LANG_SYSTEM_DEFAULT);

                 lcids.push_back( MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT) );

                 ::std::vector< LCID >::const_iterator lcidIt = lcids.begin();
                 for(; lcidIt!=lcids.end(); ++lcidIt)
                    {
                     //LCID tryLcid = ::win32::lcidFromLocaleName(*lcidIt);
                     if (::win32::getMessageString(platformCode, strFormat, *lcidIt))
                        break; // found message text
                    }
                }
                break;
                #else
                resCode = EC_FORMAT_ERR_UNAVAIL_TEXT;
                break;
                #endif

        case EC_SOURCE_POSIX:  
                strFormat = ::posix::getErrorMessage( RC2POSIX(code), langAndLocale, flags );
                break;
        //case :  
        //        break;
        default: resCode = EC_FORMAT_ERR_UNKN_CODE_SRC;
       }

    if (strFormat.empty())
       {
        if (!resCode)
           resCode = EC_RESOURCE_NOT_FOUND;
        strFormat = L"Not found message for code ";
        strFormat.append(::cli::messages::impl::toStr(code));
        strFormat.append(L".");
        if (pArgs)
           {
            SIZE_T paramCount = pArgs->getCount();
            if (paramCount)
               {
                strFormat.append(L" Format parameters (");
                strFormat.append(::cli::messages::impl::uintToStr((unsigned)pArgs->getCount()));
                strFormat.append(L" items) are:");
                for(SIZE_T i = 0; i<paramCount; ++i)
                   {
                    if (i) strFormat.append(L",");
                    strFormat.append(L" %");
                    strFormat.append(::cli::messages::impl::uintToStr((unsigned)i+1));
                   }
               }
           }
       }


    if (msgFormatted)
       {
        using namespace ::cli::format;
        ::std::wstring strFormattedBuf = ::cli::format::messageEx(strFormat, arg(pArgs), flags);
        //cliFormatMessage( strFormattedBuf, strFormat.c_str(), pArgs, flags, 0, 0 );
        clipstr_alloc( msgFormatted, strFormattedBuf.c_str() );
       }

//uintToStr
/*
    if (strFound.empty())
       {
        //if (msgFound) *msgFound = 0;
        return EC_RESOURCE_NOT_FOUND;
       }

    if (msgFound)
       clipstr_alloc( msgFound, strFound.c_str() );
*/
    return resCode;
    //::cli::messages::impl::
   }

//-----------------------------------------------------------------------------
