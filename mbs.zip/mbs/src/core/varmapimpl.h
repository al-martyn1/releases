#ifndef SRC_CORE_VARMAPIMPL_H
#define SRC_CORE_VARMAPIMPL_H

/* add this lines to your src
#ifndef SRC_CORE_VARMAPIMPL_H
    #include "varmapimpl.h"
#endif
*/

#ifndef CLI_IVARMAP_H
    #include <cli/ivarmap.h>
#endif

#ifndef CLI_VARIANTIMPL_H
    #include "variantImpl.h"
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_UTILITY_) && !defined(_STLP_UTILITY) && !defined(__STD_UTILITY__) && !defined(_CPP_UTILITY) && !defined(_GLIBCXX_UTILITY)
    #include <utility>
#endif


namespace cli
{
namespace impl
{

struct CVariantMapImplMap : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_IVARIANTMAP
{

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    ::std::map< ::std::wstring, INTERFACE_CLI_IVARIANT* >  varMap;

    CVariantMapImplMap() : base_impl(DEF_MODULE), varMap()
       {
       }

    CVariantMapImplMap( const CVariantMapImplMap &right ) : base_impl(DEF_MODULE), varMap()
       {
        ::std::map< ::std::wstring, INTERFACE_CLI_IVARIANT* >::iterator insertHint = varMap.begin();
        ::std::map< ::std::wstring, INTERFACE_CLI_IVARIANT* >::const_iterator it = right.varMap.begin();
        for(; it != right.varMap.end(); ++it)
           {
            INTERFACE_CLI_IVARIANT* pVariant = 0;
            if (it->second)
               {
                it->second->cloneVariant( &pVariant);
               }
            insertHint = varMap.insert( insertHint, ::std::make_pair( it->first, pVariant ) );
           }
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    ~CVariantMapImplMap()
       {
        clearMap();
       }

    CLI_BEGIN_INTERFACE_MAP2(CVariantMapImplMap, INTERFACE_CLI_IVARIANTMAP)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IVARIANTMAP )
    CLI_END_INTERFACE_MAP(CVariantMapImplMap)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    CLIMETHOD(insertValue) (THIS_ const CLISTR*     name
                                , BOOL    overwriteExisting /* [in] bool  overwriteExisting  */
                                , BOOL    copyValue /* [in] bool  copyValue  */
                                , INTERFACE_CLI_IVARIANT*    pValue /* [in,optional] ::cli::iVariant*  pValue  */
                           )
       {
        if (!name) return EC_INVALID_PARAM;
        return insertValueImpl( stdstr(name), overwriteExisting, copyValue, pValue );
       }

    CLIMETHOD(insertValueChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                                     , BOOL    overwriteExisting /* [in] bool  overwriteExisting  */
                                     , BOOL    copyValue /* [in] bool  copyValue  */
                                     , INTERFACE_CLI_IVARIANT*    pValue /* [in,optional] ::cli::iVariant*  pValue  */
                                )
       {
        if (!name) return EC_INVALID_PARAM;
        return insertValueImpl( stdstr(name), overwriteExisting, copyValue, pValue );
       }

    CLIMETHOD(queryValueByName) (THIS_ const CLISTR*     name
                                     , INTERFACE_CLI_IVARIANT**    pValue /* [out] ::cli::iVariant* pValue  */
                                )
       {
        if (!name) return EC_INVALID_PARAM;
        return queryValueByNameImpl( stdstr(name), pValue );
       }

    CLIMETHOD(queryValueByNameChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                                          , INTERFACE_CLI_IVARIANT**    pValue /* [out] ::cli::iVariant* pValue  */
                                     )
       {
        if (!name) return EC_INVALID_PARAM;
        return queryValueByNameImpl( stdstr(name), pValue );
       }

    CLIMETHOD(queryValueByNameTo) (THIS_ const CLISTR*     name
                                       , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                  )
       {
        if (!name) return EC_INVALID_PARAM;
        return queryValueByNameToImpl( stdstr(name), pValue );
       }

    CLIMETHOD(queryValueByNameCharsTo) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                                            , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                       )
       {
        if (!name) return EC_INVALID_PARAM;
        return queryValueByNameToImpl( stdstr(name), pValue );
       }

    CLIMETHOD(eraseByName) (THIS_ const CLISTR*     name)
       {
        if (!name) return EC_INVALID_PARAM;
        return eraseByNameImpl( stdstr(name) );
       }

    CLIMETHOD(eraseByNameChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */)
       {
        if (!name) return EC_INVALID_PARAM;
        return eraseByNameImpl( stdstr(name) );
       }

    CLIMETHOD(clearMap) (THIS)
       {
        ::std::map< ::std::wstring, INTERFACE_CLI_IVARIANT* >::const_iterator it = varMap.begin();
        for(; it != varMap.end(); ++it)
           {
            if (it->second) it->second->release();
           }
        varMap.clear();
        return EC_OK;
       }

    CLIMETHOD(cloneMap) (THIS_ INTERFACE_CLI_IVARIANTMAP**    pVarMap /* [out] ::cli::iVariantMap* pVarMap  */)
       {
        CLI_TRY{
                if (!pVarMap) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pVarMap" );  }
                *pVarMap = new CVariantMapImplMap( *this );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }


    CLIMETHOD(insertValueImpl) (THIS_ const ::std::wstring &name
                                , BOOL    overwriteExisting /* [in] bool  overwriteExisting  */
                                , BOOL    copyValue /* [in] bool  copyValue  */
                                , INTERFACE_CLI_IVARIANT*    pValue /* [in,optional] ::cli::iVariant*  pValue  */
                           )
       {
        ::std::map< ::std::wstring, INTERFACE_CLI_IVARIANT* >::iterator it = varMap.find(name);
        if (it != varMap.end() && !overwriteExisting ) return EC_ERR_ALLREADY;

        INTERFACE_CLI_IVARIANT* pVariantNew = 0;
        if (pValue && copyValue)
           {
            pValue->cloneVariant( &pVariantNew );
           }
        else
           {
            pVariantNew = pValue; 
            if (pVariantNew) pVariantNew->addRef(); 
           }

        if (it == varMap.end())
           {
            varMap.insert( ::std::make_pair(name, pVariantNew) );
           }
        else
           {
            if (it->second) it->second->release();
            it->second = pVariantNew;
           }
        return EC_OK;
       }

    CLIMETHOD(queryValueByNameImpl) (THIS_ const ::std::wstring &name
                                     , INTERFACE_CLI_IVARIANT**    pValue /* [out] ::cli::iVariant* pValue  */
                                )
       {
        ::std::map< ::std::wstring, INTERFACE_CLI_IVARIANT* >::const_iterator it = varMap.find(name);
        if (it == varMap.end() ) return EC_NOT_FOUND;
        if (pValue)
           {
            if (it->second) it->second->addRef();
            *pValue = it->second;
           }
        return EC_OK;
       }

    CLIMETHOD(queryValueByNameToImpl) (THIS_ const ::std::wstring &name
                                       , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                  )
       {
        ::std::map< ::std::wstring, INTERFACE_CLI_IVARIANT* >::const_iterator it = varMap.find(name);
        if (it == varMap.end() ) return EC_NOT_FOUND;
        if (pValue)
           {
            if (it->second) pValue->assignVariant(it->second);
            else            pValue->setEmpty();
           }
        return EC_OK;
       }

    CLIMETHOD(eraseByNameImpl) (THIS_ const ::std::wstring &name)
       {
        ::std::map< ::std::wstring, INTERFACE_CLI_IVARIANT* >::iterator it = varMap.find(name);
        if (it == varMap.end() ) return EC_NOT_FOUND;
        if (it->second) it->second->release();
        varMap.erase(it);
        return EC_OK;
       }

    CLIMETHOD(getFirstKey) (THIS_ CLISTR*           firstKey)
       {
        ::std::map< ::std::wstring, INTERFACE_CLI_IVARIANT* >::const_iterator it = varMap.begin();
        if (it == varMap.end() ) 
           {
            ::cli::propertyGetImpl( firstKey, ::std::wstring() );
            return EC_NOT_FOUND;
           }
        return ::cli::propertyGetImpl( firstKey, it->first );
       }

    CLIMETHOD(getNextKey) (THIS_ const CLISTR*     key
                               , CLISTR*           nextKey
                          )
       {
        ::std::map< ::std::wstring, INTERFACE_CLI_IVARIANT* >::const_iterator it = varMap.find( stdstr(key) );
        if (it == varMap.end() ) 
           {
            ::cli::propertyGetImpl( nextKey, ::std::wstring() );
            return EC_NOT_FOUND;
           }
        return ::cli::propertyGetImpl( nextKey, it->first );
       }


};



}; // namespace impl
}; // namespace cli



#endif /* SRC_CORE_VARMAPIMPL_H */

