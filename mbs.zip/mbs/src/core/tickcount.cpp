#define CLI_INTERNAL

/*
#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif
*/

#ifndef CLI_TICKCOUNT_H
    #include <cli/tickcount.h>
#endif

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif

#ifdef WIN32

    #if !defined(_WINDOWS_)
        #include <windows.h>
    #endif

#else
    
    #if !defined(_SYS_TIME_H) && !defined(_SYS_TIME_H_)
        #include <sys/time.h>
    #endif

    #if !defined(_INC_TIME) && !defined(_TIME_H_) && !defined(_TIME_H)
        #include <time.h>
    #endif

#endif


CLIAPIENTRY
TICK_T
CLICALL
cliGetTickCount( )
   {
    #ifdef WIN32

    static ilint_t  high_part = 0;
    static ilint_t  prev_tick = 0;

    ilint_t  cached_high_part = high_part;
    ilint_t  cached_prev_tick = prev_tick;
    unsigned     cur_tick         = ::GetTickCount();
    // �᫨ ���祭�� prev_tick �� �뫮 �������� ��㣨� ��⮪�� (�ࠢ������ � ������), ��࠭塞 ⥪�騩 ⨪
    interlockedCompareExchange(&prev_tick, ilint_t(cur_tick), cached_prev_tick);

    if (cur_tick < unsigned(cached_prev_tick)) // ���᪮� 48 ��⮪
        {
         // �᫨ ������ ���� �� ������� ��㣮� ��⮪, � ����ᨬ ���祭�� + 1, 
         // � ��⨢��� ��砥 ��祣� ���譮�� �� �ந������
         interlockedCompareExchange(&high_part, cached_high_part+1, cached_high_part);
         //high_part++;
        }
    //prev_tick = cur_tick;
    return (((UINT64)unsigned(high_part))<<32) | unsigned(cur_tick);

    #else

    struct timeval stv;

    #if defined(GETMICROUPTIME_SUPPORTED)
    ::getmicrouptime(&stv);
    #else
    ::gettimeofday(&stv, 0);
    #endif

    TICK_T sec_millisec = ((TICK_T)stv.tv_sec)*1000;
    TICK_T microsec_millisec = ((TICK_T)stv.tv_usec)/1000;

    TICK_T millisec = sec_millisec + microsec_millisec;

    return millisec;

    #endif
    
   }

CLIAPIENTRY
TICK_DIFF_T
CLICALL
cliTickDiff(TICK_T start_tick, TICK_T end_tick)
   {
    return (TICK_DIFF_T)(end_tick - start_tick); // requires compiler support for int64 type
   }

CLIAPIENTRY
INT
CLICALL
cliTickDiffShort(TICK_T start_tick, TICK_T end_tick)
   {
    return (INT)(TICK_DIFF_T)(end_tick - start_tick); // requires compiler support for int64 type
   }

CLIAPIENTRY
TICK_DIFF_T
CLICALL
cliGetCurrentTickDiff(TICK_T start_tick)
   {
    return cliTickDiff(start_tick, cliGetTickCount( ) );
   }

CLIAPIENTRY
INT
CLICALL
cliGerCurrentTickDiffShort(TICK_T start_tick)
   {
    return cliTickDiffShort(start_tick, cliGetTickCount( ) );
   }

