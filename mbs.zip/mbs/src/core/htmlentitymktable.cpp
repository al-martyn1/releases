
#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif



template<typename TC>
TC digit2charLower(unsigned digit)
{
    if (digit<10) return (TC)digit+(TC)'0';
    return (TC)digit-10+(TC)'a';
}

template<typename TC>
TC digit2charUpper(unsigned digit)
{
    if (digit<10) return (TC)digit+(TC)'0';
    return (TC)digit-10+(TC)'A';
}

template<typename TC>
TC digit2char(unsigned digit, bool upperCase = true)
{
    return upperCase ? digit2charUpper<TC>(digit) : digit2charLower<TC>(digit);
}

template< typename CharType 
        , typename Traits
        , typename Allocator
        >
bool formatUnsigned( ::std::basic_string<CharType, Traits, Allocator> &strFormatTo
                   , unsigned i, unsigned base = 10
                   , typename ::std::basic_string<CharType, Traits, Allocator>::size_type width = 0
                   , bool upperCase = true
                   )
{
    typedef ::std::basic_string<CharType, Traits, Allocator> string_type;
    typedef typename string_type::size_type  size_type;

    if (base==0) base = 10;

    if (base<2 || base>36) return false;
    size_type startPos = strFormatTo.size();
    size_type numCharsAdded = 0;
    for(; i>0; ++numCharsAdded )
       {
        strFormatTo.append( 1, digit2char<CharType>(i%base) );
        i /= base;
       }
    if (!numCharsAdded) { ++numCharsAdded; strFormatTo.append( 1, (CharType)'0' ); }
    for(; numCharsAdded<width; ++numCharsAdded) strFormatTo.append( 1, (CharType)'0' );
    ::std::reverse( strFormatTo.begin()+startPos, strFormatTo.begin()+startPos+numCharsAdded);
    return true;
} 



int main(int argc, char* argv[])
   {
    bool makeText = false;
    bool makeHtml = false;
    bool makeAttr = false;
    bool makeEntities = false;
    bool makeNoEntities = false;
    std::string targetType = "XmlText";
    if (argc>1) 
       {
        targetType = argv[1];
       }
    if (targetType=="XmlText")
       {
        makeText = true;
        makeHtml = false;
        makeAttr = false;
       }
    else if (targetType=="XmlAttr")
       {
        makeText = false;
        makeHtml = false;
        makeAttr = true;
       }
    else if (targetType=="HtmlText")
       {
        makeText = true;
        makeHtml = true;
        makeAttr = false;
       }
    else if (targetType=="HtmlAttr")
       {
        makeText = false;
        makeHtml = true;
        makeAttr = true;
       }
    else if (targetType=="Entities" || targetType=="XmlHtmlEntities")
       {
        makeEntities = true;
       }
    else if (targetType=="NoEntities")
       {
        makeNoEntities = true;
       }
    else
       {
        std::cout<<"Unknown target type\n";
        return 0;
       }
       
    struct char_entity
    {
     const char *entityName;
     unsigned    entityNameIndex;
     char_entity() : entityName(0), entityNameIndex(0) {}
     char_entity(const char *en) : entityName(en), entityNameIndex(0) {}
    };


    // http://www.ascii.cl/htmlcodes.htm
    // http://en.wikipedia.org/wiki/List_of_XML_and_HTML_character_entity_references

    std::map< wchar_t, char_entity > charEntities;
    
    /*
    charEntities[(wchar_t)0x01] = { "&#x01;";
    charEntities[(wchar_t)0x02] = { "&#x02;";
    charEntities[(wchar_t)0x03] = { "&#x03;";
    charEntities[(wchar_t)0x04] = { "&#x04;";
    charEntities[(wchar_t)0x05] = { "&#x05;";
    charEntities[(wchar_t)0x06] = { "&#x06;";
    charEntities[(wchar_t)0x07] = { "&#x07;";
    charEntities[(wchar_t)0x08] = { "&#x08;";
    */
    
    if (!makeEntities)
       {
        if (makeAttr) // this entity values must be used in attributes and allowed to be as non-entity in text
           {
            charEntities[(wchar_t)0x01] = char_entity( "#x01" );
            charEntities[(wchar_t)0x02] = char_entity( "#x02" );
            charEntities[(wchar_t)0x03] = char_entity( "#x03" );
            charEntities[(wchar_t)0x04] = char_entity( "#x04" );
            charEntities[(wchar_t)0x05] = char_entity( "#x05" );
            charEntities[(wchar_t)0x06] = char_entity( "#x06" );
            charEntities[(wchar_t)0x07] = char_entity( "#x07" );
            charEntities[(wchar_t)0x08] = char_entity( "#x08" );
            charEntities[(wchar_t)0x09] = char_entity( "#x09" ); // Horizontal tab \t
            charEntities[(wchar_t)0x0A] = char_entity( "#x0A" ); // Line feed \n
            charEntities[(wchar_t)0x0B] = char_entity( "#x0B" ); // unused
            charEntities[(wchar_t)0x0C] = char_entity( "#x0C" ); // unused
            charEntities[(wchar_t)0x0D] = char_entity( "#x0D" ); // Carriage Return \r
           }
        
        if (makeAttr || makeText) // this entity values must be used both in attributes and in text
           {
            charEntities[(wchar_t)0x0E] = char_entity( "#x0E" );
            charEntities[(wchar_t)0x0F] = char_entity( "#x0F" );
            charEntities[(wchar_t)0x10] = char_entity( "#x10" );
            charEntities[(wchar_t)0x11] = char_entity( "#x11" );
            charEntities[(wchar_t)0x12] = char_entity( "#x12" );
            charEntities[(wchar_t)0x13] = char_entity( "#x13" );
            charEntities[(wchar_t)0x14] = char_entity( "#x14" );
            charEntities[(wchar_t)0x15] = char_entity( "#x15" );
            charEntities[(wchar_t)0x16] = char_entity( "#x16" );
            charEntities[(wchar_t)0x17] = char_entity( "#x17" );
            charEntities[(wchar_t)0x18] = char_entity( "#x18" );
            charEntities[(wchar_t)0x19] = char_entity( "#x19" );
            charEntities[(wchar_t)0x1A] = char_entity( "#x1A" );
            charEntities[(wchar_t)0x1B] = char_entity( "#x1B" );
            charEntities[(wchar_t)0x1C] = char_entity( "#x1C" );
            charEntities[(wchar_t)0x1D] = char_entity( "#x1D" );
            charEntities[(wchar_t)0x1E] = char_entity( "#x1E" );
            charEntities[(wchar_t)0x1F] = char_entity( "#x1F" );
           }
    
        // XML predefined named entities
        if (makeAttr)
           {
            charEntities[(wchar_t)0x0022] = char_entity( "quot" );
            charEntities[(wchar_t)0x0026] = char_entity( "amp" );
            charEntities[(wchar_t)0x0027] = char_entity( "apos" );
           }
        if (makeText)
           {
            charEntities[(wchar_t)0x0027] = char_entity( "apos" );
            charEntities[(wchar_t)0x003C] = char_entity( "lt" );
            charEntities[(wchar_t)0x003E] = char_entity( "gt" );
           }
       }

    if (makeEntities)
       {
        charEntities[(wchar_t)0x00A0] = char_entity( "nbsp" );
        charEntities[(wchar_t)0x00A1] = char_entity( "iexcl" );
        charEntities[(wchar_t)0x00A2] = char_entity( "cent" );
        charEntities[(wchar_t)0x00A3] = char_entity( "pound" );
        charEntities[(wchar_t)0x00A4] = char_entity( "curren" );
        charEntities[(wchar_t)0x00A5] = char_entity( "yen" );
        charEntities[(wchar_t)0x00A6] = char_entity( "brvbar" );
        charEntities[(wchar_t)0x00A7] = char_entity( "sect" );
        charEntities[(wchar_t)0x00A8] = char_entity( "uml" );
        charEntities[(wchar_t)0x00A9] = char_entity( "copy" );
        charEntities[(wchar_t)0x00AB] = char_entity( "laquo" );
        charEntities[(wchar_t)0x00AC] = char_entity( "not" );
        charEntities[(wchar_t)0x00AD] = char_entity( "shy" );
        charEntities[(wchar_t)0x00AE] = char_entity( "reg" );
        charEntities[(wchar_t)0x00B0] = char_entity( "deg" );
        charEntities[(wchar_t)0x00B1] = char_entity( "plusmn" );
        charEntities[(wchar_t)0x00B2] = char_entity( "sup2" );
        charEntities[(wchar_t)0x00B3] = char_entity( "sup3" );
        charEntities[(wchar_t)0x00B4] = char_entity( "acute" );
        charEntities[(wchar_t)0x00B5] = char_entity( "micro" );
        charEntities[(wchar_t)0x00B6] = char_entity( "para" );
        charEntities[(wchar_t)0x00B7] = char_entity( "middot" );
        charEntities[(wchar_t)0x00B8] = char_entity( "cedil" );
        charEntities[(wchar_t)0x00B9] = char_entity( "sup1" );
        charEntities[(wchar_t)0x00BB] = char_entity( "raquo" );
        charEntities[(wchar_t)0x00BC] = char_entity( "frac14" );
        charEntities[(wchar_t)0x00BD] = char_entity( "frac12" );
        charEntities[(wchar_t)0x00BE] = char_entity( "frac34" );
        charEntities[(wchar_t)0x00BF] = char_entity( "iquest" );
    
        charEntities[(wchar_t)0x02C6] = char_entity( "circ" );
        charEntities[(wchar_t)0x02DC] = char_entity( "tilde" );
        charEntities[(wchar_t)0x2002] = char_entity( "ensp" );
        charEntities[(wchar_t)0x2003] = char_entity( "emsp" );
        charEntities[(wchar_t)0x2009] = char_entity( "thinsp" );
        charEntities[(wchar_t)0x2013] = char_entity( "ndash" );
        charEntities[(wchar_t)0x2014] = char_entity( "mdash" );
        charEntities[(wchar_t)0x2018] = char_entity( "lsquo" );
        charEntities[(wchar_t)0x2019] = char_entity( "rsquo" );
        charEntities[(wchar_t)0x201A] = char_entity( "sbquo" );
        charEntities[(wchar_t)0x201C] = char_entity( "ldquo" );
        charEntities[(wchar_t)0x201D] = char_entity( "rdquo" );
        charEntities[(wchar_t)0x201E] = char_entity( "bdquo" );
        charEntities[(wchar_t)0x2030] = char_entity( "permil" );
        charEntities[(wchar_t)0x2039] = char_entity( "lsaquo" );
        charEntities[(wchar_t)0x203A] = char_entity( "rsaquo" );
        charEntities[(wchar_t)0x20AC] = char_entity( "euro" );
        charEntities[(wchar_t)0x2122] = char_entity( "trade" );
        charEntities[(wchar_t)0x2264] = char_entity( "le" );
        charEntities[(wchar_t)0x2265] = char_entity( "ge" );

        /*
        charEntities[(wchar_t)] = "" );
        charEntities[(wchar_t)] = "" );
        charEntities[(wchar_t)] = "" );
        */
       }

    if (makeNoEntities)
       {
            charEntities[(wchar_t)0x1F] = char_entity( "#x1F" );
       }

    std::map< std::string, wchar_t > entityChars;

    std::map< wchar_t, char_entity >::iterator ceIt = charEntities.begin();
    for(; ceIt != charEntities.end(); ++ceIt)
       {
        entityChars[ceIt->second.entityName] = ceIt->first;
       }

    unsigned idx = 0;
    std::map< std::string, wchar_t >::iterator ecIt = entityChars.begin();
    for(; ecIt != entityChars.end(); ++ecIt, ++idx)
       {
        charEntities[ecIt->second].entityNameIndex = idx;
       }



    std::cout<<"struct C"<<targetType<<"EntityProcessing : public CEntityProcessingBase {\n\n";

    std::cout<<"    static  wchar_t entityChars["<<(unsigned)charEntities.size()+1<<"];\n";
    std::cout<<"    static  unsigned charToEntity["<<(unsigned)charEntities.size()+1<<"];\n";
    std::cout<<"    static  const wchar_t *entities["<<(unsigned)entityChars.size()+1<<"];\n";
    std::cout<<"    static  wchar_t entityToChar["<<(unsigned)entityChars.size()+1<<"];\n";
    std::cout<<"\n\n";

    std::cout<<"    const wchar_t* getEntitiesCharString() const\n";
    std::cout<<"       {\n";
    std::cout<<"        return &entityChars[0];\n";
    std::cout<<"       }\n";
    std::cout<<"\n\n";

    std::cout<<"    // convert entiry name to char\n";
    std::cout<<"    bool convertEntityToChar( const std::wstring &entityName, std::wstring &val ) const\n";
    std::cout<<"       {\n";
    std::cout<<"        const wchar_t ** pBegin = &entities[0];\n";
    std::cout<<"        const wchar_t ** pEnd   = pBegin + "<<(unsigned)charEntities.size()<<";\n";
    std::cout<<"        const wchar_t **pFoundEntityName = (const wchar_t **)util::binary_find( pBegin, pEnd, entityName.c_str(), wstringLess );\n";
    std::cout<<"        if (pFoundEntityName!=pEnd)\n";
    std::cout<<"           {\n";
    std::cout<<"            SIZE_T entityIdx = pFoundEntityName - &entities[0];\n";
    std::cout<<"            val.assign(1,entityToChar[entityIdx]);\n";
    std::cout<<"            return true;\n";
    std::cout<<"           }\n";
    std::cout<<"        return false;\n";
    std::cout<<"       }\n";
    std::cout<<"\n\n";

    std::cout<<"    // convert entiry char to entity name\n";
    std::cout<<"    bool convertCharToEntity( wchar_t ch, std::wstring &entityNameAppendTo ) const\n";
    std::cout<<"       {\n";
    std::cout<<"        const wchar_t* pEntityChar = util::binary_find( entityChars, entityChars+"<<(unsigned)charEntities.size()<<", ch );\n";
    std::cout<<"        if (pEntityChar!=(entityChars+"<<(unsigned)charEntities.size()<<"))\n";
    std::cout<<"           {\n";
    std::cout<<"            SIZE_T charIdx = (pEntityChar - entityChars);\n";
    std::cout<<"            SIZE_T entityIdx = charToEntity[charIdx];\n";
    std::cout<<"            entityNameAppendTo.append(entities[entityIdx]);\n";
    std::cout<<"            return true;\n";
    std::cout<<"           }\n";
    std::cout<<"        return false;\n";
    std::cout<<"       }\n";
    std::cout<<"\n\n";

    std::cout<<"}; // struct C"<<targetType<<"EntityProcessing\n\n";


    // static\n
    std::cout<<"wchar_t C"<<targetType<<"EntityProcessing::entityChars["<<(unsigned)charEntities.size()+1<<"] = {\n";
    idx = 0;
    ceIt = charEntities.begin();
    for(; ceIt != charEntities.end(); ++ceIt, ++idx)
       {
        std::string formattedCharNumber;
        formatUnsigned( formattedCharNumber
                      , (unsigned)ceIt->first, 16
                      , (ceIt->first > 255) ? 4 : 2
                      , true // upperCase
                      );
        std::cout<<"  0x"<<formattedCharNumber<<", // "<<idx<<"  ("<<ceIt->second.entityName<<")\n";
       }
    std::cout<<"  0\n};\n\n";



    // static\n
    std::cout<<"unsigned C"<<targetType<<"EntityProcessing::charToEntity["<<(unsigned)charEntities.size()+1<<"] = {\n";
    idx = 0;
    ceIt = charEntities.begin();
    for(; ceIt != charEntities.end(); ++ceIt, ++idx)
       {
        std::string formattedNumber;
        formatUnsigned( formattedNumber
                      , (unsigned)ceIt->second.entityNameIndex, 10
                      , 1
                      , true // upperCase
                      );
        std::cout<<"  "<<formattedNumber;
        //std::map< wchar_t, char_entity >::iterator ceItNext = ceIt; ++ceItNext;
        //if (ceItNext!=charEntities.end()) 
        std::cout<<",";
        std::cout<<" // "<<idx<<"  ("<<ceIt->second.entityName<<")\n";
       }
    std::cout<<"  0xFA\n};\n\n";



    // static\n
    std::cout<<"const wchar_t* C"<<targetType<<"EntityProcessing::entities["<<(unsigned)entityChars.size()+1<<"] = {\n";
    idx = 0;
    ecIt = entityChars.begin();
    for(; ecIt != entityChars.end(); ++ecIt, ++idx)
       {
        std::cout<<"  L\""<<ecIt->first<<"\"";
        //std::map< std::string, wchar_t >::iterator ecItNext = ecIt; ++ecItNext;
        //if (ecItNext!=entityChars.end()) 
        std::cout<<",";
        std::string formattedCharNumber;
        formatUnsigned( formattedCharNumber
                      , (unsigned)ecIt->second, 16
                      , (ecIt->second > 255) ? 4 : 2
                      , true // upperCase
                      );
        std::cout<<" // "<<idx<<" (0x"<<formattedCharNumber<<")\n";
       }
    std::cout<<"  L\"END\"\n};\n\n";



    // static\n
    std::cout<<"wchar_t C"<<targetType<<"EntityProcessing::entityToChar["<<(unsigned)entityChars.size()+1<<"] = {\n";
    idx = 0;
    ecIt = entityChars.begin();
    for(; ecIt != entityChars.end(); ++ecIt, ++idx)
       {
        std::string formattedCharNumber;
        formatUnsigned( formattedCharNumber
                      , (unsigned)ecIt->second, 16
                      , (ecIt->second > 255) ? 4 : 2
                      , true // upperCase
                      );
        std::cout<<"  0x"<<formattedCharNumber<<"";
        //std::map< std::string, wchar_t >::iterator ecItNext = ecIt; ++ecItNext;
        //if (ecItNext!=entityChars.end()) 
        std::cout<<",";

        std::cout<<" // "<<idx<<" ("<<ecIt->first<<")\n";
       }
    std::cout<<"  0xFA\n};\n\n";


/*
    struct char_entity
    {
     const char *entityName;
     unsigned    entityNameIndex;
     char_entity() : entityName(0), entityNameIndex(0) {}
     char_entity(const char *en) : entityName(en), entityNameIndex(0) {}
    };

    std::map< wchar_t, char_entity > charEntities;
*/


    //std::map< wchar_t, std::string > charEntities;



    return 0;
   }