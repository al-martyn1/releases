
#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif


template<typename TC>
TC digit2charLower(unsigned digit)
{
    if (digit<10) return (TC)digit+(TC)'0';
    return (TC)digit-10+(TC)'a';
}

template<typename TC>
TC digit2charUpper(unsigned digit)
{
    if (digit<10) return (TC)digit+(TC)'0';
    return (TC)digit-10+(TC)'A';
}

template<typename TC>
TC digit2char(unsigned digit, bool upperCase = true)
{
    return upperCase ? digit2charUpper<TC>(digit) : digit2charLower<TC>(digit);
}

template< typename CharType 
        , typename Traits
        , typename Allocator
        >
bool formatUnsigned( ::std::basic_string<CharType, Traits, Allocator> &strFormatTo
                   , unsigned i, unsigned base = 10
                   , typename ::std::basic_string<CharType, Traits, Allocator>::size_type width = 0
                   , bool upperCase = true
                   )
{
    typedef ::std::basic_string<CharType, Traits, Allocator> string_type;
    typedef typename string_type::size_type  size_type;

    if (base==0) base = 10;

    if (base<2 || base>36) return false;
    size_type startPos = strFormatTo.size();
    size_type numCharsAdded = 0;
    for(; i>0; ++numCharsAdded )
       {
        strFormatTo.append( 1, digit2char<CharType>(i%base) );
        i /= base;
       }
    if (!numCharsAdded) { ++numCharsAdded; strFormatTo.append( 1, (CharType)'0' ); }
    for(; numCharsAdded<width; ++numCharsAdded) strFormatTo.append( 1, (CharType)'0' );
    ::std::reverse( strFormatTo.begin()+startPos, strFormatTo.begin()+startPos+numCharsAdded);
    return true;
} 


inline
std::string makeEscapedString( const std::string &str )
{
    std::string res; res.reserve(str.size());
    std::string::size_type i = 0, size = str.size();
    for(; i!=size; ++i)
       {
        char ch = str[i];
        
        switch(ch)
           {
            case '\\': res.append("\\\\");
                       break;
            case '\"': res.append("\\\"");
                       break;
            case '\'': res.append("\\\'");
                       break;
            case '\n': res.append("\\\n");
                       break;
            case '\r': res.append("\\\r");
                       break;
            case '\t': res.append("\\\t");
                       break;
            default:   res.append(1, ch);
           }
       }
    return res;
}


int main(int argc, char* argv[])
   {
    
        struct enc_info
        {
           unsigned        enc;
           unsigned        encIdx;
           const char     *info;
           const char     *canonicalName;
           enc_info() : enc(0), encIdx(0), info(0), canonicalName(0) {}
           enc_info(unsigned e, const char *cn, const char *i ) : enc(e), encIdx(0), info(i), canonicalName(cn) {}
        };

        // ms-help://MS.MSDNQTR.v90.en/intl/unicode_81rn.htm
        // Also see http://www.ietf.org/rfc/rfc1766.txt

        // http://www.iana.org/assignments/character-sets/character-sets.xhtml
        // http://www.w3.org/International/O-charset.ru.php

        std::map< std::string, enc_info >  encNames;

        encNames["translit"]            = enc_info( 3  , "translit"      , "International charsets to ASCI mapping" );
        encNames["transliteration"]     = enc_info( 3  , "translit"      , "International charsets to ASCI mapping" );
        // http://en.wikipedia.org/wiki/Translit

        encNames["ibm437"]              = enc_info( 437, "ibm437"        , "OEM United States" );
        encNames["ibm-437"]             = enc_info( 437, "ibm-437"       , "OEM United States" );
        encNames["asmo-708"]            = enc_info( 708, "asmo-708"      , "Arabic (ASMO 708)" );
        encNames["asmo-449"]            = enc_info( 709, "asmo-449"      , "ASMO-449+, BCON V4" );
        encNames["arabic"]              = enc_info( 710, "arabic"        , "Transparent Arabic" );
        encNames["dos-720"]             = enc_info( 720, "dos-720"       , "Arabic (Transparent ASMO); Arabic (DOS)" );
        encNames["dos-862"]             = enc_info( 862, "dos-862"       , "OEM Hebrew; Hebrew (DOS)" );

        encNames["cp-737"]              = enc_info( 737, "cp737"         , "OEM Greek (formerly 437G); Greek (DOS)" );
        encNames["cp-775"]              = enc_info( 775, "cp775"         , "OEM Baltic; Baltic (DOS)" );
        encNames["cp-850"]              = enc_info( 850, "cp850"         , "OEM Multilingual Latin 1; Western European (DOS)" );
        encNames["cp-852"]              = enc_info( 852, "cp852"         , "OEM Latin 2; Central European (DOS)" );
        encNames["cp-855"]              = enc_info( 855, "cp855"         , "OEM Cyrillic (primarily Russian)" );
        encNames["cp-857"]              = enc_info( 857, "cp857"         , "OEM Turkish; Turkish (DOS)" );
        encNames["cp-860"]              = enc_info( 860, "cp860"         , "OEM Portuguese; Portuguese (DOS)" );
        encNames["cp-861"]              = enc_info( 861, "cp861"         , "OEM Icelandic; Icelandic (DOS)" );
        encNames["cp-863"]              = enc_info( 863, "cp863"         , "OEM French Canadian; French Canadian (DOS)" );
        encNames["cp-864"]              = enc_info( 864, "cp864"         , "OEM Arabic; Arabic (864)" );
        encNames["cp-865"]              = enc_info( 865, "cp865"         , "OEM Nordic; Nordic (DOS)" );
        encNames["cp-866"]              = enc_info( 866, "cp866"         , "OEM Russian; Cyrillic (DOS)" );
        encNames["cp-869"]              = enc_info( 869, "cp869"         , "OEM Modern Greek; Greek, Modern (DOS)" );

        encNames["cp737"]               = enc_info( 737, "cp737"         , "OEM Greek (formerly 437G); Greek (DOS)" );
        encNames["cp775"]               = enc_info( 775, "cp775"         , "OEM Baltic; Baltic (DOS)" );
        encNames["cp850"]               = enc_info( 850, "cp850"         , "OEM Multilingual Latin 1; Western European (DOS)" );
        encNames["cp852"]               = enc_info( 852, "cp852"         , "OEM Latin 2; Central European (DOS)" );
        encNames["cp855"]               = enc_info( 855, "cp855"         , "OEM Cyrillic (primarily Russian)" );
        encNames["cp857"]               = enc_info( 857, "cp857"         , "OEM Turkish; Turkish (DOS)" );
        encNames["cp860"]               = enc_info( 860, "cp860"         , "OEM Portuguese; Portuguese (DOS)" );
        encNames["cp861"]               = enc_info( 861, "cp861"         , "OEM Icelandic; Icelandic (DOS)" );
        encNames["cp863"]               = enc_info( 863, "cp863"         , "OEM French Canadian; French Canadian (DOS)" );
        encNames["cp864"]               = enc_info( 864, "cp864"         , "OEM Arabic; Arabic (864)" );
        encNames["cp865"]               = enc_info( 865, "cp865"         , "OEM Nordic; Nordic (DOS)" );
        encNames["cp866"]               = enc_info( 866, "cp866"         , "OEM Russian; Cyrillic (DOS)" );
        encNames["cp869"]               = enc_info( 869, "cp869"         , "OEM Modern Greek; Greek, Modern (DOS)" );

        encNames["ibm-737"]             = enc_info( 737, "cp737"         , "OEM Greek (formerly 437G); Greek (DOS)" );
        encNames["ibm-775"]             = enc_info( 775, "cp775"         , "OEM Baltic; Baltic (DOS)" );
        encNames["ibm-850"]             = enc_info( 850, "cp850"         , "OEM Multilingual Latin 1; Western European (DOS)" );
        encNames["ibm-852"]             = enc_info( 852, "cp852"         , "OEM Latin 2; Central European (DOS)" );
        encNames["ibm-855"]             = enc_info( 855, "cp855"         , "OEM Cyrillic (primarily Russian)" );
        encNames["ibm-857"]             = enc_info( 857, "cp857"         , "OEM Turkish; Turkish (DOS)" );
        encNames["ibm-860"]             = enc_info( 860, "cp860"         , "OEM Portuguese; Portuguese (DOS)" );
        encNames["ibm-861"]             = enc_info( 861, "cp861"         , "OEM Icelandic; Icelandic (DOS)" );
        encNames["ibm-863"]             = enc_info( 863, "cp863"         , "OEM French Canadian; French Canadian (DOS)" );
        encNames["ibm-864"]             = enc_info( 864, "cp864"         , "OEM Arabic; Arabic (864)" );
        encNames["ibm-865"]             = enc_info( 865, "cp865"         , "OEM Nordic; Nordic (DOS)" );
        encNames["ibm-866"]             = enc_info( 866, "cp866"         , "OEM Russian; Cyrillic (DOS)" );
        encNames["ibm-869"]             = enc_info( 869, "cp869"         , "OEM Modern Greek; Greek, Modern (DOS)" );

        encNames["ibm737"]              = enc_info( 737, "cp737"         , "OEM Greek (formerly 437G); Greek (DOS)" );
        encNames["ibm775"]              = enc_info( 775, "cp775"         , "OEM Baltic; Baltic (DOS)" );
        encNames["ibm850"]              = enc_info( 850, "cp850"         , "OEM Multilingual Latin 1; Western European (DOS)" );
        encNames["ibm852"]              = enc_info( 852, "cp852"         , "OEM Latin 2; Central European (DOS)" );
        encNames["ibm855"]              = enc_info( 855, "cp855"         , "OEM Cyrillic (primarily Russian)" );
        encNames["ibm857"]              = enc_info( 857, "cp857"         , "OEM Turkish; Turkish (DOS)" );
        encNames["ibm860"]              = enc_info( 860, "cp860"         , "OEM Portuguese; Portuguese (DOS)" );
        encNames["ibm861"]              = enc_info( 861, "cp861"         , "OEM Icelandic; Icelandic (DOS)" );
        encNames["ibm863"]              = enc_info( 863, "cp863"         , "OEM French Canadian; French Canadian (DOS)" );
        encNames["ibm864"]              = enc_info( 864, "cp864"         , "OEM Arabic; Arabic (864)" );
        encNames["ibm865"]              = enc_info( 865, "cp865"         , "OEM Nordic; Nordic (DOS)" );
        encNames["ibm866"]              = enc_info( 866, "cp866"         , "OEM Russian; Cyrillic (DOS)" );
        encNames["ibm869"]              = enc_info( 869, "cp869"         , "OEM Modern Greek; Greek, Modern (DOS)" );

        encNames["ibm00858"]            = enc_info( 858, "ibm00858"      , "OEM Multilingual Latin 1 + Euro symbol" );
        encNames["windows-874"]         = enc_info( 874, "windows-874"   , "ANSI/OEM Thai (same as 28605, ISO 8859-15); Thai (Windows)" );
        encNames["shift_jis"]           = enc_info( 932, "shift-jis"     , "ANSI/OEM Japanese; Japanese (Shift-JIS)" );
        encNames["shift-jis"]           = enc_info( 932, "shift-jis"     , "ANSI/OEM Japanese; Japanese (Shift-JIS)" );
        encNames["gb2312"]              = enc_info( 936, "gb2312"        , "ANSI/OEM Simplified Chinese (PRC, Singapore); Chinese Simplified (GB2312)" );
        encNames["ks_c_5601-1987"]      = enc_info( 949, "ks-c-5601-1987", "ANSI/OEM Korean (Unified Hangul Code)" );
        encNames["ks-c-5601-1987"]      = enc_info( 949, "ks-c-5601-1987", "ANSI/OEM Korean (Unified Hangul Code)" );
        encNames["big5"]                = enc_info( 950, "big5"          , "ANSI/OEM Traditional Chinese (Taiwan; Hong Kong SAR, PRC); Chinese Traditional (Big5)" );

        encNames["windows-1250"]        = enc_info( 1250, "Windows-1250" , "ANSI Central European; Central European (Windows)" );
        encNames["windows-1251"]        = enc_info( 1251, "Windows-1251" , "ANSI Cyrillic; Cyrillic (Windows)" );
        encNames["windows-1252"]        = enc_info( 1252, "Windows-1252" , "ANSI Latin 1; Western European (Windows)" );
        encNames["windows-1253"]        = enc_info( 1253, "Windows-1253" , "ANSI Greek; Greek (Windows)" );
        encNames["windows-1254"]        = enc_info( 1254, "Windows-1254" , "ANSI Turkish; Turkish (Windows)" );
        encNames["windows-1255"]        = enc_info( 1255, "Windows-1255" , "ANSI Hebrew; Hebrew (Windows)" );
        encNames["windows-1256"]        = enc_info( 1256, "Windows-1256" , "ANSI Arabic; Arabic (Windows)" );
        encNames["windows-1257"]        = enc_info( 1257, "Windows-1257" , "ANSI Baltic; Baltic (Windows)" );
        encNames["windows-1258"]        = enc_info( 1258, "Windows-1258" , "ANSI/OEM Vietnamese; Vietnamese (Windows)" );

        encNames["windows1250"]         = enc_info( 1250, "Windows-1250" , "ANSI Central European; Central European (Windows)" );
        encNames["windows1251"]         = enc_info( 1251, "Windows-1251" , "ANSI Cyrillic; Cyrillic (Windows)" );
        encNames["windows1252"]         = enc_info( 1252, "Windows-1252" , "ANSI Latin 1; Western European (Windows)" );
        encNames["windows1253"]         = enc_info( 1253, "Windows-1253" , "ANSI Greek; Greek (Windows)" );
        encNames["windows1254"]         = enc_info( 1254, "Windows-1254" , "ANSI Turkish; Turkish (Windows)" );
        encNames["windows1255"]         = enc_info( 1255, "Windows-1255" , "ANSI Hebrew; Hebrew (Windows)" );
        encNames["windows1256"]         = enc_info( 1256, "Windows-1256" , "ANSI Arabic; Arabic (Windows)" );
        encNames["windows1257"]         = enc_info( 1257, "Windows-1257" , "ANSI Baltic; Baltic (Windows)" );
        encNames["windows1258"]         = enc_info( 1258, "Windows-1258" , "ANSI/OEM Vietnamese; Vietnamese (Windows)" );

        encNames["cp-1250"]             = enc_info( 1250, "Windows-1250" , "ANSI Central European; Central European (Windows)" );
        encNames["cp-1251"]             = enc_info( 1251, "Windows-1251" , "ANSI Cyrillic; Cyrillic (Windows)" );
        encNames["cp-1252"]             = enc_info( 1252, "Windows-1252" , "ANSI Latin 1; Western European (Windows)" );
        encNames["cp-1253"]             = enc_info( 1253, "Windows-1253" , "ANSI Greek; Greek (Windows)" );
        encNames["cp-1254"]             = enc_info( 1254, "Windows-1254" , "ANSI Turkish; Turkish (Windows)" );
        encNames["cp-1255"]             = enc_info( 1255, "Windows-1255" , "ANSI Hebrew; Hebrew (Windows)" );
        encNames["cp-1256"]             = enc_info( 1256, "Windows-1256" , "ANSI Arabic; Arabic (Windows)" );
        encNames["cp-1257"]             = enc_info( 1257, "Windows-1257" , "ANSI Baltic; Baltic (Windows)" );
        encNames["cp-1258"]             = enc_info( 1258, "Windows-1258" , "ANSI/OEM Vietnamese; Vietnamese (Windows)" );

        encNames["cp1250"]              = enc_info( 1250, "Windows-1250" , "ANSI Central European; Central European (Windows)" );
        encNames["cp1251"]              = enc_info( 1251, "Windows-1251" , "ANSI Cyrillic; Cyrillic (Windows)" );
        encNames["cp1252"]              = enc_info( 1252, "Windows-1252" , "ANSI Latin 1; Western European (Windows)" );
        encNames["cp1253"]              = enc_info( 1253, "Windows-1253" , "ANSI Greek; Greek (Windows)" );
        encNames["cp1254"]              = enc_info( 1254, "Windows-1254" , "ANSI Turkish; Turkish (Windows)" );
        encNames["cp1255"]              = enc_info( 1255, "Windows-1255" , "ANSI Hebrew; Hebrew (Windows)" );
        encNames["cp1256"]              = enc_info( 1256, "Windows-1256" , "ANSI Arabic; Arabic (Windows)" );
        encNames["cp1257"]              = enc_info( 1257, "Windows-1257" , "ANSI Baltic; Baltic (Windows)" );
        encNames["cp1258"]              = enc_info( 1258, "Windows-1258" , "ANSI/OEM Vietnamese; Vietnamese (Windows)" );

        encNames["macintosh"]           = enc_info( 10000, "macintosh"         , "macintosh MAC Roman; Western European (Mac)" );
        encNames["x-mac-japanese"]      = enc_info( 10001, "x-mac-japanese"    , "Japanese (Mac)" );
        encNames["x-mac-chinesetrad"]   = enc_info( 10002, "x-mac-chinesetrad" , "MAC Traditional Chinese (Big5); Chinese Traditional (Mac)" );
        encNames["x-mac-korean"]        = enc_info( 10003, "x-mac-korean"      , "Korean (Mac)" );
        encNames["x-mac-arabic"]        = enc_info( 10004, "x-mac-arabic"      , "Arabic (Mac)" );
        encNames["x-mac-hebrew"]        = enc_info( 10005, "x-mac-hebrew"      , "Hebrew (Mac)" );
        encNames["x-mac-greek"]         = enc_info( 10006, "x-mac-greek"       , "Greek (Mac)" );
        encNames["x-mac-cyrillic"]      = enc_info( 10007, "x-mac-cyrillic"    , "Cyrillic (Mac)" );
        encNames["x-mac-chinesesimp"]   = enc_info( 10008, "x-mac-chinesesimp" , "MAC Simplified Chinese (GB 2312); Chinese Simplified (Mac)" );
        encNames["x-mac-romanian"]      = enc_info( 10010, "x-mac-romanian"    , "Romanian (Mac)" );
        encNames["x-mac-ukrainian"]     = enc_info( 10017, "x-mac-ukrainian"   , "Ukrainian (Mac)" );
        encNames["x-mac-thai"]          = enc_info( 10021, "x-mac-thai"        , "Thai (Mac)" );
        encNames["x-mac-ce"]            = enc_info( 10029, "x-mac-ce"          , "MAC Latin 2; Central European (Mac)" );
        encNames["x-mac-icelandic"]     = enc_info( 10079, "x-mac-icelandic"   , "Icelandic (Mac)" );
        encNames["x-mac-turkish"]       = enc_info( 10081, "x-mac-turkish"     , "Turkish (Mac)" );
        encNames["x-mac-croatian"]      = enc_info( 10082, "x-mac-croatian"    , "Croatian (Mac)" );
        encNames["x-chinese_cns"]       = enc_info( 20000, "x-chinese_cns"     , "CNS Taiwan; Chinese Traditional (CNS)" );
        encNames["x-chinese-cns"]       = enc_info( 20000, "x-chinese-cns"     , "CNS Taiwan; Chinese Traditional (CNS)" );
        encNames["x-cp20001"]           = enc_info( 20001, "x-cp20001"         , "TCA Taiwan" );
        encNames["x_chinese-eten"]      = enc_info( 20002, "x-chinese-eten"    , "Eten Taiwan; Chinese Traditional (Eten)" );
        encNames["x-chinese-eten"]      = enc_info( 20002, "x-chinese-eten"    , "Eten Taiwan; Chinese Traditional (Eten)" );
        encNames["x-cp20003"]           = enc_info( 20003, "x-cp20003"         , "IBM5550 Taiwan" );
        encNames["x-cp20004"]           = enc_info( 20004, "x-cp20004"         , "TeleText Taiwan" );
        encNames["x-cp20005"]           = enc_info( 20005, "x-cp20005"         , "Wang Taiwan" );
        encNames["x-ia5"]               = enc_info( 20105, "x-ia5"             , "IA5 (IRV International Alphabet No. 5, 7-bit); Western European (IA5)" );
        encNames["x-ia5-german"]        = enc_info( 20106, "x-ia5-german"      , "IA5 German (7-bit)" );
        encNames["x-ia5-swedish"]       = enc_info( 20107, "x-ia5-swedish"     , "IA5 Swedish (7-bit)" );
        encNames["x-ia5-norwegian"]     = enc_info( 20108, "x-ia5-norwegian"   , "IA5 Norwegian (7-bit)" );
        encNames["us-ascii"]            = enc_info( 20127, "us-ascii"          , "US-ASCII (7-bit)" );
        encNames["x-cp20261"]           = enc_info( 20261, "x-cp20261"         , "T.61" );
        encNames["x-cp20269"]           = enc_info( 20269, "x-cp20269"         , "ISO 6937 Non-Spacing Accent" );
        encNames["koi8-r"]              = enc_info( 20866, "koi8-r"            , "Russian (KOI8-R); Cyrillic (KOI8-R)" );
        encNames["euc-jp"]              = enc_info( 20932, "euc-jp"            , "Japanese (JIS 0208-1990 and 0121-1990)" );
        encNames["x-cp20936"]           = enc_info( 20936, "x-cp20936"         , "Simplified Chinese (GB2312); Chinese Simplified (GB2312-80)" );
        encNames["x-cp20949"]           = enc_info( 20949, "x-cp20949"         , "Korean Wansung" );
        encNames["koi8-u"]              = enc_info( 21866, "koi8-u"            , "Ukrainian (KOI8-U); Cyrillic (KOI8-U)" );
        encNames["iso-8859-1"]          = enc_info( 28591, "iso-8859-1"        , "ISO 8859-1 Latin 1; Western European (ISO)" );
        encNames["iso-8859-2"]          = enc_info( 28592, "iso-8859-2"        , "ISO 8859-2 Central European; Central European (ISO)" );
        encNames["iso-8859-3"]          = enc_info( 28593, "iso-8859-3"        , "ISO 8859-3 Latin 3" );
        encNames["iso-8859-4"]          = enc_info( 28594, "iso-8859-4"        , "ISO 8859-4 Baltic" );
        encNames["iso-8859-5"]          = enc_info( 28595, "iso-8859-5"        , "ISO 8859-5 Cyrillic" );
        encNames["iso-8859-6"]          = enc_info( 28596, "iso-8859-6"        , "ISO 8859-6 Arabic" );
        encNames["iso-8859-7"]          = enc_info( 28597, "iso-8859-7"        , "ISO 8859-7 Greek" );
        encNames["iso-8859-8"]          = enc_info( 28598, "iso-8859-8"        , "ISO 8859-8 Hebrew; Hebrew (ISO-Visual)" );
        encNames["iso-8859-9"]          = enc_info( 28599, "iso-8859-9"        , "ISO 8859-9 Turkish" );
        encNames["iso-8859-13"]         = enc_info( 28603, "iso-8859-13"       , "ISO 8859-13 Estonian" );
        encNames["iso-8859-15"]         = enc_info( 28605, "iso-8859-15"       , "ISO 8859-15 Latin 9" );
        encNames["x-europa"]            = enc_info( 29001, "x-europa"          , "Europa 3" );
        encNames["iso-8859-8-i"]        = enc_info( 38598, "iso-8859-8-i"      , "ISO 8859-8 Hebrew; Hebrew (ISO-Logical)" );
        encNames["iso-2022-jp"]         = enc_info( 50220, "iso-2022-jp"       , "ISO 2022 Japanese with no halfwidth Katakana; Japanese (JIS)" );
        encNames["csiso2022jp"]         = enc_info( 50221, "csiso2022jp"       , "ISO 2022 Japanese with halfwidth Katakana; Japanese (JIS-Allow 1 byte Kana)" );
        encNames["iso-2022-jp"]         = enc_info( 50222, "iso-2022-jp"       , "ISO 2022 Japanese JIS X 0201-1989; Japanese (JIS-Allow 1 byte Kana - SO/SI)" );
        encNames["iso-2022-kr"]         = enc_info( 50225, "iso-2022-kr"       , "ISO 2022 Korean" );
        encNames["x-cp50227"]           = enc_info( 50227, "x-cp50227"         , "ISO 2022 Simplified Chinese; Chinese Simplified (ISO 2022)" );
        encNames["x-cp50229"]           = enc_info( 50229, "x-cp50229"         , "ISO 2022 Traditional Chinese" );
        encNames["euc-jp"]              = enc_info( 51932, "euc-jp"            , "EUC Japanese" );
        encNames["euc-cn"]              = enc_info( 51936, "euc-cn"            , "EUC Simplified Chinese; Chinese Simplified (EUC)" );
        encNames["euc-kr"]              = enc_info( 51949, "euc-kr"            , "EUC Korean" );
        encNames["euc"]                 = enc_info( 51950, "euc"               , "Traditional Chinese" );
        encNames["hz-gb-2312"]          = enc_info( 52936, "hz-gb-2312"        , "HZ-GB2312 Simplified Chinese; Chinese Simplified (HZ)" );
        encNames["x-iscii-de"]          = enc_info( 57002, "x-iscii-de"        , "ISCII Devanagari" );
        encNames["x-iscii-be"]          = enc_info( 57003, "x-iscii-be"        , "ISCII Bengali" );
        encNames["x-iscii-ta"]          = enc_info( 57004, "x-iscii-ta"        , "ISCII Tamil" );
        encNames["x-iscii-te"]          = enc_info( 57005, "x-iscii-te"        , "ISCII Telugu" );
        encNames["x-iscii-as"]          = enc_info( 57006, "x-iscii-as"        , "ISCII Assamese" );
        encNames["x-iscii-or"]          = enc_info( 57007, "x-iscii-or"        , "ISCII Oriya" );
        encNames["x-iscii-ka"]          = enc_info( 57008, "x-iscii-ka"        , "ISCII Kannada" );
        encNames["x-iscii-ma"]          = enc_info( 57009, "x-iscii-ma"        , "ISCII Malayalam" );
        encNames["x-iscii-gu"]          = enc_info( 57010, "x-iscii-gu"        , "ISCII Gujarati" );
        encNames["x-iscii-pa"]          = enc_info( 57011, "x-iscii-pa"        , "ISCII Punjabi" );
        encNames["utf-7"]               = enc_info( 65000, "utf-7"             , "Unicode (UTF-7)" );
        encNames["utf-8"]               = enc_info( 65001, "utf-8"             , "Unicode (UTF-8)" );
        encNames["utf-16"]              = enc_info( 1200 , "utf-16"            , "Unicode (UTF-16) little endian" );
        encNames["utf-16le"]            = enc_info( 1200 , "utf-16"            , "Unicode (UTF-16) little endian" );
        encNames["utf-16(le)"]          = enc_info( 1200 , "utf-16"            , "Unicode (UTF-16) little endian" );
        encNames["unicodeFEFF"]         = enc_info( 1200 , "utf-16"            , "Unicode (UTF-16) little endian" );
        encNames["utf-16be"]            = enc_info( 1201 , "utf-16be"          , "Unicode (UTF-16) big endian" );
        encNames["utf-16(be)"]          = enc_info( 1201 , "utf-16be"          , "Unicode (UTF-16) big endian" );
        encNames["unicodeFFFE"]         = enc_info( 1201 , "utf-16be"          , "Unicode (UTF-16) big endian" );

/*
        encNames["ibm037"]              = 37;  // IBM EBCDIC US-Canada 
        encNames["ibm500"]              = 500; // IBM EBCDIC International 
        encNames["ibm870"]              = 870; // IBM EBCDIC Multilingual/ROECE (Latin 2); IBM EBCDIC Multilingual Latin 2 
        encNames["cp875"]               = 875; // IBM EBCDIC Greek Modern 

1026 IBM1026 IBM EBCDIC Turkish (Latin 5) 
1047 IBM01047 IBM EBCDIC Latin 1/Open System 
1140 IBM01140 IBM EBCDIC US-Canada (037 + Euro symbol); IBM EBCDIC (US-Canada-Euro)  
1141 IBM01141 IBM EBCDIC Germany (20273 + Euro symbol); IBM EBCDIC (Germany-Euro) 
1142 IBM01142 IBM EBCDIC Denmark-Norway (20277 + Euro symbol); IBM EBCDIC (Denmark-Norway-Euro) 
1143 IBM01143 IBM EBCDIC Finland-Sweden (20278 + Euro symbol); IBM EBCDIC (Finland-Sweden-Euro) 
1144 IBM01144 IBM EBCDIC Italy (20280 + Euro symbol); IBM EBCDIC (Italy-Euro) 
1145 IBM01145 IBM EBCDIC Latin America-Spain (20284 + Euro symbol); IBM EBCDIC (Spain-Euro) 
1146 IBM01146 IBM EBCDIC United Kingdom (20285 + Euro symbol); IBM EBCDIC (UK-Euro) 
1147 IBM01147 IBM EBCDIC France (20297 + Euro symbol); IBM EBCDIC (France-Euro) 
1148 IBM01148 IBM EBCDIC International (500 + Euro symbol); IBM EBCDIC (International-Euro) 
1149 IBM01149 IBM EBCDIC Icelandic (20871 + Euro symbol); IBM EBCDIC (Icelandic-Euro) 
1200 utf-16 Unicode UTF-16, little endian byte order (BMP of ISO 10646); available only to managed applications 
1201 unicodeFFFE Unicode UTF-16, big endian byte order; available only to managed applications  
1361 Johab Korean (Johab) 
12000 utf-32 Unicode UTF-32, little endian byte order; available only to managed applications 
12001 utf-32BE Unicode UTF-32, big endian byte order; available only to managed applications 

20273 IBM273 IBM EBCDIC Germany 
20277 IBM277 IBM EBCDIC Denmark-Norway 
20278 IBM278 IBM EBCDIC Finland-Sweden 
20280 IBM280 IBM EBCDIC Italy 
20284 IBM284 IBM EBCDIC Latin America-Spain 
20285 IBM285 IBM EBCDIC United Kingdom 
20290 IBM290 IBM EBCDIC Japanese Katakana Extended 
20297 IBM297 IBM EBCDIC France 
20420 IBM420 IBM EBCDIC Arabic 
20423 IBM423 IBM EBCDIC Greek 
20424 IBM424 IBM EBCDIC Hebrew 

20833 x-EBCDIC-KoreanExtended IBM EBCDIC Korean Extended 
20838 IBM-Thai IBM EBCDIC Thai 

20871 IBM871 IBM EBCDIC Icelandic 
20880 IBM880 IBM EBCDIC Cyrillic Russian 
20905 IBM905 IBM EBCDIC Turkish 
20924 IBM00924 IBM EBCDIC Latin 1/Open System (1047 + Euro symbol) 

21025 cp1025 IBM EBCDIC Cyrillic Serbian-Bulgarian 
21027  (deprecated) 

        encNames[""] = 50930; //   EBCDIC Japanese (Katakana) Extended                                                           
        encNames[""] = 50931; //   EBCDIC US-Canada and Japanese                                                                 
        encNames[""] = 50933; //   EBCDIC Korean Extended and Korean                                                             
        encNames[""] = 50935; //   EBCDIC Simplified Chinese Extended and Simplified Chinese                                     
        encNames[""] = 50936; //   EBCDIC Simplified Chinese                                                                     
        encNames[""] = 50937; //   EBCDIC US-Canada and Traditional Chinese                                                      
        encNames[""] = 50939; //   EBCDIC Japanese (Latin) Extended and Japanese                                                 

        encNames["GB18030"] = 54936; //   Windows XP and later: GB18030 Simplified Chinese (4 byte); Chinese Simplified (GB18030)
*/

    struct enc_info_ex
    {
       unsigned        enc;
       unsigned        nameIndex;
       unsigned        encIdx;
       std::vector<std::string>  names;
       std::string     info;
       enc_info_ex() : enc(0), nameIndex(0), encIdx(0), names(), info() {}
       enc_info_ex(unsigned e, unsigned ni, const std::string &i) : enc(e), nameIndex(ni), encIdx(0), names(), info(i) {}
    };

    std::vector<std::string>          canonicalNames;
    std::map<std::string,unsigned>    canonicalNamesMap;

    // const char     *canonicalName;

    std::map< unsigned, enc_info_ex > encInfo;

    std::map< std::string, enc_info >::iterator encIt = encNames.begin();
    //unsigned //encIdx = 0, 
    //         encNameIdx = 0;
    for(; encIt != encNames.end(); ++encIt) // ++encIdx, ++encNameIdx
       {
        if (canonicalNamesMap.find(encIt->second.canonicalName)==canonicalNamesMap.end())
           { // canonical name not found
            canonicalNamesMap[encIt->second.canonicalName] = (unsigned)canonicalNames.size();
            canonicalNames.push_back(encIt->second.canonicalName);
           }

        //if (canonicalNameExistence
        if (encInfo.find(encIt->second.enc)==encInfo.end())
           {
            encInfo[encIt->second.enc] = enc_info_ex( encIt->second.enc, canonicalNamesMap.find(encIt->second.canonicalName)->second, encIt->second.info );
           }
        encInfo[encIt->second.enc].names.push_back(encIt->first);
       }

    std::map< unsigned, enc_info_ex >::iterator encInfoIt = encInfo.begin();
    unsigned encIdx = 0;
    for(; encInfoIt != encInfo.end(); ++encInfoIt, ++encIdx)
       {
        encInfoIt->second.encIdx = encIdx;
        std::vector<std::string>::iterator nit = encInfoIt->second.names.begin();
        for(; nit != encInfoIt->second.names.end(); ++nit)
           {
            encNames[*nit].encIdx = encIdx;
           }
       }


    std::cout<<"struct CEncodingInfo{\n  unsigned encCode;\n  unsigned encNameIdx;\n  const char *encInfoString;\n};\n\n";
    std::cout<<"struct CEncNameToIndex{\n const char *encName;\n  unsigned encIdx;\n};\n\n";

    std::cout<<"static\nCEncodingInfo encInfo["<<(unsigned)encInfo.size()<<"] = {\n";

    //std::map< unsigned, enc_info_ex >::const_iterator 
    encInfoIt = encInfo.begin();
    //unsigned encIdx = 0;
    for(; encInfoIt != encInfo.end(); ++encInfoIt)
       {
        std::cout<< "  { " << encInfoIt->first<<", "<< encInfoIt->second.nameIndex<<", \""<<encInfoIt->second.info <<"\" }";
        std::map< unsigned, enc_info_ex >::const_iterator encInfoItNext = encInfoIt; ++encInfoItNext;
        if (encInfoItNext!=encInfo.end()) std::cout<<",";
        std::cout<<" // ";
        std::vector<std::string>::iterator nit = encInfoIt->second.names.begin();
        for(; nit != encInfoIt->second.names.end(); ++nit)
           {
            if (nit != encInfoIt->second.names.begin()) std::cout<<", ";
            std::cout<<*nit;
           }
        std::cout<<"\n";
       }
    std::cout<<"};\n\n";

    std::cout<<"static\nCEncNameToIndex encNameToIndex["<<(unsigned)encNames.size()<<"] = {\n";

    //std::map< std::string, enc_info >::const_iterator 
    encIt = encNames.begin();
    for(; encIt != encNames.end(); ++encIt)
       {
        //if (encIt != encNames.begin()) std::cout<<",\n  ";
        //else                           std::cout<<"\n  ";
        std::cout<< "  { \"" << encIt->first<<"\", "<<encIt->second.encIdx <<" }";
        std::map< std::string, enc_info >::const_iterator nextIt = encIt; ++nextIt;
        if (nextIt!=encNames.end()) std::cout<<",";
        std::cout<<" // "<<encIt->second.enc;
        std::cout<<"\n";
       }
    std::cout<<"};\n\n";

    std::cout<<"static\nconst char* encCanonicalNames["<<(unsigned)canonicalNames.size()<<"] = {\n";
    std::vector<std::string>::const_iterator cnIt = canonicalNames.begin();
    for(; cnIt != canonicalNames.end(); ++cnIt)
       {
        std::cout<<"  \""<<*cnIt<<"\"";
        std::vector<std::string>::const_iterator cnItNext = cnIt; ++cnItNext;
        if (cnItNext!=canonicalNames.end()) std::cout<<",";
        std::cout<<" // "<<(unsigned)(cnIt-canonicalNames.begin());
        std::cout<<"\n";
       }
    std::cout<<"};\n\n";

/*
    struct translit_entry
    {
     WCHA
    };
*/

    // http://www.ascii.cl/htmlcodes.htm
    // http://en.wikipedia.org/wiki/List_of_XML_and_HTML_character_entity_references

    std::map< wchar_t, std::string> translitMap;

    // Russian
    // Capital
    translitMap[0x0401] = "E"; // CyrYo
    translitMap[0x0403] = "G"; // CyrG - Ukrain
    translitMap[0x0404] = "Je"; // CyrRevertE - Ukrain - as Euro sign
    translitMap[0x0406] = "I"; // CyrI   - Ukrain (as latin capital i)
    translitMap[0x0407] = "Ji"; // CyrIdd - Ukrain (as latin capital i with double dot)

    translitMap[0x0410] = "A"; // CyrA
    translitMap[0x0411] = "B"; // CyrB
    translitMap[0x0412] = "V"; // CyrV
    translitMap[0x0413] = "G"; // CyrG
    translitMap[0x0414] = "D"; // CyrD
    translitMap[0x0415] = "E"; // CyrE
    translitMap[0x0416] = "Zh"; // CyrZh
    translitMap[0x0417] = "Z"; // CyrZ
    translitMap[0x0418] = "I"; // CyrI
    translitMap[0x0419] = "Y"; // CyrShortI (J)
    translitMap[0x041A] = "K"; // CyrK
    translitMap[0x041B] = "L"; // CyrL
    translitMap[0x041C] = "M"; // CyrM
    translitMap[0x041D] = "N"; // CyrN
    translitMap[0x041E] = "O"; // CyrO
    translitMap[0x041F] = "P"; // CyrP
    translitMap[0x0420] = "R"; // CyrR
    translitMap[0x0421] = "S"; // CyrS
    translitMap[0x0422] = "T"; // CyrT
    translitMap[0x0423] = "U"; // CyrU
    translitMap[0x0424] = "F"; // CyrF
    translitMap[0x0425] = "Kh"; // CyrH
    translitMap[0x0426] = "Ts"; // CyrC
    translitMap[0x0427] = "Ch"; // CyrCh
    translitMap[0x0428] = "Sh"; // CyrSh
    translitMap[0x0429] = "Shch"; // CyrSoftSh
    translitMap[0x042A] = "'"; // CyrHardSign
    translitMap[0x042B] = "Y"; // CyrII
    translitMap[0x042C] = "'"; // CyrSoftSign
    translitMap[0x042D] = "E"; // CyrEE
    translitMap[0x042E] = "Ju"; // CyrYu (Y/J)
    translitMap[0x042F] = "Ja"; // CyrYa (Y/J)

    // lowercase
    translitMap[0x0451] = "e"; // CyrYo
    translitMap[0x0453] = "g"; // CyrG - Ukrain
    translitMap[0x0454] = "je"; // CyrRevertE - Ukrain - as Euro sign
    translitMap[0x0456] = "i"; // CyrI   - Ukrain (as latin capital i)
    translitMap[0x0457] = "ji"; // CyrIdd - Ukrain (as latin capital i with double dot)

    translitMap[0x0430] = "a"; // CyrA
    translitMap[0x0431] = "b"; // CyrB
    translitMap[0x0432] = "v"; // CyrV
    translitMap[0x0433] = "g"; // CyrG
    translitMap[0x0434] = "d"; // CyrD
    translitMap[0x0435] = "e"; // CyrE
    translitMap[0x0436] = "zh"; // CyrZh
    translitMap[0x0437] = "z"; // CyrZ
    translitMap[0x0438] = "i"; // CyrI
    translitMap[0x0439] = "y"; // CyrShortI (J)
    translitMap[0x043A] = "k"; // CyrK
    translitMap[0x043B] = "l"; // CyrL
    translitMap[0x043C] = "m"; // CyrM
    translitMap[0x043D] = "n"; // CyrN
    translitMap[0x043E] = "o"; // CyrO
    translitMap[0x043F] = "p"; // CyrP
    translitMap[0x0440] = "r"; // CyrR
    translitMap[0x0441] = "s"; // CyrS
    translitMap[0x0442] = "t"; // CyrT
    translitMap[0x0443] = "u"; // CyrU
    translitMap[0x0444] = "f"; // CyrF
    translitMap[0x0445] = "kh"; // CyrH
    translitMap[0x0446] = "ts"; // CyrC
    translitMap[0x0447] = "ch"; // CyrCh
    translitMap[0x0448] = "sh"; // CyrSh
    translitMap[0x0449] = "shch"; // CyrSoftSh
    translitMap[0x044A] = "'"; // CyrHardSign
    translitMap[0x044B] = "y"; // CyrII
    translitMap[0x044C] = "'"; // CyrSoftSign
    translitMap[0x044D] = "e"; // CyrEE
    translitMap[0x044E] = "ju"; // CyrYu (y/j)
    translitMap[0x044F] = "ja"; // CyrYa (y/j)

    // Spanish http://webdesign.about.com/od/localization/l/blhtmlcodes-sp.htm
    translitMap[0x00C1] = "A"; // EsAacute - Capital A-acute
    translitMap[0x00E1] = "a"; // Esaacute - Lowercase a-acute
    translitMap[0x00C9] = "E"; // EsEacute - Capital E-acute
    translitMap[0x00E9] = "e"; // Eseacute - Lowercase e-acute
    translitMap[0x00CD] = "I"; // EsIacute - Capital I-acute
    translitMap[0x00ED] = "i"; // Esiacute - Lowercase i-acute
    translitMap[0x00D1] = "N"; // EsNtilde - Capital N-tilde (ENNE)
    translitMap[0x00F1] = "n"; // Esntilde - Lowercase n-tilde (enne)
    translitMap[0x00D3] = "O"; // EsOacute - Capital O-acute
    translitMap[0x00F3] = "o"; // Esoacute - Lowercase o-acute
    translitMap[0x00DA] = "U"; // EsUacute - Capital U-acute
    translitMap[0x00FA] = "u"; // Esuacute - Lowercase u-acute

    // Spanish-Deitch
    translitMap[0x00DC] = "U"; // EsUumlaut - Capital U-umlaut
    translitMap[0x00FC] = "u"; // Esuumlaut - Lowercase u-umlaut

    // http://ru.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D0%B5%D0%B3%D0%BE%D1%80%D0%B8%D1%8F:%D0%91%D1%83%D0%BA%D0%B2%D1%8B_%D1%80%D0%B0%D1%81%D1%88%D0%B8%D1%80%D0%B5%D0%BD%D0%BD%D0%BE%D0%B9_%D0%BB%D0%B0%D1%82%D0%B8%D0%BD%D0%B8%D1%86%D1%8B

    // Deitch
    translitMap[0x00C4] = "A"; // DeAumlaut - Capital A-umlaut
    translitMap[0x00E4] = "a"; // Deaumlaut - Lowercase a-umlaut
    translitMap[0x00D6] = "O"; // DeOumlaut - Capital O-umlaut
    translitMap[0x00F6] = "o"; // Deoumlaut - Lowercase o-umlaut

    translitMap[0x00C7] = "C"; // FrCcedil - Capital �-cedil
    translitMap[0x00E7] = "c"; // Frccedil - Lowercase c-cedil


    translitMap[0x00A5] = "Y"; // yen
    translitMap[0x00A6] = "|"; // brvbar
    translitMap[0x00A7] = "$"; // sect
    translitMap[0x00A8] = ":"; // uml
    translitMap[0x00A9] = "(c)"; // copy
    translitMap[0x00AB] = "\""; // laquo
    translitMap[0x00AC] = "!"; // not
    translitMap[0x00AD] = "shy";
    translitMap[0x00AE] = "(R)"; // reg
    translitMap[0x00B0] = "deg"; // deg
    translitMap[0x00B1] = "+-"; // plusmn
    translitMap[0x00B2] = "^2"; // sup2
    translitMap[0x00B3] = "^3"; // sup3
    translitMap[0x00B4] = "`"; // acute
    translitMap[0x00B5] = "u"; // micro
    translitMap[0x00B6] = "$"; // para
    translitMap[0x00B7] = "."; // middot
    translitMap[0x00B8] = ","; // cedil
    translitMap[0x00B9] = "^1"; // sup1
    translitMap[0x00BB] = "\""; // raquo
    translitMap[0x00BC] = "1/4"; // frac14
    translitMap[0x00BD] = "1/2"; // frac12
    translitMap[0x00BE] = "3/4"; // frac34
    translitMap[0x00BF] = "?"; // iquest

    translitMap[0x02C6] = "o"; // circ
    translitMap[0x02DC] = "~"; // tilde
    translitMap[0x2002] = " "; // ensp
    translitMap[0x2003] = " "; // emsp
    translitMap[0x2009] = " "; // thinsp
    translitMap[0x2013] = "-"; // ndash
    translitMap[0x2014] = "-"; //
    translitMap[0x2018] = "\'"; // lsquo
    translitMap[0x2019] = "\'"; // rsquo
    translitMap[0x201A] = ","; // sbquo
    translitMap[0x201C] = "\""; // ldquo
    translitMap[0x201D] = "\""; // rdquo
    translitMap[0x201E] = ",,"; // bdquo
    translitMap[0x2030] = "permil";
    translitMap[0x2039] = "\""; // lsaquo
    translitMap[0x203A] = "\""; // rsaquo
    translitMap[0x20AC] = "E"; // euro
    translitMap[0x2122] = "(tm)"; // trade
    translitMap[0x2264] = "<="; // le
    translitMap[0x2265] = ">="; // ge


    std::cout<<"static\nwchar_t encTranslitChars["<<(unsigned)translitMap.size()<<"] = {\n";
    std::map< wchar_t, std::string>::const_iterator tmIt = translitMap.begin();
    unsigned idx = 0;
    for(;tmIt != translitMap.end();++tmIt, ++idx)
       {
        std::string formattedCharNumber;
        formatUnsigned( formattedCharNumber
                      , (unsigned)tmIt->first, 16
                      , (tmIt->first > 255) ? 4 : 2
                      , true // upperCase
                      );
        std::cout<<"  0x"<<formattedCharNumber<<"";
        std::map< wchar_t, std::string >::const_iterator tmItNext = tmIt; ++tmItNext;
        if (tmItNext!=translitMap.end()) std::cout<<",";

        std::cout<<" // "<<idx<<" \""<<makeEscapedString(tmIt->second)<<"\"\n";
       }
    std::cout<<"};\n\n";

    std::cout<<"static\nconst char* encTranslitSubsts["<<(unsigned)translitMap.size()<<"] = {\n";
    //std::map< wchar_t, std::string>::const_iterator 
    tmIt = translitMap.begin();
    idx = 0;
    for(;tmIt != translitMap.end();++tmIt, ++idx)
       {
        std::cout<<"  \""<<makeEscapedString(tmIt->second)<<"\"";
        std::map< wchar_t, std::string >::const_iterator tmItNext = tmIt; ++tmItNext;
        if (tmItNext!=translitMap.end()) std::cout<<",";
        std::string formattedCharNumber;
        formatUnsigned( formattedCharNumber
                      , (unsigned)tmIt->first, 16
                      , (tmIt->first > 255) ? 4 : 2
                      , true // upperCase
                      );
        std::cout<<" // "<<idx<<" (0x"<<formattedCharNumber<<")\n";
       }
    std::cout<<"};\n\n";


/*
        struct enc_info
        {
           unsigned  enc;
           char     *info;
        };

        std::map< std::string, enc_info >  encNames;

        encNames["ibm437"]              = { 437, "OEM United States" };
*/


    return 0;
   }
