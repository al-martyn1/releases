/* Warning! Automaticaly generated file, do not edit */

#include <stack>
#include "fp_ATIParser_Automata.h"


#ifndef CLI_FORMAT_IMPL_CTIFORMATPARSER_STACK_USED
#define CLI_FORMAT_IMPL_CTIFORMATPARSER_STACK_USED
#endif

#ifndef CLI_FORMAT_IMPL_CTIFORMATPARSER_NO_OVERFLOW_CALLS
#define CLI_FORMAT_IMPL_CTIFORMATPARSER_NO_OVERFLOW_CALLS
#endif




namespace cli {
namespace format {
namespace impl {



}; // namespace impl {
}; // namespace format {
}; // namespace cli {

