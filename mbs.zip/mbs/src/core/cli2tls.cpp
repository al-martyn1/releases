#if defined(WIN32) || defined(_WIN32)

#define CLI_INTERNAL
#include <cli/tls.h>

static CLI_TLS_DESTUCTION_FN cliTlsDestructor = 0;

EXTERN_C
BOOL WINAPI DllMain( HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved );
BOOL WINAPI DllMain( HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved )
   {
    if (dwReason==DLL_THREAD_DETACH && cliTlsDestructor)
       cliTlsDestructor();
    return TRUE;
   }

CLIAPIENTRY
CLI_TLS_DESTUCTION_FN
CLICALL
cliSetTlsDestructorFunction( CLI_TLS_DESTUCTION_FN pfn )
   {
    CLI_TLS_DESTUCTION_FN ret = cliTlsDestructor;
    cliTlsDestructor = pfn;
    return ret;
   }

CLIAPIENTRY
CLI_TLS_DESTUCTION_FN
CLICALL
cliGetTlsDestructorFunction( )
   {
    return cliTlsDestructor;
   }
#endif

