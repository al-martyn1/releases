#ifndef SRC_CORE_CLIRCIMPL_H
#define SRC_CORE_CLIRCIMPL_H

/* add this lines to your scr
#ifndef SRC_CORE_CLIRCIMPL_H
    #include "clircimpl.h"
#endif
*/

#ifndef MARTY_ENV_H
    #include <marty/env.h>
#endif

#ifndef CLI_ICLONEAB_H
    #include <cli/icloneab.h>
#endif

#include <cli/io/sstreams.h>

#include "taggedStream.h"

namespace cli {
namespace impl {


namespace hlp {

#if defined(_WIN32) || defined(WIN32)

inline
::std::wstring getLocaleInfo(LCID lcid, LCTYPE lctype)
   {
    WCHAR buf[256];
    buf[ ::GetLocaleInfoW(lcid, lctype, buf, sizeof(buf)/sizeof(buf[0])-1) ] = 0;
    return ::std::wstring(buf);
   }

inline 
::std::wstring getDefLocaleName( DWORD flags )
   {
    LCID lcid = (flags&CLI_ERCMANFINDFLAGS_RCUSESYSTEMLOCALE) ? LOCALE_SYSTEM_DEFAULT : LOCALE_USER_DEFAULT;

    ::std::wstring res = getLocaleInfo(lcid, LOCALE_SISO639LANGNAME);
    
    if (res.empty()) return ::std::wstring();

    ::std::wstring country = getLocaleInfo(lcid, LOCALE_SISO3166CTRYNAME);
    if (!country.empty())
       {
        res.append(L"-");
        res.append(country);
       }
    return res;
   }

#else

inline
::std::wstring getDefLocaleNameAux()
   {
    ::std::wstring localeName;
    if (!::marty::env::getVar(::std::wstring(L"LC_MESSAGES"), localeName))
       ::marty::env::getVar(::std::wstring(L"LANG"), localeName);
    return localeName;
   }

inline
::std::wstring getDefLocaleName(DWORD  /* flags */ ) // remove encoding part
   {
    ::std::wstring lname = getDefLocaleNameAux();
    if (lname.empty()) return lname;
    ::std::wstring::size_type pos = lname.find('.');
    if (pos!=::std::wstring::npos) return ::std::wstring(lname, 0, pos);
    return lname;
   }

#endif

}; // namespace hlp



class CResourceManagerImpl : public INTERFACE_CLI_IRESOURCEMANAGER
                           , public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
{

        // GENERATOR: CLASS MEMBERS - GOES HERE
        // GENERATOR: CLASS MEMBERS - END

    public:

        typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
        typedef CResourceManagerImpl this_class;

        struct CBuiltinRc
        {
             ::std::wstring                 name;
             ::std::wstring                 lang;
             ENUM_CLI_ERCMANREGISTERFLAGS   rcType;
             //CiIOStream
             INTERFACE_CLI_IO_IIOSTREAM *pStream;
             CBuiltinRc( const ::std::wstring &n, const ::std::wstring &l, INTERFACE_CLI_IO_IIOSTREAM *ps, ENUM_CLI_ERCMANREGISTERFLAGS t )
                : name(n), lang(l), rcType(t), pStream(ps)
                {}
             CBuiltinRc( const ::std::wstring &n, const ::std::wstring &l )
                : name(n), lang(l), rcType(0), pStream(0)
                {}
             CBuiltinRc(const CBuiltinRc &b)
                : name(b.name), lang(b.lang), rcType(b.rcType), pStream(b.pStream)
                {}
        }; // struct CBuiltinRc

        struct CBuiltinNameLess
           {
            bool operator()( const CBuiltinRc &b1, const CBuiltinRc &b2)
               {
                return b1.name<b2.name;
               }
           };

        struct CBuiltinNameLangLess
           {
            bool operator()( const CBuiltinRc &b1, const CBuiltinRc &b2)
               {
                if (b1.name<b2.name) return true;
                else if (b1.name>b2.name) return false;
                return b1.lang<b2.lang;
               }
           };

        struct CBuiltinLangLess
           {
            bool operator()( const CBuiltinRc &b1, const CBuiltinRc &b2)
               {
                return b1.lang<b2.lang;
               }
           };

        typedef ::cli::util::CAutoSortVector<CBuiltinRc, CBuiltinNameLangLess>  CRcVector;


        struct CStringResourceEntry
        {
            ::std::wstring  key;
            ::std::wstring  value;
            CStringResourceEntry() : key(), value() {}
            CStringResourceEntry( const ::std::wstring &k) : key(k), value() {}
            CStringResourceEntry( const ::std::wstring &k, const ::std::wstring &v) : key(k), value(v) {}
        }; // struct CStringResourceEntry

        struct CStringResourceEntryLess
        {
            CStringResourceEntryLess() {}
            bool operator()(const CStringResourceEntry e1, const CStringResourceEntry &e2) { return e1.key < e2.key; }
        }; // struct CStringResourceEntryLess

        typedef ::cli::util::CAutoSortVector<CStringResourceEntry, CStringResourceEntryLess>  CStringResourceVector;

        struct CStringResourceCache
        {
            ::cli::CCriticalSection    cs;
            CStringResourceVector      strings;
            CStringResourceCache() : cs(), strings() {}
        }; // struct CStringResourceCache





        static ENUM_CLI_ERCMANFINDFLAGS      defFindFlags;
        static ::cli::CCriticalSection       builtinsRcCs;
        static CRcVector                     builtinsRc;
        static ::cli::CCriticalSection       pathListCs;
        static ::std::vector< ::std::wstring> userPathList;
        static ::cli::CCriticalSection       stringResourceGlobalCs;
        static ::std::map< ::std::wstring, CStringResourceCache* >  stringResourceGlobal;
        static ::std::wstring                rcLocale;
        static ::std::set< ::std::wstring >  cachedFiles;
        #if defined(_WIN32) || defined(WIN32)
        ::std::map< ::std::wstring, LCID >  localesISO;

        void fillIsoMapForLocale( DWORD lcid, bool noCountry = false)
           {
            ::std::vector< ::std::wstring > langIsoNames;
            ::std::wstring 
            name = hlp::getLocaleInfo(lcid, 0x00000059  /* LOCALE_SISO639LANGNAME */  );
            if (!name.empty()) { ::cli::fmtutil::toLowerCase(name); langIsoNames.push_back(name); }
            name = hlp::getLocaleInfo(lcid, 0x00000067  /* LOCALE_SISO639LANGNAME2 */  );
            if (!name.empty()) { ::cli::fmtutil::toLowerCase(name); langIsoNames.push_back(name); }

            ::std::vector< ::std::wstring > countryIsoNames;
            if (!noCountry)
               {
                name = hlp::getLocaleInfo(lcid, 0x0000005A  /* LOCALE_SISO3166CTRYNAME */  );
                if (!name.empty()) { ::cli::fmtutil::toLowerCase(name); countryIsoNames.push_back(name); }
                name = hlp::getLocaleInfo(lcid, 0x00000068  /* LOCALE_SISO3166CTRYNAME2 */  );
                if (!name.empty()) { ::cli::fmtutil::toLowerCase(name); countryIsoNames.push_back(name); }
               }
            
            ::std::vector< ::std::wstring >::const_iterator langIt = langIsoNames.begin();
            for(; langIt != langIsoNames.end(); ++langIt)
               {
                if (countryIsoNames.empty())
                   {
                    localesISO[*langIt] = lcid;
                   }
                else
                   {
                    ::std::vector< ::std::wstring >::const_iterator ctryIt = countryIsoNames.begin();
                    for(; ctryIt != countryIsoNames.end(); ++ctryIt )
                       {
                        ::std::wstring fullName = *langIt + ::std::wstring(L"-") + *ctryIt;
                        localesISO[fullName] = lcid;
                       }
                   }
               }
           }

        void fillIsoMapForLangOnly( WORD lang, WORD sublang )
           {
            WORD  langId = MAKELANGID(lang,sublang);
            DWORD lcid   = MAKELCID( langId, SORT_DEFAULT );
            fillIsoMapForLocale( lcid, true );
           }
        
        bool isLangIdGeneric(WORD langId)
           {
            if ( langId==0x1000 // Unspecified custom locale language
               ||langId==0x0C00 // Default custom locale language
               ||langId==0x1400 // Default custom MUI locale language
               ||langId==0x007f // Invariant language 0x7f
               ||langId==0x0000 // Neutral locale language
               ||langId==0x0800 // System default locale language
               ||langId==0x0400 // User default locale language 
               //||langId==
               ) return true;
            return false;
           }
        #endif



        CResourceManagerImpl()
           : base_impl(DEF_MODULE)
           //, defFindFlags(0)
           //, builtinsRcCs(1000, false)
           //, builtinsRc()
           //, pathListCs(1000, false)
           //, userPathList()
           //, stringResourceGlobalCs()
           //, stringResourceGlobal()
           //, rcLocale()
           //, cachedFiles()
           #if defined(_WIN32) || defined(WIN32)
           , localesISO()
           #endif
           {
            #if defined(_WIN32) || defined(WIN32)
            // ms-help://MS.MSDNQTR.v90.ru/intl/nls_61df.htm
            for(USHORT usPrimaryLanguage = 0; usPrimaryLanguage!=256; ++usPrimaryLanguage)
               {
                for(USHORT usSubLanguage = 0; usSubLanguage!=256; ++usSubLanguage)
                   {
                    WORD langId = MAKELANGID(usPrimaryLanguage,usSubLanguage);
                    if (isLangIdGeneric(langId)) continue;

                    DWORD lcid = MAKELCID( langId, SORT_DEFAULT );
                    fillIsoMapForLocale( lcid );
                   }

                if (usPrimaryLanguage) fillIsoMapForLangOnly( usPrimaryLanguage , SUBLANG_DEFAULT );
                /*
                WORD langId = MAKELANGID(usPrimaryLanguage,SUBLANG_NEUTRAL);
                if (isLangIdGeneric(langId)) continue;
                DWORD lcid = MAKELCID( langId, SORT_DEFAULT );
                fillIsoMapForLocale( lcid );
                */
               }
            #endif
           }

        ~CResourceManagerImpl()
           {
            //CLI_SCOPED_LOCK(builtinsRcCs)
            /*
            CRcVector::iterator it = builtinsRc.begin();
            for(; it != builtinsRc.end(); ++it)
               {
                it->pStream->release();
               }

            ::std::map< ::std::wstring, CStringResourceCache* >::iterator srIt = stringResourceGlobal.begin();
            for(; srIt != stringResourceGlobal.end(); ++srIt)
               {
                CStringResourceCache *pCache = srIt->second;
                if (pCache) delete pCache;
               }
            */
           }

        ::std::wstring composeStringCacheId( const ::std::wstring &lang, const ::std::wstring &strId )
           {
            return lang + strId;
           }

        CStringResourceCache* getStringCache( const ::std::wstring &stringType )
           {
            CLI_SCOPED_LOCK(stringResourceGlobalCs);
            ::std::map< ::std::wstring, CStringResourceCache* >::const_iterator it = stringResourceGlobal.find(stringType);
            if (it!=stringResourceGlobal.end()) return it->second;

            CStringResourceCache* pNewCache = new CStringResourceCache();
            try{
                stringResourceGlobal[stringType] = pNewCache;
                return pNewCache;
               }
            catch(...) {}
            delete pNewCache;
            return 0;
           }

        CLI_BEGIN_INTERFACE_MAP2(CResourceManagerImpl, INTERFACE_CLI_IRESOURCEMANAGER)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IRESOURCEMANAGER )
        CLI_END_INTERFACE_MAP(CResourceManagerImpl)

        CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
        CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }
        CLIMETHOD_(VOID, destroy) (THIS)
           {
           #include <cli/compspec/delthis.h>
           }

        void fillPathList( ::std::vector< ::std::wstring > &pathList, ENUM_CLI_ERCMANFINDFLAGS flags )
           {
            CLI_SCOPED_LOCK(pathListCs);
            if (flags&CLI_ERCMANFINDFLAGS_RCFINDPREFFERUSERPATHS)
               pathList = userPathList;
            if (!(flags&CLI_ERCMANFINDFLAGS_RCFINDIGNOREBUILTINPATHS))
               {
                pathList.push_back(L"./");
                if (!(flags&CLI_ERCMANFINDFLAGS_RCFINDDISABLERESOURCELOOKUP))
                   {
                    pathList.push_back(L"../rc/");
                    pathList.push_back(L"rc/");
                   }
                if (!(flags&CLI_ERCMANFINDFLAGS_RCFINDDISABLECONFIGLOOKUP))
                   {
                    pathList.push_back(L"../conf/");
                    pathList.push_back(L"conf/");
                   }
               }
            if (!(flags&CLI_ERCMANFINDFLAGS_RCFINDPREFFERUSERPATHS))
               pathList.insert( pathList.end(), userPathList.begin(), userPathList.end() );
           }

        ::std::wstring getRcRootPath()
           {
            ::std::wstring p;
            int getModNameRes = MARTY_LIBAPI_NS getModuleFileName(0, p);
            if (getModNameRes) return L".";
            using MARTY_FILENAME_NS     getPath;
            return getPath(p);
           }

        CLIMETHOD(setResourcesLocale) (THIS_ const CLISTR*     langAndLocale)
           {
            CLI_TRY{
                    CLI_SCOPED_LOCK(stringResourceGlobalCs);
                    rcLocale = stdstr(langAndLocale);
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(setResourcesLocaleStr) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */)
           {
            CLI_TRY{
                    CLI_SCOPED_LOCK(stringResourceGlobalCs);
                    rcLocale = stdstr(langAndLocale);
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(getResourcesLocale) (THIS_ CLISTR*     _langAndLocale)
           {
            CLI_TRY{
                    CLI_SCOPED_LOCK(stringResourceGlobalCs);
                    if (rcLocale.empty())
                       return ::cli::propertyGetImpl( _langAndLocale, getRealLocaleNameImpl(L"user", 0)  );
                    return ::cli::propertyGetImpl( _langAndLocale, rcLocale);
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           
           }

        CLIMETHOD(defRcRootPathGet) (THIS_ CLISTR*           _defRcRootPath)
           {
            CLI_TRY{
                    using MARTY_FILENAME::appendPath;
                    using MARTY_FILENAME_NS makeCanonical;
                    ::std::wstring p = makeCanonical(appendPath(getRcRootPath(), L"/../bin"));
                    if (MARTY_FILESYSTEM::isPathDirectory(p))
                       return ::cli::propertyGetImpl( _defRcRootPath, makeCanonical(appendPath(getRcRootPath(), L"/..")) );
                    return ::cli::propertyGetImpl( _defRcRootPath, makeCanonical(getRcRootPath()) );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        ::std::wstring getRealLocaleNameImpl( ::std::wstring ll, ENUM_CLI_ERCMANFINDFLAGS flags )
           {
            if (ll.empty())
               ll = L"default";
            if (ll == L"default")
               {
                if (flags&CLI_ERCMANFINDFLAGS_RCUSESYSTEMLOCALE)
                   ll = L"system";
                else
                   ll = L"user";
               }
            if (ll == L"user")
               {
                ll = hlp::getDefLocaleName(0);
               }
            else if (ll == L"system")
               {
                ll = hlp::getDefLocaleName(CLI_ERCMANFINDFLAGS_RCUSESYSTEMLOCALE);
               }
            return ll;
           }

        // first lookup requested lang
        // if requested lang is
        //    'system', 'user', 'default' or empty - system/user lang used
        // if requested lang is 'nodefault' - dont lookup for default lang

        void fillLangsList( ::std::vector< ::std::wstring > &langsList
                          , ::std::wstring requestedLang
                          , ENUM_CLI_ERCMANFINDFLAGS flags
                          )
           {
            if (flags&CLI_ERCMANFINDFLAGS_RCFINDDISABLERESOURCELOOKUP) 
               {
                langsList.push_back(::std::wstring()); // default - empty lang path
                return; // don't lookup for lang if config requested
               }

            if (requestedLang.empty())
               {
                CLI_SCOPED_LOCK(stringResourceGlobalCs);
                requestedLang = rcLocale;
               }

            requestedLang = getRealLocaleNameImpl( requestedLang, flags );

            if (requestedLang!=L"nodefault")
               {
                if (!requestedLang.empty())
                   langsList.push_back(requestedLang);
                ::std::wstring::size_type pos = requestedLang.find('_');
                if (pos!=::std::wstring::npos) langsList.push_back(::std::wstring(requestedLang, 0, pos));
               }

            langsList.push_back(::std::wstring(L"en_US"));
            langsList.push_back(::std::wstring(L"en"));
            langsList.push_back(::std::wstring());
            // ???
           }

        std::wstring getDefaultResourcesPath(ENUM_CLI_ERCMANREGISTERFLAGS flags)
           {
            std::wstring strRootPath;
            MARTY_LIBAPI::getModuleFileName((ABSTRACT_MODULE_HANDLE)0, strRootPath);
            strRootPath = MARTY_FILENAME::getPath(strRootPath);
            MARTY_FILENAME::stripSlashInplace(strRootPath);
            std::wstring binName = MARTY_FILENAME::getName(strRootPath);
            if (binName==L"bin" || binName==L"Bin" || binName==L"BIN")
               strRootPath = MARTY_FILENAME::appendPath(strRootPath, L"..");
            if ((flags&CLI_ERCMANREGISTERFLAGS_RCTYPEMASK) == CLI_ERCMANREGISTERFLAGS_RCTYPERESOURCE)
               strRootPath = MARTY_FILENAME::appendPath(strRootPath, L"rc");
            else
               strRootPath = MARTY_FILENAME::appendPath(strRootPath, L"conf");
            return MARTY_FILENAME::makeCanonical(strRootPath);
           }

        CLIMETHOD(exportBuiltinResources) (THIS_ const CLISTR*     rootPath
                                               , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                          )
           {
            CLI_TRY{
                    //if (!rootPath) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"rootPath" );  }
                    std::wstring strRootPath = stdstr(rootPath);
                    if (strRootPath.empty())
                       {
                        //::std::wstring ;
                        /*
                        MARTY_LIBAPI::getModuleFileName((ABSTRACT_MODULE_HANDLE)0, strRootPath);
                        strRootPath = MARTY_FILENAME::getPath(strRootPath);
                        MARTY_FILENAME::stripSlashInplace(strRootPath);
                        std::wstring binName = MARTY_FILENAME::getName(strRootPath);
                        if (binName==L"bin" || binName==L"Bin" || binName==L"BIN")
                           strRootPath = MARTY_FILENAME::appendPath(strRootPath, L"..");
                        if ((flags&CLI_ERCMANREGISTERFLAGS_RCTYPEMASK) == CLI_ERCMANREGISTERFLAGS_RCTYPERESOURCE)
                           strRootPath = MARTY_FILENAME::appendPath(strRootPath, L"rc");
                        else
                           strRootPath = MARTY_FILENAME::appendPath(strRootPath, L"conf");
                        strRootPath = MARTY_FILENAME::makeCanonical(strRootPath);
                        */
                        strRootPath = getDefaultResourcesPath(flags);
                       }
                    return exportBuiltinResourcesImpl( strRootPath, flags );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(exportBuiltinResourcesChars) (THIS_ const WCHAR*    rootPath /* [in,flat] wchar  rootPath[]  */
                                               , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                          )
           {
            CLI_TRY{
                    //if (!rootPath) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"rootPath" );  }
                    std::wstring strRootPath = stdstr(rootPath);
                    if (strRootPath.empty())
                       {
                        //::std::wstring ;
                        /*
                        MARTY_LIBAPI::getModuleFileName((ABSTRACT_MODULE_HANDLE)0, strRootPath);
                        strRootPath = MARTY_FILENAME::getPath(strRootPath);
                        MARTY_FILENAME::stripSlashInplace(strRootPath);
                        std::wstring binName = MARTY_FILENAME::getName(strRootPath);
                        if ((flags&CLI_ERCMANREGISTERFLAGS_RCTYPEMASK) == CLI_ERCMANREGISTERFLAGS_RCTYPERESOURCE)
                           strRootPath = MARTY_FILENAME::appendPath(strRootPath, L"rc");
                        else
                           strRootPath = MARTY_FILENAME::appendPath(strRootPath, L"conf");
                        strRootPath = MARTY_FILENAME::makeCanonical(strRootPath);
                        */
                        strRootPath = getDefaultResourcesPath(flags);
                       }
                    return exportBuiltinResourcesImpl( strRootPath, flags );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(getDefaultResourcesPath) (THIS_ CLISTR*           defPath
                                                , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                           )
           {
            CLIMETHOD_IMPL_BEGIN();
            CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, defPath );

            //std::wstring strRootPath = getDefaultResourcesPath(flags);
            return ::cli::propertyGetImpl(defPath, getDefaultResourcesPath(flags) );

            CLIMETHOD_IMPL_END();
           }

        CLIMETHOD(getDefaultResourcesPathChars) (THIS_ WCHAR*    defPathBuf /* [out,flat,optional] wchar defPathBuf[]  */
                                                     , SIZE_T*    defPathBufSize /* [in,out] size_t defPathBufSize  */
                                                     , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                                )
           {
            CLIMETHOD_IMPL_BEGIN();
            CLIMETHOD_IMPL_CHECK_PARAM_PTR(2, defPathBufSize);

            std::wstring strRootPath = getDefaultResourcesPath(flags);

            if (!defPathBuf)
               {
                *defPathBufSize = strRootPath.size()+1;
               }
            else
               {
                SIZE_T numCharsToCopy = *defPathBufSize - 1;
                if (numCharsToCopy>strRootPath.size()) numCharsToCopy = strRootPath.size();
                strRootPath.copy( defPathBuf, numCharsToCopy );
                defPathBuf[numCharsToCopy] = 0;
               }

            CLIMETHOD_IMPL_END();
           }


        //#define RC_DEFAULT_FILENAME L"_._"
        #define RC_DEFAULT_FILENAME L"(default)"
        #define RC_DEFAULT_LANGNAME L"(default)"


        CLIMETHOD(exportBuiltinResourcesImpl) (THIS_ const ::std::wstring &rootPath /* [in,flat] wchar  rootPath[]  */, ENUM_CLI_ERCMANREGISTERFLAGS    flags)
           {
            ::cli::io::CiIOFactory iof( "/cli/io-factory" );
            char buf[16384];
            SIZE_T readed, written;

            MARTY_FILESYSTEM::forceCreateDirectory( rootPath );

            CLI_SCOPED_LOCK(builtinsRcCs);

            CRcVector::const_iterator rcIt = builtinsRc.begin();
            for(; rcIt!=builtinsRc.end(); ++rcIt)
               {
                using MARTY_FILENAME::appendPath;
                using MARTY_FILENAME::getPath;
                ::std::wstring resultFileName;
                if ((flags&CLI_ERCMANREGISTERFLAGS_RCTYPEANY) != CLI_ERCMANREGISTERFLAGS_RCTYPEANY
                  &&(flags&CLI_ERCMANREGISTERFLAGS_RCTYPEANY)!=rcIt->rcType
                   ) continue;

                if (rcIt->lang.empty()) resultFileName = rootPath;
                else                    resultFileName = appendPath( rootPath, rcIt->lang );

                if (rcIt->name.empty()) resultFileName = appendPath( resultFileName, RC_DEFAULT_FILENAME);
                else                    resultFileName = appendPath( resultFileName, rcIt->name);

                MARTY_FILESYSTEM::forceCreateDirectory( getPath(resultFileName) );

                ::std::wstring resultStreamName;
                if (iof.mergeName(resultStreamName, L"file", L"", L"", resultFileName, L"mode=w"))
                   continue;

                ::cli::io::CiIOStream iosOut;
                if (iof.createStream(resultStreamName, iosOut.getPP(), 0)) continue;
                if (!iosOut) continue;

                ::cli::io::CiIOStream rcIos(rcIt->pStream);
                ::cli::CiShareCloneable shareCloneableOrg;
                if ( rcIos.queryInterface(shareCloneableOrg /* .getPP() */ ) || !shareCloneableOrg) continue;

                ::cli::CiShareCloneable shareCloneableClone;
                if (shareCloneableOrg.shareCloneObject(shareCloneableClone.getPP()) || !shareCloneableClone) continue;

                ::cli::io::CiIOStream rcIosClone;
                if (shareCloneableClone.queryInterface(rcIosClone) || !rcIosClone ) continue;

                while( !rcIosClone.read((VOID*)buf, sizeof(buf), &readed) && readed>0 )
                   {
                    iosOut.write((VOID*)buf, readed, &written);
                   }
               }
            return EC_OK;
           }

        CLIMETHOD(logEnumBuiltinResources) (THIS)
           {
            CLI_SCOPED_LOCK(builtinsRcCs);
            CLI_TRY{
                    ::cli::format::cli_log::message( L"-------" );
                    ::cli::format::cli_log::message( L"List of registered resources" );
                    ::cli::format::cli_log::message( L"-------" );
                    CRcVector::const_iterator rcIt = builtinsRc.begin();
                    for(; rcIt!=builtinsRc.end(); ++rcIt)
                       {
                        ::std::wstring        rcName = rcIt->name;
                        if (rcName.empty())   rcName = RC_DEFAULT_FILENAME;
                        ::std::wstring        langName = rcIt->lang;
                        if (langName.empty()) langName = RC_DEFAULT_LANGNAME;
                        ::cli::format::cli_log::message( L"%1 / %2", ::cli::format::arg(rcName) % langName );
                       }
                    ::cli::format::cli_log::message( L"-------" );
                    ::cli::format::cli_log::message( L"End of list of registered resources" );
                    ::cli::format::cli_log::message( L"-------" );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(searchPathsGet) (THIS_ CLISTR*           _searchPaths
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  )
           {
            CLI_TRY{
                    if (!_searchPaths) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"searchPaths" );  }
                    CLI_SCOPED_LOCK(pathListCs);

                    if (idx1>=userPathList.size())
                       { throw ::cli::CException( false, EC_OUT_OF_RANGE, __FILE__, __LINE__ );  }
                    return ::cli::propertyGetImpl( _searchPaths, userPathList[idx1] );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(searchPathsSet) (THIS_ const CLISTR*     _searchPaths
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  )
           {
            CLI_TRY{
                    if (idx1>=userPathList.size()) userPathList.push_back( stdstr(_searchPaths) );
                    else                           userPathList[idx1] = stdstr(_searchPaths);
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(searchPathsSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
           {
            CLI_TRY{
                    if (_size) *_size = userPathList.size();
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(clearSearchPaths) (THIS)
           {
            CLI_TRY{
                    userPathList.clear();
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(addSearchPath) (THIS_ const CLISTR*     p)
           {
            CLI_TRY{
                    userPathList.push_back( stdstr(p) );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(addSearchPathChars) (THIS_ const WCHAR*    p /* [in,flat] wchar  p[]  */)
           {
            CLI_TRY{
                    userPathList.push_back( stdstr(p) );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(defFindFlagsGet) (THIS_ ENUM_CLI_ERCMANFINDFLAGS*    _defFindFlags /* [out] ::cli::ERcManFindFlags _defFindFlags  */)
           {
            if (_defFindFlags) *_defFindFlags = defFindFlags;
            return EC_OK;
           }

        CLIMETHOD(defFindFlagsSet) (THIS_ ENUM_CLI_ERCMANFINDFLAGS    _defFindFlags /* [in] ::cli::ERcManFindFlags  _defFindFlags  */)
           {
            defFindFlags = _defFindFlags;
            return EC_OK;
           }

        CLIMETHOD(findResourceFilesToList) (THIS_ const CLISTR*     langAndLocale
                                                , const CLISTR*     fileName
                                                , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                                , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                           )
           {
            CLI_TRY{
                    if (!fileName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"fileName" );  }
                    if (!pStreamList) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 3) % L"pStreamList" );  }
                    return findResourceFilesToListImpl( stdstr(langAndLocale), stdstr(fileName), pStreamList, flags );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(findResourceFilesToListChars) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                                     , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                                     , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                                     , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                                )
           {
            CLI_TRY{
                    if (!fileName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"fileName" );  }
                    if (!pStreamList) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 3) % L"pStreamList" );  }
                    return findResourceFilesToListImpl( stdstr(langAndLocale), stdstr(fileName), pStreamList, flags );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(findResourceFiles) (THIS_ const CLISTR*     langAndLocale
                                          , const CLISTR*     fileName
                                          , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                          , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                     )
           {
            CLI_TRY{
                    if (!fileName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"fileName" );  }
                    if (!pStreamList) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 3) % L"pStreamList" );  }
                    *pStreamList = static_cast< INTERFACE_CLI_IOBJECTLIST* >( new ::cli::impl::CObjListImpl() );
                    return findResourceFilesToListImpl( stdstr(langAndLocale), stdstr(fileName), *pStreamList, flags );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(findResourceFilesChars) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                               , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                               , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                               , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                          )
           {
            CLI_TRY{
                    if (!fileName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"fileName" );  }
                    if (!pStreamList) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 3) % L"pStreamList" );  }
                    *pStreamList = static_cast< INTERFACE_CLI_IOBJECTLIST* >( new ::cli::impl::CObjListImpl() );
                    return findResourceFilesToListImpl( stdstr(langAndLocale), stdstr(fileName), *pStreamList, flags );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(findResourceFilesToListImpl) (THIS_ const ::std::wstring &langAndLocale
                                                , const ::std::wstring &fileName
                                                , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                                , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                           )
           {
            if (!(flags&CLI_ERCMANFINDFLAGS_RCIGNOREDEFFLAGS)) flags = defFindFlags;
            ::std::vector< ::std::wstring > langsList, pathList;
            fillLangsList( langsList, langAndLocale, flags );
            fillPathList( pathList, flags );

            SIZE_T streamListOrgSize = 0;
            pStreamList->getObjectCount( &streamListOrgSize );

            ::std::wstring rootPath = getRcRootPath();

            ::cli::io::CiIOFactory iof( "/cli/io-factory" );

            ::std::vector< ::std::wstring >::const_iterator pit = pathList.begin();
            for(; pit != pathList.end(); ++pit)
               {
                using MARTY_FILENAME_NS appendPath;
                using MARTY_FILENAME_NS makeFullPath;
                using MARTY_FILENAME_NS makeCanonical;
                ::std::wstring curPath = makeFullPath(makeCanonical(rootPath), makeCanonical(*pit));

                ::std::vector< ::std::wstring >::const_iterator lit = langsList.begin();
                for(; lit != langsList.end(); ++lit)
                   {
                    ::std::wstring curLangPath;
                    if (lit->empty())
                       curLangPath = curPath;
                    else
                       curLangPath = appendPath( curPath, *lit );

                    ::std::wstring resultStreamName;
                    if (iof.mergeName(resultStreamName, L"file", L"", L"", appendPath( curLangPath, fileName ) , L"mode=r"))
                       continue;

                    //INTERFACE_CLI_IO_IIOSTREAM *pIios;
                    ::cli::io::CiIOStream ios;
                    if (iof.createStream(resultStreamName, ios.getPP(), 0)) continue;
                    if (!ios) continue;

                    ::cli::io::impl::CIOTaggedStreamImpl *pTagged = 
                                     new ::cli::io::impl::CIOTaggedStreamImpl();

                       {
                        //INTERFACE_CLI_IO_IOSTREAM *pNewIos = static_cast< INTERFACE_CLI_IO_IOSTREAM* >(pTagged); // don work. why?
                        ::cli::io::CiIOStream_tmp rcIosNew( pTagged /* pNewIos */ ); // aumatic cast 
                        ::std::wstring streamName = ios.streamName;
                        rcIosNew.streamName = streamName;
                       }


                    INTERFACE_CLI_IUNKNOWN *pUnk = static_cast<INTERFACE_CLI_IUNKNOWN*>(static_cast<INTERFACE_CLI_ISTRINGTAG*>(pTagged));
                    ::cli::CiStringTag          tmpTagged( static_cast<INTERFACE_CLI_ISTRINGTAG*>(pTagged) );
                    //::cli::io::CiIOStream       tmpIos   ( static_cast<INTERFACE_CLI_IO_IIOSTREAM*>(pTagged) );
                    ::cli::io::CiIOStreamHolder tmpHolder( static_cast<INTERFACE_CLI_IO_IIOSTREAMHOLDER*>(pTagged) );
                    pTagged->release();

                    tmpHolder.streamPtr = ios.getIfPtr();
                    tmpTagged.tagValue  = *lit;

                    pStreamList->pushObject(pUnk);
                   }
               }

            SIZE_T streamListResSize = 0;
            pStreamList->getObjectCount( &streamListResSize );

            if (streamListOrgSize==streamListResSize)
               {
                ::cli::format::cli_log::message( L"File '%1' not found in resource paths at all.", ::cli::format::arg(fileName) );
               }

            return EC_OK;
           }


        CLIMETHOD(findBuiltinResourcesToList) (THIS_ const CLISTR*     langAndLocale
                                                   , const CLISTR*     fileName
                                                   , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                                   , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                              )
           {
            CLI_TRY{
                    if (!fileName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"fileName" );  }
                    if (!pStreamList) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 3) % L"pStreamList" );  }
                    return findBuiltinResourcesToListImpl( stdstr(langAndLocale), stdstr(fileName), pStreamList, flags );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(findBuiltinResourcesToListChars) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                                        , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                                        , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                                        , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                                   )
           {
            CLI_TRY{
                    if (!fileName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"fileName" );  }
                    if (!pStreamList) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 3) % L"pStreamList" );  }
                    return findBuiltinResourcesToListImpl( stdstr(langAndLocale), stdstr(fileName), pStreamList, flags );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(findBuiltinResources) (THIS_ const CLISTR*     langAndLocale
                                             , const CLISTR*     fileName
                                             , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                             , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                        )
           {
            CLI_TRY{
                    if (!fileName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"fileName" );  }
                    if (!pStreamList) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 3) % L"pStreamList" );  }
                    *pStreamList = static_cast< INTERFACE_CLI_IOBJECTLIST* >( new ::cli::impl::CObjListImpl() );
                    return findBuiltinResourcesToListImpl( stdstr(langAndLocale), stdstr(fileName), *pStreamList, flags );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(findBuiltinResourcesChars) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                                  , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                                  , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                                  , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                             )
           {
            CLI_TRY{
                    if (!fileName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"fileName" );  }
                    if (!pStreamList) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 3) % L"pStreamList" );  }
                    *pStreamList = static_cast< INTERFACE_CLI_IOBJECTLIST* >( new ::cli::impl::CObjListImpl() );
                    return findBuiltinResourcesToListImpl( stdstr(langAndLocale), stdstr(fileName), *pStreamList, flags );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(findBuiltinResourcesToListImpl) (THIS_ const ::std::wstring &langAndLocale
                                                   , const     ::std::wstring &fileName
                                                   , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                                   , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                              )
           {
            if (!(flags&CLI_ERCMANFINDFLAGS_RCIGNOREDEFFLAGS)) flags = defFindFlags;
            ::std::vector< ::std::wstring > langsList;
            fillLangsList( langsList, langAndLocale, flags );

            SIZE_T streamListOrgSize = 0;
            pStreamList->getObjectCount( &streamListOrgSize );

            CLI_SCOPED_LOCK(builtinsRcCs);

            ::std::pair< CRcVector::const_iterator, CRcVector::const_iterator > 
                   nameRange = std::equal_range( builtinsRc.begin()
                                               , builtinsRc.end()
                                               , CBuiltinRc( fileName, langAndLocale )
                                               , CBuiltinNameLess()
                                               );
            if (nameRange.first!=nameRange.second /*  && nameRange.first==builtinsRc.end() */ )
               {
                ::std::vector< ::std::wstring >::const_iterator lit = langsList.begin();
                for(; lit != langsList.end(); ++lit)
                   {
                    ::std::pair< CRcVector::const_iterator, CRcVector::const_iterator > 
                               langRange = std::equal_range( nameRange.first // builtinsRc.begin()
                                                           , nameRange.second // builtinsRc.end()
                                                           , CBuiltinRc( fileName, *lit )
                                                           , CBuiltinLangLess()
                                                           );
                    if (langRange.first==langRange.second /*  && langRange.first==nameRange.second */ )
                       continue;

                    ::cli::io::CiIOStream rcIos(langRange.first->pStream);

                    ::cli::CiShareCloneable shareCloneableOrg;
                    if ( rcIos.queryInterface(shareCloneableOrg /* .getPP() */ ) || !shareCloneableOrg) continue;
    
                    ::cli::CiShareCloneable shareCloneableClone;
                    if (shareCloneableOrg.shareCloneObject(shareCloneableClone.getPP()) || !shareCloneableClone) continue;
    
                    ::cli::io::CiIOStream rcIosClone;
                    if (shareCloneableClone.queryInterface(rcIosClone) || !rcIosClone ) continue;
    
                    ::cli::io::impl::CIOTaggedStreamImpl *pTagged = 
                                     new ::cli::io::impl::CIOTaggedStreamImpl();


                       {
                        //INTERFACE_CLI_IO_IOSTREAM *pNewIos = static_cast< INTERFACE_CLI_IO_IOSTREAM* >(pTagged); // don work. why?
                        ::cli::io::CiIOStream_tmp rcIosNew( pTagged /* pNewIos */ ); // aumatic cast 
                        ::std::wstring streamName = rcIos.streamName;
                        rcIosNew.streamName = streamName;
                       }

                    INTERFACE_CLI_IUNKNOWN *pUnk = static_cast< INTERFACE_CLI_IUNKNOWN* >(static_cast< INTERFACE_CLI_ISTRINGTAG* >(pTagged));
                    ::cli::CiStringTag          tmpTagged( static_cast< INTERFACE_CLI_ISTRINGTAG* >(pTagged) );
                    //::cli::io::CiIOStream       tmpIos   ( static_cast<INTERFACE_CLI_IO_IIOSTREAM*>(pTagged) );
                    ::cli::io::CiIOStreamHolder tmpHolder( static_cast< INTERFACE_CLI_IO_IIOSTREAMHOLDER* >(pTagged) );
                    pTagged->release();
    
                    tmpHolder.streamPtr = rcIosClone.getIfPtr();
                    tmpTagged.tagValue  = *lit;
    
                    pStreamList->pushObject(pUnk);
                   }
               }

            SIZE_T streamListResSize = 0;
            pStreamList->getObjectCount( &streamListResSize );

            if (streamListOrgSize==streamListResSize)
               {
                ::cli::format::cli_log::message( L"File '%1' not found in builtin resources at all.", ::cli::format::arg(fileName) );
               }

            return 0;
           }


        CLIMETHOD(findResourcesToList) (THIS_ const CLISTR*     langAndLocale
                                            , const CLISTR*     fileName
                                            , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                            , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                       )
           {
            CLI_TRY{
                    if (!fileName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"fileName" );  }
                    if (!pStreamList) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 3) % L"pStreamList" );  }
                    return findResourcesToListImpl( stdstr(langAndLocale), stdstr(fileName), pStreamList, flags );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(findResourcesToListChars) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                                 , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                                 , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                                 , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                            )
           {
            CLI_TRY{
                    if (!fileName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"fileName" );  }
                    if (!pStreamList) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 3) % L"pStreamList" );  }
                    return findResourcesToListImpl( stdstr(langAndLocale), stdstr(fileName), pStreamList, flags );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(findResources) (THIS_ const CLISTR*     langAndLocale
                                      , const CLISTR*     fileName
                                      , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                      , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                 )
           {
            CLI_TRY{
                    if (!fileName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"fileName" );  }
                    if (!pStreamList) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 3) % L"pStreamList" );  }
                    *pStreamList = static_cast< INTERFACE_CLI_IOBJECTLIST* >( new ::cli::impl::CObjListImpl() );
                    return findResourcesToListImpl( stdstr(langAndLocale), stdstr(fileName), *pStreamList, flags );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(findResourcesChars) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                           , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                           , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                           , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                          )
           {
            CLI_TRY{
                    if (!fileName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"fileName" );  }
                    if (!pStreamList) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 3) % L"pStreamList" );  }
                    *pStreamList = static_cast< INTERFACE_CLI_IOBJECTLIST* >( new ::cli::impl::CObjListImpl() );
                    return findResourcesToListImpl( stdstr(langAndLocale), stdstr(fileName), *pStreamList, flags );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(findResourcesToListImpl) (THIS_ const ::std::wstring &langAndLocale
                                            , const ::std::wstring &fileName
                                            , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                            , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                       )
           {
            if (!(flags&CLI_ERCMANFINDFLAGS_RCIGNOREDEFFLAGS)) flags = defFindFlags;

            RCODE res = 0;
            if (flags&CLI_ERCMANFINDFLAGS_RCFINDPREFFERBUILTIN)
               {
                if (!(flags&CLI_ERCMANFINDFLAGS_RCFINDIGNOREBUILTIN))
                   res = findBuiltinResourcesToListImpl( langAndLocale, fileName, pStreamList, flags );
                if (res) return res;

                res = 0;
                if (!(flags&CLI_ERCMANFINDFLAGS_RCFINDIGNOREFILES))
                   res = findResourceFilesToListImpl   ( langAndLocale, fileName, pStreamList, flags );
               }
            else
               {
                if (!(flags&CLI_ERCMANFINDFLAGS_RCFINDIGNOREFILES))
                   res = findResourceFilesToListImpl   ( langAndLocale, fileName, pStreamList, flags );
                if (res) return res;

                res = 0;
                if (!(flags&CLI_ERCMANFINDFLAGS_RCFINDIGNOREBUILTIN))
                   res = findBuiltinResourcesToListImpl( langAndLocale, fileName, pStreamList, flags );
               }
            return res;
           }

        CLIMETHOD(registerResource) (THIS_ const CLISTR*     langAndLocale
                                         , const CLISTR*     fileName
                                         , const BYTE*    pRcData /* [in] byte*  pRcData  */
                                         , SIZE_T    rcLen /* [in] size_t  rcLen  */
                                         , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                    )
           {
            CLI_TRY{
                    if (!fileName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"fileName" );  }
                    if (!pRcData)  { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 3) % L"pRcData" );  }
                    return registerResourceImpl( stdstr(langAndLocale), stdstr(fileName), pRcData, rcLen, flags );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(registerResourceChars) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                              , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                              , const BYTE*    pRcData /* [in] byte*  pRcData  */
                                              , SIZE_T    rcLen /* [in] size_t  rcLen  */
                                              , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                         )
           {
            CLI_TRY{
                    if (!fileName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"fileName" );  }
                    if (!pRcData)  { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 3) % L"pRcData" );  }
                    return registerResourceImpl( stdstr(langAndLocale), stdstr(fileName), pRcData, rcLen, flags );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(registerResourceImpl) (THIS_ const ::std::wstring &langAndLocale
                                         , const ::std::wstring &fileName
                                         , const BYTE*    pRcData /* [in] byte*  pRcData  */
                                         , SIZE_T    rcLen /* [in] size_t  rcLen  */
                                         , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                    )
           {
            CLI_SCOPED_LOCK(builtinsRcCs);

            ::std::pair< CRcVector::const_iterator, CRcVector::const_iterator > 
                   nameRange = std::equal_range( builtinsRc.begin()
                                               , builtinsRc.end()
                                               , CBuiltinRc( fileName, langAndLocale )
                                               , CBuiltinNameLangLess()
                                               );
            if (nameRange.first!=nameRange.second /*  || nameRange.first!=builtinsRc.end() */ )
               return EC_ERR_ALLREADY;

            ::cli::io::CiIOStream ios(    flags&CLI_ERCMANREGISTERFLAGS_RCREGCOPY
                                        ? static_cast<INTERFACE_CLI_IO_IIOSTREAM*>( new ::cli::io::CStringIOStream( (const char*)pRcData, rcLen ) )
                                        : static_cast<INTERFACE_CLI_IO_IIOSTREAM*>( new ::cli::io::CMemoryIOStream( (BYTE*)      pRcData, rcLen ) )
                                      , true /* doNotAddRef */
                                     );

            ::std::wstring streamNameFull = fileName;
            if (!langAndLocale.empty())
               streamNameFull = langAndLocale + ::std::wstring(L"/") + fileName;
            ios.streamName = streamNameFull;

            builtinsRc.push_back( CBuiltinRc( fileName, langAndLocale, ios.getIfPtr(), flags&CLI_ERCMANREGISTERFLAGS_RCTYPEANY ) );
            ios.getIfPtr()->addRef();
            return EC_OK;
           }

        CLIMETHOD(unregisterResource) (THIS_ const CLISTR*     langAndLocale
                                           , const CLISTR*     fileName
                                      )
           {
            CLI_TRY{
                    if (!fileName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"fileName" );  }
                    return unregisterResourceImpl( stdstr(langAndLocale), stdstr(fileName) );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(unregisterResourceChars) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                                , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                           )
           {
            CLI_TRY{
                    if (!fileName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"fileName" );  }
                    return unregisterResourceImpl( stdstr(langAndLocale), stdstr(fileName) );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(unregisterResourceImpl) (THIS_ const ::std::wstring &langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                                , const ::std::wstring &fileName /* [in,flat] wchar  fileName[]  */
                                           )
           {
            CLI_SCOPED_LOCK(builtinsRcCs);
            ::std::pair< CRcVector::iterator, CRcVector::iterator > 
                   nameRange = std::equal_range( builtinsRc.begin()
                                               , builtinsRc.end()
                                               , CBuiltinRc( fileName, langAndLocale )
                                               , CBuiltinNameLangLess()
                                               );
            if (nameRange.first==nameRange.second /*  || nameRange.first!=builtinsRc.end() */ )
               return 0;

            builtinsRc.erase( nameRange.first, nameRange.second );
            return EC_OK;
           }

        CLIMETHOD(getCurrentLocaleName) (THIS_ CLISTR*           langAndLocale
                                      , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                 )
           {
            CLI_TRY{
                    if (!langAndLocale) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"langAndLocale" );  }
                    if (!(flags&CLI_ERCMANFINDFLAGS_RCIGNOREDEFFLAGS)) flags = defFindFlags;
                    return ::cli::propertyGetImpl( langAndLocale, hlp::getDefLocaleName(flags) );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(getRealLocaleName) (THIS_ const CLISTR*     langAndLocaleOrAlias
                                          , CLISTR*           langAndLocale
                                          , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                     )
           {
            CLI_TRY{
                    if (!langAndLocaleOrAlias) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"langAndLocaleOrAlias" );  }
                    if (!(flags&CLI_ERCMANFINDFLAGS_RCIGNOREDEFFLAGS)) flags = defFindFlags;
                    return ::cli::propertyGetImpl( langAndLocale, getRealLocaleNameImpl(stdstr(langAndLocaleOrAlias),flags) );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(getLocaleSearchOrderList) (THIS_ const CLISTR*     langAndLocaleOrAlias
                                                 , INTERFACE_CLI_IARGLIST*    pLocalesList /* [in] ::cli::iArgList*  pLocalesList  */
                                                 , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                            )
           {
            CLI_TRY{
                    if (!pLocalesList) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"pLocalesList" );  }
                    if (!(flags&CLI_ERCMANFINDFLAGS_RCIGNOREDEFFLAGS)) flags = defFindFlags;

                    ::std::vector< ::std::wstring > langsList;
                    fillLangsList( langsList, stdstr(langAndLocaleOrAlias), flags );
                    ::std::vector< ::std::wstring >::const_iterator lit = langsList.begin();

                    //::cli::CiArgList_tmp llTmp(pLocalesList);

                    for(; lit != langsList.end(); ++lit)
                       {
                        pLocalesList->putStringChars( lit->data(), lit->size() );
                       }
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(clearAllStringCache) (THIS)
           {
            CLI_TRY{
                    CLI_SCOPED_LOCK(stringResourceGlobalCs);
                    ::std::map< ::std::wstring, CStringResourceCache* >::const_iterator it = stringResourceGlobal.begin();
                    for(; it != stringResourceGlobal.end(); ++it)
                       {
                        CStringResourceCache* p = it->second;
                        if (p) p->strings.clear();
                       }
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(clearStringCache) (THIS_ const CLISTR*     strTypeString)
           {
            CLI_TRY{
                    CStringResourceCache* pCache = getStringCache(stdstr(strTypeString));
                    if (!pCache) return EC_OK;
        
                    CLI_SCOPED_LOCK(pCache->cs);
                    pCache->strings.clear();
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        void addStringMapEntry( ::std::map< ::std::wstring, ::std::wstring > &stringMap
                              , const ::std::wstring &langStrId
                              , const ::std::wstring &str
                              )
           {
            ::std::map< ::std::wstring, ::std::wstring >::iterator it = stringMap.find( langStrId );
            if (it!=stringMap.end())
               {
                if (it->second!=str) it->second = str; // update value
               }
            else
               {
                stringMap.insert( ::std::make_pair(langStrId,str) );
               }
           }

        //::std::map< ::std::wstring, ::std::wstring > tempStringMap;


        CLIMETHOD(findGenericStringImpl) (THIS_       ::std::wstring      &_foundStr
                                              , const ::std::wstring      &_strId
                                              , const ::std::wstring      &_langAndLocale
                                              , ENUM_CLI_ERCMANFINDFLAGS   flags /* [in] ::cli::ERcManFindFlags  flags  */
                                              ,       ::std::wstring       moduleName
                                              , const ::std::wstring      &strTypeString
                                       )
           {
            CStringResourceCache* pCache = getStringCache(strTypeString);
            if (!pCache) return EC_RESOURCE_NOT_FOUND;
            if (!(flags&CLI_ERCMANFINDFLAGS_RCIGNOREDEFFLAGS)) 
               {
                flags = defFindFlags | (flags&(CLI_ERCMANFINDFLAGS_RCFINDSTRINGFROMMODULE|CLI_ERCMANFINDFLAGS_RCFINDSTRINGFROMAPP));
               }

            if (!moduleName.empty()) moduleName = MARTY_FILENAME::getName(moduleName);

            ::std::vector< ::std::wstring > langsList;
            fillLangsList( langsList, _langAndLocale, flags );

            //::std::wstring strId = composeStringCacheId( _langAndLocale, _strId );
            // try to find message in cache
               {
                CLI_SCOPED_LOCK(pCache->cs);
                ::std::vector< ::std::wstring >::const_iterator lit = langsList.begin();
                for(; lit != langsList.end(); ++lit)
                   {
                    CStringResourceVector::const_iterator it = pCache->strings.find( CStringResourceEntry(composeStringCacheId( *lit, _strId )) );
                    if (it!=pCache->strings.end())
                       {
                        _foundStr = it->value;
                        return EC_OK;
                       }
                   }
               }
            // oops. we need to find string in resource files


            // generate file name for lookup
            //::std::wstring moduleName;
            if (!(flags&CLI_ERCMANFINDFLAGS_RCFINDSTRINGFROMMODULE))
               {
                moduleName.clear();
               }

            if (moduleName.empty())
               { // we get the app file name as module name
                ::std::wstring appExeName;
                MARTY_LIBAPI_NS getModuleFileName( 0, appExeName );
                using MARTY_FILENAME_NS getName;
                moduleName = getName(appExeName);
               }

            if (moduleName.empty())
               {
                moduleName = L"cli2";
               }

            ::std::wstring requestedFileName = MARTY_FILENAME::appendExtention(moduleName, strTypeString);

/*
            // Ok, here we have the file name
            // Check that file is allready cached
               {
                CLI_SCOPED_LOCK(stringResourceGlobalCs);
                if (cachedFiles.find(requestedFileName)!=cachedFiles.end())
                   { // already cached, but no string found
                    return EC_RESOURCE_NOT_FOUND;
                   }
                // not found in cache, insert for prevent next parsing
                cachedFiles.insert(requestedFileName);
               }
*/

            ::cli::CiObjectList foundRcFilesList( static_cast< INTERFACE_CLI_IOBJECTLIST* >( new ::cli::impl::CObjListImpl() )
                                                , true /* doNotAddRef */
                                                );
            findResourcesToListImpl( _langAndLocale, requestedFileName, foundRcFilesList.getIfPtr(), flags );

            ::std::map< ::std::wstring, ::std::wstring > tempStringMap;

            char rdbuf[4096];
            ::std::wstring tmpStrFound;
            bool foundInFiles = false;


            CLI_SCOPED_LOCK(pCache->cs);

            // copy prev cached strings to map
              {
               CStringResourceVector::const_iterator sit = pCache->strings.begin();
               for(; sit != pCache->strings.end(); ++sit)
                  {
                   addStringMapEntry( tempStringMap, sit->key, sit->value );
                  }
              }

            SIZE_T initialTempStringMapSize = (SIZE_T)tempStringMap.size();
            //bool newStringsAdded = false;

            SIZE_T totalFound = foundRcFilesList.objectCount;
            for(SIZE_T streamNo = 0; !foundInFiles && streamNo!=totalFound; ++streamNo)
               {
                ::cli::CiUnknown unk;
                foundRcFilesList.getObject(streamNo, unk.getPP());

                ::std::wstring curLang;
                try{
                    ::cli::CiStringTag tag;
                    if (!unk.queryInterface(tag.getPP()))
                       {
                        curLang = tag.tagValue;
                       }
                   }
                catch(...) {}

                try{
                    ::cli::io::CiIOStream ios;
                    if (!unk.queryInterface(ios.getPP()))
                       {
                        // parse file here
                        ::std::wstring streamName = ios.streamName;
                        bool foundInCachedFiles = false;
                          {
                           CLI_SCOPED_LOCK(stringResourceGlobalCs);
                           foundInCachedFiles = cachedFiles.find(streamName)!=cachedFiles.end();
                          }

                        if (foundInCachedFiles)
                           { // do nothing
                           
                           }
                        else
                           {
                              {
                               CLI_SCOPED_LOCK(stringResourceGlobalCs);
                               cachedFiles.insert(streamName);
                              }

                            // Old parsing code, need refactoring
                            ::std::wstring fileText; // converted from UTF8 
                            MARTY_UTF_NS CCharsCollector<wchar_t> collector(fileText);
                            MARTY_UTF_NS CUtfToWcharDecoder<MARTY_UTF_NS CCharsCollector<wchar_t> > decoder(collector); // use auto detect feature - default parameter 2 value
    
                            SIZE_T readed;
                            while(!ios.read((VOID*)rdbuf, sizeof(rdbuf), &readed) && readed)
                               {
                                decoder(rdbuf, readed);
                               }
    
                            std::vector< ::std::wstring > lines;
                            ::marty::util::split(lines, fileText, ::marty::util::CIsExactChar<'\n'>(), ::marty::util::token_compress_on);
    
    
                            std::vector< ::std::wstring >::const_iterator lineIt = lines.begin();
                            for(; lineIt!=lines.end(); ++lineIt)
                               {
                                ::std::wstring line = ::marty::util::trim_copy( *lineIt, ::marty::util::CIsSpace<wchar_t>());
                                if (line.empty()) continue;
                    
                                ::std::wstring::size_type spacePos = lineIt->find(' ');
                                if (spacePos == ::std::wstring::npos) continue; // space separator not found
                    
                                ::std::wstring key(*lineIt, 0, spacePos);
                                if (key.empty())  continue;
                                if (key[0]==L'#') continue;
                                if (key.size()>1 && key[0]==L'\"' && key[key.size()-1]==L'\"')
                                   {
                                    key.erase(key.size()-1); // remove trailing quot
                                    key.erase(0, 1);         // remove leading quot
                                   }
                    
                                ::std::wstring val = ::marty::util::trim_copy( ::std::wstring(*lineIt, spacePos, ::std::wstring::npos ), ::marty::util::CIsSpace<wchar_t>());
                                if (val.size()>1 && val[0]==L'\"' && val[val.size()-1]==L'\"')
                                   {
                                    val.erase(val.size()-1); // remove trailing quot
                                    val.erase(0, 1);         // remove leading quot
                                   }
                                val = ::marty::util::parseBasicEscapesC( val );
    
                                if (key==_strId)
                                   {
                                    tmpStrFound = val;
                                    foundInFiles = true;
                                   }
                                // !!!
                                addStringMapEntry( tempStringMap, composeStringCacheId(curLang,key), val );
                                //newStringsAdded = true;
                                // pCache->strings.unsorted_push_back( CStringResourceEntry(composeStringCacheId(curLang,key)
                                //                                                         , val
                                //                                                         )
                                //                                   );
                                // !!!
                               }

                           } // if (foundInCachedFiles) else

                       } // if (!unk.queryInterface(ios.getPP()))
                   }
                catch(...) {}
               }

            SIZE_T newTempStringMapSize = (SIZE_T)tempStringMap.size();
            bool newStringsAdded = false;
            if (initialTempStringMapSize!=newTempStringMapSize)
               newStringsAdded = true;

            // put all strings into cache vector
            if (newStringsAdded)
              {
               pCache->strings.clear();
               ::std::map< ::std::wstring, ::std::wstring >::const_iterator mit = tempStringMap.begin();
               for(; mit != tempStringMap.end(); ++mit)
                  {
                   pCache->strings.unsorted_push_back( CStringResourceEntry( mit->first, mit->second ));
                  }
               pCache->strings.sort();
              }

            // we assume that strings from map are allready sorted
            // assumption false, we need to sort strings

            if (foundInFiles)
               {
                _foundStr = tmpStrFound;
                return EC_OK;
               }

            // next time try to find message in cache 
            ::std::vector< ::std::wstring >::const_iterator lit = langsList.begin();
            for(; lit != langsList.end(); ++lit)
               {
                CStringResourceVector::const_iterator it = pCache->strings.find( CStringResourceEntry(composeStringCacheId( *lit, _strId )) );
                if (it!=pCache->strings.end())
                   {
                    _foundStr = it->value;
                    return EC_OK;
                   }
               }
            return EC_RESOURCE_NOT_FOUND;
           }



        CLIMETHOD(findGenericString) (THIS_ CLISTR*           _foundStr
                                          , const CLISTR*     _strId
                                          , const CLISTR*     _langAndLocale
                                          , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                          , const CLISTR*     _moduleName
                                          , const CLISTR*     _strTypeString
                                     )
           {
            CLI_TRY{
                    ::std::wstring strRes;
                    RCODE res = findGenericStringImpl( strRes, stdstr(_strId), stdstr(_langAndLocale), flags, stdstr(_moduleName), stdstr(_strTypeString) );
                    if (!res) return ::cli::propertyGetImpl( _foundStr, strRes );
                    return res;
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_RESOURCE_NOT_FOUND;
           }

        CLIMETHOD(findStringEx) (THIS_ CLISTR*           foundStr
                                     , const CLISTR*     strId
                                     , const CLISTR*     langAndLocale
                                     , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                     , const CLISTR*     moduleName
                                )
           {
            CLI_TRY{
                    ::std::wstring strRes;
                    RCODE res = findGenericStringImpl( strRes, stdstr(strId), stdstr(langAndLocale), flags, stdstr(moduleName), L"str" );
                    if (!res) return ::cli::propertyGetImpl( foundStr, strRes );
                    return res;
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_RESOURCE_NOT_FOUND;
           }

        CLIMETHOD(findString) (THIS_ CLISTR*           foundStr
                                   , const CLISTR*     strId
                                   , const CLISTR*     langAndLocale
                                   , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                              )
           {
            CLI_TRY{
                    ::std::wstring strRes;
                    RCODE res = findGenericStringImpl( strRes, stdstr(strId), stdstr(langAndLocale), flags&(~CLI_ERCMANFINDFLAGS_RCFINDSTRINGFROMMODULE), ::std::wstring(), L"str" );
                    if (!res) return ::cli::propertyGetImpl( foundStr, strRes );
                    return res;
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_RESOURCE_NOT_FOUND;
           }

        WCHAR digit2hex( RCODE digit )
           {
            digit &= 0xF;
            return digit<10 ? (L'0' + (WCHAR)digit) : (L'A' + (WCHAR)(digit-10));
           }

        ::std::wstring rcode2hex( RCODE code )
           {
            ::std::wstring res;
            for(unsigned i=0; i!=8; ++i)
               {
                res.append(1, digit2hex(code));
                code >>= 4;
               }
            ::std::reverse(res.begin(), res.end());
            return ::std::wstring(L"0x") + res;
           }

        CLIMETHOD(findMessageEx) (THIS_ CLISTR*           foundStr
                                      , RCODE    code /* [in] rcode  code  */
                                      , const CLISTR*     langAndLocale
                                      , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                      , const CLISTR*     moduleName
                                 )
           {
            CLI_TRY{
                    ::std::wstring strRes;
                    RCODE res = 0;
                    if (code&EC_USER_CODE)
                       res = findGenericStringImpl( strRes, rcode2hex( code ), stdstr(langAndLocale), flags|CLI_ERCMANFINDFLAGS_RCFINDSTRINGFROMMODULE, stdstr(moduleName), L"msg" );
                    else
                       res = findGenericStringImpl( strRes, rcode2hex( code ), stdstr(langAndLocale), flags|CLI_ERCMANFINDFLAGS_RCFINDSTRINGFROMMODULE, L"cli2", L"msg" );
                    if (!res) return ::cli::propertyGetImpl( foundStr, strRes );
                    return res;
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_RESOURCE_NOT_FOUND;
           }

        CLIMETHOD(findMessage) (THIS_ CLISTR*           foundStr
                                    , RCODE    code /* [in] rcode  code  */
                                    , const CLISTR*     langAndLocale
                                    , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                               )
           {
            CLI_TRY{
                    ::std::wstring strRes;
                    RCODE res = findGenericStringImpl( strRes, rcode2hex( code ), stdstr(langAndLocale), flags&(~CLI_ERCMANFINDFLAGS_RCFINDSTRINGFROMMODULE), ::std::wstring(), L"msg" );
                    if (!res) return ::cli::propertyGetImpl( foundStr, strRes );
                    return res;
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_RESOURCE_NOT_FOUND;
           }

        CLIMETHOD(enumBuiltinLocalesImpl) (THIS_ const ::std::wstring &fileName
                                    , ENUM_CLI_ERCMANFINDFLAGS    flags
                                    //, ::std::vector< ::std::wstring > &foundLocales
                                    , ::std::set< ::std::wstring > &foundLocales
                               )
           {
            CLI_SCOPED_LOCK(builtinsRcCs);
            CRcVector::const_iterator rcIt = builtinsRc.begin();
            for(; rcIt!=builtinsRc.end(); ++rcIt)
               {
                if ((flags&CLI_ERCMANREGISTERFLAGS_RCTYPEANY) != CLI_ERCMANREGISTERFLAGS_RCTYPEANY
                  &&(flags&CLI_ERCMANREGISTERFLAGS_RCTYPEANY)!=rcIt->rcType
                   ) continue;

                ::std::wstring        rcName = rcIt->name;
                if (rcName.empty())   rcName = RC_DEFAULT_FILENAME;

                if (rcName==fileName && !rcIt->lang.empty()) foundLocales.insert(rcIt->lang);
               }
            return EC_OK;
           }

        CLIMETHOD(enumFilesystemLocalesImpl) (THIS_ const ::std::wstring &fileName
                                    , ENUM_CLI_ERCMANFINDFLAGS    flags
                                    , ::std::set< ::std::wstring > &foundLocales
                               )
           {
            ::std::vector< ::std::wstring > pathList;
            fillPathList( pathList, flags );

            using MARTY_FILENAME::appendPath;
            using MARTY_FILENAME::makeFullPath;
            using MARTY_FILENAME::makeCanonical;
            using MARTY_FILENAME::getName;

            ::std::set< ::std::wstring > pathSetAux;
            ::std::vector< ::std::wstring >::const_iterator pit = pathList.begin();
            for(; pit != pathList.end(); ++pit)
               {
                pathSetAux.insert(makeCanonical(*pit));
               }

            ::std::wstring rootPath = getRcRootPath();

            ::cli::io::CiIOFactory iof( "/cli/io-factory" );

            ::std::set< ::std::wstring > allFoundLocales;

            ::std::wstring fileNameLower = fileName; ::cli::fmtutil::toLowerCase(fileNameLower);

            //::std::vector< ::std::wstring >::const_iterator 
            pit = pathList.begin();
            for(; pit != pathList.end(); ++pit)
               {
                ::std::wstring curPath = makeCanonical(makeFullPath(makeCanonical(rootPath), makeCanonical(*pit)));

                std::vector< MARTY_FILESYSTEM::CFindFileInfo< wchar_t > > localeDirs;
                MARTY_FILESYSTEM::findFiles( localeDirs, curPath, ::std::wstring(L"*.*"), true, false );
                std::vector< MARTY_FILESYSTEM::CFindFileInfo< wchar_t > >::const_iterator ldIt = localeDirs.begin();
                for(; ldIt != localeDirs.end(); ++ldIt)
                   {
                    ::std::wstring fullPath = makeCanonical(makeFullPath(makeCanonical(ldIt->path), makeCanonical(ldIt->file)));
                    ::std::wstring fullPathLower = fullPath; ::cli::fmtutil::toLowerCase(fullPathLower);

                    if (!::cli::util::endsWith(fullPathLower,fileNameLower)) continue; // not match

                    ::std::wstring subPath;
                    if ( !MARTY_FILENAME::subPath( subPath, curPath, fullPath )) continue;

                    // remove filename
                    if (subPath.size()>=fileName.size())
                       subPath.erase( subPath.size()-fileName.size(), subPath.npos );

                    MARTY_FILENAME::pathRemoveTrailingSlashInplace(subPath);

                    ::std::wstring localeNameCandidate = getName(subPath);
                    if (!localeNameCandidate.empty() && pathSetAux.find(localeNameCandidate)==pathSetAux.end())
                       foundLocales.insert(localeNameCandidate);

                   }
               }
            return EC_OK;
           }

        /*
        #ifdef _WIN32
        
        inline
        ::std::wstring getLocaleInfo(LCID lcid, LCTYPE lctype)
           {
            WCHAR buf[256];
            buf[ ::GetLocaleInfoW(lcid, lctype, buf, sizeof(buf)/sizeof(buf[0])-1) ] = 0;
            return ::std::wstring(buf);
           }
        
        inline 
        ::std::wstring getLocaleName( DWORD flags )
           {
            LCID lcid = (flags&FIND_MESSAGE_USE_USER_LOCALE) ? LOCALE_USER_DEFAULT : LOCALE_SYSTEM_DEFAULT;
        
            ::std::wstring res = getLocaleInfo(lcid, LOCALE_SISO639LANGNAME);
            
            if (res.empty()) return ::std::wstring();
        
            ::std::wstring country = getLocaleInfo(lcid, LOCALE_SISO3166CTRYNAME);
            if (!country.empty())
               {
                res.append(L"_");
                res.append(country);
               }
            return res;
           }
        
        #else
        
        ::std::wstring getDefLocaleNameAux()
           {
            ::std::wstring localeName;
            if (!::marty::env::getVar(::std::wstring(L"LC_MESSAGES"), localeName))
               ::marty::env::getVar(::std::wstring(L"LANG"), localeName);
            return localeName;
           }
        
        ::std::wstring getDefLocaleName(DWORD  flags ) // remove encoding part
           {
            ::std::wstring lname = getDefLocaleNameAux();
            if (lname.empty()) return lname;
            ::std::wstring::size_type pos = lname.find('.');
            if (pos!=::std::wstring::npos) return ::std::wstring(lname, 0, pos);
            return lname;
           }
        
        #endif
        */

        ::std::wstring getLocaleName(::std::wstring langAndLocaleForLookup, ::std::wstring resultLangAndLocale)
           {
            ::cli::fmtutil::toLowerCase(langAndLocaleForLookup);
            ::cli::fmtutil::toLowerCase(resultLangAndLocale);

            ::std::wstring::size_type pos = 0, size = langAndLocaleForLookup.size();
            for(; pos!=size; ++pos)
               {
                if (langAndLocaleForLookup[pos]==L'_') langAndLocaleForLookup[pos] = L'-';
               }

            //::std::wstring::size_type 
            pos = 0; size = resultLangAndLocale.size();
            for(; pos!=size; ++pos)
               {
                if (resultLangAndLocale[pos]==L'_') resultLangAndLocale[pos] = L'-';
               }

            #if defined(WIN32) || defined(_WIN32)
            ::std::map< ::std::wstring, LCID >::const_iterator lit = localesISO.find(langAndLocaleForLookup);
            if (lit==localesISO.end()) return langAndLocaleForLookup;

            ::std::wstring countryName;
            ::std::wstring languageName;
            if (::cli::util::startsWith(resultLangAndLocale, L"en"))
               {
                languageName = hlp::getLocaleInfo(lit->second,LOCALE_SENGLANGUAGE );
                //countryName  = hlp::getLocaleInfo(lit->second,LOCALE_SENGCOUNTRY );
               }
            else
               {
                languageName = hlp::getLocaleInfo(lit->second,LOCALE_SLANGUAGE );
                //countryName = hlp::getLocaleInfo(lit->second,LOCALE_SCOUNTRY );
               }
            
            if (!countryName.empty())
               {
                if (!languageName.empty()) languageName.append(1, L' ');
                languageName.append(1, L'(');
                languageName.append(countryName);
                languageName.append(1, L')');
               }
            return languageName;

            //LOCALE_SENGCOUNTRY - Full localized name of the country/region. The maximum number of characters allowed for this string is 80, including a terminating null character. This name is based on the localization of the product. Thus it changes for each localized version.
            //LOCALE_SENGLANGUAGE
            //LOCALE_SLANGUAGE
            #else
            return langAndLocaleForLookup;
            #endif
           }

        CLIMETHOD(enumLocalesImpl) (THIS_ INTERFACE_CLI_ILOCALEENUMERATOR*    pEnumerator /* [in] ::cli::iLocaleEnumerator*  pEnumerator  */
                                    , const ::std::wstring &langAndLocale
                                    , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                    , ::std::wstring fileName
                               )
           {
            if (fileName.empty()) fileName = RC_DEFAULT_FILENAME;
            if (!(flags&CLI_ERCMANFINDFLAGS_RCIGNOREDEFFLAGS)) flags = defFindFlags;

            ::std::set< ::std::wstring > allFoundLocales;
            if (!(flags&CLI_ERCMANFINDFLAGS_RCFINDIGNOREBUILTIN))
               enumBuiltinLocalesImpl(fileName,flags,allFoundLocales);
            if (!(flags&CLI_ERCMANFINDFLAGS_RCFINDIGNOREFILES))
               enumFilesystemLocalesImpl(fileName,flags,allFoundLocales);

            /*
            ::std::set< ::std::wstring > allFoundLocales;
            ::std::vector< ::std::wstring >::const_iterator lit = foundLocales.begin();
            for(; lit != foundLocales.end(); ++lit)
               {
                allFoundLocales.insert(*lit);
               }
            */

            CiLocaleEnumerator_tmp enumerator(pEnumerator);
            ::std::set< ::std::wstring >::const_iterator allIt = allFoundLocales.begin();
            for(; allIt != allFoundLocales.end(); ++allIt)
               {
                enumerator.onLocaleEnumerate( allIt->c_str(), getLocaleName(*allIt, langAndLocale).c_str() );
                /*
                LOCALE_SLANGUAGE. Fully localized name of the language. 
                LOCALE_SNAME. Locale/language name. Windows Vista and later
                LOCALE_SSCRIPTS. Script for the locale. 
                */
               }
            return EC_OK;
           }

        CLIMETHOD(enumLocales) (THIS_ INTERFACE_CLI_ILOCALEENUMERATOR*    pEnumerator /* [in] ::cli::iLocaleEnumerator*  pEnumerator  */
                                    , const CLISTR*     langAndLocale
                                    , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                    , const CLISTR*     fileName
                               )
           {
            CLI_TRY{
                    if (!pEnumerator) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pEnumerator" );  }
                    enumLocalesImpl(pEnumerator, stdstr(langAndLocale), flags, stdstr(fileName) );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD(enumGenericStringLocales) (THIS_ INTERFACE_CLI_ILOCALEENUMERATOR*    pEnumerator /* [in] ::cli::iLocaleEnumerator*  pEnumerator  */
                                                 , const CLISTR*     langAndLocale
                                                 , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                                 , const CLISTR*     _moduleName
                                                 , const CLISTR*     _strTypeString
                                            )
           {
            CLI_TRY{
                    if (!pEnumerator) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pEnumerator" );  }
                    ::std::wstring strTypeString = stdstr(_strTypeString);
                    if (strTypeString.empty()) strTypeString = L"str";

                    ::std::wstring moduleName = stdstr(moduleName);

                    if (!moduleName.empty()) moduleName = MARTY_FILENAME::getName(moduleName);
                    // generate file name for lookup
                    //::std::wstring moduleName;
                    if (!(flags&CLI_ERCMANFINDFLAGS_RCFINDSTRINGFROMMODULE))
                       {
                        moduleName.clear();
                       }
        
                    if (moduleName.empty())
                       { // we get the app file name as module name
                        ::std::wstring appExeName;
                        MARTY_LIBAPI_NS getModuleFileName( 0, appExeName );
                        using MARTY_FILENAME_NS getName;
                        moduleName = getName(appExeName);
                       }
        
                    if (moduleName.empty())
                       {
                        moduleName = L"cli2";
                       }
        
                    ::std::wstring requestedFileName = MARTY_FILENAME::appendExtention(moduleName, strTypeString);
                    enumLocalesImpl(pEnumerator, stdstr(langAndLocale), flags, requestedFileName );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }



/*

        CStringResourceCache* getStringCache( const ::std::wstring &stringType )
           {
            CLI_SCOPED_LOCK(stringResourceGlobalCs);
            ::std::map< ::std::wstring, CStringResourceCache* >::const_iterator it = stringResourceGlobal.find(stringType);
            if (it!=stringResourceGlobal.end()) return it->second;

            CStringResourceCache* pNewCache = new CStringResourceCache*();
            try{
                stringResourceGlobal[stringType] = pNewCache;
                return pNewCache;
               }
            catch(...) {}
            delete pNewCache;
            return 0;
           }

        struct CStringResourceEntry
        {
            ::std::wstring  key;
            ::std::wstring  value;
            CStringResourceEntry() : key(), value() {}
            CStringResourceEntry( const ::std::wstring &k, const ::std::wstring &v) : key(k), value(v) {}
        }; // struct CStringResourceEntry

        struct CStringResourceEntryLess
        {
            CStringResourceEntryLess() {}
            bool operator()(const CStringResourceEntry e1, const CStringResourceEntry &e2) { return e1.key < e2.key; }
        }; // struct CStringResourceEntryLess

        typedef ::cli::util::CAutoSortVector<CStringResourceEntry, CStringResourceEntryLess>  CStringResourceVector;

        struct CStringResourceCache
        {
            ::cli::CCriticalSection    cs;
            CStringResourceVector      strings;
            CStringResourceCache() : cs(), strings() {}
        }; // struct CStringResourceCache
*/

}; // class CResourceManagerImpl




}; // namespace impl
}; // namespace cli


#endif /* SRC_CORE_CLIRCIMPL_H */

