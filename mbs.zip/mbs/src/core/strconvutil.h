#ifndef SRC_CORE_STRCONVUTIL_H
#define SRC_CORE_STRCONVUTIL_H

/* add this lines to your scr
#ifndef SRC_CORE_STRCONVUTIL_H
    #include "src/core/strconvutil.h"
#endif
*/

inline
int char2digit( char ch )
{
    if (ch>='0' && ch<='9') return (int)ch - '0';
    if (ch>='a' && ch<='z') return (int)ch - 'a' + 10;
    if (ch>='A' && ch<='Z') return (int)ch - 'A' + 10;
    return -1;
}

inline
int char2digit( wchar_t ch )
{
    if (ch>=L'0' && ch<=L'9') return (int)ch - L'0';
    if (ch>=L'a' && ch<=L'z') return (int)ch - L'a' + 10;
    if (ch>=L'A' && ch<=L'Z') return (int)ch - L'A' + 10;
    return -1;
}

template<typename TC>
TC digit2charLower(unsigned digit)
{
    if (digit<10) return (TC)digit+(TC)'0';
    return (TC)digit-10+(TC)'a';
}

template<typename TC>
TC digit2charUpper(unsigned digit)
{
    if (digit<10) return (TC)digit+(TC)'0';
    return (TC)digit-10+(TC)'A';
}

template<typename TC>
TC digit2char(unsigned digit, bool upperCase = true)
{
    return upperCase ? digit2charUpper<TC>(digit) : digit2charLower<TC>(digit);
}


/*
template <typename TC>
const TC* parseInteger( const TC* pStr, int base, int &intVal )
{
    intVal = 0;
    for(;*pStr; ++pStr)
       {
        int d = char2digit( *pStr );
        if (d<0) return pStr;
        if (d>=base) return pStr;
        intVal *= base;
        intVal += d;
       }
    return pStr;
}
*/


#endif /* SRC_CORE_STRCONVUTIL_H */

