#ifndef CLI_VARIANTIMPL_H
#define CLI_VARIANTIMPL_H

/* add this lines to your src
#ifndef CLI_VARIANTIMPL_H
    #include "variantImpl.h"
#endif
*/

#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif

#ifndef CORE_ALVARIANT_H
    #include "alvariant.h"
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef SRC_CORE_VARIANTTYPENAMECONV_H
    #include "variantTypeNameConv.h"
#endif

#ifndef SRC_CORE_CLRCONV_H
    #include "clrconv.h"
#endif


// http://psyfactor.org/lybr73.htm
// http://psyfactor.org/lib/rumours8.htm

namespace cli
{
//namespace arglist
//{
namespace impl
{

using ::cli::VariantType::vt_empty   ;
using ::cli::VariantType::vt_none    ;
using ::cli::VariantType::vt_char    ;
using ::cli::VariantType::vt_wchar   ;
using ::cli::VariantType::vt_short   ;
using ::cli::VariantType::vt_ushort  ;
using ::cli::VariantType::vt_int     ;
using ::cli::VariantType::vt_uint    ;
using ::cli::VariantType::vt_int64   ;
using ::cli::VariantType::vt_uint64  ;
using ::cli::VariantType::vt_int_ptr ;
using ::cli::VariantType::vt_uint_ptr;
using ::cli::VariantType::vt_float   ;
using ::cli::VariantType::vt_double  ;
using ::cli::VariantType::vt_pstring ;
using ::cli::VariantType::vt_ptr     ;
using ::cli::VariantType::vt_dump    ;
using ::cli::VariantType::vt_datetime;
using ::cli::VariantType::vt_colorref;
using ::cli::VariantType::vt_iUnknown;
using ::cli::VariantType::vt_bigint  ;
using ::cli::VariantType::vt_rational;



template <typename TBaseImpl>
class CVariantImplBase : public TBaseImpl
                       , public INTERFACE_CLI_IVARIANT
                       , public INTERFACE_CLI_IREADONLYVARIANT
{

    protected:

        CVariant                     value;
        //::cli::CRefCounter           refCounter;

    public:

        typedef TBaseImpl base_impl;

        CVariantImplBase() : base_impl(), INTERFACE_CLI_IVARIANT(), INTERFACE_CLI_IREADONLYVARIANT(), value() /* , refCounter(0) */  {}

        CLIMETHOD_(DWORD, getType) ()
           {
            return value.valType;
           }

        CLIMETHOD(convertType) (THIS_ ENUM_CLI_VARIANTTYPE    newType /* [in] ::cli::VariantType  newType  */)
           {
            if (value.valType==newType) return EC_OK;
            value.convert( (DWORD)newType, false);
            return EC_OK;
           }

        CLIMETHOD(serializeSimple) (THIS_ CLISTR*           str)
           {
            return ::cli::propertyGetImpl( str, value.asString(false) );
           }

        CLIMETHOD(serializeAdvanced) (THIS_ CLISTR*           str)
           {
            return ::cli::propertyGetImpl( str
                                         , ::std::wstring(L"{") + convertVariantTypeNameToString(value.valType) + ::std::wstring(L"}:[") + value.asString(false) + ::std::wstring(L"]")
                                         );
           }

        CLIMETHOD(serializeAdvancedSeparate) (THIS_ CLISTR*           strValue
                                                  , CLISTR*           strType
                                             )
           {
            ::cli::propertyGetImpl( strValue, value.asString(false) );
            return ::cli::propertyGetImpl( strType, convertVariantTypeNameToString(value.valType) );
           }

        CLIMETHOD(deserializeSimple) (THIS_ const CLISTR*     str)
           {
            if (stdstr(str).empty())
               return setEmpty();
            return setString(str);
            /*
            CLIPSTR pstr = 0;
            clipstr_alloc( &pstr, L"<NULL>" );
            CVariant tmp( pstr );
            value.swap(tmp);
            return EC_OK;
            */
           }

        RCODE deserializeAdvancedHelper( const ::std::wstring &strData, ENUM_CLI_VARIANTTYPE vt )
           {
            if (vt==CLI_VARIANTTYPE_VT_EMPTY && !strData.empty())
               {
                vt = CLI_VARIANTTYPE_VT_PSTRING;
               }

            if (vt==CLI_VARIANTTYPE_VT_EMPTY) return setEmpty();

            CLIPSTR pstr = 0;
            clipstr_alloc( &pstr, strData.c_str() );
            CVariant tmp( pstr );
            if (tmp.valType != vt)
               tmp.convert(vt);
            value.swap(tmp);
            return EC_OK;
           }

        bool splitStringAdvancedSerialized( const ::std::wstring &str, ::std::wstring &strValue, ::std::wstring &strType )
           {
            if (str.empty()) return false;
            if (str[0]!=L'{' || str[str.size()-1]!=L']') { strValue = str; return false; }
            ::std::wstring::size_type pos = str.find(L"}:[");
            if (pos==str.npos) { strValue = str; return false; }
            //strValue = ::std::wstring(str,pos+3,str.npos);
            strValue = ::std::wstring(str,pos+3,str.size()-pos-3-1);
            strType  = ::std::wstring(str,1,pos-1);
            return true;
           }

        CLIMETHOD(deserializeAdvanced) (THIS_ const CLISTR*     _str)
           {
            ::std::wstring strVal, strType;
            if (!splitStringAdvancedSerialized( stdstr(_str), strVal, strType ))
               { // simple
                if (strVal.empty()) return setEmpty();
                else                return setString(_str);
               }
            else
               { // advanced
                return deserializeAdvancedHelper( strVal, convertVariantTypeNameFromString(strType) );
               }

            /*
            ::std::wstring str = stdstr(_str);
            if (str.empty()) return setEmpty();
            if (str[0]!=L'{' || str[str.size()-1]!=L']') return setString(_str);

            ::std::wstring::size_type pos = str.find(L"}:[");
            if (pos==str.npos) return setString(_str);
            return deserializeAdvancedHelper( ::std::wstring(str,pos+3,str.npos)
                                            , convertVariantTypeNameFromString( ::std::wstring(str,1,pos-1) )
                                            );
            */
           }

        CLIMETHOD(deserializeAdvancedSeparate) (THIS_ const CLISTR*     strValue
                                                    , const CLISTR*     strType
                                               )
           {
            return deserializeAdvancedHelper( stdstr(strValue), convertVariantTypeNameFromString( stdstr(strType) ) );
            //return ::cli::propertyGetImpl( str, value.asString() );
           }

        CLIMETHOD(deserializeAuto) (THIS_ const CLISTR*     str)
           {
            return deserializeAdvanced(str);
            /*
            ::std::wstring strVal, strType;
            if (!splitStringAdvancedSerialized( stdstr(_str), strVal, strType ))
               { // simple
                if (strVal.empty()) return setEmpty();
                else                return setString(_str);
               }
            else
               { // advanced
                return deserializeAdvancedHelper( strVal, convertVariantTypeNameFromString(strType) );
               }
            */
           }

        CLIMETHOD(getTypeStringChars) ( WCHAR*    buf /* [out] wchar buf[]  */
                                      , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                      )
           {
            if (!buf && !bufSize) return EC_INVALID_PARAM;
            //if (!buf) return EC_OK;
            if (!buf) // but bufSize taken
               {
                *bufSize = value.typeName(L'W').size() + 1;
                return EC_OK;
               }
            if (!bufSize) return EC_INVALID_PARAM;
            ::cli::util::copyStr2buf( value.typeName(L'W'), buf, *bufSize, bufSize );
            return EC_OK;
           }

        CLIMETHOD(getTypeString) (THIS_ CLISTR*           typeStr)
           {
            return ::cli::propertyGetImpl( typeStr, value.typeName(L'W') );
           }

        CLIMETHOD(valueQueryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                            , VOID**    ifPtr /* [out] void* ifPtr  */
                                       )
           {
            CLI_TRY{
                    if (!interfaceId) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"interfaceId" );  }
                    if (!ifPtr)       { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"ifPtr" );  }

                    if (value.valType!=::cli::VariantType::vt_iUnknown)
                        return EC_NOT_OBJECT;

                    if (!value.value.vUnknown)
                       return EC_NO_OBJECT;

                    return value.value.vUnknown->queryInterface( interfaceId, ifPtr );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        CLIMETHOD_(STRUCT_CLI_VARIANT*, getVariantRawPtr) (THIS)
           {
            return &value;
           }

        CLIMETHOD(assignRawVariant) (THIS_ const STRUCT_CLI_VARIANT*    v /* [in,ref] ::cli::Variant  v  */)
           {
            //if (!v) return EC_INVALID_PARAM;
            if (!v) 
               {
                CVariant tmp;
                value.swap(tmp);
                return EC_OK; // undone: need return error?
               }

            CVariant tmp(*v);
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(assignVariant) (THIS_ INTERFACE_CLI_IVARIANT*    pVariant /* [in] ::cli::iVariant*  pVariant  */)
           {
            if (!pVariant) 
               {
                CVariant tmp;
                value.swap(tmp);
                return EC_OK; // undone: need return error?
               }

            /*
            STRUCT_CLI_VARIANT *pv = pVariant->getVariantRawPtr();
            if (!pv) 
               {
                CVariant tmp;
                value.swap(tmp);
                return EC_OK; // undone: need return error?
               }

            return assignRawVariant(pv);
            */

            return assignRawVariant( pVariant->getVariantRawPtr() );
           }

        CLIMETHOD(setEmpty) (THIS)  
           { 
            CVariant tmp;
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(setChar) (THIS_ CHAR    ch /* [in] char  ch  */)
           {
            CVariant tmp(ch);
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(setWChar) (THIS_ WCHAR    wch /* [in] wchar  wch  */)
           {
            CVariant tmp(wch);
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(setShort) (THIS_ SHORT    s /* [in] short  s  */)
           {
            CVariant tmp(s);
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(setUShort) (THIS_ USHORT    us /* [in] ushort  us  */)
           {
            CVariant tmp(us);
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(setInt) (THIS_ INT    i /* [in] int  i  */)
           {
            CVariant tmp(i);
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(setUInt) (THIS_ UINT    i /* [in] uint  i  */)
           {
            CVariant tmp(i);
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(setColorref) (THIS_ COLORREF    i /* [in] colorref  i  */)
           {
            CVariant tmp(i, ::cli::VariantType::vt_colorref);
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(setInt64) (THIS_ INT64    i /* [in] int64  i  */)
           {
            CVariant tmp(i);
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(setUInt64) (THIS_ UINT64    i /* [in] uint64  i  */)
           {
            CVariant tmp(i);
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(setIntPtr) (THIS_ INT_PTR    i /* [in] int_ptr  i  */)
           {
            CVariant tmp((INT_PTR)i, true /* dummy */ );
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(setUIntPtr) (THIS_ UINT_PTR    i /* [in] uint_ptr  i  */)
           {
            CVariant tmp((UINT_PTR)i, true /* dummy */ );
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(setFloat) (THIS_ FLOAT    f /* [in] float  f  */)
           {
            CVariant tmp(f);
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(setDouble) (THIS_ DOUBLE    d /* [in] double  d  */)
           {
            CVariant tmp(d);
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(setPtr) (THIS_ const VOID*    vptr /* [in] void*  vptr  */)
           {
            CVariant tmp(const_cast<VOID*>(vptr));
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(setUnknown) (THIS_ INTERFACE_CLI_IUNKNOWN*    pUnknown /* [in] ::cli::iUnknown*  pUnknown  */)
           {
            CVariant tmp(pUnknown);
            value.swap(tmp);
            return EC_OK;           
           }

        CLIMETHOD(setString) (THIS_ const CLISTR*     str)
           {
            CLIPSTR pstr = 0;
            if (!str)
               {
                clipstr_alloc( &pstr, L"<NULL>" );
               }
            else
               {
                CCliStr *pCliStr = (CCliStr*)str;
                if (!pCliStr->data())
                   {
                    clipstr_alloc( &pstr, L"<NULL>" );
                   }
                else
                   {
                    clipstr_alloc( &pstr, pCliStr->data(), pCliStr->size() );
                   }
               }
            CVariant tmp( pstr );
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(setStringPStr) (THIS_ CLIPSTR           str)
           {
            if (!str)
               {
                CLIPSTR pstr = 0;
                clipstr_alloc( &pstr, L"<NULL>" );
                CVariant tmp( pstr );
                value.swap(tmp);
                return EC_OK;
               }
            else
               {
                CVariant tmp( str );
                value.swap(tmp);
                return EC_OK;
               }
           }


        CLIMETHOD(setStringChars) (THIS_ const WCHAR*    str /* [in,flat] wchar  str[]  */
                                       , SIZE_T    strSize /* [in] size_t  strSize  */
                                  )
           {
            CLIPSTR pstr = 0;
            if (!str)
               {
                clipstr_alloc( &pstr, L"<NULL>" );
               }
            else
               {
                if (strSize==SIZE_T_NPOS)
                   clipstr_alloc( &pstr, str );
                else
                   clipstr_alloc( &pstr, str, strSize );
               }
            CVariant tmp( pstr );
            value.swap(tmp);
            return EC_OK;
           }

        CLIMETHOD(setDump) (THIS_ const BYTE*    d /* [in,flat] byte  d[]  */
                                , SIZE_T    dumpSize /* [in] size_t  dumpSize  */
                           )
           {
            if (!d || !dumpSize)
               {
                CVariant tmp( (UINT)0 );
                value.swap(tmp);
                return EC_OK;
               }
            else
               {
                CLIPCSTR pstr = 0;
                clipstr_alloc( &pstr, (const CHAR*)d, dumpSize );
                CVariant tmp( pstr );
                value.swap(tmp);
                return EC_OK;
               }
           }

        CLIMETHOD(setDate) (THIS_ const STRUCT_CLI_CLISYSTEMTIME*    datetime /* [in,ref] ::cli::CLISYSTEMTIME  datetime  */)
           {
            if (!datetime)
               {
                CVariant tmp( (INT64)0 );
                value.swap(tmp);
                return EC_OK;
               }
            else
               {
                CVariant tmp( *datetime );
                value.swap(tmp);
                return EC_OK;
               }
           }

        CLIMETHOD(setBigInteger) (THIS_ const STRUCT_CLI_BIGINTEGER*    bigint /* [in,ref] ::cli::BigInteger  bigint  */)
           {
            if (!bigint)
               {
                CVariant tmp( ::cli::numeric::extended_int128_t(0) );
                value.swap(tmp);
                return EC_OK;
               }
            else
               {
                CVariant tmp( *bigint );
                value.swap(tmp);
                return EC_OK;
               }
           }

        
        CLIMETHOD(setRationalNumber) (THIS_ const STRUCT_CLI_RATIONALNUMBER*    rational /* [in,ref] ::cli::RationalNumber  rational  */)
           {
            if (!rational)
               {
                CVariant tmp( ::cli::numeric::rational_number_t(0) );
                value.swap(tmp);
                return EC_OK;
               }
            else
               {
                CVariant tmp( *rational );
                value.swap(tmp);
                return EC_OK;
               }
           }

        CLIMETHOD(setBool) (THIS_ BOOL    b /* [in] bool  b  */)
           {
            CVariant tmp = CVariant::makeBool( b );
            value.swap(tmp);
            //value.swap(CVariant::makeBool( b ));
            return EC_OK;
           }

        CLIMETHOD(getBool) ( BOOL*    b /* [out] bool b  */
                           )
           {
            if (!b) return EC_OK;
            *b = value.asBool();
            return EC_OK;
           }

        CLIMETHOD(getChar) ( CHAR*    ch /* [out] char ch  */
                           )
           {
            if (!ch) return EC_OK;
            *ch = value.asChar();
            return EC_OK;
           }

        CLIMETHOD(getWChar) ( WCHAR*    wch /* [out] wchar wch  */
                            )
           {
            if (!wch) return EC_OK;
            *wch = value.asWChar();
            return EC_OK;            
           }

        CLIMETHOD(getShort) ( SHORT*    s /* [out] short s  */
                            )
           {
            if (!s) return EC_OK;
            *s = value.asShort();
            return EC_OK;            
           }

        CLIMETHOD(getUShort) ( USHORT*    us /* [out] ushort us  */
                             )
           {
            if (!us) return EC_OK;
            *us = value.asUShort();
            return EC_OK;            
           }

        CLIMETHOD(getInt) ( INT*    i /* [out] int i  */
                          )
           {
            if (!i) return EC_OK;
            *i = value.asInt();
            return EC_OK;            
           }

        CLIMETHOD(getUInt) ( UINT*    i /* [out] uint i  */
                           )
           {
            if (!i) return EC_OK;
            *i = value.asUInt();
            return EC_OK;            
           }

/*
COLORREF convertColorrefFromString( const ::std::wstring &_str );
::std::wstring convertColorrefToName( COLORREF clr, bool bUpperName, bool bUpperNumeric );
*/
        CLIMETHOD(getColorref) (THIS_ COLORREF*    i /* [out] colorref i  */)
           {
            if (!i) return EC_OK;
            //*i = value.asUInt();
            *i = value.asColorref();
            return EC_OK;
           }

        CLIMETHOD(getInt64) ( INT64*    i /* [out] int64 i  */
                            )
           {
            if (!i) return EC_OK;
            *i = value.asInt64();
            return EC_OK;            
           }

        CLIMETHOD(getUInt64) ( UINT64*    i /* [out] uint64 i  */
                             )
           {
            if (!i) return EC_OK;
            *i = value.asUInt64();
            return EC_OK;            
           }

        CLIMETHOD(getIntPtr) ( INT_PTR*    i /* [out] int_ptr i  */
                             )
           {
            if (!i) return EC_OK;
            *i = value.asIntPtr();
            return EC_OK;            
           }

        CLIMETHOD(getUIntPtr) ( UINT_PTR*    i /* [out] uint_ptr i  */
                              )
           {
            if (!i) return EC_OK;
            *i = value.asUIntPtr();
            return EC_OK;            
           }

        CLIMETHOD(getFloat) ( FLOAT*    f /* [out] float f  */
                            )
           {
            if (!f) return EC_OK;
            *f = value.asFloat();
            return EC_OK;            
           }

        CLIMETHOD(getDouble) ( DOUBLE*    d /* [out] double d  */
                             )
           {
            if (!d) return EC_OK;
            *d = value.asDouble();
            return EC_OK;            
           }

        CLIMETHOD(getPtr) ( VOID**    vptr /* [out] void* vptr  */
                          )
           {
            if (!vptr) return EC_OK;
            *vptr = value.asPtr();
            return EC_OK;            
           }

        CLIMETHOD(getUnknown) (THIS_ INTERFACE_CLI_IUNKNOWN**    pUnknown /* [out] ::cli::iUnknown* pUnknown  */)
           {
            if (!pUnknown) return EC_OK;
            *pUnknown = value.asUnknown();
            if (*pUnknown) (*pUnknown)->addRef();
            return EC_OK;
           }

        CLIMETHOD(getString) ( CLISTR*           str
                             )
           {
            if (!str) return EC_OK;
            CCliStr_copyTo( *((CCliStr*)str), value.asString() );
            return EC_OK;            
           }

        CLIMETHOD(getStringPStr) ( CLIPSTR*          str
                                 )
           {
            if (!str) return EC_OK;
            CLIPSTR_copyTo( *str, value.asString() );
            return EC_OK;            
           }

        CLIMETHOD(getStringChars) ( WCHAR*    buf /* [out] wchar buf[]  */
                                       , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                  )
           {
            if (!buf && !bufSize) return EC_INVALID_PARAM;
            //if (!buf) return EC_OK;
            if (!buf) // but bufSize taken
               {
                *bufSize = value.asString().size() + 1;
                return EC_OK;
               }
            if (!bufSize) return EC_INVALID_PARAM;
            ::cli::util::copyStr2buf( value.asString(), buf, *bufSize, bufSize );
            return EC_OK;
           }

        CLIMETHOD(getDate) ( STRUCT_CLI_CLISYSTEMTIME*    datetime /* [out] ::cli::CLISYSTEMTIME datetime  */
                           )
           {
            if (!datetime) return EC_OK;
            *datetime = value.asDatetime();
            return EC_OK;
           }

        CLIMETHOD(getBigInteger) (THIS_ STRUCT_CLI_BIGINTEGER*    bigint /* [out] ::cli::BigInteger bigint  */)
           {
            if (!bigint) return EC_OK;
            *bigint = value.asBigInteger();
            return EC_OK;
           }

        CLIMETHOD(getRationalNumber) (THIS_ STRUCT_CLI_RATIONALNUMBER*    rational /* [out] ::cli::RationalNumber rational  */)
           {
            if (!rational) return EC_OK;
            *rational = value.asRational();
            return EC_OK;
           }
 
        CLIMETHOD(getDump) ( CLIPCSTR*         str
                           )
           {
            if (!str) return EC_OK;
            if (value.valType != ::cli::VariantType::vt_dump)
               {
                clipstr_assign(str, "", 0);
               }
            else
               {
                clipstr_assign(str, clipstr_data(value.value.vDump), clipstr_size(value.value.vDump) );
               }
            return EC_OK;
           }

}; // class CVariantImplBase


// base implementation which use ref counting for self and for module
// used for "free" implementation
struct CVariantImplBaseHeapedBaseImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
{
    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    CVariantImplBaseHeapedBaseImpl() : base_impl(DEF_MODULE) {}
}; // struct CVariantImplBaseBaseImpl


struct CVariantFreeImpl : public CVariantImplBase<CVariantImplBaseHeapedBaseImpl>
{
    typedef CVariantImplBase<CVariantImplBaseHeapedBaseImpl> base_impl;

    CVariantFreeImpl() : base_impl() {}

    CLI_BEGIN_INTERFACE_MAP2(CVariantFreeImpl, INTERFACE_CLI_IVARIANT)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IVARIANT )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IREADONLYVARIANT )
    CLI_END_INTERFACE_MAP(CVariantFreeImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }
    CLIMETHOD_(VOID, destroy) (THIS)
       {
        #include <cli/compspec/delthis.h>
       }

    CLIMETHOD(cloneVariant) (THIS_ INTERFACE_CLI_IVARIANT**    pVariantCopy /* [out] ::cli::iVariant* pVariantCopy  */)
       {
        // undone: CLI_TRY
        if (!pVariantCopy) return EC_INVALID_OUT_PTR;
        CVariantFreeImpl *pv = new CVariantFreeImpl();
        pv->value = value;
        *pVariantCopy = pv;
        return EC_OK;
       }

    CLIMETHOD(cloneVariantReadOnly) (THIS_ INTERFACE_CLI_IREADONLYVARIANT**    pVariantCopy /* [out] ::cli::iReadOnlyVariant* pVariantCopy  */)
       {
        // undone: CLI_TRY
        if (!pVariantCopy) return EC_INVALID_OUT_PTR;
        CVariantFreeImpl *pv = new CVariantFreeImpl();
        pv->value = value;
        *pVariantCopy = pv;
        return EC_OK;
       }


    CLIMETHOD(createEmptyVariant) (THIS_ INTERFACE_CLI_IVARIANT**    pVariantEmpty /* [out] ::cli::iVariant* pVariantEmpty  */)
       {
        // undone: CLI_TRY
        if (!pVariantEmpty) return EC_INVALID_OUT_PTR;
        INTERFACE_CLI_IVARIANT *pv = new CVariantFreeImpl();
        *pVariantEmpty = pv;
        return EC_OK;
       }

};  // CVariantFreeImpl



struct CVariantImplBasePooledBaseImpl
{
}; // struct CVariantImplBasePooledBaseImpl


struct CVariantPooledBaseImpl : public CVariantImplBase<CVariantImplBasePooledBaseImpl>
{
    typedef CVariantImplBase<CVariantImplBasePooledBaseImpl> base_impl;

protected:

    ::cli::CRefCounter    refCounter;

public:

    CVariantPooledBaseImpl() : base_impl(), refCounter(0) {}

    void clearVariant()
       {
        CVariant tmp;
        value.swap(tmp);
       }

}; // struct CVariantPooledBaseImpl











}; // namespace impl
//}; // namespace arglist
}; // namespace cli




#endif /* CLI_VARIANTIMPL_H */

