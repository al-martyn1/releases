#ifndef SRC_CORE_CORESERVICES_H
#define SRC_CORE_CORESERVICES_H

/* add this lines to your scr
#ifndef SRC_CORE_CORESERVICES_H
    #include "coreservices.h"
#endif
*/

#ifndef CLI_CORESERVICES_H
    #include <cli/coreservices.h>
#endif

#ifndef MARTY_UTF_H
    #include <marty/utf.h>
#endif

namespace cli
{
namespace impl
{


struct CComponentManagerImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_ICOMPONENTMANAGER
{


    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    CComponentManagerImpl( ) : base_impl(DEF_MODULE)
       {
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    ~CComponentManagerImpl()
       {
       }

    CLI_BEGIN_INTERFACE_MAP(CComponentManagerImpl)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICOMPONENTMANAGER )
    CLI_END_INTERFACE_MAP(CComponentManagerImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    
       { 
        return addRefImpl();
       }

    CLIMETHOD_(ULONG, release) (THIS)
       {
        return releaseImpl();
       }


    bool enumComponentCategoriesImpl( const std::string &componentId
                                    , SIZE_T    categoryIdx
                                    , std::string &categoryName
                                    )
       {
        if (componentId.empty()) return false;
        char nameBuf[4096];
        if (!cliEnumComponentCategories( componentId.c_str(), categoryIdx, sizeof(nameBuf), &nameBuf[0] ) ) return false;
        categoryName.assign(nameBuf);
        return true;
       }

    bool enumCategoriesImpl( SIZE_T    categoryIdx
                           , std::string &categoryName
                           )
       {
        char nameBuf[4096];
        if (!cliEnumCategories( categoryIdx, sizeof(nameBuf), &nameBuf[0] ) ) return false;
        categoryName.assign(nameBuf);
        return true;
       }

    bool enumCategoryComponentsImpl( const std::string &categoryId
                               , SIZE_T    componentIdx
                               , std::string &componentName
                               )
       {
        if (categoryId.empty()) return false;
        char nameBuf[4096];
        if (!cliEnumCategoryComponents( categoryId.c_str(), componentIdx, sizeof(nameBuf), &nameBuf[0] ) ) return false;
        componentName.assign(nameBuf);
        return true;
       }

    bool getComponentDescriptionImpl( const std::string &componentId, const std::wstring &langId, BOOL findExactLang, std::wstring &descriptionStr)
       {
        if (componentId.empty()) return false;
        wchar_t nameBuf[4096];
        if (!cliGetComponentDecsription( componentId.c_str(), langId.empty() ? (const wchar_t*)0 : langId.c_str(), findExactLang, sizeof(nameBuf), &nameBuf[0] ) ) return false;
        descriptionStr.assign(nameBuf);
        return true;
       }

    CLIMETHOD_(SIZE_T, enumComponentCategoriesMbs) (THIS_ const CHAR*    componentId /* [in,flat] char  componentId[]  */
                                                        , SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                                        , SIZE_T    categoryNameBufSize /* [in] size_t  categoryNameBufSize  */
                                                        , CHAR*    categoryNameBuf /* [out,flat,optional] char categoryNameBuf[]  */
                                                   )
       {
        try{
            if (!componentId) return 0;
    
            std::string resCategoryName;
            if (!enumComponentCategoriesImpl( stdstr(componentId), categoryIdx, resCategoryName ))
               return 0;
    
            if (!categoryNameBuf)
               return resCategoryName.size()+1;
    
            SIZE_T numCharsToCopy = categoryNameBufSize - 1;
            if (numCharsToCopy>resCategoryName.size()) numCharsToCopy = resCategoryName.size();
            resCategoryName.copy( categoryNameBuf, numCharsToCopy );
            categoryNameBuf[numCharsToCopy] = 0;
            return numCharsToCopy+1;
           }
        catch(...) { }
        return 0;
       }

    CLIMETHOD_(SIZE_T, enumComponentCategoriesBuf) (THIS_ const WCHAR*    componentId /* [in,flat] wchar  componentId[]  */
                                                        , SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                                        , SIZE_T    categoryNameBufSize /* [in] size_t  categoryNameBufSize  */
                                                        , WCHAR*    categoryNameBuf /* [out,flat,optional] wchar categoryNameBuf[]  */
                                                   )
       {
        try{
            if (!componentId) return 0;
            std::string resCategoryNameTmp;
            if (!enumComponentCategoriesImpl( MARTY_UTF::toUtf8(stdstr(componentId)), categoryIdx, resCategoryNameTmp ))
               return 0;
    
            std::wstring resCategoryName = MARTY_UTF::fromUtf8(resCategoryNameTmp);
            SIZE_T numCharsToCopy = categoryNameBufSize - 1;
            if (numCharsToCopy>resCategoryName.size()) numCharsToCopy = resCategoryName.size();
            resCategoryName.copy( categoryNameBuf, numCharsToCopy );
            categoryNameBuf[numCharsToCopy] = 0;
            return numCharsToCopy+1;
           }
        catch(...) { }
        return 0;
       }

    CLIMETHOD(enumComponentCategories) (THIS_ const CLISTR*     componentId
                                            , SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                            , CLISTR*           categoryName
                                       )
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, componentId );
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(3, categoryName );

        std::string resCategoryNameTmp;
        if (!enumComponentCategoriesImpl( MARTY_UTF::toUtf8(stdstr(componentId)), categoryIdx, resCategoryNameTmp ))
           return EC_COMPONENT_NOT_FOUND;
        return ::cli::propertyGetImpl( categoryName, MARTY_UTF::fromUtf8(resCategoryNameTmp) );

        CLIMETHOD_IMPL_END();
       }




    CLIMETHOD_(SIZE_T, enumCategoriesMbs) (THIS_ SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                               , SIZE_T    categoryNameBufSize /* [in] size_t  categoryNameBufSize  */
                                               , CHAR*    categoryNameBuf /* [out,flat,optional] char categoryNameBuf[]  */
                                          )
       {
        try{
            std::string resCategoryName;
            if (!enumCategoriesImpl( categoryIdx, resCategoryName ))
               return 0;
    
            if (!categoryNameBuf)
               return resCategoryName.size()+1;
    
            SIZE_T numCharsToCopy = categoryNameBufSize - 1;
            if (numCharsToCopy>resCategoryName.size()) numCharsToCopy = resCategoryName.size();
            resCategoryName.copy( categoryNameBuf, numCharsToCopy );
            categoryNameBuf[numCharsToCopy] = 0;
            return numCharsToCopy+1;
           }
        catch(...) { }
        return 0;
       }

    CLIMETHOD_(SIZE_T, enumCategoriesBuf) (THIS_ SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                               , SIZE_T    categoryNameBufSize /* [in] size_t  categoryNameBufSize  */
                                               , WCHAR*    categoryNameBuf /* [out,flat,optional] wchar categoryNameBuf[]  */
                                          )
       {
        try{
            std::string resCategoryNameTmp;
            if (!enumCategoriesImpl( categoryIdx, resCategoryNameTmp ))
               return 0;
    
            std::wstring resCategoryName = MARTY_UTF::fromUtf8(resCategoryNameTmp);
            if (!categoryNameBuf)
               return resCategoryName.size()+1;

            SIZE_T numCharsToCopy = categoryNameBufSize - 1;
            if (numCharsToCopy>resCategoryName.size()) numCharsToCopy = resCategoryName.size();
            resCategoryName.copy( categoryNameBuf, numCharsToCopy );
            categoryNameBuf[numCharsToCopy] = 0;
            return numCharsToCopy+1;
           }
        catch(...) { }
        return 0;
       }

    CLIMETHOD(enumCategories) (THIS_ SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                   , CLISTR*           categoryName
                              )
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(2, categoryName );

        std::string resCategoryNameTmp;
        if (!enumCategoriesImpl( categoryIdx, resCategoryNameTmp ))
           return EC_COMPONENT_NOT_FOUND;
        return ::cli::propertyGetImpl( categoryName, MARTY_UTF::fromUtf8(resCategoryNameTmp) );

        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD_(SIZE_T, enumCategoryComponentsMbs) (THIS_ const CHAR*    categoryId /* [in,flat] char  categoryId[]  */
                                                       , SIZE_T    componentIdx /* [in] size_t  componentIdx  */
                                                       , SIZE_T    componentNameBufSize /* [in] size_t  componentNameBufSize  */
                                                       , CHAR*    componentNameBuf /* [out,flat,optional] char componentNameBuf[]  */
                                                  )
       {
        try{
            if (!categoryId) return 0;
    
            std::string resComponentName;
            if (!enumCategoryComponentsImpl( stdstr(categoryId), componentIdx, resComponentName ))
               return 0;
    
            if (!componentNameBufSize)
               return resComponentName.size()+1;
    
            SIZE_T numCharsToCopy = componentNameBufSize - 1;
            if (numCharsToCopy>resComponentName.size()) numCharsToCopy = resComponentName.size();
            resComponentName.copy( componentNameBuf, numCharsToCopy );
            componentNameBuf[numCharsToCopy] = 0;
            return numCharsToCopy+1;
           }
        catch(...) { }
        return 0;
       }

    CLIMETHOD_(SIZE_T, enumCategoryComponentsBuf) (THIS_ const WCHAR*    categoryId /* [in,flat] wchar  categoryId[]  */
                                                       , SIZE_T    componentIdx /* [in] size_t  componentIdx  */
                                                       , SIZE_T    componentNameBufSize /* [in] size_t  componentNameBufSize  */
                                                       , WCHAR*    componentNameBuf /* [out,flat,optional] wchar componentNameBuf[]  */
                                                  )
       {
        try{
            if (!categoryId) return 0;
    
            std::string resComponentNameTmp;
            if (!enumCategoryComponentsImpl( MARTY_UTF::toUtf8(stdstr(categoryId)), componentIdx, resComponentNameTmp ))
               return 0;
    
            std::wstring resComponentName = MARTY_UTF::fromUtf8(resComponentNameTmp);
            SIZE_T numCharsToCopy = componentNameBufSize - 1;
            if (numCharsToCopy>resComponentName.size()) numCharsToCopy = resComponentName.size();
            resComponentName.copy( componentNameBuf, numCharsToCopy );
            componentNameBuf[numCharsToCopy] = 0;
            return numCharsToCopy+1;
           }
        catch(...) { }
        return 0;
       }

    CLIMETHOD(enumCategoryComponents) (THIS_ const CLISTR*     categoryId
                                           , SIZE_T    componentIdx /* [in] size_t  componentIdx  */
                                           , CLISTR*           componentName
                                      )
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, categoryId );
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(3, componentName );

        std::string resComponentNameTmp;
        if (!enumCategoryComponentsImpl( MARTY_UTF::toUtf8(stdstr(categoryId)), componentIdx, resComponentNameTmp ))
           return EC_COMPONENT_NOT_FOUND;
        return ::cli::propertyGetImpl( componentName, MARTY_UTF::fromUtf8(resComponentNameTmp) );

        CLIMETHOD_IMPL_END();
       }


    CLIMETHOD_(SIZE_T, getComponentDescriptionMbs) (THIS_ const CHAR*    componentId /* [in,flat] char  componentId[]  */
                                                        , const WCHAR*    requestedLang /* [in,flat] wchar  requestedLang[]  */
                                                        , BOOL         findExactLang
                                                        , SIZE_T    descriptionBufSize /* [in] size_t  descriptionBufSize  */
                                                        , WCHAR*    descriptionBuf /* [out,flat,optional] wchar descriptionBuf[]  */
                                                   )
       {
        try{
            if (!componentId) return 0;
    
            std::wstring descriptionStr;
            if (!getComponentDescriptionImpl( stdstr(componentId), requestedLang ? stdstr(requestedLang) : std::wstring(), findExactLang, descriptionStr ))
               return 0;
    
            if (!descriptionBufSize)
               return descriptionStr.size()+1;
    
            SIZE_T numCharsToCopy = descriptionBufSize - 1;
            if (numCharsToCopy>descriptionStr.size()) numCharsToCopy = descriptionStr.size();
            descriptionStr.copy( descriptionBuf, numCharsToCopy );
            descriptionBuf[numCharsToCopy] = 0;
            return numCharsToCopy+1;
           }
        catch(...) { }
        return 0;
       }

    CLIMETHOD_(SIZE_T, getComponentDescriptionBuf) (THIS_ const WCHAR*    componentId /* [in,flat] wchar  componentId[]  */
                                                        , const WCHAR*    requestedLang /* [in,flat] wchar  requestedLang[]  */
                                                        , BOOL         findExactLang
                                                        , SIZE_T    descriptionBufSize /* [in] size_t  descriptionBufSize  */
                                                        , WCHAR*    descriptionBuf /* [out,flat,optional] wchar descriptionBuf[]  */
                                                   )
       {
        try{
            if (!componentId) return 0;

            std::wstring descriptionStr;
            if (!getComponentDescriptionImpl( MARTY_UTF::toUtf8(stdstr(componentId)), requestedLang ? stdstr(requestedLang) : std::wstring(), findExactLang, descriptionStr ))
               return 0;

            if (!descriptionBufSize)
               return descriptionStr.size()+1;

            SIZE_T numCharsToCopy = descriptionBufSize - 1;
            if (numCharsToCopy>descriptionStr.size()) numCharsToCopy = descriptionStr.size();
            descriptionStr.copy( descriptionBuf, numCharsToCopy );
            descriptionBuf[numCharsToCopy] = 0;
            return numCharsToCopy+1;
           }
        catch(...) { }
        return 0;
       }

    CLIMETHOD(getComponentDescription) (THIS_ const CLISTR*     componentId
                                            , const CLISTR*     requestedLang
                                            , BOOL         findExactLang
                                            , CLISTR*           descriptionStr
                                       )
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, componentId );
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(3, descriptionStr );

        std::wstring resDescriptionStr;
        if (!getComponentDescriptionImpl( MARTY_UTF::toUtf8(stdstr(componentId)), requestedLang ? stdstr(requestedLang) : std::wstring(), findExactLang, resDescriptionStr ))
           return EC_COMPONENT_NOT_FOUND;

        return ::cli::propertyGetImpl( descriptionStr, resDescriptionStr );

        CLIMETHOD_IMPL_END();
       }


/*
                EXTERN_CLI
                CLIAPIENTRY
                SIZE_T
                CLICALL
                cliGetComponentDecsription( CHAR const * componentId
                                          , const WCHAR* requestedLang
                                          , SIZE_T bufSize
                                          , WCHAR *componentDescriptionBuf
                                          )
*/

}; // struct CComponentManagerImpl


}; // namespace impl
}; // namespace cli



#endif /* SRC_CORE_CORESERVICES_H */

