#define CLI_STANDALONE_CLIPONENTS_DATADOM

/*!
\project Datadom components
    \libraries
    \libpath 
    \incpath

\platform linux
    \libraries cli2

\platform mingw
    \libraries cli2

\platform win32
    \libraries cli2

*/



#ifndef CLI_VARIANTIMPL_H
    #include "variantImpl.h"
#endif

//#ifdef CLI_BUILTIN_CLIPONENTS_DATADOM
    #include "datadom.h"
//#endif


/*
#if defined(WIN32) || defined(_WIN32)
    #ifdef WIN32_ON_DYN_MODULE_THREAD_DETACH
        #undef WIN32_ON_DYN_MODULE_THREAD_DETACH
    #endif
    #define WIN32_ON_DYN_MODULE_THREAD_DETACH() cliCallTlsDestructorFunction( )
#endif
*/

/*
#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif
*/


DECLARE_COMPONENT_CREATION_PROC( create_cli_datanodelist       , ::cli::impl::CDataNodeListImpl     , INTERFACE_CLI_IDATANODELIST )
DECLARE_COMPONENT_CREATION_PROC( create_cli_datanode           , ::cli::impl::CDataNodeImpl         , INTERFACE_CLI_IDATANODE )
DECLARE_COMPONENT_CREATION_PROC( create_cli_dataxpathquery     , ::cli::impl::CDataXPathQueryImpl   , INTERFACE_CLI_IDATAXPATHQUERY )
DECLARE_COMPONENT_CREATION_PROC( create_cli_dataroot           , ::cli::impl::CDataRootImpl         , INTERFACE_CLI_IDATAROOT )

CLI_BEGIN_COMPONENT_TABLE()
      CLI_COMPONENT_TABLE_ENTRY1("/cli/datanodelist"  , create_cli_datanodelist  , INTERFACE_CLI_IDATANODELIST_IID, "en:DataDom - DataDom/DataNodeList - a list of data nodes;"),
      CLI_COMPONENT_TABLE_ENTRY1("/cli/datanode"      , create_cli_datanode      , INTERFACE_CLI_IDATANODE_IID, "en:DataDom - DataDom node;"),
      CLI_COMPONENT_TABLE_ENTRY1("/cli/dataxpathquery", create_cli_dataxpathquery, INTERFACE_CLI_IDATAXPATHQUERY_IID, "en:DataDom - XPath Query;"),
      CLI_COMPONENT_TABLE_ENTRY2("/cli/dataroot"      , create_cli_dataroot      , INTERFACE_CLI_IDATAROOT_IID, INTERFACE_CLI_IDATANODE_IID, "en:DataDom - Data root;"),
CLI_END_COMPONENT_TABLE(registerCliDataDomModule, "clidatadom")
