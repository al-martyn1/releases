#ifndef SRC_CORE_THHLP_H
#define SRC_CORE_THHLP_H

/* add this lines to your scr
#ifndef SRC_CORE_THHLP_H
    #include "src/core/thhlp.h"
#endif
*/

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif
#ifndef MARTY_FILESYS_H
    #include <marty/filesys.h>
#endif
#include <marty/libapi.h>



#if defined(WIN32) || defined(_WIN32)

#include <windows.h>
#include <TlHelp32.h>

namespace cli
{

typedef HANDLE (WINAPI *CreateToolhelp32SnapshotProcT)( DWORD dwFlags, DWORD th32ProcessID );
typedef BOOL   (WINAPI *Module32FirstProcT)( HANDLE hSnapshot, LPMODULEENTRY32 lpme);
typedef BOOL   (WINAPI *Module32NextProcT )( HANDLE hSnapshot, LPMODULEENTRY32 lpme);

struct CEnumModulesApi
{
    CreateToolhelp32SnapshotProcT  CreateToolhelp32SnapshotProc;
    Module32FirstProcT             Module32FirstProc           ;
    Module32NextProcT              Module32NextProc            ;
    
};


inline
bool getEnumModulesApi( CEnumModulesApi *pApi )
{
    if (!pApi) return false;

    HINSTANCE hInst = GetModuleHandle(_T("KERNEL32"));
    if (!hInst) return false;

    pApi->CreateToolhelp32SnapshotProc = (CreateToolhelp32SnapshotProcT)GetProcAddress(hInst, "CreateToolhelp32Snapshot");
    pApi->Module32FirstProc            = (Module32FirstProcT           )GetProcAddress(hInst, "Module32First");
    pApi->Module32NextProc             = (Module32NextProcT            )GetProcAddress(hInst, "Module32Next");
    return pApi->CreateToolhelp32SnapshotProc!=0 &&
           pApi->Module32FirstProc           !=0 &&
           pApi->Module32NextProc            !=0 ;
}


struct CProcessModulesSnapshot
{
    HANDLE           hSnapshot;
    CEnumModulesApi *pApi;

    CProcessModulesSnapshot( CEnumModulesApi *p_pApi, DWORD dwPID ) : hSnapshot(INVALID_HANDLE_VALUE), pApi(p_pApi)
    {
        hSnapshot = pApi->CreateToolhelp32SnapshotProc( TH32CS_SNAPMODULE, dwPID );
    }

    ~CProcessModulesSnapshot()
    {
        if (isValid()) ::CloseHandle(hSnapshot);
    }

    bool isValid() const
    {
        return hSnapshot!=INVALID_HANDLE_VALUE;
    }

    BOOL moduleFirst( LPMODULEENTRY32 lpme )
    {
        return pApi->Module32FirstProc( hSnapshot, lpme );
    }

    BOOL moduleNext( LPMODULEENTRY32 lpme )
    {
        return pApi->Module32NextProc( hSnapshot, lpme );
    }
};


//MARTY_LIBAPI::

struct CMemModuleInfo
{
    typedef ::std::basic_string< TCHAR, 
                                 ::std::char_traits<TCHAR>, 
                                 ::std::allocator<TCHAR> >  tstring;

    ABSTRACT_MODULE_HANDLE       moduleHandle;
    tstring                      moduleName;
    tstring                      modulePath;

    CMemModuleInfo() : moduleHandle(0), moduleName(), modulePath() {}
    CMemModuleInfo(ABSTRACT_MODULE_HANDLE mh, const tstring &mn) : moduleHandle(mh), moduleName(mn), modulePath() {}
    CMemModuleInfo(ABSTRACT_MODULE_HANDLE mh, const tstring &mn, const tstring &mp) : moduleHandle(mh), moduleName(mn), modulePath(mp) {}
    CMemModuleInfo(const CMemModuleInfo &mi) : moduleHandle(mi.moduleHandle), moduleName(mi.moduleName), modulePath(mi.modulePath) {}
    CMemModuleInfo& operator=(const CMemModuleInfo &mi)
    {
        if (&mi==this) return *this;
        moduleHandle = mi.moduleHandle;
        moduleName   = mi.moduleName;
        modulePath   = mi.modulePath;
        return *this;
    }
};


inline
void enumMemoryModules( std::vector< CMemModuleInfo > &modulesInfo )
{
    CEnumModulesApi enumApi;
    if (!getEnumModulesApi( &enumApi )) return;

    CProcessModulesSnapshot snapshot( &enumApi, GetCurrentProcessId() );
    if (!snapshot.isValid()) return;

    MODULEENTRY32 me;
    me.dwSize = sizeof( me ); 

    if (!snapshot.moduleFirst(&me)) return;
    do {
        modulesInfo.push_back(CMemModuleInfo( me.hModule, me.szModule, me.szExePath));
    } while( snapshot.moduleNext(&me) );

}

}; // namespace cli

#else // end if WIN32


namespace cli
{

struct CMemModuleInfo
{
    typedef ::std::basic_string< TCHAR, 
                                 ::std::char_traits<TCHAR>, 
                                 ::std::allocator<TCHAR> >  tstring;

    ABSTRACT_MODULE_HANDLE       moduleHandle;
    tstring                      moduleName;
    tstring                      modulePath;

    CMemModuleInfo() : moduleHandle(0), moduleName(), modulePath() {}
    CMemModuleInfo(ABSTRACT_MODULE_HANDLE mh, const tstring &mn) : moduleHandle(mh), moduleName(mn), modulePath() {}
    CMemModuleInfo(ABSTRACT_MODULE_HANDLE mh, const tstring &mn, const tstring &mp) : moduleHandle(mh), moduleName(mn), modulePath(mp) {}
    CMemModuleInfo(const CMemModuleInfo &mi) : moduleHandle(mi.moduleHandle), moduleName(mi.moduleName), modulePath(mi.modulePath) {}
    CMemModuleInfo& operator=(const CMemModuleInfo &mi)
    {
        if (&mi==this) return *this;
        moduleHandle = mi.moduleHandle;
        moduleName   = mi.moduleName;
        modulePath   = mi.modulePath;
        return *this;
    }
};

inline
void enumMemoryModules( std::vector< CMemModuleInfo > &modulesInfo )
{
    //::std::string selfMaps;
    //if (!procfs::readSelfMaps( selfMaps )) return;

    ::std::vector< MARTY_LIBAPI::procfs::CMemMapItem > memMap;
    MARTY_LIBAPI::procfs::parseSelfMaps(memMap);

    //std::map< std::string, void* > pushedMods;
    std::set<std::string>          pushedMods;

    {
     ::std::string selfExeName;
     if (MARTY_LIBAPI::procfs::readProcSelfExeName(selfExeName))
        {
         pushedMods.insert(selfExeName);
        }
    }

    ::std::vector<MARTY_LIBAPI::procfs::CMemMapItem>::const_iterator mmIt = memMap.begin();
    for(; mmIt != memMap.end(); ++mmIt)
       {
        // mem block must have X (executable) attribute
        // must have iNode
        // must have name
        if (!(mmIt->perms & MARTY_LIBAPI::procfs::CMemMapItem::permExecute)) continue;
        if (!mmIt->iNode) continue;
        if (mmIt->pathname.empty() || mmIt->pathname[0]!='/') continue; // not a file

        ABSTRACT_MODULE_HANDLE mHandle = MARTY_LIBAPI::getModuleHandle( mmIt->pathname, false ); // use local
        /*
        if (!mHandle) 
           {
            mHandle = MARTY_LIBAPI::getModuleHandle( mmIt->pathname, true ); // try global
            #ifdef DL_DEBUG
            printf("try global\n");
            #endif
           }
        */
        if (!mHandle) 
           {
            #ifdef DL_DEBUG
            printf("getModuleHandle returned 0 for %s - error: %s\n", mmIt->pathname.c_str(), dlerror());
            #endif
            continue;
           }

        modulesInfo.push_back(CMemModuleInfo( mHandle, MARTY_FILENAME::getFile(mmIt->pathname), mmIt->pathname ));

        /*
        Dl_info info;
        int dladdrRes = dladdr((void*)(mmIt->startAddr), &info);
        if (!dladdrRes) continue;

        std::string modName = info.dli_fname;
        void *modBase       = info.dli_fbase;

        if (pushedMods.find(modName)!=pushedMods.end()) continue;

        #if defined(UNICODE) || defined(_UNICODE)
        std::string modNameW;
        MARTY_FILESYSTEM::filenameDecode( modNameW, modName );
        modulesInfo.push_back(CMemModuleInfo( modBase, MARTY_FILENAME::getFile(modNameW), modNameW));
        #else
        modulesInfo.push_back(CMemModuleInfo( modBase, MARTY_FILENAME::getFile(modName), modName));
        #endif
        */
       }
}


}; // namespace cli

#endif



#endif /* SRC_CORE_THHLP_H */

