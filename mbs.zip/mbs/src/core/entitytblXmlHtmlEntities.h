struct CXmlHtmlEntitiesEntityProcessing : public CEntityProcessingBase {

    static  wchar_t entityChars[50];
    static  unsigned charToEntity[50];
    static  const wchar_t *entities[50];
    static  wchar_t entityToChar[50];


    const wchar_t* getEntitiesCharString() const
       {
        return &entityChars[0];
       }


    // convert entiry name to char
    bool convertEntityToChar( const std::wstring &entityName, std::wstring &val ) const
       {
        const wchar_t ** pBegin = &entities[0];
        const wchar_t ** pEnd   = pBegin + 49;
        const wchar_t **pFoundEntityName = (const wchar_t **)util::binary_find( pBegin, pEnd, entityName.c_str(), wstringLess );
        if (pFoundEntityName!=pEnd)
           {
            SIZE_T entityIdx = pFoundEntityName - &entities[0];
            val.assign(1,entityToChar[entityIdx]);
            return true;
           }
        return false;
       }


    // convert entiry char to entity name
    bool convertCharToEntity( wchar_t ch, std::wstring &entityNameAppendTo ) const
       {
        const wchar_t* pEntityChar = util::binary_find( entityChars, entityChars+49, ch );
        if (pEntityChar!=(entityChars+49))
           {
            SIZE_T charIdx = (pEntityChar - entityChars);
            SIZE_T entityIdx = charToEntity[charIdx];
            entityNameAppendTo.append(entities[entityIdx]);
            return true;
           }
        return false;
       }


}; // struct CXmlHtmlEntitiesEntityProcessing

wchar_t CXmlHtmlEntitiesEntityProcessing::entityChars[50] = {
  0xA0, // 0  (nbsp)
  0xA1, // 1  (iexcl)
  0xA2, // 2  (cent)
  0xA3, // 3  (pound)
  0xA4, // 4  (curren)
  0xA5, // 5  (yen)
  0xA6, // 6  (brvbar)
  0xA7, // 7  (sect)
  0xA8, // 8  (uml)
  0xA9, // 9  (copy)
  0xAB, // 10  (laquo)
  0xAC, // 11  (not)
  0xAD, // 12  (shy)
  0xAE, // 13  (reg)
  0xB0, // 14  (deg)
  0xB1, // 15  (plusmn)
  0xB2, // 16  (sup2)
  0xB3, // 17  (sup3)
  0xB4, // 18  (acute)
  0xB5, // 19  (micro)
  0xB6, // 20  (para)
  0xB7, // 21  (middot)
  0xB8, // 22  (cedil)
  0xB9, // 23  (sup1)
  0xBB, // 24  (raquo)
  0xBC, // 25  (frac14)
  0xBD, // 26  (frac12)
  0xBE, // 27  (frac34)
  0xBF, // 28  (iquest)
  0x02C6, // 29  (circ)
  0x02DC, // 30  (tilde)
  0x2002, // 31  (ensp)
  0x2003, // 32  (emsp)
  0x2009, // 33  (thinsp)
  0x2013, // 34  (ndash)
  0x2014, // 35  (mdash)
  0x2018, // 36  (lsquo)
  0x2019, // 37  (rsquo)
  0x201A, // 38  (sbquo)
  0x201C, // 39  (ldquo)
  0x201D, // 40  (rdquo)
  0x201E, // 41  (bdquo)
  0x2030, // 42  (permil)
  0x2039, // 43  (lsaquo)
  0x203A, // 44  (rsaquo)
  0x20AC, // 45  (euro)
  0x2122, // 46  (trade)
  0x2264, // 47  (le)
  0x2265, // 48  (ge)
  0
};

unsigned CXmlHtmlEntitiesEntityProcessing::charToEntity[50] = {
  26, // 0  (nbsp)
  16, // 1  (iexcl)
  4, // 2  (cent)
  32, // 3  (pound)
  7, // 4  (curren)
  48, // 5  (yen)
  2, // 6  (brvbar)
  39, // 7  (sect)
  47, // 8  (uml)
  6, // 9  (copy)
  18, // 10  (laquo)
  28, // 11  (not)
  40, // 12  (shy)
  35, // 13  (reg)
  8, // 14  (deg)
  31, // 15  (plusmn)
  42, // 16  (sup2)
  43, // 17  (sup3)
  0, // 18  (acute)
  24, // 19  (micro)
  29, // 20  (para)
  25, // 21  (middot)
  3, // 22  (cedil)
  41, // 23  (sup1)
  33, // 24  (raquo)
  13, // 25  (frac14)
  12, // 26  (frac12)
  14, // 27  (frac34)
  17, // 28  (iquest)
  5, // 29  (circ)
  45, // 30  (tilde)
  10, // 31  (ensp)
  9, // 32  (emsp)
  44, // 33  (thinsp)
  27, // 34  (ndash)
  23, // 35  (mdash)
  22, // 36  (lsquo)
  37, // 37  (rsquo)
  38, // 38  (sbquo)
  19, // 39  (ldquo)
  34, // 40  (rdquo)
  1, // 41  (bdquo)
  30, // 42  (permil)
  21, // 43  (lsaquo)
  36, // 44  (rsaquo)
  11, // 45  (euro)
  46, // 46  (trade)
  20, // 47  (le)
  15, // 48  (ge)
  0xFA
};

const wchar_t* CXmlHtmlEntitiesEntityProcessing::entities[50] = {
  L"acute", // 0 (0xB4)
  L"bdquo", // 1 (0x201E)
  L"brvbar", // 2 (0xA6)
  L"cedil", // 3 (0xB8)
  L"cent", // 4 (0xA2)
  L"circ", // 5 (0x02C6)
  L"copy", // 6 (0xA9)
  L"curren", // 7 (0xA4)
  L"deg", // 8 (0xB0)
  L"emsp", // 9 (0x2003)
  L"ensp", // 10 (0x2002)
  L"euro", // 11 (0x20AC)
  L"frac12", // 12 (0xBD)
  L"frac14", // 13 (0xBC)
  L"frac34", // 14 (0xBE)
  L"ge", // 15 (0x2265)
  L"iexcl", // 16 (0xA1)
  L"iquest", // 17 (0xBF)
  L"laquo", // 18 (0xAB)
  L"ldquo", // 19 (0x201C)
  L"le", // 20 (0x2264)
  L"lsaquo", // 21 (0x2039)
  L"lsquo", // 22 (0x2018)
  L"mdash", // 23 (0x2014)
  L"micro", // 24 (0xB5)
  L"middot", // 25 (0xB7)
  L"nbsp", // 26 (0xA0)
  L"ndash", // 27 (0x2013)
  L"not", // 28 (0xAC)
  L"para", // 29 (0xB6)
  L"permil", // 30 (0x2030)
  L"plusmn", // 31 (0xB1)
  L"pound", // 32 (0xA3)
  L"raquo", // 33 (0xBB)
  L"rdquo", // 34 (0x201D)
  L"reg", // 35 (0xAE)
  L"rsaquo", // 36 (0x203A)
  L"rsquo", // 37 (0x2019)
  L"sbquo", // 38 (0x201A)
  L"sect", // 39 (0xA7)
  L"shy", // 40 (0xAD)
  L"sup1", // 41 (0xB9)
  L"sup2", // 42 (0xB2)
  L"sup3", // 43 (0xB3)
  L"thinsp", // 44 (0x2009)
  L"tilde", // 45 (0x02DC)
  L"trade", // 46 (0x2122)
  L"uml", // 47 (0xA8)
  L"yen", // 48 (0xA5)
  L"END"
};

wchar_t CXmlHtmlEntitiesEntityProcessing::entityToChar[50] = {
  0xB4, // 0 (acute)
  0x201E, // 1 (bdquo)
  0xA6, // 2 (brvbar)
  0xB8, // 3 (cedil)
  0xA2, // 4 (cent)
  0x02C6, // 5 (circ)
  0xA9, // 6 (copy)
  0xA4, // 7 (curren)
  0xB0, // 8 (deg)
  0x2003, // 9 (emsp)
  0x2002, // 10 (ensp)
  0x20AC, // 11 (euro)
  0xBD, // 12 (frac12)
  0xBC, // 13 (frac14)
  0xBE, // 14 (frac34)
  0x2265, // 15 (ge)
  0xA1, // 16 (iexcl)
  0xBF, // 17 (iquest)
  0xAB, // 18 (laquo)
  0x201C, // 19 (ldquo)
  0x2264, // 20 (le)
  0x2039, // 21 (lsaquo)
  0x2018, // 22 (lsquo)
  0x2014, // 23 (mdash)
  0xB5, // 24 (micro)
  0xB7, // 25 (middot)
  0xA0, // 26 (nbsp)
  0x2013, // 27 (ndash)
  0xAC, // 28 (not)
  0xB6, // 29 (para)
  0x2030, // 30 (permil)
  0xB1, // 31 (plusmn)
  0xA3, // 32 (pound)
  0xBB, // 33 (raquo)
  0x201D, // 34 (rdquo)
  0xAE, // 35 (reg)
  0x203A, // 36 (rsaquo)
  0x2019, // 37 (rsquo)
  0x201A, // 38 (sbquo)
  0xA7, // 39 (sect)
  0xAD, // 40 (shy)
  0xB9, // 41 (sup1)
  0xB2, // 42 (sup2)
  0xB3, // 43 (sup3)
  0x2009, // 44 (thinsp)
  0x02DC, // 45 (tilde)
  0x2122, // 46 (trade)
  0xA8, // 47 (uml)
  0xA5, // 48 (yen)
  0xFA
};

