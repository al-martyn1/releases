#define CLICOMPONENTINFO_CONST_FIELD

#include <cli/cli2base.h>
#include <cli/csec.h>

#ifndef CLI_CLIERR_H
    #include <cli/clierr.h>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#include <cli/cliutilx.h>
//#include <marty/filename.h>
#include <marty/libapi.h>

#ifdef _WIN32
    #include <marty/winapi.h>
#endif


#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif  

#include <cli/tickcount.h>

#include <cli/cliexcept.h>

#ifndef SRC_CORE_FLATSTRUTILS_H
    #include "flatStrUtils.h"
#endif

#ifndef SRC_CORE_LANGUTIL_H
    #include "langUtil.h"
#endif

#ifndef SRC_CORE_THHLP_H
    #include "thhlp.h"
#endif

#include "modInfoCppImpl.h"
#include "cli2init.h"


//-----------------------------------------------------------------------------
#ifdef _WIN32
::std::wstring formatWinError(unsigned err)
   {
    wchar_t buf[1024];
    return ::std::wstring(MARTY_WINAPI_NS formatMessageW(err, buf, sizeof(buf)/sizeof(buf[0])));
   }
#endif

typedef ::std::basic_string< TCHAR, 
                             ::std::char_traits<TCHAR>, 
                             ::std::allocator<TCHAR> >  tstring;

typedef ::cli::util::CIdMap<tstring, MARTY_FILENAME_NS predLess> module_map_t;

::cli::CCliOptions* getCliRuntimeOptions();

struct CComponentInfo
{
    ::std::string                         componentName;
    std::vector<std::string>              componentCategories;
    std::map<std::string, std::string>    componentDescription;
    module_map_t::size_type               moduleId;
};

bool operator<(const CComponentInfo &c1, const CComponentInfo &c2)
   {
    return c1.componentName < c2.componentName;
   }

struct CModuleInfo
{
    ABSTRACT_MODULE_HANDLE    handle;
    cli_create_proc_t         legacyCreationProc;
    CliCreateProcT            creationProc;
    CliCanUnloadProcT         testUnloadProc;

    CModuleInfo() 
       : handle(0)
       , legacyCreationProc(0)
       , creationProc(0) 
       , testUnloadProc(0)
       {}

    CModuleInfo(const CModuleInfo &mi) 
       : handle(mi.handle)
       , legacyCreationProc(mi.legacyCreationProc)
       , creationProc(mi.creationProc)
       , testUnloadProc(mi.testUnloadProc)
       {}

    CModuleInfo& operator=(const CModuleInfo &mi)
       {
        if (&mi==this) return *this;
        handle = mi.handle;
        legacyCreationProc = mi.legacyCreationProc;
        creationProc = mi.creationProc;
        return *this;
       }
};


//-----------------------------------------------------------------------------
// lock critical sections listed below only in same order as they are defined
static ::cli::CCriticalSection                            clCs(0, true);  // component list locker
static ::cli::CCriticalSection                            mlCs(0, true);  // module list locker
extern ::cli::CCriticalSection                            initCs; // init config guard (declared in cli2.cpp)

static module_map_t                                       modulesIdMap;
static ::std::map<module_map_t::size_type, CModuleInfo>   modulesInfo;
static ::std::vector<CComponentInfo>                      componentsInfo;
static ::std::map< ::std::string, ::std::vector< ::std::string > > categoryComponents;

//-----------------------------------------------------------------------------
CModuleInfo& getModuleInfo(module_map_t::size_type moduleId, bool &newlyLoaded);


CModuleInfo& getModuleInfo(module_map_t::size_type moduleId, bool &newlyLoaded)
   {
    CLI_AUTOLOCK_EX(modListLocker, mlCs);

    CModuleInfo& res = modulesInfo[moduleId];
    newlyLoaded = false;

    if (res.handle)
       {
        return res;
       }

    tstring modname = modulesIdMap.getKey(moduleId);
    res.handle = MARTY_LIBAPI_NS loadModule(modname);
    if (!res.handle)
       {
        CLI_AUTOLOCK_EX(initLocker, initCs);
        ::cli::CCliOptions* pOpts = ::cli::getCliRuntimeOptions();    
        pOpts->log()<<"Failed to load "<<modname<<" - ";
        #ifdef _WIN32
        pOpts->log()<<formatWinError(::GetLastError());
        #else
        pOpts->log()<<dlerror();
        #endif
        pOpts->log()<<"\n";       
       }

    newlyLoaded = true;
    return res;
   }

//-----------------------------------------------------------------------------
//CLI_ERR_UNKNOWN
RCODE
CLICALL
cliCreateObject( CHAR const * componentId
               , CHAR const * interfaceId
               , CLI_IUNKNOWN_PTR outer
               , GENERIC_OBJ_PTR *pRes
               )
   {
    CLI_TRY{
            if (outer)        { throw ::cli::CException( false, EC_NOT_IMPLEMENTED, __FILE__, __LINE__, ::cli::format::arg( 3) % L"outer" );  }
            if (!componentId) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"componentId" );  }
            if (!interfaceId) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"interfaceId" );  }
            if (!pRes)        { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 4) % L"pRes" );  }
               
            CLI_AUTOLOCK_EX(componentListLocker, clCs);
        
            CComponentInfo ci; ci.componentName = componentId;
        
            ::std::vector<CComponentInfo>::const_iterator cit = ::cli::util::binary_find(componentsInfo.begin(), componentsInfo.end(), ci);
        
            CLI_AUTOLOCK_EX(modListLocker, mlCs);
        
            if (cit==componentsInfo.end())
               {
                CLI_AUTOLOCK_EX(initLocker, initCs);
                ::cli::CCliOptions* pOpts = ::cli::getCliRuntimeOptions();
                pOpts->log()<<"Failed to find info for component '"<<componentId<<"' - unknown component\n";
                throw ::cli::CException( false, EC_COMPONENT_NOT_FOUND, __FILE__, __LINE__, ::cli::format::arg(componentId) );
                //return CLI_ERR_UNKNOWN;
               }
        
            bool newlyLoaded = false;
            CModuleInfo& modInfo = getModuleInfo(cit->moduleId, newlyLoaded);
            if (!modInfo.handle)
               {
                CLI_AUTOLOCK_EX(initLocker, initCs);
                ::cli::CCliOptions* pOpts = ::cli::getCliRuntimeOptions();
                pOpts->log()<<"Failed to create component '"<<componentId<<"' - can't load apropriate module\n";
                throw ::cli::CException( false, EC_COMPONENT_MODULE_NOT_FOUND, __FILE__, __LINE__, ::cli::format::arg(componentId) );
                //return CLI_ERR_UNKNOWN;
               }
        
            // cli_create_proc_t         legacyCreationProc;
            // CliCreateProcT            creationProc;
            // CliCanUnloadProcT         testUnloadProc;
            if (!modInfo.legacyCreationProc)
               {
                modInfo.legacyCreationProc = (cli_create_proc_t)MARTY_LIBAPI_NS getProcAddress(modInfo.handle, LEGACY_CLICREATEPROCNAME);
               }
        
            if (!modInfo.legacyCreationProc)
               {
                CLI_AUTOLOCK_EX(initLocker, initCs);
                ::cli::CCliOptions* pOpts = ::cli::getCliRuntimeOptions();
                ::std::string moduleFilename;
                MARTY_LIBAPI_NS getModuleFileName(modInfo.handle, moduleFilename);
                pOpts->log()<<"Failed to create component '"<<componentId<<"' - there is no entry point "<<LEGACY_CLICREATEPROCNAME<<" in module "<<moduleFilename<<"\n";
        
                // unload bad module
                if (newlyLoaded)
                   {
                    MARTY_LIBAPI_NS freeModule(modInfo.handle);
                    modInfo.handle = 0;
                   }
                throw ::cli::CException( false, EC_COMPONENT_MODULE_NO_ENTRY, __FILE__, __LINE__, ::cli::format::arg(componentId) );
               }
        
            CLI_IUNKNOWN_PTR resPtr = (CLI_IUNKNOWN_PTR)modInfo.legacyCreationProc(componentId, interfaceId, outer);
            if (!resPtr)
               {
                //CLI_AUTOLOCK_EX(initLocker, initCs);
                //::cli::CCliOptions* pOpts = getCliRuntimeOptions();
                //pOpts->log()<<"Failed to create component '"<<componentId<<"' - there is no entry point "<<LEGACY_CLICREATEPROCNAME<<" in module "<<MARTY_LIBAPI_NS getModuleFileName(modInfo.handle)<<"\n";
        
                // unload bad module
                if (newlyLoaded)
                   {
                    MARTY_LIBAPI_NS freeModule(modInfo.handle);
                    modInfo.handle = 0;
                   }
                *pRes = resPtr;
                throw ::cli::CException( false, EC_COMPONENT_CREATION_FAILED, __FILE__, __LINE__, ::cli::format::arg(componentId) );
               }

            *pRes = resPtr;
            return 0; // resPtr;
           }
    CLI_CATCH_RETURN_CLI_EXCEPTION()
    CLI_CATCH_RETURN_STD_EXCEPTIONS()
    return EC_OK;

   }
//-----------------------------------------------------------------------------
/*
GENERIC_OBJ_PTR
CLICALL
cli_create( CHAR const * componentId, 
          CHAR const * interfaceId, 
          GENERIC_OBJ_PTR outer)
   {
    GENERIC_OBJ_PTR resPtr = 0;
    RCODE res = cliCreateObject( componentId, interfaceId, outer, &resPtr );
    if (res) return 0;
    return resPtr;


    if (outer) return 0; // not supported feature now

    if (!componentId || !interfaceId) return 0; // error, UNDONE: make error reporting with extended err info 

    CLI_AUTOLOCK_EX(componentListLocker, clCs);

    CComponentInfo ci; ci.componentName = componentId;

    ::std::vector<CComponentInfo>::const_iterator cit = ::cli::util::binary_find(componentsInfo.begin(), componentsInfo.end(), ci);

    CLI_AUTOLOCK_EX(modListLocker, mlCs);

    if (cit==componentsInfo.end())
       {
        CLI_AUTOLOCK_EX(initLocker, initCs);
        ::cli::CCliOptions* pOpts = getCliRuntimeOptions();
        pOpts->log()<<"Failed to find info for component '"<<componentId<<"' - unknown component\n";
        return 0;
       }

    bool newlyLoaded = false;
    CModuleInfo& modInfo = getModuleInfo(cit->moduleId, newlyLoaded);
    if (!modInfo.handle)
       {
        CLI_AUTOLOCK_EX(initLocker, initCs);
        ::cli::CCliOptions* pOpts = getCliRuntimeOptions();
        pOpts->log()<<"Failed to create component '"<<componentId<<"' - can't load apropriate module\n";
        return 0;
       }

    // cli_create_proc_t         legacyCreationProc;
    // CliCreateProcT            creationProc;
    // CliCanUnloadProcT         testUnloadProc;
    if (!modInfo.legacyCreationProc)
       {
        modInfo.legacyCreationProc = (cli_create_proc_t)MARTY_LIBAPI_NS getProcAddress(modInfo.handle, LEGACY_CLICREATEPROCNAME);
       }

    if (!modInfo.legacyCreationProc)
       {
        CLI_AUTOLOCK_EX(initLocker, initCs);
        ::cli::CCliOptions* pOpts = getCliRuntimeOptions();
        pOpts->log()<<"Failed to create component '"<<componentId<<"' - there is no entry point "<<LEGACY_CLICREATEPROCNAME<<" in module "<<MARTY_LIBAPI_NS getModuleFileName(modInfo.handle)<<"\n";

        // unload bad module
        if (newlyLoaded)
           {
            MARTY_LIBAPI_NS freeModule(modInfo.handle);
            modInfo.handle = 0;
           }
        return 0;
       }

    GENERIC_OBJ_PTR resPtr = modInfo.legacyCreationProc(componentId, interfaceId, outer);
    if (!resPtr)
       {
        //CLI_AUTOLOCK_EX(initLocker, initCs);
        //::cli::CCliOptions* pOpts = getCliRuntimeOptions();
        //pOpts->log()<<"Failed to create component '"<<componentId<<"' - there is no entry point "<<LEGACY_CLICREATEPROCNAME<<" in module "<<MARTY_LIBAPI_NS getModuleFileName(modInfo.handle)<<"\n";

        // unload bad module
        if (newlyLoaded)
           {
            MARTY_LIBAPI_NS freeModule(modInfo.handle);
            modInfo.handle = 0;
           }
       }

    return resPtr;
   }
*/

bool isFilenameExcludedByMask( const tstring &fullFilename
                             , const ::std::vector<tstring> &excludeFilesMasks
                             )
   {
    tstring filename = MARTY_FILENAME::getFile(fullFilename);

    ::std::vector<tstring>::const_iterator maskIt = excludeFilesMasks.begin();
    for(; maskIt != excludeFilesMasks.end(); ++maskIt)
       {
        #if defined(WIN32) || defined(_WIN32)
        if (MARTY_FILENAME::matchMaskI( filename, *maskIt ) )
        #else
        if (MARTY_FILENAME::matchMaskE( filename, *maskIt ) )
        #endif
           {
            return true; // excluded, no further processing needed
           }
       }
    return false;
   }

bool isFilenameExcludedByMask( const tstring &fullFilename
                             , const ::std::vector<tstring> &excludeFilesMasks
                             //, tstring &excludedByMask
                             , SIZE_T &maskId
                             )
   {
    tstring filename = MARTY_FILENAME::getFile(fullFilename);

    ::std::vector<tstring>::const_iterator maskIt = excludeFilesMasks.begin();
    for(; maskIt != excludeFilesMasks.end(); ++maskIt)
       {
        #if defined(WIN32) || defined(_WIN32)
        if (MARTY_FILENAME::matchMaskI( filename, *maskIt ) )
        #else
        if (MARTY_FILENAME::matchMaskE( filename, *maskIt ) )
        #endif
           {
            //excludedByMask = *maskIt;
            maskId = maskIt - excludeFilesMasks.begin();
            return true; // excluded, no further processing needed
           }
       }
    return false;
   }


inline void addModuleComponents( ::std::map< ::std::string, CComponentInfo> &componentsInfoQuickFinder
                               , const std::vector< ::cli::implx::CComponentInfo<TCHAR> > &infoList
                               , ::cli::CCliOptions* pOpts
                               )
   {
    std::vector< ::cli::implx::CComponentInfo<TCHAR> >::const_iterator ilIt = infoList.begin();
    for(; ilIt!=infoList.end(); ++ilIt)
       {
        ::std::map< ::std::string, CComponentInfo>::const_iterator qit = componentsInfoQuickFinder.find(ilIt->name);
        if (qit!=componentsInfoQuickFinder.end())
           { // component info allready exist
            tstring prevModName;
            if (!modulesIdMap.getKey(qit->second.moduleId, prevModName))
               {
                pOpts->log()<<"Internal error: can't find module name for id = "<<(int)qit->second.moduleId<<"\n";
                pOpts->log()<<"Component '"<<ilIt->name<<"' allready declared in module with id = "<<(int)qit->second.moduleId<<"\n";
               }
            else
               {
                pOpts->log()<<"Component '"<<ilIt->name<<"' allready declared in module '"<<prevModName<<"'\n";
               }
            continue; // next component
           }

        CComponentInfo newInfo;
        newInfo.moduleId              = modulesIdMap.getId(ilIt->moduleName);
        newInfo.componentName         = ilIt->name;
        newInfo.componentCategories   = ilIt->categories;
        newInfo.componentDescription  = ilIt->description;

        std::vector<std::string>::const_iterator ccIt = newInfo.componentCategories.begin();
        for(; ccIt!=newInfo.componentCategories.end(); ++ccIt)
           {
            categoryComponents[*ccIt].push_back(newInfo.componentName);
           }
        //::std::map< ::std::string, ::std::vector< ::std::string > >::iterator ccIt = categoryComponents;

        componentsInfoQuickFinder[newInfo.componentName] = newInfo;
        componentsInfo.push_back(newInfo);
       }
    }


//-----------------------------------------------------------------------------
void loadModulesInformation( const ::std::vector<tstring> &path
                           , const ::std::vector<tstring> &excludeModPath
                           , const ::std::vector<tstring> &extList
                           , const ::std::vector<tstring> &excludeFilesMasks
                           , bool clearComponentInfo
                           )
//void loadModulesInformation(const ::std::vector<tstring> &path, const ::std::vector<tstring> &extList, bool clearComponentInfo)
   {
    CLI_AUTOLOCK_EX(componentListLocker, clCs);

    if (clearComponentInfo)
       componentsInfo.erase(componentsInfo.begin(), componentsInfo.end());

    ::std::map< ::std::string, CComponentInfo> componentsInfoQuickFinder;
       {
        ::std::vector<CComponentInfo>::const_iterator cit = componentsInfo.begin();
        for(; cit!=componentsInfo.end(); ++cit)
           {
            componentsInfoQuickFinder[cit->componentName] = *cit;
           }
       }

    std::vector< cli::CMemModuleInfo > inMemoryModulesInfo;
    cli::enumMemoryModules( inMemoryModulesInfo );
    std::set< tstring > usedModules;

    /*
    std::vector< cli::CMemModuleInfo > modulesInfo;
    cli::enumMemoryModules( modulesInfo );

    std::vector< cli::CMemModuleInfo >::const_iterator mit = modulesInfo.begin();
    for(; mit != modulesInfo.end(); ++mit)

    ::std::basic_string<CharType, Traits, Allocator> MARTY_FILENAME::prepareForCompare( const ::std::basic_string<CharType, Traits, Allocator> &fileName
    */


    CLI_AUTOLOCK_EX(modListLocker, mlCs);
    CLI_AUTOLOCK_EX(initLocker, initCs);

    ::cli::CCliOptions* pOpts = ::cli::getCliRuntimeOptions();

    pOpts->log()<<"-------\nInitializing CLI2\n-------\n";

    pOpts->log()<<"---\nLooking for loaded modules\n---\n";

    pOpts->log()<<"Found "<<(int)inMemoryModulesInfo.size()<<" already loaded modules\n";

    std::vector< cli::CMemModuleInfo >::const_iterator inMemModIit = inMemoryModulesInfo.begin();
    for( ; inMemModIit != inMemoryModulesInfo.end(); ++inMemModIit)
       {
        tstring comparableModName = MARTY_FILENAME::prepareForCompare(inMemModIit->modulePath);
        if (usedModules.find(comparableModName)!=usedModules.end()) 
           {
            #if defined(DEBUG) || defined(_DEBUG)
            pOpts->log()<<"Module: "<<inMemModIit->modulePath<<" - already processed\n";
            #endif
            continue;
           }
        usedModules.insert(comparableModName);

        pOpts->log()<<"Processing module: "<<inMemModIit->modulePath<<" - ";

        std::vector< ::cli::implx::CComponentInfo<TCHAR> > infoList;
        RCODE errCode;
        tstring errMsg;

        #ifdef DL_DEBUG
        MARTY_LIBAPI::CModuleHandle hMod1(inMemModIit->moduleHandle);
        MARTY_LIBAPI::CModuleHandle hMod2(inMemModIit->modulePath.c_str());
        printf("h1: %p, h2: %p - %s\n", (void*)hMod1.get(), (void*)hMod2.get(), inMemModIit->modulePath.c_str() );
        #endif

        bool res = readComponentInfoFromModule( inMemModIit->modulePath
                                              , MARTY_LIBAPI::CModuleHandle(inMemModIit->moduleHandle)
                                              , infoList, &errCode, &errMsg );

        if (!res)
           {
            
            if (errCode && !errMsg.empty())
               {
                pOpts->log()<<"failed - is not a CLI2 module, error "<<(UINT)errCode<<" with message: "<<errMsg<<"\n";
               }
            else if (errCode)
               {
                pOpts->log()<<"failed - is not a CLI2 module, error "<<(UINT)errCode<<"\n";
               }
            else
               {
                pOpts->log()<<"failed - is not a CLI2 module\n";
               }
            
            continue;
           }

        pOpts->log()<<"Ok\n";

        addModuleComponents( componentsInfoQuickFinder, infoList, pOpts );
/*        
    ABSTRACT_MODULE_HANDLE       moduleHandle;
    tstring                      moduleName;
    tstring                      modulePath;
*/

       }

    bool useCache = pOpts->useCache();

    ::std::vector<tstring> masks;
    ::std::vector<tstring>::const_iterator elIt = extList.begin();
    for(; elIt!=extList.end(); ++elIt)
       {
        tstring mask(_T("*"));
        mask = MARTY_FILENAME_NS appendExtention(mask, *elIt);
        if (useCache)
           mask = MARTY_FILENAME_NS appendExtention(mask, tstring(CLI_MODULE_INFO_CACHE_SUFFIX));
        masks.push_back(mask);
       }

    if (masks.empty()) masks.push_back( tstring(_T("*.dll")) );

    TICK_T startFindModulesTick = cliGetTickCount();
    std::vector<MARTY_FILESYSTEM_NS CFindFileInfo<TCHAR> > matchedFiles;
    /*
    std::vector<tstring>       excludePathList; // empty exclusion list
    excludePathList.reserve(excludeModPath.size());
    ::std::vector<tstring>::const_iterator excludeIt = excludeModPath.begin();
    for( ; excludeIt != excludeModPath.end(); ++excludeIt )
       {
        std::map<tstring, tstring> tmpVars;
        excludePathList.push_back( MARTY_FILENAME::stripSlashCopy(::marty::macro::substMacroses(tmpVars, *excludeIt, false, false, &envCache) ) );
       }
    //excludeModPath

    std::string excludePaths;
    ::marty::env::getVar(::std::string("CLI2_MOD_PATH_EXCLUDE"), excludePaths);
    if (!excludePaths.empty())
       excludePaths.append(1, sep);

    */

    
    #if defined(ANDROID)
    bool allowExternalModules = false;
    #else
    bool allowExternalModules = true;
    #endif

    if (allowExternalModules)
       {
        ::std::string disableExternalModulesStr;
        ::marty::env::getVar(::std::string("CLI2_DISABLE_PLUGINS"), disableExternalModulesStr);
        if (!disableExternalModulesStr.empty())
           {
            if (disableExternalModulesStr=="1" || disableExternalModulesStr=="YES" || disableExternalModulesStr=="yes" || disableExternalModulesStr=="Yes"
               || disableExternalModulesStr=="DISABLE" || disableExternalModulesStr=="disable" || disableExternalModulesStr=="Disable"
               )
               allowExternalModules = false;
           }
       }

    if (!allowExternalModules)
       {
        pOpts->log()<<"---\nExternal modules disabled\n---\n";
       }
    else
       {
       
        pOpts->log()<<"---\nLooking for modules\n---\n";
    
        int findRes = MARTY_FILESYSTEM::findFilesPathListEx( matchedFiles
                                                           , path
                                                           , excludeModPath // excludePathList
                                                           , masks
                                                           , true // recurseSubdirs - TODO - add an environment flag to control this option
                                                           , false // forceCmpWithPath
                                                           , true  // threat excludePathList as masks
                                                           );
    
        TICK_T endFindModulesTick = cliGetTickCount();
        pOpts->log()<<"Found "<<(int)matchedFiles.size()<<" modules; ";
         
          {
           TICK_DIFF_T d = cliTickDiff( startFindModulesTick, endFindModulesTick );       
           pOpts->log()<<"time ellapsed: "<<(int)d<<" ms\n";
          } 
         
    
        if (findRes)
           {
            pOpts->log()<<"Scan stops with error: ";
            #ifdef _WIN32
            pOpts->log()<<formatWinError(findRes)<<"\n";
            #else
            pOpts->log()<< MARTY_FILESYSTEM_NS errorStr(findRes)<<"\n";
            #endif
           }
    
    
        TICK_T startProcessingModulesTick = cliGetTickCount();
        std::vector<MARTY_FILESYSTEM_NS CFindFileInfo<TCHAR> >::const_iterator mfIt = matchedFiles.begin();
        for(; mfIt!=matchedFiles.end(); ++mfIt)
           {
            if (MARTY_FILESYSTEM_NS efIsDir(mfIt->attrs)) continue; // skip dirs
    
            tstring modName = MARTY_FILENAME_NS appendPath(mfIt->path, mfIt->file);
    
            tstring comparableModName = MARTY_FILENAME::prepareForCompare(modName);
            if (usedModules.find(comparableModName)!=usedModules.end()) 
               {
                #if defined(DEBUG) || defined(_DEBUG)
                pOpts->log()<<"Module: "<<modName<<" - already processed\n";
                #endif
                continue;
               }

            usedModules.insert(comparableModName);
    
            pOpts->log()<<"Processing module";
    
            if (useCache)
               pOpts->log()<<" cache";
            pOpts->log()<<": "<<modName<<" - ";
    
            //tstring excludedByMask;
            SIZE_T maskId = 0;
            if ( isFilenameExcludedByMask( modName, excludeFilesMasks, maskId /* excludedByMask */  ) )
               {
                pOpts->log()<<"excluded by mask '"<< excludeFilesMasks[maskId]<<"'\n";
                continue;
               }
    
            std::vector< ::cli::implx::CComponentInfo<TCHAR> > infoList;
            bool res = false;
    
            RCODE errCode;
            tstring errMsg;
    
            if (useCache)
               res = ::cli::implx::readComponentInfoFromModuleCache(modName, infoList);
            else
               res = ::cli::implx::readComponentInfoFromModule     (modName, infoList, &errCode, &errMsg );
    
            if (!res)
               {
                if (useCache)
                   pOpts->log()<<"failed - can't open file";
                else
                   {
                    if (errCode && !errMsg.empty())
                       {
                        pOpts->log()<<"failed - is not a CLI2 module, error "<<(UINT)errCode<<" with message: "<<errMsg<<"\n";
                       }
                    else if (errCode)
                       {
                        pOpts->log()<<"failed - is not a CLI2 module, error "<<(UINT)errCode<<"\n";
                       }
                    else
                       {
                        pOpts->log()<<"failed - is not a CLI2 module\n";
                       }
                   }
                continue;
               }
            
            pOpts->log()<<"Ok\n";
            // 
            addModuleComponents( componentsInfoQuickFinder, infoList, pOpts );
    
           }
    
        TICK_T endProcessingModulesTick = cliGetTickCount();
          {
           TICK_DIFF_T d = cliTickDiff( startProcessingModulesTick, endProcessingModulesTick );       
           //TICK_DIFF_T d = cliTickDiff( startFindModulesTick, endProcessingModulesTick );
           pOpts->log()<<"Time ellapsed on modules processing: "<<(int)d<<" ms\n";
          }

       }

    ::std::sort(componentsInfo.begin(), componentsInfo.end());

    pOpts->log()<<"-------\nList of known components\n-------\n";
       {
        ::std::vector<CComponentInfo>::const_iterator cit = componentsInfo.begin();
        for(; cit!=componentsInfo.end(); ++cit)
           {
            pOpts->log()<<cit->componentName<<": "<<modulesIdMap.getKey(cit->moduleId)<<"\n";
           }
       }

    if (componentsInfo.empty())
       pOpts->log()<<"Component list empty\n";

    pOpts->log()<<"-------\nEnd of list of known components (total found: "<<(int)(unsigned)componentsInfo.size()<<")\n-------\n";
    TICK_T endKnownComponentsTick = cliGetTickCount();
      {
       TICK_DIFF_T d = cliTickDiff( startFindModulesTick, endKnownComponentsTick );
       //pOpts->log()<<"Time ellapsed total: "<<(int)d<<" ms\n";
       pOpts->log()<<"Total time ellapsed: "<<(int)d<<" ms\n";
      }


    /*
    ::std::vector<tstring>::const_iterator pit = path.begin();
    for(; pit!=path.end(); ++pit)
       {
        pOpts->log()<<"Scaning path: "<<*pit<<"\n";
       }
    */
   }

//-----------------------------------------------------------------------------
SIZE_T
CLICALL
cliGetComponentDecsription( CHAR const * componentId
                          , const WCHAR* requestedLang
                          , BOOL         findExactLang
                          , SIZE_T bufSize
                          , WCHAR *componentDescriptionBuf
                          )
   {
    if (!componentId) return 0; // error, enum stops 

    CLI_AUTOLOCK_EX(componentListLocker, clCs);

    CComponentInfo ci; ci.componentName = componentId;

    ::std::vector<CComponentInfo>::const_iterator cit = ::cli::util::binary_find(componentsInfo.begin(), componentsInfo.end(), ci);
    if (cit==componentsInfo.end())
       return 0; // unknown component, enum stops

    if (cit->componentDescription.empty()) return 0; // no description

    std::string strRequestedLang = requestedLang ? ::cli::impl::flat_str_utils::fromWidePlain( requestedLang ) : std::string();

    const std::map<std::string, std::string> &componentDescriptionMap = cit->componentDescription;
    std::string strDescription;
    if (strRequestedLang.empty())
       {
        strDescription = componentDescriptionMap.begin()->second; // get first
       }
    else
       {
        strRequestedLang = ::cli::impl::normalizeLangIdString(strRequestedLang);
        std::map<std::string, std::string>::const_iterator descrIt = componentDescriptionMap.find(strRequestedLang);

        if (descrIt == componentDescriptionMap.end() && !findExactLang)
           {
            strRequestedLang = ::cli::impl::getLangIdPrimaryLang(strRequestedLang);
            descrIt = componentDescriptionMap.find(strRequestedLang);
           }

        if (descrIt == componentDescriptionMap.end() && !findExactLang)
           return 0; // description not found for requested lang
        
        strDescription = descrIt->second;
       }

    std::wstring descrFound = MARTY_UTF::fromUtf8(strDescription);

    if (!componentDescriptionBuf) return descrFound.size()+1;

    SIZE_T numCharsToCopy = bufSize - 1;
    if (numCharsToCopy>descrFound.size()) numCharsToCopy = descrFound.size();
    descrFound.copy( componentDescriptionBuf, numCharsToCopy );
    componentDescriptionBuf[numCharsToCopy] = 0;
    return numCharsToCopy+1;
   }
//-----------------------------------------------------------------------------


/* return 0 if categoryIdx out of range
   if categoryNameBuf is 0
      return buf size required for category name, including termanating zero
      bufSize ignored
   if categoryNameBuf != 0
      copy category name to categoryNameBuf up to bufSize chars, return number of copied chars
 */
SIZE_T
CLICALL
cliEnumComponentCategories( CHAR const * componentId
                          , SIZE_T categoryIdx
                          , SIZE_T bufSize
                          , CHAR *categoryNameBuf
                          )
   {
    if (!componentId) return 0; // error, enum stops 

    CLI_AUTOLOCK_EX(componentListLocker, clCs);

    CComponentInfo ci; ci.componentName = componentId;

    ::std::vector<CComponentInfo>::const_iterator cit = ::cli::util::binary_find(componentsInfo.begin(), componentsInfo.end(), ci);
    if (cit==componentsInfo.end())
       return 0; // unknown component, enum stops

    if (categoryIdx>=cit->componentCategories.size()) return 0; // end f list reached, enum stops

    const ::std::string &cat = cit->componentCategories[categoryIdx];

    if (!categoryNameBuf) return cat.size()+1;

    if (!bufSize) return 0; // error - buf len is zero, enum stops

    SIZE_T numOfCharsToCopy = bufSize-1; // exclude terminating zero
    if (numOfCharsToCopy>cat.size())
       numOfCharsToCopy = cat.size();

    cat.copy(categoryNameBuf, numOfCharsToCopy, 0);
    categoryNameBuf[numOfCharsToCopy] = '\0';

    return numOfCharsToCopy+1;
   }

//-----------------------------------------------------------------------------
SIZE_T
CLICALL
cliEnumCategories( SIZE_T categoryIdx
                 , SIZE_T bufSize
                 , CHAR *categoryNameBuf
                 )
   {
    CLI_AUTOLOCK_EX(componentListLocker, clCs);


    SIZE_T curIdx = 0;
    ::std::map< ::std::string, ::std::vector< ::std::string > >::const_iterator ccIt = categoryComponents.begin();
    for(; ccIt!=categoryComponents.end() && curIdx<categoryIdx; ++ccIt, ++curIdx) {}
    if (ccIt==categoryComponents.end() || curIdx!=categoryIdx) return 0; // index out of range, or name invalid

    SIZE_T nameLen = ccIt->first.size();

    if (!categoryNameBuf) return nameLen+1;

    if (!bufSize) return 0; // error - buf len is zero, enum stops

    SIZE_T numOfCharsToCopy = bufSize-1; // exclude terminating zero
    if (numOfCharsToCopy>nameLen)
       numOfCharsToCopy = nameLen;

    memcpy( (void*)categoryNameBuf, (const void*)ccIt->first.data(), numOfCharsToCopy);
    categoryNameBuf[numOfCharsToCopy] = 0;

    return numOfCharsToCopy+1;
   }

//-----------------------------------------------------------------------------
SIZE_T
CLICALL
cliEnumCategoryComponents( CHAR const * categoryId
                         , SIZE_T componentIdx
                         , SIZE_T bufSize
                         , CHAR *componentNameBuf
                         )
   {
    if (!categoryId) return 0;

    CLI_AUTOLOCK_EX(componentListLocker, clCs);

    ::std::map< ::std::string, ::std::vector< ::std::string > >::const_iterator ccIt = categoryComponents.find(categoryId);
    if (ccIt==categoryComponents.end()) return 0;

    if (componentIdx>=ccIt->second.size()) return 0;

    const ::std::string &component = ccIt->second[componentIdx];

    if (!componentNameBuf) return component.size()+1;

    if (!bufSize) return 0; // error - buf len is zero, enum stops

    SIZE_T numOfCharsToCopy = bufSize-1; // exclude terminating zero
    if (numOfCharsToCopy>component.size())
       numOfCharsToCopy = component.size();

    component.copy(componentNameBuf, numOfCharsToCopy, 0);
    componentNameBuf[numOfCharsToCopy] = '\0';

    return numOfCharsToCopy+1;
   }

//::std::map< ::std::string, ::std::vector< ::std::string > >::iterator ccIt = categoryComponents;


//ABSTRACT_MODULE_HANDLE
//loadModule(const ::std::basic_string<CharType, Traits, Allocator> &modname)

