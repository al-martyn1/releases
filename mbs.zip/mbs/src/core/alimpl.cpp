#define CLI_INTERNAL

#include "alimpl.h"

#ifndef CLI_CSEC_H
    #include <cli/csec.h>
#endif

#if !defined(_STACK_) && !defined(_STLP_STACK) && !defined(__STD_STACK__) && !defined(_CPP_STACK) && !defined(_GLIBCXX_STACK)
    #include <stack>
#endif

#ifndef CLI_ARGLIST_H
    #include <cli/arglist.h>
#endif

#ifndef CLI_VARIANTIMPL_H
    #include "variantImpl.h"
#endif

#ifndef CLI_VARIANT_H
    #include <cli/variant.h>
#endif

#ifndef CLI_OBJPOOLX_H
    #include <cli/objpoolx.h>
#endif


namespace cli
{
//namespace arglist
//{
namespace impl
{


struct CArgListCleanup
{
    CArgListCleanup()
    {
    }

    void operator()() const
    {
    };
};


class CDefaultArgList : public CArgList<false>
{
        typedef CArgList<false> baseClass;

    public:

        CDefaultArgList() : baseClass() {}

        CLI_BEGIN_INTERFACE_MAP(CDefaultArgListl)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IARGLIST )
        CLI_END_INTERFACE_MAP(CDefaultArgList)
        CLIMETHOD_(ULONG, addRef) (THIS)    { return (ilint_t)++refCounter;  }
        CLIMETHOD_(ULONG, release) (THIS)   
           {
            if (! --refCounter) 
               { 
                clearArgList(); // ������� ������ ���������� ��� ������������ �������������
                return 0;
               }
            return (ilint_t)refCounter;
           }
}; // class CDefaultArgList



class CPooledArgList;

typedef ::cli::CObjectPool< CDefaultArgList
                          , CPooledArgList
                          , INTERFACE_CLI_IARGLIST
                          , ::cli::CCriticalSection
                          , CArgListCleanup
                          > CArgListPool;


class CPooledArgList : public CArgList<true>
{
        typedef CArgList<true> baseClass;

        CArgListPool  &ownerPool;

    public:

        CPooledArgList(CArgListPool  &op) : baseClass(), ownerPool(op) {}

        CLI_BEGIN_INTERFACE_MAP(CPooledArgList)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IARGLIST )
        CLI_END_INTERFACE_MAP(CPooledArgList)
        CLIMETHOD_(ULONG, addRef) (THIS)    { return (ilint_t)++refCounter;  }
        CLIMETHOD_(ULONG, release) (THIS)   
           {
            if (! --refCounter) 
               { 
                //destroy(); 
                //return 0;
                clearArgList(); // ������� ������ ���������� ��� ������������ �������������
                ownerPool.putBack(this); // ������ ����� � ���
                return 0;
               }
            return (ilint_t)refCounter;
           }

        void dumpPooledObject( ::std::wstring &dumpStr )
           {
            SIZE_T idx = 0, size = varList.size();
            for(; idx!=size; ++idx)
               {
                if (!dumpStr.empty())
                   dumpStr.append(L", ");
                dumpStr.append(1, L'{');
                ::std::wstring tmp = varList[idx].asString();
                dumpStr.append(tmp, 0, tmp.size());
                dumpStr.append(1, L'}');
               }
           }
}; // class CPooledArgList




//CVariantPooledBaseImpl
class CDefaultVariant : public CVariantPooledBaseImpl
{
        typedef CVariantPooledBaseImpl baseClass;

    public:

        CDefaultVariant() : baseClass() {}

        CLI_BEGIN_INTERFACE_MAP2(CDefaultVariant, INTERFACE_CLI_IVARIANT)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IVARIANT )
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IREADONLYVARIANT )
        CLI_END_INTERFACE_MAP(CDefaultVariant)

        CLIMETHOD_(ULONG, addRef) (THIS)    { return (ilint_t)++refCounter;  }
        CLIMETHOD_(ULONG, release) (THIS)   
           {
            if (! --refCounter) 
               { 
                clearVariant();
                return 0;
               }
            return (ilint_t)refCounter;
           }
    
        CLIMETHOD(cloneVariant) (THIS_ INTERFACE_CLI_IVARIANT**    pVariantCopy /* [out] ::cli::iVariant* pVariantCopy  */)
           {
            // undone: CLI_TRY
            if (!pVariantCopy) return EC_INVALID_OUT_PTR;
            //clearVariant();
            *pVariantCopy = static_cast<INTERFACE_CLI_IVARIANT*>(this);
            addRef();
            return EC_OK;
           }

        CLIMETHOD(cloneVariantReadOnly) (THIS_ INTERFACE_CLI_IREADONLYVARIANT**    pVariantCopy /* [out] ::cli::iReadOnlyVariant* pVariantCopy  */)
           {
            // undone: CLI_TRY
            if (!pVariantCopy) return EC_INVALID_OUT_PTR;
            //clearVariant();
            *pVariantCopy = static_cast<INTERFACE_CLI_IREADONLYVARIANT*>(this);
            addRef();
            return EC_OK;
           }

    
        CLIMETHOD(createEmptyVariant) (THIS_ INTERFACE_CLI_IVARIANT**    pVariantEmpty /* [out] ::cli::iVariant* pVariantEmpty  */)
           {
            // undone: CLI_TRY
            if (!pVariantEmpty) return EC_INVALID_OUT_PTR;
            clearVariant();
            *pVariantEmpty = static_cast<INTERFACE_CLI_IVARIANT*>(this);
            addRef();
            return EC_OK;
           }

}; // class CDefaultVariant



struct CVariantCleanup
{
    CVariantCleanup()
    {
    }

    void operator()() const
    {
    };
}; // CVariantCleanup


class CPooledVariant;


typedef ::cli::CObjectPool< CDefaultVariant
                          , CPooledVariant
                          , INTERFACE_CLI_IVARIANT
                          , ::cli::CCriticalSection
                          , CVariantCleanup
                          > CVariantPool;


class CPooledVariant : public CVariantPooledBaseImpl
{
        typedef CVariantPooledBaseImpl baseClass;

        CVariantPool  &ownerPool;

    public:

        CPooledVariant(CVariantPool &op) : baseClass(), ownerPool(op) {}

        CLI_BEGIN_INTERFACE_MAP2(CPooledVariant, INTERFACE_CLI_IVARIANT)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IVARIANT )
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IREADONLYVARIANT )
        CLI_END_INTERFACE_MAP(CPooledVariant)

        CLIMETHOD_(ULONG, addRef) (THIS)    { return (ilint_t)++refCounter;  }
        CLIMETHOD_(ULONG, release) (THIS)   
           {
            if (! --refCounter) 
               { 
                //destroy(); 
                //return 0;
                clearVariant();
                ownerPool.putBack(this); // ������ ����� � ���
                return 0;
               }
            return (ilint_t)refCounter;
           }

        void dumpPooledObject( ::std::wstring &dumpStr )
           {
            dumpStr = value.asString();
           }

        CLIMETHOD(cloneVariant) (THIS_ INTERFACE_CLI_IVARIANT**    pVariantCopy /* [out] ::cli::iVariant* pVariantCopy  */)
           {
            // undone: CLI_TRY
            if (!pVariantCopy) return EC_INVALID_OUT_PTR;
            *pVariantCopy = ownerPool.getInstance();
            if (*pVariantCopy) return (*pVariantCopy)->assignVariant( this );
            return EC_OK;
           }

        CLIMETHOD(cloneVariantReadOnly) (THIS_ INTERFACE_CLI_IREADONLYVARIANT**    pVariantCopy /* [out] ::cli::iReadOnlyVariant* pVariantCopy  */)
           {
            // undone: CLI_TRY
            if (!pVariantCopy) return EC_INVALID_OUT_PTR;
            INTERFACE_CLI_IVARIANT* pVariant = ownerPool.getInstance();
            if (pVariant) pVariant->queryInterface( INTERFACE_CLI_IVARIANT_IID, (VOID**)&pVariantCopy );
            
            //*pVariantCopy = ownerPool.getInstance();
            RCODE res = EC_OK;
            if (*pVariantCopy)
               {
                if (pVariant)
                   res = pVariant->assignVariant( this );
                //return (*pVariantCopy)->assignVariant( this );
               }
            if (pVariant)
               pVariant->release();
            return res;
           }
    
        CLIMETHOD(createEmptyVariant) (THIS_ INTERFACE_CLI_IVARIANT**    pVariantEmpty /* [out] ::cli::iVariant* pVariantEmpty  */)
           {
            // undone: CLI_TRY
            if (!pVariantEmpty) return EC_INVALID_OUT_PTR;
            *pVariantEmpty = ownerPool.getInstance();
            return EC_OK;
           }


}; // class CPooledArgList






}; // namespace impl
//}; // namespace arglist
}; // namespace cli


::cli::impl::CArgListPool argListPool(L"argListPool");

CLIAPIENTRY
INTERFACE_CLI_IARGLIST*
CLICALL
cliGetArgList( )
   {
    //return argListPool.getArgList();
    return argListPool.getInstance();
   }


::cli::impl::CVariantPool variantPool(L"variantPool");

CLIAPIENTRY
INTERFACE_CLI_IVARIANT*
CLICALL
cliGetVariant( )
   {
    //return argListPool.getArgList();
    return variantPool.getInstance();
   }






