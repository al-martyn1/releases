#include <iostream>
#include <fstream>

#include <boost/algorithm/string/predicate.hpp>
#include <boost/algorithm/string/trim.hpp>
#include <boost/algorithm/string/split.hpp>

#include <dia/dia.h>
#include <fsm/fsmdef.h>
#include <marty/confUtils.h>

#include "diaConv.h"

namespace fsm
{

using MARTY_FILENAME_NS     appendPath;
using MARTY_FILESYSTEM_NS   getCurrentDirectory;
using MARTY_FILESYSTEM_NS   openFile;
using MARTY_FILESYSTEM_NS   closeFile;


//-----------------------------------------------------------------------------
void convertDiaDiagram(const dia::CDiargam &diagram, fsm::CFsmConfig &fsm)
   {
    unsigned objNameCounter = 0;

    const dia::CDiaAttr *pAttr = 0;

    std::vector<dia::CDiargamLayer>::const_iterator lit = diagram.layers.begin();
    for(; lit!=diagram.layers.end(); ++lit)
       {
        fsm::CStateMachineInfo sm;
        sm.name = lit->name;

        std::map<tstring, tstring> stateIdToNameMap;
        tstring startStateId;
        std::map<tstring, tstring> endStatesIdList;

        std::map<tstring, tstring> noteIdToTextMap;

        CConnectorMap              connectorsMap;

        // step one, prepare
        std::vector<dia::CObject>::const_iterator objIt = lit->objects.begin(), objEnd = lit->objects.end();        
        for(; objIt!=objEnd; ++objIt)
           {
            dia::EObjectType objType = objIt->getObjectType();

            switch(objType)
               {
                case dia::objtypeUmlNote: 
                       {
                        pAttr = objIt->findAttr("text");
                        if (pAttr && !pAttr->composite.empty())
                            pAttr = pAttr->composite[0].findAttr("string");
                      
                        tstring noteText;
                        if (pAttr)
                           noteText = dia::textUnquote(pAttr->stringVal);
                      
                        noteIdToTextMap[objIt->id] = noteText;
                       }
                       break;

                case dia::objtypeUmlTransition: 
                case dia::objtypeUmlGeneralization:
                       connectorsMap.addConnector(*objIt);
                       break;

                case dia::objtypeUmlStateTerm: 
                       //pAttr = objIt->findAttr("is_final");
                       //if (pAttr && pAttr->boolVal.val)
                       if (getDiaObjectAttrVal(*objIt, "is_final", false))
                          { // end state
                           //endStatesIdList.insert(objIt->id);
                           endStatesIdList[objIt->id] = tstring(); // ���������� ��������
                          }
                       else
                          { // start state
                           if (!startStateId.empty()) // allready taken
                              {
                               std::cout<<"Warning: multiple start states defined, previous start state object id: "<<startStateId<<", newly defined: "<<objIt->id<<"\n";
                              }
                           startStateId = objIt->id;
                          }

                       break;

                case dia::objtypeUmlState: 
                       { 
                        pAttr = objIt->findAttr("text");
                        if (pAttr && !pAttr->composite.empty())
                            pAttr = pAttr->composite[0].findAttr("string");
                      
                        tstring stateName;
                        if (pAttr)
                           stateName = dia::textUnquote(pAttr->stringVal);

                        if (!stateName.empty() && !isValidCppName(stateName))
                           {
                            std::cout<<"Warning: State (object id: "<<objIt->id<<") - invalid state name: '"<<stateName<<"'\n";
                           }

                        if (!stateName.empty())
                           {
                            stateIdToNameMap[objIt->id] = stateName;
                           }
                        else
                           {
                            TCHAR buf[256];
                            wsprintf(buf, "State%d", objNameCounter++);
                            std::cout<<"Warning: State (object id: "<<objIt->id<<") has no name, used generated name '"<<buf<<"'\n";
                            stateIdToNameMap[objIt->id] = tstring(buf);
                           }
                       }
                       break;
               };
           }

        // step two
        objIt = lit->objects.begin();
        for(; objIt!=objEnd; ++objIt)
           {
            dia::EObjectType objType = objIt->getObjectType();
            switch(objType)
               {
                case dia::objtypeUmlStateTerm: 
                     {
                      std::map<tstring, tstring>::iterator esit = endStatesIdList.find(objIt->id);
                      bool endState = esit!=endStatesIdList.end();
                      //if (esit==endStatesIdList.end()) // not an end state
                      //   {
                      //    //break;
                      //   }

                      CConnectorMap::connector_vector v;
                      CConnectorMap::cv_size_type cnt = connectorsMap.getListByConnectedFrom(objIt->id, v, dia::objtypeUmlGeneralization);
                      //CConnectorMap::cv_size_type cnt = connectorsMap.getListByConnectedTo(objIt->id, v, dia::objtypeUmlGeneralization);
                      if (!cnt)
                         {
                          std::cout<<"Warning: Terminal state (object id: "<<objIt->id<<") - has no markers\n";
                          break;
                         }
                      // else if (cnt>1)
                      //    {
                      //     std::cout<<"Warning: Terminal state (object id: "<<objIt->id<<") - has multiple marker connections ("<<(unsigned)cnt<<")\n";
                      //    }

                      fsm::CStateInfo st;
                              // st.bReturn      = false;
                              // esit->second = text;
                              // st.name         = text;
                              // st.entryAction  = std::string();
                              // st.doAction     = std::string();
                              // st.exitAction   = std::string();
                              // st.complexRef   = std::string();                                  
                              // st.callRef      = std::string();                                  
                              // st.includeFile  = std::string();                     
                              // st.isFinal      = true;
                              // sm.states.push_back(st);
                              //  
                              // stateIdToNameMap[objIt->id] = st.name;

                      // lookup for objtypeUmlGeneralization
                      CConnectorMap::connector_vector::const_iterator vit = v.begin();
                      for(; vit!=v.end(); ++vit)
                         {
                          if (vit->type!=dia::objtypeUmlGeneralization) continue;
                          // found objtypeUmlGeneralization

                          std::map<tstring, tstring>::const_iterator nit = noteIdToTextMap.find(vit->to);
                          if (nit==noteIdToTextMap.end())
                             continue; // broken connection, continue iterations

                          std::string text = nit->second;
                          std::map<std::string, std::string> extAttrs;
                          bool extAttrsFound = ::fsm::getAttributeExtendedOptions(text, extAttrs);
                             
                          if (!endState)
                             {
                              if (!extAttrsFound)
                                 { // no extended attr found, here is state name
                                  if (!sm.automataClass.empty())
                                     {
                                      std::cout<<"Warning: Terminal start state (object id: "
                                               <<objIt->id<<") - start state allready defined, old: "
                                               <<sm.automataClass
                                               <<", new: "
                                               <<text<<"\n";
                                     }
                                  sm.automataClass = text;
                                 }
                              else // found extended attrs
                                 {
                                  std::map<std::string, std::string>::const_iterator eaIt = extAttrs.find("call_entry_action");
                                  if (eaIt!=extAttrs.end())
                                     {
                                      sm.callEntryAction = ::boost::algorithm::trim_copy(text);
                                     }
                                  else 
                                     {
                                      eaIt = extAttrs.find("inline_entry_action");
                                      if (eaIt!=extAttrs.end())
                                         {
                                          sm.inlineEntryAction = ::boost::algorithm::trim_copy(text);
                                         }
                                     }
                                 }
                              //std::map<std::string, std::string>::const_iterator eaIt = extAttrs.find("return");

                              //break;
                              continue;
                             }
                          
                          if (!extAttrsFound)
                             {
                              // no extended attrs, simple state name   
                              esit->second = ::boost::algorithm::trim_copy(text);
                              st.name      = ::boost::algorithm::trim_copy(text);
                              continue;
                             }
                          
                          std::map<std::string, std::string>::const_iterator eaIt = extAttrs.find("return");
                          if (eaIt!=extAttrs.end() && eaIt->second!=std::string("false") && eaIt->second!=std::string("0"))
                             { // found ext attr return, state name is in this block also
                              st.bReturn      = true;
                              esit->second = ::boost::algorithm::trim_copy(text);
                              st.name      = ::boost::algorithm::trim_copy(text);
                              //eaIt = extAttrs.find("recurse_event");
                              if (extAttrs.find("recurse_event")!=extAttrs.end())
                                 {
                                  st.recurRet = true;
                                 }
                              continue;
                             }

                          eaIt = extAttrs.find("entry_action");
                          if (eaIt!=extAttrs.end())
                             {
                              //st.entryAction  = eaIt->second;
                              st.entryAction  = ::boost::algorithm::trim_copy(text);
                             }

                         }

                      
                      if (endState)
                         {
                          st.isFinal      = true;
                          if (st.name.empty())
                             {
                              std::cout<<"Warning: Terminal "<<(endState?"end":"start")<<" state (object id: "<<objIt->id<<") - has no name\n";
                             }
                          sm.states.push_back(st);
                          stateIdToNameMap[objIt->id] = st.name;
                         }

                     }
                     break;
               };
           }


        // step three

        //std::vector<dia::CObject>::const_iterator 
        objIt = lit->objects.begin(); //, objEnd = lit->objects.end();
        // main step
        for(; objIt!=objEnd; ++objIt)
           {
            dia::EObjectType objType = objIt->getObjectType();
            switch(objType)
               {
                case dia::objtypeUmlTransition: 
                       {
                        fsm::CTransitionInfo tr;
                        tr.inner = false;
                        bool fromStart = false; // set to true if transition from start state
                        tstring toRealStartStateId;

                        tr.trigger = getDiaObjectAttrVal(*objIt, "trigger", tr.trigger);
                        // pAttr = objIt->findAttr("trigger");
                        // if (pAttr)
                        //    tr.trigger = dia::textUnquote(pAttr->stringVal);

                        //tr.action = getDiaObjectAttrVal(*objIt, "action", tr.action);
                         pAttr = objIt->findAttr("action");
                         if (pAttr)
                            {
                             tstring action = dia::textUnquote(pAttr->stringVal);
                             if (!action.empty()) tr.actions.push_back(action);
                            }
                        
                        tr.guard = getDiaObjectAttrVal(*objIt, "guard", tr.guard);
                        // pAttr = objIt->findAttr("guard");
                        // if (pAttr)
                        //    tr.guard = dia::textUnquote(pAttr->stringVal);
                    
                        //getDiaObjectAttrVal(*objIt, "", );
                        if (!objIt->connections.empty())
                           {
                            // connectorsMap

                            const dia::CDiaConnection* 
                            conn = objIt->findConnection(tstring(_T("0")));
                            if (conn)
                               {
                                tr.startState = stateIdToNameMap[conn->to];

                                if (startStateId==conn->to) // 0->to is from, transition from special start state
                                       fromStart = true;
                               }
                            conn = objIt->findConnection(tstring(_T("1")));
                            if (conn)
                               {
                                //std::set<tstring>::
                                std::map<tstring, tstring>::const_iterator esIt = endStatesIdList.find(conn->to);
                                if (esIt==endStatesIdList.end())
                                   tr.endState = stateIdToNameMap[conn->to];
                                else
                                   {
                                    tr.endState = esIt->second; // tstring(_T("#END#"));
                                   }
                                if (tr.endState.empty())
                                   tr.endState = "#UNDEFINED#";
                               }

                            if (fromStart)
                               toRealStartStateId = conn->to;
                           }

                        if (fromStart)
                           {
                            sm.startState = stateIdToNameMap[toRealStartStateId];
                           }
                        else
                           {
                            std::map<std::string, std::string> extAttrs;
                            if (::fsm::getAttributeExtendedOptions(tr.trigger, extAttrs))
                               {
                                std::map<std::string, std::string>::const_iterator eaIt = extAttrs.find("inner");
                                if (eaIt!=extAttrs.end())
                                   {
                                    if (eaIt->second!="false")
                                       tr.inner = true;
                                   }
                               }

                            /*
                            if (!tr.trigger.empty() && tr.trigger[0]=='{')
                               { // parse extended attributes
                                std::string :: size_type extEnd = 
                                            ::marty::confUtils::findBracketPair(tr.trigger, '{', '}');
                                if (extEnd!=std::string :: npos)
                                   { // found ext attrs
                                    std::map<std::string, std::string> extAttrs;
                                    ::marty::confUtils::splitOptionsString( extAttrs, ::std::string(tr.trigger, 1, extEnd-2), ';', ':');
                                    std::map<std::string, std::string>::const_iterator eaIt = extAttrs.find("inner");
                                    if (eaIt!=extAttrs.end())
                                       {
                                        if (eaIt->second!="false")
                                           tr.inner = true;
                                       }
                                    tr.trigger.erase(0,extEnd); // erase ext attrs from trigger value
                                   }
                               }
                            */

                            if (tr.inner && tr.startState!=tr.endState)
                               {
                                std::cout<<"Warning: inner connections must have the same start and end states (start state: "<<tr.startState<<", end state: "<<tr.endState<<"\n";
                               }

                            sm.transitions.push_back(tr);
                           }
                       }
                       break;

                case dia::objtypeUmlStateTerm: 
                       break;

                case dia::objtypeUmlState: 
                       {
                        fsm::CStateInfo st;
                        st.name = stateIdToNameMap[objIt->id];
                        st.isFinal = false;
                        st.bReturn = false;

                        pAttr = objIt->findAttr("entry_action");
                        if (pAttr)
                           st.entryAction = dia::textUnquote(pAttr->stringVal);

                        pAttr = objIt->findAttr("do_action");
                        if (pAttr)
                           st.doAction = dia::textUnquote(pAttr->stringVal);

                        pAttr = objIt->findAttr("exit_action");
                        if (pAttr)
                           st.exitAction = dia::textUnquote(pAttr->stringVal);

                        std::map<std::string, std::string> extAttrs;
                        if (::fsm::getAttributeExtendedOptions(st.doAction, extAttrs))
                           {
                            std::map<std::string, std::string>::const_iterator eaIt = extAttrs.find("complex");
                            if (eaIt!=extAttrs.end())
                               {
                                if (!eaIt->second.empty())
                                   st.complexRef = eaIt->second;
                               }

                            //{call:ACallable;recurse_on_call;recurse_on_ret}
                            //std::map<std::string, std::string>::const_iterator 
                            eaIt = extAttrs.find("call");
                            if (eaIt!=extAttrs.end())
                               {
                                if (!eaIt->second.empty())
                                   st.callRef = eaIt->second;

                                eaIt = extAttrs.find("recurse_event");
                                if (eaIt!=extAttrs.end())
                                   {
                                    st.recurCall = true;
                                    //st.recurRet  = true;
                                   }
                                /*
                                else
                                   {
                                    eaIt = extAttrs.find("recurse_on_call");
                                    if (eaIt!=extAttrs.end()) st.recurCall = true;
                                    eaIt = extAttrs.find("recurse_on_ret");
                                    if (eaIt!=extAttrs.end()) st.recurRet  = true;
                                   }
                                */
                               }

                            eaIt = extAttrs.find("spawn");
                            if (eaIt!=extAttrs.end())
                               {
                                if (!eaIt->second.empty())
                                   st.callRef = eaIt->second;
                                st.recurCall = true;
                                st.bSpawn    = true;
                               }

                            eaIt = extAttrs.find("include");
                            if (eaIt!=extAttrs.end())
                               {
                                if (!eaIt->second.empty())
                                   st.includeFile = eaIt->second;
                               }
                           }
                        /*
                        if (!st.doAction.empty() && st.doAction[0]=='{')
                           { // parse extended attributes
                            std::string :: size_type extEnd = 
                                        ::marty::confUtils::findBracketPair(st.doAction, '{', '}');
                            if (extEnd!=std::string :: npos)
                               { // found ext attrs
                                std::map<std::string, std::string> extAttrs;
                                ::marty::confUtils::splitOptionsString( extAttrs, ::std::string(st.doAction, 1, extEnd-2), ';', ':');
                                std::map<std::string, std::string>::const_iterator eaIt = extAttrs.find("complex");
                                if (eaIt!=extAttrs.end())
                                   {
                                    if (!eaIt->second.empty())
                                       st.complexRef = eaIt->second;
                                   }

                                eaIt = extAttrs.find("include");
                                if (eaIt!=extAttrs.end())
                                   {
                                    if (!eaIt->second.empty())
                                       st.includeFile = eaIt->second;
                                   }
                                st.doAction.erase(0,extEnd); // erase ext attrs from trigger value
                               }
                           }
                        */

                        sm.states.push_back(st);
                       }
                       break;

                case dia::objtypeUmlNote: 
                       break;

                case dia::objtypeUmlActivity: 
                       break;

                case dia::objtypeUmlDependency: 
                       break;

                case dia::objtypeUmlGeneralization: 
                       break;

                case dia::objtypeUmlClass: 
                       {
                        fsm::CClassInfo cl;

                        pAttr = objIt->findAttr("name");
                        if (pAttr)
                            cl.name = dia::textUnquote(pAttr->stringVal);

                        pAttr = objIt->findAttr("stereotype");
                        if (pAttr)
                            cl.stereotype = dia::textUnquote(pAttr->stringVal);

                        pAttr = objIt->findAttr("comment");
                        if (pAttr)
                            cl.comment = dia::textUnquote(pAttr->stringVal);


                        pAttr = objIt->findAttr("attributes");
                        if (pAttr)
                           {
                            // st.entryAction = dia::textUnquote(pAttr->stringVal);
                            std::vector<dia::CDiaComposite>::const_iterator  dit = pAttr->composite.begin();
                            for(; dit!=pAttr->composite.end(); ++dit )
                               {
                                if (dit->type!="umlattribute") continue;

                                CClassAttributeInfo classAttr;
                                // name, type, value, comment : string
                                // visibility : enum
                                // class_scope : boolean
                                const dia::CDiaAttr *pAttr2 = dit->findAttr("name");
                                if (pAttr2)
                                    classAttr.name = dia::textUnquote(pAttr2->stringVal);

                                pAttr2 = dit->findAttr("type");
                                if (pAttr2)
                                    classAttr.type = dia::textUnquote(pAttr2->stringVal);

                                pAttr2 = dit->findAttr("value");
                                if (pAttr2)
                                    classAttr.value = dia::textUnquote(pAttr2->stringVal);

                                /*
                                pAttr2 = dit->findAttr("value");
                                if (pAttr2)
                                    classAttr.value = dia::textUnquote(pAttr2->stringVal);
                                */

                                pAttr2 = dit->findAttr("comment");
                                if (pAttr2)
                                    classAttr.comment = dia::textUnquote(pAttr2->stringVal);

                                std::map<std::string, std::string> extAttrs;
                                if (::fsm::getAttributeExtendedOptions(classAttr.comment, extAttrs))
                                   {
                                    std::map<std::string, std::string>::const_iterator eaIt = extAttrs.find("const");
                                    if (eaIt!=extAttrs.end())
                                       {
                                        if (eaIt->second!="false")
                                           classAttr.constAttr = true;
                                       }
                                   }

                                pAttr2 = dit->findAttr("visibility");
                                int vis = 0;
                                if (pAttr2)
                                   vis = pAttr2->enumVal.val;
                                if (vis<0 || vis>3)
                                   {
                                    std::cout<<"Warning: class attribute visibility (object id: "<<objIt->id<<", attribute: "<<classAttr.name<<") - invalid value: "<<vis<<"\n";
                                   }
                                classAttr.visibility = (fsm::EMemberVisibility)vis;

                                pAttr2 = dit->findAttr("class_scope");
                                if (pAttr2)
                                    classAttr.classScope = pAttr2->boolVal.val;

                                if (classAttr.type.empty())
                                   {
                                    if (classAttr.ptr) classAttr.type = "void";
                                    else               classAttr.type = "int";
                                   }

                                classAttr.checkAndCorrectIfPtrType();

                                cl.attributes.push_back(classAttr);
                               }


                           }

                        pAttr = objIt->findAttr("operations");
                        if (pAttr)
                           {
                            std::vector<dia::CDiaComposite>::const_iterator  dit = pAttr->composite.begin();
                            for(; dit!=pAttr->composite.end(); ++dit )
                               {
                                if (dit->type!="umloperation") continue;

                                CClassMethodInfo classMethod;

                                const dia::CDiaAttr *pAttr2 = dit->findAttr("name");
                                if (pAttr2)
                                    classMethod.name = dia::textUnquote(pAttr2->stringVal);

                                pAttr2 = dit->findAttr("stereotype");
                                if (pAttr2)
                                    classMethod.stereotype = dia::textUnquote(pAttr2->stringVal);

                                pAttr2 = dit->findAttr("type");
                                if (pAttr2)
                                    classMethod.type = dia::textUnquote(pAttr2->stringVal);
                                if (classMethod.type.empty())
                                   classMethod.type = "void";

                                pAttr2 = dit->findAttr("comment");
                                if (pAttr2)
                                    classMethod.comment = dia::textUnquote(pAttr2->stringVal);

                                pAttr2 = dit->findAttr("visibility");
                                int vis = 0;
                                if (pAttr2)
                                   vis = pAttr2->enumVal.val;
                                if (vis<0 || vis>3)
                                   {
                                    std::cout<<"Warning: class method visibility (object id: "<<objIt->id<<", method: "<<classMethod.name<<") - invalid value: "<<vis<<"\n";
                                   }
                                classMethod.visibility = (fsm::EMemberVisibility)vis;

                                pAttr2 = dit->findAttr("inheritance_type");
                                if (pAttr2)
                                    {
                                     //std::string inheritance_type = dia::textUnquote(pAttr2->stringVal);
                                     int inheritance_type = pAttr2->enumVal.val;
                                     if (inheritance_type==0)
                                        {
                                         classMethod.virtualMethod  = true;
                                         classMethod.abstractMethod = true;
                                        }
                                     else if (inheritance_type==1)
                                        {
                                         classMethod.virtualMethod  = true;
                                         classMethod.abstractMethod = false;
                                        }
                                     else if (inheritance_type==2)
                                        {
                                         classMethod.virtualMethod  = false;
                                         classMethod.abstractMethod = false;
                                        }
                                    }                                

                                pAttr2 = dit->findAttr("class_scope");
                                if (pAttr2)
                                    classMethod.classScope = pAttr2->boolVal.val;

                                if (classMethod.virtualMethod && classMethod.classScope)
                                   {
                                    std::cout<<"Warning: class method (object id: "<<objIt->id<<", method: "<<classMethod.name<<") - declaration of static (class scope) method conflicts with declaration of virtual method (inheritance type)\n";
                                   }

                                pAttr2 = dit->findAttr("query");
                                if (pAttr2)
                                    classMethod.query = pAttr2->boolVal.val;                                

                                // read params here
                                pAttr2 = dit->findAttr("parameters");
                                if (pAttr2)
                                   {
                                    std::vector<dia::CDiaComposite>::const_iterator  dit = pAttr2->composite.begin();
                                    for(; dit!=pAttr2->composite.end(); ++dit )
                                       {
                                        if (dit->type!="umlparameter") continue;

                                        CMethodParameterInfo methodParam;

                                        const dia::CDiaAttr *pAttr3 = dit->findAttr("name");
                                        if (pAttr3)
                                            methodParam.name = dia::textUnquote(pAttr3->stringVal);
        
                                        pAttr3 = dit->findAttr("type");
                                        if (pAttr3)
                                            methodParam.type = dia::textUnquote(pAttr3->stringVal);
        
                                        /*
                                        pAttr2 = dit->findAttr("value");
                                        if (pAttr2)
                                            classAttr.value = dia::textUnquote(pAttr2->stringVal);
                                        */
        
                                        pAttr3 = dit->findAttr("comment");
                                        if (pAttr3)
                                            methodParam.comment = dia::textUnquote(pAttr3->stringVal);
        
                                        pAttr3 = dit->findAttr("kind");
                                        int ioKind = 0;
                                        if (pAttr3)
                                           ioKind = pAttr3->enumVal.val;
                                        if (ioKind<0 || ioKind>3)
                                           {
                                            std::cout<<"Warning: class method parameter kind (object id: "<<objIt->id<<", method: "<<classMethod.name<<", parameter: "<<methodParam.name<<") - invalid value: "<<ioKind<<"\n";
                                           }
                                        methodParam.ioKind = (fsm::EIoKind)ioKind;

                                        methodParam.checkAndCorrectIfPtrType();

                                        if (methodParam.type.empty())
                                           {
                                            if (methodParam.ptr) methodParam.type = "void";
                                            else                 methodParam.type = "int";
                                           }

                                        /*
                                        std::map<std::string, std::string> extAttrs;
                                        if (::fsm::getAttributeExtendedOptions(methodParam.comment, extAttrs))
                                           {
                                            std::map<std::string, std::string>::const_iterator eaIt = extAttrs.find("const");
                                            if (eaIt!=extAttrs.end())
                                               {
                                                if (eaIt->second!="false")
                                                   methodParam.constAttr = true;
                                               }
                                           }
                                        */
                                           
                                        classMethod.parameters.push_back(methodParam);
                                       }                                    
                                   }
                                cl.methods.push_back(classMethod);
                               }
                           }

                        CConnectorMap::connector_vector v;
                        CConnectorMap::cv_size_type cnt = connectorsMap.getListByConnectedFrom(objIt->id, v, dia::objtypeUmlGeneralization);
  
                        // lookup for objtypeUmlGeneralization
                        CConnectorMap::connector_vector::const_iterator vit = v.begin();
                        for(; vit!=v.end(); ++vit)
                           {
                            if (vit->type!=dia::objtypeUmlGeneralization) continue;
                            // found objtypeUmlGeneralization
  
                            std::map<tstring, tstring>::const_iterator nit = noteIdToTextMap.find(vit->to);
                            if (nit==noteIdToTextMap.end())
                               continue; // broken connection, continue iterations

                            std::string text = nit->second;

                            std::map<std::string, std::string> extAttrs;
                            if (::fsm::getAttributeExtendedOptions(text, extAttrs))
                               {
                                std::map<std::string, std::string>::iterator eaIt = extAttrs.find("type");
                                if (eaIt!=extAttrs.end())
                                   {
                                    std::string type = eaIt->second;
                                    extAttrs.erase(eaIt);
                                    CClassOptions classOptions;
                                    classOptions.text = text;
                                    classOptions.attrsFromMap(extAttrs);

                                    if (type=="includes")
                                       {
                                        cl.includes.push_back(classOptions);
                                       }
                                    else if (type=="code")
                                       {
                                        //cl.code.push_back(classOptions);
                                        std::map<std::string, std::string>::const_iterator mnIt = extAttrs.find("method");
                                        if (mnIt==extAttrs.end())
                                           {
                                            std::cout<<"Warning: UML Special note (type:code) - method name not taken\n";
                                           }
                                        else
                                           {
                                            std::string methodName = mnIt->second;
                                            CClassMethodInfo *pmi = cl.getMethodInfo(methodName);
                                            if (!pmi)
                                               {
                                                std::cout<<"Warning: UML Special note (type:code) - method '"<<methodName<<"' not defined in class '"<<cl.name<<"'\n";
                                               }
                                            else
                                               {
                                                CMethodCode c;
                                                c.text = text;

                                                mnIt = extAttrs.find("lang");
                                                if (mnIt!=extAttrs.end())
                                                   c.lang = mnIt->second;

                                                c.bInline = true;
                                                mnIt = extAttrs.find("inline");
                                                if (mnIt!=extAttrs.end() && mnIt->second==std::string("false"))
                                                   c.bInline = false;

                                                if (!pmi->addCode(c))
                                                   {
                                                    std::cout<<"Warning: UML Special note (type:code) - "<<cl.name<<"::"<<methodName<<" allready has code for lang(s) '"<<c.lang<<"', code was redefined\n";
                                                   }                                               
                                               }
                                           }
                                       } // if (type=="code")
                                   }
                                
                               }
                           }



                        sm.classes.push_back(cl);
                       }

                       break;

                // case : 
                //        break;
                //  

               };
            //objIt
           
           }

        fsm.fsmList.push_back(sm);
       }
   
    fsm.trim();
    fsm.updateStatesOrgStateMachine();


   }

//-----------------------------------------------------------------------------
bool loadFsm(const CIncludeFinder<TCHAR> &includeFinder, std::map<std::string, fsm::CStateMachineInfo> &stateMachines, const tstring &fileName, bool convertFromDia)
   {
    tstring dummyFile = appendPath(getCurrentDirectory(), _T("curdir.tmp") );
    tstring foundFilename;
    MARTY_FILESYSTEM_NS handle_t hFound = 
                        includeFinder.searchForInclude( dummyFile
                                                      , tstring(_T("<")) + fileName + tstring(_T(">"))
                                                      , foundFilename
                                                      );
    if (hFound==MARTY_FILESYSTEM_NS hInvalidHandle)
       {
        std::cout<<"Error: file '"<<fileName<<"' not found\n";
        return false;
       }

    closeFile(hFound);
 
    bool fErr = false;
    std::string errText;
 
    fsm::CFsmConfig fsm;

    if (convertFromDia)
       {
        dia::CDiargam diagram;
        try{
            load_diagram(foundFilename, diagram);
           }
        CATCH_6ML_ERRORS(fErr, errText)

        if (!fErr)
           {
            convertDiaDiagram(diagram, fsm);
           }
       }
    else
       {
        try{
            load_fsmdef(foundFilename, fsm);
           }
        CATCH_6ML_ERRORS(fErr, errText)
       }

    if (fErr)
       {
        std::cout<<"Error: failed to read '"<<foundFilename<<"' file: "<<errText<<"\n";
        return false;
       }

    std::vector<fsm::CStateMachineInfo>::iterator fsmIt = fsm.fsmList.begin();
    for(; fsmIt!=fsm.fsmList.end(); ++fsmIt)
       {
        if (stateMachines.find(fsmIt->name)!=stateMachines.end())
           {
            std::cout<<"Error: state machine '"<<fsmIt->name<<"' allready loaded from '"<<fsmIt->loadedFromFile<<"'\n";
            return false;           
           }
        fsmIt->loadedFromFile = foundFilename;
        stateMachines[fsmIt->name] = *fsmIt;
       }
    return true;
   }






}; // namespace fsm

