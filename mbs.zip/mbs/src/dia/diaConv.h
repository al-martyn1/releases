#ifndef FSMGEN_DIACONV_H
#define FSMGEN_DIACONV_H

#include <dia/dia.h>
#include <fsm/fsmdef.h>
#include <marty/confUtils.h>

#include <marty/filename.h>
#include <marty/filesys.h>

#if defined(DIA_USE_OLD_SIXML)
    #include "../common/6mlerr.h"
#else
    #define CATCH_6ML_ERRORS(bFlagErr, strErr) \
    catch(...)                                 \
       {                                       \
        return false;                          \
       }
#endif



#include "../common/incSearch.h"



namespace fsm
{

template<char C>
struct CIsExactChar
{
    bool operator()(char c) const
       { return c==C; }
};

inline
bool isCppAlpha(char ch)
   {
    if (ch>='a' && ch<='z') return true;
    if (ch>='A' && ch<='Z') return true;
    return false;
   }

inline
bool isCppDigit(char ch)
   {
    if (ch>='0' && ch<='9') return true;
    return false;
   }

inline
bool isValidCppName(const std::string &s)
   {
    std::string::const_iterator it = s.begin();
    if (it==s.end()) return false;

    if (*it!='_' && !isCppAlpha(*it)) return false;

    ++it;

    for(; it!=s.end(); ++it)
       if (*it!='_' && !isCppAlpha(*it) && !isCppDigit(*it)) return false;

    return true;
   }

inline
bool getAttributeExtendedOptions(std::string &attrVal, std::map<std::string, std::string> &extAttrs)
   {
    if (attrVal.empty() || attrVal[0]!='{')
       return false; // no ext options found

    std::string :: size_type extEnd = 
                ::marty::confUtils::findBracketPair(attrVal, '{', '}');
    if (extEnd==std::string :: npos)
       return false; // no ext options found

    ::marty::confUtils::splitOptionsString( extAttrs, ::std::string(attrVal, 1, extEnd-2), ';', ':');

    attrVal.erase(0,extEnd); // erase ext attrs from attr value

    return true;
   }



struct CConnectorInfo
{
    dia::EObjectType  type     ; // connector type  

    tstring       connector; // object id
    tstring       from     ; // connected from object id
    tstring       to       ; // connected to object id

    //void extractFromObject
    CConnectorInfo()
       : type(dia::objtypeUnknown)
       , connector()
       , from()
       , to()
       {}

    CConnectorInfo(const dia::CObject &obj)
       : type(obj.getObjectType())
       , connector(obj.id)
       , from()
       , to()
       {
        if (obj.connections.empty()) return;
        
        const dia::CDiaConnection* 
        conn = obj.findConnection(tstring(_T("0")));
        if (conn) from = conn->to;

        conn = obj.findConnection(tstring(_T("1")));
        if (conn) to = conn->to;

        if (type==dia::objtypeUmlGeneralization)
           from.swap(to);
       }

    

};


class CConnectorMap
{
    public:

    typedef std::vector<CConnectorInfo>   connector_vector;
    typedef connector_vector::size_type   cv_size_type;

    protected:

    connector_vector                        connectors;
    std::multimap<tstring, cv_size_type>    idToPos;
    std::multimap<tstring, cv_size_type>    fromToPos;
    std::multimap<tstring, cv_size_type>    toToPos;

    public:

    void addConnector(const CConnectorInfo &c)
       {
        std::multimap<tstring, cv_size_type>::value_type vo(c.connector, connectors.size());
        idToPos.insert(vo);

        std::multimap<tstring, cv_size_type>::value_type vf(c.from, connectors.size());
        fromToPos.insert(vf);

        std::multimap<tstring, cv_size_type>::value_type vt(c.to, connectors.size());
        toToPos.insert(vt);

        connectors.push_back(c);
       }

    void addConnector(const dia::CObject &obj)
       {
        addConnector(CConnectorInfo(obj));
       }

    cv_size_type getListBy( const tstring &objId
                          , const std::multimap<tstring, cv_size_type> &fromMap
                          , connector_vector &v
                          , dia::EObjectType getType = dia::objtypeUnknown
                          )
       {
        //cv_size_type res = 0;
        std::pair <std::multimap<tstring, cv_size_type>::const_iterator, std::multimap<tstring, cv_size_type>::const_iterator> 
                  range = fromMap.equal_range( objId);
        std::multimap<tstring, cv_size_type>::const_iterator it = range.first;
        for(; it!=range.second; ++it)
           {
            if (it->second>=connectors.size()) continue;
            if (getType!=dia::objtypeUnknown && connectors[it->second].type!=getType) continue;
            v.push_back(connectors[it->second]);
           }
        return (cv_size_type)v.size();
       }

    cv_size_type getListByConnectorId(const tstring &objId, connector_vector &v, dia::EObjectType getType = dia::objtypeUnknown)
       {
        return getListBy( objId, idToPos, v, getType);
       }

    cv_size_type getListByConnectedFrom(const tstring &connectedFrom, connector_vector &v, dia::EObjectType getType = dia::objtypeUnknown)
       {
        return getListBy( connectedFrom, fromToPos, v, getType);
       }

    cv_size_type getListByConnectedTo(const tstring &connectedTo, connector_vector &v, dia::EObjectType getType = dia::objtypeUnknown)
       {
        return getListBy( connectedTo, toToPos, v, getType);
       }
};




void convertDiaDiagram(const dia::CDiargam &diagram, fsm::CFsmConfig &fsm);
bool loadFsm(const CIncludeFinder<TCHAR> &includeFinder, std::map<std::string, fsm::CStateMachineInfo> &stateMachines, const tstring &fileName, bool convertFromDia);




inline
tstring getDiaObjectAttrVal(const dia::CObject &obj, const tstring &attrName, const tstring &defVal)
   {
    const dia::CDiaAttr *pAttr = obj.findAttr(attrName);
    if (pAttr)
       return dia::textUnquote(pAttr->stringVal);
    return defVal;
   }

inline
bool getDiaObjectAttrVal(const dia::CObject &obj, const tstring &attrName, bool defVal)
   {
    const dia::CDiaAttr *pAttr = obj.findAttr(attrName);
    if (pAttr)
       return pAttr->boolVal.val;
    return defVal;
   }



}; // namespace fsm




#endif /* FSMGEN_DIACONV_H */

