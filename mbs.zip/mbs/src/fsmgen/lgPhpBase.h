#ifndef FSMGEN_LGPHPBASE_H
#define FSMGEN_LGPHPBASE_H


#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif

#include "langGen.h"
#include "util.h"
#include "../scanner/idlScanner.h"

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#if !defined(_FSTREAM_) && !defined(_STLP_FSTREAM) && !defined(__STD_FSTREAM__) && !defined(_CPP_FSTREAM) && !defined(_GLIBCXX_FSTREAM)
    #include <fstream>
#endif

#if !defined(_SSTREAM_) && !defined(_STLP_SSTREAM) && !defined(__STD_SSTREAM__) && !defined(_CPP_SSTREAM) && !defined(_GLIBCXX_SSTREAM)
    #include <sstream>
#endif


#include "lgCBase.h"

namespace fsm
{

using fsm::util::alignLeft;
using marty::uml::getVisibilityName;
using marty::uml::getIoKindName;

/*
inline
std::string escapeC(const std::string &str)
   {
    std::string res;
    bool bAppendQuot = false;
    std::string::size_type i=0, size = str.size();
    if (str.size()>=3 && str[0]=='L' && str[1]=='\"' && str[size-1]=='\"')
       { // Unicode literal
        bAppendQuot = true;
        res.append(1, 'L');
        res.append(1, '\"');
        i += 2;
        --size;
        //std::cout<<"L+ "<<str;
       }
    else if (str.size()>=2 && str[0]=='\"' && str[size-1]=='\"')
       {
        bAppendQuot = true;
        res.append(1, '\"');
        ++i;
        --size;
        //std::cout<<"+  "<<str;
       }
    else
       {
        //std::cout<<"-  "<<str<<"\n";
        return str;
       }

    for(; i!=size; ++i)
       {
        if (str[i]=='\\' || str[i]=='\"')
           res.append(1,'\\');
        res.append(1,str[i]);
       }
    if (bAppendQuot)
       res.append(1, '\"');
    //std::cout<<"   return "<<res<<"\n";
    return res;
   }
*/

struct IPhpBaseGenerator : public ISourceGenerator
{

    std::set<std::string>  podSet;

    IPhpBaseGenerator(const std::string &namesStyle)
       : ISourceGenerator(namesStyle), podSet()
       {
        podSet.insert("int");
        podSet.insert("signed int");
        podSet.insert("unsigned int");
        podSet.insert("long int");
        podSet.insert("signed long int");
        podSet.insert("unsigned long int");
        podSet.insert("signed long");
        podSet.insert("unsigned long");
        podSet.insert("short int");
        podSet.insert("signed short int");
        podSet.insert("unsigned short int");
        podSet.insert("signed short");
        podSet.insert("unsigned short");
        podSet.insert("char");
        podSet.insert("signed char");
        podSet.insert("unsigned char");
        podSet.insert("void");
        // WIN32 types
        //podSet.insert("ATOM");
        podSet.insert("BOOL");
        podSet.insert("BOOLEAN");
        podSet.insert("BYTE");
        podSet.insert("CHAR");
        podSet.insert("DWORD");
        podSet.insert("DWORDLONG");
        podSet.insert("DWORD_PTR");
        podSet.insert("DWORD32");
        podSet.insert("DWORD64");
        //podSet.insert("FLOAT");
        podSet.insert("HALF_PTR");
        podSet.insert("INT");
        podSet.insert("INT_PTR");
        podSet.insert("INT32");
        podSet.insert("INT64");
        podSet.insert("LONG");
        podSet.insert("LONGLONG");
        podSet.insert("LONG_PTR");
        podSet.insert("LONG32");
        podSet.insert("LONG64");
        podSet.insert("LPARAM");
        podSet.insert("WPARAM");
        podSet.insert("SHORT");
        podSet.insert("SIZE_T");
        podSet.insert("SSIZE_T");
        podSet.insert("TBYTE");
        podSet.insert("TCHAR");
        podSet.insert("UCHAR");
        podSet.insert("UINT");
        podSet.insert("UINT_PTR");
        podSet.insert("UINT32");
        podSet.insert("UINT64");
        podSet.insert("ULONG");
        podSet.insert("ULONGLONG");
        podSet.insert("ULONG_PTR");
        podSet.insert("ULONG32");
        podSet.insert("ULONG64");
        podSet.insert("USHORT");
        podSet.insert("WCHAR");
        podSet.insert("WORD");
        //podSet.insert("");
       }


    virtual std::string modifyGuardVarName( const std::string &guardVarName )
       {
        return std::string("$") + guardVarName;
       }

    //virtual int isAllowedCppTransitionCoverage( ) = 0;
    int generateCppTransitionCoverage( std::ostream &os );


    int parseForConvertCode( const std::string &cppStyleCode
                           , const std::vector<std::string> &defines
                           , std::vector<CScannerEvent> &scannerEvents
                           );



    int isPodType( const std::string &typeName )
        {
         //std::string cleanTypeName;
         //isPtrType(cleanTypeName, typeName);
         //if (podSet.find(cleanTypeName)==podSet.end()) return 0;
         if (podSet.find(typeName)==podSet.end()) return 0;
         return 1;
        }

    int makeEmptyReturn( std::ostream &os
                       , const marty::uml::CClassMethodInfo &methodInfo
                       )
        {
         std::string cleanRetType;
         bool ptr = methodInfo.isPtrReturnType(cleanRetType);
         if (ptr)
            {
             os<<"return 0;"; // zero ptr is good empty/undefined return value for generic pointer
            }
         else
            {
             if (isPodType(cleanRetType))
                {
                 if (cleanRetType!="void")
                    os<<"return 0;"; // zero is good empty/undefined return value for POD types
                 else
                    os<<"return;"; // zero is good empty/undefined return value for POD types
                }
             else
                {
                 os<<"return "<<cleanRetType<<"();";
                }
            }
         return 0;
        }


    int generatePushStateCode( const CClassInfo &curClass
                             , const std::vector<std::string> &namespaces
                             , std::ostream &os
                             , bool bPlain
                             , bool bCallOverflows
                             , bool bLangPlainC
                             );

    int generateSpawnStateCode( const CClassInfo &curClass
                             , const std::vector<std::string> &namespaces
                             , std::ostream &os
                             , bool bPlain
                             , bool bCallOverflows
                             , bool bLangPlainC
                             );

    int generatePopStateCode( const CClassInfo &curClass
                            , const std::vector<std::string> &namespaces
                            , std::ostream &os
                            , bool bPlain
                            , bool bCallOverflows
                            , bool bLangPlainC
                            );

    int generateClearStateStackCode( const CClassInfo &curClass
                                   , const std::vector<std::string> &namespaces
                                   , std::ostream &os
                                   , bool bPlain
                                   , bool bCallOverflows
                                   );

    int addStackVars( CClassInfo &curClass
                    , const std::vector<std::string> &namespaces
                    , const std::string &stackSizeStr
                    , bool bPlainCodeStyle
                    , bool bCallOverflows
                    , bool bInline
                    , bool bLangPlainC
                    );

    int addStackIncludesDefines( const CClassInfo &curClass
                               , const std::vector<std::string> &namespaces
                               , std::vector<std::string> &includes
                               , std::vector<std::string> &defines
                               , bool bPlain
                               );

    int generateMemberAccess( std::ostream &os
                            , const std::string &memberName
                            , const std::string &pthisName
                            );

    int generateHeaderProlog( std::ostream &os
                            , const std::string &filename
                            , const std::vector<std::string> &namespaces
                            , const std::vector<std::string> &incFiles
                            , const std::vector<std::string> &defines
                            );
    int generateHeaderEpilog( std::ostream &os
                            , const std::string &filename
                            , const std::vector<std::string> &namespaces
                            );
    int generateSourceProlog( std::ostream &os
                            , const std::string &filename
                            , const std::vector<std::string> &namespaces
                            , const std::vector<std::string> &incFiles
                            , const std::vector<std::string> &defines
                           );
    int generateSourceEpilog( std::ostream &os
                            , const std::string &filename
                            , const std::vector<std::string> &namespaces
                            );

    int generateIncludes(std::ostream &os, const std::vector<std::string> &incFiles)
       {
        std::vector<std::string>::const_iterator it = incFiles.begin();
        for(; it!=incFiles.end(); ++it)
           { // require_once(PFS_ROOT . 'scripts/pfscms.php');
            if (it->empty()) continue;
            if ((*it)[0]=='<' || (*it)[0]=='\"')
               os<<"require_once('"<< std::string(*it, 1, it->size()>2 ? it->size()-2 : it->size()-1 )<<"');\n";
            //else if ((*it)[0]=='\"')
            //   os<<"#include "<<*it<<"\n";
            else
               os<<"require_once('"<<*it<<"');\n";
           }
        return 0;
       }

    int generateDefines( std::ostream &os
                       , const std::vector<std::string> &definesList 
                       )
       {
        std::vector<std::string>::const_iterator it = definesList.begin();
        for(; it!=definesList.end(); ++it)
           {
            const std::string &def = *it;
            std::string::size_type pos = 0, size = def.size();
            for(; pos!=size; ++pos)
               {
                if (def[pos]==' ') break;
               }
            std::string macroName(def, 0, pos);
            std::string macroVal (def, pos!=size ? pos+1 : pos, std::string::npos);
            if (macroVal=="") macroVal = "1";
            os<<"if (!defined('"<<macroName<<"'))\n   {\n    "
              <<"define('"<<macroName<<"', "<<macroVal<<");\n   }\n";
           }
        return 0;
       }

    void generateNamespacesOpen(std::ostream &os, const std::vector<std::string> &namespaces)
       {
        os<<"\n";
        std::vector<std::string>::const_iterator it = namespaces.begin();
        for(; it!=namespaces.end(); ++it)
           {
            os<<"namespace "<<*it<<" {\n";
           }
        os<<"\n";
       }

    void generateNamespacesClose(std::ostream &os, const std::vector<std::string> &namespaces)
       {
        os<<"\n";
        std::vector<std::string>::const_reverse_iterator it = namespaces.rbegin();
        for(; it!=namespaces.rend(); ++it)
           {
            os<<"}; // namespace "<<*it<<" {\n";
           }
        os<<"\n";
       }

    // C/C++ helpers
    int generateAttributeDefinition( std::ostream &os, 
                                     const std::string &offs, 
                                     const marty::uml::CClassAttributeInfo &attrInfo, 
                                     const std::vector< std::string > &namespaces, 
                                     const std::string  &className, 
                                     bool plainC, 
                                     bool generateStaticConst,
                                     bool staticConstAsEnum,
                                     bool fFirst,
                                     bool fLast
                                   )
       {
        bool curAttrStaticConstWithVal = attrInfo.isStaticConstant();

        if (curAttrStaticConstWithVal!=generateStaticConst) return 0; // skip this attr

        bool stateEnumItem = false;
        if (curAttrStaticConstWithVal && staticConstAsEnum)
           {
            //plainC = false;
            stateEnumItem = true;
           }
        
        os<<offs; //"    ";
        if (!stateEnumItem && !curAttrStaticConstWithVal)
           {
                os<<alignLeft(
                               ( getVisibilityName(attrInfo.visibility).size()>0 
                               ? getVisibilityName(attrInfo.visibility) + std::string(" ") //+ std::string(":")  don't needed for PHP 
                               : getVisibilityName(attrInfo.visibility)
                               )
                             , 12
                             , ' '
                             );
           }

        // http://php.su/learnphp/phpoo/?php5_2
        std::string type; // don't needed for PHP = attrInfo.type.empty() ? (attrInfo.ptr ? std::string("void") : std::string("int")) : attrInfo.type;
        //std::string type = attrInfo.type.empty() ? std::string("int") : attrInfo.type;
        if (!stateEnumItem)
           {
            if (!plainC || !curAttrStaticConstWithVal)
               {
                if (curAttrStaticConstWithVal)
                   type = std::string("const "); // std::string("static const ") + type; don't needed for PHP 
    
                os<<alignLeft(type, 20, ' ');
                if (attrInfo.ptr || attrInfo.ref) 
                   {
                    //if (attrInfo.ptr) os<<"*";
                    //else              os<<"&"; 
                   }
                else
                   {
                    //os<<" ";
                   }
               }
           }

        std::string attrName = attrInfo.name;
         
        if (plainC && curAttrStaticConstWithVal)
           {
            //attrName = makeMethodName( namespaces, className, attrName);
            attrName = makeMethodName( "def", namespaces, className, attrName, true);
           }
        else
           {
            //if (!declaration)
            //attrName = className + std::string("::") + attrName;
           }

        if (!curAttrStaticConstWithVal) attrName = ::std::string("$") + attrName;
        if (attrName.size()>20)
           os<<alignLeft(attrName, 60, ' ');
        else
           os<<alignLeft(attrName, 12, ' ');

        if (!attrInfo.value.empty())
           {
            if (plainC && !stateEnumItem) os<<"    ";
            else        os<<" = ";
            os<<attrInfo.value;
           }

        if (!stateEnumItem)
           {
            if (!plainC || !curAttrStaticConstWithVal)
               os<<";";
           }
        else
           {
            if (!fLast) os<<",";
           }

        if (!attrInfo.comment.empty())
           {
            //if (plainC)
               os<<" /*!< "<<attrInfo.comment<<" */";
            //else
            //   os<<" //!< "<<attrInfo.comment;
           }

        os<<"\n";
        return 0;
       }

    

    int generateParameterDefinition( std::ostream &os, const marty::uml::CClassAttributeInfo &attrInfo, bool plainC, int typeAlign)
       {
        //os<<offs; //"    ";
        /* if (attrInfo.ioKind==marty::uml::eiokIn)
         *    os<<"const ";
         * else
         *    os<<"      ";
         */

        std::string type; // = attrInfo.type.empty() ? (attrInfo.ptr ? std::string("void") : std::string("int")) : attrInfo.type; don't needed for PHP 
        //std::string type = attrInfo.type.empty() ? (attrInfo.ptr ? std::string("void") : std::string("int")) : attrInfo.type;
        if (attrInfo.ioKind==marty::uml::eiokIn)
           {
            //type = std::string("const ") + type;
           }

        if (!typeAlign) return 1; // (int)type.size();

        //os<<alignLeft(type, typeAlign+1, ' ');

        if (attrInfo.ptr || attrInfo.ref) 
           {
            //if (attrInfo.ptr) os<<"*";
            //else              os<<"&"; 
            os<<"&";
           }
        else
           {
            os<<" ";
           }

        std::string attrName = std::string("$") + attrInfo.name;

        os<<alignLeft(attrName, 12, ' '); //<<";";
        if (!attrInfo.comment.empty())
           {
            //if (plainC)
               os<<" /*!< "<<attrInfo.comment<<" */";
            //else
            //   os<<" //!< "<<attrInfo.comment<<"";
           }

        return 0;
       }

    virtual std::string generateGuardVarSerializeCode( const std::string &guardVarName, const std::string &serializeToVarName )
       {
        std::ostringstream tmpSs;                                                          //(unsigned)
        tmpSs<<serializeToVarName<<" = \"Guard var value: \" . "<<guardVarName<<" . \" (\" . " << guardVarName<<" . \")\"; ";
        return tmpSs.str();
       }

    virtual std::string getSerializedVarValueCode( const std::string &serializeToVarName )
       {
        return serializeToVarName;
       }

    std::string makeMethodName( INameNotationMaker* nm
                              , const std::vector<std::string> &namespaces
                              , const std::string &className
                              , const std::string &methodName
                              , bool plainC
                              )
       {
        std::vector<std::string> nsList;
        if (plainC) nsList = namespaces;

        if (!className.empty() && plainC)
           {
            std::vector<std::string> vClassName;
            nmaker->splitName(className, vClassName);
            std::copy(vClassName.begin(), vClassName.end(), std::back_inserter(nsList) );
           }

        if (!methodName.empty())
           {
            std::vector<std::string> vMethodName;
            nmaker->splitName(methodName, vMethodName);
            std::copy(vMethodName.begin(), vMethodName.end(), std::back_inserter(nsList) );
           }

        //if (!className.empty())  nsList.push_back(className);
        //if (!methodName.empty()) nsList.push_back(methodName);
        return nm->makeName(nsList);
       }

    std::string makeMethodName( const std::vector<std::string> &namespaces
                              , const std::string &className
                              , const std::string &methodName
                              , bool plainC
                              )
       {
        return makeMethodName( nmaker, namespaces, className, methodName, plainC);
       }

    std::string makeMethodName( const std::string &nameStyle
                              , const std::vector<std::string> &namespaces
                              , const std::string &className
                              , const std::string &methodName
                              , bool plainC
                              )
       {
        /* std::auto_ptr<INameNotationMaker> nm = cretateNameNotationMaker(nameStyle);
         * return makeMethodName( nm.get(), namespaces, className, methodName);
         */
        INameNotationMaker *pnm = cretateNameNotationMaker(nameStyle);
        std::string res = makeMethodName( pnm, namespaces, className, methodName, plainC);
        delete pnm;
        return res;
       }

    int generateMethodDefinition( std::ostream &os, const std::string &offs, 
                                  const std::string &className, 
                                  const marty::uml::CClassMethodInfo &methodInfo, 
                                  const std::vector<std::string> &namespaces, 
                                  bool plainC, bool declaration)
       {
        if ( /* !plainC &&  */ methodInfo.virtualMethod && methodInfo.abstractMethod && !declaration) return 0;

        if (!plainC)
           os<<offs;
        
        if (methodInfo.virtualMethod && methodInfo.abstractMethod)
           os<<"abstract\n"<<offs;

        std::string offs2 = plainC ? std::string() : offs;
        //if (declaration)
        //   offs2 += std::string(4, '!');

        /* methodInfo.virtualMethod
         * methodInfo.abstractMethod
         */

        if (declaration && !plainC)
           {
            offs2 += std::string(4, ' ');

            os<<alignLeft(
                           ( getVisibilityName(methodInfo.visibility).size()>0 
                           ? getVisibilityName(methodInfo.visibility) + std::string(" ") // std::string(":") 
                           : getVisibilityName(methodInfo.visibility)
                           )
                         , 12
                         , ' '
                         );            
            os<<"\n"<<offs2;
            if (methodInfo.classScope)
               {
                //os<<"static\n"<<offs2;
               }
            else if (methodInfo.virtualMethod && declaration)
               {
                //os<<"virtual\n"<<offs2;
               }
           }
        else if(declaration)
           {
            os<<"EXTERN_C\n"<<offs2;
           
           }

        std::string type = methodInfo.type.empty() ? std::string("void") : methodInfo.type;
        std::string formatedType = type; //alignLeft(type, 12, ' ');
        //os<<formatedType;
        //os<<formatedType<<"\n"<<offs2;
        os<<"function\n"<<offs2;

        std::string methodName = methodInfo.name;
        
        if (declaration || plainC)
           methodName = makeMethodName( namespaces, className, methodName, plainC);
        else
           methodName = className + std::string("::") + makeMethodName( namespaces, className, methodName, false);

        /*
        if (plainC)
           {
            methodName = makeMethodName( namespaces, className, methodName);
           }
        else
           {
            std::vector<std::string> emprtyVec;
            // if (!declaration)
            //    methodName = className + std::string("::") + methodName;
            // 
            if (!declaration)
               methodName = className + std::string("::") + makeMethodName( emprtyVec, std::string(), methodName);
            else
               methodName = makeMethodName( emprtyVec, std::string(), methodName);
           }
        //makeMethodName
        */
        //os<<alignLeft(methodInfo.name, 32, ' ');
        os<<methodName;

        //offs2 += std::string(formatedType.size(), ' ');
        offs2 += std::string(methodName.size(), ' ');

        //os<<"\n"<<offs2<<"( ";
        os<<"\n"<<offs2<<"( ";


        std::vector<CMethodParameterInfo> params;

        if (plainC && !methodInfo.classScope)
           {
            CMethodParameterInfo param;
            param.name = "_pthis";
            param.type = className;
            param.comment = "Automaticaly generated this pointer";
            param.ptr = true;
            param.ref = false;

            if (methodInfo.query)
               param.ioKind = marty::uml::eiokIn;
            else
               param.ioKind = marty::uml::eiokUndef;

            //param.
            
            params.push_back(param);
           }

        std::copy(methodInfo.parameters.begin(), methodInfo.parameters.end(), std::back_inserter(params) );

        int maxTypeLen = 0;
        std::vector<CMethodParameterInfo>::const_iterator pit = params.begin();
        for(; pit!=params.end(); ++pit)
           {
            int len = generateParameterDefinition( os, *pit, plainC, 0);
            if (maxTypeLen<len) maxTypeLen = len;
           }

        pit = params.begin();
        for(; pit!=params.end(); ++pit)
           {
            if (pit!=params.begin())
               os<<", ";
            generateParameterDefinition( os, *pit, plainC, maxTypeLen);
            os<<"\n"<<offs2;
           }

        if (params.empty())
           os<<"\n"<<offs2;

        os<<")";

        //if (methodInfo.query && !plainC)
        //   os<<" const";

        //if (!plainC && methodInfo.virtualMethod && methodInfo.abstractMethod)
        //   os<<" = 0";

        //if (!plainC && methodInfo.virtualMethod && methodInfo.abstractMethod)
        //   os<<"{}";


        return 0;

        //os<<"\n"<<offs<<std::string(24, ' ')<<

        /*
        os<<offs; //"    ";
        if (definition)
        if (plainC)
           {
            os<<"            ";
           }
        else
           {
            os<<alignLeft(
                           ( getVisibilityName(attrInfo.visibility).size()>0 
                           ? getVisibilityName(attrInfo.visibility) + std::string(":") 
                           : getVisibilityName(attrInfo.visibility)
                           )
                         , 12
                         , ' '
                         );
           
           }

    std::string        name        ;
    std::string        stereotype  ; // event_handler
    std::string        type        ;
    EMemberVisibility  visibility  ; // 0 - pub, 1 - private, 2 - protected, 3 - implementation (?)
    bool               query       ; // const method
    bool               classScope  ; // static member
    std::string        comment     ;
    std::vector<CMethodParameterInfo> parameters;
        */
       }


    std::string generateLogEventCall( fsm::ISourceGenerator *pGen
                                    , const fsm::CStateMachineInfo &stateMachine
                                    , int genFlags
                                    , const std::string &automataClassName
                                    , const std::string &logMethodName
                                    , const std::string &pthisStr
                                    , const std::vector<std::string> &namespaces
                                    , const std::map< std::string, fsm::CConstantName > &stateNames
                                    , const fsm::CTransitionInfo &transition
                                    , const std::string &codeStr
                                    , const std::string &msgStr
                                    )
       {
        std::vector<std::string> callParams;
        callParams.push_back(codeStr);
    
    
        std::map< std::string, fsm::CConstantName >::const_iterator stIt = stateNames.find(transition.startState);
        if (stIt!=stateNames.end())
           {
            callParams.push_back(stIt->second.intName);
           }
        else
           {
            callParams.push_back("0");
           }
    
        stIt = stateNames.find(transition.endState);
        if (stIt!=stateNames.end())
           {
            callParams.push_back(stIt->second.intName);
           }
        else
           {
            callParams.push_back("0");
           }
    
        //callParams.push_back(strQuot + msgStr + strQuot);
        //callParams.push_back(escapeC(msgStr));
        //callParams.push_back(msgStr);
        callParams.push_back("$msg");
        //tmpSs<< pGen->generateGuardVarSerializeCode( pGen->modifyGuardVarName(guardObject), pGen->modifyGuardVarName("tmpss") );
    
        std::ostringstream ss;
        ss<<"{ $msg = "<<msgStr<<"; ";
        pGen->generateFunctionCall( ss, namespaces, automataClassName
                                  , logMethodName
                                  , pthisStr, callParams
                                  );
        ss<<" }";
        return ss.str();   
       }



};


}; // namespace fsm


#endif /* FSMGEN_LGPHPBASE_H */

