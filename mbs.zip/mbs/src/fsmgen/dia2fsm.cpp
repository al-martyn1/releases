/*!
\project dia2fsm - ��������� ������ .dia � .smxml - FSM XML (Finite State Machine XML format)

    \incpath #(BOOST.include) #(MARTYUSR.include)
    \libpath #(BOOST.lib) #(MARTYUSR.lib)

    \configuration release unicode_release
        \libraries cli2
        \libpath
        \incpath

    \configuration debug unicode_debug
        \libraries cli2
        \libpath
        \incpath


\platform mingw win32
    \configuration release unicode_release
        \libraries cli2 cli3
        \libpath
        \incpath
    
    \configuration debug unicode_debug
        \libraries cli2
        \libpath
        \incpath
*/

#include <iostream>
#include <fstream>

#if defined(DIA_USE_OLD_SIXML)
    #include <sixml/sixmlx.h>
    #include <sixml/serializ.h>
#else
    #include <cli/xml/sixml/pugixml/serializer.h>
    #ifndef CLI_MISC_READUTILS_H
        #include <cli/misc/readutils.h>
    #endif
    
    #ifndef CLI_MISC_WRITEUTILS_H
        #include <cli/misc/writeutils.h>
    #endif
#endif

#include <dia/dia.h>
#include <fsm/fsmdef.h>
#include <marty/libapi.h>
#include <marty/filename.h>
#include <marty/filesys.h>
#include <marty/confUtils.h>



#include <boost/algorithm/string/trim.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <boost/regex.hpp>

#if defined(DIA_USE_OLD_SIXML)
    #include "../common/6mlerr.h"
#else
    #define CATCH_6ML_ERRORS(bFlagErr, strErr) \
    catch(...)                                 \
       {                                       \
        return false;                          \
       }
#endif


#include "../dia/diaConv.h"




#include <sixml/sixmlx.cxx>
//#include <marty/filesys.cpp>



using MARTY_LIBAPI_NS       tstring;
using MARTY_FILENAME_NS     changeExtention;
using MARTY_LIBAPI_NS       getModuleFileName;
using MARTY_FILESYSTEM_NS   getCurrentDirectory;

using MARTY_FILESYSTEM_NS   openFile;
using MARTY_FILESYSTEM_NS   closeFile;
//using MARTY_FILESYSTEM_NS   handle_t;
using MARTY_FILESYSTEM_NS   fileopenmode;

inline
bool createFileOverwrite(const tstring &filename, bool fOverwrite)
   {
    fileopenmode omode = fileopenmode (MARTY_FILESYSTEM_NS o_rdwr | MARTY_FILESYSTEM_NS o_creat);
    if (!fOverwrite)
       omode = fileopenmode (omode | MARTY_FILESYSTEM_NS o_excl);
    
    MARTY_FILESYSTEM_NS handle_t hFile = openFile(filename, omode);
    if (hFile == MARTY_FILESYSTEM_NS hInvalidHandle) return false;
    closeFile(hFile);
    return true;
   }

int parse_option(const char* s);
int read_config_file(const char* fname);
void print_help();
int convertDiaFile( const tstring &diaFileName
                  , const tstring &fileOrPrefix
                  , bool fUseSeparateFiles
                  , bool fOverwrite);





tstring fsmFilename;      // -nname or -sprefix
bool    useSeparateFiles       = false; // -s
bool    overWriteExistingFiles = true;






int main(int argc, char* argv[])
   {
    tstring executableFileName;
    if (getModuleFileName(0, executableFileName))
       {
        std::cout<<"Error: system error - can't get executable file name.\nExiting.\n";
        return 0;
       }

    tstring confName = changeExtention( executableFileName, tstring(_T(".conf")));

    read_config_file(confName.c_str());

    for (int i=1; i<argc; i++)
        {
         int pr = 0;
         switch(*argv[i])
           {
            case '-':
            case '/':  pr = parse_option(argv[i]);
                       break;
            case '@':  pr = read_config_file(argv[i]+1);
                       break;
            
            default:
                       {
                        int res = convertDiaFile(argv[i], fsmFilename, useSeparateFiles, overWriteExistingFiles);
                        if (res) return res;
                       }

           };
         
         if (pr) return pr;     
        }

    return 0;
   }

//-----------------------------------------------------------------------------
int read_config_file(const char* fname) 
{
 std::ifstream cfg(fname);
 std::string cfg_line;
 std::getline(cfg,cfg_line);
 cfg_line = ::boost::algorithm::trim_copy(cfg_line); //trim(cfg_line);  
 while(cfg && cfg_line.size())
   {
      int pr = 0;
      switch(cfg_line[0])
        {
         case '-':
         case '/':  pr = parse_option(cfg_line.c_str());
                    break;
        };
    if (pr) return pr;
    std::getline(cfg,cfg_line);
    cfg_line = ::boost::algorithm::trim_copy(cfg_line); //trim(cfg_line);  
   }
 return 0;
}

//-----------------------------------------------------------------------------
int parse_option(const char* s)
{
 if (*s!='-' && *s!='/')
    {
     std::cout<<"Invalid command line option: '"<<s<<"'\n";
     return 3;
    }
 char key = *((++s)++);

 switch(key)
   {
    case 'o':
              if (*s=='-')
                 overWriteExistingFiles = false;
              else
                 overWriteExistingFiles = false;
              break;

    case 's':
              fsmFilename = s;
              useSeparateFiles = true;
              break;

    case 'n':
              fsmFilename = s;
              useSeparateFiles = false;
              break;

    case 'w':
              {
               ::std::string exeFilename;
               getModuleFileName(0, exeFilename);
               std::cout<<"dia2fsm location: "<<exeFilename<<"\n";
               return 1;
              }

    case '?': 
    case 'h': 
              print_help();
              return 2;              

    default:  
              std::cout<<"Invalid command line option: '-"<<s<<"'\n";
              print_help();
              return 3;
   };
 return 0;
}

//-----------------------------------------------------------------------------
void print_help()
{
 std::cout<<"Dia to FSM definition converter\n";
 std::cout<<"Converts Dia UML statechart diagram into finite state machine definition file\n";
 std::cout<<"Usage: dia2fsm [-option [-option]] file1.dia fil2.dia ...\n";
 std::cout<<"Options:\n";
 std::cout<<"  -o[+|-]         - overwrite mode on/off.\n";
 std::cout<<"  -sprefix        - save fsm's into separate files, 'prefix' is prefix for file name.\n";
 std::cout<<"  -nfilename      - save fsm's into single file.\n";
 std::cout<<"  -w              - prints path/name, where is dia2fsm located, and exit.\n";

}

//-----------------------------------------------------------------------------
int convertDiaFile( const tstring &diaFileName
                  , const tstring &fileOrPrefix
                  , bool fUseSeparateFiles
                  , bool fOverwrite)
   {
    if (diaFileName.empty() || diaFileName==tstring(_T("")))
       {
        std::cout<<"Error: no input file name specified.\nExiting.\n";
        return 4;
       }

    if (!fUseSeparateFiles && fileOrPrefix.empty())
       {
        std::cout<<"Error: output file name not taken.\nExiting.\n";
        return 4;
       }

    dia::CDiargam diagram;

    std::string errText;
    bool fErr = false;
    try{
        load_diagram(diaFileName, diagram);
       }
    CATCH_6ML_ERRORS(fErr, errText)
    if (fErr)
       {
        std::cout<<"Current directory: "<<getCurrentDirectory()<<"\n";
        std::cout<<"Error: failed to read '"<<diaFileName<<"' dia diagram file: "<<errText<<"\n";

        return 4;
       }

    fsm::CFsmConfig fsm;

    convertDiaDiagram(diagram, fsm);


    // if single file, save fsm here
    if (!fUseSeparateFiles)
       {
        fErr = false;
        tstring filename = fileOrPrefix;
        filename = changeExtention( filename, tstring(_T(".smxml")));

        if (!createFileOverwrite(filename, overWriteExistingFiles))
           {
            fErr = true;
            errText = "can't create file - may be file allready exist.";
           }
        else
           {
            try{
                if (filename.empty())
                   {
                    fErr = true;
                    //errText = "Error: failed to save output file - file name is empty";
                    errText = "file name is empty";
                   }
                else
                   {
                    fsm::save_fsmdef(filename, fsm);
                   }
                //tstring(_T("_"))
               }
            CATCH_6ML_ERRORS(fErr, errText)
           }
        if (fErr)
           {
            std::cout<<"Error: failed to save '"<<filename<<"' fsm definition file: "<<errText<<"\n";
            return 4;
           }
       }
    else // split into separate files
       {
        std::vector<fsm::CStateMachineInfo>::const_iterator smIt = fsm.fsmList.begin();
        for(;smIt!=fsm.fsmList.end(); ++smIt)
           {
            fsm::CFsmConfig tmpFsm;
            tmpFsm.fsmList.push_back(*smIt);

            fErr = false;
            tstring filename = fileOrPrefix + smIt->name;
            filename = changeExtention( filename, tstring(_T(".smxml")));

            if (!createFileOverwrite(filename, overWriteExistingFiles))
               {
                fErr = true;
                errText = "can't create file - may be file allready exist.";
               }
            else
               {
                try{
                    if (filename.empty())
                       {
                        fErr = true;
                        //errText = "Error: failed to save output file - file name is empty";
                        errText = "file name is empty";
                       }
                    else
                       {
                        fsm::save_fsmdef(filename, tmpFsm);
                       }
                    //tstring(_T("_"))
                   }
                CATCH_6ML_ERRORS(fErr, errText)
               }

            if (fErr)
               {
                std::cout<<"Error: failed to save '"<<filename<<"' fsm definition file: "<<errText<<"\n";
                return 4;
               }

           }
       }
    return 0;
   }

