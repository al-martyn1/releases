#ifndef CLASSHOLDER_H
#define CLASSHOLDER_H

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif


#include <fsm/fsmdef.h>
#include "lgCBase.h"


namespace fsmgen
{

class CClassHolder
{

    protected:

    const marty::uml::CClassInfo     *pClassInfo;
    const std::vector<std::string>   &namespaces;
    //fsm::ICBaseGenerator             *pGen;
    fsm::ISourceGenerator            *pGen;
    

    public:

    //CClassHolder() : pClassInfo() {}
    CClassHolder( const marty::uml::CClassInfo   *pci
                , const std::vector<std::string> &ns
                , fsm::ISourceGenerator          *pg)
       : pClassInfo(pci)
       , namespaces(ns)
       , pGen(pg)
       {}

    bool isMemberMethod(const std::string &name)
       {
        if (!pClassInfo || name.empty()) return false;
        std::vector<marty::uml::CClassMethodInfo>::const_iterator b = pClassInfo->methods.begin();
        std::vector<marty::uml::CClassMethodInfo>::const_iterator e = pClassInfo->methods.end();
        std::vector<marty::uml::CClassMethodInfo>::const_iterator mit = std::find_if(b, e, fsm::IsEqualByName<marty::uml::CClassMethodInfo>(name));
        if (mit==e) return false;
        return true;        
       }

    bool isMemberAttr(const std::string &name)
       {
        if (!pClassInfo || name.empty()) return false;
        std::vector<CClassAttributeInfo>::const_iterator ait = std::find_if(pClassInfo->attributes.begin(), pClassInfo->attributes.end(), fsm::IsEqualByName<marty::uml::CClassAttributeInfo>(name));
        if (ait==pClassInfo->attributes.end()) return false;
        return true;        
       }

    bool isStaticConstMemberAttr(const std::string &name)
       {
        if (!pClassInfo || name.empty()) return false;
        std::vector<CClassAttributeInfo>::const_iterator ait = std::find_if(pClassInfo->attributes.begin(), pClassInfo->attributes.end(), fsm::IsEqualByName<marty::uml::CClassAttributeInfo>(name));
        if (ait==pClassInfo->attributes.end()) return false;
        if (ait->classScope && ait->constAttr) return true;
        return false;
       }

};

}; // namespace fsmgen



#endif /* CLASSHOLDER_H */

