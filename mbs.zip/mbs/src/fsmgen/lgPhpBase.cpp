#include <cli/cli2.h>

#include <boost/algorithm/string/trim.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <boost/algorithm/string/case_conv.hpp>

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#if !defined(_FSTREAM_) && !defined(_STLP_FSTREAM) && !defined(__STD_FSTREAM__) && !defined(_CPP_FSTREAM) && !defined(_GLIBCXX_FSTREAM)
    #include <fstream>
#endif

#if !defined(_SSTREAM_) && !defined(_STLP_SSTREAM) && !defined(__STD_SSTREAM__) && !defined(_CPP_SSTREAM) && !defined(_GLIBCXX_SSTREAM)
    #include <sstream>
#endif


#include <marty/filename.h>

#include "lgPhpBase.h"
#include "util.h"
#include "generator.h"



//using MARTY_FILENAME_NS     changeExtention;

/*
using ::boost::algorithm::to_lower_copy;

        targetConf.name = to_lower_copy(confIt->NameOnly);
        std::transform(targetConf.name.begin(), targetConf.name.end(), targetConf.name.begin(), util::CSpaceTransformator());
*/

namespace fsm
{

int IPhpBaseGenerator::generateCppTransitionCoverage( std::ostream &os )
   {
    os<<"\
#ifndef CTRANSITIONINFOKEY_DEFINED\n\
#define CTRANSITIONINFOKEY_DEFINED\n\
\n\
struct CTransitionInfoKey\n\
{\n\
    std::string  startState;\n\
    std::string  endState;\n\
    std::string  trigger;\n\
    std::string  guard;\n\
    std::string  startOrgName;\n\
    std::string  endOrgName;\n\
\n\
    CTransitionInfoKey()\n\
       : startState()\n\
       , endState()\n\
       , trigger()\n\
       , guard()\n\
       , startOrgName()\n\
       , endOrgName()\n\
       {}\n\
\n\
    CTransitionInfoKey(const CTransitionInfoKey &ti)\n\
       : startState(ti.startState)\n\
       , endState(ti.endState)\n\
       , trigger(ti.trigger)\n\
       , guard(ti.guard)\n\
       , startOrgName(ti.startOrgName)\n\
       , endOrgName(ti.endOrgName)\n\
       {}\n\
\n\
    CTransitionInfoKey(const std::string &s, const std::string &oS, const std::string &e, const std::string &oE, const std::string &t, const std::string &g)\n\
       : startState(s)\n\
       , endState(e)\n\
       , trigger(t)\n\
       , guard(g)\n\
       , startOrgName(oS)\n\
       , endOrgName(oE)\n\
       {}\n\
};\n\
\n\
\n\
struct CTransitionInfoKeyLess\n\
{\n\
    bool operator()(const CTransitionInfoKey &tr1, const CTransitionInfoKey &tr2) const\n\
       {\n\
        int cmpStart = tr1.startState.compare(tr2.startState);\n\
        if (cmpStart<0) return true;\n\
        else if (!cmpStart)\n\
           {\n\
            int cmpEnd = tr1.endState.compare(tr2.endState);\n\
            if (cmpEnd<0) return true;\n\
            else if (!cmpEnd)\n\
               {\n\
                int cmpTrigger = tr1.trigger.compare(tr2.trigger);\n\
                if (cmpTrigger<0) return true;\n\
                else if (!cmpTrigger)\n\
                   {\n\
                    int cmpGuard = tr1.guard.compare(tr2.guard);\n\
                    if (cmpGuard<0) return true;\n\
                   }\n\
               }\n\
           }\n\
        return false;\n\
       }\n\
};\n\
\n\
struct CTransitionInfoPrinter\n\
{\n\
    std::ostream &os;\n\
    unsigned     &zeroCount;\n\
    bool          printStep;\n\
    bool          printOrgNames;\n\
    unsigned      &fromLen;\n\
    unsigned      &toLen;\n\
    unsigned      &eventLen;\n\
    unsigned      &guardLen;\n\
\n\
    CTransitionInfoPrinter(std::ostream &o, unsigned &zc, unsigned &fl, unsigned &tl, unsigned &el, unsigned &gl)\n\
       : os(o)\n\
       , zeroCount(zc)\n\
       , printStep(false)\n\
       , printOrgNames(false)\n\
       , fromLen(fl)\n\
       , toLen(tl) \n\
       , eventLen(el)\n\
       , guardLen(gl)\n\
       {}\n\
    CTransitionInfoPrinter(const CTransitionInfoPrinter &tip)\n\
       : os(tip.os)\n\
       , zeroCount(tip.zeroCount)\n\
       , printStep(tip.printStep)\n\
       , printOrgNames(tip.printOrgNames)\n\
       , fromLen(tip.fromLen)\n\
       , toLen(tip.toLen)\n\
       , eventLen(tip.eventLen)\n\
       , guardLen(tip.guardLen)\n\
       {}\n\
\n\
    void setCalcLenMode()       { printStep = false; }\n\
    void setPrintMode()         { printStep = true; }\n\
    void setPrintOrgNamesMode(bool printOrg = true) { printOrgNames = printOrg; }\n\
\n\
\n\
    template <typename T>\n\
    std::string startName(const T &elem)\n\
       {\n\
        if (!printOrgNames)\n\
           return elem.first.startState;\n\
        else\n\
           return elem.first.startOrgName;\n\
        \n\
       }\n\
\n\
    template <typename T>\n\
    std::string endName(const T &elem)\n\
       {\n\
        if (!printOrgNames)\n\
           return elem.first.endState;\n\
        else\n\
           return elem.first.endOrgName;\n\
        \n\
       }\n\
\n\
\n\
    template <typename T>\n\
    void operator()(const T &elem)\n\
       {\n\
        if (!printStep)\n\
           {\n\
            if (fromLen<(unsigned)startName(elem).size())\n\
               fromLen = (unsigned)startName(elem).size();\n\
            if (toLen<(unsigned)endName(elem).size())\n\
               toLen = (unsigned)endName(elem).size();\n\
            if (eventLen<(unsigned)elem.first.trigger.size())\n\
               eventLen = elem.first.trigger.size();\n\
            if (guardLen<(unsigned)elem.first.guard.size())\n\
               guardLen = elem.first.guard.size();\n\
            if (!elem.second)\n\
               ++zeroCount;\n\
            return;\n\
           }\n\
\n\
        std::ios_base::fmtflags oldFlags = std::cout.flags();\n\
        std::cout.setf(std::ios_base::left, std::ios_base::adjustfield);\n\
        if (!elem.second)\n\
           {\n\
            os<<\"! \";\n\
           }\n\
        else\n\
           {\n\
            os<<\"  \";\n\
           }\n\
        os<<\"From \"<<std::setw(fromLen)<<startName(elem)<<\" to  \"<<std::setw(toLen)<<endName(elem)<<\" on  \"<<std::setw(eventLen)<<elem.first.trigger<<\"   with guard: \"<<std::setw(guardLen)<<elem.first.guard<<\",  counter: \"<<std::setw(4)<<elem.second<<\"\\n\";\n\
        std::cout.flags(oldFlags);\n\
       }\n\
};\n\
\n\
\n\
template <typename TAutomata>\n\
void printTransitionCoverageStat(const TAutomata& ta, std::ostream &os, bool printOrgNames)\n\
{\n\
    unsigned zeroCount = 0;\n\
    unsigned stateFromMaxLen = 0;\n\
    unsigned stateToMaxLen = 0;\n\
    unsigned eventNameMaxLen = 0;\n\
    unsigned guardNameMaxLen = 0;\n\
\n\
    os<<\"\\nTransition coverage statistic:\\n\";\n\
    CTransitionInfoPrinter printer(os, zeroCount, stateFromMaxLen, stateToMaxLen, eventNameMaxLen, guardNameMaxLen);\n\
    printer.setPrintOrgNamesMode(printOrgNames);\n\
    std::for_each(ta.transitionsCoverage.begin(), ta.transitionsCoverage.end(), printer);\n\
\n\
    printer.setPrintMode();\n\
    std::for_each(ta.transitionsCoverage.begin(), ta.transitionsCoverage.end(), printer);\n\
\n\
    os<<\"\\nUncovered transitions: \"<<zeroCount<<\"\\n\";\n\
\n\
}\n\
\n\
#endif /* CTRANSITIONINFOKEY_DEFINED */\n\n\n\n\
";
    return 0;   
   }

//-----------------------------------------------------------------------------
int IPhpBaseGenerator::generatePushStateCode( const CClassInfo &curClass
                         , const std::vector<std::string> &namespaces
                         , std::ostream &os
                         , bool bPlain
                         , bool bCallOverflows
                         , bool bLangPlainC
                         )
   {
    std::map< std::string, fsm::CConstantName > constantNames;
    constantNames["stackSizeMax"] = fsm::CConstantName(false, 0);
    this->generateConstantNames(constantNames, namespaces, curClass.name, std::string("LIM_"), std::string());
    std::vector<std::string> emptyVec;

    if (bPlain)
       {
        os<<"\
if (_pthis->stackPos>="<<constantNames["stackSizeMax"].intName<<")\n\
   {\n\
    ";
        if (bCallOverflows)
           {
            //os<<"_pthis->stackOverflow();\n";
            generateFunctionCall( os, namespaces, curClass.name, "stackOverflow", "_pthis", emptyVec);
            os<<"\n";
           }
        else
           {
            os<<"/* calling stackOverflow disabled by generator options */\n";
           }
        os<<"\
   }\n\
else\n\
   {\n\
    _pthis->stateStack[_pthis->stackPos++] = curState;\n\
    _pthis->curState = newState;\n\
   }\n\
return _pthis->curState;\n\
";
       }
    else
       {
        os<<"\
try{\n\
    _pthis->stateStack.push(_pthis->curState);\n\
    _pthis->curState = newState;\n\
   }\n\
catch(...)\n\
   {\n    ";
        if (bCallOverflows)
           {
            generateFunctionCall( os, namespaces, curClass.name, "stackOverflow", "_pthis", emptyVec);
            os<<"\n";
            //os<<"_pthis->stackOverflow();\n";
           }
        else
           {
            os<<"/* calling stackOverflow disabled by generator options */\n";
           }
        os<<"\
   }\n\
return _pthis->curState;\
";
       }
    
    return 0;
   }

//-----------------------------------------------------------------------------
int IPhpBaseGenerator::generateSpawnStateCode( const CClassInfo &curClass
                         , const std::vector<std::string> &namespaces
                         , std::ostream &os
                         , bool bPlain
                         , bool bCallOverflows
                         , bool bLangPlainC
                         )
   {
    os<<"\
    _pthis->curState = newState;\n\
    return _pthis->curState;\n\
";
    return 0;
   }

//-----------------------------------------------------------------------------
int IPhpBaseGenerator::generatePopStateCode( const CClassInfo &curClass
                        , const std::vector<std::string> &namespaces
                        , std::ostream &os
                        , bool bPlain
                        , bool bCallOverflows
                        , bool bLangPlainC
                        )
   {
    std::vector<std::string> emptyVec;
    if (bPlain)
       {
        os<<"\
if (stackPos<=0)\n\
   {\n    ";
        if (bCallOverflows)
           {
            generateFunctionCall( os, namespaces, curClass.name, "stackUnderflow", "_pthis", emptyVec);
            os<<"\n";
            //os<<"_pthis->stackUnderflow();\n";
           }
        else
           { 
            os<<"/* calling stackUnderflow disabled by generator options */\n";
           }
        os<<"\
   }\n\
else\n\
   {\n\
    _pthis->curState = _pthis->stateStack[--_pthis->stackPos];\n\
   }\n\
return _pthis->curState;\n\
";

       }
    else
       {
        os<<"\
if (_pthis->stateStack.empty())\n\
   {\n    ";
        if (bCallOverflows)
           {
            generateFunctionCall( os, namespaces, curClass.name, "stackUnderflow", "_pthis", emptyVec);
            os<<"\n";
            //os<<"_pthis->stackUnderflow();\n";
           }
        else
           {
            os<<"/* calling stackUnderflow disabled by generator options */\n";
           }
        os<<"\
   }\n\
else\n\
   {\n\
    _pthis->curState = _pthis->stateStack.top();\n\
    _pthis->stateStack.pop();\n\
   }\n\
return _pthis->curState;\
";
       }

    return 0;
   }

//-----------------------------------------------------------------------------
int IPhpBaseGenerator::generateClearStateStackCode( const CClassInfo &curClass
                               , const std::vector<std::string> &namespaces
                               , std::ostream &os
                               , bool bPlain
                               , bool bCallOverflows
                               )
   {
    if (bPlain)
       {
        os<<"_pthis->stackPos = 0;";
       }
    else
       {
        os<<"while(!_pthis->stateStack.empty()) _pthis->stateStack.pop();";
       }
    return 0;
   }

//-----------------------------------------------------------------------------
int IPhpBaseGenerator::addStackVars( CClassInfo &curClass
                                 , const std::vector<std::string> &namespaces
                                 , const std::string &stackSizeStr
                                 , bool bPlainCodeStyle
                                 , bool bCallOverflows
                                 , bool bInline
                                 , bool bLangPlainC
                                 )
   {
    std::map< std::string, fsm::CConstantName > constantNames;
    constantNames["stackSizeMax"] = fsm::CConstantName(false,  0 /* stackSize */ );
    this->generateConstantNames(constantNames, namespaces, curClass.name, std::string("LIM_"), std::string());


    {
     marty::uml::CClassAttributeInfo attr;
 
     attr.name        = constantNames["stackSizeMax"].attrName;
     attr.type        = "int";
 
     /*
     char buf[256];
     wsprintf(buf, "0x%08X", constantNames["stackSizeMax"].value);
     */
     attr.value       = stackSizeStr;
 
     attr.comment     = "Automaticaly generated stack size limit constant";
     attr.ptr         = false;
     attr.ref         = false;
      
     attr.visibility  = marty::uml::emvPub; // 0 - pub, 1 - private, 2 - protected, 3 - implementation (?)
     attr.classScope  = true; // static member 
     attr.constAttr   = true;
 
     curClass.attributes.push_back(attr);
    }

    if (bPlainCodeStyle)
       {
         {
            marty::uml::CClassAttributeInfo attr;
            attr.name = "stackPos";
            attr.type        = "int";
            attr.visibility  = marty::uml::emvPro;
           
            attr.comment     = "Automaticaly generated stack pointer";
            attr.ptr         = false;
            attr.ref         = false;
            curClass.attributes.push_back(attr);
         }
         {
            marty::uml::CClassAttributeInfo attr;
            attr.name = std::string("stateStack[") +  stackSizeStr + std::string("]");
            attr.type        = "int";
            attr.visibility  = marty::uml::emvPro;
           
            attr.comment     = "Automaticaly generated state stack array";
            attr.ptr         = false;
            attr.ref         = false;
            curClass.attributes.push_back(attr);
         }
       }
    else
       {
        marty::uml::CClassAttributeInfo attr;
        attr.name = std::string("stateStack");
        attr.type        = "std::stack<int>";
        attr.visibility  = marty::uml::emvPro;
       
        attr.comment     = "Automaticaly generated state stack";
        attr.ptr         = false;
        attr.ref         = false;
        curClass.attributes.push_back(attr);
       }

    {
        marty::uml::CClassMethodInfo m;
        m.name = "callState";
        m.type = "int";
        m.visibility = marty::uml::emvPro;
        m.comment = "Automaticaly generated method";
        m.virtualMethod = false;
        m.abstractMethod = false; // pureVirtual

        marty::uml::CMethodParameterInfo p;
        p.name   = "newState";
        p.type   = "int";
        p.ioKind = marty::uml::eiokUndef;
        p.comment = "new state code";
        m.parameters.push_back(p);

        std::ostringstream os;
        this->generatePushStateCode( curClass, namespaces, os, bPlainCodeStyle, bCallOverflows, bLangPlainC);
        m.addCode(getLangName(), os.str(), bInline);

        curClass.methods.push_back(m);
    }

    {
        marty::uml::CClassMethodInfo m;
        m.name = "spawnState";
        m.type = "int";
        m.visibility = marty::uml::emvPro;
        m.comment = "Automaticaly generated method";
        m.virtualMethod = false;
        m.abstractMethod = false; // pureVirtual

        marty::uml::CMethodParameterInfo p;
        p.name   = "newState";
        p.type   = "int";
        p.ioKind = marty::uml::eiokUndef;
        p.comment = "new state code";
        m.parameters.push_back(p);

        std::ostringstream os;
        this->generateSpawnStateCode( curClass, namespaces, os, bPlainCodeStyle, bCallOverflows, bLangPlainC);
        m.addCode(getLangName(), os.str(), bInline);

        curClass.methods.push_back(m);
    }


    {
        marty::uml::CClassMethodInfo m;
        m.name = "returnFromState";
        m.type = "int";
        m.visibility = marty::uml::emvPro;
        m.comment = "Automaticaly generated method";
        m.virtualMethod = false;
        m.abstractMethod = false; // pureVirtual

        std::ostringstream os;
        this->generatePopStateCode( curClass, namespaces, os, bPlainCodeStyle, bCallOverflows, bLangPlainC);
        m.addCode(getLangName(), os.str(), bInline);

        curClass.methods.push_back(m);
    }

    {
        marty::uml::CClassMethodInfo m;
        m.name = "clearStateStack";
        m.type = "void";
        m.visibility = marty::uml::emvPro;
        m.comment = "Automaticaly generated method";
        m.virtualMethod = false;
        m.abstractMethod = false; // pureVirtual

        std::ostringstream os;
        this->generateClearStateStackCode( curClass, namespaces, os, bPlainCodeStyle, bCallOverflows);
        m.addCode(getLangName(), os.str(), bInline);

        curClass.methods.push_back(m);
    }
    
    if (bCallOverflows)
       {
        marty::uml::CClassMethodInfo m;
        m.name = "stackOverflow";
        m.type = "void";
        m.visibility = marty::uml::emvPro;
        m.comment = "Automaticaly generated method abstract method";
        m.virtualMethod = true;
        m.abstractMethod = true; // pureVirtual
        curClass.methods.push_back(m);       

        m.name = "stackUnderflow";
        curClass.methods.push_back(m);
       }


    return 0;
   }

//-----------------------------------------------------------------------------
int IPhpBaseGenerator::addStackIncludesDefines( const CClassInfo &curClass
                           , const std::vector<std::string> &namespaces
                           , std::vector<std::string> &includes
                           , std::vector<std::string> &defines
                           , bool bPlain
                           )
   {
    //if (!bPlain)
    //   includes.push_back("<stack>");

    return 0;
   }

//-----------------------------------------------------------------------------
int IPhpBaseGenerator::parseForConvertCode( const std::string &cppStyleCode
                                        , const std::vector<std::string> &defines
                                        , std::vector<CScannerEvent> &scannerEvents
                                        )
   {
    //nmdl::CNmdlErrorContext errContext;
    CScannerErrorContext   errContext;

    //std::vector<CScannerEvent> scannerEvents;
    std::vector<std::string>   processedFiles;
    CIncludeFinderImpl       includeFinder;

    CC2IdlScanner scanner(scannerEvents, processedFiles, "-");
    scanner.setDefaultPreprocessor();
    scanner.getPreprocessor()->setIncludeFinder(&includeFinder);
    scanner.setErrorContext(&errContext);

    std::vector<std::string>::const_iterator dit = defines.begin();
    for(; dit!=defines.end(); ++dit)
       scanner.getPreprocessor()->addMacro(*dit);

    std::string::size_type pos = 0, size = cppStyleCode.size();
    for(; pos!=size; ++pos)
       {
        if (!scanner.put((unsigned char)cppStyleCode[pos]))
           {
            return 1;
           }
       }
    scanner.finalize();

    return 0;
   }

int IPhpBaseGenerator::generateMemberAccess( std::ostream &os
                        , const std::string &memberName
                        , const std::string &pthisName
                        )
   {
    os<<"$"<<pthisName<<"->"<<memberName;
    return 0;
   }

int IPhpBaseGenerator::generateHeaderProlog( std::ostream &os
                           , const std::string &filename
                           , const std::vector<std::string> &namespaces
                           , const std::vector<std::string> &incFiles
                           , const std::vector<std::string> &defines
                           )
   {
    std::string incGuard = filename;
    std::transform(incGuard.begin(), incGuard.end(), incGuard.begin(), fsm::util::CToCMacroTransformator());
    os<<"<?php\n"; 
    os<<"/* Warning! Automaticaly generated file, do not edit */\n/* Visit www.purefractalsolutions.com for more details */\n";
    os<<"if (!defined('"<<incGuard<<"'))\n   {\n    define('"<<incGuard<<"', 1);\n   }\n";

    generateIncludes(os, incFiles);
    os<<"\n\n";
    generateDefines(os, defines);
    os<<"\n\n";

    return 0;
   }

int IPhpBaseGenerator::generateHeaderEpilog( std::ostream &os
                           , const std::string &filename
                           , const std::vector<std::string> &namespaces
                           )
   {
    //std::string incGuard = filename;
    //std::transform(incGuard.begin(), incGuard.end(), incGuard.begin(), fsm::util::CToCMacroTransformator());
    //os<<"#endif /* "<<incGuard<<" */\n";
    os<<"?>";
    return 0;
   }

int IPhpBaseGenerator::generateSourceProlog( std::ostream &os
                           , const std::string &filename
                           , const std::vector<std::string> &namespaces
                           , const std::vector<std::string> &incFiles
                           , const std::vector<std::string> &defines
                           )
   {

    os<<"<?php\n/* Warning! Automaticaly generated file, do not edit */\n/* Visit www.purefractalsolutions.com for more details */\n\n";
    generateIncludes(os, incFiles);
    os<<"\n\n";
    generateDefines(os, defines);
    os<<"\n\n";

    return 0;
   }

int IPhpBaseGenerator::generateSourceEpilog( std::ostream &os
                           , const std::string &filename
                           , const std::vector<std::string> &namespaces
                           )
   {
    os<<"?>";
    return 0;
   }


}; // namespace fsm

