#ifndef ASER_ASCANNEREVENTSERIALIZER_AUTOMATA_H
#define ASER_ASCANNEREVENTSERIALIZER_AUTOMATA_H

/* Warning! Automaticaly generated file, do not edit */

#include "../scanner/lextypes.h"
#include "../scanner/scanner.h"


#ifndef _pthis
#define _pthis this
#endif




namespace codegen {

class CScannerEventSerializator {

    public:     std::string          buf         ;
    protected:  int                  curState    ; //!< Automaticaly added member for saving current automata state
    public:     static const int     ST_END       = 0x80000001; //!< END
    public:     static const int     ST_WaitGt    = 0x00000002; //!< WAIT_GT
    public:     static const int     ST_WaitLt    = 0x00000003; //!< WAIT_LT
    public:     static const int     ST_WaitLtgt  = 0x00000004; //!< WAIT_LTGT
    public:     static const int     ST_IntStatefinalmask = 0x80000000; //!< __int_stateFinalMask__


    public:     
        int
        putEvent( const CScannerEvent &evt         
                )
           {
            /* guard variable - evt.token */
            switch(this->curState)
               {
                case ST_WaitGt:    /* WAIT_GT */
                        if (evt.token==LT_GREATER || evt.token==LT_SHIFT_RIGHT) /* Guard: [LT_GREATER,LT_SHIFT_RIGHT] */
                           {
                            this->curState = ST_WaitGt;
                               /* State WAIT_GT - exit_action empty */
                               /* Transition from WAIT_GT to WAIT_GT actions */
                               { appendBuf(" "); appendBuf(evt.text); }
                               /* State WAIT_GT - entry_action empty */
                           }
                        else
                           {
                            this->curState = ST_WaitLtgt;
                               /* State WAIT_GT - exit_action empty */
                               /* Transition from WAIT_GT to WAIT_LTGT actions */
                               { appendBuf(evt.text); }
                               /* State WAIT_LTGT - entry_action empty */
                           }
                     break;
                case ST_WaitLt:    /* WAIT_LT */
                        if (evt.token==LT_LESS || evt.token==LT_SHIFT_LEFT) /* Guard: [LT_LESS,LT_SHIFT_LEFT] */
                           {
                            this->curState = ST_WaitLt;
                               /* State WAIT_LT - exit_action empty */
                               /* Transition from WAIT_LT to WAIT_LT actions */
                               { appendBuf(" "); appendBuf(evt.text); }
                               /* State WAIT_LT - entry_action empty */
                           }
                        else
                           {
                            this->curState = ST_WaitLtgt;
                               /* State WAIT_LT - exit_action empty */
                               /* Transition from WAIT_LT to WAIT_LTGT actions */
                               { appendBuf(evt.text); }
                               /* State WAIT_LTGT - entry_action empty */
                           }
                     break;
                case ST_WaitLtgt:    /* WAIT_LTGT */
                        if (evt.token==LT_GREATER || evt.token==LT_SHIFT_RIGHT) /* Guard: [LT_GREATER,LT_SHIFT_RIGHT] */
                           {
                            this->curState = ST_WaitGt;
                               /* State WAIT_LTGT - exit_action empty */
                               /* Transition from WAIT_LTGT to WAIT_GT actions */
                               { appendBuf(evt.text); }
                               /* State WAIT_GT - entry_action empty */
                           }
                        else if (evt.token==LT_LESS || evt.token==LT_SHIFT_LEFT) /* Guard: [LT_LESS,LT_SHIFT_LEFT] */
                           {
                            this->curState = ST_WaitLt;
                               /* State WAIT_LTGT - exit_action empty */
                               /* Transition from WAIT_LTGT to WAIT_LT actions */
                               { appendBuf(evt.text); }
                               /* State WAIT_LT - entry_action empty */
                           }
                        else
                           {
                            this->curState = ST_WaitLtgt;
                               /* State WAIT_LTGT - exit_action empty */
                               /* Transition from WAIT_LTGT to WAIT_LTGT actions */
                               { appendBuf(evt.text); }
                               /* State WAIT_LTGT - entry_action empty */
                           }
                     break;
               };
            return this->curState;
           }

    public:     
        int
        eod( )
           {
            /* there is no guard variable */
            switch(this->curState)
               {
                case ST_WaitGt:    /* WAIT_GT */
                           {
                            this->curState = ST_END;
                               /* State WAIT_GT - exit_action empty */
                               /* Transition from WAIT_GT to END actions */
                               /* State END - entry_action empty */
                           }
                     break;
                case ST_WaitLt:    /* WAIT_LT */
                           {
                            this->curState = ST_END;
                               /* State WAIT_LT - exit_action empty */
                               /* Transition from WAIT_LT to END actions */
                               /* State END - entry_action empty */
                           }
                     break;
                case ST_WaitLtgt:    /* WAIT_LTGT */
                           {
                            this->curState = ST_END;
                               /* State WAIT_LTGT - exit_action empty */
                               /* Transition from WAIT_LTGT to END actions */
                               /* State END - entry_action empty */
                           }
                     break;
               };
            return this->curState;
           }

    private:    
        void
        appendBuf( const std::string &str         
                 )
           {
            buf.append(str);
           }

    public:     
        int
        getCurState( ) const
           {
            return this->curState;
           }

    public:     
        int
        isInFinalState( ) const
           {
            return (this->curState & ST_IntStatefinalmask) ? 1 : 0;
           }

    protected:  
        virtual
        void
        customResetAutomata( )
           {
            return;
           }

    public:     
        void
        resetAutomata( )
           {
            this->curState = ST_WaitLtgt;
            this->customResetAutomata(  );
           }

    public:     
        int
        isInInadmissibleFinalState( )
           {
            return 0;
           }


};


}; // namespace codegen {

#endif /* ASER_ASCANNEREVENTSERIALIZER_AUTOMATA_H */
