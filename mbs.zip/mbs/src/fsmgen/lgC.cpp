#include <cli/cli2.h>

#include "lgC.h"
#include "util.h"

#include "../scanner/idlScanner.h"
#include "serializeSE.h"

#include "classHolder.h"
#include "pp2c_ACConverter_Automata.h"

#include "generator.h"

namespace fsm
{


struct CCpp2CConverter : public codegen::c::CCppConverter, fsmgen::CClassHolder
{
    
    CCpp2CConverter( const marty::uml::CClassInfo   *pci
                   , const std::vector<std::string> &ns
                   , fsm::ISourceGenerator          *pg)
    : codegen::c::CCppConverter()
    , fsmgen::CClassHolder(pci, ns, pg)
    {}

    int
    eventIsMemberMethod( const CScannerEvent &evt         
                       )
    {
     if (evt.token!=LT_IDENT) return 0; // no a member
     else if (fsmgen::CClassHolder::isMemberMethod(evt.text)) return 1;
     return 0;
    }

    int
    eventIsMemberAttr( const CScannerEvent &evt         
                     )
    {
     if (evt.token!=LT_IDENT) return 0; // no a member
     else if (fsmgen::CClassHolder::isMemberAttr(evt.text)) return 1;
     return 0;
    }

    int
    eventIsMemberConstStaticAttr
                                ( const CScannerEvent &evt         
                                )
    {
     if (evt.token!=LT_IDENT) return 0; // no a member
     else if (fsmgen::CClassHolder::isStaticConstMemberAttr(evt.text)) return 1;
     return 0;
    }

    void
    mangleNameToC( CScannerEvent &evt         
                 )
    {
     if (evt.token!=LT_IDENT) return;
     if (!pClassInfo) return;
     evt.text = pGen->makeMethodName( namespaces, pClassInfo->name, evt.text, true);
    }


};

//-----------------------------------------------------------------------------
int ICCodeGenerator::isAllowedCppInline( )
   {
    return 0;
   }

//-----------------------------------------------------------------------------
std::string ICCodeGenerator::getHeaderSuffix()
   {
    return std::string(".h");
   }

//-----------------------------------------------------------------------------
std::string ICCodeGenerator::getLangName()
   {
    return std::string("c");
   }

//-----------------------------------------------------------------------------
std::string ICCodeGenerator::getSourceSuffix()
   {
    return std::string(".c");
   }

//-----------------------------------------------------------------------------
int ICCodeGenerator::generatePushStateCode( const CClassInfo &curClass
                         , const std::vector<std::string> &namespaces
                         , std::ostream &os
                         , bool bPlain
                         , bool bCallOverflows
                         , bool bLangPlainC
                         )
   {
    return ICBaseGenerator::generatePushStateCode( curClass, namespaces, os, true, bCallOverflows, bLangPlainC);
   }

//-----------------------------------------------------------------------------
int ICCodeGenerator::generatePopStateCode( const CClassInfo &curClass
                        , const std::vector<std::string> &namespaces
                        , std::ostream &os
                        , bool bPlain
                        , bool bCallOverflows
                        , bool bLangPlainC)
   {
    return ICBaseGenerator::generatePopStateCode( curClass, namespaces, os, true, bCallOverflows, bLangPlainC);
   }

//-----------------------------------------------------------------------------
int ICCodeGenerator::generateClearStateStackCode( const CClassInfo &curClass
                               , const std::vector<std::string> &namespaces
                               , std::ostream &os
                               , bool bPlain
                               , bool bCallOverflows)
   {
    return ICBaseGenerator::generateClearStateStackCode( curClass, namespaces, os, true, bCallOverflows);
   }

//-----------------------------------------------------------------------------
int ICCodeGenerator::addStackVars( CClassInfo &curClass
                                 , const std::vector<std::string> &namespaces
                                 , const std::string &stackSizeStr
                                 , bool bPlain
                                 , bool bCallOverflows
                                 , bool bInline
                                 , bool bLangPlainC
                                 )
   {
    return ICBaseGenerator::addStackVars( curClass, namespaces, stackSizeStr, true, bCallOverflows, bInline, true);
   }

//-----------------------------------------------------------------------------
int ICCodeGenerator::addStackIncludesDefines( const CClassInfo &curClass
                           , const std::vector<std::string> &namespaces
                           , std::vector<std::string> &includes
                           , std::vector<std::string> &defines
                           , bool bPlain
                           )
   {
    return ICBaseGenerator::addStackIncludesDefines( curClass, namespaces, includes, defines, true );
   }

//-----------------------------------------------------------------------------
int ICCodeGenerator::convertCode( const std::string &cppStyleCode
               , const CClassInfo &curClass
               , const std::vector<CClassInfo> &allClasses
               , const std::vector<std::string> &namespaces
               , const std::vector<std::string> &defines
               , std::string &toStr
               )
   {
    std::vector<CScannerEvent> scannerEvents;
    int res = parseForConvertCode( cppStyleCode, defines, scannerEvents );
    if (res)
       {
        return res;
       }

    CCpp2CConverter cpp2cConverter(&curClass, namespaces, this);
    cpp2cConverter.resetAutomata();

    std::vector<CScannerEvent>:: /* const_ */ iterator sceIt = scannerEvents.begin();
    for(; sceIt!=scannerEvents.end(); ++sceIt)
       {
        cpp2cConverter.putEvent(*sceIt);
       }
    cpp2cConverter.eod();

    cpp2cConverter.buf.swap(scannerEvents);
    sceIt = scannerEvents.begin();
    for(; sceIt!=scannerEvents.end(); ++sceIt)
       {
        if (sceIt->token==LT_KWD_THIS || (sceIt->token==LT_IDENT && sceIt->text==std::string("this")))
           {
            sceIt->text = "_pthis";
           }
       }

    //toStr = ser.buf;
    //std::cout<<"Org: ["<<cppStyleCode<<"], converted: ["<<serializeScannerEvents(scannerEvents)<<"]\n";
    toStr = serializeScannerEvents(scannerEvents);
    //toStr = cppStyleCode;
    
    return 0;
   }

//-----------------------------------------------------------------------------
int ICCodeGenerator::generateFunctionCall( std::ostream &os
                        , const std::vector<std::string> &namespaces
                        , const std::string &className
                        , const std::string &fnName
                        , const std::string &pthisName
                        , const std::vector<std::string> &args
                        )
   {
    os<<makeMethodName( namespaces, className, fnName, true)<<"( "<<pthisName; //<<", ";
    std::vector<std::string>::const_iterator argIt = args.begin();
    for(; argIt!=args.end(); ++argIt)
       {
        //if (argIt!=args.begin())
        os<<", ";
        //os<<*argIt;
        os<<escapeC(*argIt);
       }
    os<<" );";
    return 0;
   }

//-----------------------------------------------------------------------------
int ICCodeGenerator::generateConstantNames( std::map< std::string, CConstantName > &names, 
                                            const std::vector<std::string> &namespaces,
                                            const std::string &className,
                                            const std::string &prefix, 
                                            const std::string &postfix)
   {
    std::map< std::string, CConstantName >::iterator it = names.begin();
    for(; it!=names.end(); ++it)
       {
        it->second.attrName = prefix + it->first + postfix;
        it->second.intName  = it->second.extName = 
                              makeMethodName( "def", namespaces, className, it->second.attrName, true);
       }
    
    return 0;
   }

//-----------------------------------------------------------------------------
int ICCodeGenerator::generateClassDefinition( std::ostream &os
                           , const std::vector<std::string> &namespaces
                           , const CClassInfo &clInfo
                           , int genFlags
                           )
   {
    //if (clInfo.stereotype!="Automata") return 0;

    ::std::string stateEnumName;
    if (genFlags&FGF_STATIC_CONST_AS_ENUM)
       {
        stateEnumName = ::std::string("E") + clInfo.name + ::std::string("State");
       }

    size_t staticAttrCount = 0;
    std::vector<marty::uml::CClassAttributeInfo>::const_iterator  ait = clInfo.attributes.begin();
    for(; ait!=clInfo.attributes.end(); ++ait)
       {
        if (!ait->isStaticConstant()) continue;
        ++staticAttrCount;
       }

    size_t indexFirst = 0;
    size_t indexLast  = staticAttrCount - 1;
    size_t indexCurrent = 0;

    if (genFlags&FGF_STATIC_CONST_AS_ENUM && staticAttrCount)
       {
        os<<"enum "<<stateEnumName<<"{\n";
       }

    //std::vector<marty::uml::CClassAttributeInfo>::const_iterator  
    ait = clInfo.attributes.begin();
    for(; ait!=clInfo.attributes.end(); ++ait)
       {
        if (!ait->isStaticConstant()) continue;
        generateAttributeDefinition( os, std::string(""), *ait, namespaces, clInfo.name
                                   , true, true, ((genFlags&FGF_STATIC_CONST_AS_ENUM) ? true : false)
                                   , indexCurrent==indexFirst, indexCurrent==indexLast
                                   ); // static const
        ++indexCurrent;
       }

    if (genFlags&FGF_STATIC_CONST_AS_ENUM && staticAttrCount)
       {
        os<<"};";
       }

    if (staticAttrCount) os<<"\n\n";

    os<<"typedef struct tag_"<<clInfo.name<<" {\n\n";

    indexLast  = clInfo.attributes.size() - staticAttrCount - 1;
    indexCurrent = 0;

    //std::vector<marty::uml::CClassAttributeInfo>::const_iterator  
    ait = clInfo.attributes.begin();
    for(; ait!=clInfo.attributes.end(); ++ait)
       {
        if (ait->isStaticConstant()) continue;
        marty::uml::CClassAttributeInfo attrInfo = *ait;
        if (genFlags&FGF_STATIC_CONST_AS_ENUM && attrInfo.name=="curState")
           attrInfo.type = stateEnumName;
        generateAttributeDefinition( os, std::string("    "), attrInfo, namespaces, clInfo.name
                                   , true, false, ((genFlags&FGF_STATIC_CONST_AS_ENUM) ? true : false)
                                   , indexCurrent==indexFirst, indexCurrent==indexLast
                                   ); // all but no static const
        ++indexCurrent;
       }

    //os<<"\n\n";

    os<<"\n} "<<clInfo.name<<";\n\n\n";

    std::vector<marty::uml::CClassMethodInfo>::const_iterator  mit = clInfo.methods.begin();
    for(; mit!=clInfo.methods.end(); ++mit)
       {
        generateMethodDefinition( os, std::string("    "), clInfo.name, *mit, namespaces, true, true);
        os<<";\n\n";
       }


    return 0;
   }

//-----------------------------------------------------------------------------
int ICCodeGenerator::generateClassImplemetation( std::ostream &os
                           , const std::vector<std::string> &namespaces
                           , const CClassInfo &clInfo
                           , std::map<std::string, std::string> &methodsCode
                           )
   {
    std::vector<marty::uml::CClassMethodInfo>::const_iterator  mit = clInfo.methods.begin();
    for(; mit!=clInfo.methods.end(); ++mit)
       {
        if (mit->virtualMethod && mit->abstractMethod) continue;
        os<<"\n/*---------------------------------------------------------------------------*/\n";
        generateMethodDefinition( os, std::string(), clInfo.name, *mit, namespaces, true, false);
        os<<"\n   {";

        const CMethodCode *pcode = mit->getCodeForLang(getLangName(), true);
        if (!pcode)
           pcode = mit->getCodeForLang(getLangName(), false);
        if (pcode)
           {
            //std::string ind(8, ' ');
            //os<<"\n"<<ind<<"   {\n";

            std::string convertedCode;
            std::vector<CClassInfo> allClasses;
            std::vector<std::string> defines;
            defines.push_back("_pthis  this");
            convertCode( pcode->text, clInfo, allClasses, namespaces, defines, convertedCode );

            //os<<fsm::util::codeIndent(convertedCode, 12)<<"\n";
            os<<"\n"<<fsm::util::codeIndent(convertedCode, 4)<<"\n";
            //os<<ind<<"   }\n\n";
           }

        /*
        std::string code;
        bool codeFound = false;

        std::map<std::string, std::string>::iterator mcIt = methodsCode.find(mit->name);
        if (mcIt!=methodsCode.end())
           {
            code = mcIt->second;
            codeFound = true;
           }

        if (!codeFound)
           {
            const marty::uml::CClassOptions *pClassOptions = clInfo.getMethodCode( getLangName(), mit->name);
            if (pClassOptions)
               {
                code = pClassOptions->text;
                codeFound = true;
               }
           }

        if (codeFound)
           {
            os<<"\n"<<fsm::util::codeIndent(code, 4)<<"\n";
           }
        */
        // std::map<std::string, std::string>::iterator mcIt = methodsCode.find(mit->name);
        // if (mcIt!=methodsCode.end())
        //    {
        //     os<<"\n"<<fsm::util::codeIndent(mcIt->second, 4)<<"\n";
        //    }
        os<<"   }\n";
       }
    return 0;
   }

//-----------------------------------------------------------------------------

int ICCodeGenerator::generateClassImplTemplate( std::ostream &os
                           , const std::vector<std::string> &namespaces
                           , const CClassInfo &clInfo
                           , std::map<std::string, std::string> &methodsCode
                           )
   {
    return 0;
   }

//-----------------------------------------------------------------------------
int ICCodeGenerator::generateEventContextClassDefinition( std::ostream &os
                           , const std::vector<std::string> &namespaces
                           , const CClassInfo &clInfo
                           )
   {
    return 0;
   }

//-----------------------------------------------------------------------------
int ICCodeGenerator::generateHeaderProlog( std::ostream &os
                                         , const std::string &filename
                                         , const std::vector<std::string> &namespaces
                                         , const std::vector<std::string> &incFiles
                                         , const std::vector<std::string> &_defines
                                         )
   {
    //const std::vector<std::string> defines = _defines;
    //defines.push_back("EXTERN_C extern \"C\"");
    int res = ICBaseGenerator::generateHeaderProlog( os, filename, namespaces, incFiles, _defines );

    os<<"#if defined(__cplusplus)\n"
        "    #if !defined(EXTERN_C)\n"
        "        #define EXTERN_C extern \"C\"\n"
        "    #endif /* EXTERN_C */\n"
        "#else /* ! __cplusplus */\n"
        "    #if !defined(EXTERN_C)\n"
        "        #define EXTERN_C\n"
        "    #endif /* EXTERN_C */\n"
        "#endif /* __cplusplus */\n\n";

    return res;
   }

//-----------------------------------------------------------------------------

int ICCodeGenerator::generateHeaderEpilog( std::ostream &os
                                         , const std::string &filename
                                         , const std::vector<std::string> &namespaces
                                         )
   {
    int res = ICBaseGenerator::generateHeaderEpilog( os, filename, namespaces );
    return res;
   }

//-----------------------------------------------------------------------------

                     
                     
}; // namespace fsm
