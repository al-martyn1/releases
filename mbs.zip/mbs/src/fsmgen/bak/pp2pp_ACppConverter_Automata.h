#ifndef PP2PP_ACPPCONVERTER_AUTOMATA_H
#define PP2PP_ACPPCONVERTER_AUTOMATA_H

/* Warning! Automaticaly generated file, do not edit */
/* Visit www.purefractalsolutions.com for more details */
#include "../scanner/lextypes.h"
#include "../scanner/scanner.h"





namespace codegen {
namespace cpp {

class CCppConverter {

public:     static const int     ST_endConverting = 0x80000001; //!< ACppConverter:END_CONVERTING
public:     static const int     ST_waitCommaOrBracket                                        = 0x00000002; //!< ACppConverter:WAIT_COMMA_OR_BRACKET
public:     static const int     ST_waitCLikeThis = 0x00000003; //!< ACppConverter:WAIT_C_LIKE_THIS
public:     static const int     ST_waitIdent = 0x00000004; //!< ACppConverter:WAIT_IDENT
public:     static const int     ST_waitMemberAccessOp                                        = 0x00000005; //!< ACppConverter:WAIT_MEMBER_ACCESS_OP
public:     static const int     ST_waitOpenBracket = 0x00000006; //!< ACppConverter:WAIT_OPEN_BRACKET
public:     static const int     ST_waitPtrName = 0x00000007; //!< ACppConverter:WAIT_PTR_NAME
public:     static const int     ST_waitScopedName = 0x00000008; //!< ACppConverter:WAIT_SCOPED_NAME
public:     static const int     ST_intStatefinalmask = 0x80000000; //!< __int_stateFinalMask__


    public:     std::vector<CScannerEvent> buf         ;
    public:     std::vector<CScannerEvent> tempBuf     ;
    protected:  int                  curState    ; //!< Automaticaly added member for saving current automata state


    public:     
        int
        putEvent
                ( const CScannerEvent &evt         
                )
           {
            /* guard variable - evt.token */
            switch(this->curState)
               {
                case ST_waitCommaOrBracket:    /* ACppConverter:WAIT_COMMA_OR_BRACKET */
                        if (evt.token==LT_COMMA) /* Guard: [LT_COMMA] */
                           {
                               /* State WAIT_COMMA_OR_BRACKET - exit_action empty */
                               /* Transition from WAIT_COMMA_OR_BRACKET to WAIT_IDENT actions */
                               { appendBufThisAccOp(); flushTempBuf(); }
                               /* State WAIT_IDENT - entry_action empty */
                            this->curState = ST_waitIdent;
                           }
                        else if (evt.token==LT_BRACKET_END) /* Guard: [LT_BRACKET_END] */
                           {
                               /* State WAIT_COMMA_OR_BRACKET - exit_action empty */
                               /* Transition from WAIT_COMMA_OR_BRACKET to WAIT_IDENT actions */
                               { appendBufThisAccOp(); flushTempBufAndAppend(evt); }
                               /* State WAIT_IDENT - entry_action empty */
                            this->curState = ST_waitIdent;
                           }
                        else if ((eventIsSpace(evt))) /* Guard: [(eventIsSpace(evt))] */
                           {
                               /* State WAIT_COMMA_OR_BRACKET - exit_action empty */
                               /* Transition from WAIT_COMMA_OR_BRACKET to WAIT_COMMA_OR_BRACKET actions */
                               /* State WAIT_COMMA_OR_BRACKET - entry_action empty */
                            this->curState = ST_waitCommaOrBracket;
                           }
                        else
                           {
                               /* State WAIT_COMMA_OR_BRACKET - exit_action empty */
                               /* Transition from WAIT_COMMA_OR_BRACKET to WAIT_IDENT actions */
                               { flushTempBufAndAppend(evt); }
                               /* State WAIT_IDENT - entry_action empty */
                            this->curState = ST_waitIdent;
                           }
                     break;
                case ST_waitCLikeThis:    /* ACppConverter:WAIT_C_LIKE_THIS */
                        if ((eventIsThis(evt))) /* Guard: [(eventIsThis(evt))] */
                           {
                               /* State WAIT_C_LIKE_THIS - exit_action empty */
                               /* Transition from WAIT_C_LIKE_THIS to WAIT_COMMA_OR_BRACKET actions */
                               /* State WAIT_COMMA_OR_BRACKET - entry_action empty */
                            this->curState = ST_waitCommaOrBracket;
                           }
                        else if ((eventIsSpace(evt))) /* Guard: [(eventIsSpace(evt))] */
                           {
                               /* State WAIT_C_LIKE_THIS - exit_action empty */
                               /* Transition from WAIT_C_LIKE_THIS to WAIT_C_LIKE_THIS actions */
                               { appendTempBuf(evt); }
                               /* State WAIT_C_LIKE_THIS - entry_action empty */
                            this->curState = ST_waitCLikeThis;
                           }
                        else
                           {
                               /* State WAIT_C_LIKE_THIS - exit_action empty */
                               /* Transition from WAIT_C_LIKE_THIS to WAIT_IDENT actions */
                               { flushTempBufAndAppend(evt); }
                               /* State WAIT_IDENT - entry_action empty */
                            this->curState = ST_waitIdent;
                           }
                     break;
                case ST_waitIdent:    /* ACppConverter:WAIT_IDENT */
                        if (evt.token==LT_DOUBLE_COLON) /* Guard: [LT_DOUBLE_COLON] */
                           {
                               /* State WAIT_IDENT - exit_action empty */
                               /* Transition from WAIT_IDENT to WAIT_SCOPED_NAME actions */
                               { appendBuf(evt); }
                               /* State WAIT_SCOPED_NAME - entry_action empty */
                            this->curState = ST_waitScopedName;
                           }
                        else if ((eventIsThis(evt))) /* Guard: [(eventIsThis(evt))] */
                           {
                               /* State WAIT_IDENT - exit_action empty */
                               /* Transition from WAIT_IDENT to WAIT_MEMBER_ACCESS_OP actions */
                               { appendBuf(evt); }
                               /* State WAIT_MEMBER_ACCESS_OP - entry_action empty */
                            this->curState = ST_waitMemberAccessOp;
                           }
                        else if ((eventIsMemberMethod(evt))) /* Guard: [(eventIsMemberMethod(evt))] */
                           {
                               /* State WAIT_IDENT - exit_action empty */
                               /* Transition from WAIT_IDENT to WAIT_OPEN_BRACKET actions */
                               { appendTempBuf(evt); mangleNameToC(tempBuf[tempBuf.size()-1]); }
                               /* State WAIT_OPEN_BRACKET - entry_action empty */
                            this->curState = ST_waitOpenBracket;
                           }
                        else
                           {
                               /* State WAIT_IDENT - exit_action empty */
                               /* Transition from WAIT_IDENT to WAIT_IDENT actions */
                               { appendBuf(evt); }
                               /* State WAIT_IDENT - entry_action empty */
                            this->curState = ST_waitIdent;
                           }
                     break;
                case ST_waitMemberAccessOp:    /* ACppConverter:WAIT_MEMBER_ACCESS_OP */
                        if ((eventIsSpace(evt))) /* Guard: [(eventIsSpace(evt))] */
                           {
                               /* State WAIT_MEMBER_ACCESS_OP - exit_action empty */
                               /* Transition from WAIT_MEMBER_ACCESS_OP to WAIT_MEMBER_ACCESS_OP actions */
                               { appendBuf(evt); }
                               /* State WAIT_MEMBER_ACCESS_OP - entry_action empty */
                            this->curState = ST_waitMemberAccessOp;
                           }
                        else if ((evt.token==LT_PTR_ACC)) /* Guard: [(GUARDVAR==LT_PTR_ACC)] */
                           {
                               /* State WAIT_MEMBER_ACCESS_OP - exit_action empty */
                               /* Transition from WAIT_MEMBER_ACCESS_OP to WAIT_PTR_NAME actions */
                               { appendBuf(evt); }
                               /* State WAIT_PTR_NAME - entry_action empty */
                            this->curState = ST_waitPtrName;
                           }
                        else
                           {
                               /* State WAIT_MEMBER_ACCESS_OP - exit_action empty */
                               /* Transition from WAIT_MEMBER_ACCESS_OP to WAIT_IDENT actions */
                               { appendBuf(evt); }
                               /* State WAIT_IDENT - entry_action empty */
                            this->curState = ST_waitIdent;
                           }
                     break;
                case ST_waitOpenBracket:    /* ACppConverter:WAIT_OPEN_BRACKET */
                        if (evt.token==LT_BRACKET_START) /* Guard: [LT_BRACKET_START] */
                           {
                               /* State WAIT_OPEN_BRACKET - exit_action empty */
                               /* Transition from WAIT_OPEN_BRACKET to WAIT_C_LIKE_THIS actions */
                               { appendTempBuf(evt); }
                               /* State WAIT_C_LIKE_THIS - entry_action empty */
                            this->curState = ST_waitCLikeThis;
                           }
                        else if ((eventIsSpace(evt))) /* Guard: [(eventIsSpace(evt))] */
                           {
                               /* State WAIT_OPEN_BRACKET - exit_action empty */
                               /* Transition from WAIT_OPEN_BRACKET to WAIT_OPEN_BRACKET actions */
                               { appendTempBuf(evt); }
                               /* State WAIT_OPEN_BRACKET - entry_action empty */
                            this->curState = ST_waitOpenBracket;
                           }
                        else
                           {
                               /* State WAIT_OPEN_BRACKET - exit_action empty */
                               /* Transition from WAIT_OPEN_BRACKET to WAIT_IDENT actions */
                               { flushTempBufAndAppend(evt); }
                               /* State WAIT_IDENT - entry_action empty */
                            this->curState = ST_waitIdent;
                           }
                     break;
                case ST_waitPtrName:    /* ACppConverter:WAIT_PTR_NAME */
                        if ((eventIsSpace(evt))) /* Guard: [(eventIsSpace(evt))] */
                           {
                               /* State WAIT_PTR_NAME - exit_action empty */
                               /* Transition from WAIT_PTR_NAME to WAIT_PTR_NAME actions */
                               { appendBuf(evt); }
                               /* State WAIT_PTR_NAME - entry_action empty */
                            this->curState = ST_waitPtrName;
                           }
                        else if ((eventIsMemberMethod(evt))) /* Guard: [(eventIsMemberMethod(evt))] */
                           {
                               /* State WAIT_PTR_NAME - exit_action empty */
                               /* Transition from WAIT_PTR_NAME to WAIT_IDENT actions */
                               { appendBuf(evt); mangleNameToC(buf[buf.size()-1]); }
                               /* State WAIT_IDENT - entry_action empty */
                            this->curState = ST_waitIdent;
                           }
                        else
                           {
                               /* State WAIT_PTR_NAME - exit_action empty */
                               /* Transition from WAIT_PTR_NAME to WAIT_IDENT actions */
                               { appendBuf(evt); }
                               /* State WAIT_IDENT - entry_action empty */
                            this->curState = ST_waitIdent;
                           }
                     break;
                case ST_waitScopedName:    /* ACppConverter:WAIT_SCOPED_NAME */
                                       {
                               /* State WAIT_SCOPED_NAME - exit_action empty */
                               /* Transition from WAIT_SCOPED_NAME to WAIT_IDENT actions */
                               { appendBuf(evt); }
                               /* State WAIT_IDENT - entry_action empty */
                            this->curState = ST_waitIdent;
                           }
                     break;
               };
            return this->curState;
           }

    public:     
        int
        eod
           ( 
           )
           {
            /* there is no guard variable */
            switch(this->curState)
               {
                case ST_waitCommaOrBracket:    /* ACppConverter:WAIT_COMMA_OR_BRACKET */
                           {
                               /* State WAIT_COMMA_OR_BRACKET - exit_action empty */
                               /* Transition from WAIT_COMMA_OR_BRACKET to END_CONVERTING actions */
                               { flushTempBuf(); }
                               /* End state END_CONVERTING - entry_action empty */
                            this->curState = ST_endConverting;
                           }
                     break;
                case ST_waitCLikeThis:    /* ACppConverter:WAIT_C_LIKE_THIS */
                           {
                               /* State WAIT_C_LIKE_THIS - exit_action empty */
                               /* Transition from WAIT_C_LIKE_THIS to END_CONVERTING actions */
                               { flushTempBuf(); }
                               /* End state END_CONVERTING - entry_action empty */
                            this->curState = ST_endConverting;
                           }
                     break;
                case ST_waitIdent:    /* ACppConverter:WAIT_IDENT */
                           {
                               /* State WAIT_IDENT - exit_action empty */
                               /* Transition from WAIT_IDENT to END_CONVERTING actions */
                               /* End state END_CONVERTING - entry_action empty */
                            this->curState = ST_endConverting;
                           }
                     break;
                case ST_waitMemberAccessOp:    /* ACppConverter:WAIT_MEMBER_ACCESS_OP */
                           {
                               /* State WAIT_MEMBER_ACCESS_OP - exit_action empty */
                               /* Transition from WAIT_MEMBER_ACCESS_OP to END_CONVERTING actions */
                               /* End state END_CONVERTING - entry_action empty */
                            this->curState = ST_endConverting;
                           }
                     break;
                case ST_waitOpenBracket:    /* ACppConverter:WAIT_OPEN_BRACKET */
                           {
                               /* State WAIT_OPEN_BRACKET - exit_action empty */
                               /* Transition from WAIT_OPEN_BRACKET to END_CONVERTING actions */
                               { flushTempBuf(); }
                               /* End state END_CONVERTING - entry_action empty */
                            this->curState = ST_endConverting;
                           }
                     break;
                case ST_waitPtrName:    /* ACppConverter:WAIT_PTR_NAME */
                           {
                               /* State WAIT_PTR_NAME - exit_action empty */
                               /* Transition from WAIT_PTR_NAME to END_CONVERTING actions */
                               /* End state END_CONVERTING - entry_action empty */
                            this->curState = ST_endConverting;
                           }
                     break;
                case ST_waitScopedName:    /* ACppConverter:WAIT_SCOPED_NAME */
                           {
                               /* State WAIT_SCOPED_NAME - exit_action empty */
                               /* Transition from WAIT_SCOPED_NAME to END_CONVERTING actions */
                               /* End state END_CONVERTING - entry_action empty */
                            this->curState = ST_endConverting;
                           }
                     break;
               };
            return this->curState;
           }

    protected:  
        void
        appendBuf
                 ( const CScannerEvent  evt         
                 )
           {
            buf.push_back(evt);
           }

    protected:  
        void
        appendTempBuf
                     ( const CScannerEvent  evt         
                     )
           {
            tempBuf.push_back(evt);
           }

    protected:  
        void
        flushTempBuf
                    ( 
                    )
           {
            buf.insert(buf.end(), tempBuf.begin(), tempBuf.end());
            tempBuf.erase(tempBuf.begin(), tempBuf.end());
           }

    protected:  
        void
        flushTempBufAndAppend
                             ( const CScannerEvent  evt         
                             )
           {
            flushTempBuf();
            appendBuf(evt);
           }

    protected:  
        virtual
        int
        eventIsMemberMethod
                           ( const CScannerEvent &evt         
                           ) = 0;

    protected:  
        int
        eventIsSpace
                    ( const CScannerEvent  evt         
                    )
           {
            return LT_IS_WHITESPACE(evt.token);
           }

    protected:  
        int
        eventIsThis
                   ( const CScannerEvent &evt         
                   )
           {
            if ( evt.token==LT_KWD_THIS ||
                 (evt.token==LT_IDENT && evt.text==std::string("this"))
               ) return 1;
            return 0;
           }

    protected:  
        void
        appendTokenBuf
                      ( int                tt          
                      , const std::string &text        
                      )
           {
            buf.push_back(CScannerEvent(tt, text));
           }

    protected:  
        void
        appendBufThis
                     ( 
                     )
           {
            appendTokenBuf(LT_KWD_THIS, "this");
           }

    protected:  
        void
        appendBufThisAccOp
                          ( 
                          )
           {
            appendTokenBuf(LT_KWD_THIS, "this");
            appendTokenBuf(LT_PTR_ACC, "->");
           }

    protected:  
        virtual
        void
        mangleNameToC
                     ( CScannerEvent &evt         
                     ) = 0;

    protected:  
        void
        appendBufThisComma
                          ( 
                          )
           {
            appendTokenBuf(LT_KWD_THIS, "this");
            appendTokenBuf(LT_COMMA, ",");
           }

    protected:  
        void
        appendBufThisBrEnd
                          ( 
                          )
           {
            appendTokenBuf(LT_KWD_THIS, "this");
            appendTokenBuf(LT_BRACKET_END, ")");
           }

    protected:  
        void
        flushTempBufAppendToken
                               ( int                tt          
                               , const std::string &text        
                               )
           {
            flushTempBuf();
            appendTokenBuf(tt, text);
           }

    protected:  
        virtual
        int
        eventIsMemberAttr
                         ( const CScannerEvent &evt         
                         ) = 0;

    public:     
        int
        getCurState
                   ( 
                   ) const
           {
            return this->curState;
           }

    public:     
        int
        isInFinalState
                      ( 
                      ) const
           {
            return (this->curState & ST_intStatefinalmask) ? 1 : 0;
           }

    protected:  
        virtual
        void
        customResetAutomata
                           ( 
                           )
           {
            return;
           }

    public:     
        void
        resetAutomata
                     ( 
                     )
           {
            this->customResetAutomata(  );
            this->curState = ST_waitIdent;
           }

    public:     
        int
        isInInadmissibleFinalState
                                  ( 
                                  )
           {
            return 0;
           }


};


}; // namespace cpp {
}; // namespace codegen {

#endif /* PP2PP_ACPPCONVERTER_AUTOMATA_H */
