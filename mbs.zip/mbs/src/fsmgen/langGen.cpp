#include "langGen.h"
#include "lgC.h"
#include "lgCpp.h"
#include "lgPhp.h"

namespace fsm
{

ISourceGenerator* createGenerator(const std::string &lang, const std::string &namesStyle)
   {
    if (lang=="c")
       return new ICCodeGenerator(namesStyle);
    else if (lang=="cpp" || lang=="c++" || lang=="cxx")
       return new ICppCodeGenerator(namesStyle);
    else if (lang=="php")
       return new IPhpCodeGenerator(namesStyle);

    return 0;
   }

}; // namespace fsm

// #include <boost/algorithm/string/trim.hpp>
// #include <boost/algorithm/string/predicate.hpp>
// #include <boost/algorithm/string/case_conv.hpp>
