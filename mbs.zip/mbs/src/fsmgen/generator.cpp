#include <cli/cli2.h>

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#if !defined(_FSTREAM_) && !defined(_STLP_FSTREAM) && !defined(__STD_FSTREAM__) && !defined(_CPP_FSTREAM) && !defined(_GLIBCXX_FSTREAM)
    #include <fstream>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#if !defined(_SSTREAM_) && !defined(_STLP_SSTREAM) && !defined(__STD_SSTREAM__) && !defined(_CPP_SSTREAM) && !defined(_GLIBCXX_SSTREAM)
    #include <sstream>
#endif

#include <boost/algorithm/string/trim.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <boost/algorithm/string/split.hpp>



#include <marty/filename.h>


#include "generator.h"
#include "langGen.h"
#include "namenot.h"
#include "util.h"

#include "../dia/diaConv.h"


using ::boost::algorithm::trim_copy;
using ::boost::algorithm::trim;

using MARTY_FILENAME_NS     getExtention;

const std::string pthisStr      = "_pthis";
const std::string logMethodName = "logEvent";
const std::string strQuot       = "\"";


//-----------------------------------------------------------------------------
std::string generateLogEventCall( fsm::ISourceGenerator *pGen
                                , const fsm::CStateMachineInfo &stateMachine
                                , int genFlags
                                , const std::string &automataClassName
                                , const std::vector<std::string> &namespaces
                                , const std::map< std::string, fsm::CConstantName > &stateNames
                                , const fsm::CTransitionInfo &transition
                                , const std::string &codeStr
                                , const std::string &msgStr
                                )
   {
    return pGen->generateLogEventCall( pGen, stateMachine, genFlags, automataClassName, logMethodName, pthisStr
                                     , namespaces, stateNames, transition, codeStr, msgStr 
                                     );

/*
    std::vector<std::string> callParams;
    callParams.push_back(codeStr);


    std::map< std::string, fsm::CConstantName >::const_iterator stIt = stateNames.find(transition.startState);
    if (stIt!=stateNames.end())
       {
        callParams.push_back(stIt->second.intName);
       }
    else
       {
        callParams.push_back("0");
       }

    stIt = stateNames.find(transition.endState);
    if (stIt!=stateNames.end())
       {
        callParams.push_back(stIt->second.intName);
       }
    else
       {
        callParams.push_back("0");
       }

    //callParams.push_back(strQuot + msgStr + strQuot);
    //callParams.push_back(escapeC(msgStr));
    callParams.push_back(msgStr);
    //tmpSs<< pGen->generateGuardVarSerializeCode( pGen->modifyGuardVarName(guardObject), pGen->modifyGuardVarName("tmpss") );

    std::ostringstream ss;
    pGen->generateFunctionCall( ss, namespaces, automataClassName
                              , logMethodName
                              , pthisStr, callParams
                              );
    return ss.str();   
*/
   }

//-----------------------------------------------------------------------------
//parseGuardCondition("'0'-'9',',',TOKEN_TEST, TOKEN_START-TOKEN_END", cond);
int parseGuardCondition(const std::string &str, std::vector<CGuardConditionPair> &cond)
   {
    const int ST_START                     = 1;
    const int ST_READ_QUOTED               = 2;
    const int ST_READ_QUOTED_WAIT_ESCAPED  = 3;
    const int ST_READ_UNQUOTED             = 4;

    int state = ST_START;
    bool flagMax = false;

    CGuardConditionPair curPair;
    unsigned inBrackets = 0;

    std::string buf;
    std::string::size_type pos = 0, size = str.size();
    for(; pos!=size; ++pos)
       {
        char ch = str[pos];
        switch(state)
            {
             case ST_START    :
                  if (ch==' ')
                     {
                      if (inBrackets)
                         buf.append(1, ch);
                      continue;
                     }                     
                  else if (ch=='(')
                     {
                      if (flagMax)
                         {
                          std::cout<<"Error: invalid range in guard condition ["<<str<<"]\n";
                          return 28;
                         }
                      inBrackets++;
                      buf.append(1, ch);
                      continue;
                     }
                  else if (ch==')' && inBrackets)
                     {
                      inBrackets--;
                      buf.append(1, ch);
                      continue;
                     }

                  if (inBrackets)
                     {
                      buf.append(1, ch);
                      continue;
                     }

                  //else 
                  if (ch=='-')
                     {
                      if (flagMax)
                         {
                          std::cout<<"Error: invalid range in guard condition ["<<str<<"]\n";
                          return 28;
                         }

                      if (!buf.empty())
                         { // ��������� buf � curPair
                          if (!flagMax)
                             curPair.minVal = buf;
                          else
                             curPair.maxVal = buf;
                          buf.clear();
                         }

                      flagMax = true;
                     }
                  else if (ch==',')
                     {
                      if (!buf.empty())
                         { // ��������� buf � curPair
                          if (!flagMax)
                             curPair.minVal = buf;
                          else
                             curPair.maxVal = buf;
                          buf.clear();
                         }

                      if (!curPair.minVal.empty() || !curPair.maxVal.empty())
                         cond.push_back(curPair);

                      curPair.minVal.clear();
                      curPair.maxVal.clear();
                      flagMax = false;
                     }
                  else if (ch=='\'')
                     {
                      buf.append(1, ch);
                      state = ST_READ_QUOTED;
                     }
                  else
                     {
                      buf.append(1, ch);
                      state = ST_READ_UNQUOTED;
                     }
                  break;

             case ST_READ_QUOTED    :
                  if (ch=='\\')
                     {
                      buf.append(1, ch);
                      state = ST_READ_QUOTED_WAIT_ESCAPED;
                     }
                  else if (ch=='\'')
                     {
                      buf.append(1, ch);
                      state = ST_START;
                     }
                  else
                     {
                      buf.append(1, ch);
                     }
                  break;

             case ST_READ_QUOTED_WAIT_ESCAPED    :
                  buf.append(1, ch);
                  state = ST_READ_QUOTED;
                  break;

             case ST_READ_UNQUOTED:
                  if (ch==' ')
                     {
                      continue;
                     }
                  else if (ch=='-')
                     {
                      if (flagMax)
                         {
                          std::cout<<"Error: invalid range in guard condition ["<<str<<"]\n";
                          return 28;
                         }

                      if (!buf.empty())
                         { // ��������� buf � curPair
                          if (!flagMax)
                             curPair.minVal = buf;
                          else
                             curPair.maxVal = buf;
                          buf.clear();
                         }

                      flagMax = true;
                      state = ST_START;
                     }
                  else if (ch==',')
                     {
                      if (!buf.empty())
                         { // ��������� buf � curPair
                          if (!flagMax)
                             curPair.minVal = buf;
                          else
                             curPair.maxVal = buf;
                          buf.clear();
                         }

                      if (!curPair.minVal.empty() || !curPair.maxVal.empty())
                         cond.push_back(curPair);

                      curPair.minVal.clear();
                      curPair.maxVal.clear();
                      flagMax = false;
                      state = ST_START;
                     }
                  else
                     {
                      buf.append(1, ch);
                     }
                  break;
            }
       }

    if (!buf.empty())
       { // ��������� buf � curPair
        if (buf[0]=='\'' && buf[buf.size()-1]!='\'')
           {
            std::cout<<"Error: invalid range in guard condition '"<<str<<"' - missing closing apos at end of condition\n";
           }
        if (!flagMax)
           curPair.minVal = buf;
        else
           curPair.maxVal = buf;
       }
    if (!curPair.minVal.empty() || !curPair.maxVal.empty())
       cond.push_back(curPair);

    return 0;
   }
//-----------------------------------------------------------------------------
int generateAssignNextState( std::ostream &os
                           , const fsm::CStateMachineInfo &stateMachine
                           , fsm::ISourceGenerator *pGen
                           , int genFlags
                           , const marty::uml::CClassInfo &automataClass
                           , const std::vector<std::string> &namespaces
                           , const std::map< std::string, fsm::CConstantName > &stateNames
                           , const fsm::CTransitionInfo &transition
                           , const std::string &stateVar
                           , const std::string &eventHandlerName
                           , const std::vector<std::string> &eventHandlerArgList
                           , const std::string &indent
                           )
   {
    if (transition.inner && transition.startState!=transition.endState)
       {
        std::cout<<"Error: inner transition has different start and end states (start state '"
                 <<stateMachine.getStateName(transition.startState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"', end state '"
                 <<stateMachine.getStateName(transition.endState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"')\n";
            return 24;
       }

    if (transition.endState.empty())
       {
        std::cout<<"Error: transition from state '"
                 <<stateMachine.getStateName(transition.startState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"' - end state undefined\n";
        return 25;
       }

    std::map< std::string, fsm::CConstantName >::const_iterator stnIt = stateNames.find(transition.endState);
    const fsm::CStateInfo *pState = stateMachine.getStateInfo(transition.endState);
    if (!pState || stnIt==stateNames.end())
       {
        std::cout<<"Error: transition from state '"
                 <<stateMachine.getStateName(transition.startState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"' - end state '"
                 <<stateMachine.getStateName(transition.endState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"' not found in state machine definition\n";
        return 26;
       }
    
    if (pState->callRef.empty())
       {
        if (pState->isFinal && pState->bReturn)
           {
            os<<indent<<"/* Final state, returning */\n";
            os<<indent /* <<pthisStr<<"->" */ <<"returnFromState();\n";
            if (pState->recurRet)
               {
                os<<indent<<"/* Recursive send event to previos state */\n";
                os<<indent;
                pGen->generateFunctionCall( os, namespaces, automataClass.name, eventHandlerName, pthisStr, eventHandlerArgList);
                os<<"\n";
               }
           }
        else
           {
            if (!pState->orgName.empty())
               {
                stnIt = stateNames.find(pState->orgName);
                if (stnIt==stateNames.end())
                   {
                    std::cout<<"Error: transition from state '"
                             <<stateMachine.getStateName(transition.startState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"' - end state '"
                             <<stateMachine.getStateName(transition.endState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"' (actial is '"<<pState->orgName<<"') not found in state machine definition\n";
                    return 26;
                   }
               }
            os<<indent /* <<pthisStr<<"->" */ <<stateVar<<" = "<< stnIt->second.intName<<";\n";
           }
       }
    else // !pState->callRef.empty()
       {
        std::map<std::string, std::string>::const_iterator callIt = stateMachine.callables.find(pState->callRef);
        if (callIt==stateMachine.callables.end())
           {
            std::cout<<"Error: called automata '"<<pState->callRef<<"' start state not found\n";
            return 26;
           }
        
        stnIt = stateNames.find(callIt->second);
        if (stnIt==stateNames.end())
           {
            std::cout<<"Error: calling automata '"<<pState->callRef<<"' - start state '"<<callIt->second<<"' not found in state machine definition\n";
            return 26;
           }

        os<<indent /* <<pthisStr<<"->" */ << (pState->bSpawn ? "spawnState" : "callState")<<"("<< stnIt->second.intName<<");\n";
        if (pState->recurCall)
           {
            os<<indent<<"/* Recursive send event to called state */\n";
            os<<indent;
            pGen->generateFunctionCall( os, namespaces, automataClass.name, eventHandlerName, pthisStr, eventHandlerArgList);
            os<<"\n";
           }
       }
    // if (stnIt==stateNames.end())
    //    {
    //     std::cout<<"Error: transition from state '"<<transition.startState<<"' - end state '"<<transition.endState<<"' not found in state machine definition\n";
    //     return 26;
    //    }


    return 0;
   }

//-----------------------------------------------------------------------------
int generateExecActions( std::ostream &os
                       , const fsm::CStateMachineInfo &stateMachine
                       , fsm::ISourceGenerator *pGen
                       , const marty::uml::CClassInfo &automataClass
                       , const std::vector<std::string> &namespaces
                       , const std::map< std::string, fsm::CConstantName > &stateNames
                       , const std::vector<std::string> &_defines
                       , int genFlags
                       , const fsm::CTransitionInfo &transition
                       , const std::string &eventHandlerName
                       , const std::vector<std::string> &eventHandlerArgList
                       , const std::string &indent
                       )
   {
    std::vector<marty::uml::CClassInfo> allClasses;
    std::vector<std::string> defines = _defines;
    defines.push_back("_pthis  this");
    //defines.push_back("this    _pthis");
    //std::vector<std::string> defines;

    const fsm::CStateInfo* pState = stateMachine.getStateInfo(transition.startState);
    if (!pState)
       {
        std::cout<<"Error: transition from state '"<<stateMachine.getStateName(transition.startState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"' - state not found\n";
        return 27;
       }

    if (genFlags&FGF_TRANSITION_COVERAGE && pGen->isAllowedCppTransitionCoverage() && !transition.ignoreAllActions)
       {
        os<<indent<<"transitionsCoverage[CTransitionInfoKey(\""
                  <<transition.startState
                   <<"\", \""
                  <<stateMachine.getStateName(transition.startState, true)
                  <<"\", \""
                  <<transition.endState
                   <<"\", \""
                  <<stateMachine.getStateName(transition.endState, true)
                  <<"\", \""<<transition.trigger<<"\", \""<<transition.guard<<"\")]++;\n";
       }

    if (!transition.ignoreAllActions)
       {
        if (!transition.inner)
           {
            if (pState->exitAction.empty())
              os<<indent<<"   /* State "<<pState->getStateName(genFlags&FGF_LOG_ORG_STATE_NAMES)<<" - exit_action empty */\n";
            else
              {
               os<<indent<<"   /* State "<<pState->getStateName(genFlags&FGF_LOG_ORG_STATE_NAMES)<<" - exit_action */\n";
               if (genFlags&FGF_USE_LOGGING)
                  {
                   os<<indent + std::string(3, ' ')<<generateLogEventCall( pGen, stateMachine, genFlags, automataClass.name, namespaces, stateNames, transition, "0x0204", strQuot + pState->exitAction + strQuot)<<"\n";
                   //0x0201 - entry action, 0x0202 - trigger action, 0x0203 - do action, 0x0204 - exit action
                  }
    
               os<<indent<<"   { "<<correctActionCode(pGen, pState->exitAction, automataClass, allClasses, namespaces, defines)<<" }\n";
              }
           }
       }

    os<<indent<<"   /* Transition from "<<stateMachine.getStateName(transition.startState, genFlags&FGF_LOG_ORG_STATE_NAMES)
                                        <<" to "
                                        <<stateMachine.getStateName(transition.endState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<" actions */\n";
    std::vector<std::string>::const_iterator ait = transition.actions.begin();
    for(; ait!=transition.actions.end(); ++ait)
       {
        if (!transition.ignoreAllActions)
           {
            if (genFlags&FGF_USE_LOGGING)
               {
                os<<indent + std::string(3, ' ')<<generateLogEventCall( pGen, stateMachine, genFlags, automataClass.name, namespaces, stateNames, transition, "0x0202", strQuot + *ait + strQuot)<<"\n";
                //0x0201 - entry action, 0x0202 - trigger action, 0x0203 - do action, 0x0204 - exit action
               }
            os<<indent<<"   { "<<correctActionCode(pGen, *ait, automataClass, allClasses, namespaces, defines)<<" }\n";
           }
       }

    if (!transition.ignoreAllActions)
       {
        if (transition.inner)
           {
            if (transition.startState!=transition.endState)
               {
                std::cout<<"Error: inner transition from '"
                         <<stateMachine.getStateName(transition.startState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"' - end state must be the same, '"
                         <<stateMachine.getStateName(transition.endState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"' end state taken\n";
                return 28;
               }

            if (pState->doAction.empty())
              os<<indent<<"   /* State "<<pState->getStateName(genFlags&FGF_LOG_ORG_STATE_NAMES)<<" - do_action empty */\n";
            else
              {
               os<<indent<<"   /* State "<<pState->getStateName(genFlags&FGF_LOG_ORG_STATE_NAMES)<<" - do_action */\n";
               if (genFlags&FGF_USE_LOGGING)
                  {
                   os<<indent + std::string(3, ' ')<<generateLogEventCall( pGen, stateMachine, genFlags, automataClass.name, namespaces, stateNames, transition, "0x0203", strQuot + pState->doAction + strQuot)<<"\n";
                   //0x0201 - entry action, 0x0202 - trigger action, 0x0203 - do action, 0x0204 - exit action
                  }
               os<<indent<<"   { "<<correctActionCode(pGen, pState->doAction, automataClass, allClasses, namespaces, defines)<<" }\n";
              }
            return 0;
           }
       }

    pState = stateMachine.getStateInfo(transition.endState);    
    if (!pState)
       {
        std::cout<<"Error: transition to state '"<<stateMachine.getStateName(transition.endState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"' - state not found\n";
        return 28;
       }

    if (!transition.ignoreAllActions)
       {
        // 
        if (pState->entryAction.empty())
          os<<indent<<"   /* "<<(pState->isFinal?"End s":"S")<<"tate "<<pState->getStateName(genFlags&FGF_LOG_ORG_STATE_NAMES)<<" - entry_action empty */\n";
        else
          {
           os<<indent<<"   /* "<<(pState->isFinal?"End s":"S")<<"tate "<<pState->getStateName(genFlags&FGF_LOG_ORG_STATE_NAMES)<<" - entry_action */\n";
           if (genFlags&FGF_USE_LOGGING)
              {
               os<<indent + std::string(3, ' ')<<generateLogEventCall( pGen, stateMachine, genFlags, automataClass.name, namespaces, stateNames, transition, "0x0201", strQuot + pState->entryAction + strQuot)<<"\n";
               //0x0201 - entry action, 0x0202 - trigger action, 0x0203 - do action, 0x0204 - exit action
              }
           os<<indent<<"   { "<<correctActionCode(pGen, pState->entryAction, automataClass, allClasses, namespaces, defines)<<" }\n";
          }

        if (pState->callRef.empty())
           {
            if (!pState->orgName.empty())
               {
                std::string stOrgName = pState->orgName;
                pState = stateMachine.getStateInfo(stOrgName);
                if (!pState)
                   {
                    std::cout<<"Error: transition from state '"
                             <<stateMachine.getStateName(transition.startState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"' - end state '"
                             <<stateMachine.getStateName(transition.endState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"' (actial is '"
                             <<stOrgName<<"') not found in state machine definition\n";
                    return 26;
                   }
                else 
                   {
                    //if (pState->entryAction.emp)
                    if (pState->entryAction.empty())
                      os<<indent<<"   /* Jump to state "<<pState->getStateName(genFlags&FGF_LOG_ORG_STATE_NAMES)<<" - entry_action empty */\n";
                    else
                      {
                       os<<indent<<"   /* Jump to State "<<pState->getStateName(genFlags&FGF_LOG_ORG_STATE_NAMES)<<" - entry_action */\n";
                       if (genFlags&FGF_USE_LOGGING)
                          {
                           os<<indent + std::string(3, ' ')<<generateLogEventCall( pGen, stateMachine, genFlags, automataClass.name, namespaces, stateNames, transition, "0x0201", strQuot + pState->entryAction + strQuot)<<"\n";
                           //0x0201 - entry action, 0x0202 - trigger action, 0x0203 - do action, 0x0204 - exit action
                          }
                       os<<indent<<"   { "<<correctActionCode(pGen, pState->entryAction, automataClass, allClasses, namespaces, defines)<<" }\n";
                      }
                   }
               }
           }
        else
           {
            std::map<std::string, std::string>::const_iterator callIt = stateMachine.callables.find(pState->callRef);
            if (callIt==stateMachine.callables.end())
               {
                std::cout<<"Error: called automata '"<<pState->callRef<<"' start state not found\n";
                return 26;
               }

            pState = stateMachine.getStateInfo(callIt->second);    
            if (!pState)
               {
                std::cout<<"Error: calling automata '"<<callIt->first<<"' - start state '"<<callIt->second<<"' not found in state machine definition\n";
                return 26;
               }

            if (pState->callAction.empty())
              os<<indent<<"   /* Called state "<<pState->getStateName(genFlags&FGF_LOG_ORG_STATE_NAMES)<<" - call_entry_action empty */\n";
            else
              {
               os<<indent<<"   /* Called State "<<pState->getStateName(genFlags&FGF_LOG_ORG_STATE_NAMES)<<" - call_entry_action */\n";
               if (genFlags&FGF_USE_LOGGING)
                  {
                   os<<indent + std::string(3, ' ')<<generateLogEventCall( pGen, stateMachine, genFlags, automataClass.name, namespaces, stateNames, transition, "0x0205", strQuot + pState->callAction + strQuot)<<"\n";
                   //0x0201 - entry action, 0x0202 - trigger action, 0x0203 - do action, 0x0204 - exit action
                  }
               os<<indent<<"   { "<<correctActionCode(pGen, pState->callAction, automataClass, allClasses, namespaces, defines)<<" }\n";
              }

            if (pState->entryAction.empty())
              os<<indent<<"   /* Called state "<<pState->getStateName(genFlags&FGF_LOG_ORG_STATE_NAMES)<<" - entry_action empty */\n";
            else
              {
               os<<indent<<"   /* Called State "<<pState->getStateName(genFlags&FGF_LOG_ORG_STATE_NAMES)<<" - entry_action */\n";
               if (genFlags&FGF_USE_LOGGING)
                  {
                   os<<indent + std::string(3, ' ')<<generateLogEventCall( pGen, stateMachine, genFlags, automataClass.name, namespaces, stateNames, transition, "0x0201", strQuot + pState->entryAction + strQuot)<<"\n";
                   //0x0201 - entry action, 0x0202 - trigger action, 0x0203 - do action, 0x0204 - exit action
                  }
               os<<indent<<"   { "<<correctActionCode(pGen, pState->entryAction, automataClass, allClasses, namespaces, defines)<<" }\n";
              }

           
           }
       }
    return 0;
   }

//-----------------------------------------------------------------------------
int generateStateCode( std::ostream &os
                     , const fsm::CStateMachineInfo &stateMachine
                     , fsm::ISourceGenerator *pGen
                     , int genFlags
                     , const marty::uml::CClassInfo &automataClass
                     , const std::vector<std::string> &namespaces
                     , const std::map< std::string, fsm::CConstantName > &stateNames
                     , const std::vector<std::string> &defines
                     , const std::string &eventName
                     , const std::string &stateName
                     , const std::string &eventHandlerName
                     , const std::vector<std::string> &eventHandlerArgList
                     , const std::vector<fsm::transition_pos_type> &trPosList
                     , const std::string &guardVar
                     , const std::string &stateVar
                     , bool  isPodGuardArg
                     , const std::string &guardObject
                     , const std::string &indent
                     )
   {
    fsm::transition_pos_type lastCheckTransitionPos = stateMachine.transitions.size();
    int ifCount = 0;
    int unconditionalCount = 0;

    std::vector<fsm::transition_pos_type>::const_iterator trPosIt = trPosList.begin();
    for(; trPosIt!=trPosList.end(); ++trPosIt)
       {
        fsm::transition_pos_type trPos = *trPosIt;
        const fsm::CTransitionInfo &transition = stateMachine.transitions[trPos];

        std::string guardLoggingCall;
        if (genFlags&FGF_USE_GUARD_LOGGING && pGen->isAllowedCppTransitionCoverage() && !guardObject.empty())
           {
            std::stringstream tmpSs;
    
            if (isPodGuardArg)
               {
                tmpSs<<"{";
                //tmpSs<<"{ std::stringstream tmpss; tmpss<<\"Guard var value: \"<<"<<guardObject<<"<<\" (\"<<(unsigned)"<<guardObject<<"<<\")\"; ";
                tmpSs<< pGen->generateGuardVarSerializeCode( pGen->modifyGuardVarName(guardObject), pGen->modifyGuardVarName("tmpss") );
                tmpSs<<generateLogEventCall( pGen, stateMachine, genFlags, automataClass.name, namespaces, stateNames, transition, "1", pGen->getSerializedVarValueCode(pGen->modifyGuardVarName("tmpss"))  /* "tmpss.str().c_str()" */ )
                     <<" }";
               }
            else
               {
                tmpSs<<"{ "; // std::stringstream tmpss; tmpss<<\"Guard var value: \"; fsmObjSerialize(tmpss, "<<guardObject<<"); ";
                tmpSs<<generateLogEventCall( pGen, stateMachine, genFlags, automataClass.name, namespaces, stateNames, transition, "1", pGen->getSerializedVarValueCode(pGen->modifyGuardVarName("tmpss"))  /* "tmpss.str().c_str()" */  )
                     <<" }";
               }        
            guardLoggingCall = tmpSs.str();
           }


        if (transition.guard=="*")
           {
            if (lastCheckTransitionPos!=stateMachine.transitions.size())
               {
                std::cout<<"Error: found default transition (guard - '*') from state '"<<stateName<<"' on '"<<eventName<<"' event, but there is the same transition allready defined\n";
                //std::cout<<"Error: found 'all other cases guard' (*) transition from state '"<<stateName<<"', but there is the same transition allready defined\n";
                return 22;
               }
            lastCheckTransitionPos = trPos;
            continue;
           }

        if (transition.guard.empty())
           { // unconditional transition from this state on event
            ++unconditionalCount;
            //if (unconditionalCount)
            if (trPosList.size()>1)
               {
                std::cout<<"Error: found unconditional transition (empty guard value) from state '"<<stateName<<"' on '"<<eventName<<"' event, but there is more transitions from this state. Check automata definition\n";
                return 23;
               }

            os<<indent<<"   {\n";

            if (genFlags&FGF_USE_LOGGING)
               {
                std::ostringstream ss;
                if (genFlags&FGF_LOG_TRANSITION_SUMMARY_MULTILINE)
                   ss<<"Transition from "<<stateMachine.getStateName(transition.startState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"\\n             to "<<stateMachine.getStateName(transition.endState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"\\n             on "<<eventName<<"\\n            unconditional";
                else
                   ss<<"Transition from "<<stateMachine.getStateName(transition.startState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<" to "<<stateMachine.getStateName(transition.endState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<" on "<<eventName<<", unconditional";
                os<<indent + std::string(4, ' ')<<generateLogEventCall( pGen, stateMachine, genFlags, automataClass.name, namespaces, stateNames, transition, (transition.ignoreAllActions ? "0x10" : "0"), strQuot + ss.str() + strQuot)<<"\n";
                if (!guardLoggingCall.empty()) os<<indent + std::string(4, ' ')<<guardLoggingCall<<"\n";
                //os<<indent + std::string(4, ' ')<<generateLogEventCall( pGen, stateMachine, genFlags, automataClass.name, namespaces, stateNames, transition, "0x0101", ss.str() )<<"\n";
               }

            int 
            genRes = generateExecActions(os, stateMachine, pGen, automataClass, namespaces, stateNames, defines, genFlags, transition, eventHandlerName, eventHandlerArgList, indent + std::string(4, ' '));
            if (genRes) return genRes;

            genRes = generateAssignNextState( os, stateMachine, pGen, genFlags, automataClass, namespaces, stateNames, transition, stateVar, eventHandlerName, eventHandlerArgList, indent + std::string(4, ' '));
            if (genRes) return genRes;

            os<<indent<<"   }\n";
            continue;
           }

        std::string guardComment;
        std::string guard = transition.guard;
        //if (guard[0]!='(')
           {
            std::vector<CGuardConditionPair> cond;
            int pgcRes = parseGuardCondition(guard, cond);
            if (pgcRes) return pgcRes;

            std::string gv = pGen->modifyGuardVarName(guardVar);
            guard = std::string("(") + makeCondition(cond, gv, (genFlags&FGF_USE_TCHAR ? true : false), (genFlags&FGF_USE_WCHAR ? true : false) ) + std::string(")");
            if (guard=="(-)")
               guardComment = std::string("- invalid guard condition");
               //guardComment = std::string("Invalid guard condition: [") + transition.guard + std::string("]");
               //guard += std::string("/* Invalid guard condition: [") + transition.guard + std::string("] */");
           }
        /*
        else
           {
            // confition in guard is raw code
            if (guard[guard.size()-1]!=')')
               {
                std::cout<<"Error: raw guard condition '"<<guard<<"' - missing closing bracket (transition from '"<<transition.startState<<"' to '"<<transition.endState<<"' on '"<<eventName<<"'\n";
                return 23;
               }
           
           }
        */

        os<<indent;
        if (ifCount) os<<"else ";
        os<<"if "<<guard<<" ";
        if (guard!=transition.guard) os<<"/* "<<"Guard: ["<<transition.guard<<"] "<<guardComment<<"*/";
        os<<"\n";
        os<<indent<<"   {\n";

        if (genFlags&FGF_USE_LOGGING)
           {
            std::ostringstream ss;
            if (genFlags&FGF_LOG_TRANSITION_SUMMARY_MULTILINE)
               ss<<"Transition from "<<stateMachine.getStateName(transition.startState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"\\n             to "<<stateMachine.getStateName(transition.endState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"\\n             on "<<eventName<<"\\n             guard: "<<transition.guard;
            else
               ss<<"Transition from "<<stateMachine.getStateName(transition.startState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<" to "<<stateMachine.getStateName(transition.endState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<" on "<<eventName<<", guard: "<<transition.guard;
            os<<indent + std::string(4, ' ')<<generateLogEventCall( pGen, stateMachine, genFlags, automataClass.name, namespaces, stateNames, transition, (transition.ignoreAllActions ? "0x10" : "0"), strQuot + ss.str() + strQuot)<<"\n";
            if (!guardLoggingCall.empty()) os<<indent + std::string(4, ' ')<<guardLoggingCall<<"\n";
           }

        int 
        genRes = generateExecActions(os, stateMachine, pGen, automataClass, namespaces, stateNames, defines, genFlags, transition, eventHandlerName, eventHandlerArgList, indent + std::string(4, ' '));
        if (genRes) return genRes;

        genRes = generateAssignNextState( os, stateMachine, pGen, genFlags, automataClass, namespaces, stateNames, transition, stateVar, eventHandlerName, eventHandlerArgList, indent + std::string(4, ' '));
        if (genRes) return genRes;

        os<<indent<<"   }\n";

        ++ifCount;

        continue;

       }

    if (lastCheckTransitionPos!=stateMachine.transitions.size())
       {
        // ���� default (*) �������
        const fsm::CTransitionInfo &transition = stateMachine.transitions[lastCheckTransitionPos];

        std::string guardLoggingCall;
        if (genFlags&FGF_USE_GUARD_LOGGING && pGen->isAllowedCppTransitionCoverage() && !guardObject.empty())
           {
            std::stringstream tmpSs;

            if (isPodGuardArg)
               {
                tmpSs<<"{";
                //tmpSs<<"{ std::stringstream tmpss; tmpss<<\"Guard var value: \"<<"<<guardObject<<"<<\" (\"<<(unsigned)"<<guardObject<<"<<\")\"; ";
                tmpSs<< pGen->generateGuardVarSerializeCode( pGen->modifyGuardVarName(guardObject), pGen->modifyGuardVarName("tmpss") );
                tmpSs<<generateLogEventCall( pGen, stateMachine, genFlags, automataClass.name, namespaces, stateNames, transition, "1", pGen->getSerializedVarValueCode(pGen->modifyGuardVarName("tmpss"))  /* "tmpss.str().c_str()" */ )
                     <<" }";
               }
            else
               {
                tmpSs<<"{ "; // std::stringstream tmpss; tmpss<<\"Guard var value: \"; fsmObjSerialize(tmpss, "<<guardObject<<"); ";
                tmpSs<<generateLogEventCall( pGen, stateMachine, genFlags, automataClass.name, namespaces, stateNames, transition, "1", pGen->getSerializedVarValueCode(pGen->modifyGuardVarName("tmpss"))  /* "tmpss.str().c_str()" */  )
                     <<" }";
               }        

/*    
            if (isPodGuardArg)
               {
                tmpSs<<"{ std::stringstream tmpss; tmpss<<\"Guard var value: \"<<"<<guardObject<<"<<\" (\"<<(unsigned)"<<guardObject<<"<<\")\"; ";
                tmpSs<<generateLogEventCall( pGen, stateMachine, genFlags, automataClass.name, namespaces, stateNames, transition, "1", "tmpss.str().c_str()" )
                     <<" }";
               }
            else
               {
                tmpSs<<"{ std::stringstream tmpss; tmpss<<\"Guard var value: \"; fsmObjSerialize(tmpss, "<<guardObject<<"); ";
                tmpSs<<generateLogEventCall( pGen, stateMachine, genFlags, automataClass.name, namespaces, stateNames, transition, "1", "tmpss.str().c_str()" )
                     <<" }";           
               }        
*/
            guardLoggingCall = tmpSs.str();
           }

        os<<indent;
        if (ifCount) os<<"else\n";
        os<<indent<<"   {\n";

        if (genFlags&FGF_USE_LOGGING)
           {
            std::ostringstream ss;
            if (genFlags&FGF_LOG_TRANSITION_SUMMARY_MULTILINE)
               ss<<"Transition from "<<stateMachine.getStateName(transition.startState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"\\n             to "<<stateMachine.getStateName(transition.endState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<"\\n             on "<<eventName<<"\\n             default transition";
            else
               ss<<"Transition from "<<stateMachine.getStateName(transition.startState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<" to "<<stateMachine.getStateName(transition.endState, genFlags&FGF_LOG_ORG_STATE_NAMES)<<" on "<<eventName<<", default transition";
            os<<indent + std::string(4, ' ')<<generateLogEventCall( pGen, stateMachine, genFlags, automataClass.name, namespaces, stateNames, transition, (transition.ignoreAllActions ? "0x10" : "0"), strQuot + ss.str() + strQuot)<<"\n";
            if (!guardLoggingCall.empty()) os<<indent + std::string(4, ' ')<<guardLoggingCall<<"\n";
            //os<<indent + std::string(4, ' ')<<generateLogEventCall( pGen, automataClass.name, namespaces, stateNames, transition, "0x0101", ss.str() )<<"\n";
           }

        int 
        genRes = generateExecActions(os, stateMachine, pGen, automataClass, namespaces, stateNames, defines, genFlags, transition, eventHandlerName, eventHandlerArgList, indent + std::string(4, ' '));
        if (genRes) return genRes;

        genRes = generateAssignNextState( os, stateMachine, pGen, genFlags, automataClass, namespaces, stateNames, transition, stateVar, eventHandlerName, eventHandlerArgList, indent + std::string(4, ' '));
        if (genRes) return genRes;

        os<<indent<<"   }\n";
       }
    else
       {
        // ��� default ��������
        if (!unconditionalCount) // � ��� ������������ ��������
            std::cout<<"Warning: default transition (guard - '*') from state '"<<stateName<<"' not found\n";
       }
    return 0;
   }

//-----------------------------------------------------------------------------
int substAutomataIncludes( const CIncludeFinder<TCHAR> &includeFinder
                         , std::map<std::string, fsm::CStateMachineInfo> &stateMachines
                         , fsm::CStateMachineInfo &stateMachine
                         , std::map<std::string, std::set<std::string> > &inlinedAutomatas
                         )
   {
    std::vector<fsm::CStateInfo>::iterator stIt = stateMachine.states.begin();
    // ��� ���� ��������� ��������� ���������� �������
    for(; stIt!=stateMachine.states.end(); ++stIt)
       {
        /*
        std::cout<<"state: "<<stIt->name;
        if (stIt->complexRef.empty()) 
            std::cout<<", not complex";
        else
            std::cout<<", complex";
        */

        if (stIt->includeFile.empty()) 
           {
            //std::cout<<", no includes\n";
            continue;
           }
        //std::cout<<", loading include: "<<stIt->includeFile<<"\n";
        if (!fsm::loadFsm(includeFinder, stateMachines, stIt->includeFile, getExtention(stIt->includeFile)==".dia"))
           {
            std::cout<<"Error: failed to include file '"<<stIt->includeFile<<"'\n";
            return 14;
           }
        stIt->includeFile = tstring();
       }

    std::vector<fsm::CStateInfo>::size_type curStatePos = 0;
    for(; curStatePos!=stateMachine.states.size(); ++curStatePos)
       {
        if (stateMachine.states[curStatePos].complexRef.empty()) continue;

        std::map<std::string, fsm::CStateMachineInfo>::iterator smIt1 = stateMachines.find(stateMachine.states[curStatePos].complexRef);
        if (smIt1==stateMachines.end())
           {
            std::cout<<"Error: failed to inline automata '"
                     <<stateMachine.states[curStatePos].complexRef
                     <<"' into complex state '"<<stateMachine.states[curStatePos].name<<"'\n";
            return 15;
           }

        inlinedAutomatas[stateMachine.name].insert(stateMachine.states[curStatePos].complexRef);

        int substRes = substAutomataIncludes( includeFinder, stateMachines, smIt1->second, inlinedAutomatas );
        if (substRes) return substRes;

        // ��� ������� � ���������� ����������

        // substAutomataIncludes ����� �������������� stateMachines, ������� �������� smIt1 ��������������
        // smIt - �����������, ��� ��� ��� ���� ������� �����
        std::map<std::string, fsm::CStateMachineInfo>::const_iterator smIt = stateMachines.find(stateMachine.states[curStatePos].complexRef);
        if (smIt==stateMachines.end())
           { // �� ����, ��� �� ������ ������� �����������
            std::cout<<"Error: failed to inline automata '"
                     <<stateMachine.states[curStatePos].complexRef
                     <<"' into complex state '"<<stateMachine.states[curStatePos].name<<"'\n";
            return 16;
           }

        // smIt->second - ����������
        // stateMachine.states[curStatePos] - ��������� ���������
        // stateMachine.states[curStatePos] - ������� �������������� ��������� ���������

        fsm::CStateMachineInfo subMachine = smIt->second; // ���������� �����������, ��� ����������� � ��� ����� ��������

        // ��������������� ��� ��������� �����������, �������� ������� � ������ ����������� ���������� ���������
        std::string prefix = stateMachine.states[curStatePos].name + std::string(1, '_');
        #ifndef NO_STATE_NAMES_DEBUG_SEPARATOR
        prefix += std::string("0_");
        #endif

        subMachine.modifyStateNames(prefix, std::string()  /* postfix */ );

        // ��������� ����������� ��������
        {
         // ������� ��� �������� � ��������� ���������
         std::vector<fsm::transition_pos_type> trPosList;
         stateMachine.findTransitionsTo(stateMachine.states[curStatePos].name, trPosList);
         
         // ��� ������� ��������� �������� 

         // ��������� action ���������� ���������
         stateMachine.addActionToTransitions(trPosList, stateMachine.states[curStatePos].entryAction);
         // ��������� inline_entry_action �����������
         if (!subMachine.inlineEntryAction.empty())
            stateMachine.addActionToTransitions(trPosList, subMachine.inlineEntryAction);

         // ������������� ���������, � ������� ������������ �������, ������ ���������� ��������� �����������
         stateMachine.setTransitionsEndState(trPosList, subMachine.startState);
        }

        // ��������� �����������
        {
         // ���������� ��� �������� �� ���������� ���������
         std::vector<fsm::transition_pos_type> transitionsFromComplexPosList;
         stateMachine.findTransitionsFrom(stateMachine.states[curStatePos].name, transitionsFromComplexPosList);

         // �������� ����� - �������� ����� ������� � �����, ��� ���� ������� ���������� �� ����������
         std::vector<fsm::transition_pos_type>::const_reverse_iterator trFromComplexPosIt = transitionsFromComplexPosList.rbegin();
         for(; trFromComplexPosIt!=transitionsFromComplexPosList.rend(); ++trFromComplexPosIt)
            { //
             fsm::transition_pos_type trFromComplexPos  = *trFromComplexPosIt; // ������ ��� ��������� �������������
             // stateMachine.transitions[trFromComplexPos].trigger - ������ ���� ����������� 
             // ������ ����� ��������� ��������� ����������� (������ ���� ����� �������)

             ::std::vector< ::std::string > mainFsmTransitionTriggers;

             ::boost::algorithm::split( mainFsmTransitionTriggers
                                      , stateMachine.transitions[trFromComplexPos].trigger
                                      , fsm::util::CIsExactChar<','>()
                                      , boost::algorithm::token_compress_on);

             ::std::vector< ::std::string >::const_iterator ttIt = mainFsmTransitionTriggers.begin();
             for(; ttIt!=mainFsmTransitionTriggers.end(); ++ttIt)
                {
                 // � ����������� ���� ��������� � ������, ������ trigger'� ��������
                 std::vector<fsm::CStateInfo>::iterator subStIt 
                           = std::find_if( subMachine.states.begin()
                                         , subMachine.states.end()
                                         , fsm::CStateNameEqualTo(prefix + *ttIt) //, fsm::CStateNameEqualTo(prefix + stateMachine.transitions[trFromComplexPos].trigger)
                                         );
    
                 if (subStIt==subMachine.states.end())
                    {
                     std::cout<<"Error: transition from complex state '"<<stateMachine.states[curStatePos].name
                              <<"' with trigger '"<<*ttIt
                              <<"' - no such state found in included automata '"<<subMachine.name<<"'\n";
                     return 17;
                    }
                 
                 if (!subStIt->isFinal)
                    { // ���������, �������� �� ��� ��������, ���� ��� - ����
                     std::cout<<"Error: transition from complex state '"<<stateMachine.states[curStatePos].name
                              <<"' with trigger '"<<*ttIt
                              <<"' - no such end state found in included automata '"<<subMachine.name<<"', found state not final\n";
                     return 18;
                    }
    
                 // ������� � ����������� ��� �������� � ������ ���������
                 std::vector<fsm::transition_pos_type> transitionsToFinalPosList;
                 subMachine.findTransitionsTo(subStIt->name, transitionsToFinalPosList);
    
                 // ��� ������� �������� � �������� ��������� � �����������
                 std::vector<fsm::transition_pos_type>::const_iterator trToFinalPosIt = transitionsToFinalPosList.begin();
                 for(; trToFinalPosIt!=transitionsToFinalPosList.end(); ++trToFinalPosIt)
                    {
                     // ��������� � ��� actions 
                     // smIt->second.transitions[*trToFinalPosIt].actions.push_back();
                     //0) entry_action ��������� ��������� �����������
                     if (!subStIt->entryAction.empty())
                        {
                         subMachine.transitions[*trToFinalPosIt].actions.push_back(subStIt->entryAction);
                        }
    
                     // 1) exitAction ���������� ���������
                     if (!stateMachine.states[curStatePos].exitAction.empty())
                        subMachine.transitions[*trToFinalPosIt].actions.push_back(stateMachine.states[curStatePos].exitAction);
    
                     // 2) actions �������� �� ���������� ���������
                     //if (!stateMachine.transitions[trFromComplexPos].action.empty())
                     //   subMachine.transitions[*trToFinalPosIt].actions.push_back(stateMachine.transitions[trFromComplexPos].action);
                     subMachine.transitions[*trToFinalPosIt].actions.insert(
                                subMachine.transitions[*trToFinalPosIt].actions.end(),
                                stateMachine.transitions[trFromComplexPos].actions.begin(),
                                stateMachine.transitions[trFromComplexPos].actions.end()
                                                                           );
    
                     // ����� ������� �������� ������ �������� ���������, ������ ��������� ��������� �������� �� ���������� ���������
                     subMachine.transitions[*trToFinalPosIt].endState = stateMachine.transitions[trFromComplexPos].endState;

                    }

                 subMachine.states.erase(subStIt); // ������� ������ �������� ��������� �� �����������

                 // end of subloop
                }

             // ������ ����� ������� ������� �� ���������� ���������
             stateMachine.transitions.erase(stateMachine.transitions.begin()+trFromComplexPos);


            }
         // �� ���������� ����� ����� ��� �������� �� ���������� ��������� ���������� � ������� �� �������� ��������

         // ���� ���������, ���� � ����������� �������� �������� ���������, �� ��� �� �������� � ��� �������������
         std::vector<fsm::state_pos_type> tmpPosList;
         subMachine.findFinalStates(true, tmpPosList);
         if (!tmpPosList.empty())
            {
             std::cout<<"Error: unresolved final states ("<<unsigned(tmpPosList.size())<<") in included automata '"<<subMachine.name
                      <<"': ";
             std::vector<fsm::state_pos_type>::const_iterator tmpit = tmpPosList.begin();
             for(; tmpit!=tmpPosList.end(); ++tmpit)
                {
                 if (tmpit!=tmpPosList.begin()) std::cout<<", ";
                 std::cout<<subMachine.states[*tmpit].name;
                }
             std::cout<<"\n";
             return 19;
            }
        }

        // ������� ��������� ���������
        stateMachine.states.erase(stateMachine.states.begin() + curStatePos);

        // ������ ���� �������� ��� �������� � ��������� ����������� � �������
        stateMachine.states.insert(stateMachine.states.begin() + curStatePos, subMachine.states.begin(), subMachine.states.end());
        stateMachine.transitions.insert(stateMachine.transitions.end(), subMachine.transitions.begin(), subMachine.transitions.end());

        // �����
       }

    return 0;
   }

//-----------------------------------------------------------------------------
int generateAutomata( const CIncludeFinder<TCHAR> &includeFinder
                    , const std::map<std::string, fsm::CStateMachineInfo> &paramStateMachines
                    , int genFlags
                    , const std::string &generateForLang
                    , const std::vector<std::string> &namespaces
                    , const std::string &namesStyle
                    , const std::string &filePrefix
                    , const std::string &automataName
                    , const std::string &saveIntermediateAutomata
                    , const std::string &stackSizeStr
                    )
   {
    std::cout<<"-----\n"; //

    if (generateForLang.empty())
       {
        std::cout<<"Error: destination language not taken, use -L option\n";
        return 10;
       }

    if (automataName.empty())
       {
        std::cout<<"Error: can't generate code - automat name empty\n";
        return 11;
       }

    if (!genFlags)
       {
        std::cout<<"Error: can't generate code - nothing to generate, use -G option\n";
        return 12;
       }

    std::map<std::string, fsm::CStateMachineInfo> stateMachines = paramStateMachines;

    fsm::CStateMachineInfo stateMachine;
      {
        std::map<std::string, fsm::CStateMachineInfo>::const_iterator smIt = stateMachines.find(automataName);
        if (smIt==stateMachines.end())
           {
            std::cout<<"Error: automata '" << automataName << "' definition not found - load apropriate files with -i or -d options\n";
            return 13;       
           }
       stateMachine = smIt->second;
      }

    bool automataNeedStack = false;
    std::map<std::string, std::set<std::string> > inlinedAutomatas;
    std::map<std::string, std::set<std::string> > calledAutomatas;

    // lookup for additional include files
    int res = substAutomataIncludes( includeFinder, stateMachines, stateMachine, inlinedAutomatas);
    if (res) return res;

     { // add callable automatas
      //std::set<>
      std::vector<fsm::CStateInfo>::size_type spos = 0, ssize = stateMachine.states.size();
      for(; spos!=ssize; ++spos)
         {
          // const 
          std::string  /* & */ calledAutomataName = stateMachine.states[spos].callRef;
          if (calledAutomataName.empty()) continue;
          if (stateMachine.callables.find(calledAutomataName)!=stateMachine.callables.end())
             continue;

          automataNeedStack = true;
          
          std::map<std::string, fsm::CStateMachineInfo>::const_iterator 
              stmIt = stateMachines.find(calledAutomataName);
                      // std::find_if( stateMachines.begin()
                      //             , stateMachines.end()
                      //             , marty::uml::IsEqualByName<fsm::CStateMachineInfo>(calledAutomataName)
                      //             );
          if (stmIt==stateMachines.end())
             {
              std::cout<<"Error: called automata '" << calledAutomataName << "' definition not found - load apropriate files with -i or -d options\n";
              return 13;       
             }

          calledAutomatas[stateMachine.states[spos].orgStateMachine].insert(stateMachine.states[spos].callRef);

          fsm::CStateMachineInfo calledStateMachine = stmIt->second;
          int res = substAutomataIncludes( includeFinder, stateMachines, calledStateMachine, inlinedAutomatas);
          if (res) return res;

          std::string prefix = calledAutomataName + std::string("_"); // + + std::string("_");
          #ifndef NO_STATE_NAMES_DEBUG_SEPARATOR
          prefix += std::string("0_");
          #endif
          stateMachine.callables[calledAutomataName] = prefix + calledStateMachine.startState;

          //std::map<std::string, std::string> newStateNames;

          // ���������
          std::vector<fsm::CStateInfo>::const_iterator stIt = calledStateMachine.states.begin();
          for(; stIt!=calledStateMachine.states.end(); ++stIt)
             {
              fsm::CStateInfo st = *stIt;
              if (st.name==calledStateMachine.startState)
                 {
                  st.callAction = calledStateMachine.callEntryAction;
                 }

              std::string newName = prefix + st.name;
              if (st.isFinal && !st.bReturn)
                 {
                  st.orgName = st.name;
                 }
              st.name = newName;
              stateMachine.states.push_back(st);
             }

          // ��������
          std::vector<fsm::CTransitionInfo>::const_iterator trIt = calledStateMachine.transitions.begin();
          for(; trIt!=calledStateMachine.transitions.end(); ++trIt)
             {
              fsm::CTransitionInfo tr = *trIt;
              tr.startState = prefix + tr.startState;
              tr.endState   = prefix + tr.endState;
              stateMachine.transitions.push_back(tr);
             }

          //std::map<std::string, std::string> callables
         }
     }


    #ifdef SORT_STATE_MACHINE_BEFORE_SAVING
    std::sort( stateMachine.transitions.begin()
             , stateMachine.transitions.end()
             , fsm::transitionLessStrict()
             );

    std::sort( stateMachine.states.begin()
             , stateMachine.states.end()
             , marty::uml::LessByName<fsm::CStateInfo>()
             );
    #endif


    std::vector<marty::uml::CClassInfo> allClasses;

    std::map<std::string, fsm::CStateMachineInfo>::const_iterator stmIt = stateMachines.begin();
    for(; stmIt!=stateMachines.end(); ++stmIt)
       {
        std::copy(stmIt->second.classes.begin(), stmIt->second.classes.end(), std::back_inserter(allClasses) );
        //std::cout<<"Name: "<<stmIt->second.name<<", loaded from: "<<stmIt->second.loadedFromFile<<"\n";
       }
             
    std::vector<marty::uml::CClassInfo>::iterator alcIt = allClasses.begin();
    for(; alcIt!=allClasses.end(); ++alcIt)
       {
        alcIt->splitMethodsCodeByLangs();
       }

    // save inlined state machine definition
    std::string errText;
    bool fErr = false;
    try{
        fsm::CFsmConfig fsm;
        fsm.classes = allClasses;
        stateMachine.classes.erase(stateMachine.classes.begin(), stateMachine.classes.end());
        fsm.fsmList.push_back(stateMachine);
        fsm::save_fsmdef(saveIntermediateAutomata, fsm);
       }
    CATCH_6ML_ERRORS(fErr, errText)


    #ifndef SORT_STATE_MACHINE_BEFORE_SAVING
    std::sort( stateMachine.transitions.begin()
             , stateMachine.transitions.end()
             , fsm::transitionLessStrict()
             );

    std::sort( stateMachine.states.begin()
             , stateMachine.states.end()
             , marty::uml::LessByName<fsm::CStateInfo>()
             );
    #endif

    if (genFlags&FGF_MAKE_CALL_STAT)
       {
        std::cout<<"\n! Calling/inlining summary information for '"<<stateMachine.name<<"' automata\n";
        std::map<std::string, std::set<std::string> > inlinedAutomatasFrom;

        std::cout<<"\n> Inlined automatas";
        if (inlinedAutomatas.empty())
           std::cout<<" empty";
        std::cout<<"\n";

        std::map<std::string, std::set<std::string> >::const_iterator 
        iaIt = inlinedAutomatas.begin();
        for(; iaIt!=inlinedAutomatas.end(); ++iaIt)
           {
            std::cout<<iaIt->first<<" inlines automatas :\n";
            std::set<std::string>::const_iterator it = iaIt->second.begin();
            for(; it!=iaIt->second.end(); ++it)
               {
                std::cout<<"    "<<*it<<"\n";
                inlinedAutomatasFrom[*it].insert(iaIt->first);
               }
           }

        std::cout<<"\n> Inlined automatas (from)";
        if (inlinedAutomatasFrom.empty())
           std::cout<<" empty";
        std::cout<<"\n";

        iaIt = inlinedAutomatasFrom.begin();
        for(; iaIt!=inlinedAutomatasFrom.end(); ++iaIt)
           {
            std::cout<<iaIt->first<<" inlined from automatas :\n";
            std::set<std::string>::const_iterator it = iaIt->second.begin();
            for(; it!=iaIt->second.end(); ++it)
               {
                std::cout<<"    "<<*it<<"\n";
               }
           }


        std::map<std::string, std::set<std::string> > calledAutomatasFrom;

        std::cout<<"\n> Called automatas";
        if (calledAutomatas.empty())
           std::cout<<" empty";
        std::cout<<"\n";

        //std::map<std::string, std::set<std::string> >::const_iterator 
        iaIt = calledAutomatas.begin();
        for(; iaIt!=calledAutomatas.end(); ++iaIt)
           {
            std::cout<<iaIt->first<<" calling automatas :\n";
            std::set<std::string>::const_iterator it = iaIt->second.begin();
            for(; it!=iaIt->second.end(); ++it)
               {
                std::cout<<"    "<<*it<<"\n";
                calledAutomatasFrom[*it].insert(iaIt->first);
               }
           }

        std::cout<<"\n> Called automatas (from)";
        if (calledAutomatasFrom.empty())
           std::cout<<" empty";
        std::cout<<"\n";

        iaIt = calledAutomatasFrom.begin();
        for(; iaIt!=calledAutomatasFrom.end(); ++iaIt)
           {
            std::cout<<iaIt->first<<" called from automatas :\n";
            std::set<std::string>::const_iterator it = iaIt->second.begin();
            for(; it!=iaIt->second.end(); ++it)
               {
                std::cout<<"    "<<*it<<"\n";
               }
           }


       }

    if (genFlags&FGF_DONT_GENERATE_CODE)
       {
        std::cout<<"Exiting due -Gx option, no source code generated\n";
        return 0;
       }

    // �������� �� ������������� ����� ���������
    {
     int dupCount = 0;
     std::set<std::string> stateNames;
     std::vector<fsm::CStateInfo>::const_iterator it = stateMachine.states.begin();
     for(; it!=stateMachine.states.end(); ++it)
        {
         if (stateNames.find(it->name)!=stateNames.end())
            {
             std::cout<<"Error: state '"<<it->name<<"' multiple times\n";
             ++dupCount;
            }
         else
            {
             stateNames.insert(it->name);
            }
        }
     if (dupCount)
        return 23;
    }

    const std::string inadmissibleEndStateName = "__int_stateInadmissibleEnd__";
    bool needInadmissibleEndState = false;
    // �������� �� ������������� ��������
    {
     int dupCount = 0;
     std::set<std::string> eventsSet;

     typedef std::map<std::string, unsigned> string_to_unsigned_map;

     ::std::map< ::std::string, int> eventUsageCounts;

     std::map<std::string, string_to_unsigned_map > stateEventsCounts;
     std::set<fsm::CTransitionInfo, fsm::transitionLess> trSet;
     std::vector<fsm::CTransitionInfo>::const_iterator it = stateMachine.transitions.begin();
     for(; it!=stateMachine.transitions.end(); ++it)
        {
         stateEventsCounts[it->startState][it->trigger]++;
         std::set<fsm::CTransitionInfo, fsm::transitionLess>::const_iterator allreadyTrIt = trSet.find(*it);
         if (allreadyTrIt!=trSet.end())
            {
             ++dupCount;
             std::cout<<"Error: duplicated transition: from '"<<it->startState
                      <<"' to '"<<it->endState
                      <<"' with trigger '"<<it->trigger
                      <<"' and guard '"<<it->guard
                      <<"', "<<(unsigned)it->actions.size()<<" actions\n";
             std::cout<<"Error: allready defined  is:  from '"<<allreadyTrIt->startState
                      <<"' to '"<<allreadyTrIt->endState
                      <<"' with trigger '"<<allreadyTrIt->trigger
                      <<"' and guard '"<<allreadyTrIt->guard
                      <<"', "<<(unsigned)allreadyTrIt->actions.size()<<" actions\n";
            }
         else
            {
             trSet.insert(*it);
             eventsSet.insert(it->trigger);
             eventUsageCounts[it->trigger] ++;
            }         
        }

     if (dupCount)
        {
         std::cout<<"Checked "<<(unsigned)stateMachine.transitions.size()<<" transitions, found "<<(unsigned)trSet.size()<<" unique transitions\n";
         return 23;
        }
     else
        {
         std::cout<<"Checked "<<(unsigned)stateMachine.transitions.size()<<" transitions, duplicates not found, continue\n";
        }

     std::cout<<"Found  "<<(unsigned)eventsSet.size()<<" event types\n";
     if (!stateMachine.transitions.empty())
        {
         ::std::map< ::std::string, int>::const_iterator eucIt = eventUsageCounts.begin();
         for(; eucIt!=eventUsageCounts.end(); ++eucIt)
            {
             double percent = (double)eucIt->second * 100.0 / 
                              (double)(int)stateMachine.transitions.size();
             std::cout<<"    Event '"<<eucIt->first<<"' used on "<<percent<<"% transitions ("<<eucIt->second<<" times)";
             if (percent>1.0) { std::cout<<"\n"; continue; }
             std::cout<<", possible error. Check states: \n";
             //std::vector<fsm::CTransitionInfo>::const_iterator 
             it = stateMachine.transitions.begin();
             for(; it!=stateMachine.transitions.end(); ++it)
                {
                 if (it->trigger!=eucIt->first) continue;

                 
                 ::std::string startStateName = stateMachine.getStateName(it->startState, true);
                 ::std::string endStateName = stateMachine.getStateName(it->endState, true);

                 std::cout<<"        Transition: from "<<it->startState<<", to "<<it->endState<<"\n"; //<<", trigger"
                 if (startStateName!=it->startState || endStateName!=it->endState)
                    std::cout<<"                   (from "<<startStateName<<", to "<<endStateName<<")\n"; //<<", trigger"
                 //<<"', "<<(unsigned)it->actions.size()<<" actions\n";
                }
            }
        }

     std::vector<fsm::state_pos_type> nonFinalStatesPosList;
     fsm::state_pos_type nonFinalStatesCount = stateMachine.findFinalStates(false, nonFinalStatesPosList);

     unsigned totalEventsOnStates = 0;
     std::map<std::string, string_to_unsigned_map >::const_iterator stecIt = stateEventsCounts.begin();
     for(; stecIt!=stateEventsCounts.end(); ++stecIt)
        {
         totalEventsOnStates += (unsigned)stecIt->second.size();
        }

     std::cout<<"Found  "<<(unsigned)nonFinalStatesCount<<" non-final states and "<<(unsigned)totalEventsOnStates<<" unique events on that states\n";


     unsigned inadmissibleTransitionCount = 0;
     // ������������� ��������. �� ������� ��������� ������ ���� �������� �� ������� �������.
     // ���� � ��������� ��������� ��������� ������� �����������, ������������ ������� � 
     // ����������� �������� ���������, ��������������� � ������������ ������������ ��������
     if (nonFinalStatesCount*eventsSet.size()>totalEventsOnStates)
        {
         std::cout<<"Adding definitions for transitions on inadmissible events\n";

         // ���������� ���������
         //std::vector<fsm::CStateInfo>::const_iterator 
         std::vector<fsm::state_pos_type>::const_iterator  stPosIt = nonFinalStatesPosList.begin();
         for(; stPosIt!=nonFinalStatesPosList.end(); ++stPosIt)
            {
             fsm::state_pos_type stPos = *stPosIt;
             
             //std::cout<<"Checking state '"<<stateMachine.states[stPos].name<<"'\n";
             std::set<std::string>::const_iterator esit = eventsSet.begin();
             for(; esit!=eventsSet.end(); ++esit)
                {
                 //std::cout<<"   Lookup for '"<<*esit<<"' event\n";
                 if (!stateMachine.states[stPos].callRef.empty()) continue;
                 stecIt = stateEventsCounts.find(stateMachine.states[stPos].name);
                 // ���� ��������� �� ������� � ������ ��������� ��� �������� �������
                 // ��� � ��������� ��� �������� �� �������� ������� *esit,
                 if (stecIt==stateEventsCounts.end() || stecIt->second.find(*esit)==stecIt->second.end())
                    { 
                     // �� ���� �������� ������� �� ������� �������
                     //std::cout<<"   No transitions found from state on event, adding transition\n";

                     ++inadmissibleTransitionCount;

                     fsm::CTransitionInfo tr;
                     tr.startState        = stateMachine.states[stPos].name; //stecIt->first;
                     //tr.endState          = ;
                     tr.trigger           = *esit;
                     tr.guard             = "";

                     if (genFlags&FGF_INADMISSIBLE_EVENTS_IGNORED)
                        { // ����������� ������� �� �������������� ������� ������ ���������� ���� �������
                         tr.inner             = true;
                         tr.ignoreAllActions  = true;
                         tr.endState          = tr.startState;
                        }
                     else
                        { // ����������� ������� ������������ � �������� ���������, ��������������� 
                          // �� ������ ������������� ��������
                         tr.inner             = false;
                         tr.ignoreAllActions  = true;
                         tr.endState          = inadmissibleEndStateName;
                        }                    
                     stateMachine.transitions.push_back(tr);
                    }
                }
            }

         if (!(genFlags&FGF_INADMISSIBLE_EVENTS_IGNORED))
            {
             needInadmissibleEndState = true;
            }

         if (inadmissibleTransitionCount)
            {
             std::cout<<"Added "<<(unsigned)inadmissibleTransitionCount<<" transitions on inadmissible events (to disable this message, explicitly determine transitions on all events for all states)\n";
            }

        }

    }

    if (needInadmissibleEndState)
       {
        fsm::CStateInfo st;
        st.name         = inadmissibleEndStateName;
        st.entryAction  = std::string();
        st.doAction     = std::string();
        st.exitAction   = std::string();
        st.complexRef   = std::string();
        st.includeFile  = std::string();
        st.isFinal      = true;
        stateMachine.states.push_back(st);
       }

    //inadmissibleEndStateName

    if (genFlags&FGF_FORCE_ADD_STACK)
       {
        automataNeedStack = true;
       }

    // Generating code
    std::cout<<"Start generating automata '"<<automataName<<"' source for lang '"<<generateForLang<<"'\n";

    std::cout<<"Loaded state machine definitions: "<<(unsigned)stateMachines.size()<<"\n";
    //std::map<std::string, fsm::CStateMachineInfo>::const_iterator 
    stmIt = stateMachines.begin();
    for(; stmIt!=stateMachines.end(); ++stmIt)
       {
        //std::copy(stmIt->second.classes.begin(), stmIt->second.classes.end(), std::back_inserter(allClasses) );
        std::cout<<"Name: "<<stmIt->second.name<<", loaded from: "<<stmIt->second.loadedFromFile<<"\n";
       }

    // std::vector<marty::uml::CClassInfo>::iterator classIt = stateMachine.classes.begin();
    // for(; classIt!=stateMachine.classes.end(); ++classIt)
    //    {
    //     if (classIt->stereotype=="Automata") break;
    //    }
    std::vector<marty::uml::CClassInfo>::iterator classIt = allClasses.begin();
    for(; classIt!=allClasses.end(); ++classIt)
       {
        if (classIt->stereotype!="Automata") continue;
        if (classIt->name==stateMachine.automataClass) break;
       }

    if (classIt==allClasses.end())
       {
        std::cout<<"Error: not found automata class definition, add marker with class name to start state and use stereotype='Automata' for defining automata class\n";
        return 14;
       }
       
    marty::uml::CClassInfo automataClass = *classIt;

    std::auto_ptr<fsm::ISourceGenerator>  /* * */  pGen(fsm::createGenerator(generateForLang, namesStyle));
    if (!pGen.get())
       {
        std::cout<<"Error: can't generate code for lang '"<<generateForLang<<"' no code generator for this language\n";
        return 15;
       }

    std::auto_ptr <fsm::INameNotationMaker>  /* * */  pDefNameMaker(fsm::cretateNameNotationMaker("def"));
    if (!pDefNameMaker.get())
       {
        std::cout<<"Error: failed to create name formatter\n";
        return 15;
       }


    //std::vector<marty::uml::CClassInfo> allClasses;
    //std::map<std::string, fsm::CStateMachineInfo>::const_iterator stmIt = stateMachines.begin();


    //std::vector<marty::uml::CClassInfo>::iterator guardClassIt = stateMachine.classes.begin();


    //{ // add curState member to automata class

    const std::string curStateVarNameOnly = "curState";
    const std::string curStateVarName = generateMemberAccess(pGen.get(), curStateVarNameOnly, pthisStr);

     marty::uml::CClassAttributeInfo curStateClassAttr;
     curStateClassAttr.name = curStateVarNameOnly;
     curStateClassAttr.type = "int";
     curStateClassAttr.visibility = marty::uml::emvPro;
     curStateClassAttr.classScope = false;
     curStateClassAttr.value      = "";
     curStateClassAttr.comment    = "Automaticaly added member for saving current automata state" ;
     automataClass.attributes.push_back(curStateClassAttr);
    //}

    if (genFlags&FGF_TRANSITION_COVERAGE && pGen->isAllowedCppTransitionCoverage())
       {
        marty::uml::CClassAttributeInfo attr;
        attr.name = "transitionsCoverage";
        attr.type = "std::map<CTransitionInfoKey, unsigned, CTransitionInfoKeyLess>";
        attr.visibility = marty::uml::emvPub;
        attr.classScope = false;
        attr.value      = "";
        attr.comment    = "Automaticaly added member for checking transitions coverage" ;
        automataClass.attributes.push_back(attr);
       }

    // ������� ������ �������, � ������� ������� ���������� ���������, � ������� ����� ��������� ������� ��� ������� ������� �������
    std::map<std::string, std::set<std::string> > eventStates;

    std::vector<fsm::CTransitionInfo>::const_iterator trIt = stateMachine.transitions.begin();
    for(; trIt!=stateMachine.transitions.end(); ++trIt)
       {
        eventStates[trIt->trigger].insert(trIt->startState);
       }
    

    std::cout<<"Generating code\n";

    std::vector<std::string> commonDefines;
    std::vector<std::string> commonIncludes;

    //commonDefines.push_back("TEST test");

    bool bInline = false;
    if (genFlags&FGF_INLINE_METHODS && pGen->isAllowedCppInline())
       bInline = true;

    int stateCnt = 1;
    //const 
    int stateFinalMask = 0x80000000;
    if (genFlags&FGF_SHORT_INT)
       stateFinalMask = 0x8000;
    const std::string stateFinalMaskName = "__int_stateFinalMask__";

    std::map< std::string, fsm::CConstantName > stateNames;
    { // ���������� ����� �������� ���������
     std::vector<fsm::CStateInfo>::const_iterator stIt = stateMachine.states.begin();
     for(; stIt!=stateMachine.states.end(); ++stIt)
        {
         int v = stateCnt++;
         if (stIt->isFinal) v |= stateFinalMask;
         stateNames[stIt->name] = fsm::CConstantName(stIt->isFinal, v);
        }
     stateNames[stateFinalMaskName] = fsm::CConstantName(true, stateFinalMask);

     pGen->generateConstantNames(stateNames, namespaces, automataClass.name, std::string("ST_"), std::string());

     std::map< std::string, fsm::CConstantName >::const_iterator stNameIt = stateNames.begin();
     for(; stNameIt!=stateNames.end(); ++stNameIt)
        {
         marty::uml::CClassAttributeInfo attr;

         attr.name        = stNameIt->second.attrName;
         attr.type        = "int";

         char buf[256];
         if (genFlags&FGF_SHORT_INT)
            wsprintf(buf, "0x%04X", stNameIt->second.value);
         else
            wsprintf(buf, "0x%08X", stNameIt->second.value);
         attr.value       = buf;

         //attr.comment     = stNameIt->getStateName(genFlags); /* stNameIt->first; */ 
         attr.comment     = stateMachine.getStateName(stNameIt->first, genFlags); /* stNameIt->first; */ 
         attr.ptr         = false;
         attr.ref         = false;
     
         attr.visibility  = marty::uml::emvPub; // 0 - pub, 1 - private, 2 - protected, 3 - implementation (?)
         attr.classScope  = true; // static member 
         attr.constAttr   = true;

         automataClass.attributes.push_back(attr);
        }
    }

    const std::vector<std::string> emptyStringVector;

    //std::map<std::string, std::string> methodsCode;

    {
     marty::uml::CClassMethodInfo getCurrentStateMethodDeclaration;
     
     getCurrentStateMethodDeclaration.name = "getCurState";
     getCurrentStateMethodDeclaration.type = "int";
     getCurrentStateMethodDeclaration.visibility = marty::uml::emvPub;
     getCurrentStateMethodDeclaration.query = true;
     getCurrentStateMethodDeclaration.comment = "Automaticaly generated method, returns automata state";

     getCurrentStateMethodDeclaration.addCode( pGen->getLangName()
                                             , std::string("return ") + curStateVarName + std::string(";")
                                             , bInline
                                             );
     automataClass.methods.push_back(getCurrentStateMethodDeclaration);

     //methodsCode[getCurrentStateMethodDeclaration.name] = std::string("return ") + curStateVarName + std::string(";");

     marty::uml::CClassMethodInfo isInFinalStateMethodDeclaration;
     isInFinalStateMethodDeclaration.name = "isInFinalState";
     isInFinalStateMethodDeclaration.type = "int";
     isInFinalStateMethodDeclaration.visibility = marty::uml::emvPub;
     isInFinalStateMethodDeclaration.query = true;
     isInFinalStateMethodDeclaration.comment = "Automaticaly generated method, test automata is in one of final states";

     // isInFinalStateMethodDeclaration.addCode( pGen->getLangName()
     //                                        ,
     //                                        );

     isInFinalStateMethodDeclaration.addCode( pGen->getLangName()
                                            , std::string("return (") 
                                              + curStateVarName 
                                              + std::string(" & ") 
                                              + stateNames[stateFinalMaskName].intName 
                                              + std::string(") ? 1 : 0;")
                                            , bInline
                                            );
     automataClass.methods.push_back(isInFinalStateMethodDeclaration);
 
     // methodsCode[isInFinalStateMethodDeclaration.name] = std::string("return (") 
     //                                                   + curStateVarName 
     //                                                   + std::string(" & ") 
     //                                                   + stateNames[stateFinalMaskName].intName 
     //                                                   + std::string(") ? 1 : 0;");
     //return (curState & stateFinalMask) ? 1 : 0;
 
     if (!(genFlags&FGF_NO_CUSTOM_RESET))
        {
         marty::uml::CClassMethodInfo customResetMethodDeclaration;
         customResetMethodDeclaration.name = "customResetAutomata";
         customResetMethodDeclaration.type = "void";
         customResetMethodDeclaration.visibility = marty::uml::emvPro;
         customResetMethodDeclaration.comment = "Automaticaly generated abstract method declaration, define its body in dougther classes";
         customResetMethodDeclaration.virtualMethod = true;
         if (bInline)
            customResetMethodDeclaration.abstractMethod = false;
         else
            customResetMethodDeclaration.abstractMethod = true; // pureVirtual
    
         automataClass.methods.push_back(customResetMethodDeclaration);
        }

     marty::uml::CClassMethodInfo resetMethodDeclaration;
     resetMethodDeclaration.name = "resetAutomata";
     resetMethodDeclaration.type = "void";
     resetMethodDeclaration.visibility = marty::uml::emvPub;
     resetMethodDeclaration.comment = "Automaticaly generated method, resets automata to initial state";

     {
      std::stringstream ss;    
      //ss<<"\n";
      if (automataNeedStack)
         {
          pGen->generateFunctionCall( ss, namespaces, automataClass.name
                                   , "clearStateStack" // customResetMethodDeclaration.name
                                   , pthisStr, emptyStringVector
                                   );
          ss<<"\n";
         }

      if (!(genFlags&FGF_NO_CUSTOM_RESET))
         {
          pGen->generateFunctionCall( ss, namespaces, automataClass.name
                                   , "customResetAutomata" // customResetMethodDeclaration.name
                                   , pthisStr, emptyStringVector
                                   );
          ss<<"\n";
         }
 
      ss<<curStateVarName<<" = "<<stateNames[stateMachine.startState].intName<<";";
      resetMethodDeclaration.addCode( pGen->getLangName()
                                    , ss.str() // + std::string("\n")
                                    , bInline
                                    );

      //methodsCode[resetMethodDeclaration.name] = pthisStr + std::string("->state = ") + stateNames[stateMachine.startState].intName + std::string(";\n") + ss.str() + std::string("\n");
      //methodsCode[resetMethodDeclaration.name] = curStateVarName + std::string(" = ") + stateNames[stateMachine.startState].intName + std::string(";") + ss.str(); // + std::string("\n");
     }
     automataClass.methods.push_back(resetMethodDeclaration);


     marty::uml::CClassMethodInfo isInInadmissibleFinalStateMethodDeclaration;
     isInInadmissibleFinalStateMethodDeclaration.name = "isInInadmissibleFinalState";
     isInInadmissibleFinalStateMethodDeclaration.type = "int";
     isInInadmissibleFinalStateMethodDeclaration.visibility = marty::uml::emvPub;
     isInInadmissibleFinalStateMethodDeclaration.comment = "Automaticaly generated method, resets automata to initial state";

     std::string codeText;
     if (!needInadmissibleEndState)
        codeText = std::string("return 0;");
     else
        codeText = 
                     std::string("return ")
                   + curStateVarName
                   + std::string("==")
                   + stateNames[inadmissibleEndStateName].intName
                   + std::string(" ? 1 : 0;");

     isInInadmissibleFinalStateMethodDeclaration.addCode( pGen->getLangName()
                                   , codeText
                                   , bInline
                                   );
     automataClass.methods.push_back(isInInadmissibleFinalStateMethodDeclaration);
    }



    if (genFlags&FGF_USE_LOCKING)
       {
        marty::uml::CClassMethodInfo lockMethodDeclaration;
        lockMethodDeclaration.name = "lockAutomata";
        lockMethodDeclaration.type = "void";
        lockMethodDeclaration.visibility = marty::uml::emvPro;
        lockMethodDeclaration.comment = "Automaticaly generated method declaration, redefine its body in dougther classes";
        lockMethodDeclaration.virtualMethod = true;
        lockMethodDeclaration.abstractMethod = true; // pureVirtual
        automataClass.methods.push_back(lockMethodDeclaration);

        lockMethodDeclaration.name = "unlockAutomata";
        automataClass.methods.push_back(lockMethodDeclaration);

        std::vector<std::string> nameList = namespaces;
        nameList.push_back(automataClass.name);
        nameList.push_back("locking");
        nameList.push_back("used");
        commonDefines.push_back(pDefNameMaker->makeName(nameList));
       }


    if (genFlags&FGF_USE_LOGGING)
       {
        marty::uml::CClassMethodInfo logMethodDeclaration;
        logMethodDeclaration.name = logMethodName;
        logMethodDeclaration.type = "void";
        logMethodDeclaration.visibility = marty::uml::emvPro;
        logMethodDeclaration.comment = "Automaticaly generated method declaration, redefine its body in dougther classes";
        logMethodDeclaration.virtualMethod = true;
        logMethodDeclaration.abstractMethod = true; // pureVirtual

        marty::uml::CMethodParameterInfo paramEventType;
        paramEventType.name   = "eventTypeCode";
        paramEventType.type   = "int";
        paramEventType.ioKind = marty::uml::eiokUndef;
        paramEventType.comment = "0x0100 - event info flag, 0x0200 - action info flag, 0 - event message, 0x0010 - guard variable (C++ only, if -GL2|-GL+ command line options used), 2 - event message on inadmissible event, 0x0101 - from, 0x0102 - to, 0x0103 - event, 0x0104 - quard, 0x0201 - entry action, 0x0202 - trigger action, 0x0203 - do action, 0x0204 - exit action";
        logMethodDeclaration.parameters.push_back(paramEventType);

        paramEventType.name   = "fromState";
        paramEventType.type   = "int";
        paramEventType.ioKind = marty::uml::eiokUndef;
        paramEventType.comment = "transition start state, can be used for event filtration";
        logMethodDeclaration.parameters.push_back(paramEventType);

        paramEventType.name   = "toState";
        paramEventType.comment = "transition end state, can be used for event filtration";
        logMethodDeclaration.parameters.push_back(paramEventType);

        paramEventType.name   = "eventMsg";
        paramEventType.type   = "char";
        paramEventType.ptr    = true;
        paramEventType.ioKind = marty::uml::eiokIn;
        paramEventType.comment = "from/to state name, event name, guard condition, entry/trigger/do/exit action text or info message";
        logMethodDeclaration.parameters.push_back(paramEventType);

        automataClass.methods.push_back(logMethodDeclaration);

        std::vector<std::string> nameList = namespaces;
        nameList.push_back(automataClass.name);
        nameList.push_back("logging");
        nameList.push_back("used");
        commonDefines.push_back(pDefNameMaker->makeName(nameList));
       }

     if (genFlags&FGF_TRANSITION_COVERAGE && pGen->isAllowedCppTransitionCoverage())
        {
         marty::uml::CClassMethodInfo initCoverageMethod;
         initCoverageMethod.name = "initCoverage";
         initCoverageMethod.type = "void";
         initCoverageMethod.visibility = marty::uml::emvPub;
         initCoverageMethod.comment = "Automaticaly generated method declaration, initialises (clear) transition coverage map";
         initCoverageMethod.virtualMethod = false;
         initCoverageMethod.abstractMethod = false; // pureVirtual

         std::ostringstream ss;

         std::vector<fsm::CTransitionInfo>::const_iterator tit = stateMachine.transitions.begin();
         for(; tit!=stateMachine.transitions.end(); ++tit)
            {
             if (!tit->ignoreAllActions)
                {
                 ss<<"transitionsCoverage[CTransitionInfoKey(\""
                   <<tit->startState
                   <<"\", \""
                   <<stateMachine.getStateName(tit->startState, true)
                   <<"\", \""
                   <<tit->endState
                   <<"\", \""
                   <<stateMachine.getStateName(tit->endState, true)
                   <<"\", \""<<tit->trigger<<"\", \""<<tit->guard<<"\")] = 0;\n";
                }
            }

         initCoverageMethod.addCode( pGen->getLangName()
                                   , ss.str()
                                   , bInline
                                   );

         automataClass.methods.push_back(initCoverageMethod);

         //methodsCode[initCoverageMethod.name] = ss.str();

        std::vector<std::string> nameList = namespaces;
        nameList.push_back(automataClass.name);
        nameList.push_back("transition");
        nameList.push_back("coverage");
        nameList.push_back("used");
        commonDefines.push_back(pDefNameMaker->makeName(nameList));
        }

    
    if (automataNeedStack)
       { // Generating code for automata state stack
        
        pGen->addStackVars( automataClass, namespaces, stackSizeStr
                          , (genFlags&FGF_STACK_FORCE_PLAIN_C ? true : false)
                          , (genFlags&FGF_STACK_NO_OVERFLOW_CALLS ? false : true)
                          , bInline
                          , false /* bPlainCCode */
                          );

        pGen->addStackIncludesDefines( automataClass, namespaces, commonIncludes, commonDefines, (genFlags&FGF_STACK_FORCE_PLAIN_C ? true : false));

        std::vector<std::string> nameList = namespaces;
        nameList.push_back(automataClass.name);
        nameList.push_back("stack");
        nameList.push_back("used");
        commonDefines.push_back(pDefNameMaker->makeName(nameList));

        if (genFlags&FGF_STACK_NO_OVERFLOW_CALLS)
           {
            nameList = namespaces;
            nameList.push_back(automataClass.name);
            nameList.push_back("NO_OVERFLOW_CALLS");
            commonDefines.push_back(pDefNameMaker->makeName(nameList));
           }

    //std::vector<std::string> commonDefines;
    //std::vector<std::string> commonIncludes;
       
       }

    std::map<std::string, std::set<std::string> >::const_iterator esIt = eventStates.begin();
    for(; esIt!=eventStates.end(); ++esIt)
       {
        std::vector<marty::uml::CClassMethodInfo>::const_iterator methodIt
                    = std::find_if(
                                   automataClass.methods.begin(),
                                   automataClass.methods.end(),
                                   marty::uml::IsEqualByName<marty::uml::CClassMethodInfo>(esIt->first)
                                  );
        if (methodIt==automataClass.methods.end())
           {
            std::cout<<"Error: not found event handler (method '"<<esIt->first<<"') in automata class '"<<automataClass.name<<"'\n";
            return 20;
           }
        if (methodIt->abstractMethod)
           {
            std::cout<<"Error: event handler '"<<methodIt->name<<"' - can't be abstract method\n";
            return 21;           
           }

        std::string eventHandlerName = methodIt->name;
        std::vector<std::string> eventHandlerArgList;
        std::vector<CMethodParameterInfo>::const_iterator methodParamIt = methodIt->parameters.begin();
        unsigned paramCounter = 0;
        unsigned paramError = 0;
        for(; methodParamIt!=methodIt->parameters.end(); ++methodParamIt, ++paramCounter)
           {
            if (methodParamIt->name.empty())
               {
                std::cout<<"Error: event handler '"<<methodIt->name<<"' - parameter "<<paramCounter+1<<" has no name\n";
                ++paramError;
                //return 21;
               }
            eventHandlerArgList.push_back(methodParamIt->name);
           }

        //methodIt->
        if (paramError)
           return 21;

        bool isPodGuard = true;
        std::string guardObject;
        std::string guardVar;
        if (!methodIt->parameters.empty())
           {
            const marty::uml::CMethodParameterInfo &firstParam = methodIt->parameters[0];
            //std::vector<marty::uml::CMethodParameterInfo> parameters;
            if (firstParam.type!="void")
               {    // int by default       or other POD type
                if (firstParam.type.empty() || pGen->isPodType(firstParam.type))
                   {
                    if (firstParam.ptr)
                       guardVar = std::string(1, '*') + firstParam.name;
                    else
                       guardVar = firstParam.name;

                    guardObject = guardVar;
                   }
                else // non pod guardian variable
                   {
                    isPodGuard = false;
                    std::vector<marty::uml::CClassInfo>::iterator guardClassIt 
                                = std::find_if(
                                                allClasses.begin(), 
                                                allClasses.end(), 
                                                marty::uml::IsEqualByName<marty::uml::CClassInfo>(firstParam.type) 
                                              );
                    if (guardClassIt!=allClasses.end())
                       {
                        guardVar = firstParam.name;
                        if (firstParam.ptr)
                           {
                            guardObject = std::string(1, '*') + guardVar;
                            guardVar.append("->");
                           }
                        else
                           {
                            guardObject = guardVar;
                            guardVar.append(".");
                           }

                        bool structFieldFound = false;
                        std::vector<marty::uml::CClassAttributeInfo>::const_iterator attrIt
                                    = std::find_if(
                                                    guardClassIt->attributes.begin(), 
                                                    guardClassIt->attributes.end(), 
                                                    marty::uml::IsEqualByComment<marty::uml::CClassAttributeInfo>("guard") 
                                                  );
                        if (attrIt!=guardClassIt->attributes.end())
                           {
                            guardVar.append(attrIt->name);
                            structFieldFound = true;
                           }
                        else
                           {
                            std::vector<marty::uml::CClassMethodInfo>::const_iterator methodIt
                                        = std::find_if(
                                                        guardClassIt->methods.begin(), 
                                                        guardClassIt->methods.end(), 
                                                        marty::uml::IsEqualByComment<marty::uml::CClassMethodInfo>("guard") 
                                                      );
                            if (methodIt!=guardClassIt->methods.end())
                               {
                                guardVar.append(methodIt->name); guardVar.append("()");
                                structFieldFound = true;
                               }
                           }

                        if (!structFieldFound)
                           {
                            std::cout<<"Error: guard class/struct definition for event handler '"<<methodIt->name<<"' found, but there is no information about guard member/method\n";
                            return 21;
                           }

                       }
                    //std::vector<marty::uml::CClassInfo> allClasses;
                   }
               }
           }

        //stateMachine.buildStateMap();

        std::ostringstream codess;

        if (!guardVar.empty())
           {
            std::string gv = pGen->modifyGuardVarName(guardVar);
            codess<<"/* guard variable - "<<gv<<" */\n";
            codess<<"#ifdef GUARDVAR\n#undef GUARDVAR\n#endif\n#define GUARDVAR "<<gv<<"\n";
           }
        else
           codess<<"/* there is no guard variable */\n";

        if (genFlags&FGF_USE_LOCKING)
            {
             pGen->generateFunctionCall( codess, namespaces, automataClass.name
                                       , "lockAutomata"
                                       , pthisStr, emptyStringVector
                                       );
             codess<<"\n";
            }

        std::string ind(4, ' ');
        codess<<"switch("<<curStateVarName<<")\n"
              <<"   {\n";
              //<<ind;
        std::set<std::string>::const_iterator stIt = esIt->second.begin();
        for(; stIt!=esIt->second.end(); ++stIt)
           {
            codess<<ind<<"case "<<stateNames[*stIt].intName<<":    /* "<<stateMachine.getStateName(*stIt, genFlags)<<" */\n";

            std::vector<fsm::transition_pos_type> trPosList;
            //fsm::transition_pos_type foundTransitionsCount = 
            stateMachine.findTransitionsByEventFrom(esIt->first, *stIt, trPosList);
            std::vector<std::string> defines = commonDefines;
            defines.push_back(std::string("GUARDVAR ") + guardVar);
            int genRes = generateStateCode( codess
                                          , stateMachine
                                          , pGen.get()
                                          , genFlags
                                          , automataClass
                                          , namespaces
                                          , stateNames
                                          , defines
                                          , esIt->first  /* eventName */ 
                                          , *stIt        /* stateName */ 
                                          , eventHandlerName
                                          , eventHandlerArgList
                                          , trPosList
                                          , guardVar 
                                          , curStateVarName
                                          , isPodGuard
                                          , guardObject
                                          , ind + ind + ind
                                          );
            if (genRes) return genRes;

            //codess<<ind<<ind<<"// Found transitrions: "<<(unsigned)foundTransitionsCount<<"\n";

            // generate code here
            //cfg_line = ::boost::algorithm::trim_copy(cfg_line); //trim(cfg_line);  
            codess<<ind<<ind<<" break;\n\n";
           }
        //codess<<ind<<ind<<ind<<"default: ASSERT()\n\n";
        codess<<"   };\n";

        if (genFlags&FGF_USE_LOCKING)
            {
             pGen->generateFunctionCall( codess, namespaces, automataClass.name
                                       , "unlockAutomata"
                                       , pthisStr, emptyStringVector
                                       );
             codess<<"\n";
            }

        if (!methodIt->type.empty() && methodIt->type!="void")
           codess /* <<ind */ <<"return "<<curStateVarName<<";"; // "\n"

        automataClass.addMethodCode(methodIt->name, pGen->getLangName(), codess.str(), bInline);
        //methodsCode[methodIt->name] = codess.str();
       }


    { // check code existence for all methods
     std::vector<marty::uml::CClassMethodInfo>::iterator mit = automataClass.methods.begin();
     for(; mit!=automataClass.methods.end(); ++mit)
        {
         const CClassMethodInfo* pmi = automataClass.getMethodInfo(mit->name);
         if (pmi->virtualMethod && pmi->abstractMethod) continue;

         const marty::uml::CMethodCode *pmc = automataClass.getMethodCodeForLang(mit->name, pGen->getLangName(), true);
         if (!pmc)
            {
             pmc = automataClass.getMethodCodeForLang(mit->name, std::string("c++"), true);
             if (!pmc)
                {
                 pmc = automataClass.getMethodCodeForLang(mit->name, std::string(), false);
                }
             if (pmc)
                {
                 //marty::uml::getMethodCode mc = *pmc;
                 //mc.lang = pGen->getLangName();
                 automataClass.addMethodCode(mit->name, pGen->getLangName(), pmc->text, pmc->bInline);
                }
            }
         pmc = automataClass.getMethodCodeForLang(mit->name, pGen->getLangName(), true);
         if (!pmc)
            {
             std::ostringstream ss;
             pGen->makeEmptyReturn( ss, *mit );           
             automataClass.addMethodCode(mit->name, pGen->getLangName(), ss.str(), bInline);
            }

         /*
         const marty::uml::CClassOptions *pClassCodeOptions = automataClass.getMethodCode( pGen->getLangName(), mit->name);
                 
         if (pClassCodeOptions)
            { // code options found for mit->name method
             continue;
             //std::cout<<"Method: "<<mit->name<<" - found (inline) code options\n";
             //std::map<std::string, std::string> codeOptTags;
             //pClassCodeOptions->attrsToMap(codeOptTags);
            }

         std::map<std::string, std::string>::iterator codeIt = methodsCode.find(mit->name);
         
         if (codeIt!=methodsCode.end()) 
            continue; // found generated code

         std::ostringstream ss;
         pGen->makeEmptyReturn( ss, *mit );           
         methodsCode[mit->name] = ss.str();
         */
        }
    }

    //methodsCode[methodIt->name]
    //std::map<std::string, std::string> methodsCode;
    /*
    if (genFlags&FGF_INLINE_METHODS)
       {
        std::vector<marty::uml::CClassMethodInfo>::const_iterator mit = automataClass.methods.begin();
        for(; mit!=automataClass.methods.end(); ++mit)
           {
            if (mit->virtualMethod && mit->abstractMethod) continue;
   
            std::map<std::string, std::string>::iterator codeIt = methodsCode.find(mit->name);
            if (codeIt==methodsCode.end()) continue;
   
            marty::uml::CClassOptions opts;
            opts.text = codeIt->second;
            
            opts.optionAttrs.push_back(marty::uml::COptionAttr("lang", pGen->getLangName()));
            opts.optionAttrs.push_back(marty::uml::COptionAttr("method", mit->name));
            opts.optionAttrs.push_back(marty::uml::COptionAttr("inline", ""));
            automataClass.code.push_back(opts);

            methodsCode.erase(codeIt);
           }
       }
    */

    std::string basename = filePrefix + automataName;

    //std::vector<std::string> commonIncludeFiles;
    //std::copy(automataClass.includesList.begin(), automataClass.includesList.end(), std::back_inserter(commonIncludeFiles) );


    const std::string quotStr = "\"";


    if (genFlags&FGF_GENERATE_AUTOMATA_CLASS_DEF)
       {
        std::vector<std::string> includeFiles = commonIncludes;
        //includeFiles.push_back(quotStr + basename + std::string("_Ctx") + pGen->getHeaderSuffix() + quotStr);

        bool stringIncluded = false;
        if (genFlags&FGF_TRANSITION_COVERAGE && pGen->isAllowedCppTransitionCoverage())
           {
            includeFiles.push_back("<string>"); stringIncluded = true;
            includeFiles.push_back("<map>");
            includeFiles.push_back("<iostream>");
            includeFiles.push_back("<iomanip>");
           }

        if (genFlags&FGF_USE_GUARD_LOGGING && pGen->isAllowedCppTransitionCoverage())
           {
            pGen->addLoggerIncludes(includeFiles);
            /*
            if (!stringIncluded)
               {
                includeFiles.push_back("<string>"); stringIncluded = true;
               }
            includeFiles.push_back("<sstream>");
            */
           }

        const marty::uml::CClassOptions *pClassOptions = automataClass.getIncludes( pGen->getLangName() );
        if (pClassOptions)
           {
            std::vector<std::string> additionalIncludeFiles;
            ::boost::algorithm::split(additionalIncludeFiles, pClassOptions->text, fsm::util::CIsExactChar<'\n'>(), boost::algorithm::token_compress_on);
            std::copy(additionalIncludeFiles.begin(), additionalIncludeFiles.end(), std::back_inserter(includeFiles) );
           }        

        std::vector<std::string> defines = commonDefines;
        //defines.push_back("_pthis this");

        std::string filename = basename 
                             //+ std::string("_Automata") 
                             + ((genFlags&FGF_ADD_FILENAME_AUTOMATA_SUFFIX) ? std::string("_Automata") : std::string() )
                             + pGen->getHeaderSuffix();
        std::ofstream of(filename.c_str());

        pGen->generateHeaderProlog( of, filename, namespaces, includeFiles, defines);

        if (genFlags&FGF_TRANSITION_COVERAGE && pGen->isAllowedCppTransitionCoverage())
           {
            pGen->generateCppTransitionCoverage(of);
           }

        pGen->generateClassDefinition( of, namespaces, automataClass, genFlags );

        pGen->generateHeaderEpilog( of, filename, namespaces);
       }

    if (genFlags&FGF_GENERATE_AUTOMATA_CLASS_IMPL)
       {
        std::vector<std::string> includeFiles = commonIncludes;
        includeFiles.push_back( quotStr + basename 
                              + ((genFlags&FGF_ADD_FILENAME_AUTOMATA_SUFFIX) ? std::string("_Automata") : std::string() )
                              + pGen->getHeaderSuffix() + quotStr);

        std::vector<std::string> defines = commonDefines;
        //defines.push_back("_pthis this");

        std::string filename = basename 
                             //+ std::string("_Automata") 
                             + ((genFlags&FGF_ADD_FILENAME_AUTOMATA_SUFFIX) ? std::string("_Automata") : std::string() )
                             + pGen->getSourceSuffix();
        std::ofstream of(filename.c_str());

        pGen->generateSourceProlog( of, filename, namespaces, includeFiles, defines);

        std::map<std::string, std::string> methodsCode;
        pGen->generateClassImplemetation( of, namespaces, automataClass, methodsCode);

        pGen->generateSourceEpilog( of, filename, namespaces);       
       }

/*
    if (genFlags&FGF_GENERATE_CONTEXT_CLASSES_DEF)
       {
        std::vector<std::string> includeFiles = commonIncludes;

        std::vector<std::string> defines = commonDefines;

        std::string filename = basename + std::string("_Ctx") + pGen->getHeaderSuffix();
        std::ofstream of(filename.c_str());

        pGen->generateHeaderProlog( of, filename, namespaces, includeFiles, defines);

        pGen->generateHeaderEpilog( of, filename, namespaces);       
       }

    if (genFlags&FGF_GENERATE_AUTOMATA_CLASS_TPL)
       {
        std::vector<std::string> includeFiles = commonIncludes;
        includeFiles.push_back(quotStr + basename + std::string("_Automata") + pGen->getHeaderSuffix() + quotStr);

        std::vector<std::string> defines = commonDefines;

        std::string filename = basename + std::string("_AutomataImpTpl") + pGen->getSourceSuffix();
        std::ofstream of(filename.c_str());

        pGen->generateSourceProlog( of, filename, namespaces, includeFiles, defines);

        pGen->generateSourceEpilog( of, filename, namespaces);
       }
*/
    //delete pGen;
    //delete pDefNameMaker;

    return 0;
   }

//-----------------------------------------------------------------------------




