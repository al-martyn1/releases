#include <cli/cli2.h>

#include "lgPhp.h"
#include "util.h"


#include "../scanner/idlScanner.h"
#include "serializeSE.h"

#include "classHolder.h"
//#include "pp2pp_ACppConverter_Automata.h"
//#include "pp2c_ACConverter_Automata.h"
#include "pp2php_APhpConverter_Automata.h"

#include "generator.h"


using fsm::util::alignLeft;
using marty::uml::getVisibilityName;
using marty::uml::getIoKindName;

namespace fsm
{


struct CCpp2PhpConverter : public codegen::php::CCppConverter, fsmgen::CClassHolder
{
    
    CCpp2PhpConverter( const marty::uml::CClassInfo   *pci
                   , const std::vector<std::string> &ns
                   , fsm::ISourceGenerator           *pg)
    : codegen::php::CCppConverter()
    , fsmgen::CClassHolder(pci, ns, pg)
    {}

    int
    eventIsMemberMethod( const CScannerEvent &evt         
                       )
    {
     if (evt.token!=LT_IDENT) return 0; // no a member
     else if (fsmgen::CClassHolder::isMemberMethod(evt.text)) return 1;
     return 0;
    }

    int
    eventIsMemberAttr( const CScannerEvent &evt         
                     )
    {
     if (evt.token!=LT_IDENT) return 0; // no a member
     else if (fsmgen::CClassHolder::isMemberAttr(evt.text)) return 1;
     return 0;
    }

    int
    eventIsMemberConstStaticAttr
                                ( const CScannerEvent &evt         
                                )
    {
     if (evt.token!=LT_IDENT) return 0; // no a member
     else if (fsmgen::CClassHolder::isStaticConstMemberAttr(evt.text)) return 1;
     return 0;
    }


    void
    appendBufThisAccOp
                      ( 
                      )
       {
        appendTokenBuf(LT_KWD_THIS, "$this");
        appendTokenBuf(LT_PTR_ACC, "->");
       }

/*
    void
    mangleNameToC( CScannerEvent &evt         
                 )
    {
     if (evt.token!=LT_IDENT) return;
     if (!pClassInfo) return;
     //std::vector<std::string> emptyVec;
     // std::cout<<"Cpp mangle name '"<<evt.text<<"' to '"
     //          <<pGen->makeMethodName( namespaces, pClassInfo->name, evt.text, false)<<"'\n";
     evt.text = pGen->makeMethodName( namespaces, pClassInfo->name, evt.text, false);
    }
*/
    void
    mangleNameToC( CScannerEvent &evt         
                 )
    {
     if (evt.token!=LT_IDENT) return;
     if (!pClassInfo) return;
     evt.text = //std::string("$this->") + // /* std::string("$this->") + */  evt.text; 
     pGen->makeMethodName( namespaces, pClassInfo->name, evt.text, false);
    }


};

/*

struct CCpp2PhpConverter : public codegen::c::CCppConverter, fsmgen::CClassHolder
{
    
    CCpp2PhpConverter( const marty::uml::CClassInfo   *pci
                   , const std::vector<std::string> &ns
                   , fsm::ISourceGenerator           *pg)
    : codegen::c::CCppConverter()
    , fsmgen::CClassHolder(pci, ns, pg)
    {}

    int
    eventIsMemberMethod( const CScannerEvent &evt         
                       )
    {
     if (evt.token!=LT_IDENT) return 0; // no a member
     else if (fsmgen::CClassHolder::isMemberMethod(evt.text)) return 1;
     return 0;
    }

    int
    eventIsMemberAttr( const CScannerEvent &evt         
                     )
    {
     if (evt.token!=LT_IDENT) return 0; // no a member
     else if (fsmgen::CClassHolder::isMemberAttr(evt.text)) return 1;
     return 0;
    }

    void
    mangleNameToC( CScannerEvent &evt         
                 )
    {
     if (evt.token!=LT_IDENT) return;
     if (!pClassInfo) return;
     evt.text = std::string("$this->") + evt.text; // pGen->makeMethodName( namespaces, pClassInfo->name, evt.text, true);
    }


};
*/

//-----------------------------------------------------------------------------
int IPhpCodeGenerator::isAllowedCppInline( )
   {
    return 1;
   }

//-----------------------------------------------------------------------------
std::string IPhpCodeGenerator::getLangName()
   {
    return std::string("php");
   }


//-----------------------------------------------------------------------------
int IPhpCodeGenerator::convertCode( const std::string &cppStyleCode
               , const CClassInfo &curClass
               , const std::vector<CClassInfo> &allClasses
               , const std::vector<std::string> &namespaces
               , const std::vector<std::string> &defines
               , std::string &toStr
               )
   {
    std::vector<CScannerEvent> scannerEvents;
    int res = parseForConvertCode( cppStyleCode, defines, scannerEvents );
    if (res)
       {
        return res;
       }

    CCpp2PhpConverter cpp2phpConverter(&curClass, namespaces, this);
    cpp2phpConverter.resetAutomata();

    std::vector<CScannerEvent>::const_iterator sceIt = scannerEvents.begin();
    for(; sceIt!=scannerEvents.end(); ++sceIt)
       {
        cpp2phpConverter.putEvent(*sceIt);
       }
    cpp2phpConverter.eod();

    //toStr = ser.buf;
    //std::cout<<"Org: ["<<cppStyleCode<<"], converted: ["<<serializeScannerEvents(cpp2cConverter.buf)<<"]\n";
    toStr = serializeScannerEvents(cpp2phpConverter.buf);
    //toStr = cppStyleCode;
    
    return 0;
   }

//-----------------------------------------------------------------------------
int IPhpCodeGenerator::addStackVars( CClassInfo &curClass
                                   , const std::vector<std::string> &namespaces
                                   , const std::string &stackSizeStr
                                   , bool bPlain
                                   , bool bCallOverflows
                                   , bool bInline
                                   , bool bLangPlainC
                                   )
   {
    return IPhpBaseGenerator::addStackVars( curClass, namespaces, stackSizeStr
                                        , bPlain, bCallOverflows, bInline, false);
   }

//-----------------------------------------------------------------------------
int IPhpCodeGenerator::generateFunctionCall( std::ostream &os
                        , const std::vector<std::string> &namespaces
                        , const std::string &className
                        , const std::string &fnName
                        , const std::string &pthisName
                        , const std::vector<std::string> &args
                        )
   {
    os//<<pthisName<<"->"
      <<makeMethodName( namespaces, className, fnName, false)<<"( "; //<<", ";
    //os<<pthisName<<"->"<<fnName<<"( ";
    std::vector<std::string>::const_iterator argIt = args.begin();
    for(; argIt!=args.end(); ++argIt)
       {
        if (argIt!=args.begin())
           os<<", ";
        //os<<*argIt;
        os<<escapeC(*argIt);
       }
    os<<" );";

    return 0;
   }

//-----------------------------------------------------------------------------
int IPhpCodeGenerator::generateHeaderProlog( std::ostream &os
                        , const std::string &filename
                        , const std::vector<std::string> &namespaces
                        , const std::vector<std::string> &incFiles
                        , const std::vector<std::string> &_defines
                        )
   {
    std::vector<std::string> defines = _defines;
    //defines.push_back("_pthis this");

    IPhpBaseGenerator::generateHeaderProlog(os, filename, namespaces, incFiles, defines);
    generateNamespacesOpen(os, namespaces);
    return 0;
   }

//-----------------------------------------------------------------------------
int IPhpCodeGenerator::generateHeaderEpilog( std::ostream &os
                        , const std::string &filename
                        , const std::vector<std::string> &namespaces
                        )
   {
    generateNamespacesClose(os, namespaces);
    IPhpBaseGenerator::generateHeaderEpilog(os, filename, namespaces);
    return 0;
   }

//-----------------------------------------------------------------------------
int IPhpCodeGenerator::generateSourceProlog( std::ostream &os
                        , const std::string &filename
                        , const std::vector<std::string> &namespaces
                        , const std::vector<std::string> &incFiles
                        , const std::vector<std::string> &_defines
                        )
   {
    std::vector<std::string> defines = _defines;
    //defines.push_back("_pthis this");
    IPhpBaseGenerator::generateSourceProlog(os, filename, namespaces, incFiles, defines);
    generateNamespacesOpen(os, namespaces);
    return 0;
   }

//-----------------------------------------------------------------------------
int IPhpCodeGenerator::generateSourceEpilog( std::ostream &os
                        , const std::string &filename
                        , const std::vector<std::string> &namespaces
                        )
   {
    generateNamespacesClose(os, namespaces);
    IPhpBaseGenerator::generateSourceEpilog(os, filename, namespaces);
    return 0;
   }

//-----------------------------------------------------------------------------
std::string IPhpCodeGenerator::getHeaderSuffix()
   {
    return std::string(".php");
   }

//-----------------------------------------------------------------------------

std::string IPhpCodeGenerator::getSourceSuffix()
   {
    return std::string(".impl.php");
   }

//-----------------------------------------------------------------------------
int IPhpCodeGenerator::generateConstantNames( std::map< std::string, CConstantName > &names, 
                                              const std::vector<std::string> &namespaces,
                                              const std::string &className,
                                              const std::string &prefix, 
                                              const std::string &postfix)
   {
    std::vector<std::string> tmpEmptyVec;

    std::map< std::string, CConstantName >::iterator it = names.begin();
    for(; it!=names.end(); ++it)
       {
        it->second.attrName = prefix + makeMethodName(  /* "camel", */  tmpEmptyVec, std::string(), it->first, false) + postfix;
        it->second.intName  = prefix + makeMethodName(  /* "camel", */  tmpEmptyVec, std::string(), it->first, false) + postfix;
        //std::string 
        std::vector<std::string>::const_iterator nsIt = namespaces.begin();
        for(; nsIt!=namespaces.end(); ++nsIt)
           {
            if (nsIt->empty()) continue;
            if (!it->second.extName.empty())
               it->second.extName.append("::");
            it->second.extName.append(*nsIt);
           }
        if (!className.empty())
           {
            if (!it->second.extName.empty())
               it->second.extName.append("::");
            it->second.extName.append(className);
           }
        it->second.extName.append(it->second.intName);
       }
    return 0;
   }

//-----------------------------------------------------------------------------
int IPhpCodeGenerator::generateClassDefinition( std::ostream &os
                           , const std::vector<std::string> &namespaces
                           , const CClassInfo &clInfo
                           , int genFlags
                           )
   {
    //if (clInfo.stereotype!="Automata") return 0;

    bool hasAbstractMethods = false;
    std::vector<marty::uml::CClassMethodInfo>::const_iterator  mit = clInfo.methods.begin();
    for(; mit!=clInfo.methods.end(); ++mit)
       {
        if (mit->virtualMethod && mit->abstractMethod) 
           {
            hasAbstractMethods = true;
            break;
           }
        const CMethodCode *pcode = mit->getCodeForLang(getLangName(), true);
        if (!pcode) 
           {
            hasAbstractMethods = true;
            break;
           }
       }

    if (hasAbstractMethods) os<<"abstract ";
    os<<"class "<<clInfo.name<<" {\n\n";

    ::std::string stateEnumName;
    if (genFlags&FGF_STATIC_CONST_AS_ENUM)
       {
        stateEnumName = ::std::string("E") + clInfo.name + ::std::string("State");
       }

    size_t staticAttrCount = 0;
    std::vector<marty::uml::CClassAttributeInfo>::const_iterator  ait = clInfo.attributes.begin();
    for(; ait!=clInfo.attributes.end(); ++ait)
       {
        if (!ait->isStaticConstant()) continue;
        ++staticAttrCount;
       }

    size_t indexFirst = 0;
    size_t indexLast  = staticAttrCount - 1;
    size_t indexCurrent = 0;

/*
    if (genFlags&FGF_STATIC_CONST_AS_ENUM && staticAttrCount)
       {
        os<<"enum "<<stateEnumName<<"{\n";
       }
*/

    //std::vector<marty::uml::CClassAttributeInfo>::const_iterator  
    ait = clInfo.attributes.begin();
    for(; ait!=clInfo.attributes.end(); ++ait)
       {
        if (!ait->isStaticConstant()) continue;
        generateAttributeDefinition( os, std::string(""), *ait, namespaces, clInfo.name
                                   , false, true, ((genFlags&FGF_STATIC_CONST_AS_ENUM) ? true : false)
                                   , indexCurrent==indexFirst, indexCurrent==indexLast
                                   ); // static const
        ++indexCurrent;
       }

/*
    if (genFlags&FGF_STATIC_CONST_AS_ENUM && staticAttrCount)
       {
        os<<"};";
       }
*/

    if (staticAttrCount) os<<"\n\n";

    indexLast  = clInfo.attributes.size() - staticAttrCount - 1;
    indexCurrent = 0;

    //std::vector<marty::uml::CClassAttributeInfo>::const_iterator  
    ait = clInfo.attributes.begin();
    for(; ait!=clInfo.attributes.end(); ++ait)
       {
        if (ait->isStaticConstant()) continue;
        marty::uml::CClassAttributeInfo attrInfo = *ait;
        if (genFlags&FGF_STATIC_CONST_AS_ENUM && attrInfo.name=="curState")
           attrInfo.type = stateEnumName;
        generateAttributeDefinition( os, std::string("    "), attrInfo, namespaces, clInfo.name
                                   , false, false, ((genFlags&FGF_STATIC_CONST_AS_ENUM) ? true : false)
                                   , indexCurrent==indexFirst, indexCurrent==indexLast
                                   ); // all but no static const
        ++indexCurrent;
       }
/*
//FGF_STATIC_CONST_AS_ENUM
    size_t indexFirst = 0;
    size_t indexLast  = clInfo.attributes.size()-1;
    size_t indexCurrent = 0;

    std::vector<marty::uml::CClassAttributeInfo>::const_iterator  ait = clInfo.attributes.begin();
    for(; ait!=clInfo.attributes.end(); ++ait, ++indexCurrent)
       {
        generateAttributeDefinition( os, std::string("    "), *ait, namespaces, clInfo.name, false, true , false, indexCurrent==indexFirst, indexCurrent==indexLast);
        generateAttributeDefinition( os, std::string("    "), *ait, namespaces, clInfo.name, false, false, false, indexCurrent==indexFirst, indexCurrent==indexLast);
       }
*/
    os<<"\n\n";

    //std::vector<marty::uml::CClassMethodInfo>::const_iterator  
    mit = clInfo.methods.begin();
    for(; mit!=clInfo.methods.end(); ++mit)
       {
        generateMethodDefinition( os, std::string("    "), clInfo.name, *mit, namespaces, false, true);

        const CMethodCode *pcode = mit->getCodeForLang(getLangName(), true);
        if (!pcode)
           pcode = mit->getCodeForLang(getLangName(), false);

        if (mit->virtualMethod && mit->abstractMethod)
           pcode = 0;

        if (pcode  /* && pcode->bInline */)
           {
            std::string ind(8, ' ');
            os<<"\n"<<ind<<"   {\n";

            std::string convertedCode;
            std::vector<CClassInfo> allClasses;
            std::vector<std::string> defines;
            defines.push_back("_pthis  this");
            convertCode( pcode->text, clInfo, allClasses, namespaces, defines, convertedCode );

            os<<fsm::util::codeIndent(convertedCode, 12)<<"\n";
            os<<ind<<"   }\n\n";
           }
        else
           os<<";\n\n"; // os<<"{}\n\n";
        
        /*
        const marty::uml::CClassOptions *pClassOptions = clInfo.getMethodCode( getLangName(), mit->name);
        if (pClassOptions)
           {
            std::map<std::string, std::string> optTags;
            pClassOptions->attrsToMap(optTags);
            std::map<std::string, std::string>::const_iterator it = optTags.find("inline");
            if (it==optTags.end() || it->second!="false")
               {
                std::string ind(8, ' ');
                os<<"\n"<<ind<<"   {\n";
                os<<fsm::util::codeIndent(pClassOptions->text, 12)<<"\n";
                os<<ind<<"   }\n\n";
               }
           }
        else
           os<<";\n\n";
        */
       }


    os<<"\n};\n\n";

    return 0;
   }

//-----------------------------------------------------------------------------
int IPhpCodeGenerator::generateClassImplemetation( std::ostream &os
                           , const std::vector<std::string> &namespaces
                           , const CClassInfo &clInfo
                           , std::map<std::string, std::string> &methodsCode
                           )
   {
    //os<<"\n#ifndef _pthis\n#define _pthis this\n#endif\n\n";

    os<<"\n";
    std::vector<marty::uml::CClassMethodInfo>::const_iterator  mit = clInfo.methods.begin();
    for(; mit!=clInfo.methods.end(); ++mit)
       {
        if (mit->virtualMethod && mit->abstractMethod) continue;

        const CMethodCode *pcode = mit->getCodeForLang(getLangName(), true);
        if (!pcode)
           pcode = mit->getCodeForLang(getLangName(), false);
        if (!pcode || pcode->bInline)
           continue;


        /*
        const marty::uml::CClassOptions *pClassCodeOptions = clInfo.getMethodCode( getLangName(), mit->name);
        std::map<std::string, std::string> codeOptTags;
    
        if (pClassCodeOptions)
           {
            //std::cout<<"Method: "<<mit->name<<" - found (inline) code options\n";
            pClassCodeOptions->attrsToMap(codeOptTags);
           }
    
        std::map<std::string, std::string>::const_iterator inlineIt = codeOptTags.find("inline");
        if (inlineIt!=codeOptTags.end())
           {
            //std::cout<<"Method: "<<mit->name<<" - found 'inline' option\n";
            if (inlineIt->second!="false")
               {
                //std::cout<<"Method: "<<mit->name<<" - 'inline' option not false\n";
                continue; // inline code
               }
            else
               {
                //std::cout<<"Method: "<<mit->name<<" - 'inline' option is false\n";
               }
           }
        else // code options found, but inline option not found, default value for inline opt is true, then continue;
           {
            if (pClassCodeOptions) continue;
           }
        */

        os<<"\n//-----------------------------------------------------------------------------\n";
        generateMethodDefinition( os, std::string(), clInfo.name, *mit, namespaces, false, false);
        os<<"\n   {";

        if (pcode && !pcode->bInline)
           {
            //std::string ind(8, ' ');
            //os<<"\n"<<ind<<"   {\n";

            std::string convertedCode;
            std::vector<CClassInfo> allClasses;
            std::vector<std::string> defines;
            defines.push_back("_pthis  this");
            convertCode( pcode->text, clInfo, allClasses, namespaces, defines, convertedCode );

            //os<<fsm::util::codeIndent(convertedCode, 12)<<"\n";
            os<<"\n"<<fsm::util::codeIndent(convertedCode, 4)<<"\n";
            //os<<ind<<"   }\n\n";
           }

        /*
        std::string code;
        bool codeFound = false;

        std::map<std::string, std::string>::iterator mcIt = methodsCode.find(mit->name);
        if (mcIt!=methodsCode.end())
           {
            code = 
                   //std::string("\n") + 
                   mcIt->second;
            codeFound = true;
           }

        if (!codeFound)
           {
            //const marty::uml::CClassOptions *pClassOptions = clInfo.getMethodCode( getLangName(), mit->name);
            //if (pClassOptions)
            //   {
                //std::map<std::string, std::string> optTags;
                //pClassOptions->attrsToMap(optTags);
                //std::map<std::string, std::string>::const_iterator it = optTags.find("inline");
                //if (it!=optTags.end() && it->second=="false")
                if (inlineIt!=codeOptTags.end())
                   {
                    code = 
                           //std::string("\n") + 
                           pClassCodeOptions->text;
                    codeFound = true;
                   }
            //    }
           }

        if (codeFound)
           {
            os<<"\n"<<fsm::util::codeIndent(code, 4)<<"\n";
           }
        */
        os<<"   }\n";
       }
    return 0;
   }

//-----------------------------------------------------------------------------

int IPhpCodeGenerator::generateClassImplTemplate( std::ostream &os
                           , const std::vector<std::string> &namespaces
                           , const CClassInfo &clInfo
                           , std::map<std::string, std::string> &methodsCode
                           )
   {
    return 0;
   }

//-----------------------------------------------------------------------------

int IPhpCodeGenerator::generateEventContextClassDefinition( std::ostream &os
                           , const std::vector<std::string> &namespaces
                           , const CClassInfo &clInfo
                           )
   {
    if (clInfo.stereotype!="Context") return 0;

    {
     std::vector<std::string>::const_iterator it = namespaces.begin();
     for(; it!=namespaces.end(); ++it)
        {
         os<<"namespace "<<*it<<" {\n";
        }
    }
    os<<"\n";

    os<<"typedef struct tag_"<<clInfo.name<<" {\n"; // nmaker->makeName()


    os<<"\n} "<<clInfo.name<<";\n\n";

    {
     std::vector<std::string>::const_reverse_iterator it = namespaces.rbegin();
     for(; it!=namespaces.rend(); ++it)
        {
         os<<"}; // namespace "<<*it<<" {\n";
        }
    }

    return 0;
   }

//-----------------------------------------------------------------------------


}; // namespace fsm
