#ifndef FSMGEN_LGCPP_H
#define FSMGEN_LGCPP_H

#include "lgCBase.h"

namespace fsm
{

struct ICppCodeGenerator : public ICBaseGenerator
{
    ICppCodeGenerator(const std::string &namesStyle)
       : ICBaseGenerator(namesStyle)
       {
        podSet.insert("bool");
       }

    int isAllowedCppTransitionCoverage( )
       {
        return 1;
       }

    std::string getLangName();

    int isAllowedCppInline( );

    int addStackVars( CClassInfo &curClass
                    , const std::vector<std::string> &namespaces
                    , const std::string &stackSizeStr
                    , bool bPlain
                    , bool bCallOverflows
                    , bool bInline
                    , bool bLangPlainC
                    );

    int convertCode( const std::string &cppStyleCode
                   , const CClassInfo &curClass
                   , const std::vector<CClassInfo> &allClasses
                   , const std::vector<std::string> &namespaces
                   , const std::vector<std::string> &defines
                   , std::string &toStr
                   );

    int generateFunctionCall( std::ostream &os
                            , const std::vector<std::string> &namespaces
                            , const std::string &className
                            , const std::string &fnName
                            , const std::string &pthisName
                            , const std::vector<std::string> &args
                            );

    int generateHeaderProlog( std::ostream &os
                            , const std::string &filename
                            , const std::vector<std::string> &namespaces
                            , const std::vector<std::string> &incFiles
                            , const std::vector<std::string> &defines
                            );
    int generateHeaderEpilog( std::ostream &os
                            , const std::string &filename
                            , const std::vector<std::string> &namespaces
                            );
    int generateSourceProlog( std::ostream &os
                            , const std::string &filename
                            , const std::vector<std::string> &namespaces
                            , const std::vector<std::string> &incFiles
                            , const std::vector<std::string> &defines
                            );
    int generateSourceEpilog( std::ostream &os
                            , const std::string &filename
                            , const std::vector<std::string> &namespaces
                            );

    std::string getHeaderSuffix();

    std::string getSourceSuffix();

    int generateConstantNames( std::map< std::string, CConstantName > &names, 
                               const std::vector<std::string> &namespaces,
                               const std::string &className,
                               const std::string &prefix, 
                               const std::string &postfix);

    int generateClassDefinition( std::ostream &os
                               , const std::vector<std::string> &namespaces
                               , const CClassInfo &clInfo
                               , int genFlags
                               );
    int generateClassImplemetation( std::ostream &os
                               , const std::vector<std::string> &namespaces
                               , const CClassInfo &clInfo
                               , std::map<std::string, std::string> &methodsCode
                               );
    int generateClassImplTemplate( std::ostream &os
                               , const std::vector<std::string> &namespaces
                               , const CClassInfo &clInfo
                               , std::map<std::string, std::string> &methodsCode
                               );
    int generateEventContextClassDefinition( std::ostream &os
                               , const std::vector<std::string> &namespaces
                               , const CClassInfo &clInfo
                               );
    virtual void addLoggerIncludes( std::vector<std::string> & includeFiles)
       {
        includeFiles.push_back("<string>");
        includeFiles.push_back("<sstream>");
       }



};

}; // namespace fsm


#endif /* FSMGEN_LGCPP_H */

