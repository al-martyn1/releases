#ifndef SERIALIZESE_H
#define SERIALIZESE_H


#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#include "seser.h"

inline
std::string serializeScannerEvents(const std::vector<CScannerEvent> &scannerEvents)
   {
    codegen::CScannerEventSerializator ser;
    ser.resetAutomata( );

    std::vector<CScannerEvent>::const_iterator it = scannerEvents.begin();
    for(; it!=scannerEvents.end(); ++it)
       {
        ser.putEvent(*it);
       }
    ser.eod();
    return ser.buf;
   }



#endif /* SERIALIZESE_H */

