/*----------------------------------------------------------------------------
*  Module Name:  cc2x_arg.cpp
*  Description:  cc2x command line arguments parsing
*  Date:         03/15/02
*----------------------------------------------------------------------------*/

#pragma hdrstop

#include <vector>
#include <map>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdio>

#include "pcpp_arg.h"
//#include "../common/textutil.h"

#include <marty/filename.h>

std::string ltrim(const std::string& s);
std::string rtrim(const std::string& s);
inline
std::string trim(const std::string& s)
{ 
 return ltrim(rtrim(s));
};


static
bool __pcpp_arg_isspace(char ch)
{
/*
 if (ch==_T(' ')  || 
     ch==_T('\t') || 
     ch==_T('\r') || 
     ch==_T('\n') || 
     ch==_T('\b')
    ) return true;
*/
 if (ch==' '  || 
     ch=='\t' || 
     ch=='\r' || 
     ch=='\n' || 
     ch=='\b'
    ) return true;
 return false;
}

//-----------------------------------------------------------------------------
std::string ltrim(const std::string& s)
{
 std::string::size_type i=0;
 for (; i<s.size(); i++)
     {
      if (!__pcpp_arg_isspace(s[i])) break;
     }
 return std::string(s, i, std::string::npos);
}

//-----------------------------------------------------------------------------
std::string rtrim(const std::string& s)
{
 int j;
 for (j=s.size()-1; j>=0; j--)
     {
      if (!__pcpp_arg_isspace(s[j])) break;
     }
 return std::string(s, 0, (std::string::size_type)j+1);
}


#ifdef USE_MARTY_NAMESPACE
using namespace ::marty;
#endif



//#include "pcppaux.h"

/*
#include "ccsymmap.h"
#include "cclexenv.h"
#include "cckeywrd.h"
#include "ccfiles.h"
#include "ccvarpr.h"
*/

using namespace std;

int read_config_file(const char* fname);
void print_help();
int parse_option(const char* s);
/*
extern int dont_map_symbols;
extern string user_types_save_filename;
extern int    dont_save_user_types;
extern int disable_output;
extern int disable_links;
extern int disable_labels;
*/

/*----------------------------------------------------------------------------*/
int read_config_file(const char* fname) 
{
 std::ifstream cfg(fname);
 std::string cfg_line;
 getline(cfg,cfg_line);
 cfg_line = trim(cfg_line);  
 while(cfg && cfg_line.size())
   {
    int pr = parse_option(cfg_line.c_str());
    if (pr) return pr;
    getline(cfg,cfg_line);
    cfg_line = trim(cfg_line);  
   }
 return 0;
}
/*----------------------------------------------------------------------------*/
void print_help()
{
/*
 std::cout<<"Usage: cc2x [-option [-option]] file1.ext file2.ext ...\n";
 std::cout<<"If no input file(s) assumed, used stdin.\n";
 std::cout<<"Options:\n";
 std::cout<<"  -efile               - Lexems environment file.\n";
 std::cout<<"  -m(+|-|filename)     - Symbol mapping - Use | Don't use | Map file.\n";
 std::cout<<"  -kfilename           - Keywords file.\n";
 std::cout<<"  -ufilename           - User keywords file.\n";
 std::cout<<"  -tfilename           - Types file.\n";
 std::cout<<"  -yfilename           - User types file.\n";
 std::cout<<"  -s(+|-|filename)     - Save user types - Save | Don't save | File for saving.\n";
 std::cout<<"                         Default file name is same as in -y option.\n";
 std::cout<<"  -nfilename           - Name decoration file.\n";
 std::cout<<"  -r(+|-)              - Disable | Enable hyperlinks.\n";
 std::cout<<"  -l(+|-)              - Disable | Enable labels.\n";
 std::cout<<"  -o(+|-|filename)     - Output - Enable | Disable | Set output file.\n";
 std::cout<<"                         Default is stdout\n.";
 std::cout<<"  -Pvar_popref         - Variable or fn arg popref decoration\n";
 std::cout<<"  -fvar_popref_fixed_text - Variable or fn arg popref decoration fixed part\n";
 std::cout<<"  -vvar[,var]          - Variable or fn arg names list for popref decoration\n";
 std::cout<<"  -Fvar_popref_fixed_text - Type popref decoration fixed part (2)\n";
 std::cout<<"  -Vvar[,var]          - Type names list for popref decoration (2)\n";
 std::cout<<"                         Default is stdout\n.";
 std::cout<<"  -h,?                 - This help screen.\n";
 std::cout<<"Default options: -m -s -r -l -o\n";
*/
}
/*----------------------------------------------------------------------------*/
int parse_option(const char* s)
{
 int res = 0;
 if (*s!='-' && *s!='/')
    {
     std::cout<<"Invalid command line option: '"<<s<<"'\n";
     return 2;
    }
 char key = *((++s)++);
 switch(key)
   {
   /*
    case 's':
              switch(*s)
                {
                 case '\0': 
                 case '+':  dont_save_user_types = 0; break;
                 case '-':  dont_save_user_types = 1; break;
                 default :  user_types_save_filename = s;
                };              
              break;

    case 'k': read_keywords(s);
              break;

    case 'u': read_user_keywords(s);
              break;

    case 't': read_types(s);
              break;

    case 'y': if (!user_types_save_filename.size()) 
                 user_types_save_filename = s;
              read_user_types(s);
              break;

    case 'e': read_lexenv_file(s);
              break;

    case 'o': 
              switch(*s)
                {
                 case '\0':
                 case '+':  disable_output = 0; break;
                 case '-':  disable_output = 1; break;
                 default :  output_set_file(s);
                };
              break;

    case 'r': 
              switch(*s)
                {
                 case '-':  disable_links = 1; break;
                 case '\0':
                 case '+':  disable_links = 0; break;                 
                };
              break;

    case 'l': 
              switch(*s)
                {
                 case '-':  disable_labels = 1; break;
                 case '\0':
                 case '+':  disable_labels = 0; break;                 
                };
              break;

    case 'm': 
              switch(*s)
                {
                 case '\0': 
                 case '+':  dont_map_symbols = 0; break;
                 case '-':  dont_map_symbols = 1; break;
                 default :  res = read_map_file(s);
                };              
              break; 

    case 'n': read_name_decoration(s);
              break;

    case 'P': set_popref_text(s);
              break;

    case 'f': set_popref_fixed_text(s);
              break;

    case 'v': add_popref_idents(s);
              break;

    case 'F': set_popref_fixed_text(s, 1);
              break;

    case 'V': add_popref_idents(s, 1);
              break;

    case '?': 
    case 'h': 
              print_help();
              return 1;              

*/
    case '0' : break;
    default:  
              std::cout<<"Invalid command line option: '"<<s<<"'\n";
              print_help();
              return 1;
   };
 return res;
}
/*----------------------------------------------------------------------------*/
int parse_command_line(int argc, char* argv[])
{
 return parce_command_line(argc, argv);
}

/*----------------------------------------------------------------------------*/
int parce_command_line(int argc, char* argv[])
{
 ios_base::sync_with_stdio(true);

 //std::string cfg_name = get_file_name(argv[0]) + std::string(".cfg");
 std::string cfg_name = filename::changeExtention(argv[0], ".cfg");// get_file_name(argv[0]) + std::string(".cfg");
 int pr = read_config_file(cfg_name.c_str());
 if (pr) return pr;

 for (int i=1; i<argc; i++)
     {
      int pr = 0;
      switch(*argv[i])
        {
         case '-':
         case '/':  pr = parse_option(argv[i]);
                    break;

         case '@':  pr = read_config_file(argv[i]+1);
                    break;
//         default:   //std::string infile = argv[i];
                    //infile = trim(infile);
                    //input_add_file(infile.c_str());
        };
      
      if (pr) return pr;     
     }
 return 0;
}
/*----------------------------------------------------------------------------*/
