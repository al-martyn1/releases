/*----------------------------------------------------------------------------
*  Module Name:  pcpp_arg.cpp
*  Description:  pcpp command line arguments parsing
*  Date:         
*----------------------------------------------------------------------------*/

#ifndef PCPP_ARG_H
#define PCPP_ARG_H



#ifdef __cplusplus
extern "C"{
#endif /* __cplusplus */

int parce_command_line(int argc, char* argv[]);
int parse_command_line(int argc, char* argv[]);











#ifdef __cplusplus
};
#endif /* __cplusplus */


#endif /* CC2X_ARG_H */