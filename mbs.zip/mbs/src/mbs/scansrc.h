#ifndef MBS_SCANSRC_H
#define MBS_SCANSRC_H

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif


#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif


#include "../scanner/utils.h"
#include "util.h"
#include <marty/macroses.h>
#include "toolset.h"


#ifndef BOOST_STRING_CASE_CONV_HPP
    #include <boost/algorithm/string/case_conv.hpp>
#endif

namespace mbs
{




template <typename T>
::std::ostream& operator<<( ::std::ostream &os, const ::std::vector<T> &t)
   {
    for(::std::vector<T>::const_iterator it = t.begin(); it!=t.end(); ++it)
       os<<*it<<" ";
    return os;
   }


template <typename T>
void pushBackIfNotExist(::std::vector<T> &v, const T &t)
   {
    ::std::vector<T>::const_iterator it = v.begin();
    for(; it!=v.end(); ++it)
       if (*it==t) return;
    v.push_back(t);
   }

template <typename T>
void appendUnique( const ::std::vector<T> &V, ::std::vector<T> &toV)
   {
    ::std::vector<T>::const_iterator it = V.begin();
    for(; it!=V.end(); ++it)
       pushBackIfNotExist(toV, *it);
   }



template <typename T>
void splitStructByName(const T &t, ::std::vector<T> &v)
   {
    if (t.name.empty()) { v.push_back(t); return; }
    ::std::vector< ::std::string > names;
    util::splitStringToWords( t.name, names, util::isExactChar<';'>());

    T tmp = t;
    ::std::vector< ::std::string >::const_iterator it = names.begin();
    for(; it!=names.end(); ++it)
       {
        if (it->empty()) continue;
        tmp.name = *it;
        v.push_back(tmp);
       }
   }

struct CConfigurationSrcInfo
{
    ::std::string                      name;
    ::std::vector<::std::string>       libs;
    ::std::vector<::std::string>       libPath;
    ::std::vector<::std::string>       incPath;
    ::std::vector<::std::string>       defines;

    void clear()
       {
        name.clear();
        libs.clear();
        libPath.clear();
        incPath.clear();
        defines.clear();
       }

    bool empty()
       {
        return (name.empty() && libs.empty() && libPath.empty() && incPath.empty() && defines.empty());
       }

    void split(::std::vector< CConfigurationSrcInfo > &v) const
       {
        splitStructByName(*this, v);
       }

    bool merge( const CConfigurationSrcInfo &ci)
       {
        if (name != ci.name) return false;
        //libs.insert(libs.end(), ci.libs.begin(), ci.libs.end());
        //libPath.insert(libPath.end(), ci.libPath.begin(), ci.libPath.end());
        //incPath.insert(incPath.end(), ci.incPath.begin(), ci.incPath.end());
        appendUnique( ci.libs, libs);
        appendUnique( ci.libPath, libPath);
        appendUnique( ci.incPath, incPath);
        appendUnique( ci.defines, defines);
        return true;
       }

}; // struct CConfigurationSrcInfo

inline 
::std::ostream& operator<<( ::std::ostream &os, const CConfigurationSrcInfo &i)
   {
    os<<"    Configuration: "<<i.name<<"\n";
    os<<"        Libs   : "<<i.libs<<"\n";
    os<<"        LibPath: "<<i.libPath<<"\n";
    os<<"        IncPath: "<<i.incPath<<"\n";
    os<<"        Defines: "<<i.defines<<"\n";
    return os;
   }




struct CPlatformSrcInfo
{
    ::std::string                          name;
    ::std::vector<CConfigurationSrcInfo>   configurations;

    void getConfigurationInfo(const ::std::string &cname, CConfigurationSrcInfo &info) const
       {
        CConfigurationSrcInfo tmp;
        tmp.name = std::string("");
        std::vector<CConfigurationSrcInfo>::const_iterator it = configurations.begin();
        for(; it!=configurations.end(); ++it)
           {
            tmp.merge(*it);
           }

        tmp.name = cname;
        it = configurations.begin();
        for(; it!=configurations.end(); ++it)
           {
            tmp.merge(*it);
           }

        info = tmp;       
       }

    void clear()
       {
        name.clear();
        configurations.clear();
       }

    bool empty()
       {
        return (name.empty() && configurations.empty());
       }

    void split(::std::vector< CPlatformSrcInfo > &v) const
       {
        ::std::vector<CConfigurationSrcInfo> tmp;
        ::std::vector<CConfigurationSrcInfo>::const_iterator it = configurations.begin();
        for(; it!=configurations.end(); ++it)
           it->split(tmp);

        CPlatformSrcInfo platformTmp;
        platformTmp.name = name;
        platformTmp.configurations = tmp;
        splitStructByName(platformTmp, v);
       }

    //void split

    bool merge( const CPlatformSrcInfo &ci)
       {
        //if (name != ci.name) return false;
        if (name != ci.name) return false;

        ::std::vector<CConfigurationSrcInfo>::const_iterator citCi = ci.configurations.begin();
        for(; citCi!=ci.configurations.end(); ++citCi)
           {
            ::std::vector<CConfigurationSrcInfo>::iterator cit = configurations.begin();
            for(; cit!=configurations.end(); ++cit)
               {
                if (cit->merge(*citCi)) 
                   break; // ������� ������������ � ����� �� ������, ������
               }
            if (cit==configurations.end()) // ����� ������������ ���, ��������� ������������ � �����
             configurations.push_back(*citCi);
           }
        return true;
       }


}; // struct CPlatformSrcInfo

inline 
::std::ostream& operator<<( ::std::ostream &os, const CPlatformSrcInfo &i)
   {
    os<<"Platform: "<<i.name<<"\n";
    os<<i.configurations<<"\n";
    return os;
   }


struct CProjectSrcInfo
{
    std::string                      description;
    std::vector<CPlatformSrcInfo>    platforms;
    std::vector< ::std::string >     slnconvFlags;
    int                              slnconvKnownFlags;

    // must be in sync with CMakefileInfo
    static const int useQt = 1;
    static const int useWx = 2;
    static const int mocAllHeaders = 4;


    inline 
    void converterFlagsToMacroses(std::map<std::string, std::string> &macroses) const
       {
        std::vector< ::std::string >::const_iterator it = slnconvFlags.begin();
        for(; it!=slnconvFlags.end(); ++it)
           {
            marty::macro::varsToMacroses(*it, macroses, true, false, std::string("_"), std::string("_"));
           }
       }

    void buildKnownSlnconvFlags()
       {
        slnconvKnownFlags = 0;
        std::vector< ::std::string >::const_iterator it = slnconvFlags.begin();
        for(; it!=slnconvFlags.end(); ++it)
           {
            ::std::string var, val;
            bool bAppend = false; // not used
            bool bSubst  = false; // not used
            marty::macro::splitToMacrosPair( *it, var, val, bAppend, bSubst, '=');
            ::boost::algorithm::to_lower(var);
            if (var=="usewx")
               slnconvKnownFlags |= useWx;
            else if (var=="useqt")
               slnconvKnownFlags |= useQt;
            else if (var=="mocallheaders")
               slnconvKnownFlags |= mocAllHeaders;
           }
       
       }

    void getPlatformInfo(const ::std::string &pname, CPlatformSrcInfo &info) const
       {
        CPlatformSrcInfo &tmp = info;
        tmp.name = ::std::string("[") + pname + ::std::string("]");
        std::vector<CPlatformSrcInfo>::const_iterator it = platforms.begin();
        for(; it!=platforms.end(); ++it)
           {
            if (tmp.merge(*it))
               {
                tmp.name = pname;
                return; // found exact platform
               }
           }

        // try to build 
        ::std::vector< std::string > platformNameParts;
        mbs::toolset::splitPlatformName( pname, platformNameParts );
        platformNameParts.insert( platformNameParts.begin(), std::string() );

        ::std::string curPlatformName;
        ::std::vector< std::string >::const_iterator pnpIt = platformNameParts.begin();
        for(; pnpIt != platformNameParts.end(); ++pnpIt)
           {
            if (!curPlatformName.empty())
               curPlatformName.append(1, '-');
            curPlatformName += *pnpIt;
            tmp.name = curPlatformName;
            std::vector<CPlatformSrcInfo>::const_iterator it = platforms.begin();
            for(; it!=platforms.end(); ++it)
               {
                tmp.merge(*it);
               }
           }

        tmp.name = pname;
        //CPlatformSrcInfo tmp;

        /*
        CPlatformSrcInfo &tmp = info;
        tmp.name = std::string("");
        std::vector<CPlatformSrcInfo>::const_iterator it = platforms.begin();
        for(; it!=platforms.end(); ++it)
           {
            tmp.merge(*it);
           }


        tmp.name = pname;
        it = platforms.begin();
        for(; it!=platforms.end(); ++it)
           {
            tmp.merge(*it);
           }
        */
        //info = tmp;
       }

    void split()
       {
        std::vector<CPlatformSrcInfo> tmp;
        std::vector<CPlatformSrcInfo>::const_iterator pit = platforms.begin();
        for(; pit!=platforms.end(); ++pit)
           pit->split(tmp);
        platforms.swap(tmp);
       }

    void merge()
       {
        std::vector<CPlatformSrcInfo> tmp; //   platforms;
        
        std::vector<CPlatformSrcInfo>::const_iterator pit = platforms.begin();
        for(; pit!=platforms.end(); ++pit)
           {
            std::vector<CPlatformSrcInfo>::iterator tmpIt = tmp.begin();
            for(; tmpIt!=tmp.end(); ++tmpIt)
               {
                if (tmpIt->merge(*pit)) break;
               }
            //if (tmpIt->merge(*pit)) break;
            if (tmpIt==tmp.end()) tmp.push_back(*pit);
           }
       }

    void normalize()
       {
        split();
        merge();
       }
}; // struct CProjectSrcInfo

inline 
::std::ostream& operator<<( ::std::ostream &os, const CProjectSrcInfo &i)
   {
    os<<"Description: "<<i.description<<"\n";
    os<<i.platforms<<"\n";
    return os;
   }

bool searchSrcInfo(const std::string &filename, CProjectSrcInfo &info);


struct CProjectSrcInfoCache
{
    struct CCachePair
       {
        bool             bExist;
        CProjectSrcInfo  info;
        CCachePair() : bExist(false), info() {}
        CCachePair(bool b) : bExist(b), info() {}
        CCachePair(bool b, const CProjectSrcInfo &i) : bExist(b), info(i) {}
        CCachePair(const CCachePair &p) : bExist(p.bExist), info(p.info) {}
        CCachePair& operator=(const CCachePair &p)
           {
            if (&p==this) return *this;
            bExist = p.bExist;
            info   = p.info;
           }
       };

    ::std::map< ::std::string, CCachePair>   cache;

    CProjectSrcInfoCache() : cache() {}
    CProjectSrcInfoCache(const CProjectSrcInfoCache &psic) : cache(psic.cache) {}
    CProjectSrcInfoCache& operator=(const CProjectSrcInfoCache &psic)
       {
        if (&psic==this) return *this;
        ::std::map< ::std::string, CCachePair>  new_cache(psic.cache);
        new_cache.swap(cache);
        return *this;
       }

    const CProjectSrcInfo* getSrcInfo(const std::string &filename)
       {
        typedef ::std::map< ::std::string, CCachePair>::const_iterator const_iterator;
        typedef ::std::map< ::std::string, CCachePair>::iterator             iterator;

        const_iterator it = cache.find(filename);
        if (it!=cache.end())
           {
            if (it->second.bExist)
               return &(it->second.info);
            return 0;
           }

        CProjectSrcInfo info;
        
        bool res = searchSrcInfo(filename, info);
        if (res)
           {
            info.buildKnownSlnconvFlags();
            ::std::pair <iterator, bool> insRes = cache.insert( ::std::make_pair(filename, CCachePair(true, info)) );
            return &(insRes.first->second.info);
           }
        else
           {
            cache.insert( ::std::make_pair(filename, CCachePair(false)) );
            return 0;
           }
       }

}; // struct CProjectSrcInfoCache



}; // namespace mbs


#endif /* MBS_SCANSRC_H */

