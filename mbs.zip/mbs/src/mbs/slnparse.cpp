// warning C4748: /GS can not protect parameters and local variables from local buffer overrun because optimizations are disabled in function
#if defined(_MSC_VER) && _MSC_VER>=1400
#pragma warning (disable : 4748)
#endif

#include "slnparse.h"

#ifndef BOOST_STRING_TRIM_HPP
    #include <boost/algorithm/string/trim.hpp>
#endif

#ifndef BOOST_STRING_CASE_CONV_HPP
    #include <boost/algorithm/string/case_conv.hpp>
#endif

#ifndef BOOST_STRING_PREDICATE_HPP
    #include <boost/algorithm/string/predicate.hpp>
#endif

#ifndef BOOST_RE_REGEX_HPP
    #include <boost/regex.hpp>
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#if !defined(_FSTREAM_) && !defined(_STLP_FSTREAM) && !defined(__STD_FSTREAM__) && !defined(_CPP_FSTREAM) && !defined(_GLIBCXX_FSTREAM)
    #include <fstream>
#endif



#include <marty/filename.h>

#ifdef USE_MARTY_NAMESPACE
using namespace ::marty;
#endif

#include "../mbs/vcproj.h"

#include <sixml/sixmlx.cxx>
#include "../common/6mlerr.h"

#include "util.h"
#include "mkutil.h"
#include "mak.h"

#include <boost/algorithm/string/trim.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <boost/regex.hpp>


#if !defined(_EXCEPTION_) && !defined(__EXCEPTION__) && !defined(_STLP_EXCEPTION) && !defined(__STD_EXCEPTION)
    #include <exception>
#endif

#if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
    #include <stdexcept>
#endif


//extern std::vector<std::string> excludeProjectPatterns;
extern int opDetailed;


namespace mbs{

using namespace boost::regex_constants;


bool parseMsvcSolution(const std::string &basePath, const std::string &slnFile, CMsvcSolutionInfo &info, const std::vector<std::string> &excludeProjectPatterns)
   {
    std::string fullName = filename::appendPath(basePath, slnFile);
    if (fullName.empty()) return false;
    std::ifstream in(fullName.c_str());
    if (!in) 
       {
        std::cout<<"Failed to open solution file - "<<fullName<<"\n";
        return false;
       }

    std::string sln;
    mbs::util::readFileAll(in, sln);
    if (!sln.empty() && sln[0]=='\xEF')
       sln.erase(0,4); // 0D 0A now as only 0A

    std::string slnVerMajor, slnVerMinor;
    boost::smatch slnSignMatches;
    std::string strSlnSignPat = "Microsoft Visual Studio Solution File, Format Version[[:space:]]*([[:digit:]]+)\\.([[:digit:]]*)[[:space:]]*(.*)";
    boost::regex slnSignPat( strSlnSignPat );
    if (boost::regex_match(sln, slnSignMatches, slnSignPat))
        {
         slnVerMajor = slnSignMatches[1];
         slnVerMinor = slnSignMatches[2];
         //std::cout<<"Solution file version: "<<slnVerMajor<<"."<<slnVerMinor<<"\n";
         //std::cout << matches[2] << std::endl;
        }
    else
        {
         std::cout<<"Failed to read solution file - no version information. Is it realy a MSVC solution file?\n";
         std::cout<<"Pattern: "<<strSlnSignPat<<"\n";
         return false;
        }
    

    //boost::regex pat( "^Subject: (Re: |Aw: )*(.*)" );
    //boost::regex projectPattern( "Project\\(\"\\{(.*)\\}\"\\)[[:space:]]=[[:space:]]\"(.*)\"[[:space:]],[[:space:]]\"(.*)\"[[:space:]],[[:space:]](.*)EndProject" );
    //boost::regex projectPattern( "Project\\(\"\\{(.*)\\}\"\\)[[:space:]]*=[[:space:]]*\"([^\"]*)\"[[:space:]]*,[[:space:]]*\"([^\"]*)\"[[:space:]]*,[[:space:]]*\\(\"\\{(.*)\\}\"\\)(.*)EndProject" );
    boost::regex projectPattern( "\\<Project\\(\"([^\"]*)\"\\)[[:space:]]*=[[:space:]]*\"([^\"]*)\"[[:space:]]*,[[:space:]]*\"([^\"]*)\"[[:space:]]*,[[:space:]]*\"([^\"]*)\"[[:space:]]*(.*?)[[:space:]]*EndProject\\>" );
    std::string::const_iterator start = sln.begin(), end = sln.end();
    boost::match_results<std::string::const_iterator> foundProjects;
    boost::match_flag_type flags = boost::match_default;

    while(boost::regex_search(start, end, foundProjects, projectPattern, flags))
       {
        //std::cout<<"---\n";

        std::string tmpProjectRelPAth = std::string(foundProjects[3].first, foundProjects[3].second);
        tmpProjectRelPAth = MARTY_FILENAME_NS makeCanonical ( MARTY_FILENAME_NS getFile(tmpProjectRelPAth)
                                                            , "/\\"
                                                            , '/'
                                                            );
        bool excluded = false;
        std::vector<std::string>::const_iterator exIt = excludeProjectPatterns.begin();
        for(; exIt!=excludeProjectPatterns.end(); ++exIt)
           {
            boost::regex pattern( *exIt );
            boost::smatch matches;
            if (boost::regex_match(tmpProjectRelPAth, matches, pattern))
               {
                excluded = true;
                if (opDetailed)
                   {
                    std::cout<<"Solution '"<<fullName<<"', project '"<<tmpProjectRelPAth<<"' -  excluded by pattern ["<<*exIt<<"]\n";
                   }
                break;
               }
           }

        if (excluded) 
           {
            // continue searching projects
            flags |= boost::match_prev_avail;
            flags |= boost::match_not_bob;
            //start = foundProjects[0].second;
            start = foundProjects.suffix().first;
            continue;
           }

        CMsvcProjectInfo prjInfo; // foundProjects[0] - all string matched
        // foundProjects[1] - unknown guid
        prjInfo.slnName         = std::string(foundProjects[2].first, foundProjects[2].second);
        prjInfo.slnRelativePath = std::string(foundProjects[3].first, foundProjects[3].second);
        prjInfo.uid             = std::string(foundProjects[4].first, foundProjects[4].second);
        std::string projectInnerInfo = ::boost::algorithm::trim_copy(std::string(foundProjects[5].first, foundProjects[5].second));
        // parse project here

        std::string::const_iterator piiStart = projectInnerInfo.begin(), piiEnd = projectInnerInfo.end();

        boost::match_results<std::string::const_iterator> foundDepsSection;
        boost::regex projectDependenciesSectionPattern( "\\<ProjectSection[[:space:]]*\\(ProjectDependencies\\)[[:space:]]*=[[:space:]]*postProject[[:space:]]*(.*?)[[:space:]]*EndProjectSection\\>" );
        if (boost::regex_search(piiStart, piiEnd, foundDepsSection, projectDependenciesSectionPattern, boost::match_default))
           {
            //std::cout<<"Deps Section: "<<std::string(foundDepsSection[1].first, foundDepsSection[1].second)<<"\n";
            std::string deps = std::string(foundDepsSection[1].first, foundDepsSection[1].second);
            
            boost::regex projectDependenciesPattern( "(\\{[^\\}]*\\})[[:space:]]*=[[:space:]]*(\\{[^\\}]*\\})" );
            std::string::const_iterator pdStart = deps.begin(), pdEnd = deps.end();
            boost::match_results<std::string::const_iterator> foundDeps;
            boost::match_flag_type depFlags = boost::match_default;
            while(boost::regex_search(pdStart, pdEnd, foundDeps, projectDependenciesPattern, depFlags))
               {
                // XXX = XXX
                // [1]   [2]
                // ���������� �������� ����� � ������,���������� ������; ����� ������
                prjInfo.dependencies.push_back(std::string(foundDeps[2].first, foundDeps[2].second));
                /*
                std::cout<<"---\n";
                boost::match_results<std::string::const_iterator>::const_iterator it = foundDeps.begin();
                for(++it; it!=foundDeps.end(); ++it)
                   {
                    //std::cout<<"! "<<std::string(it->first, it->second)<<"\n";
                   }
                */
                // continue searching dependencies
                depFlags |= boost::match_prev_avail;
                depFlags |= boost::match_not_bob;
                pdStart = foundDeps.suffix().first;           
               }
            
           }
        //prjInfo.dependencies =
        /*
        boost::match_results<std::string::const_iterator>::const_iterator it = foundProjects.begin();
        for(++it; it!=foundProjects.end(); ++it)
           {
            std::cout<<"! "<<std::string(it->first, it->second)<<"\n";
           }
        */
        info.projects[prjInfo.uid] = prjInfo;

        // continue searching projects
        flags |= boost::match_prev_avail;
        flags |= boost::match_not_bob;
        //start = foundProjects[0].second;
        start = foundProjects.suffix().first;
       }

/*
    GlobalSection(SolutionConfigurationPlatforms) = preSolution
        Debug|Win32 = Debug|Win32
        Release|Win32 = Release|Win32
        Unicode Debug|Win32 = Unicode Debug|Win32
        Unicode Release|Win32 = Unicode Release|Win32
    EndGlobalSection
*/

    boost::regex configPlatformsPattern( "\\<GlobalSection[[:space:]]*\\(SolutionConfigurationPlatforms\\)[[:space:]]*=[[:space:]]*preSolution[[:space:]]*(.*?)[[:space:]]*EndGlobalSection\\>" );
    boost::match_results<std::string::const_iterator> foundConfigPlatforms;
    start = sln.begin(), end = sln.end();
    if (boost::regex_search(start, end, foundConfigPlatforms, configPlatformsPattern, boost::match_default))
       {
        //std::cout<<"ConfiPlatforms: "<<std::string(foundConfigPlatforms[1].first, foundConfigPlatforms[1].second)<<"\n";
        std::string configPlatformsInfo = std::string(foundConfigPlatforms[1].first, foundConfigPlatforms[1].second);
        boost::regex singleConfigPlatformPattern( "^[[:space:]]*(.*?)[[:space:]]*\\|[[:space:]]*(.*?)[[:space:]]*=[[:space:]]*(.*?)[[:space:]]*\\|[[:space:]]*(.*?)[[:space:]]*$" );
        std::string::const_iterator cpStart = configPlatformsInfo.begin(), cpEnd = configPlatformsInfo.end();
        boost::match_results<std::string::const_iterator> foundSingleConfigPlatform;
        boost::match_flag_type cpFlags = boost::match_default;
        while(boost::regex_search(cpStart, cpEnd, foundSingleConfigPlatform, singleConfigPlatformPattern, cpFlags))
           {
            /*
            std::cout<<"---\n";
            boost::match_results<std::string::const_iterator>::const_iterator it = foundSingleConfigPlatform.begin();
            for(++it; it!=foundSingleConfigPlatform.end(); ++it)
               {
                std::cout<<"! "<<std::string(it->first, it->second)<<"\n";
               }
            */
            // Configurations are in form Name|Platfrom = Name|Platfrom
            std::string name     = std::string(foundSingleConfigPlatform[1].first, foundSingleConfigPlatform[1].second);
            std::string platform = std::string(foundSingleConfigPlatform[2].first, foundSingleConfigPlatform[2].second);
            platform = ::boost::algorithm::to_lower_copy(platform);
            /*
            if (platform=="win32")
               {
                info
               }
            */
            info.platformConfigurations[platform].push_back(name);
            // continue searching platforms
            cpFlags |= boost::match_prev_avail;
            cpFlags |= boost::match_not_bob;
            cpStart = foundSingleConfigPlatform.suffix().first;
           }

       }
      


/*
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "test01", "test01.vcproj", "{220CF262-FB62-4095-9D9A-1C15FE317D00}"
    ProjectSection(ProjectDependencies) = postProject
        {2AEA4690-E44F-4239-A83F-DDFD1A2CA902} = {2AEA4690-E44F-4239-A83F-DDFD1A2CA902}
    EndProjectSection
EndProject
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "test02", "test02.vcproj", "{2AEA4690-E44F-4239-A83F-DDFD1A2CA902}"
EndProject
*/
    // std::string line;
    // boost::regex pat( "^Subject: (Re: |Aw: )*(.*)" );
    //  
    // while (std::cin)
    //    {
    //     boost::smatch matches;
    //     if (boost::regex_match(line, matches, pat))
    //         std::cout << matches[2] << std::endl;
    //    }


    // reading vcproj'ects

    //CMsvcSolutionInfo &info
    // struct CMsvcSolutionInfo
    // {
    //     std::map<std::string, std::vector<std::string> >     platformConfigurations;
    //     std::map<std::string, CMsvcProjectInfo >             projects;
    //std::string fullName = filename::appendPath(basePath, slnFile);
    std::string prjRootPath = filename::getPath(fullName);

    std::map<std::string, CMsvcProjectInfo >  projects;
    std::map<std::string, CMsvcProjectInfo >::iterator prjIt = info.projects.begin();
    for(; prjIt!=info.projects.end(); ++prjIt)
       {
        std::string prjFile = filename::appendPath(prjRootPath, filename::makeCanonical(prjIt->second.slnRelativePath));
        //slnRelativePath
        //std::cout<<"reading "<<prjFile<<"\n";
        if (prjFile.empty())
           {
            std::cout<<"Invalid (empty) project file name, project skipped\n";
            continue;
           }

        
        std::string errText;
        bool fErr = false;
        mbs::CMsvcProjectFile conf;
        try{
            sixml::serializer::load_xml( prjFile.c_str(), conf, "VisualStudioProject");
           }
        CATCH_6ML_ERRORS(fErr, errText)
        /*
        catch(...)
           {
            std::cout<<"Failed to read "<<prjFile<<" project file, project skipped\n";
            continue;
           }
        */
        if (fErr)
           {
            //std::cout<<"Current directory: "<<getCurrentDirectory()<<"\n";
            std::cout<<"Failed to read "<<prjFile<<"' project file: "<<errText<<"\n";
            std::cout<<"Project skipped\n";    
            continue;
           }



        std::vector<CMsvcProjectConfigurationInfo>::iterator prjConfIt = conf.Configurations.begin();
        for(; prjConfIt!=conf.Configurations.end(); ++prjConfIt)
           {
            std::string confName, confPlatform;
            boost::smatch confNamePlatformMatches;
            std::string strNamePlatformPat = "(.*)\\|(.*)";
            boost::regex namePlatformPat( strNamePlatformPat );
            if (boost::regex_match(prjConfIt->Name, confNamePlatformMatches, namePlatformPat))
                {
                 prjConfIt->NameOnly      = confNamePlatformMatches[1];
                 prjConfIt->PlatformOnly  = confNamePlatformMatches[2];
                }
           }


        CMsvcProjectInfo prjInfo(prjIt->second);

        //prjIt->second
        prjInfo.prjName  = conf.Name;
        //prjIt->second
        prjInfo.prjUid   = conf.ProjectGUID;
        prjInfo.prjConfigurations = conf.Configurations;
        conf.getFileListEx(_T("Source Files")        , prjInfo.prjSourceFiles   );
        conf.getFileListEx(_T("Header Files")        , prjInfo.prjHeaderFiles   );
        conf.getFileListEx(_T("Generated Files")     , prjInfo.prjGeneratedFiles);
        conf.getFileListEx(_T("Form Files")          , prjInfo.prjFormFiles     );
        conf.getFileListEx(_T("wxFormBuilder Files") , prjInfo.prjFormFiles     );
        prjInfo.buildSourcesIncludedList();
        projects[prjIt->first] = prjInfo;       
       }
    info.projects.swap(projects);

    return true;
   }


//-----------------------------------------------------------------------------

bool makeMakefileInfo(const CMsvcProjectInfo &info, CMakefileInfo &mi)
   {
    using ::boost::algorithm::to_lower_copy;
    using ::boost::algorithm::starts_with;

    //mi.relativePath = filename::getPath(filename::makeCanonical(info.slnRelativePath));
    mi.orgRelativePath = info.slnRelativePath;
    mi.relativePath    = filename::getPathName(info.slnRelativePath);

    mi.targetName   = info.prjName;

    mi.sourceFiles    = info.prjSourceFiles   ;
    mi.headerFiles    = info.prjHeaderFiles   ;
    mi.generatedFiles = info.prjGeneratedFiles;
    mi.formFiles      = info.prjFormFiles     ;
    
    //mi.sourceFiles  = info.prjSourceFiles;

    std::vector<CMsvcProjectConfigurationInfo>::const_iterator confIt = info.prjConfigurations.begin();
    for(; confIt!=info.prjConfigurations.end(); ++confIt)
       {
        if (!starts_with(to_lower_copy(confIt->PlatformOnly), _T("win")))
           continue;

        CMakefileTargetConfigurationInfo  targetConf;

        /*
        targetConf.name = to_lower_copy(confIt->NameOnly);
        std::transform(targetConf.name.begin(), targetConf.name.end(), targetConf.name.begin(), util::CSpaceTransformator());
        */
        targetConf.name = mbs::util::makeCanonicalConfigurationName(confIt->NameOnly);
        targetConf.OutputDirectory       = confIt->OutputDirectory;
        targetConf.IntermediateDirectory = confIt->IntermediateDirectory;

        if (confIt->ConfigurationType==CONFIGURATION_TYPE_OUTPUT_EXE)      targetConf.outputType = "exe";
        else if (confIt->ConfigurationType==CONFIGURATION_TYPE_OUTPUT_DLL) targetConf.outputType = "dll";
        else if (confIt->ConfigurationType==CONFIGURATION_TYPE_OUTPUT_LIB) targetConf.outputType = "lib";
        else                                                               targetConf.outputType = "unknown-output-type";

        targetConf.subsystem = SUBSYSTEM_CONSOLE;

        const CMsvcToolInfo* pLinkerTool = confIt->getToolInfo("VCLinkerTool");
        if (pLinkerTool)
           {
            if (!pLinkerTool->ModuleDefinitionFile.empty())
               targetConf.moduleDefinitionFile = pLinkerTool->ModuleDefinitionFile;
            targetConf.subsystem = pLinkerTool->SubSystem;
           }

        mi.configurations.push_back(targetConf);
       }

    // std::string              relativePath;
    // std::string              targetName;
    // std::vector<std::string> configurations;
    // std::vector<std::string> sourceFiles;

    return true;
   }

//-----------------------------------------------------------------------------
bool makeMakefileSolution(const CMsvcSolutionInfo &sol, CMakefileSolutionInfo &mkSol)
   {
    std::vector<std::string> orderedProjects;
    makeValidDependencyOrder(sol.projects, orderedProjects);

    std::vector<std::string>::const_iterator opIt = orderedProjects.begin();
    for(; opIt!=orderedProjects.end(); ++opIt)
       {
        std::map<std::string, CMsvcProjectInfo >::const_iterator pIt = sol.projects.find(*opIt);
        if (pIt==sol.projects.end()) continue;

        try{
            CMakefileInfo mkInfo;
            if (!makeMakefileInfo( pIt->second, mkInfo)) throw ::std::runtime_error("need continue");

            //CMakefileInfo mkInfo( pIt->second );
            std::vector<std::string>::const_iterator depIt = pIt->second.dependencies.begin();
            for(; depIt!=pIt->second.dependencies.end(); ++depIt)
               { // iterate trough dependecies GUIDs
                //depIt
                std::map<std::string, CMsvcProjectInfo >::const_iterator depPrjIt = sol.projects.find(*depIt);
                if (depPrjIt==sol.projects.end())
                   continue;
                mkInfo.dependencies.push_back(depPrjIt->second.slnRelativePath);
               }
    
            mkSol.makefiles.push_back(mkInfo);
           }
        catch(...)
           {
            continue;
           }
        //if (!makeMakefileInfo(pIt->second, mkInfo))
        //   continue;

        // std::vector<std::string>::const_iterator depIt = pIt->second.dependencies.begin();
        // for(; depIt!=pIt->second.dependencies.end(); ++depIt)
        //    { // iterate trough dependecies GUIDs
        //     //depIt
        //     std::map<std::string, CMsvcProjectInfo >::const_iterator depPrjIt = sol.projects.find(*depIt);
        //     if (depPrjIt==sol.projects.end()) continue;
        //     mkInfo.dependencies.push_back(depPrjIt->second.slnRelativePath);
        //    }
        //  
        // mkSol.makefiles.push_back(mkInfo);
       }   
    return true;
   }


}; // namespace mbs
