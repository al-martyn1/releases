#include "prjInfo.h"



namespace mbs
{
namespace doc
{




::std::ostream& generateHtmlSummary( ::std::ostream &os, const ::std::vector<mbs::doc::CSolutionInfo> &solutionsInfo)
   {
    int id = 0;
    // small help http://faqs.org.ru/progr/web_lang/html_faq3.htm
    // more info http://www.htmlbook.ru/css/cursor.html
    // cursor:hand cursor:pointer
    // file associations in Linux http://ubuntuguide.org/wiki/Ubuntu_Feisty#How_to_associate_Adobe_Reader_with_files_in_Nautilus
    // styles are from W:\mantis\www\kb\skins\common\ModernKB.css
/* this works
<SPAN class=boxtoggle>[<A id=tbatog1 onclick="return ToggleBox('1')" href="/">+</A>]</SPAN> 
<SPAN class=boxtitle>Box title</SPAN><BR>
<DIV class=boxbody id=tbdtog1 style="DISPLAY: none">Box body</DIV>
*/
    os<<"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n"
        "<HTML>\n<HEAD>\n<TITLE>Projects summary information</TITLE>\n"
                        "<META http-equiv=Content-Type content=\"text/html; charset=utf-8\"/>\n"
        "<SCRIPT type=\"text/javascript\">\n"
        "<!--\n\
function ToggleBox(id)\n\
{\n\
    el=document.getElementById('tbdtog' + id);\n\
    anch=document.getElementById('tbatog' + id);\n\
    if (anch.innerText==\'-\')\n\
       {\n\
        el.style.display=\"none\";\n\
        anch.innerText = \'+\';\n\
       }\n\
    else\n\
       {\n\
        el.style.display=\"block\";\n\
        anch.innerText = \'-\';\n\
       }\n\
    return false;\n\
}\n\n"
"\
function getElementsByClass(node, cls, tag)\n\
{\n\
    var resElements = new Array();\n\
    var tags = node.getElementsByTagName(tag);\n\
    var size = tags.length;\n\
    for(i=0, j=0; i<size; i++)\n\
       {\n\
        if (tags[i].className==cls)\n\
           {\n\
            resElements[j] = tags[i];\n\
            j++;\n\
           }\n\
       }\n\
    \n\
    return resElements;\n\
}\n\
\n\
function expandAll(node)\n\
{\n\
    var anchors = getElementsByClass(node, 'togglemark', 'A');\n\
    var size = anchors.length;\n\
    \n\
    for(i=0; i<size; i++)\n\
       {\n\
        anchors[i].innerText = '-';\n\
       }\n\
\n\
    var divs = getElementsByClass(document, 'boxbody', 'DIV');\n\
    size = divs.length;\n\
    for(i=0; i<size; i++)\n\
       {\n\
        divs[i].style.display='block';\n\
       }\n\
    return false;\n\
}\n\
\n\
function collapseAll(node)\n\
{\n\
    var anchors = getElementsByClass(node, 'togglemark', 'A');\n\
    var size = anchors.length;\n\
    for(i=0; i<size; i++)\n\
       {\n\
        anchors[i].innerText = '+';\n\
       }\n\
\n\
    var divs = getElementsByClass(document, 'boxbody', 'DIV');\n\
    size = divs.length;\n\
    for(i=0; i<size; i++)\n\
       {\n\
        divs[i].style.display='none';\n\
       }\n\
    return false;\n\
}\n\
"
        "//-->\n"
        "</SCRIPT>\n"
        "<STYLE>\n"
        "<!--\n"
"body { font-family: Verdana, Arial, sans-serif; font-size: 10pt; color: black; margin: 0.2cm; padding: 0; }\n"
"ul, p{ margin: 0.2cm; padding: 0; }\n"
"ul{ margin-right: 0.1cm; margin-top: 0.1cm; margin-bottom: 0.1cm; margin-left: 0.6cm; }\n"
"h1,h2, h3, h4 { font-weight: bold; border: solid 1px #CFE5F0; background-color: #F7F7FA; padding: 0pt 2pt 0pt 2pt; padding: 0pt 2pt 0pt 0pt; margin: 0.8cm 0.0cm 0.3cm 0cm;}\n"
"h1 { font-size: 14pt; } h2 { font-size: 12pt; } h3 { font-size: 10pt; border: solid 1px #FFD5BF; } h4 { font-size: 10pt; } \n"
"SPAN.boxtoggle, SPAN.boxtitle { cursor:pointer; }\n"
"a { text-decoration: none; color:#65A7CB; cursor:pointer; }\n"
"a:visited { text-decoration: none; color:#65A7CB; }\n"
"a:hover { text-decoration: none; color:#65A7CB; text-decoration:underline; }\n"
"a.external { text-decoration: none; }\n"
"a.external:hover { text-decoration: underline; }\n"
"a.new { text-decoration: none; }\n"
"span.boxtitle{ font-weight: bold; }\n"
"div.boxbody{ border: none; margin-right: 0.1cm; margin-top: 0.1cm; margin-bottom: 0.1cm; margin-left: 0.6cm; }\n"
        "//-->\n"
        "</STYLE>\n"
        "</HEAD>\n"
        "<BODY>\n"
        "<P>\n"
        "<A onclick=\"return collapseAll(document)\">Collapse All</A>\n| "
        "<A onclick=\"return expandAll(document)\">Expand All</A>\n"
        "</P>\n"
        ;
    os<<CHtmlStartBox(id, ::std::string("Note for IE users"), false )
      <<"<P>To permanently allow active content in local files set parameter \"Allow active content in local files\" in Settings/Additional and restart IE</P>"
      <<CHtmlEndBox()<<"\n";

    ::std::vector<mbs::doc::CSolutionInfo>::const_iterator slnIt = solutionsInfo.begin();
    for(; slnIt!=solutionsInfo.end(); ++slnIt)
       {
        os<<"\n<H3>Solution: "<< /* "Solution: "<< */ slnIt->name <<" ("<<CHtmlLink(slnIt->solutionFile, ltrimDots(slnIt->solutionFile))<<")</H3>\n";
        os<<CHtmlStartBox(id, ::std::string("Files for building solution"), ::std::string("ffbs"), false)<<"\n";
        
        CSlnAltersHtmlPrint slnAltersHtmlPrint(os, id);
        ::std::for_each(slnIt->alternateSolutionFiles.begin(), slnIt->alternateSolutionFiles.end(), slnAltersHtmlPrint);
        os<<CHtmlEndBox()<<"\n";

        os<<CHtmlStartBox(id, ::std::string("Projects"), ::std::string("slnprojects"), true)<<"\n";


        ::std::map< ::std::string, CProjectInfo >::const_iterator prjIt = slnIt->projects.begin();
        for(; prjIt!=slnIt->projects.end(); ++prjIt)
           {
            os<<"\n<H4>Project: "<< prjIt->second.name <<" ("<<CHtmlLink(prjIt->second.projectFile, ltrimDots(prjIt->second.projectFile))<<")</H4>\n";

            if (!prjIt->second.description.empty())
               {
                ::std::string note = prjIt->second.description;
                os<<CHtmlStartBox(id, ::std::string("Description"), ::std::string("prjdescription"), !note.empty())<<"\n";
                if (note.empty()) note = "No description";
                os<<"<P>"<<note<<"</P>\n";
                os<<CHtmlEndBox()<<"\n";
               }

            os<<CHtmlStartBox(id, ::std::string("Source files"), ::std::string("prjsources"), false)<<"\n";
            os<<"<UL>\n";

            ::std::string entrySrc = ltrimDots(prjIt->second.entrySource);
            //::std::vector< ::std::string >::const_iterator srcIt = prjIt->second.sources.begin();
            ::std::vector< CProjectFile >::const_iterator srcIt = prjIt->second.sources.begin();
            
            for(; srcIt!=prjIt->second.sources.end(); ++srcIt)
               {
                ::std::string src = ltrimDots(srcIt->filename);
                bool fBold = entrySrc==src;
                if (prjIt->second.sources.size()<=1) fBold = true; // force bold single file - it's a project entry
                os<<"<LI>"<<(fBold?"<B>":"")<<CHtmlLink(srcIt->filename, src)<<(fBold?"</B>":"");
                ::std::vector< tstring > incConfigurations;
                srcIt->getIncludedConfigurations(incConfigurations);
                if (incConfigurations.empty())
                   {
                    os<<" <I>All configurations</I>";
                   }
                else
                   {
                    os<<" <I>";
                    os<<"Conigurations: ";
                    ::std::vector< tstring >::const_iterator it = incConfigurations.begin();
                    for(; it!=incConfigurations.end(); ++it)
                       {
                        if (it!=incConfigurations.begin()) os<<", ";
                        os<<*it;
                       }
                    os<<"</I>";
                   }

                if (!srcIt->buildTool.empty())
                   {
                    os<<" ["<<srcIt->buildTool<<"'ing "<<srcIt->dependendOn<<"]";
                   }
                // newSourceFile.includedConfigurations.push_back(*confIt);
                // newSourceFile.dependendOn = hfIt->filename;
                // newSourceFile.buildTool = "moc";
                // sourceFiles.push_back(newSourceFile);

                os<<"</LI>\n";
               }
            os<<"</UL>\n";
            os<<CHtmlEndBox()<<"\n";
           }

/*
    ::std::string                               name;
    ::std::string                               description;
    ::std::string                               projectFile; // msvc name
    ::std::map< ::std::string, ::std::string >  alternateProjectFiles;
    ::std::string                               entrySource;
                                       
    ::std::vector< ::std::string >              sources;
*/
 
        os<<CHtmlEndBox()<<"\n";

       }
    os<<"</BODY>\n</HTML>";

    return os;
   }


}; // namespace doc
}; // namespace mbs
