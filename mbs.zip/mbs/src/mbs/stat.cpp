#ifndef _WIN32
    #define _WIN32
#endif

#ifndef WIN32
    #define WIN32
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_FSTREAM_) && !defined(_STLP_FSTREAM) && !defined(__STD_FSTREAM__) && !defined(_CPP_FSTREAM) && !defined(_GLIBCXX_FSTREAM)
    #include <fstream>
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif


#if !defined(_IOMANIP_) && !defined(_STLP_IOMANIP) && !defined(__STD_IOMANIP__) && !defined(_CPP_IOMANIP) && !defined(_GLIBCXX_IOMANIP)
    #include <iomanip>
#endif


#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#ifndef MARTY_FILESYS_H
    #include <marty/filesys.h>
#endif

#ifndef MARTY_WINAPI_H
    #include <marty/winapi.h>
#endif

#include "../scanner/idlScanner.h"
#include "../scanner/utils.h"
#include "text-fmt.h"
#include "prjInfo.h"


using filename::makeCanonical;
using filename::getName;
using filename::getFile;
using filename::getPath;
using filename::getExtention;
using filename::appendExtention;
using filename::appendPath;
using filename::changeExtention;
using filename::changePathChars;
using filename::changePathCharsCopy;


::std::ostream& formatSize( ::std::ostream &os, const SIZE_T &size)
   {
    char buf[512];
    const SIZE_T mb = 1024*1024;
    if (size>1024)
       {
        if (size>(1024*1024))
           {
            wsprintf(buf, "%d %03d Kb (%d bytes)", (unsigned)size/mb, (unsigned)(size%mb)/1024, size );
           }
        else
           {
            wsprintf(buf, "%d Kb (%d bytes)", (unsigned)size/1024, (unsigned)size );
           }
       }
    else
       {
        wsprintf(buf, "%d bytes", (unsigned)size );
       }
    os<<buf;
    return os;
   }


::std::vector< ::std::string >
trim_vector_copy(const ::std::vector< ::std::string > &v)
   {
    ::std::vector< ::std::string > res;
    ::std::vector< ::std::string >::const_iterator it = v.begin();
    for(; it!=v.end(); ++it)
       {
        ::std::string tmpStr = boost::algorithm::trim_copy(*it);
        if (tmpStr.empty()) continue;
        res.push_back(tmpStr);
       }
    return res;   
   }


struct CStatPrescanFindData
{
    std::vector<std::string> &dirList;
    int                      &hitCount;
    bool                     &hasSrcDir;
    bool                     &hasIncDir;

    CStatPrescanFindData(std::vector<std::string> &dl, int &hc, bool &hsd, bool &hid) : dirList(dl), hitCount(hc), hasSrcDir(hsd), hasIncDir(hid) {}

    bool operator()(const std::string &path, const WIN32_FIND_DATA &fndData)
       {
        if (!(fndData.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY))
           return true;

        std::string name = fndData.cFileName;
        if (name.empty())
           return true;

        if (name=="." || name=="..")
           return true;

        if (MARTY_FILENAME_NS matchMaskI( name, "src"))
           hasSrcDir = true;
        if (MARTY_FILENAME_NS matchMaskI( name, "build"))
           hitCount++;
        if (MARTY_FILENAME_NS matchMaskI( name, "include"))
           {
            hasIncDir = true;
            hitCount++;
           }

        dirList.push_back(name);
        return true;
       }
};

std::vector<std::string> tmpStringVector;

struct CStatScanData
{
    std::vector<std::string> &dirList;
    std::vector<std::string> &cppList;
    std::vector<std::string> &hList;
    std::vector<std::string> &cidlList;

    protected:
    CStatScanData()
                 : dirList(tmpStringVector)
                 , cppList(tmpStringVector)
                 , hList(tmpStringVector)
                 , cidlList(tmpStringVector)
                 {}

    public:
    CStatScanData( std::vector<std::string> &dl
                 , std::vector<std::string> &cl
                 , std::vector<std::string> &hl
                 , std::vector<std::string> &cdl
                 ) 
                 : dirList(dl)
                 , cppList(cl)
                 , hList(hl)
                 , cidlList(cdl)
                 {}

    bool operator()(const std::string &path, const WIN32_FIND_DATA &fndData)
       {
        //if (!(fndData.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY))
        //   return true;

        //std::string name = fndData.cFileName;
        std::string name(fndData.cFileName);
        //std::cout<<"name: "<<name<<"\n";

        if (name.empty())
           return true;

        if (name=="." || name=="..")
           return true;

        ::std::string fullName = makeCanonical(appendPath(path, name));
        //std::cout<<"name: "<<fullName<<"\n";

        if (MARTY_FILENAME_NS matchMaskI( name, "*.c"))
           {
            cppList.push_back(fullName);
           }
        else if (MARTY_FILENAME_NS matchMaskI( name, "*.cpp"))
           {
            cppList.push_back(fullName);
           }
        else if (MARTY_FILENAME_NS matchMaskI( name, "*.cxx"))
           {
            cppList.push_back(fullName);
           }
        else if (MARTY_FILENAME_NS matchMaskI( name, "*.h"))
           {
            hList.push_back(fullName);
           }
        else if (MARTY_FILENAME_NS matchMaskI( name, "*.hpp"))
           {
            hList.push_back(fullName);
           }
        else if (MARTY_FILENAME_NS matchMaskI( name, "*.cidl"))
           {
            cidlList.push_back(fullName);
           }

        return true;
       }
};


void makeSrcStat( const std::string &path, const std::string &saveTo)
   {
    std::vector<std::string> pathList;
    pathList.push_back(path);

    std::vector<std::string> dirs;
    int                      hitCount   = 0;
    bool                     hasSrcDir  = false;
    bool                     hasIncDir  = false;

    CStatPrescanFindData dirsScanner(dirs, hitCount, hasSrcDir, hasIncDir);
    DWORD findRes = ::winapi::findFile( pathList, _T("*"), dirsScanner, false);

    if (!hasSrcDir /*  || hitCount<2 */ )
       {
        std::cout<<"Error: can't build source statistics: there is no 'src' subdirectory\n";
        //if (hasSrcDir)
        return;
       }

    pathList.clear();
    pathList.push_back(makeCanonical(appendPath(path, "include")));
    pathList.push_back(makeCanonical(appendPath(path, "src")));

    std::vector<std::string> dirList;
    std::vector<std::string> cppList;
    std::vector<std::string> hList;
    std::vector<std::string> cidlList;

    CStatScanData statFiles( dirList
                           , cppList
                           , hList
                           , cidlList
                           );
    findRes = ::winapi::findFile( pathList, _T("*"), statFiles, true);

    //::std::cout<<"C++ sources:\n";
    std::vector<std::string>::const_iterator it = cppList.begin();
    for(; it!=cppList.end(); ++it)
       {
        //std::cout<<*it<<"\n";
       }

    //::std::cout<<"C++ headers:\n";
    // std::vector<std::string>::const_iterator 
    it = hList.begin();
    for(; it!=hList.end(); ++it)
       {
        //std::cout<<*it<<"\n";
       }

    //::std::cout<<"CIDL sources:\n";
    //std::vector<std::string>::const_iterator 
    it = cidlList.begin();
    for(; it!=cidlList.end(); ++it)
       {
        //std::cout<<*it<<"\n";
       }


    std::ofstream saveToStream(saveTo.c_str());

    //saveToStream<<"\n";

    std::set< ::std::string > cidlFileSet;

    SIZE_T cidlSize = 0;
    SIZE_T cidlCount = 0;
    it = cidlList.begin();
    for(; it!=cidlList.end(); ++it)
       {
        cidlFileSet.insert(*it);
        cidlCount++;
        HANDLE hFile = CreateFile( it->c_str(), GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0 );
        if (hFile==INVALID_HANDLE_VALUE)
           continue;
        LARGE_INTEGER li; 
        if (!GetFileSizeEx(hFile, &li))
           continue;
        cidlSize += (SIZE_T)li.QuadPart;
        CloseHandle(hFile);
       }

    SIZE_T headersGeneratedSize = 0;
    SIZE_T headersSize = 0;
    SIZE_T headersCount = 0;
    it = hList.begin();
    for(; it!=hList.end(); ++it)
       {
        //lFileSet.insert(*it);
        headersCount ++;
        HANDLE hFile = CreateFile( it->c_str(), GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0 );
        if (hFile==INVALID_HANDLE_VALUE)
           continue;
        LARGE_INTEGER li; 
        if (!GetFileSizeEx(hFile, &li))
           continue;
        headersSize += (SIZE_T)li.QuadPart;
        CloseHandle(hFile);
       }

    SIZE_T sourceGeneratedSize  = 0;
    SIZE_T sourceSize  = 0;
    SIZE_T sourceCount = 0;
    it = cppList.begin();
    for(; it!=cppList.end(); ++it)
       {
        //lFileSet.insert(*it);
        sourceCount ++;
        HANDLE hWin32File = CreateFile( it->c_str(), GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0 );
        if (hWin32File==INVALID_HANDLE_VALUE)
           continue;
        LARGE_INTEGER li; 
        if (!GetFileSizeEx(hWin32File, &li))
           continue;
        sourceSize += (SIZE_T)li.QuadPart;
        CloseHandle(hWin32File);

        CIncludeFinderImpl       includeFinder;
        std::vector<CScannerEvent> scannerEvents;
        std::vector<std::string>   processedFiles;
    
        CScannerErrorContext errContext;
        
        CC2IdlScanner scanner(scannerEvents, processedFiles, *it);
        scanner.setDefaultPreprocessor();
        scanner.getPreprocessor()->setIncludeFinder(&includeFinder);
        scanner.setErrorContext(&errContext);
    
        scanner.getPreprocessor()->options.parseIncludes      = false;
        scanner.getPreprocessor()->options.parseUserIncludes  = false;
        scanner.getPreprocessor()->options.parseIfdef         = false;
        scanner.getPreprocessor()->options.parseDefines       = false;
    
        MARTY_FILESYSTEM_NS handle_t hFile = MARTY_FILESYSTEM_NS openFile(*it, MARTY_FILESYSTEM_NS o_rdonly );
        if (hFile==MARTY_FILESYSTEM_NS hInvalidHandle)
           {
            //std::cout<<"SSI: 2, "<<filename<<"\n";
            std::cout<<"Failed to scan "<<*it<<" - can't open file\n";
            continue;
           }
    
        char buf[4096];
        int readed = MARTY_FILESYSTEM_NS readFile(hFile, buf, sizeof(buf));
        while(readed>0)
           {
            for(int i=0; i<readed; ++i)
               {
                //int err = ;
                unsigned char ch = (unsigned char)buf[i];
                if (ch==0xFF) ch = 0xDF; // bug with russian small YA - switch to capital YA
    
                if (!scanner.put(ch))
                   {
                    std::cout<<"Failed to scan "<<*it<<"\n";
                    std::cout<<"Error: "<<scanner.getError()<<" - "<<scanner.getErrorStr()<<"\n";
                    std::cout<<errContext.formatError(scanner.getError())<<"\n";
                    break;
                   }
               }
            readed = MARTY_FILESYSTEM_NS readFile(hFile, buf, sizeof(buf));
           }
    
        scanner.finalize();
    
        if (!scannerEvents.empty() && scannerEvents.back().token==LT_END) 
           {
            scannerEvents.erase(scannerEvents.end()-1);
           }

        std::vector<CScannerEvent>::const_iterator seIt = scannerEvents.begin();
        for(; seIt!=scannerEvents.end(); ++seIt)
           {
            if (!LT_IS_COMMENT(seIt->token)) continue;
            //std::string text = seIt->text;
            std::string comment = seIt->token==LT_COMMENT_SINGLE_LINE ? scanner::utils::prepareSinglelineComment(seIt->text) : scanner::utils::prepareMultilineComment(seIt->text);
            int tmp = scanner::utils::isSpecialComment(comment, seIt->token==LT_COMMENT_SINGLE_LINE);
            if (tmp==scanner::utils::comentTypeNone) continue; // return false;
    
            // simple heuristic
            if (comment.find("\\project", 0)==std::string::npos && comment.find("@project", 0)==std::string::npos) continue;
    
            ::std::vector< ::std::pair< ::std::string, ::std::vector< ::std::string> > > pairs;
            scanner::utils::splitStringDoxyStyle(comment, pairs);
    
            //CPlatformSrcInfo       platformInfo;
            //CConfigurationSrcInfo  configurationInfo;
    
            ::std::vector< ::std::pair< ::std::string, ::std::vector< ::std::string> > >::const_iterator pit = pairs.begin();
            for(; pit!=pairs.end(); ++pit)
               {
                if (pit->first==::std::string("\\project") || pit->first==::std::string("@project"))
                   {
                    /*
                    std::string description = scanner::utils::mergeVectorToString(pit->second);
                    while(!description.empty() && info.description[0]=='\n')
                       {
                        description.erase(0, 1);
                       }
                    */

                    txt::util::CFormatOptions fmtOpts;
                    fmtOpts.globalIndent    = 4;
                    fmtOpts.firstLineIndent = 0;
                    fmtOpts.lineIndent      = 0;
                    fmtOpts.paraWidth       = 70;
                    fmtOpts.formatType      = txt::util::ftWidth;

                    std::string info = txt::util::formatText(fmtOpts, trim_vector_copy(pit->second));
                    std::string fileName = *it;
                    if (mbs::doc::startsWith( fileName, path ))
                       {
                        fileName.erase(0, path.size() );
                       }
                    if (!fileName.empty() && (fileName[0]=='/' || fileName[0]=='\\'))
                       fileName.erase(0, 1 );

                    //std::cout
                    saveToStream<<fileName<<"\n"<<info<<"\n";
                   }
               }    
           }
       }

    using ::std::setw;
    //saveToStream<< ::std::width(3);
    if (cidlCount)
    //std::cout
       { saveToStream<<"Total idl's  : "<<setw(3)<<cidlCount<<", size: "; formatSize(saveToStream, cidlSize)<<"\n"; }
    //std::cout
    if (headersCount)
       {saveToStream<<"Total headers: "<<setw(3)<<headersCount<<", size: "; formatSize(saveToStream, headersSize)<<"\n"; }
    //std::cout
    if (sourceCount)
       { saveToStream<<"Total sources: "<<setw(3)<<sourceCount<<", size: "; formatSize(saveToStream, sourceSize)<<"\n"; }

    saveToStream<<"Total files  : "<<setw(3)<<(cidlCount + headersCount + sourceCount)<<", size: "; formatSize(saveToStream, cidlSize + headersSize + sourceSize)<<"\n";
    saveToStream<<"----------------------------------------------------------------------\n";
    
   }






