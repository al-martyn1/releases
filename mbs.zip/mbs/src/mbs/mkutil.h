#ifndef MBS_MKUTIL_H
#define MBS_MKUTIL_H


#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#if !defined(_SSTREAM_) && !defined(_STLP_SSTREAM) && !defined(__STD_SSTREAM__) && !defined(_CPP_SSTREAM) && !defined(_GLIBCXX_SSTREAM)
    #include <sstream>
#endif


#if !defined(_INC_STDLIB) && !defined(_STDLIB_H_) && !defined(_STDLIB_H)
    #include <stdlib.h>
#endif


#ifndef BOOST_STRING_TRIM_HPP
    #include <boost/algorithm/string/trim.hpp>
#endif

#ifndef BOOST_STRING_CASE_CONV_HPP
    #include <boost/algorithm/string/case_conv.hpp>
#endif

#ifndef BOOST_STRING_PREDICATE_HPP
    #include <boost/algorithm/string/predicate.hpp>
#endif

#ifndef BOOST_STRING_SPLIT_HPP
    #include <boost/algorithm/string/split.hpp>
#endif

#ifndef BOOST_RE_REGEX_HPP
    #include <boost/regex.hpp>
#endif

#include <marty/macroses.h>


#include "util.h"

namespace mbs
{


using ::marty::macro::changeDotsAndSlash;
using ::marty::macro::varsToMacroses;
using ::marty::macro::substMacroses;



//-----------------------------------------------------------------------------
bool getMacroText(const std::map<std::string, std::string> &macroses, const std::string &macroName, std::string *pMacroText);
bool getMacroText(const std::map<std::string, std::string> &macroses, const std::string &macroName, std::string &macroText);
bool macroExist(const std::map<std::string, std::string> &macroses, const std::string &macroName);
bool macroExistButEmpty(const std::map<std::string, std::string> &macroses, const std::string &macroName);

inline
std::string substHash(const std::string &str)
   {
    /*
    std::string res = str;
    //res.reserve(str.size());
    //bool wait

    for(std::string::iterator it = res.begin(); it!=res.end(); ++it)
       {
        if (*it=='#') *it = '$';
       }
    */
    bool waitHash = false;
    std::string res; res.reserve(str.size());
    for(std::string::const_iterator it = str.begin(); it!=str.end(); ++it)
       {
        if (waitHash)
           {
            if (*it=='#') res.append(1, *it);
            else          { res.append(1, '$'); res.append(1, *it); }
            waitHash = false;
           }
        else
           {
            if (*it=='#') waitHash = true;
            else          res.append(1, *it);
           }
       }

    return res;
   }

//-----------------------------------------------------------------------------
inline
std::string substMacrosesCB(std::map<std::string, std::string> macroses, const std::string &str)
   {
    macroses["SolutionName"] = "CodeBlocks";
    macroses["SOLUTIONNAME"] = "CODEBLOCKS";
    macroses["SOLUTION_NAME"] = "CodeBlocks";
    //$(PROJECT_NAME)
    //$(PROJECT_DIR)
    return substMacroses(macroses, str, false, false);
   }


inline 
std::string makeCodeBlocksPath( const std::string &dotsPath
                              , const std::map<std::string, std::string> &macroses
                              , const std::string &path
                              , char pathSep
                              )
   {

    using filename::makeCanonical;
    using filename::getName;
    using filename::getPath;
    using filename::getExtention;
    using filename::appendExtention;
    using filename::appendPath;
    using filename::changeExtention;
    using filename::changePathChars;
    using filename::changePathCharsCopy;

    std::string tmp = substHash(makeCanonical(appendPath(dotsPath, substMacrosesCB(macroses, path)), PATH_SEPARATORS, pathSep));
    //std::map<std::string, std::string> tmpMacroses;
    //tmpMacroses["SOLUTION_NAME"] = "CodeBlocks";
    //$(SOLUTION_NAME)
    //return appendPath("$(PROJECTDIR)", tmp, PATH_SEPARATORS, pathSep);
    //return tmp;
    return substMacrosesCB(macroses, tmp);
   }
//-----------------------------------------------------------------------------
inline
std::string makeMakCommands(const std::string &cmd)
   {
    std::string res; res.reserve(cmd.size());
    std::string::const_iterator it = cmd.begin();
    bool prevLF = false;
    for(; it!=cmd.end(); ++it)
       {
        if (*it=='\r') continue; // skip CR
        if (prevLF && (*it==' ' || *it=='\t')) continue; // skip leading whitespaces
        
        prevLF = false;
        
        if (*it=='\n') 
           {
            if (!res.empty())
               {
                res.append(1, *it);
                res.append(1, '\t');
               }
            prevLF = true;
           }
        else
           {
            res.append(1, *it);
           }
       }
    return substHash(res);
   }



inline
std::string makeDotsPath(const std::string &path, char pathSep, unsigned appendDotsNum, const std::string &appendToEnd = "")
   {
    std::vector< std::string > pathParts;
    filename::splitPath(path, pathParts);

    std::vector< std::string > dotsParts;

    std::vector< std::string >::const_iterator pit = pathParts.begin();
    for(; pit!=pathParts.end(); ++pit)
       {
        dotsParts.push_back("..");
       }

    for (unsigned i=0; i!=appendDotsNum; ++i)
       {
        dotsParts.push_back("..");
       }

    //if (dotsParts.size() > 3) DebugBreak();

    if (!appendToEnd.empty()) dotsParts.push_back(appendToEnd);
    return filename::mergePath(dotsParts, pathSep);
   }

// 256


}; // namespace mbs



#endif /* MBS_MKUTIL_H */

