#ifndef MBS_TEXT_FMT_H
#define MBS_TEXT_FMT_H


#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#ifndef BOOST_STRING_TRIM_HPP
    #include <boost/algorithm/string/trim.hpp>
#endif


namespace txt
{
namespace util
{


const int ftWidth  = 0;
const int ftCenter = 1;
const int ftLeft   = 2;
const int ftRight  = 3;


struct CFormatOptions
{
    unsigned   globalIndent;
    unsigned   firstLineIndent;
    //unsigned   lastLineIndent;
    unsigned   lineIndent;
    unsigned   paraWidth;
    unsigned   formatType;

    void checkCorrect()
       {
        if (globalIndent>80) globalIndent = 80;
        if (paraWidth<20) paraWidth = 20;
        if (paraWidth>160) paraWidth = 160;
        if (lineIndent>140) lineIndent = 140;
        if (firstLineIndent>140) firstLineIndent = 140;
        //if (lastLineIndent>140) lastLineIndent = 140;

        unsigned totalWidth = lineIndent + paraWidth;
        if (firstLineIndent+20 > totalWidth)
           firstLineIndent = totalWidth - 20;
        //if (lastLineIndent+20 > totalWidth)
        //   lastLineIndent = totalWidth - 20;

        if (formatType>ftRight) formatType = ftWidth;
       }


    
}; // struct CFormatOptions



void splitLineToWords(std::vector<std::string> &words, const std::string &line);
void splitTextToLines(std::vector<std::string> &lines, const std::string &text);
std::string::size_type findSpace(const std::string &str, std::string::size_type fromPos);
std::string::size_type findNonSpace(const std::string &str, std::string::size_type fromPos);
std::string::size_type findNextSpace(const std::string &str, std::string::size_type fromPos);
std::string formatString(const CFormatOptions &opts, const std::string& str, int width);
std::string formatPara(const CFormatOptions &opts, const std::vector<std::string> &lines);
std::string formatText(const CFormatOptions &opts, const std::vector<std::string> &lines);
std::string removeLinefeeds(const std::string &str);
std::string escapeLinefeeds(const std::string &str);

//-----------------------------------------------------------------------------
inline
void splitLineToWords(std::vector<std::string> &words, const std::string &line)
   {
    std::string curWord;
    std::string::size_type pos = 0, size = line.size();
    for(; pos<size; ++pos)
       {
        if (line[pos]==' ' || line[pos]=='\t')
           {
            if (!curWord.empty())
               {
                words.push_back(curWord);
                curWord.clear();
               }
           }
        else
           {
            curWord.append(1, line[pos]);
           }
       }

    if (!curWord.empty())
       words.push_back(curWord);
   }

//-----------------------------------------------------------------------------
inline
void splitTextToLines(std::vector<std::string> &lines, const std::string &text)
   {
    std::string curLine;
    std::string::size_type pos = 0, size = text.size();
    bool lastCharIsNewLine = false;
    for(; pos<size; ++pos)
       {
        if (text[pos]=='\r') continue;
        if (text[pos]=='\n')
           {
            lines.push_back(curLine);
            curLine.clear();
            lastCharIsNewLine = true;
            continue;
           }
        lastCharIsNewLine = false;
        curLine.append(1, text[pos]);
       }
    if (!curLine.empty() || lastCharIsNewLine)
       lines.push_back(curLine);
   }

//-----------------------------------------------------------------------------
inline
std::string::size_type findSpace(const std::string &str, std::string::size_type fromPos)
   {
    std::string::size_type size = str.size();
    for(; fromPos<size; ++fromPos) if (str[fromPos]==' ') return fromPos;
    return std::string::npos;   
   }

//-----------------------------------------------------------------------------
inline
std::string::size_type findNonSpace(const std::string &str, std::string::size_type fromPos)
   {
    std::string::size_type size = str.size();
    for(; fromPos<size; ++fromPos) if (str[fromPos]!=' ') return fromPos;
    return std::string::npos;
   }

//-----------------------------------------------------------------------------
inline
std::string::size_type findNextSpace(const std::string &str, std::string::size_type fromPos)
   {
    std::string::size_type spPos = findNonSpace(str, fromPos);
    if (spPos==std::string::npos) return spPos;
    return findSpace(str, spPos);
   }

//-----------------------------------------------------------------------------
inline
std::string formatString(const CFormatOptions &opts, const std::string& str, int width)
   {
    if (opts.formatType==ftLeft)
       return str;

    bool lastLine = false;
    if (width<0)
       {
        width = -width;
        lastLine = true;
       }

    if (str.size()>=(unsigned)width)
       return str;

    if (opts.formatType==ftRight)
        return std::string((unsigned)width-str.size(), ' ') + str;
    if (opts.formatType==ftCenter)
        return std::string(((unsigned)width-str.size())/2, ' ') + str;

    if (lastLine)
       return str;

    unsigned spacesInserted = 0;
    std::string res(str);
    std::string::size_type pos = 0;
    while(res.size()<(unsigned)width)
       {
        pos = findNextSpace(res, pos);
        if (pos==std::string::npos)
           {
            if (!spacesInserted)
               return res;
            pos = 0; // next round
           }
        if (pos) 
           {
            res.insert(pos, 1, ' ');
            ++spacesInserted;
           }
       }

    return res;
   }

//-----------------------------------------------------------------------------
inline
std::string formatPara(const CFormatOptions &opts, const std::vector<std::string> &lines)
   {
    std::vector<std::string> words;
    for(std::vector<std::string>::const_iterator it = lines.begin(); it!=lines.end(); ++it)
       {
        splitLineToWords(words, *it);
       }

    unsigned totalWidth = opts.lineIndent + opts.paraWidth;
    unsigned lineLen = opts.paraWidth;
    unsigned firstLineLen = totalWidth - opts.firstLineIndent;

    std::vector<std::string> paraLines;
    std::string curLine;
    //unsigned maxLen = lineLen;

    //std::string res = "---------------------\n";
    for(std::vector<std::string>::const_iterator it = words.begin(); it!=words.end(); )
       {
        unsigned maxLen = paraLines.empty() ? firstLineLen : lineLen;

        // ���� ������ ����� � ������� ����� ������� ���� ������� ������
        // ��������� �����, ����������� ������ (�� ������, �� ������, �� ������ ����, �� ������� ����)
        // ���� ��� ���������� ����� ������ ������ �������� �����, �� ����� �����������

        if ( (curLine.size() + it->size() + 1) > maxLen ||
             (curLine.empty() && it->size() > maxLen)
           )
           { 
            if (curLine.empty())
               curLine = *it++;
            paraLines.push_back(formatString(opts, curLine, maxLen));
            curLine.clear();
            continue;
           }
        if (!curLine.empty()) 
            curLine += std::string(" ");
        curLine += *it++;;
        //res += "\n";
        //res += *it;
       }

    if (!curLine.empty()) 
       paraLines.push_back(formatString(opts, curLine, -((int)lineLen)));


    std::string res;

    for(std::vector<std::string>::const_iterator it = paraLines.begin(); it!=paraLines.end(); ++it)
       {
        if (!res.empty()) res += "\n";
        if (it==paraLines.begin())
           {
            res += std::string( opts.globalIndent + opts.firstLineIndent, ' ') + *it;
           }
        else
           {
            res += std::string( opts.globalIndent + opts.lineIndent, ' ') + *it;
           }
       }

    res += "\n";

    return res;
   }

//-----------------------------------------------------------------------------
inline
std::string formatText(const CFormatOptions &opts, const std::vector<std::string> &lines)
   {
    CFormatOptions options = opts;
    options.checkCorrect();

    std::string res;
    std::vector<std::string> paraLines;
    for(std::vector<std::string>::const_iterator it = lines.begin(); it!=lines.end(); ++it)
       {
        if (!it->empty())
           {
            paraLines.push_back(*it);
           }
        else // ������ ������ - ����� ���������
           { // ��������� ������ ������� � ����������� ������ - �������� ���������
            if (!res.empty()) res += "\n";
            if (!paraLines.empty())
                {
                 res += formatPara(options, paraLines);
                 paraLines.clear();
                }
           }
       }

    if (!paraLines.empty())
       {
        if (!res.empty()) res += "\n";
        res += formatPara(opts, paraLines);
       }

    return res;
   }

//-----------------------------------------------------------------------------
inline
std::string removeLinefeeds(const std::string &str)
   {
    std::string res;
    res.reserve(str.size());
    std::string::const_iterator it = str.begin();
    bool prevLf = false;
    for(; it!=str.end(); ++it)
       {
        if (prevLf)
           {
            res.append(1, *it);
            if (*it!='\n')
               prevLf = false;
           }
        else
           {
            if (*it=='\n') { prevLf = true; res.append(1, ' '); }
            else           res.append(1, *it);
           }
       }
    return res;
   }

inline
std::string escapeLinefeeds(const std::string &str)
   {
    std::string res;
    res.reserve(str.size());
    std::string::const_iterator it = str.begin();
    bool prevLf = false;
    for(; it!=str.end(); ++it)
       {
        if (*it=='\r') continue;
        if (*it=='\n')
           {
            res.append(1, '\\');
            res.append(1, 'n');
           }
        else
           {
            res.append(1, *it);
           }
       }
    return res;
   }

struct CLineTrim
{
    std::string operator()(const std::string &str) const
       {
        return boost::algorithm::trim_copy(str);
       }
};

struct CLineTrimAndRemoveLeadingChar
{
    char          ch;
    CLineTrim     trimmer;
    CLineTrimAndRemoveLeadingChar(char c=0) : ch(c), trimmer() {}

    std::string operator()(const std::string &str) const
       {
        std::string res = trimmer(str);
        if (!ch || res.empty()) return res;
        if (res[0]==ch)
           return trimmer(std::string(res, 1, res.npos));
        else
           return res;
       }
};



template <typename LineProcesser>
std::string processTextLinesCopy( const std::string &text
                                , const std::string &sep
                                , const LineProcesser &processer
                                )
   {
    std::vector<std::string> lines;
    txt::util::splitTextToLines(lines, text);
    std::string res; res.reserve(text.size());

    std::vector<std::string>::const_iterator lit = lines.begin();
    for(; lit!=lines.end(); ++lit)
       {
        if (!res.empty()) res.append(sep);
        res.append( processer(*lit));
       }
    return res;
   }

template <typename LineProcesser>
void processTextLines( std::string &text
                     , const std::string &sep
                     , const LineProcesser &processer
                     )
   {
    processTextLinesCopy(text, sep, processer).swap(text);
   }



}; // namespace util
}; // namespace txt




#endif /* MBS_TEXT_FMT_H */

