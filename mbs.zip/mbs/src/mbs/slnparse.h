#ifndef MBS_SLNPARSE_H
#define MBS_SLNPARSE_H


#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif


#include "makealgo.h"
#include "vcproj.h"
#include "mak.h"
#include "toolset.h"
#include "prjfile.h"
#include "util.h"


namespace mbs{



struct CMsvcProjectInfo
{
    std::string              uid;
    std::vector<std::string> dependencies;
    std::string              slnName;
    std::string              slnRelativePath;

    std::string              prjName;
    std::string              prjUid;
    std::vector<CMsvcProjectConfigurationInfo>   prjConfigurations;
    //std::vector<std::string>                     prjSourceFiles;
    std::vector<CProjectFile>                    prjSourceFiles;
    std::vector<CProjectFile>                    prjHeaderFiles;
    std::vector<CProjectFile>                    prjGeneratedFiles;
    std::vector<CProjectFile>                    prjFormFiles;

    void getProjectConfigurationNames( std::vector< ::std::string > &confNames) const
       {
        std::vector<CMsvcProjectConfigurationInfo>::const_iterator it = prjConfigurations.begin();
        for(; it!=prjConfigurations.end(); ++it)
           {
            confNames.push_back(it->NameOnly);
           }
       }

    void getProjectConfigurationCanonicalNames( std::vector< ::std::string > &confNames) const
       {
        getProjectConfigurationNames( confNames );
        util::makeCanonicalConfigurationNames( confNames );
       }
    
    void buildSourcesIncludedList( const std::vector< ::std::string > &confNames, std::vector<CProjectFile> &files) const
       {
        std::vector<CProjectFile>::iterator it = files.begin();
        for(; it!=files.end(); ++it)
           {
            it->buildIncludedList(confNames);
           }
       }

    void buildSourcesIncludedList()
       {
        std::vector< ::std::string > confNames;
        getProjectConfigurationCanonicalNames(confNames);
        buildSourcesIncludedList( confNames, prjSourceFiles    );
        buildSourcesIncludedList( confNames, prjHeaderFiles    );
        buildSourcesIncludedList( confNames, prjGeneratedFiles );
        buildSourcesIncludedList( confNames, prjFormFiles      );
       }

    /*
    std::string              prjName;
    std::string              prjUid;
    std::vector<std::string> prjSourceFiles;
    */

};


inline
std::ostream& operator<<(std::ostream& os, const CMsvcProjectConfigurationInfo &i)
   {
    os<<"\n";
    //os<<"    Project GUID (vcproj): "<<i.uid<<"\n";
    //os<<"    Project name (vcproj): "<<i.slnName<<"\n";
    os<<"        Configuration        : "<<i.NameOnly<<"\n";
    os<<"        Platform             : "<<i.PlatformOnly<<"\n";
    os<<"        OutputDirectory      : "<<i.OutputDirectory<<"\n";
    os<<"        IntermediateDirectory: "<<i.IntermediateDirectory<<"\n";
    return os;
   }


inline
std::ostream& operator<<(std::ostream& os, const CProjectFile &prjFile)
   {
    std::cout<<prjFile.filename;
    ::std::vector< tstring > incConfigurations;
    prjFile.getIncludedConfigurations(incConfigurations);
    if (incConfigurations.empty())
       {
        //os<<" <I>All configurations</I>";
       }
    else
       {
        //os<<" Conigurations: ";
        os<<"   [ ";
        ::std::vector< tstring >::const_iterator it = incConfigurations.begin();
        for(; it!=incConfigurations.end(); ++it)
           {
            if (it!=incConfigurations.begin()) os<<", ";
            os<<*it;
           }
        os<<" ]";
       }
    return os;
   }

inline
std::ostream& operator<<(std::ostream& os, const CMsvcProjectInfo &i)
   {
    os<<"    Project GUID: "<<i.uid<<"\n";
    os<<"    Project name: "<<i.slnName<<"\n";
    os<<"    Project file: "<<i.slnRelativePath<<"\n";
    os<<"    Project GUID (vcproj): "<<i.prjUid<<"\n";
    os<<"    Project name (vcproj): "<<i.prjName<<"\n";
    if (!i.dependencies.empty())
       {
        os<<"    Dependencies: ";
        std::vector<std::string>::const_iterator dit = i.dependencies.begin();
        for(; dit!=i.dependencies.end(); ++dit)
           {
            if (dit!=i.dependencies.begin()) os<<", ";
            os<<*dit;
           }
        os<<"\n";
       }
    os<<"    .vcproj info\n";

    std::vector<CMsvcProjectConfigurationInfo>::const_iterator pcIt = i.prjConfigurations.begin();
    for(; pcIt!=i.prjConfigurations.end(); ++pcIt)
       {
        os<<*pcIt<<"\n";
       }

    os<<"    Source Files:\n";
    std::vector<CProjectFile>::const_iterator psfIt = i.prjSourceFiles.begin();
    for(; psfIt!=i.prjSourceFiles.end(); ++psfIt)
       {
        std::cout<<"        "<<*psfIt<<"\n";
       }

    if (!i.prjHeaderFiles.empty())
       {
        os<<"    Header Files:\n";
        std::vector<CProjectFile>::const_iterator psfIt = i.prjHeaderFiles.begin();
        for(; psfIt!=i.prjHeaderFiles.end(); ++psfIt)
           {
            std::cout<<"        "<<*psfIt<<"\n";
           }
       }

    if (!i.prjGeneratedFiles.empty())
       {
        os<<"    Generated Files:\n";
        std::vector<CProjectFile>::const_iterator psfIt = i.prjGeneratedFiles.begin();
        for(; psfIt!=i.prjGeneratedFiles.end(); ++psfIt)
           {
            std::cout<<"        "<<*psfIt<<"\n";
           }
       }

    if (!i.prjFormFiles.empty())
       {
        os<<"    Form Files:\n";
        std::vector<CProjectFile>::const_iterator psfIt = i.prjFormFiles.begin();
        for(; psfIt!=i.prjFormFiles.end(); ++psfIt)
           {
            std::cout<<"        "<<*psfIt<<"\n";
           }
       }
    return os;
   }


struct CMsvcSolutionInfo
{
    std::map<std::string, std::vector<std::string> >     platformConfigurations;
    // GUID to file name map
    std::map<std::string, CMsvcProjectInfo >             projects;

    bool checkDuplicatedProjects(std::vector<std::string> &dupNames);

    void clear()
       {
        platformConfigurations.clear();
        projects.clear();
       }

};


inline
std::ostream& operator<<(std::ostream& os, const CMsvcSolutionInfo &i)
   {
    std::map<std::string, std::vector<std::string> >::const_iterator pit = i.platformConfigurations.begin();
    for(; pit!=i.platformConfigurations.end(); ++pit)
       {
        os<<"    Platform: "<<pit->first<<", configurations:\n";
        std::vector<std::string>::const_iterator cit = pit->second.begin();
        for(; cit!=pit->second.end(); ++cit)
           {
            os<<"        "<<*cit<<"\n";
           }
       }

    os<<"\nProjects:\n";
    std::map<std::string, CMsvcProjectInfo >::const_iterator prjIt = i.projects.begin();
    for(; prjIt!=i.projects.end(); ++prjIt)
       {
        os<<"\n"<<prjIt->second;//<<"\n";
       }

    os<<"\n";

    os<<"\nProject build order:\n";

    std::vector<std::string> orderedProjects;    
    makeValidDependencyOrder(i.projects, orderedProjects);

    std::vector<std::string>::const_iterator opIt = orderedProjects.begin();
    for (; opIt!=orderedProjects.end(); ++opIt)
        {
         std::map<std::string, CMsvcProjectInfo >::const_iterator prjIt = i.projects.find(*opIt);
         if (prjIt!=i.projects.end())
            std::cout<<*opIt<<" - "<<prjIt->second.slnName<<"\n";
         else
            std::cout<<*opIt<<"\n";
        }

    return os;
   }


bool parseMsvcSolution(const std::string &basePath, const std::string &slnFile, CMsvcSolutionInfo &info, const std::vector<std::string> &excludeProjectPatterns );
bool makeMakefileInfo(const CMsvcProjectInfo &info, CMakefileInfo &mi);
bool makeMakefileSolution(const CMsvcSolutionInfo &sol, CMakefileSolutionInfo &mkSol);


}; // namespace mbs


#endif /* MBS_SLNPARSE_H */

