// warning C4748: /GS can not protect parameters and local variables from local buffer overrun because optimizations are disabled in function
#if defined(_MSC_VER) && _MSC_VER>=1400
#pragma warning (disable : 4748)
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#include "mbsconf.h"
#include "toolset.h"
#include "../common/6mlerr.h"



namespace mbs
{

namespace util
{


template<typename TT>
struct CFindByName
{
    std::string name;
    CFindByName(const std::string &n) : name(n) {}
    bool operator()(const TT &t) const
       { return t.name==name; }
};


template<typename TT>
struct CFindByToolsetPlatformConfiguration
{
    std::string toolset, hostPlatform, targetPlatform, outputType, configuration;
    CFindByToolsetPlatformConfiguration(const std::string &t, const std::string &hp, const std::string &tp, const std::string &ot, const std::string &c)
       : toolset(t), hostPlatform(hp), targetPlatform(tp), outputType(ot), configuration(c) {}
    bool operator()(const TT &t) const
       { 
        if (toolset!=t.toolset)             return true;
        if (configuration!=t.configuration) return true;
        if (outputType!=t.outputType)       return true;
        //if (hostPlatform!=t.hostPlatform)     return true;
        //if (targetPlatform!=t.targetPlatform) return true;
        if (!toolset::platformCompare(hostPlatform, t.hostPlatform))     return true;
        if (!toolset::platformCompare(targetPlatform, t.targetPlatform)) return true;
        return false;
        //return !(toolset==t.toolset && hostPlatform==t.hostPlatform && targetPlatform==t.targetPlatform && configuration==t.configuration); 
       }
};

struct CAppendLine
{
    std::string strSep;
    std::string &str;
    CAppendLine(const std::string ssep, std::string &s) 
       : strSep(ssep), str(s) {}

    typedef std::string::reference         reference;
    typedef std::string::const_reference   const_reference;

    inline
    void push_back(const std::string &s)
       {
        if (!str.empty()) str.append(strSep);
        str.append(s);
       }
};

struct CAppendVarsLine
{
    std::string strSep;
    std::string &str;
    CAppendVarsLine(const std::string ssep, std::string &s) 
       : strSep(ssep), str(s) {}

    // typedef std::string::reference         reference;
    // typedef std::string::const_reference   const_reference;

    typedef CMbsVars            &reference;
    typedef const CMbsVars      &const_reference;

    inline
    void push_back(const CMbsVars &v)
       {
        if (!str.empty()) str.append(strSep);
        str.append(v.vars);
       }

    // CAppendVarsLine& operator=(const CMbsVars &v)
    //    { push_back(v); return *this; }

};

}; // namespace util



//-----------------------------------------------------------------------------
void CMbsConfig::findVars( const std::string &toolset
                         , const std::string &hostPlatform
                         , const std::string &targetPlatform
                         , const std::string &outputType
                         , const std::string &configuration
                         , std::string &res) const
   {
    util::CAppendVarsLine appendVarsLine("\n", res);
    std::remove_copy_if( vars.begin(), vars.end(), std::back_inserter(appendVarsLine)
                       , util::CFindByToolsetPlatformConfiguration<CMbsVars>(toolset, hostPlatform, targetPlatform, outputType, configuration)
                       );
   }

//-----------------------------------------------------------------------------
bool CMbsConfig::getHostPlatformOptions(const std::string &hostPlatform, CMbsHostPlatformOptions &opts) const
   {
    std::vector<CMbsHostPlatformOptions>::const_iterator it =
                                          std::find_if( 
                                                       hostPlatformOptions.begin(), 
                                                       hostPlatformOptions.end(), 
                                                       util::CFindByName<CMbsHostPlatformOptions>(hostPlatform)
                                                      );
    if (it==hostPlatformOptions.end()) return false;
    opts = *it;
    return true;
   }

//-----------------------------------------------------------------------------
void searchForMbsConf(const std::string &pathForScan, const std::string &exepath, std::vector<std::string> &confNames)
   {
    std::vector<std::string> pathParts;
    filename::splitPath(pathForScan, pathParts);

    typedef std::vector<std::string>::const_iterator iter_t;
    std::vector<std::string>::const_iterator it = pathParts.begin();
    if (it!=pathParts.end()) ++it;

    while(1==1)
       {
        std::string name = filename::appendPath(filename::mergePath<iter_t, char>(pathParts.begin(), it, '\\'), "mbs-conf.xml");
        if (winapi::fileExist(name))
           {
            confNames.push_back(name);
           }
        // name = filename::appendPath(filename::mergePath(pathParts.begin(), it, '\\'), "mbsup.conf");
        // if (winapi::fileExist(name))
        //    {
        //     confNames.push_back(name);
        //    }

        if (it==pathParts.end()) break;
        ++it;
       }
    /*
    std::string name = filename::appendPath(exepath, "mbs.conf");
    if (winapi::fileExist(name))
       confNames.push_back(name);
    */

    //toolset::reverseVector(confNames);


    std::vector<std::string> confNamesTemp;
    it = pathParts.begin();
    if (it!=pathParts.end()) ++it;

    while(1==1)
       {
        std::string name = filename::appendPath(filename::mergePath<iter_t, char>(pathParts.begin(), it, '\\'), "_mbs-conf.xml");
        if (winapi::fileExist(name))
           {
            confNamesTemp.push_back(name);
           }
        // name = filename::appendPath(filename::mergePath(pathParts.begin(), it, '\\'), "mbsdown.conf");
        // if (winapi::fileExist(name))
        //    {
        //     confNames.push_back(name);
        //    }

        if (it==pathParts.end()) break;
        ++it;
       }

    toolset::reverseVector(confNamesTemp);
    confNames.insert(confNames.end(), confNamesTemp.begin(), confNamesTemp.end());
   

    std::string name = filename::appendPath(exepath, "mbs-conf.xml");
    if (winapi::fileExist(name))
       confNames.push_back(name);

    toolset::reverseVector(confNames);


    /*
    for(; it!=pathParts.end(); ++it)
       {
        std::string name = filename::appendPath(filename::mergePath(pathParts.begin(), it, '\\'), "mbs.conf");
        //name = filename::appendPath(exepath, "mbs.conf");
        if (winapi::fileExist(name))
           confNames.push_back(name);
       }
    */
   }

//-----------------------------------------------------------------------------
void loadMbsConfigs(const std::vector<std::string> &confNames, std::vector<CMbsConfig> &confVec)
   {
    std::vector<std::string>::const_iterator it = confNames.begin();
    for(; it!=confNames.end(); ++it)
       {
        if(it->empty()) continue;
        mbs::CMbsConfig conf;
        std::string errText;
        bool fErr = false;
        try{
            sixml::serializer::load_xml( it->c_str(), conf, "mbs-config");
           }
        CATCH_6ML_ERRORS(fErr, errText)
        if (fErr)
           {
            std::cout<<"Failed to read '"<<*it<<"' config file: "<<errText<<"\n";
            continue;
           }

        // catch(...)
        //    {
        //     //std::cout<<"Failed to read "<<prjFile<<" project file, project skipped\n";
        //     continue;
        //    }
        confVec.push_back(conf);
       }
   }

//-----------------------------------------------------------------------------
void saveMbsConfig(const std::string &fname, const CMbsConfig &conf)
   {
    if (fname.empty()) return;
    try{
        sixml::serializer::write_xml( fname.c_str(),
                                      "mbs-config", 
                                      conf, 
                                      sixml::serializer::write_attr::less_indent, // default_method, more_indent
                                      true
                                    );
       }
    catch(...)
       {

       }
   }

//-----------------------------------------------------------------------------
void loadMbsConfigs(const std::vector<std::string> &confNames, CMbsConfig &conf)
   {
    std::vector<CMbsConfig> confVec;
    loadMbsConfigs(confNames, confVec);

    std::vector<CMbsConfig>::const_iterator it = confVec.begin();
    for(; it!=confVec.end(); ++it)
       {
        CMbsConfig tmp = *it;
        tmp.splitPlatformConfigs();
        conf.merge(tmp);
       }

    //conf.splitPlatformConfigs();
   }

//-----------------------------------------------------------------------------
bool CMbsConfig::findPlatformInfo( const std::string &platformName, const std::string &hostPlatformName, CMbsPlatformInfo &info) const
   {
    std::vector<std::string> vec, reverceVec;
    if (!mbs::toolset::buildPrefferedPlatformsVector( platformName, vec, reverceVec))
       return false;

    std::vector<std::string>::const_iterator it = vec.begin();
    for(; it!=vec.end(); ++it)
       {
        std::vector<CMbsPlatformInfo>::const_iterator piit = platforms.begin();
        for(; piit!=platforms.end(); ++piit)
           {
            std::string canonName = toolset::makeCanonicalPlatformName(piit->name);
            if (canonName==*it)
               {
                if (hostPlatformName.empty())
                   {
                    info = *piit;
                    return true;
                   }
                else if (hostPlatformName==piit->hostPlatform)
                   {
                    info = *piit;
                    return true;
                   }
               }
           }
       }
    return false;
   }

//-----------------------------------------------------------------------------
bool CMbsConfig::findPlatformInfo( const std::string &platformName, CMbsPlatformInfo &info) const
   {
    std::vector<std::string> vec, reverceVec;
    if (!mbs::toolset::buildPrefferedPlatformsVector( platformName, vec, reverceVec))
       return false;

    std::vector<std::string>::const_iterator it = vec.begin();
    for(; it!=vec.end(); ++it)
       {
        std::vector<CMbsPlatformInfo>::const_iterator piit = platforms.begin();
        for(; piit!=platforms.end(); ++piit)
           {
            std::string canonName = toolset::makeCanonicalPlatformName(piit->name);
            if (canonName==*it)
               {
                info = *piit;
                return true;
               }
           }
       }
    return false;
   }

//-----------------------------------------------------------------------------
bool CMbsConfig::getToolsetForPlatform(const CMbsPlatformInfo &pi, const std::string &targetPlatform, CToolset &ts, CPlatformHostTarget &foundPlatform) const
   {
    std::vector<std::string> targetPlatformVec, targetPlatformReverceVec;
    if (!mbs::toolset::buildPrefferedPlatformsVector( targetPlatform, targetPlatformVec, targetPlatformReverceVec))
       return false;

    typedef std::vector<CMbsToolsetInfo>::size_type toolset_index_t;
    typedef std::vector<std::string>::size_type     strvector_index_t;
    typedef std::pair< toolset_index_t, strvector_index_t >  index_pair_t;

    std::vector< index_pair_t > foundPlatformIndexes;

    toolset_index_t i = 0;
    for(; i<toolsets.size(); ++i)
       {
        if (toolsets[i].name != pi.toolset)      continue;

        strvector_index_t verIdx = 0, verSized = targetPlatformVec.size();
        for(; verIdx<verSized; ++verIdx)
           {
            if (toolsets[i].targetPlatform==targetPlatformVec[verIdx])
               foundPlatformIndexes.push_back(std::make_pair(i, verIdx));
           }
       }

    if (foundPlatformIndexes.empty()) return false;

    struct index_pair_second_greater : public std::binary_function< index_pair_t, index_pair_t, bool >
    {
     inline
     bool operator()( const index_pair_t &p1
                    , const index_pair_t &p2
                    ) const
        {
         return p1.second > p2.second;
        }
    };

    struct index_pair_second_not_equal : public std::binary_function< index_pair_t, index_pair_t, bool >
    {
     inline
     bool operator()( const index_pair_t &p1
                    , const index_pair_t &p2
                    ) const
        {
         return p1.second != p2.second;
        }
    };

    std::vector< std::pair< toolset_index_t, strvector_index_t > >::const_iterator maxRelevantIt = std::max_element(
                                                                                    foundPlatformIndexes.begin()
                                                                                  , foundPlatformIndexes.end()
                                                                                  , index_pair_second_greater()
                                                                                  );
    if (maxRelevantIt==foundPlatformIndexes.end())
       return false;

    /*
    std::cout<<"Most relevant toolset: "<<toolsets[maxRelevantIt->first].name
                               <<" for "<<toolsets[maxRelevantIt->first].hostPlatform
                               <<" (on "<<toolsets[maxRelevantIt->first].targetPlatform
                               <<")\n";
    */

    foundPlatformIndexes.erase(
                               std::remove_if(
                                               foundPlatformIndexes.begin()
                                             , foundPlatformIndexes.end()
                                             , std::bind2nd(index_pair_second_not_equal(), *maxRelevantIt) ),
                               foundPlatformIndexes.end()
                              );

    std::vector<CMbsToolsetInfo> targetToolsets;
    maxRelevantIt = foundPlatformIndexes.begin();
    for(; maxRelevantIt!=foundPlatformIndexes.end(); ++maxRelevantIt)
       {
        targetToolsets.push_back(toolsets[maxRelevantIt->first]);
       }

    foundPlatformIndexes.clear();


    // std::vector<std::string> hostPlatformVec, hostPlatformReverceVec;
    // if (!mbs::toolset::buildPrefferedPlatformsVector( pi.hostPlatform, hostPlatformVec, hostPlatformReverceVec))
    //    return false;

    //toolset_index_t 
    i = 0;
    for(; i<targetToolsets.size(); ++i)
       {
        // if (targetToolsets[i].name != pi.toolset)      continue;

        std::vector<std::string> hostPlatformVec, hostPlatformReverceVec;
        if (!mbs::toolset::buildPrefferedPlatformsVector( targetToolsets[i].hostPlatform /* pi.hostPlatform */ , hostPlatformVec, hostPlatformReverceVec))
           return false;

        strvector_index_t verIdx = 0, verSized = hostPlatformVec.size();
        for(; verIdx<verSized; ++verIdx)
           {
            //if (targetToolsets[i].hostPlatform==hostPlatformVec[verIdx])
            if (pi.hostPlatform==hostPlatformVec[verIdx])
               foundPlatformIndexes.push_back(std::make_pair(i, verIdx));
           }
       }

    if (foundPlatformIndexes.empty()) return false;

    maxRelevantIt = std::max_element(
                                      foundPlatformIndexes.begin()
                                    , foundPlatformIndexes.end()
                                    , index_pair_second_greater()
                                    );
    if (maxRelevantIt==foundPlatformIndexes.end())
       return false;

    foundPlatformIndexes.erase(
                               std::remove_if(
                                               foundPlatformIndexes.begin()
                                             , foundPlatformIndexes.end()
                                             , std::bind2nd(index_pair_second_not_equal(), *maxRelevantIt) ),
                               foundPlatformIndexes.end()
                              );

    if (foundPlatformIndexes.empty()) return false;

    ts = targetToolsets[foundPlatformIndexes[0].first];

    foundPlatform.hostPlatform   = targetToolsets[foundPlatformIndexes[0].first].hostPlatform  ;
    foundPlatform.targetPlatform = targetToolsets[foundPlatformIndexes[0].first].targetPlatform;


    /*
    std::vector<std::string> hostPlatformVec, hostPlatformReverceVec;
    if (!mbs::toolset::buildPrefferedPlatformsVector( pi.hostPlatform, hostPlatformVec, hostPlatformReverceVec))
       return false;
    */



    /*
    maxRelevantIt = foundPlatformIndexes.begin();
    for(; maxRelevantIt!=foundPlatformIndexes.end(); ++maxRelevantIt)
       {
        std::cout<<"    Most relevant toolset: "<<toolsets[maxRelevantIt->first].name
                                   <<" for "<<toolsets[maxRelevantIt->first].hostPlatform
                                   <<" (on "<<toolsets[maxRelevantIt->first].targetPlatform
                                   <<")\n";
       }
    */



    /*
    std::vector<CMbsToolsetInfo>::const_iterator it = toolsets.begin();
    for(; it!=toolsets.end(); ++it)
       {
        if (it->name           != pi.toolset)      continue;
        if (it->hostPlatform   != pi.hostPlatform) continue;
        if (it->targetPlatform != targetPlatform)  continue;
        ts = *it;
        return true;
       }
    */
    return true;
   }



}; // namespace mbs
