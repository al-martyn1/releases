#include "codeblocks.h"
#include "../common/6mlerr.h"

namespace mbs
{

namespace cb // CodeBlocks
{

//-----------------------------------------------------------------------------
struct CWorkspaceList
{
    std::vector<CWorkspace>     workspaces;

    STRUCT_LAYOUT_DEFAULT(CWorkspaceList)
            array(0               , &CWorkspaceList::workspaces, _T("Workspace"));
    END_STRUCT_LAYOUT()
};

//-----------------------------------------------------------------------------
bool loadWorkspace(const std::string &filename, CWorkspace &ws)
   {
    if (filename.empty()) return false;

    CWorkspaceList wsList;
    std::string errText;
    bool fErr = false;
    try{
        sixml::serializer::load_xml( filename.c_str(), wsList, "CodeBlocks_workspace_file");
       }
    CATCH_6ML_ERRORS(fErr, errText)
    if (fErr)
       {
        //std::cout<<"Failed to read '"<<*it<<"' config file: "<<errText<<"\n";
        return false;
       }
    
    if (wsList.workspaces.empty()) return false;
    ws = wsList.workspaces[0];

    return true;   
   }

//-----------------------------------------------------------------------------
//bool saveWorkspace(const std::string &filename, const CWorkspace ws)
bool saveWorkspace(const std::string &filename, CWorkspace ws)
   {
    if (filename.empty()) return false;

    CWorkspaceList wsList;
    ws.sortProjects();
    wsList.workspaces.push_back(ws);

    try{
        sixml::serializer::write_xml( filename.c_str(),
                                      "CodeBlocks_workspace_file", 
                                      wsList, 
                                      sixml::serializer::write_attr::default_method, // less_indent, default_method, more_indent
                                      true,
                                      true,
                                      true
                                    );
       }
    catch(...)
       {
        return false;
       }
    return true;
   }


/*
<CodeBlocks_project_file>
    <FileVersion major="1" minor="6" />
    <Project>
    ...
*/
struct CProjectInfoAux
{
    CFileVersion                  fileVersion;
    std::vector<CProjectInfo>     projects;

    STRUCT_LAYOUT_DEFAULT(CProjectInfoAux)
            complex( _T("FileVersion"), &CProjectInfoAux::fileVersion, CFileVersion() );
            array  ( 0                , &CProjectInfoAux::projects, _T("Project"));
    END_STRUCT_LAYOUT()

}; // struct CProjectInfoAux



bool loadProject(const std::string &filename, CProjectInfo &pi)
   {
    if (filename.empty()) return false;

    CProjectInfoAux prjList;
    std::string errText;
    bool fErr = false;
    try{
        sixml::serializer::load_xml( filename.c_str(), prjList, "CodeBlocks_project_file");
       }
    CATCH_6ML_ERRORS(fErr, errText)
    if (fErr)
       {
        //std::cout<<"Failed to read '"<<*it<<"' config file: "<<errText<<"\n";
        return false;
       }
    
    if (prjList.projects.empty()) return false;
    pi = prjList.projects[0];

    pi.verMajor = prjList.fileVersion.major;
    pi.verMinor = prjList.fileVersion.minor;

    return true;   
   }

bool saveProject(const std::string &filename, const CProjectInfo &pi)
   {
    if (filename.empty()) return false;

    CProjectInfoAux prjList;
    prjList.projects.push_back(pi);

    prjList.fileVersion.major = pi.verMajor;
    prjList.fileVersion.minor = pi.verMinor;

    try{
        sixml::serializer::write_xml( filename.c_str(),
                                      "CodeBlocks_project_file", 
                                      prjList, 
                                      sixml::serializer::write_attr::default_method, // less_indent, default_method, more_indent
                                      true,
                                      true,
                                      true
                                    );
       }
    catch(...)
       {
        return false;
       }
    return true;

   }



//-----------------------------------------------------------------------------
/*
<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>
<CodeBlocks_workspace_file>
    <Workspace title="Workspace">
        <Project filename="testCConsole\testCConsole.cbp" />
        <Project filename="testCppConsole\testCppConsole.cbp" />
        <Project filename="testCppDll\testCppDll.cbp" active="1" />
    </Workspace>
</CodeBlocks_workspace_file>
*/



}; // namespace cb


}; // namespace mbs


