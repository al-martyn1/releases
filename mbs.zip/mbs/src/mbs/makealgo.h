#ifndef MBS_MAKEALGO_H
#define MBS_MAKEALGO_H


#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

/* #if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
 *     #include <string>
 * #endif
 */

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif

#if !defined(_QUEUE_) && !defined(_STLP_QUEUE) && !defined(__STD_QUEUE__) && !defined(_CPP_QUEUE) && !defined(_GLIBCXX_QUEUE)
    #include <queue>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#if !defined(_LIST_) && !defined(_STLP_LIST) && !defined(__STD_LIST__) && !defined(_CPP_LIST) && !defined(_GLIBCXX_LIST)
    #include <list>
#endif

/*
template <typename Key, typename Val>
void makeValidDependencyOrderAux(const Key &k, const std::map<Key, Val> &m, std::set<Key> &used, std::vector<Key> &ordered)
   {
   
   }
*/

template <typename Key, typename Val>
void makeValidDependencyOrder(const std::map<Key, Val> &m, std::vector<Key> &ordered)
   {
    if (m.empty()) return;

    std::list<Key> targetsQue;

    typename std::map<Key, Val>::const_iterator mit = m.begin();
    targetsQue.push_back(mit->first);

    ::std::set< ::std::string > notFoundProjects;

    while( (ordered.size()  /* + notFoundProjects.size() */ ) < m.size() )
        {
         if (targetsQue.empty())
            {
             if (++mit==m.end()) 
                {
                 // ������� ����� � ��������� ���� target map
                 //mit = m.begin(); 
                 return;
                }
             targetsQue.push_back(mit->first);
             continue;
            }

         Key k = targetsQue.front();
         targetsQue.pop_front();

         if (std::find(ordered.begin(), ordered.end(), k)!=ordered.end()) 
            continue; // target already ordered

         typename std::map<Key, Val>::const_iterator tIt = m.find(k);
         if (tIt==m.end())
            {
             notFoundProjects.insert(k);
             continue; // target not found
            }

         typename std::vector<Key>::const_iterator depIt = tIt->second.dependencies.begin();
         unsigned queuedCound = 0;
         for(; depIt!=tIt->second.dependencies.end(); ++depIt)
            {
             if (*depIt==k) continue; // cyclic dependency
             if (std::find(ordered.begin(), ordered.end(), *depIt)!=ordered.end()) 
                continue; // dependency allready ordered
             if (notFoundProjects.find(*depIt)!=notFoundProjects.end())
                {
                 continue; // project not found, dont need add it to dependecy list
                }
             queuedCound++;

             if (std::find(targetsQue.begin(), targetsQue.end(), *depIt)!=targetsQue.end()) 
                continue; // dependency allready in targetsQue

             targetsQue.push_back(*depIt);
            }

         if (queuedCound>0)
            {
             targetsQue.push_back(k);
             continue; // delay processing
            }
         ordered.push_back(k);
         // &ordered
        }

    //m.begin()->first
   }


#endif /* MBS_MAKEALGO_H */

