#ifndef MBS_PRJINFO_H
#define MBS_PRJINFO_H


#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#if !defined(_FUNCTIONAL_) && !defined(_STLP_FUNCTIONAL) && !defined(__STD_FUNCTIONAL__) && !defined(_CPP_FUNCTIONAL) && !defined(_GLIBCXX_FUNCTIONAL)
    #include <functional>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#include <marty/filename.h>

#include "scansrc.h"
#include "prjfile.h"



namespace mbs
{
namespace doc
{


//-----------------------------------------------------------------------------
template< typename CharType 
        , typename Traits   
        , typename Allocator
        >
bool
startsWith( const ::std::basic_string<CharType, Traits, Allocator> &strCompareTo
          , const ::std::basic_string<CharType, Traits, Allocator> &strStartsWith )
   {
    if (!strCompareTo.compare(0, strStartsWith.size(), strStartsWith, 0, strStartsWith.size()))
       return true;
    return false;
   }

//-----------------------------------------------------------------------------
template< typename CharType 
        , typename Traits   
        , typename Allocator
        >
::std::basic_string<CharType, Traits, Allocator>
ltrimDots( const ::std::basic_string<CharType, Traits, Allocator> &path )
   {
    ::std::basic_string<CharType, Traits, Allocator> res = path;
    if(res.size()>=2 && startsWith(res, ::std::basic_string<CharType, Traits, Allocator>("./"))) res.erase(0, 2);
    if(res.size()>=2 && startsWith(res, ::std::basic_string<CharType, Traits, Allocator>(".\\"))) res.erase(0, 2);
    while(res.size()>=3 && startsWith(res, ::std::basic_string<CharType, Traits, Allocator>(".."))) res.erase(0, 3);
    return res;
   }

using filename::makeCanonical;
using filename::getName;
using filename::getFile;
using filename::getPath;
using filename::getExtention;
//using filename::appendExtention;
using filename::appendPath;
//using filename::changeExtention;
//using filename::changePathChars;
//using filename::changePathCharsCopy;


//-----------------------------------------------------------------------------
struct CProjectInfo
{
    ::std::string                               name;
    ::std::string                               description;
    ::std::string                               projectFile; // msvc name
    ::std::map< ::std::string, ::std::string >  alternateProjectFiles;
    ::std::string                               entrySource;

    /*                                   
    ::std::vector< ::std::string >              sources;
    */

    ::std::vector< CProjectFile >              sources;

    CProjectInfo()
       : name()
       , description()
       , projectFile()
       , alternateProjectFiles()
       , entrySource()
       , sources()
       {}

    CProjectInfo( const ::std::string &n)
       : name(n)
       , description()
       , projectFile()
       , alternateProjectFiles()
       , entrySource()
       , sources()
       {}

    CProjectInfo( const CProjectInfo &pi)
       : name(pi.name)
       , description(pi.description)
       , projectFile(pi.projectFile)
       , alternateProjectFiles(pi.alternateProjectFiles)
       , entrySource(pi.entrySource)
       , sources(pi.sources)
       {}

    void updateProjectPaths( const ::std::string &buildRoot
                           , const ::std::string &win32buildPath
                           , const ::std::string &srcPath
                           , const ::std::string &slnPath
                           )
       {
        name = makeCanonical(appendPath(slnPath, name), C_PATH_SEPARATORS, '/');
        
        projectFile = makeCanonical(appendPath(win32buildPath, appendPath(slnPath, projectFile)), C_PATH_SEPARATORS, '/');

        ::std::string srcPathPath = getPath(srcPath);
        
        ::std::vector< CProjectFile >::iterator srcIt = sources.begin();
        for(; srcIt!=sources.end(); ++srcIt)
           {
            srcIt->filename = makeCanonical(appendPath(srcPathPath, ltrimDots(srcIt->filename)), C_PATH_SEPARATORS, '/');
            //srcIt->filename = makeCanonical(appendPath(srcIt->filename, ltrimDots(*srcIt)), C_PATH_SEPARATORS, '/');
           }
        /*
        ::std::vector< ::std::string >::iterator srcIt = sources.begin();
        for(; srcIt!=sources.end(); ++srcIt)
           {
            *srcIt = makeCanonical(appendPath(srcPathPath, ltrimDots(*srcIt)), C_PATH_SEPARATORS, '/');
           }
        */
        entrySource = makeCanonical(appendPath(srcPathPath, ltrimDots(entrySource)), C_PATH_SEPARATORS, '/');
       }

}; // struct CProjectInfo


//-----------------------------------------------------------------------------
struct CSolutionInfo
{
    ::std::string                                name;
    ::std::string                                solutionFile;
    ::std::map< ::std::string, ::std::map< ::std::string, ::std::string > >   alternateSolutionFiles;

    ::std::map< ::std::string, CProjectInfo >    projects;

    CProjectInfo* getProject( const ::std::string &name)
        {
         ::std::map< ::std::string, CProjectInfo >::iterator it = projects.find(name);
         if (it!=projects.end()) return &it->second;
         ::std::pair < ::std::map< ::std::string
                                 , CProjectInfo 
                                 > ::iterator
                     , bool
                     > insRes = projects.insert( ::std::make_pair(name, CProjectInfo(name) ) );
         return &(insRes.first->second);
        }

    void updateProjectPaths( const ::std::string &buildRoot
                           , const ::std::string &win32buildPath
                           , const ::std::string &srcPath
                           )
       {
        ::std::string slnPath = getPath(solutionFile);

        solutionFile = makeCanonical(appendPath(win32buildPath, solutionFile), C_PATH_SEPARATORS, '/');
        name = makeCanonical(name, C_PATH_SEPARATORS, '/');

        ::std::map< ::std::string, ::std::map< ::std::string, ::std::string > >::iterator altIt = alternateSolutionFiles.begin();
        for(; altIt!=alternateSolutionFiles.end(); ++altIt)
           {
            ::std::map< ::std::string, ::std::string >::iterator slnTypeIt = altIt->second.begin();
            for(; slnTypeIt!=altIt->second.end(); ++slnTypeIt)
                slnTypeIt->second = makeCanonical(appendPath(buildRoot, slnTypeIt->second), C_PATH_SEPARATORS, '/');
           }
        ::std::map< ::std::string, CProjectInfo >::iterator prjIt = projects.begin();
        for(; prjIt!=projects.end(); ++prjIt)
           {
            prjIt->second.updateProjectPaths( buildRoot, win32buildPath, srcPath, slnPath );
           }
       }



}; // struct CSolutionInfo


struct CHtmlLink
       {
        ::std::string href;
        ::std::string text;
        ::std::string alt;

        CHtmlLink() : href(), text(), alt() {}
        CHtmlLink(const ::std::string &hr) : href(hr), text(hr), alt() {}
        CHtmlLink(const ::std::string &hr, const ::std::string &t) : href(hr), text(t), alt() {}
        CHtmlLink(const ::std::string &hr, const ::std::string &t, const ::std::string &a) : href(hr), text(t), alt(a) {}
        CHtmlLink(const CHtmlLink &hl) : href(hl.href), text(hl.text), alt(hl.alt) {}
       }; // struct CHtmlLink

inline
::std::ostream& operator<<(::std::ostream& os, const CHtmlLink &lnk)
   {
    ::std::string text = lnk.text;
    ::std::string alt  = lnk.alt;
        
    if (alt.empty()) alt = text;

    os<<"<A href=\""<<lnk.href<<"\" alt=\""<<alt<<"\">"<<text<<"</A>";
    return os;
   }

struct CHtmlStartBox
{
    int           &id;
    ::std::string title;
    ::std::string cls;
    bool          display;

    CHtmlStartBox(int &i, const ::std::string &t, bool d = true) : id(i), title(t), cls(), display(d) {}
    CHtmlStartBox(int &i, const ::std::string &t, const ::std::string &c, bool d = true) : id(i), title(t), cls(c), display(d) {}
    CHtmlStartBox(const CHtmlStartBox &b) : id(b.id), title(b.title), cls(b.cls), display(b.display) {}

    // helpers
    ::std::ostream& onclick(::std::ostream &os) const { os<<"onclick=\"return ToggleBox(\'"<<id<<"\')\""; return os; }
    ::std::ostream& tbaid(::std::ostream &os)   const { os<<"id=\"tbatog"<<id<<"\""; return os; }
    ::std::string d() const { return ::std::string(display?"-":"+"); }
    ::std::string t() const 
       { 
        if (cls.empty()) return title;
        return ::std::string("<SPAN class=\"") + cls + ::std::string("\">") + title + ::std::string("</SPAN>");
       }


    ~CHtmlStartBox() { ++id; }
}; // struct CHtmlStartBox


inline
::std::ostream& operator<<(::std::ostream &os, const CHtmlStartBox &b)
   {
    os<<"<SPAN class=\"boxtoggle\" " //; b.onclick(os)<<
        ">[<A class=\"togglemark\" "; b.tbaid(os)<<" "; b.onclick(os)<<">"<<b.d()<<"</A>]</SPAN>\n"
        "<SPAN class=\"boxtitle\" "; b.onclick(os)<<">"<<b.t()<<"</SPAN><BR>\n"
        //"<SPAN class=\"boxtitle\">[<A class\"atoggle\" id=\"tbatog"<<b.id<<"\" onclick=\"return ToggleBox(\'"<<b.id<<"\')\" href=\"\">"<<b.title<<"</A></SPAN><BR>\n"
        "<DIV class=\"boxbody\" id=\"tbdtog"<<b.id<<"\" style=\"DISPLAY: "<<(b.display?"block":"none")<<"\">";
    return os;
   }

struct CHtmlEndBox
{
    CHtmlEndBox() {}
}; // struct CHtmlEndBox

inline
::std::ostream& operator<<(::std::ostream &os, const CHtmlEndBox &e)
   {
    os<<"</DIV>\n";
    return os;
   }



//-----------------------------------------------------------------------------
struct CSlnAltersHtmlPrint
{
    ::std::ostream& os;
    int             &idNo;
    CSlnAltersHtmlPrint(::std::ostream& o, int &i) : os(o), idNo(i) {}
    CSlnAltersHtmlPrint(const CSlnAltersHtmlPrint &p) : os(p.os), idNo(p.idNo) {}

    template <typename TPair>
    void operator()(TPair p)
       {
        os<<CHtmlStartBox(idNo, p.first, false)<<"\n";
        //os<<"<P>"<<p.first<<"</P>\n";
        os<<"<P>\n<UL>";
        ::std::map< ::std::string, ::std::string >::const_iterator it = p.second.begin();
        for(; it!=p.second.end(); ++it)
           {                    //it->second
            os<<"<LI>"<<it->first<<" - "<<CHtmlLink(it->second,  /* getFile */ ltrimDots(it->second))<<"</LI>\n";
            
            //getFile()<< CHtmlLink(it->second, it->first)<<"</LI>"; //"<A href=\">"<<it->second<<"\">"<<it->first<<"</A></LI>\n";
            //os<<"   "<<p.first<<" - "<<it->first<<": "<<it->second<<"\n";
           }
        os<<"</UL>\n</P>\n";
        os<<CHtmlEndBox()<<"\n";
       }


}; // struct CSlnAltersHtmlPrint

//-----------------------------------------------------------------------------
inline 
void updateProjectPaths( ::std::vector<mbs::doc::CSolutionInfo> &solutionsInfo
                       , const ::std::string &buildRoot
                       , const ::std::string &win32buildPath
                       , const ::std::string &srcPath
                       )
   {
    ::std::vector<mbs::doc::CSolutionInfo>::iterator it = solutionsInfo.begin();
    for(; it!=solutionsInfo.end(); ++it)
       {
        it->updateProjectPaths( buildRoot, win32buildPath, srcPath );
       }
   }


::std::ostream& generateHtmlSummary( ::std::ostream &os, const ::std::vector<mbs::doc::CSolutionInfo> &solutionsInfo);



}; // namespace doc
}; // namespace mbs




#endif /* MBS_PRJINFO_H */

