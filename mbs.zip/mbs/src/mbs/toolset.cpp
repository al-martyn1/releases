// warning C4748: /GS can not protect parameters and local variables from local buffer overrun because optimizations are disabled in function
#if defined(_MSC_VER) && _MSC_VER>=1400
#pragma warning (disable : 4748)
#endif

// #include <boost/algorithm/string/trim.hpp>
// #include <boost/algorithm/string/predicate.hpp>
// #include <boost/regex.hpp>

#ifndef BOOST_STRING_TRIM_HPP
    #include <boost/algorithm/string/trim.hpp>
#endif

#ifndef BOOST_STRING_CASE_CONV_HPP
    #include <boost/algorithm/string/case_conv.hpp>
#endif

#ifndef BOOST_STRING_SPLIT_HPP
    #include <boost/algorithm/string/split.hpp>
#endif

#include <boost/algorithm/string/join.hpp>

#include "toolset.h"
#include "util.h"

#include "mbsconf.h"

//-----------------------------------------------------------------------------
namespace mbs
{

namespace toolset
{


//-----------------------------------------------------------------------------
void makeGoodVersionString(std::string &substr)
   {
    if (substr.size()>1) return;
    std::string res(2-substr.size(), '0');
    res.append(substr);
    res.swap(substr);
   }

struct CMakeGoodVersionString
{
inline void operator()(std::string &substr) { makeGoodVersionString(substr); }
};
//-----------------------------------------------------------------------------
void makeGoodVersionString(std::vector<std::string> &ver)
   {
    if (ver.size()==1)       ver.push_back(std::string());
    else if (ver.size()==3)  ver.push_back(std::string());
    //std::vector<std::string>::iterator it = ver.begin();
    for_each(ver.begin(), ver.end(), CMakeGoodVersionString());
   }

//-----------------------------------------------------------------------------
void makePlatformMacroses( std::map<std::string, std::string> &macroses
                         , const CPlatformHostTarget &platformHostTarget
                         , const CMbsPlatformInfo &pInfo
                         )
   {
    // moved from mak.cpp::CMakefileInfo::generateMakefile

    std::string realName = ::boost::algorithm::trim_copy(pInfo.realName);
    if (realName.empty())
       macroses["PlatformName"]     = platformHostTarget.targetPlatform; // *targetPlatformIt; //makeUnix(platformName); 
    else
       {
        macroses["PlatformName"]    = platformHostTarget.targetPlatform; // *targetPlatformIt; //makeUnix(platformName); 
        macroses["PlatformRealName"]= realName; // *targetPlatformIt; //makeUnix(platformName);
       }

    macroses["HostPlatformName"] = platformHostTarget.hostPlatform;

    if (platformHostTarget.hostPlatform.empty() || platformHostTarget.targetPlatform==platformHostTarget.hostPlatform)
       {
        macroses["PlatformHostTargetName"]    = platformHostTarget.targetPlatform; // *targetPlatformIt; //makeUnix(platformName); 
       }
    else
       {
        macroses["PlatformHostTargetName"]    = platformHostTarget.targetPlatform
                                              + ::std::string("(")
                                              + platformHostTarget.hostPlatform
                                              + ::std::string(")");
       }

    std::string os, cpu, kernelVer, distr, distrVer;
    if (!splitPlatformName( platformHostTarget.targetPlatform, os, cpu, kernelVer, distr, distrVer))
       {
        macroses["PLATFORMOS"] = "PLATFORMOS_UNKNOWN";
       }
    else
       {
        macroses["PLATFORMOS"] = ::boost::algorithm::to_upper_copy(os);

        ::boost::algorithm::trim(cpu);
        if (cpu.empty())
           macroses["PLATFORMMACHINE"] = "MACHINE_UNKNOWN";
        else
           macroses["PLATFORMMACHINE"] = std::string("MACHINE_") + ::boost::algorithm::to_upper_copy(cpu);

        std::vector<std::string> kernelVerVec;
        if (splitVersionString( kernelVer, kernelVerVec))
           {
            makeGoodVersionString(kernelVerVec);
            if (kernelVerVec.size()>=2)
               macroses["PLATFORMOSVER"] = std::string("0x") + kernelVerVec[0] + kernelVerVec[1];
            if (kernelVerVec.size()>=4)
               macroses["PLATFORMOSVERPATCH"] = std::string("0x") + kernelVerVec[2] + kernelVerVec[3];
           }


/*
        
        

        if (splitVersionString( kernelVer, kernelVerVec))
           {
           }
*/
       }
    //std::string fnCopy      = ::boost::algorithm::to_lower_copy(fn);
   }

/* winnt.h 6545
#define IMAGE_FILE_MACHINE_UNKNOWN           0
#define IMAGE_FILE_MACHINE_I386              0x014c  // Intel 386.
#define IMAGE_FILE_MACHINE_R3000             0x0162  // MIPS little-endian, 0x160 big-endian
#define IMAGE_FILE_MACHINE_R4000             0x0166  // MIPS little-endian
#define IMAGE_FILE_MACHINE_R10000            0x0168  // MIPS little-endian
#define IMAGE_FILE_MACHINE_WCEMIPSV2         0x0169  // MIPS little-endian WCE v2
#define IMAGE_FILE_MACHINE_ALPHA             0x0184  // Alpha_AXP
#define IMAGE_FILE_MACHINE_SH3               0x01a2  // SH3 little-endian
#define IMAGE_FILE_MACHINE_SH3DSP            0x01a3
#define IMAGE_FILE_MACHINE_SH3E              0x01a4  // SH3E little-endian
#define IMAGE_FILE_MACHINE_SH4               0x01a6  // SH4 little-endian
#define IMAGE_FILE_MACHINE_SH5               0x01a8  // SH5
#define IMAGE_FILE_MACHINE_ARM               0x01c0  // ARM Little-Endian
#define IMAGE_FILE_MACHINE_THUMB             0x01c2
#define IMAGE_FILE_MACHINE_AM33              0x01d3
#define IMAGE_FILE_MACHINE_POWERPC           0x01F0  // IBM PowerPC Little-Endian
#define IMAGE_FILE_MACHINE_POWERPCFP         0x01f1
#define IMAGE_FILE_MACHINE_IA64              0x0200  // Intel 64
#define IMAGE_FILE_MACHINE_MIPS16            0x0266  // MIPS
#define IMAGE_FILE_MACHINE_ALPHA64           0x0284  // ALPHA64
#define IMAGE_FILE_MACHINE_MIPSFPU           0x0366  // MIPS
#define IMAGE_FILE_MACHINE_MIPSFPU16         0x0466  // MIPS
#define IMAGE_FILE_MACHINE_AXP64             IMAGE_FILE_MACHINE_ALPHA64
#define IMAGE_FILE_MACHINE_TRICORE           0x0520  // Infineon
#define IMAGE_FILE_MACHINE_CEF               0x0CEF
#define IMAGE_FILE_MACHINE_EBC               0x0EBC  // EFI Byte Code
#define IMAGE_FILE_MACHINE_AMD64             0x8664  // AMD64 (K8)
#define IMAGE_FILE_MACHINE_M32R              0x9041  // M32R little-endian
#define IMAGE_FILE_MACHINE_CEE               0xC0EE

*/


//-----------------------------------------------------------------------------
bool splitVersionString( const std::string &verString
                      , std::vector<std::string> &ver
                      )
   {
    if (verString.empty()) return false;
    ::boost::algorithm::split(ver, verString, util::isExactChar<'.'>(), boost::algorithm::token_compress_off);
    if (ver.size()==1 && ver[0].empty()) ver.erase(ver.begin());
    return !ver.empty();
   }

//-----------------------------------------------------------------------------
bool splitPlatformName( const std::string &platformName
                      , ::std::vector< std::string > &platformNameParts
                      )
   {
    ::boost::algorithm::split(platformNameParts, platformName, util::isExactChar<'-'>(), boost::algorithm::token_compress_off);
    if (platformNameParts.empty()) return false;
    return true;
   }

bool splitPlatformName( const std::string &platformName
                      , std::string &os
                      , std::string &cpu
                      , std::string &kernelVer
                      , std::string &distr
                      , std::string &distrVer
                      )
   {
    std::vector<std::string> parts;
    if (!splitPlatformName(platformName, parts)) return false;
    if (parts.size()>0) os        = parts[0];
    if (parts.size()>1) cpu       = parts[1];
    if (parts.size()>2) kernelVer = parts[2];
    if (parts.size()>3) distr     = parts[3];
    if (parts.size()>4) distrVer  = parts[4];
    return true;
    /*
    std::vector<std::string> res;
    boost::regex pat( "([^\-]*)" );
    std::string::const_iterator start = platformName.begin(), platformName = sln.end();
    boost::match_results<std::string::const_iterator> found;
    boost::match_flag_type flags = boost::match_default;

    while(boost::regex_search(start, end, found, pat, flags))
       {

        CMsvcProjectInfo prjInfo; // foundProjects[0] - all string matched
        // foundProjects[1] - unknown guid
        prjInfo.slnName         = std::string(foundProjects[2].first, foundProjects[2].second);
        prjInfo.slnRelativePath = std::string(foundProjects[3].first, foundProjects[3].second);
        prjInfo.uid             = std::string(foundProjects[4].first, foundProjects[4].second);
        std::string projectInnerInfo = ::boost::algorithm::trim_copy(std::string(foundProjects[5].first, foundProjects[5].second));




    boost::smatch matches;
    std::string strSlnSignPat = "(.*)-(.*)-(.*)-(.*)-(.*)-(.*)-(.*)-(.*)-(.*)-(.*)";
    boost::regex slnSignPat( strSlnSignPat );
    if (boost::regex_match(sln, slnSignMatches, slnSignPat))
        {
         slnVerMajor = slnSignMatches[1];
         slnVerMinor = slnSignMatches[2];
         //std::cout<<"Solution file version: "<<slnVerMajor<<"."<<slnVerMinor<<"\n";
         //std::cout << matches[2] << std::endl;
        }
    */
   }

//-----------------------------------------------------------------------------
inline 
void addVerPart(const std::string &part, std::string &res, bool useRegex)
   {
    if (part.empty())
       {
        if (useRegex)
           res.append("(?.*?)");
        else
           { // nothing to append
           }
       }
    else
       {
        res.append(part);
       }
   }

//-----------------------------------------------------------------------------
std::string makeCanonicalPlatformName(const std::string &platformName)
   {
    std::string os, cpu, kernelVer, distr, distrVer;
    if (!splitPlatformName( platformName, os, cpu, kernelVer, distr, distrVer))
       return platformName;
    return boost::algorithm::trim_right_copy_if(mergePlatformName( os, cpu, kernelVer, distr, distrVer), util::isExactChar<'-'>());
   }

//-----------------------------------------------------------------------------
void reverseVector(std::vector<std::string> &vec)
   {
    std::vector<std::string> res;
    std::copy(vec.rbegin(), vec.rend(), std::back_inserter(res) );
    res.swap(vec);
   }

//-----------------------------------------------------------------------------
void builVersionVector(const std::vector<std::string> &verVec, std::vector<std::string> &resVec)
   {
    std::string res;
    std::vector<std::string>::const_iterator it = verVec.begin();
    for(; it!=verVec.end(); ++it)
       {
        if (!res.empty()) res.append(1, '.');
        res.append(*it);
        if (!res.empty()) resVec.push_back(res);
       }
    reverseVector(resVec);
   }

//-----------------------------------------------------------------------------
void builVersionVectorInplace(std::vector<std::string> &verVec)
   {
    std::vector<std::string> tmp;
    builVersionVector(verVec, tmp);
    tmp.swap(verVec);
   }

//-----------------------------------------------------------------------------
bool buildPrefferedPlatformsVector( const std::string &platformName
                                  , std::vector<std::string> &vec
                                  , std::vector<std::string> &reverceVec
                                  , bool useRegex)
   {
    std::string os, cpu, kernelVer, distr, distrVer;
    if (!splitPlatformName(platformName, os, cpu, kernelVer, distr, distrVer))
       return false;


    vec.clear();
    reverceVec.clear();
    //reverceVec.reserve(8);

    std::vector<std::string> kernelVerVec, distrVerVec;
    splitVersionString( kernelVer, kernelVerVec);
    splitVersionString( distrVer , distrVerVec);

    builVersionVectorInplace(kernelVerVec);
    builVersionVectorInplace(distrVerVec);

/*
    std::string res = os;
    reverceVec.push_back(res);
    if (!cpu.empty() || !kernelVerVec.empty() || !distr.empty() || !distrVerVec.empty())
       res.append(1, '-');
    addVerPart(cpu, res, useRegex);
    reverceVec.push_back(res);

    if (!kernelVerVec.empty() || !distr.empty() || !distrVerVec.empty())
       res.append(1, '-');

    std::vector<std::string>::const_iterator it = kernelVerVec.begin();
    for(; it!=kernelVerVec.end(); ++it)
       {
        std::string tmp = res + *it;
        reverceVec.push_back(res);
        if (distr.empty() && distrVerVec.empty()) continue;
        if (!distr.empty() || !distrVerVec.empty())
           res.append(1, '-');
       }
*/
    reverceVec.push_back(mergePlatformName( os, "", "", "", ""));
    if (!cpu.empty())
       reverceVec.push_back(mergePlatformName( os, cpu, "", "", ""));

    {
     std::vector<std::string> tmp;
     std::vector<std::string>::iterator it = reverceVec.begin();
     for(; it!=reverceVec.end(); ++it)
        {
         std::vector<std::string>::const_reverse_iterator kit = kernelVerVec.rbegin();
         for(; kit!=kernelVerVec.rend(); ++kit)
            {
             std::string tmpos, tmpcpu, tmpkernelVer, tmpdistr, tmpdistrVer;
             splitPlatformName(*it, tmpos, tmpcpu, tmpkernelVer, tmpdistr, tmpdistrVer);
             tmpkernelVer = *kit;
             tmp.push_back(mergePlatformName( tmpos, tmpcpu, tmpkernelVer, "", ""));
            }
        }
     std::copy(tmp.begin(), tmp.end(), std::back_inserter(reverceVec));
    }

    {
     std::vector<std::string> tmp;
     std::vector<std::string>::iterator it = reverceVec.begin();
     for(; it!=reverceVec.end(); ++it)
        {
         std::vector<std::string>::const_reverse_iterator kit = distrVerVec.rbegin();
         for(; kit!=distrVerVec.rend(); ++kit)
            {
             std::string tmpos, tmpcpu, tmpkernelVer, tmpdistr, tmpdistrVer;
             splitPlatformName(*it, tmpos, tmpcpu, tmpkernelVer, tmpdistr, tmpdistrVer);
             tmpdistrVer = *kit;
             tmp.push_back(mergePlatformName( tmpos, tmpcpu, tmpkernelVer, distr, tmpdistrVer));
            }
        }
     std::copy(tmp.begin(), tmp.end(), std::back_inserter(reverceVec));
    }


    std::vector<std::string>::iterator it = reverceVec.begin();
    for(; it!=reverceVec.end(); ++it)
       {
        boost::algorithm::trim_right_if(*it, util::isExactChar<'-'>());
       }
    
    std::copy(reverceVec.rbegin(), reverceVec.rend(), std::back_inserter(vec));

// cfg_line = ::boost::algorithm::trim_copy(cfg_line); //trim(cfg_line);  

    //mergePlatformName( os, cpu, kernelVer, distr, distrVer)
    
    //, distrVerVec;
    //if ()

    /*
    std::string res = os;
    reverceVec.push_back(res);
    res.append(1, '-');

    addVerPart(cpu, res, useRegex);
    reverceVec.push_back(res);
    res.append(1, '-');

    std::vector<std::string>::const_iterator kit = kernelVerVec.begin();
    for(; kit!=kernelVerVec.end(); ++kit)
       {
        if (kit!=kernelVerVec.begin()) res.append(1, '.');
        res.append(*kit);
        reverceVec.push_back(res);
       }
    if (kernelVerVec.empty())
       {
        addVerPart("", res, useRegex);
        reverceVec.push_back(res);
       }
    res.append(1, '-');

    addVerPart(distr, res, useRegex);
    reverceVec.push_back(res);
    res.append(1, '-');

    kit = distrVerVec.begin();
    for(; kit!=distrVerVec.end(); ++kit)
       {
        if (kit!=distrVerVec.begin()) res.append(1, '.');
        res.append(*kit);
        reverceVec.push_back(res);
       }
    if (distrVerVec.empty())
       {
        addVerPart("", res, useRegex);
        reverceVec.push_back(res);
       }

    vec.reserve(reverceVec.size());
    std::vector<std::string>::const_reverse_iterator rit = reverceVec.rbegin();
    for(; rit!=reverceVec.rend(); ++rit)
       {
        vec.push_back(*rit);
       }
    */
    return true;
   }





}; // namespace toolset

}; // namespace mbs

