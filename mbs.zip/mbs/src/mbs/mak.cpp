// warning C4748: /GS can not protect parameters and local variables from local buffer overrun because optimizations are disabled in function
#if defined(_MSC_VER) && _MSC_VER>=1400
#pragma warning (disable : 4748)
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#if !defined(_FSTREAM_) && !defined(_STLP_FSTREAM) && !defined(__STD_FSTREAM__) && !defined(_CPP_FSTREAM) && !defined(_GLIBCXX_FSTREAM)
    #include <fstream>
#endif

#if !defined(_SSTREAM_) && !defined(_STLP_SSTREAM) && !defined(__STD_SSTREAM__) && !defined(_CPP_SSTREAM) && !defined(_GLIBCXX_SSTREAM)
    #include <sstream>
#endif

#if !defined(_MEMORY_) && !defined(_STLP_MEMORY) && !defined(__STD_MEMORY__) && !defined(_CPP_MEMORY) && !defined(_GLIBCXX_MEMORY)
    #include <memory>
#endif


#if !defined(_UTILITY_) && !defined(_STLP_UTILITY) && !defined(__STD_UTILITY__) && !defined(_CPP_UTILITY) && !defined(_GLIBCXX_UTILITY)
    #include <utility>
#endif

#ifndef BOOST_STRING_TRIM_HPP
    #include <boost/algorithm/string/trim.hpp>
#endif

#ifndef BOOST_STRING_PREDICATE_HPP
    #include <boost/algorithm/string/predicate.hpp>
#endif

#ifndef BOOST_STRING_CASE_CONV_HPP
    #include <boost/algorithm/string/case_conv.hpp>
#endif

#ifndef BOOST_RE_REGEX_HPP
    #include <boost/regex.hpp>
#endif

#include <marty/winapi.h>
#include <marty/filename.h>
#include <marty/utf.h>
#include <marty/concvt.h>


#ifdef USE_MARTY_NAMESPACE
using namespace ::marty;
#endif



#include "slnparse.h"

#include "makealgo.h"
#include "vcproj.h"
#include "mak.h"
#include "util.h"
#include "mkutil.h"
#include "mbsconf.h"
#include "scansrc.h"
#include "text-fmt.h"



//extern bool opQuet;
extern int opDetailed;

namespace mbs
{

using filename::makeCanonical;
using filename::getName;
using filename::getPath;
using filename::getExtention;
using filename::appendExtention;
using filename::appendPath;
using filename::changeExtention;
using filename::changePathChars;
using filename::changePathCharsCopy;


bool useSolutionNameVar = true;



inline ::std::string upperCase(const ::std::string &str)
   {
    return MARTY_NS filename::utils:: upperCase( str, MARTY_NS filename::utils::makeCurrentLocale() );
   }

/*
CMakefileInfo::CMakefileInfo(const CMsvcProjectInfo &info)
   : orgRelativePath( info.slnRelativePath )
   , relativePath   ( filename::getPathName(info.slnRelativePath))
   , targetName     (info.prjName)
   , configurations ()

   , sourceFiles    (info.prjSourceFiles)
   , headerFiles    (info.prjHeaderFiles)
   , generatedFiles (info.prjGeneratedFiles)
   , formFiles      (info.prjFormFiles)

   , dependencies   ()
   {
    using ::boost::algorithm::to_lower_copy;
    using ::boost::algorithm::starts_with;


    std::vector<CMsvcProjectConfigurationInfo>::const_iterator confIt = info.prjConfigurations.begin();
    for(; confIt!=info.prjConfigurations.end(); ++confIt)
       {
        if (!starts_with(to_lower_copy(confIt->PlatformOnly), _T("win")))
           continue;

        CMakefileTargetConfigurationInfo  targetConf;

        targetConf.name = to_lower_copy(confIt->NameOnly);
        std::transform(targetConf.name.begin(), targetConf.name.end(), targetConf.name.begin(), util::CSpaceTransformator());

        targetConf.OutputDirectory       = confIt->OutputDirectory;
        targetConf.IntermediateDirectory = confIt->IntermediateDirectory;

        if (confIt->ConfigurationType==CONFIGURATION_TYPE_OUTPUT_EXE)
           targetConf.outputType = "exe";
        else if (confIt->ConfigurationType==CONFIGURATION_TYPE_OUTPUT_DLL)
           targetConf.outputType = "dll";
        else if (confIt->ConfigurationType==CONFIGURATION_TYPE_OUTPUT_LIB)
           targetConf.outputType = "lib";
        else
           targetConf.outputType = "unknown-output-type";

        targetConf.subsystem = SUBSYSTEM_CONSOLE;

        const CMsvcToolInfo* pLinkerTool = confIt->getToolInfo("VCLinkerTool");
        if (pLinkerTool)
           {
            if (!pLinkerTool->ModuleDefinitionFile.empty())
               targetConf.moduleDefinitionFile = pLinkerTool->ModuleDefinitionFile;
            targetConf.subsystem = pLinkerTool->SubSystem;
           }

        configurations.push_back(targetConf);
       }
   
   }
*/

/*
inline
std::string makeUnix(const std::string &path)
   {
    return makeCanonical(path, PATH_SEPARATORS, '/');
   }
*/
//-----------------------------------------------------------------------------
inline 
void makeDirectoryMakCommands( std::ostream &of
                             , const std::string &dir
                             , const std::string &mkdirCmd
                             , const CMbsHostPlatformOptions &hostPlatformOptions
                             , std::map<std::string, std::string> macroses
                             )
   {
    if (hostPlatformOptions.makeOptions.mkdirSupportForceCreate)
       {
        macroses["MkdirParam"] = dir;
        //macroses[] = upperCase();
        of<<"\t"<<makeMakCommands(substMacroses(macroses, mkdirCmd))<<"\n\n";
       }
    else
       {
        char pathSep = hostPlatformOptions.getPathSeparator();
        std::vector< std::string > pathParts;
        filename::splitPath(dir, pathParts);
        std::vector< std::string >::const_iterator pit = pathParts.begin();
        for(; pit!=pathParts.end(); )
           {
            if (pit->empty() || *pit=="." || *pit=="..") { ++pit; continue; }
            std::vector< std::string >::const_iterator tmpIt = pathParts.begin();
            std::string curPath = filename::mergePath<char, ::std::char_traits<char>, ::std::allocator<char> >(tmpIt, ++pit, pathSep);
            if (curPath.empty()) continue;
            macroses["MkdirParam"] = curPath;
            //macroses[] = upperCase();
            of<<"\t"<<makeMakCommands(substMacroses(macroses, mkdirCmd))<<"\n";
           }
        of<<"\n";
       }
   }

inline
void commandListRemoveLeadingAt(std::string &cmdlist)
   {
    txt::util::processTextLines(cmdlist, std::string("\\n"), txt::util::CLineTrimAndRemoveLeadingChar('@') );

    /*
    std::vector<std::string> lines;
    txt::util::splitTextToLines(lines, cmdlist);
    std::string resCmd; resCmd.reserve(cmdlist.size());
    std::vector<std::string>::const_iterator lit = lines.begin();
    for(; lit!=lines.end(); ++lit)
       {
        if (!resCmd.empty()) resCmd.append("\\n");
        std::string line = boost::algorithm::trim_copy(*lit);
        if (line.empty()) continue;
        if (line[0]=='@')
           resCmd.append(line, 1, line.npos);
        else
           resCmd.append(line);
       }
    resCmd.swap(cmdlist);
    */
   }

//-----------------------------------------------------------------------------
/*
inline 
void makeShellCallCommands( std::ostream &of
                          , const std::string &dir
                          , const std::string &shellCallCmd
                          , const CMbsHostPlatformOptions &hostPlatformOptions
                          , std::map<std::string, std::string> macroses
                          )
   {
    char pathSep = hostPlatformOptions.getPathSeparator();
    std::vector< std::string > pathParts;
    filename::splitPath(dir, pathParts);
    std::vector< std::string >::const_iterator pit = pathParts.begin();
    for(; pit!=pathParts.end(); )
       {
        if (pit->empty() || *pit=="." || *pit=="..") { ++pit; continue; }
        std::string curPath = filename::mergePath(pathParts.begin(), ++pit, pathSep);
        if (curPath.empty()) continue;
        macroses["MkdirParam"] = curPath;
        of<<"\t"<<makeMakCommands(substMacroses(macroses, mkdirCmd))<<"\n";
       }
    of<<"\n";
   }
*/

//-----------------------------------------------------------------------------
bool CMakefileSolutionInfo::generateScripts( 
                      const CToolset &toolset
                    , const CMbsHostPlatformOptions &hostPlatformOptions
                    , const CMbsConfig &mainConf
                    , const std::string &basePath
                    , const mbs::CPlatformHostTarget &platforms
                    , const mbs::CPlatformHostTarget &foundPlatforms
                    , const CMbsPlatformInfo &pInfo
                    , const std::string &sourceSlnFileName
                    , const std::string &originalPlatformTargetHostNames
                    , std::string &resultScriptFileName
                    , std::map<std::string, std::string> macroses
                    , bool saveMaks
                    , cb::CWorkspace &cbWs
                    , std::vector<cb::CProjectInfo> &cbProjects
                    , mbs::CProjectSrcInfoCache &prjSourcesInfoCache
                    , mbs::doc::CSolutionInfo &docSln
                    ) const
   {
    /*
    const CProjectSrcInfo *pPrjSrcInfo = 0;
    if (!pPrjSrcInfo)
       {
        pPrjSrcInfo = prjSourcesInfoCache.getSrcInfo(sourceFile);
        if (pPrjSrcInfo)
           {
            std::cout<<"Project info found in "<<sourceFile<<"\n"; //Description: "<<pPrjSrcInfo->description<<"\n";
            std::cout<<*pPrjSrcInfo<<"\n";
            pDocPrj->entrySource = relSrcFilename; //sourceFile;
           }
       }
    */

    char pathSep = hostPlatformOptions.getPathSeparator();
    char optListSep = hostPlatformOptions.getOptListSeparator();

    macroses["PSEP"] = std::string(1, pathSep);
    macroses["LSEP"] = std::string(1, optListSep);

    std::string vars;
    mainConf.findAllVars(toolset.name, foundPlatforms.hostPlatform, foundPlatforms.targetPlatform, vars);
    varsToMacroses( vars, macroses);

    //std::string &resultScriptFileName

    // resultScriptFileName = filename::appendPath(platforms.targetPlatform, changeExtention(sourceSlnFileName, hostPlatformOptions.shellExt()));
    resultScriptFileName = filename::appendPath(originalPlatformTargetHostNames, changeExtention(sourceSlnFileName, hostPlatformOptions.shellExt()));
    
    
    std::string relPath  = filename::getPath(sourceSlnFileName);
    relPath              = filename::stripSlashCopy(relPath);

    std::string fullname = filename::appendPath(basePath, resultScriptFileName);

    //std::cout<<"fullname: "<<fullname<<"\n";
    if (fullname.empty())
       {
        std::cout<<"Invalid (empty) output file name\n";
        return false;
       }

    fullname = //makeCanonical(
                        changeExtention(fullname, hostPlatformOptions.shellExt())
               //        PATH_SEPARATORS, pathSep)
                         ;
    cbWs.workspaceFilename = changeExtention(fullname, ".workspace");
    cbWs.name = changePathCharsCopy( getName(sourceSlnFileName), "\\/", '_');

    winapi::forceCreateDirectory(filename::stripSlashCopy(filename::getPath( MARTY_FILENAME::makeCanonical(fullname) )));

    std::string slnName = 
    //std::string relPath  = 
    filename::getPathName(sourceSlnFileName);

    docSln.name = slnName;

    std::ostream  *pOstream = 0;
    std::auto_ptr<std::ofstream> pOfstream(0);
    std::ostringstream oss;

    if (saveMaks)
       {
        using namespace std; // ios_base;
        ios_base::openmode mode = (hostPlatformOptions.makeOptions.useCrLf>0) 
                                ? (ios_base::out | ios_base::trunc) // CRLF used
                                : (ios_base::out | ios_base::trunc | ios_base::binary);

        if (opDetailed>8)
           {
            if (hostPlatformOptions.makeOptions.useCrLf>0)
               std::cout<<"Used CRLF eol for solution script\n";
            else
               std::cout<<"Used LF-only eol for solution script\n";
           }

        //docSln.alternateSolutionFiles[platforms.targetPlatform + ::std::string(" ") + slnName] = fullname;

        //// UNDONE: need to create dir
        //winapi::forceCreateDirectory(filename::stripSlashCopy(filename::getPath(fullname)));

        pOfstream.reset(new std::ofstream(fullname.c_str(), mode));
        std::ofstream &of = *pOfstream;
        if (!of)
           {
            std::cout<<"Failed to open output file: "<<fullname<<"\n";
            return false;
           }
        pOstream = pOfstream.get();
       }
    else
       {
        pOstream = &oss;
       }

    std::ostream &of = *pOstream;


    //docSln.solutionFile = sourceSlnFileName;
    //docSln.name         = slnName;
    
    //std::string chdir = 
    //of<<"#!/bin/bash\n\n";
    of<<hostPlatformOptions.shellScriptHeader(filename::getFile(fullname)); // /* <<hostPlatformOptions.shellCommentStart() */ <<"\n";
    of<<hostPlatformOptions.silentOn()<<"\n";
    of<<hostPlatformOptions.shellCommentStart()<<"Solution      : "<<makeCanonical(slnName, PATH_SEPARATORS, pathSep)<<"\n";
    of<<hostPlatformOptions.shellCommentStart()<<"Generated from: "<<makeCanonical(sourceSlnFileName, PATH_SEPARATORS, pathSep)<<"\n"<<hostPlatformOptions.shellCommentStart()<<"\n";
    of<<hostPlatformOptions.shellCommentStart()<<"Generated with: mbs::slnconv\n";
    of<<hostPlatformOptions.shellCommentStart()<<"Automaticaly generated, do not edit\n"<<hostPlatformOptions.shellCommentStart()<<"\n";

    std::string shellCallTool;
    //if (!toolset.getTool("shell-call", shellCallTool))
    toolset.getTool("shell-call", shellCallTool);

    {

      std::string slnPath = filename::getPath(slnName);
      //char pathSep = hostPlatformOptions.getPathSeparator();
      std::vector< std::string > pathParts;
      filename::splitPath(slnPath, pathParts);

      /*

      std::string incPath = ".."; incPath.append(1, pathSep); incPath.append(".."); incPath.append(1, pathSep);
      std::vector< std::string >::size_type i = 0, size = pathParts.size();
      for(; i<size; ++i)
         {
          //if (!incPath.empty()) 
          incPath.append("..");
          incPath.append(1, pathSep);
         }        

      std::string libPath = incPath;
      incPath.append("include");
      libPath.append("lib");
      */
      // TEST
      // ���� ����� �� ��������� � ��� �� ��� ������ ����
      //std::string dotsPath = makeDotsPath(slnPath, pathSep, 2); 
      //std::string incPath = appendPath(dotsPath, "include", PATH_SEPARATORS, pathSep)
      std::string incPath = makeDotsPath(slnPath, pathSep, 2, std::string("include")); 
      std::string libPath = makeDotsPath(slnPath, pathSep, 2, std::string("lib"));
      macroses["MBS_ROOT_LIB_PATH"] = libPath;
      macroses["MBS_INCLUDE_PATH"]  = incPath;
      
      if (hostPlatformOptions.useBatFilesSyntax())
         {
          of<<hostPlatformOptions.shellCommentStart()<<" Do not change MBS_ROOT_LIB_PATH - it must points to only alone dir\n";
          of<<"set MBS_ROOT_LIB_PATH="<<libPath<<"\n";

          of<<hostPlatformOptions.shellCommentStart()<<" Add more library dirs to MBS_LIB_PATH as \"set MBS_LIB_PATH=%MBS_LIB_PATH%;more_lib_dirs\" in config.bat, use ';' as separator\n";
          of<<"set MBS_LIB_PATH="<<libPath<<"\n";

          of<<hostPlatformOptions.shellCommentStart()<<" Add more include dirs in config.bat, use ';' as separator\n";
          of<<"set MBS_INCLUDE_PATH="<<incPath<<"\n";

          of<<"set MBS_EXT_CC_OPTIONS=\n";
          of<<"set MBS_EXT_CXX_OPTIONS=\n";
          of<<"set MBS_EXT_LINKER_OPTIONS=\n";
         }
      else
         {
          of<<hostPlatformOptions.shellCommentStart()<<" Do not change MBS_ROOT_LIB_PATH - it must points to only alone dir\n";
          of<<"MBS_ROOT_LIB_PATH="<<libPath<<"\n";

          of<<hostPlatformOptions.shellCommentStart()<<" Add more library dirs to MBS_LIB_PATH as \"MBS_LIB_PATH=$MBS_LIB_PATH:more_lib_dirs\" in config.sh, use ':' as separator\n";
          of<<"MBS_LIB_PATH="<<libPath<<"\n";

          of<<hostPlatformOptions.shellCommentStart()<<" Add more include dirs in config.sh, use ':' as separator\n";
          of<<"MBS_INCLUDE_PATH="<<incPath<<"\n";

          of<<"MBS_EXT_CC_OPTIONS=\n";
          of<<"MBS_EXT_CXX_OPTIONS=\n";
          of<<"MBS_EXT_LINKER_OPTIONS=\n";
         }

      if (!shellCallTool.empty() && !hostPlatformOptions.platformConfigScriptName.empty())
         {
          of<<"\n"<<hostPlatformOptions.shellCommentStart()<<"Call configure scripts\n";
  
          //std::string
          // filename::getPathName(sourceSlnFileName);
          std::vector<std::string> callList;
          callList.push_back(std::string(".") + std::string(1, pathSep) + hostPlatformOptions.platformConfigScriptName);
  
          std::string dotPathTmp;
          std::vector< std::string >::size_type i = 0, size = pathParts.size();
          for(; i<size; ++i)
             {
              if (!dotPathTmp.empty()) dotPathTmp.append(1, pathSep);
              dotPathTmp.append("..");
              callList.push_back(dotPathTmp + std::string(1, pathSep) + hostPlatformOptions.platformConfigScriptName);
             }        
  
          for(std::vector<std::string>::const_reverse_iterator rit = callList.rbegin(); rit!=callList.rend(); ++rit)
             {
              macroses["ShellCallParam"] = *rit;
              of<<substHash(substMacroses(macroses, shellCallTool))<<"\n";
             }
  
          of<<"\n";
         }

      ::std::string SolutionName = makeCanonical(slnName, PATH_SEPARATORS, pathSep);
      //changePathChars( SolutionName, "\\/", '_');
      if (hostPlatformOptions.useBatFilesSyntax())
         {
          of<<"set SOLUTION_NAME="<<SolutionName<<"\n";
         }
      else
         {
          of<<"SOLUTION_NAME="<<SolutionName<<"\n";
         }

      of<<hostPlatformOptions.silentOff()<<"\n";

      if (!hostPlatformOptions.useBatFilesSyntax())
         {
          of<<"export MBS_ROOT_LIB_PATH\n";
          of<<"export MBS_LIB_PATH\n";
          of<<"export MBS_INCLUDE_PATH\n";
          of<<"export MBS_EXT_CC_OPTIONS\n";
          of<<"export MBS_EXT_CXX_OPTIONS\n";
          of<<"export MBS_EXT_LINKER_OPTIONS\n";
          of<<"export SOLUTION_NAME\n\n";
         }
    }

    of<<"\n";

    std::vector<CMakefileInfo>::const_iterator mit = makefiles.begin();
    for(; mit!=makefiles.end(); ++mit)
       {
        std::string mkprojName, resultMkProjNameFull;
        cb::CProjectInfo cbProj;
        cbProj.setName(mit->targetName);
        cbProj.setPchMode(2);

        /*
        std::string srcRoot = "src/";
        //std::vector<std::string> srcFiles;
        std::vector<std::string>::const_iterator srcIt = sourceFiles.begin();
        for(; srcIt!=sourceFiles.end(); ++srcIt)
           {
            std::string::size_type prefixLen;
            std::string file;
            if (!getSubDirectoryAux(*srcIt, srcRoot, file, prefixLen))
               {
                std::cout<<"Invalid source path: '"<<*srcIt<<"'\n\tAll sources must be under 'src/' directory in project root\n";
                return false;
               }
    
            std::string relSrcFilename = makeCanonical(appendPath(dotsPath, file), PATH_SEPARATORS, pathSep);
            if (opDetailed)
               {
                std::cout<<"Src: "<<relSrcFilename<<"\n";
               }
            srcFiles.push_back(relSrcFilename);
            cbProj.addUnit( makeCanonical(relSrcFilename , PATH_SEPARATORS, pathSep)
                          , toolset.getCodeBlocksCompilerVar(relSrcFilename)
                          );
            
            std::string sourceFile = makeCanonical(filename::appendPath(getPath(resulMakFilename), relSrcFilename));
    
            if (!pPrjSrcInfo)
               {
                pPrjSrcInfo = prjSourcesInfoCache.getSrcInfo(sourceFile);
                if (pPrjSrcInfo)
                   {
                    std::cout<<"Project info found in "<<sourceFile<<"\n"; //Description: "<<pPrjSrcInfo->description<<"\n";
                    std::cout<<*pPrjSrcInfo<<"\n";
                    pDocPrj->entrySource = relSrcFilename; //sourceFile;
                   }
               }
           }

        const CProjectSrcInfo *pPrjSrcInfo = 0;
        if (!pPrjSrcInfo)
           {
            pPrjSrcInfo = prjSourcesInfoCache.getSrcInfo(sourceFile);
            if (pPrjSrcInfo)
               {
                std::cout<<"Project info found in "<<sourceFile<<"\n"; //Description: "<<pPrjSrcInfo->description<<"\n";
                std::cout<<*pPrjSrcInfo<<"\n";
                pDocPrj->entrySource = relSrcFilename; //sourceFile;
               }
           }
        */


        bool genRes = mit->generateMakefile( toolset
                                           , hostPlatformOptions
                                           , mainConf
                                           , basePath
                                           , platforms
                                           , foundPlatforms
                                           , pInfo
                                           , platforms.targetPlatform
                                           , originalPlatformTargetHostNames
                                           , slnName
                                           , mkprojName
                                           , resultMkProjNameFull
                                           , macroses
                                           , saveMaks
                                           , cbProj
                                           , prjSourcesInfoCache
                                           , docSln
                                           );

        //docSln.alternateSolutionFiles[platforms.targetPlatform + ::std::string(" ") + mkprojName] = resultMkProjNameFull;
        //docSln.alternateSolutionFiles[platforms.targetPlatform + ::std::string(" ") + mkprojName] = resultMkProjNameFull;
        //cbProj.

        if (!genRes)
           {
            continue;
           }
        else
           {
            if (opDetailed)
               {
                if (saveMaks) 
                   std::cout<<"Project makefile for : "<<mit->relativePath<<" (platform: "<<platforms.targetPlatform<<") saved into "<<resultMkProjNameFull<<"\n";
               }
           }
        //std::string mkprojPath = filename::stripSlashCopy(filename::getPath(mit->relativePath));

        std::string mkprojPath = filename::stripSlashCopy(filename::getPath(mkprojName));
        macroses["ProjectRelativePath"] = mkprojPath;
        macroses["ProjectRelativePathFileExt"] = mkprojName;
        macroses["ProjectFileExt"] = appendExtention(getName(mkprojName), getExtention(mkprojName));

        // cb::CWorkspaceProjectInfo wsPrjInfo(changeExtention(mkprojPath, ".cbp"));
        // cbWs.projects.push_back(wsPrjInfo);

        /* // wrong
        std::string cbProjectRelPath = appendPath( mkprojPath, changeExtention(mkprojName, ".cbp"));
        */
        std::string cbProjectRelPath = changeExtention(mkprojName, ".cbp");
        cb::CWorkspaceProjectInfo wsPrj( makeCanonical(cbProjectRelPath , PATH_SEPARATORS, pathSep), mit->targetName );
        std::vector<std::string>::const_iterator depIt = mit->dependencies.begin();
        for(; depIt!=mit->dependencies.end(); ++depIt)
           {
            wsPrj.addDependency(makeCanonical(changeExtention(*depIt, ::std::string(".cbp")) , PATH_SEPARATORS, pathSep) );
           }

        if (cbWs.projects.empty())
           {
            wsPrj.setActive();
           }

        cbWs.projects.push_back( wsPrj );


        cbProj.projectFilename = appendPath( getPath(cbWs.workspaceFilename), cbProjectRelPath /*, PATH_SEPARATORS, pathSep*/ );

        /*
        std::vector<std::string>::const_iterator srcIt = mit->sourceFiles.begin();
        for(; srcIt!=mit->sourceFiles.end(); ++srcIt)
           {
            cbProj.addUnit( makeCanonical(*srcIt , PATH_SEPARATORS, pathSep)
                          , toolset.getCodeBlocksCompilerVar(*srcIt));
           }
        */
        cbProjects.push_back(cbProj);
        /*
        struct CMakefileInfo
        {
            std::string                                   orgRelativePath;
            std::string                                   relativePath;
            std::string                                   targetName;
            std::vector<CMakefileTargetConfigurationInfo> configurations;
            std::vector<std::string>                      sourceFiles;
        */
        
        //cbWs.workspaceFilename = changeExtention(fullname, ".workspace");
        //cbWs.name = changePathCharsCopy( getName(sourceSlnFileName), "\\/", '_');



        std::string makeTool;
        if (!toolset.getTool("make", makeTool))
           {
            std::cout<<"Error: can't find make tool\n";
            
            return false;
           }
        of<<makeMakCommands(substMacroses(macroses, makeTool))<<"\n\n";

        /*
        of<<hostPlatformOptions.shellCommentStart()<<""<<makeCanonical(resultMkProjNameFull, PATH_SEPARATORS, pathSep)<<"\n";
        of<<"make ";
        if (!mkprojPath.empty())
           {
            of<<"--directory="<<makeCanonical(mkprojPath, PATH_SEPARATORS, pathSep)<<" ";
           }

        //of<<"-f "<<makeCanonical(mkprojName, PATH_SEPARATORS, pathSep)<<" %1\n";
        of<<"-f "<<makeCanonical(appendExtention(getName(mkprojName), getExtention(mkprojName)), PATH_SEPARATORS, pathSep)<<" %1\n";
        */
        //makeCanonical($, PATH_SEPARATORS, '/')
        //makeCanonical($, PATH_SEPARATORS, '/')

       }
    
    return true;
   }

//-----------------------------------------------------------------------------
inline
bool getSubDirectoryAux(const std::string &fn, const std::string &dirname, std::string &res, std::string::size_type &prefixLen)
   {
    std::string fnCopy1     = fn;
    std::transform(fnCopy1.begin(), fnCopy1.end(), fnCopy1.begin(), util::CSlashTransformator());

    std::string fnCopy      = ::boost::algorithm::to_lower_copy(fnCopy1);
    std::transform(fnCopy.begin(), fnCopy.end(), fnCopy.begin(), util::CSlashTransformator());

    std::string dirnameCopy = ::boost::algorithm::to_lower_copy(dirname);
    std::transform(dirnameCopy.begin(), dirnameCopy.end(), dirnameCopy.begin(), util::CSlashTransformator());
    
    std::string::size_type pos = fnCopy.find(dirnameCopy);
    if (pos==std::string::npos) return false;
    prefixLen = dirname.size();
    res = std::string(fnCopy1, pos, std::string::npos);
    return true;
   }

//-----------------------------------------------------------------------------
bool CMakefileInfo::generateMakefile( 
                           const CToolset &toolset
                         , const CMbsHostPlatformOptions &hostPlatformOptions
                         , const CMbsConfig &mainConf
                         , const std::string &basePath
                         , const mbs::CPlatformHostTarget &platforms
                         , const mbs::CPlatformHostTarget &foundPlatforms
                         , const CMbsPlatformInfo &pInfo
                         , const std::string &platformName
                         , const std::string &originalPlatformTargetHostNames
                         , const std::string &slnName
                         , std::string &resultMkProjName
                         , std::string &resultMkProjNameFull
                         , std::map<std::string, std::string> macroses
                         , bool saveMaks
                         , cb::CProjectInfo &cbProj
                         , mbs::CProjectSrcInfoCache &prjSourcesInfoCache
                         , mbs::doc::CSolutionInfo &docSln
                         ) const
   {
    char pathSep = hostPlatformOptions.getPathSeparator();
    char optListSep = hostPlatformOptions.getOptListSeparator();

    //mbs::doc::CProjectInfo *pDocPrj = docSln.getProject( cbProj.getName() );
    mbs::doc::CProjectInfo *pDocPrj = docSln.getProject( relativePath );
    

    //std::string relPath = filename::getPath(slnName);
    resultMkProjNameFull = filename::appendPath(
                                     originalPlatformTargetHostNames, // platformName,
                                     filename::appendPath(filename::getPath(slnName), relativePath)
                                               ); 
    resultMkProjNameFull = filename::changeExtention(resultMkProjNameFull, ".mkproj");
    //relPath = 
    //resultMkProjName = filename::appendPath(relPath, relativePath);
    resultMkProjName = filename::changeExtention(relativePath, ".mkproj");

    std::string resulMakFilename = filename::appendPath( basePath, resultMkProjNameFull );
    //pDocPrj->projectFile = resulMakFilename;

    //prjInfo.slnRelativePath = std::string(foundProjects[3].first, foundProjects[3].second);



    std::ostream  *pOstream = 0;
    std::auto_ptr<std::ofstream> pOfstream(0);
    std::ostringstream oss;

    if (saveMaks)
       {
        using namespace std; // ios_base;
        ios_base::openmode mode = (hostPlatformOptions.makeOptions.useCrLf>0) 
                                ? (ios_base::out | ios_base::trunc) // CRLF used
                                : (ios_base::out | ios_base::trunc | ios_base::binary);

        if (opDetailed>8)
           {
            if (hostPlatformOptions.makeOptions.useCrLf>0)
               std::cout<<"Used CRLF eol for project script\n";
            else
               std::cout<<"Used LF-only eol for project script\n";
           }

        winapi::forceCreateDirectory(filename::stripSlashCopy(filename::getPath( MARTY_FILENAME::makeCanonical(resulMakFilename) )));

        pOfstream.reset(new std::ofstream(resulMakFilename.c_str(), mode));
        std::ofstream &of = *pOfstream;
        if (!of)
           {
            std::cout<<"Failed to open output file: "<<resulMakFilename<<"\n";
            return false;
           }
        pOstream = pOfstream.get();
       }
    else
       {
        pOstream = &oss;
       }

    std::ostream &of = *pOstream;

    /*
    std::ofstream of(resulMakFilename.c_str());
    if (!of)
       {
        std::cout<<"Failed to open output file: "<<resulMakFilename<<"\n";
        return false;
       }
    else
       {
       }
    */

    std::string fromPlatformRelativePath = filename::appendPath(filename::getPath(slnName), filename::getPath(relativePath));
    //if (!useSolutionNameVar) fromPlatformRelativePath = filename::appendPath(filename::getPath(slnName), filename::getPath(relativePath));
    //else                     fromPlatformRelativePath = filename::appendPath("$(SOLUTION_NAME)", filename::getPath(relativePath));
     
    filename::stripSlashInplace(fromPlatformRelativePath);
    fromPlatformRelativePath = filename::makeCanonical(fromPlatformRelativePath);

    /*
    ::std::vector<std::string> makeFileRelPathPartsReal;
    //makeFileRelPathParts.push_back("..");
    //makeFileRelPathParts.push_back("..");
    filename::splitPath(fromPlatformRelativePath, makeFileRelPathPartsReal);
    ::std::vector<std::string> makeFileRelPathPartsDots;
    //::std::vector<std::string>::const_iterator ppIt = makeFileRelPathPartsReal.begin()
    makeFileRelPathPartsDots.push_back("..");
    makeFileRelPathPartsDots.push_back("..");

    for(::std::vector<std::string>::size_type ppi=0; ppi<makeFileRelPathPartsReal.size(); ++ppi)
       {
        makeFileRelPathPartsDots.push_back("..");
       }

    std::string dotsPath = filename::mergePath(makeFileRelPathPartsDots, '/');
    */
    // TEST
    // ���� ����� �� ��������� � ��� �� ��� ������ ����

    std::string cbCompilerToolsetName = "egcc";
       {
        std::map<std::string, std::string>::const_iterator mapIt = macroses.find("CODEBLOCKS_TOOLSET_NAME");
        if (mapIt!=macroses.end())
           {
            cbCompilerToolsetName = substMacroses(macroses, mapIt->second);
           }
       }  


    std::string dotsPath = makeDotsPath(fromPlatformRelativePath, pathSep, 2); 

    const CProjectSrcInfo *pPrjSrcInfo = 0;
    // building temporary list of source files
       {
        //::std::string compilerVar = toolset.getCodeBlocksCompilerVar(relSrcFilename);
        //::std::vector< ::std::string > confNames;
        //getConfigurationsPlainNames( confNames );

        std::string srcRoot = "src/";
        std::vector<std::string> srcFiles;
        //std::vector<std::string>::const_iterator srcIt = sourceFiles.begin();
        std::vector<CProjectFile>::const_iterator srcIt = sourceFiles.begin();
        for(; srcIt!=sourceFiles.end(); ++srcIt)
           {
            std::string::size_type prefixLen;
            std::string file;
            if (!getSubDirectoryAux(srcIt->filename, srcRoot, file, prefixLen))
               {
                std::cout<<"Invalid source path: '"<<*srcIt<<"'\n\tAll sources must be under 'src/' directory in project root\n";
                return false;
               }
    
            std::string relSrcFilename = makeCanonical(appendPath(dotsPath, file), PATH_SEPARATORS, pathSep);
            if (opDetailed)
               {
                //std::cout<<"Src: "<<relSrcFilename<<"\n";
               }
            srcFiles.push_back(relSrcFilename);

            ::std::vector< tstring > incConfigurations;
            srcIt->getIncludedConfigurations( incConfigurations );

            cbProj.addUnitWithTargets( makeCanonical(relSrcFilename , PATH_SEPARATORS, pathSep)
                                     , toolset.getCodeBlocksCompilerVar(relSrcFilename)
                                     , incConfigurations
                                     );
            
            std::string sourceFile = makeCanonical(filename::appendPath(getPath(resulMakFilename), relSrcFilename));
            // we lookup for project info in all source files regardless of its target
            if (!pPrjSrcInfo)
               {
                pPrjSrcInfo = prjSourcesInfoCache.getSrcInfo(sourceFile);
                if (pPrjSrcInfo)
                   {
                    //std::cout<<"Project info found in "<<sourceFile<<"\n"; //Description: "<<pPrjSrcInfo->description<<"\n";
                    std::cout<<*pPrjSrcInfo<<"\n";
                    pDocPrj->entrySource = relSrcFilename; //sourceFile;
                   }
               }
           }

        if (pPrjSrcInfo)
           {
            pPrjSrcInfo->converterFlagsToMacroses(macroses);
           }
        //std::vector<CProjectFile>::const_iterator 

        std::set< std::string > additionalIncludes;

        srcIt = headerFiles.begin();
        for(; srcIt!=headerFiles.end(); ++srcIt)
            cbProj.addCompileUnit( *srcIt, toolset, macroses, cbCompilerToolsetName, additionalIncludes, pathSep );

        srcIt = formFiles.begin();
        for(; srcIt!=formFiles.end(); ++srcIt)
            cbProj.addCompileUnit( *srcIt, toolset, macroses, cbCompilerToolsetName, additionalIncludes, pathSep );


        ::std::set< ::std::string >::const_iterator aiIt = additionalIncludes.begin();
        for(; aiIt!=additionalIncludes.end(); ++aiIt)
           cbProj.compiler.addDirectory(*aiIt);

 // struct CProducedFile
 // {
 //     tstring                     filename;  // produced file
 //     tstring                     buildTool;
        //for
        //CProducedFile
       } // end of building temporary list of source files


    //std::map<std::string, std::string> macroses;
    //macroses["PlatformName"] = makeCanonical(path, PATH_SEPARATORS, pathSep);(platformName); // swimed up
    ::std::string SolutionName = makeCanonical(slnName, PATH_SEPARATORS, pathSep);

    

    if (!useSolutionNameVar)
       {
        macroses["SolutionName"] = SolutionName;
        macroses["SOLUTIONNAME"] = upperCase(SolutionName);
       }
    else 
       {
        macroses["SolutionName"] = "#(SOLUTION_NAME)";
        macroses["SOLUTIONNAME"] = "#(SOLUTION_NAME)";
       }
    //if (!useSolutionNameVar) fromPlatformRelativePath = filename::appendPath(filename::getPath(slnName), filename::getPath(relativePath));
    //else                     fromPlatformRelativePath = filename::appendPath("$(SOLUTION_NAME)", filename::getPath(relativePath));

    ::std::string ProjectName = makeCanonical(targetName, PATH_SEPARATORS, pathSep);
    macroses["ProjectName"] = ProjectName;
    macroses["PROJECTNAME"] = upperCase(ProjectName);

    of<<"# "<<makeCanonical(resultMkProjNameFull, PATH_SEPARATORS, pathSep)<<"\n";
    of<<"# Generated from "<<orgRelativePath<<"\n";
    of<<"# Automaticaly generated, do not edit\n\n";


    if (pPrjSrcInfo)
       {
        of<<"# \n";

        char descrFirstChar = (pPrjSrcInfo->description.empty() ? ' ' : pPrjSrcInfo->description[0]);
        std::string text = (descrFirstChar=='+' || descrFirstChar=='-') 
                         ? std::string(pPrjSrcInfo->description, 1, pPrjSrcInfo->description.size()-1)
                         : pPrjSrcInfo->description;

        std::vector<std::string> lines;
        txt::util::splitTextToLines(lines, text);

        txt::util::CFormatOptions opts;
        opts.globalIndent    = 0;
        opts.firstLineIndent = 2;
        opts.lineIndent      = 0;
        opts.paraWidth       = 78;
        opts.formatType      = txt::util::ftLeft;

        std::string formatted = txt::util::formatText(opts, lines);

        cb::COption cbOptNote;
        cbOptNote.show_notes = descrFirstChar=='+' ? 1 : 0;

        ::std::string projectNotesUtf8 = MARTY_UTF_NS toUtf8( MARTY_CON_NS strToWide(txt::util::removeLinefeeds(formatted)) );
        pDocPrj->description = projectNotesUtf8;
        cbOptNote.notes      = projectNotesUtf8;
        cbProj.addOption(cbOptNote);
       
        lines.clear();
        txt::util::splitTextToLines(lines, formatted);

        std::vector<std::string>::const_iterator lit = lines.begin();
        for(; lit!=lines.end(); ++lit)
           {
            of<<"# "<<*lit<<"\n";
           }
        of<<"#\n\n";
       }
    


    of<<hostPlatformOptions.makeToolCondStart()<<"ifndef SOLUTION_NAME\nSOLUTION_NAME="<< /* changePathCharsCopy( */  SolutionName /* , "\\/", '_') */ <<"\n";
    of<<hostPlatformOptions.makeToolCondStart()<<"endif\n\n";

    of<<"all:";
    std::vector<CMakefileTargetConfigurationInfo>::const_iterator confIt = configurations.begin();
    for(; confIt!=configurations.end(); ++confIt)
       {
        of<<" "<<confIt->name;
       }
    of<<"\n\n";

    // include $(wildcard *.d)

    
    CPlatformSrcInfo platformSrcInfo;
    if (pPrjSrcInfo)
       {
        pPrjSrcInfo->getPlatformInfo(platformName, platformSrcInfo);
       }

    confIt = configurations.begin();
    for(; confIt!=configurations.end(); ++confIt)
       {        
        //of<<"# "<<fromPlatformRelativePath<<"\n";
        CConfigurationSrcInfo confSrcInfo;
        platformSrcInfo.getConfigurationInfo(confIt->name, confSrcInfo);

        mbs::cb::CTarget cbTarget;
        generateBuildConfiguration( toolset
                                  , hostPlatformOptions
                                  , mainConf
                                  , *confIt
                                  , platforms
                                  , foundPlatforms
                                  , pInfo
                                  , of
                                  , platformName
                                  , slnName
                                  , fromPlatformRelativePath
                                  , dotsPath
                                  //, srcFiles
                                  , macroses
                                  , cbProj
                                  , cbTarget
                                  , confSrcInfo
                                  , docSln
                                  );
        if (cbProj.compilerToolset.empty())
           {
            cbProj.compilerToolset = cbTarget.compilerToolset;
            CB_ADD_OPTION(cbProj, compiler, cbTarget.compilerToolset);
           }
        cbProj.build.addTarget(cbTarget);
       }

    //std::string mkprojPath = filename::stripSlashCopy(filename::getPath(mkprojName));


    return true;
   }

//-----------------------------------------------------------------------------
bool CMakefileInfo::generateBuildConfiguration( 
                                      const CToolset &toolset
                                    , const CMbsHostPlatformOptions &hostPlatformOptions
                                    , const CMbsConfig &mainConf
                                    , const CMakefileTargetConfigurationInfo &conf
                                    , const mbs::CPlatformHostTarget &platforms
                                    , const mbs::CPlatformHostTarget &foundPlatforms
                                    , const CMbsPlatformInfo &pInfo
                                    , std::ostream &of
                                    , const std::string &platformName
                                    , const std::string &slnName
                                    , const std::string &fromPlatformRelativePath
                                    , std::string dotsPath
                                    //, const std::vector<std::string> srcFiles
                                    , std::map<std::string, std::string> macroses
                                    , cb::CProjectInfo &cbProj
                                    , mbs::cb::CTarget &cbTarget
                                    , const CConfigurationSrcInfo &confSrcInfo
                                    , mbs::doc::CSolutionInfo &docSln
                                   ) const
   {
    std::vector<std::string> srcFiles; // UNDONE: temp var temporary replaced srcFiles parameter

    char pathSep    = hostPlatformOptions.getPathSeparator();
    char optListSep = hostPlatformOptions.getOptListSeparator();

    mbs::doc::CProjectInfo *pDocPrj = docSln.getProject( relativePath );

    // TODO: modify for other target types
    //std::string outputType = "exe";
    //std::string outputType = conf.outputType;

    std::string vars;
    mainConf.findAllVars(toolset.name, foundPlatforms.hostPlatform, foundPlatforms.targetPlatform, conf.outputType, conf.name, vars);
    varsToMacroses( vars, macroses);

    //of<<"# Output      : "<<getSubDirectoryAux(conf.OutputDirectory, "/out/")<<"\n";
    //of<<"# Intermediate: "<<getSubDirectoryAux(conf.IntermediateDirectory, "/out/")<<"\n";

    std::string::size_type prefixLen;
    const std::string out = "out/";
    const std::string bin = "bin/";
    const std::string outtmp = "out.tmp/";
    const std::string bintmp = "bin.tmp/";

    std::string outputDirectory;
    if ( !getSubDirectoryAux(conf.OutputDirectory, out, outputDirectory, prefixLen)
      && !getSubDirectoryAux(conf.OutputDirectory, bin, outputDirectory, prefixLen)
       )
       {
        std::cout<<"Failed to generate '"<<conf.name<<"' configuration for '"<< macroses["ProjectName"] /* fromPlatformRelativePath */ <<"':\n\tOutput directory must be under /out path in project root\n";
        return false;
       }

    std::string postfix = std::string(outputDirectory, prefixLen);
    if ( postfix!="$(PlatformName)/$(SolutionName)/$(ConfigurationName)"
      && postfix!="$(PlatformName)/$(ConfigurationName)"
      && postfix!="$(PlatformHostTargetName)/$(SolutionName)/$(ConfigurationName)"
      && postfix!="$(PlatformHostTargetName)/$(ConfigurationName)"
       )
       {
        std::cout<<"*** Warning: output directory is nor $(PlatformName)/$(SolutionName)/$(ConfigurationName) or $(PlatformName)/$(ConfigurationName)\n";
        std::cout<<"\t\tValue found: '"<<outputDirectory<<"'\n";
        std::cout<<"\t\tSetting output directory to out/$(PlatformName)/$(SolutionName)/$(ConfigurationName)\n";
        outputDirectory = "out/$(PlatformHostTargetName)/$(SolutionName)/$(ConfigurationName)";
       }

    ::mbs::util::replaceSubstring( outputDirectory, "$(PlatformName)", "$(PlatformHostTargetName)" );

    std::string intermediateDirectory;
    if ( !getSubDirectoryAux(conf.IntermediateDirectory, out, intermediateDirectory, prefixLen) 
      && !getSubDirectoryAux(conf.IntermediateDirectory, bin, intermediateDirectory, prefixLen)
      && !getSubDirectoryAux(conf.IntermediateDirectory, outtmp, intermediateDirectory, prefixLen)
      && !getSubDirectoryAux(conf.IntermediateDirectory, bintmp, intermediateDirectory, prefixLen)
       )
       {
        std::cout<<"Failed to generate '"<<conf.name<<"' configuration for '"<< macroses["ProjectName"] /* fromPlatformRelativePath */ <<"':\n\tIntermediate directory must be under /out or /bin or /out.tmp or /bin.tmp path in project root\n";
        return false;
       }

    postfix = std::string(intermediateDirectory, prefixLen);
    if ( postfix!="$(PlatformName)/$(SolutionName)/$(ConfigurationName)/_$(ProjectName)"
      && postfix!="$(PlatformName)/$(ConfigurationName)/_$(ProjectName)"
      && postfix!="$(PlatformHostTargetName)/$(SolutionName)/$(ConfigurationName)/_$(ProjectName)"
      && postfix!="$(PlatformHostTargetName)/$(ConfigurationName)/_$(ProjectName)"
       )
       {
        std::cout<<"*** Warning: intermediate directory is nor $(PlatformName)/$(SolutionName)/$(ConfigurationName)/_$(ProjectName) or $(PlatformName)/$(ConfigurationName)/_$(ProjectName)\n";
        std::cout<<"\t\tValue found: '"<<intermediateDirectory<<"'\n";
        std::cout<<"\t\tSetting intermediate directory to out/$(PlatformName)/$(SolutionName)/$(ConfigurationName)/_$(ProjectName)\n";
        intermediateDirectory = "out/$(PlatformHostTargetName)/$(SolutionName)/$(ConfigurationName)/_$(ProjectName)";
       }

    ::mbs::util::replaceSubstring( intermediateDirectory, "$(PlatformName)", "$(PlatformHostTargetName)" );

    of<<"\n\n\n########################################\n#### Configuration: "<<makeCanonical(conf.name, PATH_SEPARATORS, pathSep)<<"\n########################################\n\n";

    // of<<"# Output      : "<<outputDirectory<<"\n";
    // of<<"# Intermediate: "<<intermediateDirectory<<"\n";
    // of<<"# fromPlatformRelativePath: "<<fromPlatformRelativePath<<"\n";

    ::std::string ConfigurationName = changePathCharsCopy( makeCanonical(conf.name, PATH_SEPARATORS, pathSep), "\\/", '_');
    macroses["ConfigurationName"] = ConfigurationName;
    macroses["CONFIGURATIONNAME"] = upperCase(ConfigurationName);
    // macroses["ProjectName"] = 
    //macroses[""] = 

    std::string libsPrefix = substMacroses(macroses,macroses["PROJECTNAME"]+std::string("_")+macroses["CONFIGURATIONNAME"]); //+std::string("_LIBS")

    std::string additionalLibs = ::mbs::util::mergeVectorToString(confSrcInfo.libs, optListSep, ::mbs::util::CMakeGlobalVarNameConverter());
    of<<substHash(libsPrefix+std::string("_LIBS"))
      <<":=$("
      <<substHash(libsPrefix+std::string("_LIBS"))<<")";
    if (!additionalLibs.empty())
       of<<optListSep<<additionalLibs;
    of<<"\n";

    std::string additionalLibPath = ::mbs::util::mergeVectorToString(confSrcInfo.libPath, optListSep, ::mbs::util::CMakeGlobalVarNameConverter());
    of<<substHash(libsPrefix+std::string("_LIBPATH"))
      <<":=$("
      <<substHash(libsPrefix+std::string("_LIBPATH"))<<")";
    if (!additionalLibPath.empty())
       of<<optListSep<<additionalLibPath;
    of<<"\n";

    std::string additionalIncPath = ::mbs::util::mergeVectorToString(confSrcInfo.incPath, optListSep, ::mbs::util::CMakeGlobalVarNameConverter());
    of<<substHash(libsPrefix+std::string("_INCPATH"))
      <<":=$("
      <<substHash(libsPrefix+std::string("_INCPATH"))<<")";
    if (!additionalIncPath.empty())
       of<<optListSep<<additionalIncPath;
    of<<"\n";

    of<<"\n\n";


    /*
    ::std::vector<std::string> makeFileRelPathPartsReal;
    //makeFileRelPathParts.push_back("..");
    //makeFileRelPathParts.push_back("..");
    filename::splitPath(fromPlatformRelativePath, makeFileRelPathPartsReal);
    ::std::vector<std::string> makeFileRelPathPartsDots;
    //::std::vector<std::string>::const_iterator ppIt = makeFileRelPathPartsReal.begin()
    makeFileRelPathPartsDots.push_back("..");
    makeFileRelPathPartsDots.push_back("..");

    for(::std::vector<std::string>::size_type ppi=0; ppi<makeFileRelPathPartsReal.size(); ++ppi)
       {
        makeFileRelPathPartsDots.push_back("..");
       }

    std::string dotsPath = filename::mergePath(makeFileRelPathPartsDots, '/');
    */

    /*
    if (useSolutionNameVar)
       {
        macroses["SolutionName"] = "#(SOLUTION_NAME)";
        macroses["SOLUTIONNAME"] = "#(SOLUTION_NAME)";
       }
    */

    intermediateDirectory = makeCanonical(appendPath(dotsPath, substMacroses(macroses, intermediateDirectory)), PATH_SEPARATORS, pathSep);
    macroses["IntDir"] = intermediateDirectory;

    outputDirectory = makeCanonical(appendPath(dotsPath, substMacroses(macroses, outputDirectory)), PATH_SEPARATORS, pathSep);
    macroses["OutDir"] = outputDirectory;
    macroses["TargetDir"] = outputDirectory;

    // of<<"# Output      : "<<outputDirectory<<"\n";
    // of<<"# Intermediate: "<<intermediateDirectory<<"\n";
    // of<<"# fromPlatformRelativePath: "<<fromPlatformRelativePath<<"\n";

    std::vector<std::string> deps;
    std::string outdir_target = conf.name + std::string("_outdir");
    std::string intdir_target = conf.name + std::string("_intdir");

    deps.push_back(outdir_target);
    deps.push_back(intdir_target);
    //deps.push_back();

    std::string mkdirTool;
    if (!toolset.getTool("mkdir", mkdirTool))
       {
        std::cout<<"Error: can't find mkdir tool\n";
        return false;
       }

    // of<<outdir_target<<": "<<outputDirectory<<"\n\tmkdir -p "<<outputDirectory<<"\n\n";
    // of<<intdir_target<<": "<<intermediateDirectory<<"\n\tmkdir -p "<<intermediateDirectory<<"\n\n";
    of<<substHash(outdir_target)<<": "<<substHash(outputDirectory)<<"\n\n";
    of<<substHash(outputDirectory)<<":\n";

    makeDirectoryMakCommands( of, outputDirectory, mkdirTool, hostPlatformOptions, macroses);
    of<<"\n";

    /*
    if (hostPlatformOptions.makeOptions.mkdirSupportForceCreate)
       {
        macroses["MkdirParam"] = outputDirectory;
        of<<makeMakCommands(substMacroses(macroses, mkdirTool))<<"\n\n";
       }
    else
       {
        std::vector< std::string > pathParts;
        filename::splitPath(outputDirectory, )
       }
    */

    of<<substHash(intdir_target)<<": "<<substHash(intermediateDirectory)<<"\n\n";
    of<<substHash(intermediateDirectory)<<":\n";
    makeDirectoryMakCommands( of, intermediateDirectory, mkdirTool, hostPlatformOptions, macroses);
    of<<"\n";

    /*
    macroses["MkdirParam"] = intermediateDirectory;
    of<<makeMakCommands(substMacroses(macroses, mkdirTool))<<"\n\n";
    */

    std::set<std::string> objFiles;
    std::string objectFiles;
    std::vector< ::std::pair<std::string, std::string> > sourceObjects;

    std::vector<std::string>::const_iterator srcIt = srcFiles.begin();
    for(; srcIt!=srcFiles.end(); ++srcIt)
       {
        std::string fileType = toolset.getFileType(*srcIt);
        std::string objExt;
        if (!toolset.getObjectExt(fileType, objExt))
           {
            std::cout<<"Error: can't find object file info for file type '"<<fileType<<"' - file '"<<*srcIt<<"'\n";
            return false;
           }
         
        std::string objName = makeCanonical(getName(*srcIt), PATH_SEPARATORS, pathSep);

        int num = 0;
        std::string objNameExt = appendExtention(objName, objExt);
        while(objFiles.find(objNameExt)!=objFiles.end())
           {
            std::ostringstream oss;
            oss<<objName<<"~"<<num++;
            objNameExt = appendExtention(oss.str(), objExt);
           }
        std::string objFullName = makeCanonical(appendPath(intermediateDirectory, objNameExt), PATH_SEPARATORS, pathSep);
        sourceObjects.push_back(std::make_pair(*srcIt, objFullName));
        if (!objectFiles.empty()) objectFiles.append("\\\n");
        objectFiles.append(objFullName);
       }

    std::string objFilesMacroName = ::boost::algorithm::to_upper_copy(conf.name) + std::string("_OBJ_FILES");


    if (!conf.moduleDefinitionFile.empty())
       {
        std::string file, srcRoot = "src/";
        std::string::size_type prefixLen;
        if (!getSubDirectoryAux(conf.moduleDefinitionFile, srcRoot, file, prefixLen))
           {
            std::cout<<"Invalid module definition file path: '"<<*srcIt<<"'\n\tAll sources must be under 'src/' directory in project root\n";
            return false;
           }
        macroses["ModuleDefinitionFile"] = makeCanonical(appendPath(dotsPath, file), PATH_SEPARATORS, pathSep);
       }


    std::string finalTool; // = toolset.exeLinkerTool; // 

    if (!toolset.getLinkerTool(conf.outputType , finalTool))
       {
        std::cout<<"Error: can't find apropriate linker tool for output file type '"<<conf.outputType<<"'\n";
        return false;
       }

    std::string finalExt;
    if (!toolset.getLinkerToolExt(conf.outputType , finalExt))
       {
        std::cout<<"Error: can't find apropriate linker tool for output file type '"<<conf.outputType<<"'\n";
        return false;
       }

    std::string finalPrefix;
    if (!toolset.getLinkerToolPrefix(conf.outputType , finalPrefix))
       {
        std::cout<<"Error: can't find apropriate linker tool for output file type '"<<conf.outputType<<"'\n";
        return false;
       }

    //std::string outputTypeUpcase = ::boost::algorithm::to_upper_copy(conf.outputType);
    macroses["OutputType"] = conf.outputType;
    macroses["OUTPUTTYPE"] = ::boost::algorithm::to_upper_copy(conf.outputType);

    std::string targetFullName = makeCanonical(appendExtention(appendPath(outputDirectory, finalPrefix + targetName), finalExt), PATH_SEPARATORS, pathSep);

    macroses["ObjectFiles"] = std::string("$$(") + objFilesMacroName + std::string(")"); //objectFiles;
    macroses["TargetFullName"] = targetFullName;
    macroses["TARGETFULLNAME"] = upperCase(targetFullName);
    macroses["TargetFileName"] = filename::getFile(targetFullName);
    macroses["TARGETFILENAME"] = upperCase(filename::getFile(targetFullName));

    std::string targetName = filename::getName(targetFullName);
    std::string targetPath = filename::getPath(targetFullName);
    std::string targetPathName = appendPath(targetPath, targetName);

    macroses["TargetName"]     = targetName;
    macroses["TARGETNAME"]     = upperCase(targetName);
    //::std::string TargetPath
    macroses["TargetPath"]     = makeCanonical(targetPath, PATH_SEPARATORS, pathSep);
    macroses["TargetPathName"] = makeCanonical(targetPathName, PATH_SEPARATORS, pathSep);

    of<<objFilesMacroName<<"="<<substHash(objectFiles)<<"\n\n";

    //of<<conf.name<<": "<<outdir_target<<" "<<intdir_target<<" $("<<objFilesMacroName<<")\n";
    of<<substHash(conf.name)<<": "<<substHash(outdir_target)<<" "<<substHash(intdir_target)<<" "<<substHash(targetFullName)<<"\n\n";

    // include $(wildcard *.d)

    // CodeBlocks
    //cbTarget.name = ConfigurationName;
    cbTarget.setName(ConfigurationName);
    {
     // $(PROJECT_NAME)
     std::string targetFullNameTmp = makeCodeBlocksPath( "" /* dotsPath */ , macroses, targetFullName, pathSep);
     //<Option output="test_f02" prefix_auto="1" extension_auto="1" />
     cb::COption optOutput;
     optOutput.output = targetFullNameTmp;
     optOutput.prefix_auto = 0;
     optOutput.extension_auto  = 0;
     cbTarget.addOption(optOutput);

     std::string intermediateDirectoryTmp = makeCodeBlocksPath( "" /* dotsPath */ , macroses, intermediateDirectory, pathSep);
     std::string outputDirTmp             = makeCodeBlocksPath( "" /* dotsPath */ , macroses, targetPath, pathSep);
     CB_ADD_OPTION(cbTarget, working_dir  , outputDirTmp);
     CB_ADD_OPTION(cbTarget, object_output, intermediateDirectoryTmp);
     CB_ADD_OPTION(cbTarget, deps_output  , intermediateDirectoryTmp);     

     std::map<std::string, std::string>::const_iterator mapIt = macroses.find("CODEBLOCKS_TOOLSET_NAME");
     std::string cbToolsetName = "egcc";
     if (mapIt!=macroses.end())
        {
         cbToolsetName = substMacroses(macroses, mapIt->second);
        }
     cbTarget.compilerToolset = cbToolsetName;
     CB_ADD_OPTION(cbTarget, compiler, cbToolsetName);

     int otype = 0;
     if (conf.outputType=="exe")
        {
         if (conf.subsystem==SUBSYSTEM_CONSOLE)
            otype = CB_OUTPUT_TYPE_CONSOLE;
         else
            otype = CB_OUTPUT_TYPE_GUI_APP;
        }
     else if (conf.outputType=="lib")
        {
         otype = CB_OUTPUT_TYPE_STATIC_LIB;
        }
     else if (conf.outputType=="dll")
        {
         otype = CB_OUTPUT_TYPE_DYNAMIC_LIB;
        }

     CB_ADD_OPTION(cbTarget, type, otype);
     if (otype==CB_OUTPUT_TYPE_CONSOLE)
        {
         CB_ADD_OPTION(cbTarget, use_console_runner, 1);
        }
     else
        {
         CB_ADD_OPTION(cbTarget, use_console_runner, 0);
        }

     if (otype==CB_OUTPUT_TYPE_DYNAMIC_LIB)
        {
         CB_ADD_OPTION(cbTarget, createDefFile  , 1);
         CB_ADD_OPTION(cbTarget, createStaticLib, 1);

         ::std::string addStdcallAlias = substMacroses(macroses, ::std::string("$(LNK_ADD_STDCALL_ALIAS)"));
         if (!addStdcallAlias.empty())
            cbTarget.linker.addOption(addStdcallAlias); // "-Wl,--add-stdcall-alias"

         /*
         if (cbToolsetName=="gcc")
            {
             cbTarget.linker.addOption("-Wl,--add-stdcall-alias");
             //cbTarget.linker.addOption("-Wl,--kill-at");
            }
         */
            //-Wl,--add-stdcall-alias
            //-Wl,--enable-stdcall-fixup
            //-Wl,--kill-at
        }
     else if (otype==CB_OUTPUT_TYPE_CONSOLE || otype==CB_OUTPUT_TYPE_GUI_APP)
        {
         ::std::string enableStdcallFixup = substMacroses(macroses, ::std::string("$(LNK_ENABLE_STDCALL_FIXUP)"));
         if (!enableStdcallFixup.empty())
            cbTarget.linker.addOption(enableStdcallFixup); // "-Wl,--enable-stdcall-fixup"
         /*
         if (cbToolsetName=="gcc")
            {
             LNK_ADD_STDCALL_ALIAS=-Wl,--add-stdcall-alias
             LNK_ENABLE_STDCALL_FIXUP=-Wl,--enable-stdcall-fixup

             cbTarget.linker.addOption("-Wl,--enable-stdcall-fixup");
            }
         */
        }

     // Adding compiler options
     // <Compiler>
     //     <Add option="-opt" />
     // COMMONCFLAGS
         {
          ::std::vector< ::std::string > ccOpts;
          ::mbs::util::splitStringToWords( substHash(substMacroses(macroses, macroses["COMMONCFLAGS"]))
                                         , ccOpts, util::isExactChar<' '>());
          ::std::vector< ::std::string >::const_iterator ccIt = ccOpts.begin();
          for(; ccIt!=ccOpts.end(); ++ccIt)
             {
              cbTarget.compiler.addOption(*ccIt);
             }
         }

         {
          ::std::vector< ::std::string > ccOpts;
          ::mbs::util::splitStringToWords( substHash(substMacroses(macroses, macroses["CPPFLAGS"]))
                                         , ccOpts, util::isExactChar<' '>());
          ::std::vector< ::std::string >::const_iterator ccIt = ccOpts.begin();
          for(; ccIt!=ccOpts.end(); ++ccIt)
             {
              cbTarget.compiler.addOption(*ccIt);
             }
         }

         {
          ::std::vector< ::std::string > ccOpts;
          ::mbs::util::splitStringToWords( substHash(substMacroses(macroses, macroses["CPPEXFLAGS"]))
                                         , ccOpts, util::isExactChar<' '>());
          ::std::vector< ::std::string >::const_iterator ccIt = ccOpts.begin();
          for(; ccIt!=ccOpts.end(); ++ccIt)
             {
              cbTarget.compiler.addOption(*ccIt);
             }
         }

     // Adding src defines to COMMONCDEF
         {
          std::map<std::string, std::string>::iterator macIt = macroses.find("COMMONCDEF");

          //::mbs::util::CCbGlobalVarNameConverter converter;
          ::std::vector< ::std::string >::const_iterator it = confSrcInfo.defines.begin();
          for(; it!=confSrcInfo.defines.end() && macIt!=macroses.end(); ++it)
             {
              ::std::string::size_type pos = it->find('=', 0);
              std::string def1 = pos==::std::string::npos 
                               ? *it
                               : ::std::string(*it, 0, pos);
              std::string def2 = pos==::std::string::npos 
                               ? ::std::string()
                               : ::std::string(*it, pos+1, ::std::string::npos);
              ::std::string def = pos==::std::string::npos 
                                ? ::std::string(" $(CPPOPTDEF:") + def1 + ::std::string(")")
                                : ::std::string(" $(CPPOPTDEF:") + def1 + ::std::string(":") + def2 + ::std::string(")");
              macIt->second.append(def);
              //cbTarget.compiler.addDirectory(converter(*it));
             }
         }


     

     // Adding defines
     // <Compiler>
     //     <Add option="-DMACRO=TEST" />
         {
          ::std::vector< ::std::string > defs;
          ::mbs::util::splitStringToWords( substHash(substMacroses(macroses, macroses["COMMONCDEF"]))
                                         , defs, util::isExactChar<' '>());
          ::std::vector< ::std::string >::const_iterator defIt = defs.begin();
          for(; defIt!=defs.end(); ++defIt)
             {
              const ::std::string &def = *defIt;
              if (def.size()>=2 && def[0]=='\"' && def[def.size()-1]=='\"')
                 cbTarget.compiler.addOption(::std::string(def, 1, def.size()-2));
              else
                 cbTarget.compiler.addOption(def);
             }
         }

     // Adding linker options
     // <Linker>
     //     <Add option="-opt" />
     // LINKFLAGS
         {
          ::std::vector< ::std::string > linkOpts;
          ::mbs::util::splitStringToWords( substHash(substMacroses(macroses, macroses["LINKFLAGS"]))
                                         , linkOpts, util::isExactChar<' '>());
          ::std::vector< ::std::string >::const_iterator loptIt = linkOpts.begin();
          for(; loptIt!=linkOpts.end(); ++loptIt)
             {
              cbTarget.linker.addOption(*loptIt);
             }
         }

     // projects default paths
        {
         ::std::string inc = makeDotsPath(fromPlatformRelativePath, pathSep, 2, std::string("include"));
         cbTarget.compiler.addDirectory( inc );
         cbProj.extensions.code_completion.addSearchPath( inc );
         ::std::string lib = makeDotsPath(fromPlatformRelativePath, pathSep, 2, std::string("lib"));
         lib = appendPath(lib, "$(PlatformHostTargetName)/$(ConfigurationName)");
         lib = substMacroses(macroses, lib);
         cbTarget.linker.addDirectory( makeCanonical(lib, PATH_SEPARATORS, pathSep) );
        }

     // Adding inc paths to target
         {
          ::mbs::util::CCbGlobalVarNameConverter converter;
          ::std::vector< ::std::string >::const_iterator it = confSrcInfo.incPath.begin();
          for(; it!=confSrcInfo.incPath.end(); ++it)
             {
              ::std::string incDir = converter(*it);
              cbTarget.compiler.addDirectory(incDir);
              cbProj.extensions.code_completion.addSearchPath(incDir);
             }
         }

     // Adding lib paths to target
         {
          ::mbs::util::CCbGlobalVarNameConverter converter;
          ::std::vector< ::std::string >::const_iterator it = confSrcInfo.libPath.begin();
          for(; it!=confSrcInfo.libPath.end(); ++it)
             {
              cbTarget.linker.addDirectory(converter(*it));
             }
          // also add output directory to library search path
          cbTarget.linker.addDirectory("$(TARGET_OUTPUT_DIR)");
         }

     // Adding libraries to target
         {
          ::mbs::util::CCbGlobalVarNameConverter converter;
          ::std::vector< ::std::string >::const_iterator it = confSrcInfo.libs.begin();
          for(; it!=confSrcInfo.libs.end(); ++it)
             {
              cbTarget.linker.addLibrary(converter(*it));
             }
         }

     //CB_ADD_OPTION(cbTarget, type, otype);     
     
          // TEST
          //makeDotsPath(slnPath, pathSep, 2, std::string("include"));
    }
    //            <Option object_output="temp" />



    
    of<<hostPlatformOptions.makeToolCondStart()
      <<"include $(wildcard "
      <<substHash(filename::appendPath(intermediateDirectory, "*.dep", PATH_SEPARATORS, pathSep))
      <<")\n\n";

    of<<substHash(targetFullName)<<": $("<<objFilesMacroName<<")\n";


    of<<"\t"<<makeMakCommands(substMacroses(macroses, finalTool))<<"\n\n";

    of<<"# compile sources\n\n";

    std::vector< ::std::pair<std::string, std::string> >::const_iterator soIt = sourceObjects.begin();
    for(;soIt!=sourceObjects.end(); ++soIt)
       {
        std::map<std::string, std::string> tmpMacroses = macroses;
        tmpMacroses["SourceFullName"] = soIt->first;
        tmpMacroses["ObjectFullName"] = soIt->second;
        std::string compilerTool, fileType="unknown";
        if (!toolset.getCompilerTool(soIt->first, fileType, compilerTool))
           {
            std::cout<<"Error: can't find compiler tool for file type '"<<fileType<<"' - file '"<<soIt->first<<"'\n";
            return false;
           }
        of<<substHash(soIt->second)<<": "<<substHash(soIt->first)<<"\n";
        std::string dependencyTool;
        if (toolset.getDependencyTool(fileType, dependencyTool))
           {
            of<<"\t"<<makeMakCommands(substMacroses(tmpMacroses, dependencyTool))<<"\n";
           }
          of<<"\t"<<makeMakCommands(substMacroses(tmpMacroses, compilerTool))
          <<"\n\n";
       }


    //$(PlatformName)/$(SolutionName)/$(ConfigurationName)
    //$(PlatformName)/$(SolutionName)/$(ConfigurationName)/$(ProjectName)
    // conf.name
    // conf.OutputDirectory
    // conf.IntermediateDirectory
    return true;
   }


}; // namespace mbs


