#ifndef MBS_TOOLSET_H
#define MBS_TOOLSET_H


#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <algorithm>
#include <vector>
#include <string>
#include <malloc.h>


#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#if !defined(_UTILITY_) && !defined(_STLP_UTILITY) && !defined(__STD_UTILITY__) && !defined(_CPP_UTILITY) && !defined(_GLIBCXX_UTILITY)
    #include <utility>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#ifndef BOOST_STRING_CASE_CONV_HPP
    #include <boost/algorithm/string/case_conv.hpp>
#endif

#include <marty/winapi.h>
#include <marty/filename.h>


#include <sixml/sixmlx.h>

#include <sixml/serializ.h>



#ifdef USE_MARTY_NAMESPACE
using namespace ::marty;
#endif




namespace mbs
{


#ifdef USE_MARTY_NAMESPACE
using namespace ::marty;
#endif


struct CMbsPlatformInfo;


struct CPlatformHostTarget
{
      std::string     hostPlatform;
      std::string     targetPlatform;

      CPlatformHostTarget()
         : hostPlatform()
         , targetPlatform()
         {}

      CPlatformHostTarget(const std::string &h, const std::string &t)
         : hostPlatform(h)
         , targetPlatform(t)
         {}
};




namespace toolset
{

inline
std::string getSourceType(const std::string &srcExt)
   {
    std::string ext = ::boost::algorithm::to_lower_copy(srcExt);
    if (ext==".c") return "c";
    else if (ext==".cpp") return "c++";
    else if (ext==".cxx") return "c++";
    else if (ext==".c++") return "c++";
    else return "unknown";
    //else if (ext==".cpp") return "c++";
   }

inline
std::string getCodeBlocksCompilerVar(const std::string &srcExt)
   {
    std::string ext = ::boost::algorithm::to_lower_copy(srcExt);
    if (ext==".c") return "CC";
    else if (ext==".cpp") return "CPP";
    else if (ext==".cxx") return "CPP";
    else if (ext==".c++") return "CPP";
    else return "UNKNOWN";
    //else if (ext==".cpp") return "c++";
   }


bool splitPlatformName( const std::string &platformName
                      , std::string &os
                      , std::string &cpu
                      , std::string &kernelVer
                      , std::string &distr
                      , std::string &distrVer
                      );

bool splitPlatformName( const std::string &platformName
                      , ::std::vector< std::string > &platformNameParts
                      );

bool splitVersionString( const std::string &verString
                      , std::vector<std::string> &ver
                      );

void makeGoodVersionString(std::string &substr);
void makeGoodVersionString(std::vector<std::string> &ver);

inline
std::string mergePlatformName( 
                        const std::string &os
                      , const std::string &cpu
                      , const std::string &kernelVer
                      , const std::string &distr
                      , const std::string &distrVer
                      )
   {
    const std::string tire = "-";
    return os + tire + cpu + tire + kernelVer + tire + distr + tire + distrVer;
   }

std::string makeCanonicalPlatformName(const std::string &platformName);


void reverseVector(std::vector<std::string> &vec);

void builVersionVector(const std::vector<std::string> &verVec, std::vector<std::string> &resVec);
void builVersionVectorInplace(std::vector<std::string> &verVec);

bool buildPrefferedPlatformsVector( const std::string &platformName
                                  , std::vector<std::string> &vec
                                  , std::vector<std::string> &reverceVec
                                  , bool useRegex = false);

void makePlatformMacroses(std::map<std::string, std::string> &macroses, const CPlatformHostTarget &platformHostTarget, const CMbsPlatformInfo &pInfo);

inline
bool platformCompare(const std::string &p1, const std::string &p2)
   {
    std::vector<std::string> vec, reverceVec;
    if (!buildPrefferedPlatformsVector(p2, vec, reverceVec))
       return false;

    std::vector<std::string>::const_iterator it = vec.begin();
    for(; it!=vec.end(); ++it)
       {
        if (p1==*it) return true;
       }
    return false;    
   }



}; // namespace toolset





struct CToolset
{

/*
    std::string makeTool;

    std::string exeLinkerTool;
    std::string dllLinkerTool;
    std::string libLinkerTool;
*/

    std::string                         name;
    std::map<std::string, std::string>  exts;
    std::map<std::string, std::string>  prefixes;
    std::map<std::string, std::string>  tools;
    //std::map<std::string, std::string>  objectExtentions;

    std::string getFileType(const std::string &file) const
       {
        return toolset::getSourceType(filename::getExtention(file));        
       }

    std::string getCodeBlocksCompilerVar(const std::string &file) const
       {
        return toolset::getCodeBlocksCompilerVar(filename::getExtention(file));        
       }

    bool getTool(const std::string &toolType, std::string &toolStr) const
       {
        std::map<std::string, std::string>::const_iterator ctIt = tools.find(toolType);
        if (ctIt==tools.end()) return false;
        toolStr = ctIt->second;       
        return true;
       }

    bool getExt(const std::string &toolType, std::string &extStr) const
       {
        std::map<std::string, std::string>::const_iterator ctIt = exts.find(toolType);
        if (ctIt==exts.end()) return false;
        extStr = ctIt->second;       
        return true;
       }

    bool getPrefix(const std::string &toolType, std::string &prefixStr) const
       {
        std::map<std::string, std::string>::const_iterator ctIt = prefixes.find(toolType);
        if (ctIt==prefixes.end()) return false;
        prefixStr = ctIt->second;       
        return true;
       }

    bool getCompilerTool(const std::string &src, std::string &ftype, std::string &toolStr) const
       {
        ftype = getFileType(src);
        return getTool(ftype+std::string("-compiler-tool"), toolStr);
       }

    bool getDependencyTool(const std::string &ftype, std::string &toolStr) const
       {
        return getTool(ftype+std::string("-dependency-tool"), toolStr);
       }

    bool getLinkerTool(const std::string &ftype /* exe,dll,lib */ , std::string &toolStr) const
       {
        return getTool(ftype+std::string("-linker-tool"), toolStr);
       }

    bool getLinkerToolExt(const std::string &ftype /* exe,dll,lib */ , std::string &extStr) const
       {
        return getExt(ftype+std::string("-linker-tool"), extStr);
       }

    bool getLinkerToolPrefix(const std::string &ftype /* exe,dll,lib */ , std::string &prefixStr) const
       {
        return getPrefix(ftype+std::string("-linker-tool"), prefixStr);
       }

    bool getObjectExt(const std::string &ftype, std::string &extStr) const
       {
        //ftype = getFileType(src);
        return getExt(ftype+std::string("-compiler-tool"), extStr);
       }



// gcc  -Wall -g -c demo_use.c -o demo_use.o
// gcc  -g -o demo_use1 demo_use.o -L. -lhello

};






}; // namespace mbs



#endif /* MBS_TOOLSET_H */

