#ifndef MBS_PRJ_H
#define MBS_PRJ_H


#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif


#include <marty/winapi.h>
#include <marty/filename.h>

#ifdef USE_MARTY_NAMESPACE
using namespace ::marty;
#endif


namespace mbs
{

typedef filename::tstring  tstring;


struct CProjectConfigInfo
{
    //tstring

};






}; // namespace mbs


#endif /* MBS_PRJ_H */

