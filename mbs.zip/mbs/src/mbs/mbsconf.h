#ifndef MBS_MBSCONF_H
#define MBS_MBSCONF_H


#include <stdio.h>
#include <stdlib.h>
#include <errno.h>


#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_UTILITY_) && !defined(_STLP_UTILITY) && !defined(__STD_UTILITY__) && !defined(_CPP_UTILITY) && !defined(_GLIBCXX_UTILITY)
    #include <utility>
#endif

#include <malloc.h>

#include <sixml/sixmlx.h>

#include <sixml/serializ.h>

#ifndef BOOST_STRING_TRIM_HPP
    #include <boost/algorithm/string/trim.hpp>
#endif

#ifndef BOOST_STRING_CASE_CONV_HPP
    #include <boost/algorithm/string/case_conv.hpp>
#endif

#ifndef BOOST_STRING_SPLIT_HPP
    #include <boost/algorithm/string/split.hpp>
#endif

#include <marty/winapi.h>
#include <marty/filename.h>

#include "toolset.h"
#include "util.h"



#ifdef USE_MARTY_NAMESPACE
using namespace ::marty;
#endif

namespace mbs
{

typedef filename::tstring  tstring;


namespace util
{

template< typename CharType 
        , typename Traits   
        , typename Allocator
        >
void
splitTargetAndHost( const ::std::basic_string<CharType, Traits, Allocator> &targetAndHost
                  , ::std::basic_string<CharType, Traits, Allocator> &targetPlatformName
                  , ::std::basic_string<CharType, Traits, Allocator> &hostPlatformName
                  )
   {
    typedef ::std::basic_string<CharType, Traits, Allocator> string_type;
    //typename string_type::size_type bracePos = targetAndHost.find( (CharType)'{' );
    typename string_type::size_type bracePos = targetAndHost.find( (CharType)'(' );
    //if (bracePos==targetAndHost.npos || targetAndHost[targetAndHost.size()-1]!=(CharType)'}' )
    if (bracePos==targetAndHost.npos || targetAndHost[targetAndHost.size()-1]!=(CharType)')' )
       {
        targetPlatformName = targetAndHost;
        hostPlatformName.clear();
       }
    else
       {
        targetPlatformName.assign( targetAndHost, 0, bracePos );
        hostPlatformName  .assign( targetAndHost, bracePos+1, targetAndHost.size()-bracePos-2 );
       }
   }


}; // namespace util

struct CMbsPlatformInfo
{
    std::string name;
    std::string hostPlatform;
    std::string toolset;
    std::string realName;

    ::std::string getRealName() const
       {
        if (realName.empty()) return name;
        return realName;
       }

    bool merge(const CMbsPlatformInfo &i)
       {
        if (name!=i.name) return false;
        // target platforms are equal
        if (name!=i.name) return false;
        if (!hostPlatform.empty() && hostPlatform != i.hostPlatform) return false;

        if ( /* hostPlatform.empty() ||  */ !i.hostPlatform.empty() ) hostPlatform = i.hostPlatform;
        if ( /* toolset.empty()      ||  */ !i.toolset.empty()      ) toolset      = i.toolset;
        if ( /* realName.empty(      ||  */ !i.realName.empty()     ) realName     = i.realName;
        return true;
       }

    CMbsPlatformInfo()
       : name(), hostPlatform(), toolset(), realName() {}

    CMbsPlatformInfo(const std::string &n, const std::string &h, const std::string &t)
       : name(n), hostPlatform(h), toolset(t), realName() {}

    STRUCT_LAYOUT_DEFAULT(CMbsPlatformInfo)
            attribute(_T("name")            , &CMbsPlatformInfo::name);
            attribute(_T("host-platform")   , &CMbsPlatformInfo::hostPlatform, std::string());
            attribute(_T("toolset")         , &CMbsPlatformInfo::toolset, std::string());
            attribute(_T("real-name")       , &CMbsPlatformInfo::realName, std::string());
    END_STRUCT_LAYOUT()
};

struct CMbsToolInfo
{
    std::string name;
    std::string ext;
    std::string prefix;
    std::string command;

    CMbsToolInfo()
       : name(), ext(), prefix(), command() {}

    CMbsToolInfo(const std::string &n, const std::string &e, const std::string &p, const std::string &c)
       : name(n), ext(e), prefix(p), command(c) {}

    STRUCT_LAYOUT_DEFAULT(CMbsToolInfo)
            attribute(_T("name")          , &CMbsToolInfo::name);
            attribute(_T("output-ext")    , &CMbsToolInfo::ext);
            attribute(_T("output-prefix") , &CMbsToolInfo::prefix, ::std::string());
            simple(0                      , &CMbsToolInfo::command);
    END_STRUCT_LAYOUT()

};

struct CMbsToolsetInfo
{
    std::string name; // toolset name
    std::string hostPlatform;
    std::string targetPlatform;
    std::string platform;
    std::vector<CMbsToolInfo>  tools;

    CMbsToolsetInfo()
       : name(), hostPlatform(), targetPlatform(), platform(), tools() {}

    CMbsToolsetInfo(const std::string &n, const std::string &p)
       : name(n), hostPlatform(), targetPlatform(), platform(p), tools() {}

    STRUCT_LAYOUT_DEFAULT(CMbsToolsetInfo)
            attribute(_T("name")            , &CMbsToolsetInfo::name);
            attribute(_T("host-platform")   , &CMbsToolsetInfo::hostPlatform, std::string());
            attribute(_T("target-platform") , &CMbsToolsetInfo::targetPlatform, std::string());
            attribute(_T("platform")        , &CMbsToolsetInfo::platform);
            array(0                         , &CMbsToolsetInfo::tools, _T("tool"));
            //array(_T("toolsets")            , &CMbsToolInfo::tools, _T("toolset"));
    END_STRUCT_LAYOUT()

    void mergeTool(const CMbsToolInfo& ti)
       {
        std::vector<CMbsToolInfo>::iterator tit = tools.begin();
        for(; tit!=tools.end(); ++tit)
           {
            if (tit->name==ti.name)
               {
                if (!ti.ext.empty())     tit->ext     = ti.ext;
                if (!ti.command.empty()) tit->command = ti.command;
                break;
               }
           }
        if (tit==tools.end()) // not merged above
           tools.push_back(ti);
       }

    void mergeTools(const std::vector<CMbsToolInfo> &ti)
       {
        std::vector<CMbsToolInfo>::const_iterator tit = ti.begin();
        for(; tit!=ti.end(); ++tit)
           mergeTool(*tit);
       }

    bool merge(const CMbsToolsetInfo &tlsi)
       {
        if (name.empty() || hostPlatform.empty() || targetPlatform.empty())
           return false;
        if (name!=tlsi.name || hostPlatform!=tlsi.hostPlatform || targetPlatform!=tlsi.targetPlatform)
           return false;

        mergeTools(tlsi.tools);
        return true;
       }

    operator CToolset() const
       {
        CToolset ts;
        ts.name = name;
        std::vector<CMbsToolInfo>::const_iterator it = tools.begin();
        for(; it!=tools.end(); ++it)
           {
            ts.exts[it->name]  = it->ext;
            ts.prefixes[it->name]  = it->prefix;
            ts.tools[it->name] = it->command;
           }
        return ts;
       }


};


struct CMbsMakeGeneratorOptions
{
    int            useBatFilesSyntax;
    int            useCrLf;
    int            mkdirSupportForceCreate;
    std::string    pathSeparator;
    std::string    optListSeparator;
    CMbsMakeGeneratorOptions() : useBatFilesSyntax(-1), useCrLf(-1), mkdirSupportForceCreate(-1), pathSeparator(":"), optListSeparator(" ") {}

    STRUCT_LAYOUT_DEFAULT(CMbsMakeGeneratorOptions)
            attribute(_T("use-bat-files-syntax"), &CMbsMakeGeneratorOptions::useBatFilesSyntax, int(-1));
            attribute(_T("use-crlf-linefeed")   , &CMbsMakeGeneratorOptions::useCrLf          , int(-1));
            attribute(_T("mkdir-support-force-create"), &CMbsMakeGeneratorOptions::mkdirSupportForceCreate, int(-1));
            attribute(_T("path-separator-char") , &CMbsMakeGeneratorOptions::pathSeparator, std::string(":"));
            attribute(_T("opt-list-separator-char") , &CMbsMakeGeneratorOptions::optListSeparator, std::string(" "));
    END_STRUCT_LAYOUT()

    void merge(const CMbsMakeGeneratorOptions &o)
       {
        if (o.useBatFilesSyntax>=0)
           useBatFilesSyntax = o.useBatFilesSyntax;
        if (o.useCrLf>=0)
           useCrLf = o.useCrLf;
        if (o.pathSeparator=="/" || o.pathSeparator=="\\")
           pathSeparator = o.pathSeparator;
        if (o.pathSeparator==":" || o.pathSeparator==";")
           optListSeparator = o.optListSeparator;
        if (o.mkdirSupportForceCreate>=0)
           mkdirSupportForceCreate = o.mkdirSupportForceCreate;
       }
};


struct CMbsHostPlatformOptions
{
    std::string                name;
    CMbsMakeGeneratorOptions   makeOptions;
    std::string                platformConfigScriptName;

    STRUCT_LAYOUT_DEFAULT(CMbsHostPlatformOptions)
            attribute(_T("name")                   , &CMbsHostPlatformOptions::name);
            simple   (_T("config-script-name")     , &CMbsHostPlatformOptions::platformConfigScriptName, std::string());
            complex  (_T("make-generator-options") , &CMbsHostPlatformOptions::makeOptions, CMbsMakeGeneratorOptions());
    END_STRUCT_LAYOUT()

    CMbsHostPlatformOptions(const std::string &hpn=std::string()) : name(hpn), makeOptions() {}

    bool useBatFilesSyntax() const
       {
        if (makeOptions.useBatFilesSyntax>0) return true; // 1 - explicitly setted, 
        return false; // -1 - use default - false, 0 - false
       }

    bool merge(const CMbsHostPlatformOptions &hpo)
       {
        if (name!=hpo.name) return false;
        makeOptions.merge(hpo.makeOptions);
        if (!hpo.platformConfigScriptName.empty())
           platformConfigScriptName = hpo.platformConfigScriptName;
        return true;
       }

    std::string silentOn() const
       {
        if (useBatFilesSyntax()) return std::string("@echo off");
        return std::string("");
       }

    std::string silentOff() const
       {
        if (useBatFilesSyntax()) return std::string("@echo on");
        return std::string("");
       }

    std::string shellCommentStart() const
       {
        if (useBatFilesSyntax()) return std::string("rem ");
        return std::string("# ");
       }

    std::string makeToolCondStart() const
       {
        if (useBatFilesSyntax()) return std::string(""); //std::string("!");
        return std::string("");
       }

    std::string shellExt() const
       {
        if (useBatFilesSyntax()) return std::string(".sln.bat");
        return std::string(".shsln");
       }

    std::string shellScriptHeader(const std::string &fn) const
       {
        if (useBatFilesSyntax()) return std::string("@rem run \'cmd /C ") + fn + std::string("\'\n");
        return std::string("#!/bin/bash\n");
       }

    char getPathSeparator() const
       {
        if (makeOptions.pathSeparator.empty()) return '/';
        if (makeOptions.pathSeparator[0]!='/' && makeOptions.pathSeparator[0]!='\\') return '/';
        return makeOptions.pathSeparator[0];
       }

    char getOptListSeparator() const
       {
        if (makeOptions.optListSeparator.empty()) return ';';
        if (makeOptions.optListSeparator[0]!=':' && makeOptions.optListSeparator[0]!=';') return ';';
        return makeOptions.optListSeparator[0];
       }

       
};




struct CMbsVars
{
    std::string    toolset;
    std::string    hostPlatform;
    std::string    targetPlatform;
    std::string    outputType;
    std::string    configuration;
    std::string    vars;

    STRUCT_LAYOUT_DEFAULT(CMbsVars)
            attribute(_T("toolset")            , &CMbsVars::toolset        ,   std::string());
            attribute(_T("host-platform")      , &CMbsVars::hostPlatform   ,   std::string());
            attribute(_T("target-platform")    , &CMbsVars::targetPlatform ,   std::string());
            attribute(_T("output-type")        , &CMbsVars::outputType     ,   std::string());
            attribute(_T("configuration")      , &CMbsVars::configuration  ,   std::string());
            simple(0                           , &CMbsVars::vars           ,   std::string());
    END_STRUCT_LAYOUT()

    bool merge(const CMbsVars &v)
       {
        if (toolset!=v.toolset)               return false;
        if (hostPlatform!=v.hostPlatform)     return false;
        if (targetPlatform!=v.targetPlatform) return false;
        //if (!toolset::platformCompare(hostPlatform, v.hostPlatform)) return false;
        //if (!toolset::platformCompare(targetPlatform, v.targetPlatform)) return false;
        if (outputType!=v.outputType)   return false;
        if (configuration!=v.configuration)   return false;
        vars.append(1, '\n');
        vars.append(v.vars);
        return true;
       }

};


struct CMbsConfig
{
    std::vector<CMbsPlatformInfo>          platforms;
    std::vector<CMbsToolsetInfo>           toolsets;
    std::vector<CMbsHostPlatformOptions>   hostPlatformOptions;
    std::vector<CMbsVars>                  vars;

    STRUCT_LAYOUT_DEFAULT(CMbsConfig)
            array(_T("platforms"), &CMbsConfig::platforms, _T("platform"));
            array(_T("toolsets") , &CMbsConfig::toolsets, _T("toolset"));
            array(_T("host-platform-options")  , &CMbsConfig::hostPlatformOptions, _T("host-platform"));
            array(0                            , &CMbsConfig::vars, _T("vars"));
    END_STRUCT_LAYOUT()


    void findVars( const std::string &toolset
                 , const std::string &hostPlatform
                 , const std::string &targetPlatform
                 , const std::string &outputType
                 , const std::string &configuration
                 , std::string &res) const;

    void findAllVars( const std::string &toolset
                 , const std::string &hostPlatform
                 , const std::string &targetPlatform
                 , std::string &res) const
       {
        findVars(std::string(), std::string(), std::string() , std::string(), std::string(), res);
        findVars(std::string(), std::string(), targetPlatform, std::string(), std::string(), res);
        findVars(toolset      , std::string(), std::string() , std::string(), std::string(), res);
        findVars(toolset      , hostPlatform , std::string() , std::string(), std::string(), res);
        findVars(toolset      , std::string(), targetPlatform, std::string(), std::string(), res);
        findVars(toolset      , hostPlatform , targetPlatform, std::string(), std::string(), res);
       }

    void findAllVars( const std::string &toolset
                 , const std::string &hostPlatform
                 , const std::string &targetPlatform
                 , const std::string &outputType
                 , const std::string &configuration
                 , std::string &res) const
       {
        findVars(std::string(), std::string(), std::string() , outputType, std::string(), res);
        findVars(std::string(), std::string(), targetPlatform, outputType, std::string(), res);
        findVars(toolset      , std::string(), std::string() , outputType, std::string(), res);
        findVars(toolset      , hostPlatform , std::string() , outputType, std::string(), res);
        findVars(toolset      , std::string(), targetPlatform, outputType, std::string(), res);
        findVars(toolset      , hostPlatform , targetPlatform, outputType, std::string(), res);

        findVars(std::string(), std::string(), std::string() , std::string(), configuration, res);
        findVars(std::string(), std::string(), targetPlatform, std::string(), configuration, res);
        findVars(toolset      , std::string(), std::string() , std::string(), configuration, res);
        findVars(toolset      , hostPlatform , std::string() , std::string(), configuration, res);
        findVars(toolset      , std::string(), targetPlatform, std::string(), configuration, res);
        findVars(toolset      , hostPlatform , targetPlatform, std::string(), configuration, res);

        findVars(std::string(), std::string(), std::string() , outputType, configuration, res);
        findVars(std::string(), std::string(), targetPlatform, outputType, configuration, res);
        findVars(toolset      , std::string(), std::string() , outputType, configuration, res);
        findVars(toolset      , hostPlatform , std::string() , outputType, configuration, res);
        findVars(toolset      , std::string(), targetPlatform, outputType, configuration, res);
        findVars(toolset      , hostPlatform , targetPlatform, outputType, configuration, res);
       }

    bool findPlatformInfo( const std::string &platformName, CMbsPlatformInfo &info) const;
    bool findPlatformInfo( const std::string &platformName, const std::string &hostPlatformName, CMbsPlatformInfo &info) const;

    void mergeVars(const CMbsVars &v)
       {
        std::vector<CMbsVars>::iterator it = vars.begin();
        for(; it!=vars.end(); ++it)
           {
            if (it->merge(v)) return;
           }
        vars.push_back(v);
       }

    void mergeVars(const std::vector<CMbsVars> &v)
       {
        std::vector<CMbsVars>::const_iterator it = v.begin();
        for(; it!=v.end(); ++it)
           {
            mergeVars(*it);
           }
       }

    void mergeHostPlatformOptions(const CMbsHostPlatformOptions &hpo)
       {
        std::vector<CMbsHostPlatformOptions>::iterator it = hostPlatformOptions.begin();
        for(; it!=hostPlatformOptions.end(); ++it)
            if (it->merge(hpo)) return;
        hostPlatformOptions.push_back(hpo);
       }

    void mergeHostPlatformOptionsVector(const std::vector<CMbsHostPlatformOptions> &hpo)
       {
        std::vector<CMbsHostPlatformOptions>::const_iterator it = hpo.begin();
        for(; it!=hpo.end(); ++it)
           mergeHostPlatformOptions(*it);
       }

    void mergeToolset(const CMbsToolsetInfo &ti)
       {
        std::vector<CMbsToolsetInfo>::iterator tit = toolsets.begin();
        for(;tit!=toolsets.end(); ++tit)
           {
            if (tit->merge(ti)) return;
           }
        toolsets.push_back(ti);
       }

    void mergeToolsets(const std::vector<CMbsToolsetInfo> &ts)
       {
        std::vector<CMbsToolsetInfo>::const_iterator it = ts.begin();
        for(; it!=ts.end(); ++it)
           mergeToolset(*it);
       }

    void merge(const CMbsConfig &cfg)
       {
        std::vector<CMbsPlatformInfo>::const_iterator rightPlatformIt = cfg.platforms.begin();
        for(; rightPlatformIt!=cfg.platforms.end(); ++rightPlatformIt)
           {
            std::vector<CMbsPlatformInfo>::size_type i = 0;
            for(; i<platforms.size(); ++i)
               {
                if (platforms[i].merge(*rightPlatformIt)) break;
               }
            // not merged
            if (i>=platforms.size()) 
               platforms.push_back(*rightPlatformIt);
           }

        //std::copy(cfg.toolsets.begin(), cfg.toolsets.end(), std::back_inserter(toolsets) );

        mergeToolsets(cfg.toolsets);
        mergeHostPlatformOptionsVector(cfg.hostPlatformOptions);
        mergeVars(cfg.vars);
       }

    void splitPlatformConfigs()
       {
        // split vars by toolset names
        std::vector<CMbsVars>  tmpVars;
        std::vector<CMbsVars>::const_iterator vit = vars.begin();
        for(; vit!=vars.end(); ++vit)
           {
            if (boost::algorithm::trim_copy(vit->toolset).empty())
               {
                tmpVars.push_back(*vit);
                continue;
               }
            std::vector<std::string> varsToolsets;
            ::boost::algorithm::split(varsToolsets, vit->toolset, util::isExactChar<';'>(), boost::algorithm::token_compress_on);

            CMbsVars v = *vit;
            std::vector<std::string>::const_iterator nit = varsToolsets.begin();
            for(; nit!=varsToolsets.end(); ++nit)
               {
                v.toolset = *nit;
                tmpVars.push_back(v);
               }
           }
        tmpVars.swap(vars);
        tmpVars.clear();

        // split vars by host platform
        vit = vars.begin();
        for(; vit!=vars.end(); ++vit)
           {
            if (boost::algorithm::trim_copy(vit->hostPlatform).empty())
               {
                tmpVars.push_back(*vit);
                continue;
               }
            std::vector<std::string> varsHostPlatforms;
            ::boost::algorithm::split(varsHostPlatforms, vit->hostPlatform, util::isExactChar<';'>(), boost::algorithm::token_compress_on);

            CMbsVars v = *vit;
            std::vector<std::string>::const_iterator nit = varsHostPlatforms.begin();
            for(; nit!=varsHostPlatforms.end(); ++nit)
               {
                v.hostPlatform = *nit;
                tmpVars.push_back(v);
               }
           }
        tmpVars.swap(vars);
        tmpVars.clear();

        // split vars by target platform
        vit = vars.begin();
        for(; vit!=vars.end(); ++vit)
           {
            if (boost::algorithm::trim_copy(vit->targetPlatform).empty())
               {
                tmpVars.push_back(*vit);
                continue;
               }
            std::vector<std::string> varsTargetPlatforms;
            ::boost::algorithm::split(varsTargetPlatforms, vit->targetPlatform, util::isExactChar<';'>(), boost::algorithm::token_compress_on);

            CMbsVars v = *vit;
            std::vector<std::string>::const_iterator nit = varsTargetPlatforms.begin();
            for(; nit!=varsTargetPlatforms.end(); ++nit)
               {
                v.targetPlatform = *nit;
                tmpVars.push_back(v);
               }
           }
        tmpVars.swap(vars);
        tmpVars.clear();

        // split vars by output type
        vit = vars.begin();
        for(; vit!=vars.end(); ++vit)
           {
            if (boost::algorithm::trim_copy(vit->outputType).empty())
               {
                tmpVars.push_back(*vit);
                continue;
               }
            std::vector<std::string> varsOutputTypes;
            ::boost::algorithm::split(varsOutputTypes, vit->outputType, util::isExactChar<';'>(), boost::algorithm::token_compress_on);

            CMbsVars v = *vit;
            std::vector<std::string>::const_iterator nit = varsOutputTypes.begin();
            for(; nit!=varsOutputTypes.end(); ++nit)
               {
                v.outputType = *nit;
                tmpVars.push_back(v);
               }
           }
        tmpVars.swap(vars);
        tmpVars.clear();

        // split vars by configuration
        vit = vars.begin();
        for(; vit!=vars.end(); ++vit)
           {
            if (boost::algorithm::trim_copy(vit->configuration).empty())
               {
                tmpVars.push_back(*vit);
                continue;
               }
            std::vector<std::string> varsConfigurations;
            ::boost::algorithm::split(varsConfigurations, vit->configuration, util::isExactChar<';'>(), boost::algorithm::token_compress_on);

            CMbsVars v = *vit;
            std::vector<std::string>::const_iterator nit = varsConfigurations.begin();
            for(; nit!=varsConfigurations.end(); ++nit)
               {
                v.configuration = *nit;
                tmpVars.push_back(v);
               }
           }
        tmpVars.swap(vars);
        tmpVars.clear();

        // end of vars splitting


        std::vector<CMbsPlatformInfo> tmpPlatforms;
        std::vector<CMbsPlatformInfo>::const_iterator pit = platforms.begin();
        for(; pit!=platforms.end(); ++pit)
           {
            //CMbsPlatformInfo pi = *
            std::vector<std::string> names;
            ::boost::algorithm::split(names, pit->name, util::isExactChar<';'>(), boost::algorithm::token_compress_on);
            if (names.empty()) continue;
            if (names.size()==1) 
               {
                tmpPlatforms.push_back(*pit);
                continue;
               }

            CMbsPlatformInfo pi = *pit;
            std::vector<std::string>::const_iterator nit = names.begin();
            for(; nit!=names.end(); ++nit)
               {
                pi.name = *nit;
                tmpPlatforms.push_back(pi);
               }
           }
        tmpPlatforms.swap(platforms);



        std::vector<CMbsHostPlatformOptions> tmpHostPlatformOptions;
        std::vector<CMbsHostPlatformOptions>::const_iterator hpoit = hostPlatformOptions.begin();
        for(; hpoit!=hostPlatformOptions.end(); ++hpoit)
           {
            //CMbsPlatformInfo pi = *
            std::vector<std::string> names;
            ::boost::algorithm::split(names, hpoit->name, util::isExactChar<';'>(), boost::algorithm::token_compress_on);
            if (names.empty()) continue;

            CMbsHostPlatformOptions hpo = *hpoit;
            std::vector<std::string>::const_iterator nit = names.begin();
            for(; nit!=names.end(); ++nit)
               {
                hpo.name = *nit;
                tmpHostPlatformOptions.push_back(hpo);
               }
           }
        tmpHostPlatformOptions.swap(hostPlatformOptions);



        std::vector<CMbsToolsetInfo> tmpToolsets;
        std::vector<CMbsToolsetInfo>::const_iterator tit = toolsets.begin();
        for(; tit!=toolsets.end(); ++tit)
           {
            std::vector<std::string> names;
            ::boost::algorithm::split(names, tit->platform, util::isExactChar<';'>(), boost::algorithm::token_compress_on);
            if (names.empty()) continue;
            /* if (names.size()==1) 
             *    {
             *     tmpToolsets.push_back(*tit);
             *     continue;
             *    }
             */

            CMbsToolsetInfo ti = *tit;
            std::vector<std::string>::const_iterator nit = names.begin();
            for(; nit!=names.end(); ++nit)
               {
                std::vector<std::string> host_target;
                ::boost::algorithm::split(host_target, *nit, util::isExactChar<':'>(), boost::algorithm::token_compress_on);
                if (host_target.empty()) continue;

                ti.hostPlatform = host_target[0];
                if (host_target.size()>1)
                   ti.targetPlatform = host_target[1];
                else
                   ti.targetPlatform = ti.hostPlatform;
                                   
                //std::vector<std::string>::const_iterator nit = names.begin();
                //ti.targetPlatform = *nit;
                tmpToolsets.push_back(ti);
               }

           }
        tmpToolsets.swap(toolsets);
       }

    bool getToolsetForPlatform(const CMbsPlatformInfo &pi, const std::string &targetPlatform, CToolset &ts, CPlatformHostTarget &foundPlatform) const;
    bool getHostPlatformOptions(const std::string &hostPlatform, CMbsHostPlatformOptions &opts) const;


};



void searchForMbsConf(const std::string &pathForScan, const std::string &exepath, std::vector<std::string> &confNames);

void loadMbsConfigs(const std::vector<std::string> &confNames, std::vector<CMbsConfig> &confVec);
void loadMbsConfigs(const std::vector<std::string> &confNames, CMbsConfig &conf);

void saveMbsConfig(const std::string &fname, const CMbsConfig &conf);



}; // namespace mbs

#endif /* MBS_MBSCONF_H */

