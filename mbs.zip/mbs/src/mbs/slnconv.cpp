/*
*/
/*!
\project slncon - ��������� MSVC .sln � .vcproj �:
1) .bat/.sh ����� + make-����� mkproj
2) � CodeBlocks .workspace � .cbp


    \incpath #(BOOST.include) #(MARTYUSR.include)
    \libpath #(BOOST.lib) #(MARTYUSR.lib)

    \configuration release
        \libraries cli2
        \libpath
        \incpath
        
    
    \configuration debug
        \libraries cli2
        \libpath
        \incpath


\platform mingw
    \libraries cli2 cli3
    \configuration release unicode_release
        \libraries
        \libpath
        \incpath
    
    \configuration debug unicode_debug
        \libraries cli2
        \libpath
        \incpath

\platform linux
    \libraries cli2 dl
    \configuration release
        \libraries 
        \libpath
        \incpath
    
    \configuration debug
        \libraries
        \libpath
        \incpath

\platform freebsd

*/


// ������� �������� Qt ��������
// Command arguments: slnconv -d+ -om+ -oc+ -oh+ "-rwtl.*" "-rwin.*" "-etpl\\.*" "-e.*cidl.*" "-ecore\\cli.*" "-ecore\\cidl.*" "-ew32_.*" "-e.*test.*" -pbuild >slnconv.log
// Working directory: F:\work\cli2\trunk
// slnconv -d+ -om+ -oc+ -oh+ -Plinux "-rwtl.*" "-rwin.*" "-etpl\\.*" "-e.*cidl.*" "-ecore\\cli.*" "-ecore\\cidl.*" "-ew32_.*" "-e.*test.*" "-e.*nmdlc.*" -pbuild >slnconv.log
// F:\work\cli2\trunk

// �������� ��������������� �������� ����������� navis - ���-�� ���������
// Command arguments: slnconv -d+ -om+ -oc+ -oh+ "-rwtl.*" "-rwin.*" "-etpl\\.*" "-ew32_.*" "-etests.*" "-e.*tests2.*" -pbuild >slnconv.log
// Working directory: F:\work\navis\trunk


// warning C4748: /GS can not protect parameters and local variables from local buffer overrun because optimizations are disabled in function
#if defined(_MSC_VER) && _MSC_VER>=1400
#pragma warning (disable : 4748)
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#if !defined(_FSTREAM_) && !defined(_STLP_FSTREAM) && !defined(__STD_FSTREAM__) && !defined(_CPP_FSTREAM) && !defined(_GLIBCXX_FSTREAM)
    #include <fstream>
#endif


#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif


#if !defined(_INC_ERRNO) && !defined(_ERRNO_H_) && !defined(_ERRNO_H)
    #include <errno.h>
#endif

#include <process.h>

#if !defined(_INC_STDLIB) && !defined(_STDLIB_H_) && !defined(_STDLIB_H)
    #include <stdlib.h>
#endif


#if !defined(_INC_TCHAR) && !defined(_TCHAR_H_)
    #include <tchar.h>
#endif


#if !defined(_LOCALE_) && !defined(_STLP_LOCALE) && !defined(__STD_LOCALE__) && !defined(_CPP_LOCALE) && !defined(_GLIBCXX_LOCALE)
    #include <locale>
#endif

#ifndef BOOST_STRING_TRIM_HPP
    #include <boost/algorithm/string/trim.hpp>
#endif

#ifndef BOOST_STRING_PREDICATE_HPP
    #include <boost/algorithm/string/predicate.hpp>
#endif

#ifndef BOOST_RE_REGEX_HPP
    #include <boost/regex.hpp>
#endif

#include <marty/winapi.h>
#include <marty/filename.h>
#include <marty/filesys.h>

#ifdef USE_MARTY_NAMESPACE
using namespace ::marty;
#endif


#include "slnparse.h"
#include "mbsconf.h"
#include "codeblocks.h"
#include "scansrc.h"
#include "prjInfo.h"


//#include "../cmdline/pcpp_arg.h"

//-----------------------------------------------------------------------------
int read_config_file(const char* fname);
int parse_option(const char* s);
void print_help();
void makeSrcStat( const std::string &path, const std::string &saveTo);

//-----------------------------------------------------------------------------
std::string pathForScan;
std::string buildRoot;
//bool opQuet = false;
int opDetailed = 1;
bool showWhere = false;
bool generateMaks = true;
bool generateCodeblocks = false;
bool generateHtmlSummaryInfo = false;
bool generateVc8 = false;
bool generateVc9 = false;

std::vector<std::string> excludeMaskPatterns;
std::vector<std::string> excludeProjectPatterns;
std::vector<std::string> platformMaskPatterns;
//std::string              toolsetName = "gcc";
std::string              toolsetName;
std::string              dumpConfigFilename;
std::string              statFile;


using filename::makeCanonical;
using filename::getName;
using filename::getFile;
using filename::getPath;
using filename::getExtention;
using filename::appendExtention;
using filename::appendPath;
using filename::changeExtention;
using filename::changePathChars;
using filename::changePathCharsCopy;

//bool makeGeneratorUse



struct CScanForSolutionsFindData
{
    std::vector<std::string> &targets;
    std::string basePath;

    CScanForSolutionsFindData(std::vector<std::string> &t, const std::string &bp) : targets(t), basePath(bp) {}

    bool operator()(const std::string &path, const WIN32_FIND_DATA &fndData)
       {
        if (fndData.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)
           return true;

        std::string name = filename::appendPath(path, fndData.cFileName);
        name = filename::makeCanonical(name);

        //std::string onlySubPathName = fileName;
        std::string tmp;
        if (::filename::subPath(tmp, basePath, name))
           {
            targets.push_back(tmp);
           }
        else
           {
            targets.push_back(name);
           }
        return true;
       }
};


struct CScanTargetsFindData
{
    //std::map<std::string, std::vector<std::string>, ::filename::predLess> &targets;
    std::vector<std::string> &targets;

    CScanTargetsFindData(std::vector<std::string> &t) : targets(t) {}

    bool operator()(const std::string &path, const WIN32_FIND_DATA &fndData)
       {
        if (!(fndData.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY))
           return true;

        std::string name = fndData.cFileName;
        if (name.empty())
           return true;

        if (name[0]=='.')
           return true;

        targets.push_back(name);
        return true;
       }
};
//-----------------------------------------------------------------------------
template <typename ContainerType, typename StringType>
void removeElementsByName( ContainerType &c, const StringType &s)
   {
    if (s.empty()) return;
    c.erase(
           std::remove_if( c.begin()
                         , c.end()
                         , std::bind2nd(std::equal_to<std::string>(), s) 
                         ),
           c.end()
          );
   }


int main(int argc, char* argv[])
   {
    ::std::string exeFilename;
    ::winapi::getModuleFileName(0, exeFilename);
    std::string cfg_name = ::filename::getPathName( exeFilename ) + std::string(".cfg");
    //get_file_name(argv[0]) + std::string(".cfg");
    read_config_file(cfg_name.c_str());

    for (int i=1; i<argc; i++)
        {
         int pr = 0;
         switch(*argv[i])
           {
            case '-':
            case '/':  pr = parse_option(argv[i]);
                       break;
            case '@':  pr = read_config_file(argv[i]+1);
                       break;
            
            // default:   
            //            if (!findTarget(argv[i]))
            //               buildFilesList.push_back(argv[i]);
           };
         
         if (pr) return pr;     
        }

    // if (opQuet)
    //    opDetailed = false;

    if (showWhere)
       {
        std::cout<< exeFilename /* ::winapi::getModuleFileName(0) */ <<"\n";
        return 0;
       }

    if (pathForScan.empty())
       {
        //pathForScan = ::filename::getPath( ::winapi::getModuleFileName(0) );
        pathForScan = filesystem::getCurrentDirectory();
       }
    else
       {
        //pathForScan = filename::appendPath(filesystem::getCurrentDirectory(), pathForScan);
        pathForScan = filename::makeFullPath(filesystem::getCurrentDirectory(), pathForScan);
       }

    if (!statFile.empty())
       {
        makeSrcStat( pathForScan, statFile);
        return 0;
       }

    /*
    if (toolsetName.empty())
       {
        std::cerr<<"No toolset name taken, use -t option\n";
        return 1;
       }
    */

    if (opDetailed>8)
        {

         if (!excludeMaskPatterns.empty())
            {
             std::cout<<"Exclude solutions mask list:\n";
             std::vector<std::string>::const_iterator it = excludeMaskPatterns.begin();
             for(; it!=excludeMaskPatterns.end(); ++it)
                {
                 std::cout<<"    ["<<*it<<"]\n";
                }
            }

         if (!excludeProjectPatterns.empty())
            {
             std::cout<<"Exclude projects mask list:\n";
             std::vector<std::string>::const_iterator it = excludeProjectPatterns.begin();
             for(; it!=excludeProjectPatterns.end(); ++it)
                {
                 std::cout<<"    ["<<*it<<"]\n";
                }
            }

         if (!platformMaskPatterns.empty())
            {    
             std::cout<<"Used platforms mask list:\n";
             std::vector<std::string>::const_iterator it = platformMaskPatterns.begin();
             for(; it!=platformMaskPatterns.end(); ++it)
                {
                 std::cout<<"    ["<<*it<<"]\n";
                }
            }
        }



    ::std::string winTargetName, winTargetNameVc8, winTargetNameVc9      ; // win32, win32(vc8), win32(vc9)
    ::std::string win64TargetName, win64TargetNameVc8, win64TargetNameVc9; // win32-x64, win32-x64(vc8), win32-x64(vc9)

    ::std::vector<::std::string> scanPathParts;
    ::filename::splitPath(pathForScan, scanPathParts);
    if (!scanPathParts.empty())
       {
        bool fErase = false;
        ::std::vector<::std::string>::iterator sppIt = scanPathParts.end();
        sppIt--;
        ::std::string name = ::boost::algorithm::to_lower_copy(*sppIt);
        //::std::string &last = *sppIt;
        if (name=="win" || name=="win32" || name=="windows")
           {
            winTargetName = *sppIt;
            fErase = true;
           }
        else if (name=="win32(vc8)")
           {
            winTargetNameVc8 = *sppIt;
            fErase = true;
           }
        else if (name=="win32(vc9)")
           {
            winTargetNameVc9 = *sppIt;
            fErase = true;
           }
        else if (name=="win32-x64")
           {
            win64TargetName = *sppIt;
            fErase = true;
           }
        else if (name=="win32-x64(vc8)")
           {
            win64TargetNameVc8 = *sppIt;
            fErase = true;
           }
        else if (name=="win32-x64(vc9)")
           {
            win64TargetNameVc9 = *sppIt;
            fErase = true;
           }

        if (fErase) scanPathParts.erase(sppIt, scanPathParts.end());

        pathForScan = ::filename::mergePath(scanPathParts);
       }


    std::vector<std::string> pathList;
    pathList.push_back(pathForScan);

    std::vector<std::string> targets;
    CScanTargetsFindData targetsScanner(targets);    
    DWORD findRes = ::winapi::findFile( pathList, _T("*"), targetsScanner, false);

    std::vector<std::string>::iterator targetIt = targets.begin();
    for(;  /* winTargetName.empty() && */  targetIt!=targets.end(); ++targetIt)
       {
        /*
        if (  ::boost::algorithm::starts_with(*targetIt, std::string("win32"))
           || ::boost::algorithm::starts_with(*targetIt, std::string("win"))
           || ::boost::algorithm::starts_with(*targetIt, std::string("windows"))
           )
           {
            winTargetName = *targetIt;
           }
        */

        ::std::string name = ::boost::algorithm::to_lower_copy(*targetIt);
        //::std::string &last = *sppIt;
        if (name=="win" || name=="win32" || name=="windows")
           {
            winTargetName = *targetIt;
            //fErase = true;
           }
        else if (name=="win32(vc8)")
           {
            winTargetNameVc8 = *targetIt;
            //fErase = true;
           }
        else if (name=="win32(vc9)")
           {
            winTargetNameVc9 = *targetIt;
            //fErase = true;
           }
        else if (name=="win32-x64")
           {
            win64TargetName = *targetIt;
            //fErase = true;
           }
        else if (name=="win32-x64(vc8)")
           {
            win64TargetNameVc8 = *targetIt;
            //fErase = true;
           }
        else if (name=="win32-x64(vc9)")
           {
            win64TargetNameVc9 = *targetIt;
            //fErase = true;
           }
       }

    if (winTargetName.empty())
       {
        std::cerr<<"Main platform (Win32) files not found in "<<pathForScan<<"\n";
       }

    removeElementsByName( targets, winTargetName );
    removeElementsByName( targets, winTargetNameVc8 );
    removeElementsByName( targets, winTargetNameVc9 );
    removeElementsByName( targets, win64TargetName );
    removeElementsByName( targets, win64TargetNameVc8 );
    removeElementsByName( targets, win64TargetNameVc9 );

/*
    if (!winTargetName.empty())
       {
        targets.erase(
                      std::remove_if( targets.begin()
                                    , targets.end()
                                    , std::bind2nd(std::equal_to<std::string>(), winTargetName) 
                                    ),
                      targets.end()
                     );
       }
*/

    
    // targetIt = targets.begin();
    // for(; targetIt!=targets.end(); ++targetIt)
    //    {
    //     if (*targetIt==winTargetName)
    //        {
    //         targets.erase(targetIt);
    //         break;
    //        }        
    //    }

//if (!singleLineComment && ::boost::algorithm::starts_with(text, std::string("*")))
// std::string pathForScan;
// std::string buildRoot;


    std::string win32Path = ::filename::makeCanonical(::filename::appendPath(pathForScan, winTargetName));
    if (opDetailed)
       {
        std::cout<<"Scaning path: "<<pathForScan<<"\n";
       }

    std::vector<std::string> confNames;
    mbs::searchForMbsConf(pathForScan, ::filename::getPath( exeFilename  /* ::winapi::getModuleFileName(0) */  ), confNames);
    
    if (opDetailed)
       {
        std::vector<std::string>::const_iterator cnIt = confNames.begin();
        std::cout<<"Conf files:\n";
        for(; cnIt!=confNames.end(); ++cnIt)
           {
            std::cout<<"    "<<*cnIt<<"\n";
           }
       }

    if (!platformMaskPatterns.empty())
       {
        std::vector<std::string> tmpTargets;
        targetIt = targets.begin();
        for(; targetIt!=targets.end(); ++targetIt)
           {
            bool allowed = false;
            std::vector<std::string>::const_iterator exIt = platformMaskPatterns.begin();
            for(; exIt!=platformMaskPatterns.end(); ++exIt)
               {
                boost::regex pattern( *exIt );
                boost::smatch matches;
                if (boost::regex_match(*targetIt, matches, pattern))
                   {
                    allowed = true;
                    if (opDetailed)
                       {
                        //std::cout<<"Platform '"<<*targetIt<<"' excluded by pattern ["<<*exIt<<"]\n";
                       }
                    break;
                   }
               }

            if (!allowed)
               {
                if (opDetailed)
                   std::cout<<"Platform '"<<*targetIt<<"' not included due to -P option rules\n";
               }
            else
               {
                tmpTargets.push_back(*targetIt);
               }
           }
        tmpTargets.swap(targets);
       }

    if (opDetailed)
       {
        std::cout<<"Found platforms:\n";

        targetIt = targets.begin();
        for(; targetIt!=targets.end(); ++targetIt)
           {
            std::cout<<"    "<<*targetIt<<"\n";
           }
       }



// std::vector<std::string> excludeMaskPatterns;
// std::vector<std::string> platformMaskPatterns;

    if (opDetailed)
       {
        std::cout<<"Lookup for solutions in: "<<win32Path<<"\n";
       }


    pathList.erase(pathList.begin(), pathList.end());
    pathList.push_back(win32Path);

    std::vector<std::string> solutions;
    CScanForSolutionsFindData solutionsScanner(solutions, win32Path);
    findRes = ::winapi::findFile( pathList, _T("*.sln"), solutionsScanner, true);

    if (!excludeMaskPatterns.empty())
       {
        std::vector<std::string> tmpSolutions;
        std::vector<std::string>::const_iterator sit = solutions.begin();
        for(; sit!=solutions.end(); ++sit)
           {
            bool excluded = false;
            std::vector<std::string>::const_iterator exIt = excludeMaskPatterns.begin();
            for(; exIt!=excludeMaskPatterns.end(); ++exIt)
               {
                boost::regex pattern( *exIt );
                boost::smatch matches;
                if (boost::regex_match(*sit, matches, pattern))
                   {
                    excluded = true;
                    if (opDetailed)
                       {
                        std::cout<<"- Solution '"<<*sit<<"' excluded by pattern ["<<*exIt<<"]\n";
                       }
                    break;
                   }
               }
            if (!excluded)
               {
                std::cout<<"+ Solution '"<<*sit<<"' included for processing\n";
                tmpSolutions.push_back(*sit);
               }
           }
        tmpSolutions.swap(solutions);
       }

    //excludeMaskPatterns

    mbs::CMbsConfig mbsConf;
    mbs::loadMbsConfigs(confNames, mbsConf);

    if (!dumpConfigFilename.empty())
       mbs::saveMbsConfig(dumpConfigFilename, mbsConf);
       

    mbs::CProjectSrcInfoCache projectsSrcInfoCache;

    ::std::vector<mbs::doc::CSolutionInfo> solutionsInfo;
    targetIt = solutions.begin();
    for(; targetIt!=solutions.end(); ++targetIt)
       {
        //std::cout<<"    "<<*targetIt<<"\n";
        mbs::CMsvcSolutionInfo slnInfo; // ���������� ����� .sln

        ::std::string solutionFullFileName = filename::appendPath(win32Path, *targetIt);
        ::std::string solutionFullpath     = filename::getPath(solutionFullFileName);

        ::std::string orgSolutionText;
        if (::mbs::util::readFileRaw(solutionFullFileName, orgSolutionText))
           {
            using filename::makeCanonical;
            using filename::getName;
            using filename::getPath;
            using filename::getExtention;
            using filename::appendExtention;
            using filename::appendPath;
            using filename::changeExtention;
            using filename::changePathChars;
            using filename::changePathCharsCopy;
            using filename::stripSlashCopy;

            if (!winTargetNameVc8.empty())
               {
                ::std::string resultFilename;
                ::std::string vc8SolutionText = ::mbs::util::slnConvertVersion( resultFilename 
                               , pathForScan, winTargetNameVc8
                               , *targetIt, orgSolutionText
                               , "10.00", "9.00", "vc8"
                               );
                winapi::forceCreateDirectory(stripSlashCopy(getPath( makeCanonical(resultFilename) )));
                ::mbs::util::writeFileRaw(resultFilename, vc8SolutionText);
               }
            if (!winTargetNameVc9.empty())
               {
                ::std::string resultFilename;
                ::std::string vc9SolutionText = ::mbs::util::slnConvertVersion( resultFilename 
                               , pathForScan, winTargetNameVc9
                               , *targetIt, orgSolutionText
                               , "9.00", "10.00", "vc9"
                               );
                winapi::forceCreateDirectory(stripSlashCopy(getPath( makeCanonical(resultFilename) )));
                ::mbs::util::writeFileRaw(resultFilename, vc9SolutionText);
               }
            if (!win64TargetNameVc8.empty())
               {
                ::std::string resultFilename;
                ::std::string vc8SolutionText = ::mbs::util::slnConvertVersion64( resultFilename 
                               , pathForScan, win64TargetNameVc8
                               , *targetIt, orgSolutionText
                               , "10.00", "9.00", "vc8"
                               );
                winapi::forceCreateDirectory(stripSlashCopy(getPath( makeCanonical(resultFilename) )));
                ::mbs::util::writeFileRaw(resultFilename, vc8SolutionText);
               }
            if (!win64TargetNameVc9.empty())
               {
                ::std::string resultFilename;
                ::std::string vc9SolutionText = ::mbs::util::slnConvertVersion64( resultFilename 
                               , pathForScan, win64TargetNameVc9
                               , *targetIt, orgSolutionText
                               , "9.00", "10.00", "vc9"
                               );
                winapi::forceCreateDirectory(stripSlashCopy(getPath( makeCanonical(resultFilename) )));
                ::mbs::util::writeFileRaw(resultFilename, vc9SolutionText);
               }
            if (!win64TargetName.empty())
               {
                ::std::string resultFilename;
                ::std::string vcSolutionText = ::mbs::util::slnConvertVersion64( resultFilename 
                               , pathForScan, win64TargetName
                               , *targetIt, orgSolutionText
                               );
                winapi::forceCreateDirectory(stripSlashCopy(getPath( makeCanonical(resultFilename) )));
                ::mbs::util::writeFileRaw(resultFilename, vcSolutionText);
               }
           }

        //std::vector<std::string> excludeProjectPatterns;
        if (mbs::parseMsvcSolution(win32Path, *targetIt, slnInfo, std::vector<std::string>()))
           {
            mbs::CMakefileSolutionInfo mkSol;
            if (mbs::makeMakefileSolution(slnInfo, mkSol))
               {
                std::vector<mbs::CMakefileInfo>::/*const_*/iterator mfIt = mkSol.makefiles.begin();
                for(; mfIt!=mkSol.makefiles.end(); ++mfIt)
                   {
                    ::std::string projectFullFileName = filename::makeCanonical(filename::appendPath(solutionFullpath, mfIt->orgRelativePath));
                    ::std::string projectFullpath     = filename::getPath(projectFullFileName);
                    ::std::string win32FullPath = filename::makeCanonical(filename::appendPath(pathForScan, winTargetName));
                    using filename::getPath;
                    using filename::subPath;
                    ::std::string projectRelativeFileName = mfIt->orgRelativePath;
                    subPath( projectRelativeFileName, win32FullPath, projectFullFileName );

                    ::std::string orgProjectText;
                    if (::mbs::util::readFileRaw(projectFullFileName, orgProjectText))
                       {
                        using filename::makeCanonical;
                        using filename::getName;
                        using filename::getPath;
                        using filename::getExtention;
                        using filename::appendExtention;
                        using filename::appendPath;
                        using filename::changeExtention;
                        using filename::changePathChars;
                        using filename::changePathCharsCopy;
                        using filename::stripSlashCopy;
                 
                        if (!winTargetNameVc8.empty())
                           {
                            ::std::string resultFilename;
                            ::std::string vc8ProjectText = ::mbs::util::vcprojConvertVersion( resultFilename 
                                           , pathForScan, winTargetNameVc8
                                           , projectRelativeFileName, orgProjectText
                                           , "9,00", "8,00", "vc8"
                                           );
                            winapi::forceCreateDirectory(stripSlashCopy(getPath( makeCanonical(resultFilename) )));
                            ::mbs::util::writeFileRaw(resultFilename, vc8ProjectText);
                           }
                        if (!winTargetNameVc9.empty())
                           {
                            ::std::string resultFilename;
                            ::std::string vc9ProjectText = ::mbs::util::vcprojConvertVersion( resultFilename 
                                           , pathForScan, winTargetNameVc9
                                           , projectRelativeFileName, orgProjectText
                                           , "8,00", "9,00", "vc9"
                                           );
                            winapi::forceCreateDirectory(stripSlashCopy(getPath( makeCanonical(resultFilename) )));
                            ::mbs::util::writeFileRaw(resultFilename, vc9ProjectText);
                           }
                        if (!win64TargetNameVc8.empty())
                           {
                            ::std::string resultFilename;
                            ::std::string vc8ProjectText = ::mbs::util::vcprojConvertVersion64( resultFilename 
                                           , pathForScan, win64TargetNameVc8
                                           , projectRelativeFileName, orgProjectText
                                           , "9,00", "8,00", "vc8"
                                           );
                            winapi::forceCreateDirectory(stripSlashCopy(getPath( makeCanonical(resultFilename) )));
                            ::mbs::util::writeFileRaw(resultFilename, vc8ProjectText);
                           }
                        if (!win64TargetNameVc9.empty())
                           {
                            ::std::string resultFilename;
                            ::std::string vc9ProjectText = ::mbs::util::vcprojConvertVersion64( resultFilename 
                                           , pathForScan, win64TargetNameVc9
                                           , projectRelativeFileName, orgProjectText
                                           , "8,00", "9,00", "vc9"
                                           );
                            winapi::forceCreateDirectory(stripSlashCopy(getPath( makeCanonical(resultFilename) )));
                            ::mbs::util::writeFileRaw(resultFilename, vc9ProjectText);
                           }
                        if (!win64TargetName.empty())
                           {
                            ::std::string resultFilename;
                            ::std::string vcProjectText = ::mbs::util::vcprojConvertVersion64( resultFilename 
                                           , pathForScan, win64TargetName
                                           , projectRelativeFileName, orgProjectText
                                           );
                            winapi::forceCreateDirectory(stripSlashCopy(getPath( makeCanonical(resultFilename) )));
                            ::mbs::util::writeFileRaw(resultFilename, vcProjectText);
                           }
        
                       }
                   }
               }
           }

        slnInfo.clear();

        if (!mbs::parseMsvcSolution(win32Path, *targetIt, slnInfo, excludeProjectPatterns))
           continue;

        if (opDetailed>8)
           {
            std::cout<<"Solution: "<<*targetIt<<"\n"<<slnInfo<<"\n";
           }

        //excludeProjectPatterns
        // �������� � ���� �������
        // ������ ������, � ���� �������, �������� � ���� ������������
        mbs::CMakefileSolutionInfo mkSol;
        if (!mbs::makeMakefileSolution(slnInfo, mkSol))
           continue;

        mbs::doc::CSolutionInfo docSln;

        //mkSol
        docSln.solutionFile = *targetIt;
        //docSln.alternateSolutionFiles[ ::std::string("win32/msvc") ][::std::string("Visual Studio (.sln)")] = *targetIt;
        //docSln.name = getName(*targetIt);
        //docSln.

        // getting source files list for each project
            {
             std::vector<mbs::CMakefileInfo>::/*const_*/iterator mfIt = mkSol.makefiles.begin();
             for(; mfIt!=mkSol.makefiles.end(); ++mfIt)
                {
                 ::std::string projectFullFileName = filename::makeCanonical(filename::appendPath(solutionFullpath, mfIt->orgRelativePath));
                 ::std::string projectFullpath     = filename::getPath(projectFullFileName);
                 // mfIt->orgRelativePath;

                 //::std::string win32FullPath = filename::makeCanonical(filename::appendPath(pathForScan, winTargetName));

                 //using filename::getPath;
                 //using filename::getPath;
                 //using filename::subPath;

                 //::std::string projectRelativeFileName = mfIt->orgRelativePath;
                 //subPath( projectRelativeFileName, win32FullPath, projectFullFileName );

                 const mbs::CProjectSrcInfo *pPrjSrcInfo = 0;
                 
                 //std::vector<std::string>::const_iterator srcIt = mfIt->sourceFiles.begin();

                 // lookup for project info in sources
                 std::vector< mbs::CProjectFile >::const_iterator srcIt = mfIt->sourceFiles.begin();                 
                 for(; srcIt!=mfIt->sourceFiles.end(); ++srcIt)
                    {
                     ::std::string srcFullFileName = filename::makeCanonical(filename::appendPath(projectFullpath, srcIt->filename));
                     //pDocPrj->sources.push_back(*srcIt); // UNDONE: 
                     //pPrjSrcInfo = prjSourcesInfoCache.getSrcInfo(sourceFile);
                     const mbs::CProjectSrcInfo *pTmpPrjSrcInfo = projectsSrcInfoCache.getSrcInfo(srcFullFileName);
                     if (pTmpPrjSrcInfo && !pPrjSrcInfo) pPrjSrcInfo = pTmpPrjSrcInfo;
                    }

                 if (pPrjSrcInfo)
                    { // need to build moc, uic processing
                     mfIt->prepareCustomBuildedFiles( pPrjSrcInfo->slnconvKnownFlags );
                    }

                 mbs::doc::CProjectInfo* pDocPrj = docSln.getProject( mfIt->relativePath );
                 pDocPrj->projectFile = mfIt->orgRelativePath;
                 pDocPrj->sources = mfIt->sourceFiles;
                }

             //mfIt = mkSol.makefiles.begin();


            }



        std::vector<std::string>::iterator targetPlatformIt = targets.begin();
        for(; targetPlatformIt!=targets.end(); ++targetPlatformIt)
           {
            std::string targetPlatformName, hostPlatformName;
            mbs::util::splitTargetAndHost( *targetPlatformIt, targetPlatformName, hostPlatformName );
            mbs::CMbsPlatformInfo platformInfo;
            //if (!mbsConf.findPlatformInfo( targetPlatformName  /* *targetPlatformIt */ , platformInfo))
            if (!mbsConf.findPlatformInfo( targetPlatformName  /* *targetPlatformIt */ , hostPlatformName, platformInfo))
               {
                std::cout<<"Could not find platform general info for target platform '"<<*targetPlatformIt<<"'\n";
                continue;
               }

            mbs::CToolset toolset;
            mbs::CPlatformHostTarget foundPlatformInfo, requestedPlatformInfo;
            requestedPlatformInfo.hostPlatform    = platformInfo.hostPlatform; // same as hostPlatformName or empty
            requestedPlatformInfo.targetPlatform  = targetPlatformName; // *targetPlatformIt;
            if (!mbsConf.getToolsetForPlatform(platformInfo, targetPlatformName  /* *targetPlatformIt */ , toolset, foundPlatformInfo))
               {
                std::cout<<"Could not find toolset for target platform '"<<*targetPlatformIt<<"' - required toolset: '"<<platformInfo.toolset<<"'\n";
                continue;
               }

            if (opDetailed)
               {
                std::cout<<"Platform: "<<*targetPlatformIt<<", host platform: "<<platformInfo.hostPlatform<<", toolset: "<<platformInfo.toolset<<" - found "<<foundPlatformInfo.targetPlatform<<" on "<<foundPlatformInfo.hostPlatform<<"\n";
               }

            mbs::CMbsHostPlatformOptions hostPlatformOptions;
            mbsConf.getHostPlatformOptions(foundPlatformInfo.hostPlatform, hostPlatformOptions);

            std::map<std::string, std::string> macroses;

            mbs::toolset::makePlatformMacroses(macroses, requestedPlatformInfo, platformInfo);

            macroses["Toolset"] = platformInfo.toolset;
            
            mbs::cb::CWorkspace cbWs;
            std::vector<mbs::cb::CProjectInfo> cbProjects;

            std::string resultScriptFileName;
            bool genRes = mkSol.generateScripts( toolset
                                               , hostPlatformOptions
                                               , mbsConf
                                               , pathForScan
                                               , requestedPlatformInfo
                                               , foundPlatformInfo
                                               , platformInfo
                                               , *targetIt
                                               , *targetPlatformIt
                                               , resultScriptFileName
                                               , macroses
                                               , generateMaks
                                               , cbWs
                                               , cbProjects
                                               , projectsSrcInfoCache
                                               , docSln
                                               );
            if (!genRes)
               {
                std::cout<<"Failed to generate solution script for "<<*targetIt<<", platform: "<<*targetPlatformIt<<"\n";
                continue;
               }
            if (opDetailed)
               {
                if (generateMaks)
                   std::cout<<"Solution script for: "<<*targetIt<<" (platform: "<<*targetPlatformIt<<") saved into "<<resultScriptFileName<<"\n";
               }

            if (generateCodeblocks)
               {
                if (!cbWs.save())
                   {
                    std::cout<<"Failed to generate CodeBlocks workspace file for "<<*targetIt<<", platform: "<<*targetPlatformIt<<"\n";
                   }
                std::vector<mbs::cb::CProjectInfo>::const_iterator pit = cbProjects.begin();
                for(; pit!=cbProjects.end(); ++pit)
                   {
                    if (!pit->save())
                       {
                        std::cout<<"Failed to generate CodeBlocks project file for project "<<pit->name<<", "<<*targetIt<<", platform: "<<*targetPlatformIt<<"\n";
                       }
                   }
                //workspaceFilename
                //docSln.alternateSolutionFiles[ platformInfo.realName + ::std::string(" (mkproj)") ] = resultScriptFileName;
                /*
                docSln.alternateSolutionFiles[ platformInfo.getRealName() 
                                             + ::std::string("/") 
                                             + toolset.name 
                                             + ::std::string(" CodeBlocks (.workspace)") 
                                             ] = changeExtention(resultScriptFileName, ".workspace");
                */                              
                docSln.alternateSolutionFiles[ foundPlatformInfo.targetPlatform //*targetPlatformIt // platformInfo.getRealName() 
                                             + ::std::string("/") 
                                             + toolset.name 
                                             + ::std::string(" (") 
                                             + *targetPlatformIt
                                             + ::std::string(")") 
                                             ][ ::std::string("CodeBlocks (.workspace)") 
                                             ] = changeExtention(resultScriptFileName, ".workspace");

               }

            //getRealName()
            //toolset.name

            docSln.alternateSolutionFiles[ foundPlatformInfo.targetPlatform // *targetPlatformIt // platformInfo.getRealName() 
                                         + ::std::string("/") 
                                         + toolset.name
                                         + ::std::string(" (") 
                                         + *targetPlatformIt
                                         + ::std::string(")") 
                                         ][::std::string("make (") 
                                         + hostPlatformOptions.shellExt() 
                                         + ::std::string(")") 
                                         ] = resultScriptFileName;
            

           }

        solutionsInfo.push_back(docSln);
        //resultScriptFileName
       }

    updateProjectPaths( solutionsInfo
                      , ::std::string("../build")
                      , ::std::string("../build/")+winTargetName
                      , ::std::string("../src") 
                      );

    if (generateHtmlSummaryInfo)
       {
        ::std::string psFileName = makeCanonical(appendPath(win32Path, ::std::string("../../doc.src/projectSummary.html")));        
        winapi::forceCreateDirectory(filename::stripSlashCopy(filename::getPath(psFileName)));
        //std::ofstream os("projectSummary.html");
        std::ofstream os(psFileName.c_str()); // "projectSummary.html"
        generateHtmlSummary( os, solutionsInfo);
       }
    

    //::std::vector<mbs::doc::CSolutionInfo> solutionsInfo;
    

    return 0;
   }



//-----------------------------------------------------------------------------
int read_config_file(const char* fname) 
{
 std::ifstream cfg(fname);
 std::string cfg_line;
 std::getline(cfg,cfg_line);
 cfg_line = ::boost::algorithm::trim_copy(cfg_line); //trim(cfg_line);  
 while(cfg && cfg_line.size())
   {
      int pr = 0;
      switch(cfg_line[0])
        {
         case '-':
         case '/':  pr = parse_option(cfg_line.c_str());
                    break;
//         case '@':  pr = read_config_file(argv[i]+1);
//                    break;
         //default:   //std::string infile = cfg_line;
                    //infile = trim(infile);
                    //if (infile.size())
                    //   input_files.push_back(infile);
        };
//    int pr = parse_option(cfg_line.c_str());
    if (pr) return pr;
    std::getline(cfg,cfg_line);
    cfg_line = ::boost::algorithm::trim_copy(cfg_line); //trim(cfg_line);  
   }
 return 0;
}


//-----------------------------------------------------------------------------
int parse_option(const char* s)
{
 if (*s!='-' && *s!='/')
    {
     std::cout<<"Invalid command line option: '"<<s<<"'\n";
     return 1;
    }
 char key = *((++s)++);

 // if (key=='I')
 //    {
 //     add_include_path(s, !checkIncludeOnly);
 //     return 0;
 //    }


 switch(key)
   {
    case 's': statFile = s;
              break;

    case 'p': 
              pathForScan = s;
              break;

    // case 'q': 
    //           opQuet = true;
    //           break;
    //  
    case 'd': 
              switch(*s)
                 {
                  case '-':
                  case '0': opDetailed = 0; break;

                  case '1': opDetailed = 1; break;
                  case '2': opDetailed = 2; break;
                  case '3': opDetailed = 3; break;
                  case '4': opDetailed = 4; break;
                  case '5': opDetailed = 5; break;
                  case '6': opDetailed = 6; break;
                  case '7': opDetailed = 7; break;
                  case '8': opDetailed = 8; break;
                  case '9': case '+': opDetailed = 9; break;
                  //case '':
                 };
              break;

    case 'D': 
              dumpConfigFilename = s;
              break;



    case 'w':
              showWhere = true;
              break;

    case 'e':
              excludeMaskPatterns.push_back(s);
              break;

    case 'r':
              excludeProjectPatterns.push_back(s);
              break;

    case 'P':
              platformMaskPatterns.push_back(s);
              break;

    case 't':
              toolsetName = s;
              break;

    case 'v':
              {
               char subkey = *s++;
               if (subkey!='c')
                  {
                   std::cout<<"Invalid '-v' option\n"; return 2;
                  }
               else
                  {
                   char subkey = *s++;

                   switch(subkey)
                       {
                        case '8': 
                                  if (*s=='-')             generateVc8 = false;
                                  else if (!*s || *s=='+') generateVc8 = true;
                                  else { std::cout<<"Invalid '-vc8' option value\n"; return 2; }
                                  break;
                        case '9': 
                                  if (*s=='-')             generateVc9 = false;
                                  else if (!*s || *s=='+') generateVc9 = true;
                                  else { std::cout<<"Invalid '-vc9' option value\n"; return 2; }
                                  break;
                        default:
                                  std::cout<<"Invalid '-vc' option\n"; return 2;
                       };
                  }
              };
              break;

    case 'o':
              {
               char subkey = *s++;
               switch(subkey)
                   {
                    case 'm': 
                              if (*s=='-')      generateMaks = false;
                              else if (*s=='+') generateMaks = true;
                              else { std::cout<<"Invalid '-om' option value\n"; return 2; }
                              break;
                                     
                    case 'c':
                              if (*s=='-')      generateCodeblocks = false;
                              else if (*s=='+') generateCodeblocks = true;
                              else { std::cout<<"Invalid '-om' option value\n"; return 2; }
                              break;

                    case 'h':
                              if (*s=='-')      generateHtmlSummaryInfo = false;
                              else if (*s=='+') generateHtmlSummaryInfo = true;
                              else { std::cout<<"Invalid '-om' option value\n"; return 2; }
                              break;

                    default:
                              std::cout<<"Invalid '-o' option\n"; return 2;
                   }
              };
              break;


    // case 'w':
    //           showWhere = true;
    //           break;
    //  
    // case 'b': 
    //  
    //           if (std::string(s)=="all")
    //              {
    //               makeAllTargetsVector(buildTargetTypesList);
    //              }
    //           else
    //              {
    //               buildTargetTypesList.push_back(s);
    //              }
    //           break;
    //  
    case '?': 
    case 'h': 
              print_help();
              return 3;              

    default:  
              std::cout<<"Invalid command line option: '-"<<key<<s<<"'\n";
              print_help();
              return 2;
   };
// macro_adddef("CMDOPTION", "", std::string(--s) + std::string(" "), "cmd_line", 0, 1);
 return 0;
}

//-----------------------------------------------------------------------------
void print_help()
{
 std::cout<<"MBS solution converter\n";
 std::cout<<"Converts MSVC sln and vcproj files to sh/bat scripts and mkproj (make project) files\n";
 std::cout<<"Usage: slnconv [-option [-option]]\n";
 std::cout<<"Options:\n";
 std::cout<<"  -pPath          - path, where sln files will be searched.\n";
 std::cout<<"                    Default - current directory.\n";
 std::cout<<"  -dN             - detail level 0-9.\n";
 std::cout<<"                    '+' sign threated as 9, '-' sign as 0.\n";
 std::cout<<"  -Dfile          - dump configuration into file 'file'.\n";
 std::cout<<"  -w              - prints path/name, where is slnconv placed, and exit.\n";
 std::cout<<"  -ePat           - exclude solution files with taken mask 'Pat'. Pattern is an regex.\n";
 std::cout<<"  -rPat           - exclude project files with taken mask 'Pat'. Other projects in solution still used. Pattern is an regex.\n";
 std::cout<<"  -PPat           - include target platform for processing with pattern 'Pat'.\n";
 std::cout<<"                    If no -P options taken, all platforms will be processed.\n";
 std::cout<<"  -oX+|-          - generate output on/off, X - output type:\n";
 std::cout<<"                    m - generate make files on/off\n";
 std::cout<<"                    c - generate codeblocks workspace/project files on/off\n";
 std::cout<<"                    h - generate html summary information file on/off\n";
 std::cout<<"  -vc8              h - generate msvc 8.0 projects/solutions\n";
 std::cout<<"  -vc9              h - generate msvc 9.0 projects/solutions\n";
// std::cout<<"                    \n";


}
