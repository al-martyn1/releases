#ifndef PRJFILE_H
#define PRJFILE_H

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif


#include <marty/winapi.h>
#include <marty/filename.h>

#ifdef USE_MARTY_NAMESPACE
using namespace ::marty;
#endif


namespace mbs
{

typedef filename::tstring  tstring;

namespace util
{

//-----------------------------------------------------------------------------
template<class ForwardIterator, class Type>
ForwardIterator binary_find( ForwardIterator _First
                           , ForwardIterator _Last
                           , const Type& _Val
                           )
   {
    _First = std::lower_bound(_First, _Last, _Val);
    return _First == _Last ? _Last : (       _Val < *_First   ? _Last : _First);
   }

//-----------------------------------------------------------------------------
template<class ForwardIterator, class Type, class BinaryPredicate>
ForwardIterator binary_find( ForwardIterator _First
                           , ForwardIterator _Last
                           , const Type& _Val
                           , BinaryPredicate _Comp
                           )
   {
    _First = std::lower_bound(_First, _Last, _Val, _Comp);
    return _First == _Last ? _Last : ( _Comp(_Val , *_First)  ? _Last : _First);
   }


}; // namespace util



struct CProducedFile
{
    tstring                     filename;  // produced file
    tstring                     buildTool;

    CProducedFile() : filename(), buildTool() {}
    CProducedFile( const std::string &f, const std::string &bt) : filename(f), buildTool(bt) {}

};


struct CProjectFile
{
    tstring                       filename;
    ::std::vector< tstring >      excludedConfigurations;
    ::std::vector< tstring >      includedConfigurations;
                                 
    std::string                   dependendOn;
    std::string                   buildTool  ;
    std::vector<CProducedFile>    producedFiles;

    std::vector< ::std::string >  additionalIncludes;

    CProjectFile() 
       : filename()
       , excludedConfigurations()
       , includedConfigurations()
       , dependendOn()
       , buildTool  ()
       , additionalIncludes()
       {}

    explicit CProjectFile(const tstring &f) 
       : filename(f)
       , excludedConfigurations()
       , includedConfigurations()
       , dependendOn()
       , buildTool  ()
       , additionalIncludes()
       {}

    explicit CProjectFile(const tstring &f, const ::std::vector< tstring > &ex) 
       : filename(f)
       , excludedConfigurations(ex)
       , includedConfigurations()
       , dependendOn()
       , buildTool  ()
       , additionalIncludes()
       {
        ::std::sort( excludedConfigurations.begin(), excludedConfigurations.end() );
       }

    void setExcludedConfigurations( const ::std::vector< tstring > &ex)
       {
        excludedConfigurations = ex;
        ::std::sort( excludedConfigurations.begin(), excludedConfigurations.end() );
       }

    bool isExcluded( const tstring &cfgName)
       {
        if (excludedConfigurations.empty()) return false; // no excluded configs, all included by default
        ::std::vector< tstring >::const_iterator it = util::binary_find( excludedConfigurations.begin(), excludedConfigurations.end(), cfgName );
        if (it==excludedConfigurations.end()) return false;
        return true;
       }

    bool isIncluded( const tstring &cfgName)
       {
        if (includedConfigurations.empty()) return true;
        ::std::vector< tstring >::const_iterator it = util::binary_find( includedConfigurations.begin(), includedConfigurations.end(), cfgName );
        if (it==includedConfigurations.end()) return false;
        return true;
       }

    void buildIncludedList( const ::std::vector< tstring > &allConfigurations )
       {
        if (excludedConfigurations.empty()) return; // don't need to build included list, all included by default
        ::std::vector< tstring >::const_iterator it = allConfigurations.begin();
        for(; it!=allConfigurations.end(); ++it)
           {
            if (isExcluded(*it)) continue;
            includedConfigurations.push_back(*it);
           }
        ::std::sort( includedConfigurations.begin(), includedConfigurations.end() );
       }

    void getIncludedConfigurations( ::std::vector< tstring > &incConfigurations ) const
       {
        incConfigurations = includedConfigurations;
       }
};




}; // namespace mbs



#endif /* PRJFILE_H */

