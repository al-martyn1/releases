#ifndef MBS_CODEBLOCKS_H
#define MBS_CODEBLOCKS_H

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>


#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_UTILITY_) && !defined(_STLP_UTILITY) && !defined(__STD_UTILITY__) && !defined(_CPP_UTILITY) && !defined(_GLIBCXX_UTILITY)
    #include <utility>
#endif

#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif

#include <malloc.h>

#include <sixml/sixmlx.h>

#include <sixml/serializ.h>

#ifndef BOOST_STRING_TRIM_HPP
    #include <boost/algorithm/string/trim.hpp>
#endif

#include <marty/filename.h>
#include <marty/macroses.h>


#include "toolset.h"
#include "prjfile.h"
#include "text-fmt.h"

#ifdef USE_MARTY_NAMESPACE
using namespace ::marty;
#endif

namespace mbs
{


namespace cb  // CodeBlocks
{

inline
void commandListRemoveLeadingAt(std::string &cmdlist)
   {
    txt::util::processTextLines(cmdlist, std::string("\\n"), txt::util::CLineTrimAndRemoveLeadingChar('@') );
   }


//typedef filename::tstring  tstring;


/*
<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>
<CodeBlocks_workspace_file>
    <Workspace title="Workspace">
        <Project filename="testCConsole\testCConsole.cbp" />
        <Project filename="testCppConsole\testCppConsole.cbp" />
        <Project filename="testCppDll\testCppDll.cbp" active="1" />
    </Workspace>
</CodeBlocks_workspace_file>
*/



struct CDepends
{
    ::std::string    filename; // relative path
    CDepends() : filename() {}
    explicit CDepends(const ::std::string &fn) : filename(fn) {}
    CDepends(const CDepends &d) : filename(d.filename) {}

    //bool operator==(const CDepends &d)

    STRUCT_LAYOUT_DEFAULT(CDepends)
            attribute(_T("filename")  , &CDepends::filename );
    END_STRUCT_LAYOUT()



}; // struct CDepends


struct CWorkspaceProjectInfo
{
    ::std::string            projectName; // not saved, used for sort
    ::std::string            filename; // relative path
    int                      active;
    ::std::vector<CDepends>  dependencies;

    CWorkspaceProjectInfo() : projectName(), filename(), active(0), dependencies() {}
    CWorkspaceProjectInfo(const CWorkspaceProjectInfo& c) : projectName(c.projectName), filename(c.filename), active(c.active), dependencies(c.dependencies) {}
    explicit CWorkspaceProjectInfo(const std::string &fn, const std::string &pn) : projectName(pn), filename(fn), active(0), dependencies() {}

    STRUCT_LAYOUT_DEFAULT(CWorkspaceProjectInfo)
            attribute(_T("filename")  , &CWorkspaceProjectInfo::filename     );
            attribute(_T("active")    , &CWorkspaceProjectInfo::active       , int(0) );
            array    ( 0              , &CWorkspaceProjectInfo::dependencies , _T("Depends"));
    END_STRUCT_LAYOUT()

    void setActive(bool bActive = true) { active = bActive ? 1 : 0; }
    void addDependency(const ::std::string &dep) { dependencies.push_back(CDepends(dep)); }

};

inline
bool wsProjectInfoLess( const CWorkspaceProjectInfo &wspi1, const CWorkspaceProjectInfo &wspi2 )
   {
    return wspi1.projectName < wspi2.projectName;
   }





struct CWorkspace;

bool loadWorkspace(const std::string &filename, CWorkspace &ws);
//bool saveWorkspace(const std::string &filename, const CWorkspace &ws);
bool saveWorkspace(const std::string &filename, CWorkspace ws);

bool loadWorkspace(CWorkspace &ws);
bool saveWorkspace(const CWorkspace &ws);


struct CWorkspace
{
    std::string                         workspaceFilename; // not seroalized
    std::string                         name; // title
    std::vector<CWorkspaceProjectInfo>  projects;

    bool load()       { return loadWorkspace(*this); }
    bool save() const { return saveWorkspace(*this); }

    STRUCT_LAYOUT_DEFAULT(CWorkspace)
            attribute(_T("title") , &CWorkspace::name);
            array(0               , &CWorkspace::projects, _T("Project"));
    END_STRUCT_LAYOUT()

    void sortProjects()
       {
        std::sort( projects.begin(), projects.end(), wsProjectInfoLess );
       }

};

inline
bool loadWorkspace(CWorkspace &ws)
   {
    return loadWorkspace(ws.workspaceFilename, ws);
   }

inline
bool saveWorkspace(const CWorkspace &ws)
   {
    return saveWorkspace(ws.workspaceFilename, ws);
   }


// <FileVersion major="1" minor="6" />
struct CFileVersion
{
    int      major;
    int      minor;

    CFileVersion()                         : major(0) , minor(0)  {}
    explicit CFileVersion(int mj)          : major(mj), minor(0)  {}
    explicit CFileVersion(int mj, int mn)  : major(mj), minor(mn) {}
    CFileVersion(const CFileVersion &fv)   : major(fv.major), minor(fv.minor) {}

    STRUCT_LAYOUT_DEFAULT(CFileVersion)
            attribute(_T("major") , &CFileVersion::major , int(0) );
            attribute(_T("minor") , &CFileVersion::minor , int(0) );
    END_STRUCT_LAYOUT()
}; // struct CFileVersion


#define CB_OUTPUT_TYPE_GUI_APP       0
#define CB_OUTPUT_TYPE_CONSOLE       1
#define CB_OUTPUT_TYPE_STATIC_LIB    2
#define CB_OUTPUT_TYPE_DYNAMIC_LIB   3
//#define CB_OUTPUT_TYPE_

struct COption
{
    std::string         title;
    int                 pch_mode; // -1 default
    std::string         compiler;
    std::string         output;
    int                 prefix_auto; // -1 default
    int                 extension_auto; // -1 default
    int                 type; // -1 default
                              // 0 - GUI App target
                              // 1 - Console App target
                              // 2 - Static Lib target
                              // 3 - Dynamic Lib target
    int                 use_console_runner; 
    std::string         object_output;
    std::string         working_dir;
    std::string         deps_output;
    std::string         compilerVar;

    int                 show_notes;
    std::string         notes;

    std::string         platforms; // Windows;Unix;Mac;
    std::string         target   ; // Windows;Unix;Mac;

    int                 createDefFile;
    int                 createStaticLib;

    int                 compile;
    int                 link;
    int                 weight;
    //std::string         compiler;
    int                 use;
    std::string         buildCommand;

    //std::string         compiler;

    STRUCT_LAYOUT_DEFAULT(COption)
            attribute(_T("title")          , &COption::title          , std::string() );
            attribute(_T("pch_mode")       , &COption::pch_mode       , int(-1)       );
            attribute(_T("compiler")       , &COption::compiler       , std::string() );
            attribute(_T("output")         , &COption::output         , std::string() );
            attribute(_T("prefix_auto")    , &COption::prefix_auto    , int(-1)       );
            attribute(_T("extension_auto") , &COption::extension_auto , int(-1)       );
            attribute(_T("type")           , &COption::type           , int(-1)       );
            attribute(_T("use_console_runner"), &COption::use_console_runner, int(-1) );
            attribute(_T("object_output")  , &COption::object_output  , std::string() );
            attribute(_T("working_dir")    , &COption::working_dir    , std::string() );
            attribute(_T("deps_output")    , &COption::deps_output    , std::string() );
            attribute(_T("compilerVar")    , &COption::compilerVar    , std::string() );
            attribute(_T("show_notes")     , &COption::show_notes     , int(-1)       );
            simple   (_T("notes")          , &COption::notes          , std::string() );
            simple   (_T("platforms")      , &COption::platforms      , std::string() );
            attribute(_T("target")         , &COption::target         , std::string() );
            attribute(_T("createDefFile")  , &COption::createDefFile  , int(-1) );
            attribute(_T("createStaticLib"), &COption::createStaticLib, int(-1) );
            attribute(_T("compile")        , &COption::compile        , int(-1) );
            attribute(_T("link")           , &COption::link           , int(-1) );
            attribute(_T("weight")         , &COption::weight         , int(-1) );
            //attribute(_T("compiler")       , &COption::compiler       , std::string() );
            attribute(_T("use")            , &COption::use            , int(-1) );
            attribute(_T("buildCommand")   , &COption::buildCommand   , std::string() );
            
            //attribute(_T("compiler")       , &COption::compiler       , std::string() );
    END_STRUCT_LAYOUT()

    COption()
       : title()
       , pch_mode(-1)
       , compiler()
       , output()
       , prefix_auto(-1)
       , extension_auto(-1)
       , type(-1)
       , use_console_runner(-1)
       , object_output()
       , working_dir()
       , deps_output()
       , compilerVar()
       , show_notes(-1)
       , notes()
       , platforms()
       , target()
       , createDefFile(-1)
       , createStaticLib(-1)
       , compile(-1)
       , link(-1)
       , weight(-1)      
       //, compiler()    
       , use(-1)         
       , buildCommand()
       {}

    COption(const COption &po)
       : title(po.title)
       , pch_mode(po.pch_mode)
       , compiler(po.compiler)
       , output(po.output)
       , prefix_auto(po.prefix_auto)
       , extension_auto(po.extension_auto)
       , type(po.type)
       , use_console_runner(po.use_console_runner)
       , object_output(po.object_output)
       , working_dir(po.working_dir)
       , deps_output(po.deps_output)
       , compilerVar(po.compilerVar)
       , show_notes(po.show_notes)
       , notes(po.notes)
       , platforms(po.platforms)
       , target(po.target)
       , createDefFile(po.createDefFile)
       , createStaticLib(po.createStaticLib)
       , compile(po.compile)
       , link(po.link)
       , weight(po.weight)      
       //, compiler(po.compiler)    
       , use(po.use)         
       , buildCommand(po.buildCommand)
       {}

    bool operator==(const COption &po)
       {
        return title == po.title
            && pch_mode == po.pch_mode
            && compiler == po.compiler
            && output == po.output
            && prefix_auto == po.prefix_auto
            && extension_auto == po.extension_auto
            && type == po.type
            && use_console_runner == po.use_console_runner
            && object_output == po.object_output
            && working_dir == po.working_dir
            && deps_output == po.deps_output
            && compilerVar == po.compilerVar
            && show_notes == po.show_notes
            && notes == po.notes
            && platforms == po.platforms
            && target == po.target
            && createDefFile == po.createDefFile
            && createStaticLib == po.createStaticLib
            && compile == po.compile
            && link == po.link
            && weight == po.weight
            //&& compiler == po.compiler
            && use == po.use
            && buildCommand == po.buildCommand
            ;
       }

    bool operator!=(const COption &po) { return !operator==(po); }
    /*
    <Option title="testCConsole" />
    <Option pch_mode="2" />
    <Option compiler="gcc" />
    <Option output="bin\Debug\testCConsole" prefix_auto="1" extension_auto="1" />
    <Option object_output="obj\Debug\" />
    <Option type="1" />
    <Option compiler="gcc" />
    <Option compilerVar="CC" />
    */


}; // struct Option


struct CAdd
{
    std::string     option;
    std::string     directory;
    std::string     library;
    

    CAdd() : option(), directory(), library() {}
    //CAdd(const std::string &a) : option(a), directory() {}
    CAdd(const CAdd &a) : option(a.option), directory(a.directory), library(a.library) {}

    STRUCT_LAYOUT_DEFAULT(CAdd)
            attribute(_T("option")   , &CAdd::option   , std::string() );
            attribute(_T("directory"), &CAdd::directory, std::string() );
            attribute(_T("library")  , &CAdd::library  , std::string() );
    END_STRUCT_LAYOUT()

    bool operator==(const CAdd &a) const
       {
        return option==a.option
            && directory==a.directory
            && library==a.library;
       }

    bool operator!=(const CAdd &a) const { return !operator==(a); }
};

struct CCompiler
{
    std::vector<CAdd>   options;
    CCompiler() : options() {}
    CCompiler(const CCompiler &c) : options(c.options) {}

    void addOption(const std::string &opt)  { CAdd add; add.option    = opt; if (::std::find(options.begin(), options.end(), add)==options.end()) options.push_back(add); }
    void addDirectory(const std::string &d) { CAdd add; add.directory = d  ; if (::std::find(options.begin(), options.end(), add)==options.end()) options.push_back(add); }
    void addLibrary(const std::string &l)   { CAdd add; add.library   = l  ; if (::std::find(options.begin(), options.end(), add)==options.end()) options.push_back(add); }

    STRUCT_LAYOUT_DEFAULT(CCompiler)
            array( 0, &CCompiler::options, _T("Add") );
    END_STRUCT_LAYOUT()
};
/*
        <Unit filename="main.cpp">
            <Option target="Release" />
        </Unit>
*/
struct CUnit
{
    std::string             filename;
    std::vector<COption>    options;

    void addOption(const COption &opt) { options.push_back(opt); }
    void setCompilerVar(const std::string &compilerVar) { COption opt; opt.compilerVar = compilerVar; addOption(opt); }

    CUnit() : filename(), options() {}
    CUnit(const CUnit &cu) : filename(cu.filename), options(cu.options) {}
    explicit CUnit(const std::string &fn) : filename(fn), options() {}
    explicit CUnit(const std::string &fn, const std::string &compilerVar) : filename(fn), options() 
       { setCompilerVar(compilerVar); }

    explicit CUnit(const std::string &fn, const std::string &compilerVar, bool fCompile, bool fLink = false) 
       : filename(fn)
       , options() 
       { 
        setCompilerVar(compilerVar);
        COption optCompile; optCompile.compile = fCompile ? 1 : 0; addOption(optCompile);
        COption optLink   ; optLink   .compile = fLink    ? 1 : 0; addOption(optLink);
       }

    void setCustomBuildCommand(const std::string &compilerName, const std::string &buildCommand)
       {
        COption opt;
        opt.compiler = compilerName;
        opt.use = 1;
        /*
        std::vector<std::string> lines;
        txt::util::splitTextToLines(lines, buildCommand);
        std::string resCmd; resCmd.reserve(buildCommand.size());
        std::vector<std::string>::const_iterator lit = lines.begin();
        for(; lit!=lines.end(); ++lit)
           {
            if (!resCmd.empty()) resCmd.append("\\n");
            std::string line = boost::algorithm::trim_copy(*lit);
            if (line.empty()) continue;
            resCmd.append(line);
           }
        opt.buildCommand = resCmd; //txt::util::escapeLinefeeds(boost::algorithm::trim_copy(buildCommand));
        */
        opt.buildCommand = txt::util::processTextLinesCopy(buildCommand, std::string("\\n"), txt::util::CLineTrim() );
        addOption(opt);
       }

    void setWeight(int w)
       {
        if (w<0)   w = 0;
        if (w>100) w = 100;
        COption opt;
        opt.weight = w;
        addOption(opt);
       }

    void setCompileFlag() { COption opt; opt.compile = 1; addOption(opt); }
    void setLinkFlag   () { COption opt; opt.link    = 1; addOption(opt); }

    STRUCT_LAYOUT_DEFAULT(CUnit)
            attribute( _T("filename"), &CUnit::filename ); // mandatory
            array    ( 0, &CUnit::options, _T("Option") );
    END_STRUCT_LAYOUT()

};


#define CB_ADD_OPTION(obj, optName, optVal)    \
                    {                          \
                     mbs::cb::COption opt;     \
                     opt . optName = optVal;   \
                     obj . addOption(opt);     \
                    }

#define CB_ADD_OPTION_BYP(obj, optName, optVal) \
                    {                           \
                     mbs::cb::COption opt;      \
                     opt . optName = optVal;    \
                     obj -> addOption(opt);     \
                    }

// <Variable name="target" value="T3"/>
struct CVariable
{
    ::std::string    name;
    ::std::string    value;
    CVariable() : name(), value() {}
    CVariable(const ::std::string &n, const ::std::string &v) : name(n), value(v) {}

    STRUCT_LAYOUT_DEFAULT(CVariable)
            attribute(_T("name" )  , &CVariable::name , ::std::string() );
            attribute(_T("value")  , &CVariable::value, ::std::string() );
    END_STRUCT_LAYOUT()
};


struct CEnvironment
{
    ::std::vector< CVariable > variables;
    STRUCT_LAYOUT_DEFAULT(CEnvironment)
            array(0  , &CEnvironment::variables, _T("Variable") );
    END_STRUCT_LAYOUT()

    void addVariable(const ::std::string &n, const ::std::string &v) { variables.push_back(CVariable(n,v)); }
};

struct CTarget
{
    protected:
    std::string              name; // attr title
    public:
    std::vector<COption>     options;
    CCompiler                compiler;
    CCompiler                linker;
    std::vector<std::string> compilerOptionsAux;
    std::string              compilerToolset;
    //std::vector<CEnvironment> environment;
    CEnvironment             environment;
  

/*
<Environment>
                    <Variable name="target" value="T3"/>
</Environment>
*/

    

    CTarget()
       : name()
       , options()
       , compiler()
       , linker()
       , compilerOptionsAux()
       , compilerToolset()
       , environment()
       {}

    CTarget(const CTarget &t)
       : name(t.name)
       , options(t.options)
       , compiler(t.compiler)
       , linker(t.linker)
       , compilerOptionsAux(t.compilerOptionsAux)
       , compilerToolset(t.compilerToolset)
       , environment(t.environment)
       {}

    explicit CTarget(const std::string &tn)
       : name(tn)
       , options()
       , compiler()
       , linker()
       , compilerOptionsAux()
       , compilerToolset()
       , environment()
       {
        addEnvironmentVariable("target", tn);
        addEnvironmentVariable("target_name", tn);
        addEnvironmentVariable("configuration", tn);
        addEnvironmentVariable("configuration_name", tn);
       }

    void setName(const ::std::string &tn)
       {
        name = tn;
        addEnvironmentVariable("target", tn);
        addEnvironmentVariable("target_name", tn);
        addEnvironmentVariable("configuration", tn);
        addEnvironmentVariable("configuration_name", tn);
       }

    void addEnvironmentVariable(const ::std::string &n, const ::std::string &v) { environment.addVariable(n,v); }

    void addOption(const COption &opt) { options.push_back(opt); }
    void compilerOptionAuxToOptions()
       {
        std::vector<std::string>::const_iterator it = compilerOptionsAux.begin();
        for(; it!=compilerOptionsAux.end(); ++it)
           {
            compiler.addOption(*it);
           }
       }

    STRUCT_LAYOUT_DEFAULT(CTarget)
            attribute( _T("title")       , &CTarget::name   ); // mandatory
            array    ( 0                 , &CTarget::options, _T("Option") );
            complex  ( _T("Compiler")    , &CTarget::compiler, CCompiler() );
            complex  ( _T("Linker")      , &CTarget::linker  , CCompiler() );
            complex  ( _T("Environment") , &CTarget::environment  , CEnvironment() );
    END_STRUCT_LAYOUT()
};


struct CBuild
{
    std::vector<CTarget>       targets;
    CBuild() : targets() {}
    CBuild(const CBuild &cb) : targets(cb.targets) {}

    void addTarget(const CTarget &t) { targets.push_back(t); }

    STRUCT_LAYOUT_DEFAULT(CBuild)
            array    ( 0               , &CBuild::targets, _T("Target") );
    END_STRUCT_LAYOUT()

};

/*
        <Compiler>
            <Add option="-Wall" />
        </Compiler>
        <Unit filename="main.c">
            <Option compilerVar="CC" />
        </Unit>
        <Extensions>
            <code_completion />
            <debugger />
        </Extensions>
*/


/*
        <Extensions>
            <code_completion>
                <search_path add="$(#BOOST.include)" />
                <search_path add="$(#MARTYUSR.include)" />
            </code_completion>
            <debugger />
        </Extensions>
*/

struct CAttrAdd
{
    ::std::string  add;
    CAttrAdd() : add() {}
    CAttrAdd(const CAttrAdd &sp) : add(sp.add) {}
    CAttrAdd(const ::std::string &a) : add(a) {}

    STRUCT_LAYOUT_DEFAULT(CAttrAdd)
            attribute( _T("add")    , &CAttrAdd::add ); // mandatory
    END_STRUCT_LAYOUT()

    bool operator==(const CAttrAdd &a) const
       {
        return a.add==add;
       }

    /* bool operator==(const ::std::string &s)
     *    {
     *     return add==s;
     *    }
     */

    bool operator!=(const CAttrAdd &a) const { return !operator==(a); }

    /* bool operator=!(const ::std::string &s) { return !operator==(s); }
     */

}; // struct CAttrAdd


struct CCodeCompletion
{
    ::std::vector<CAttrAdd>   search_path;
    CCodeCompletion() : search_path() {}
    CCodeCompletion(const CCodeCompletion &cc) : search_path(cc.search_path) {}

    STRUCT_LAYOUT_DEFAULT(CCodeCompletion)
            array( 0    , &CCodeCompletion::search_path, _T("search_path") ); // mandatory
    END_STRUCT_LAYOUT()

    void addSearchPath(const ::std::string &path) { CAttrAdd sp(path); if (::std::find(search_path.begin(), search_path.end(), sp)==search_path.end()) search_path.push_back(sp); }

}; // struct CCodeCompletion


struct CExtensions
{
    CCodeCompletion   code_completion;

    CExtensions() : code_completion() {}
    CExtensions(const CExtensions &e) : code_completion(e.code_completion) {}

    STRUCT_LAYOUT_DEFAULT(CExtensions)
            complex( _T("code_completion"), &CExtensions::code_completion, CCodeCompletion() );
    END_STRUCT_LAYOUT()

}; // struct CExtensions


struct CProjectInfo;

bool loadProject(const std::string &filename, CProjectInfo &pi);
bool saveProject(const std::string &filename, const CProjectInfo &pi);

bool loadProject(CProjectInfo &pi);
bool saveProject(const CProjectInfo &pi);


struct CProjectInfo
{
    std::string             projectFilename; // not serialized
    int                     verMajor;
    int                     verMinor;

    std::string             name; // Option title
    std::vector<COption>    options;
    CBuild                  build;
    CCompiler               compiler;
    std::vector<CUnit>      units;
    CExtensions             extensions;


    std::string             compilerToolset; // not serialized


    CProjectInfo() 
       : projectFilename()
       , verMajor(1)
       , verMinor(6)
       , name()
       , options()
       , build()
       , compiler()
       , units()
       , extensions()
       , compilerToolset()
       {}

    CProjectInfo(const CProjectInfo &pi) 
       : projectFilename(pi.projectFilename)
       , verMajor(pi.verMajor)
       , verMinor(pi.verMinor)
       , name(pi.name)
       , options(pi.options)
       , build(pi.build)
       , compiler(pi.compiler)
       , units(pi.units)
       , extensions(pi.extensions)
       , compilerToolset(pi.compilerToolset)
       {}

    bool load()       { return loadProject(*this); }
    bool save() const { return saveProject(*this); }

    void addOption(const COption &opt) { options.push_back(opt); }
    void addUnit(const CUnit &u)       { units.push_back(u); }
    void addUnit(const std::string &filename, const std::string &compilerVar) { addUnit(CUnit(filename, compilerVar)); }
    void addUnitWithTargets( const std::string &filename
                           , const std::string &compilerVar
                           , const std::vector< ::std::string > &targets
                           ) 
       { 
        CUnit unit(filename, compilerVar);
        std::vector< ::std::string >::const_iterator it = targets.begin();
        for(; it!=targets.end(); ++it)
           {
            COption opt; opt.target = *it;
            unit.addOption(opt);
           }
        addUnit(unit); 
       }

    void setName(const std::string &n)       { name = n; COption opt; opt.title = n ; addOption(opt); }
    ::std::string getName() const            { return name; }
    void setPchMode(int pchMode)             { COption opt; opt.pch_mode = pchMode  ; addOption(opt); }
    void setCompiler(const std::string &cc)  { COption opt; opt.compiler = cc       ; addOption(opt); }

    bool addCompileUnit( const CProjectFile &file
                       , const CToolset &toolset
                       , const std::map<std::string, std::string> &_macroses
                       , const std::string &cbCompilerToolsetName
                       , std::set< std::string > &additionalIncludes
                       , char pathSep
                       )
       {
        using namespace filename;
        std::map<std::string, std::string> macrosesCopy = _macroses;
        macrosesCopy["ConfigurationName"] = "$$(TARGET_NAME)";

        for(::std::vector< ::std::string >::const_iterator it = file.additionalIncludes.begin(); it!=file.additionalIncludes.end(); ++it)
           {
            additionalIncludes.insert(makeCanonical(marty::macro::substMacroses(macrosesCopy,*it), PATH_SEPARATORS, pathSep));
           }

        if (file.producedFiles.empty()) 
           {
            addUnit( CUnit(makeCanonical(file.filename, PATH_SEPARATORS, pathSep), "CPP" /* cbCompilerToolsetName */ , false, false) );
            return false; // don't processed, simple add as 
           }
        //std::map<std::string, std::string> macroses = _macroses; // make copy of macrosses

        std::string relSrcFilename = makeCanonical(file.filename, PATH_SEPARATORS, pathSep);

        std::string buildCommand;// = "echo \"EEEEEEEEEEEEE\"\necho \"EEEEEEEEEEEEE\"\necho \"EEEEEEEEEEEEE\"";
        ::std::vector<CProducedFile>::const_iterator producedIt = file.producedFiles.begin();
        for(; producedIt!=file.producedFiles.end(); ++producedIt)
           {
            if (!buildCommand.empty()) buildCommand.append(1, '\n');

            std::string relDstFilename = makeCanonical(producedIt->filename);
            
            std::string buildToolText;
            if (!toolset.getTool( producedIt->buildTool + std::string("-tool"), buildToolText))
               {
                //std::cout<<"Not found tool info for '"<<producedIt->buildTool<<"' tool\n";
                continue;
               }
            commandListRemoveLeadingAt(buildToolText);
                        
            std::string ucBuildTool = ::boost::algorithm::to_upper_copy(producedIt->buildTool);// + std::string();
            ucBuildTool.append( 1, '_' );
            //makeCanonical(appendPath(dotsPath, file), PATH_SEPARATORS, pathSep);
            macrosesCopy[ucBuildTool + std::string("INPUT_FILE")     ] = makeCanonical(relSrcFilename, PATH_SEPARATORS, pathSep);
            macrosesCopy[ucBuildTool + std::string("INPUT_FILE_DIR") ] = makeCanonical(filename::pathRemoveTrailingSlash(getPath(relSrcFilename)), PATH_SEPARATORS, pathSep);
            macrosesCopy[ucBuildTool + std::string("OUTPUT_FILE")    ] = makeCanonical(relDstFilename, PATH_SEPARATORS, pathSep);
            macrosesCopy[ucBuildTool + std::string("OUTPUT_FILE_DIR")] = makeCanonical(filename::pathRemoveTrailingSlash(getPath(relDstFilename)), PATH_SEPARATORS, pathSep);
            macrosesCopy[ucBuildTool + std::string("INCLUDES")] = "$$includes";
            // for makefile set TOOL_INCLUDES to $(CPPOPTINCPATH:$(CPPINC))
            //macrosesCopy["ConfigurationName"] = "$$(TARGET_NAME)";
            //makeCanonical(filename::pathRemoveTrailingSlash(getPath(relDstFilename)), PATH_SEPARATORS, pathSep)
            buildCommand.append( marty::macro::substMacroses(macrosesCopy,buildToolText) );
           }

        cb::CUnit unit( relSrcFilename );
        unit.setCompileFlag();
        unit.setWeight(0);
        unit.setCustomBuildCommand( cbCompilerToolsetName, buildCommand);
        //cbProj.
        addUnit(unit);
        return true;
       }



    STRUCT_LAYOUT_DEFAULT(CProjectInfo)
            array  ( 0               , &CProjectInfo::options , _T("Option") );
            complex( _T("Build")     , &CProjectInfo::build   , CBuild()     );
            complex( _T("Compiler")  , &CProjectInfo::compiler, CCompiler()  );
            array  ( 0               , &CProjectInfo::units   , _T("Unit")   );
            complex( _T("Extensions"), &CProjectInfo::extensions, CExtensions()  );
            
            //attribute(_T("major") , &CFileVersion::major , int(0) );
            //attribute(_T("minor") , &CFileVersion::minor , int(0) );
    END_STRUCT_LAYOUT()

}; // struct CProjectInfo


inline
bool loadProject(CProjectInfo &pi)
   {
    return loadProject(pi.projectFilename, pi);
   }

inline
bool saveProject(const CProjectInfo &pi)
   {
    return saveProject(pi.projectFilename, pi);
   }



}; // namespace cb




}; // namespace mbs



#endif /* MBS_CODEBLOCKS_H */

