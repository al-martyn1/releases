#include "scansrc.h"

#include <marty/filename.h>
#include <marty/filesys.h>
#include <marty/filesys.cpp>

#include "../scanner/idlScanner.h"
#include "../scanner/utils.h"


#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif


namespace mbs
{




bool searchSrcInfo(const std::string &filename, CProjectSrcInfo &info)
   {
    if (filename.empty()) 
       {
        std::cout<<"Failed to scan source file: invalid (empty) filename \n";
        return false;
       }

    CIncludeFinderImpl       includeFinder;
    std::vector<CScannerEvent> scannerEvents;
    std::vector<std::string>   processedFiles;

    CScannerErrorContext errContext;
    
    CC2IdlScanner scanner(scannerEvents, processedFiles, filename);
    scanner.setDefaultPreprocessor();
    scanner.getPreprocessor()->setIncludeFinder(&includeFinder);
    scanner.setErrorContext(&errContext);

    scanner.getPreprocessor()->options.parseIncludes      = false;
    scanner.getPreprocessor()->options.parseUserIncludes  = false;
    scanner.getPreprocessor()->options.parseIfdef         = false;
    scanner.getPreprocessor()->options.parseDefines       = false;

    MARTY_FILESYSTEM_NS handle_t hFile = MARTY_FILESYSTEM_NS openFile(filename, MARTY_FILESYSTEM_NS o_rdonly );
    if (hFile==MARTY_FILESYSTEM_NS hInvalidHandle)
       {
        //std::cout<<"SSI: 2, "<<filename<<"\n";
        std::cout<<"Failed to scan "<<filename<<" - can't open file\n";
        return false;
       }

    char buf[4096];
    int readed = MARTY_FILESYSTEM_NS readFile(hFile, buf, sizeof(buf));
    while(readed>0)
       {
        for(int i=0; i<readed; ++i)
           {
            //int err = ;
            unsigned char ch = (unsigned char)buf[i];
            if (ch==0xFF) ch = 0xDF; // bug with russian small YA - switch to capital YA

            if (!scanner.put(ch))
               {
                std::cout<<"Failed to scan "<<filename<<"\n";
                std::cout<<"Error: "<<scanner.getError()<<" - "<<scanner.getErrorStr()<<"\n";
                std::cout<<errContext.formatError(scanner.getError())<<"\n";
                return false;
               }
           }
        readed = MARTY_FILESYSTEM_NS readFile(hFile, buf, sizeof(buf));
       }

    scanner.finalize();

    if (!scannerEvents.empty() && scannerEvents.back().token==LT_END) 
       {
        scannerEvents.erase(scannerEvents.end()-1);
       }

    std::vector<CScannerEvent>::const_iterator seIt = scannerEvents.begin();
    for(; seIt!=scannerEvents.end(); ++seIt)
       {
        if (!LT_IS_COMMENT(seIt->token)) continue;
        //std::string text = seIt->text;
        std::string comment = seIt->token==LT_COMMENT_SINGLE_LINE ? scanner::utils::prepareSinglelineComment(seIt->text) : scanner::utils::prepareMultilineComment(seIt->text);
        int tmp = scanner::utils::isSpecialComment(comment, seIt->token==LT_COMMENT_SINGLE_LINE);
        if (tmp==scanner::utils::comentTypeNone) continue; // return false;

        // simple heuristic
        if (comment.find("\\project", 0)==std::string::npos && comment.find("@project", 0)==std::string::npos) continue;

        ::std::vector< ::std::pair< ::std::string, ::std::vector< ::std::string> > > pairs;
        scanner::utils::splitStringDoxyStyle(comment, pairs);

        CPlatformSrcInfo       platformInfo;
        CConfigurationSrcInfo  configurationInfo;

        ::std::vector< ::std::pair< ::std::string, ::std::vector< ::std::string> > >::const_iterator pit = pairs.begin();
        for(; pit!=pairs.end(); ++pit)
           {
            if (pit->first==::std::string("\\project") || pit->first==::std::string("@project"))
               {
                info.description = scanner::utils::mergeVectorToString(pit->second);
                while(!info.description.empty() && info.description[0]=='\n')
                   {
                    info.description.erase(0, 1);
                   }
               }
            else if (pit->first==::std::string("\\slnconv") || pit->first==::std::string("@slnconv"))
               {
                ::std::vector< ::std::string> tmp;
                scanner::utils::filtrateLinefeeds(pit->second, tmp);
                //CProjectSrcInfo &info
                // slnconvFlags
                info.slnconvFlags.insert(info.slnconvFlags.end(), tmp.begin(), tmp.end() );
               }
            else if (pit->first==::std::string("\\platform") || pit->first==::std::string("@platform"))
               {
                if (!configurationInfo.empty())
                   {
                    platformInfo.configurations.push_back(configurationInfo);
                    configurationInfo.clear();
                   }
                if (!platformInfo.empty())
                   {
                    info.platforms.push_back(platformInfo);
                    platformInfo.clear();
                   }
                ::std::vector< ::std::string> tmp;
                scanner::utils::filtrateLinefeeds(pit->second, tmp);
                platformInfo.name = scanner::utils::mergeVectorToString(tmp, ';');
               }
            else if (pit->first==::std::string("\\configuration") || pit->first==::std::string("@configuration"))
               {
                if (!configurationInfo.empty())
                   {
                    platformInfo.configurations.push_back(configurationInfo);
                    configurationInfo.clear();
                   }
                ::std::vector< ::std::string> tmp;
                scanner::utils::filtrateLinefeeds(pit->second, tmp);
                configurationInfo.name = scanner::utils::mergeVectorToString(tmp, ';');
               }
            else if (pit->first==::std::string("\\libraries") || pit->first==::std::string("@libraries"))
               {
                ::std::vector< ::std::string> tmp;
                scanner::utils::filtrateLinefeeds(pit->second, tmp);
                configurationInfo.libs.insert(configurationInfo.libs.end(), tmp.begin(), tmp.end());
               }
            else if (pit->first==::std::string("\\libpath") || pit->first==::std::string("@libpath"))
               {
                ::std::vector< ::std::string> tmp;
                scanner::utils::filtrateLinefeeds(pit->second, tmp);
                configurationInfo.libPath.insert(configurationInfo.libPath.end(), tmp.begin(), tmp.end());
               }
            else if (pit->first==::std::string("\\incpath") || pit->first==::std::string("@incpath"))
               {
                ::std::vector< ::std::string> tmp;
                scanner::utils::filtrateLinefeeds(pit->second, tmp);
                configurationInfo.incPath.insert(configurationInfo.incPath.end(), tmp.begin(), tmp.end());
               }
            else if (pit->first==::std::string("\\defines") || pit->first==::std::string("@defines"))
               {
                ::std::vector< ::std::string> tmp;
                scanner::utils::filtrateLinefeeds(pit->second, tmp);
                configurationInfo.defines.insert(configurationInfo.defines.end(), tmp.begin(), tmp.end());
               }
            /*
            else if (pit->first==::std::string(""))
               {
               }
            */
           }


        if (!configurationInfo.empty())
           {
            platformInfo.configurations.push_back(configurationInfo);
            configurationInfo.clear();
           }
        if (!platformInfo.empty())
           {
            info.platforms.push_back(platformInfo);
            platformInfo.clear();
           }

        info.normalize();
        info.buildKnownSlnconvFlags();
        //::std::vector< ::std::pair< ::std::string, ::std::string > > pairs;

        //info.description = scanner::utils::mergeDoxyStyleToString(pairs);

        // found project description
        //info.description = "found project description";
        //std::cout<<"SSI: 4\n";
        return true;
       }

    //std::cout<<"SSI: 5\n";
    return false;
   }






}; // namespace mbs



