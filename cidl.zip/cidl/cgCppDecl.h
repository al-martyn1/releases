#ifndef CIDL_CGCPPDECL_H
#define CIDL_CGCPPDECL_H

#ifndef CIDL_STRUCTS_ALLOW_USE_IOSTREAM
    #define CIDL_STRUCTS_ALLOW_USE_IOSTREAM 1
#endif

#include <cli/cli2types.h>


#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#include <cidl/cidl.h>
#include <cidl/cidlErr.h>
#include <cidl/cidlkwd.h>
#include "cidlDefs.h"
#include "doxerImpl.h"
#include "doxy.h"

#include "cidlGen.h"
#include "cgCpp.h"


/*
 1) C/C++ headers - interface declarations                *.h                   c_decl, cpp_decl     cgCppDecl.h

*/

namespace cidl
{

class CCppIfDeclarationGenerator : public CCppGeneratorBase
{

    public:

        bool generate( ::std::ostream             &os
                     , const ::std::string        &outputFilename
                     , const CGenerationParams    &genParams
                     );

};


class CCppIfMethodGenerator : public CIMethodGenerator
{
    public:
        bool generateDeclaration( ::std::ostream                &os
                                , ::std::string                 indent
                                , const CInterfaceEntry         &iEntry
                                , const CGenerationParams       &genParams
                                , const CMethodGenerationParams &methodGenParams
                                );

        virtual
        bool generateDefinition( ::std::ostream                &os
                               , ::std::string                 indent
                               , const CInterfaceEntry         &iEntry
                               , const CGenerationParams       &genParams
                               , const CMethodGenerationParams &methodGenParams
                               );

        bool generateParameter( ::std::ostream                &os
                              , ::std::string                 indent
                              , const CInterfaceEntry         &iEntry
                              , const CParameter              &methodParam
                              , const CGenerationParams       &genParams
                              , const CMethodGenerationParams &methodGenParams
                              , bool *pNeedWrapper = 0  // output - indicator that C++ method need high level wrapper
                              );


};




}; // namespace cidl




#endif /* CIDL_CGCPPDECL_H */

