#include "cgCpp.h"

#include <cidl/ifenum.h>


#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif



namespace cidl
{

namespace util
{




}; // namespace util

//-----------------------------------------------------------------------------
void CCppGeneratorBase::generateHeaderProlog( ::std::ostream &os, const ::std::string &forFile, bool noReadOnlyWarning)
   {
    std::string incGuard = convertNameToMacro(forFile);
    os<<"#include <cli/ponce.h>\n";
    os<<"#ifdef CLI_PRAGMA_ONCE_SUPPORTED\n    #pragma once\n#endif\n\n";

    os<<"#ifndef "<<incGuard<<"\n#define "<<incGuard<<"\n\n";

    if (!noReadOnlyWarning)
       {
        os<<"/* Warning! Automaticaly generated file, do not edit */\n\n";
        os<<"/* Add next line to your IDL code\ncpp_include(\"<"<< ::cidl::genUtil::changeSlash(forFile) <<">\", "<<incGuard<<");\n*/\n\n";
        os<<"/* Add next lines to your C/C++ code\n"<<"#ifndef "<<incGuard<<"\n    #include <"<< ::cidl::genUtil::changeSlash(forFile) <<">\n#endif\n*/\n\n";
       }
   }

//-----------------------------------------------------------------------------
void CCppGeneratorBase::generateHeaderEpilog( ::std::ostream &os, const ::std::string &forFile)
   {
    std::string incGuard = convertNameToMacro(forFile);
    os<<"#endif /* "<<incGuard<<" */\n";
   }

//-----------------------------------------------------------------------------

}; // namespace cidl

