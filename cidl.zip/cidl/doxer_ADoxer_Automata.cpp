/* Warning! Automaticaly generated file, do not edit */

#include "doxer_ADoxer_Automata.h"





namespace cidl {



}; // namespace cidl {

