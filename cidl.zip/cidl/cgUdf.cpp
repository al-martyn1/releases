#include "cgUdf.h"

#include <cidl/ifenum.h>


#define IS_DOC_EMPTY(pDoc)  (!pDoc || (pDoc->description.brief.empty() && pDoc->description.detailed.empty()))

namespace cidl
{




struct CPrintIfUdf
{
    ::std::ostream              &os;
    CUdfGenerator               &gen;
    const ::std::string         &outputFilename;
    const CGenerationParams     &params;

    CPrintIfUdf(const CPrintIfUdf &p)
       : os(p.os)
       , gen(p.gen)
       , outputFilename(p.outputFilename)
       , params(p.params)
       {}

    CPrintIfUdf( ::std::ostream &_os
                    , CUdfGenerator &g
                    , const ::std::string &of
                    , const CGenerationParams &p
                    ) 
       : os(_os)
       , gen(g)
       , outputFilename(of)
       , params(p)
       {}


    bool beforeEnums()      { return true; }
    bool afterEnums()       { return true; }
    bool beforeStructs()    { return true; }
    bool afterStructs()     { return true; }
    bool beforeIfs()        { return true; }
    bool afterIfs()         { return true; }

    bool performEnum( const ::std::string  &enumName
                   , const CNamespaceInfo &rootNs
                   , const CNamespaceInfo &nsi
                   , const CEnumeration &enumInfo
                   ) // const
       {
        return performEnum(enumName, gen.makeIdentName(enumName), gen.makeLabel(enumName), rootNs, nsi, enumInfo);
       }

    bool performEnum( const ::std::string  &enumNameDuin
                    , const ::std::string  &enumIdentName
                    , const ::std::string  &enumLabelName
                    , const CNamespaceInfo &rootNs
                    , const CNamespaceInfo &nsi
                    , const CEnumeration &enumInfo
                    ) // const
       {
        if (!params.idl.isInCurrentSet(enumIdentName, params.srcFilesId)) return true;

        const CPodInfo* cppEnumPod = 0;
        if (!enumInfo.extAttrs.podType.empty())
           {
            cppEnumPod = params.idl.getPodInfo(enumInfo.extAttrs.podType, ::std::string("c"), ::std::string("c++"));
           }

        if (!enumInfo.extAttrs.podType.empty() && !cppEnumPod)
           {
            std::cout<<"Enum '"<<enumIdentName<<"' - enum POD type defined by attribute 'pod', but POD type not found - use declare_pod_type\n";
            return false;
           }

        os<<"% "<<enumNameDuin<<"\n";
        os<<"@enum_section["<<enumLabelName<<"]["<<enumIdentName<<"]\n";

        //const ::doxy::CDoxydoc * pEnumDoc = params.doc.getElementByName(enumNameDuin);

        //os<<gen.getUdfFormattedFullDescription(pEnumDoc);
        os<<gen.getUdfFormattedFullDescription(&params.doc, enumNameDuin);
        os<<"\n";

        if (!gen.printUdfEnumValues( os, enumInfo.vals, enumNameDuin, params.doc ))
           {
            return false;
           }


        /*
        ////////////
        os<<"@begin_enum_values_list[]\n@enum_values_list_header[]\n";
        ::std::vector<CEnumValue>::const_iterator vit = enumInfo.vals.begin();
        for(; vit!=enumInfo.vals.end(); ++vit)
           {
            ::std::string itemDUIN = enumNameDuin;
            itemDUIN.append("/val:");
            itemDUIN.append(vit->name);
            os<<"@begin_enum_values_list_item[]\n";

            os<<"@begin_enum_values_list_item_name[]"<<vit->name<<"@end_enum_values_list_item_name[]\n";

            
            
            os<<"@begin_enum_values_list_item_info[]\n";
            if (vit->aliasFor.empty())
               {
                const ::doxy::CDoxydoc * pEnumValDoc = params.doc.getElementByName(itemDUIN);
                os<<gen.getUdfFormattedFullDescription(pEnumValDoc, true);
               }
            else
               {
                os<<"@enum_value_alias_for["<<vit->aliasFor<<"]";
               }
            os<<"@end_enum_values_list_item_info[]\n";
           
            os<<"@end_enum_values_list_item[]\n";
           }
        os<<"@end_enum_values_list[]\n";
        ////////////
        */

        os<<"%block "<<enumLabelName<<"_c\n";
        if (!gen.printCppEnumDefines( os, enumIdentName, enumInfo, cppEnumPod, /* indent */  ::std::string(), /* addIfdef */  false))
           return false;
        os<<"%endblock\n"
          <<"%convert CC2X KWDFILE TYPESFILE % "<<enumLabelName<<"_c\n"
          //<<"@enum_lang_source_code_section["<<enumLabelName<<"_c][C]\n"
          <<"@begin_enum_lang_source_code_listing["<<enumLabelName<<"_c]["<<enumIdentName<<"][C/C++]\n"
          <<"%insert "<<enumLabelName<<"_c\n"
          <<"@end_enum_lang_source_code_listing\n\n";

        os<<"%block "<<enumLabelName<<"_cpp\n";
        if (!gen.printCppEnumXX( os, enumIdentName, enumInfo, cppEnumPod, /* indent */  ::std::string(), /* addIfdef */  false))
           return false;
        os<<"%endblock\n"
          <<"%convert CC2X KWDFILE TYPESFILE % "<<enumLabelName<<"_cpp\n"
          //<<"@enum_lang_source_code_section["<<enumLabelName<<"_cpp][C++]\n"
          <<"@begin_enum_lang_source_code_listing["<<enumLabelName<<"_cpp]["<<enumIdentName<<"][C++]\n"
          <<"%insert "<<enumLabelName<<"_cpp\n"
          <<"@end_enum_lang_source_code_listing\n\n";


/*          
%block TMPBLOCK_007
++i; // 㢥����� ���稪 横��
%endblock
%convert CC2X KWDFILE TYPESFILE % TMPBLOCK_007
@begin[listing*]
%insert TMPBLOCK_007
@end[listing*]
*/
/*
@newcommand[enum_lang_source_code_section][@para[left]@textbf[#2]]
@begin[listing*]
%insertconvertfile "codstd/ifdefcode.cpp" CC2X KWDFILE TYPESFILE
@end[listing*]
*/
        //%insertconvertfile "codstd/ifdefcode.cpp" CC2X KWDFILE TYPESFILE



        // os<<"// Enum DUIN : "<<enumNameDuin<<"\n"
        //   <<"// Enum ident: "<<enumIdentName<<"\n"
        //   <<"// Enum label: "<<enumLabelName<<"\n\n\n";
        return true;
       }


    bool performStruct( const ::std::string  &structName
                   , const CNamespaceInfo &rootNs
                   , const CNamespaceInfo &nsi
                   , const CStruct &structInfo
                   ) // const
       {
        return performStruct(structName, gen.makeIdentName(structName), gen.makeLabel(structName), rootNs, nsi, structInfo);
       }

    bool performStruct( const ::std::string  &structNameDuin
                    , const ::std::string  &structIdentName
                    , const ::std::string  &structLabelName
                    , const CNamespaceInfo &rootNs
                    , const CNamespaceInfo &nsi
                    , const CStruct &structInfo
                    ) // const
       {
        if (!params.idl.isInCurrentSet(structIdentName, params.srcFilesId)) return true;
        if (structInfo.isDeclaration()) return true; // declaration only
        if (!structInfo.aliasFor.empty()) return true; // skip alias

        //const ::doxy::CDoxydoc * pIfDoc = params.doc.getElementByName(structNameDuin);
        //::std::string ifLabel = gen.makeLabel(ifName);
        //::std::string ifIdent = gen.makeIdentName(ifName);

        os<<"% "<<structNameDuin<<"\n";
        os<<"@struct_section["<<structLabelName<<"]["<<structIdentName<<"]\n";

        //os<<gen.getUdfFormattedFullDescription(pIfDoc);
        os<<gen.getUdfFormattedFullDescription(&params.doc, structNameDuin);
        os<<"\n";


        os<<"@begin_struct_fields_list[]\n@struct_fields_list_header[]\n";
        ::std::vector<CStructItem>::const_iterator fit = structInfo.fields.begin();
        for(; fit!=structInfo.fields.end(); ++fit)
           {
            ::std::string itemDUIN = structNameDuin;
            itemDUIN.append("/member:");
            itemDUIN.append(fit->name);
            os<<"@begin_struct_fields_list_item[]\n";
    
            os<<"@begin_struct_fields_list_item_name[]"<<fit->name<<"@end_struct_fields_list_item_name[]\n";

            os<<"@begin_struct_fields_list_item_info[]\n";
            //if (vit->aliasFor.empty())
            //   {
                //const ::doxy::CDoxydoc * pEnumValDoc = params.doc.getElementByName(itemDUIN);
                //os<<gen.getUdfFormattedFullDescription(pEnumValDoc, true);
                os<<gen.getUdfFormattedFullDescription(&params.doc, itemDUIN, true);
            //   }
            //else
            //   {
            //    os<<"@enum_value_alias_for["<<vit->aliasFor<<"]";
            //   }
            os<<"@end_struct_fields_list_item_info[]\n";
            os<<"@end_struct_fields_list_item[]\n";
           }


        os<<"@end_struct_fields_list[]\n";

        /*
        if (!gen.printUdfEnumValues( os, enumInfo.vals, enumNameDuin, params.doc ))
           {
            return false;
           }
        */

        os<<"%block "<<structLabelName<<"_c\n";
        if (!gen.printCppStructDefinition( os, params.idl, structInfo, ::std::string(), params.srcFiles, structIdentName, 0))
            return false;
        os<<"%endblock\n"
          <<"%convert CC2X KWDFILE TYPESFILE % "<<structLabelName<<"_c\n"
          //<<"@enum_lang_source_code_section["<<enumLabelName<<"_c][C]\n"
          <<"@begin_struct_lang_source_code_listing["<<structLabelName<<"_c]["<<structIdentName<<"][C]\n"
          <<"%insert "<<structLabelName<<"_c\n"
          <<"@end_struct_lang_source_code_listing\n\n";

        os<<"%block "<<structLabelName<<"_cpp\n";
        if (!gen.printCppStructDefinition( os, params.idl, structInfo, ::std::string(), params.srcFiles, structIdentName, 1))
            return false;
        os<<"%endblock\n"
          <<"%convert CC2X KWDFILE TYPESFILE % "<<structLabelName<<"_cpp\n"
          //<<"@enum_lang_source_code_section["<<enumLabelName<<"_cpp][C++]\n"
          <<"@begin_struct_lang_source_code_listing["<<structLabelName<<"_cpp]["<<structIdentName<<"][C++]\n"
          <<"%insert "<<structLabelName<<"_cpp\n"
          <<"@end_struct_lang_source_code_listing\n\n";


        return true;
       }


    bool performIf( const ::std::string  &ifName
                   , const CNamespaceInfo &rootNs
                   , const CNamespaceInfo &nsi
                   , const CInterfaceInfo &ii
                   ) // const
       {
        return performIf(ifName, gen.makeIdentName(ifName), gen.makeLabel(ifName), rootNs, nsi, ii);
       }

    bool performIf( const ::std::string  &ifNameDuin
                   , const ::std::string  &ifIdentName
                   , const ::std::string  &ifLabelName
                   , const CNamespaceInfo &rootNs
                   , const CNamespaceInfo &nsi
                   , const CInterfaceInfo &ii
                   ) // const
       {
        if (!params.idl.isInCurrentSet(ifIdentName, params.srcFilesId)) return true;
        if (ii.isDeclaration()) return true; // declaration only
        if (ii.fImplementation) return true; // now, support for implementation documentation not implemented


        //const ::doxy::CDoxydoc * pIfDoc = params.doc.getElementByName(ifNameDuin);
        //::std::string ifLabel = gen.makeLabel(ifName);
        //::std::string ifIdent = gen.makeIdentName(ifName);

        os<<"% "<<ifNameDuin<<"\n";
        os<<"@interface_section["<<ifLabelName<<"]["<<ifIdentName<<"]\n";

        /*
        if (!pIfDoc || (pIfDoc->description.brief.empty() && pIfDoc->description.detailed.empty()))
           {
            os<<"@no_description_text[]\n";
           }
        else
           {
            //if ()
            os<<pIfDoc->description.brief<<"\n";
            if (!pIfDoc->description.brief.empty()) os<<"@para[]\n";
            os<<pIfDoc->description.detailed<<"\n";
           }
        */
        //os<<gen.getUdfFormattedFullDescription(pIfDoc);
        os<<gen.getUdfFormattedFullDescription(&params.doc, ifNameDuin);
        os<<"\n";


        //::std::string getIdentLastName(const ::std::string &_name)

        if (!ii.extendsList.empty())
           {
            os<<"\n\n@interface_extends_section["<<ifLabelName<<"_if_extends_list][@if_extends_para_title[]]\n";
            if(ii.extendsList.size()>1) os<<"@if_extends_text_multi[]: ";
            else                        os<<"@if_extends_text_single[]: ";

            ::std::vector< ::std::string >::const_iterator eit = ii.extendsList.begin();
            for(; eit!=ii.extendsList.end(); ++eit)
               {
                if (eit!=ii.extendsList.begin()) os<<", ";
                os<<gen.makeUdfRef(::doxy::makeInterfaceDuinFromIdent(*eit), params, mrfFullName|mrfCheckExistence);
                /*
                if (!params.idl.isInCurrentSet(*eit, params.srcFilesId))
                   os<<"@ident["<<*eit<<"]";
                else
                   os<<"@ref["<<gen.makeLabel(::doxy::makeInterfaceDuinFromIdent(*eit))<<"]["<<*eit<<"]";
                */
               }
            os<<"\n\n";
           }

        int propertyCount = 0;
        int methodCount   = 0;
        ::std::vector< CInterfaceEntry >::const_iterator mit = ii.methods.begin();
        for(; mit!=ii.methods.end(); ++mit)
           {
            if (mit->fProperty)
               {
                ++propertyCount;
               }
            else
               {
                //if (!mit->methodInfo.propertyMethod)
                   ++methodCount;
               }
           }

        if (propertyCount)
           {
/*
@newcommand[begin_member_list][@begin[tabular][][1mmt][none]]
@newcommand[end_member_list][@end[tabular]]
@newcommand[begin_member_list_item][@begin[tbl_row]]
@newcommand[end_member_list_item][@end[tbl_row]]
@newcommand[begin_member_list_item_name][@begin[tbl_cell][70mm]]
@newcommand[end_member_list_item_name][@end[tbl_cell]]
@newcommand[begin_member_list_item_info][@begin[tbl_cell][110mm]]
@newcommand[end_member_list_item_info][@end[tbl_cell]]
*/
            os<<"\n\n@interface_properties_summary_section["<<ifLabelName<<"_if_properties][@if_properties_para_title]\n\n";
            //os<<"@begin[entry]\n";
            os<<"@begin_member_list[]\n\n";
            mit = ii.methods.begin();
            for(; mit!=ii.methods.end(); ++mit)
               {
                if (!mit->fProperty) continue;
                ::std::string propNameDuin = ifNameDuin + ::std::string("/property:") + mit->propertyInfo.name;
                os<<"@begin_member_list_item[]\n@begin_member_list_item_name[]";
                os<<gen.makeUdfRef(propNameDuin, params);
                os<<"@end_member_list_item_name[]\n@begin_member_list_item_info[]";
                os<<gen.getUdfBrief(params.doc.getElementByName(propNameDuin));
                os<<"@end_member_list_item_info[]\n";
                os<<"@end_member_list_item[]\n\n";
               }
            //os<<"@end[entry]\n";
            os<<"@end_member_list[]\n";
           }

        if (methodCount)
           {
            os<<"\n\n@interface_methods_summary_section["<<ifLabelName<<"_if_methods][@if_methods_para_title]\n";
            os<<"@begin_member_list[]\n\n";
            mit = ii.methods.begin();
            for(; mit!=ii.methods.end(); ++mit)
               {
                if (mit->fProperty) continue;
                ::std::string methodNameDuin = ifNameDuin + ::std::string("/method:") + mit->methodInfo.name;
                os<<"@begin_member_list_item[]\n@begin_member_list_item_name[]";
                os<<gen.makeUdfRef(methodNameDuin, params);
                os<<"@end_member_list_item_name[]\n@begin_member_list_item_info[]";
                if (!mit->methodInfo.propertyMethod)
                   os<<gen.getUdfBrief(params.doc.getElementByName(methodNameDuin));
                else
                   {
                    ::std::string propNameDuin = ifNameDuin + ::std::string("/property:") + mit->propertyInfo.name;
                    os<<"@prop_"<<mit->methodInfo.description.brief<<"["<<gen.makeUdfRef(propNameDuin, params)<<"]";
                   }
                   //os<<gen.getUdfBrief(params.doc.getElementByName(methodNameDuin));

                os<<"@end_member_list_item_info[]\n";
                os<<"@end_member_list_item[]\n\n";

                //if (!mit->methodInfo.propertyMethod)

               }
            os<<"@end_member_list[]\n";
           }

        mit = ii.methods.begin();
        for(; mit!=ii.methods.end(); ++mit)
           {
            if (mit->fProperty)
               {
                ::std::string propNameDuin = ifNameDuin + ::std::string("/property:") + mit->propertyInfo.name;
                os<<"\n\n@interface_property_section["<<gen.makeLabel(propNameDuin)<<"]"
                                                 <<"["<<gen.makeIdentName(propNameDuin)<<"]\n";
                //os<<gen.getUdfFormattedFullDescription(params.doc.getElementByName(propNameDuin));
                os<<gen.getUdfFormattedFullDescription(&params.doc, propNameDuin);

                /*
                os<<"@begin_member_list_item[]\n@begin_member_list_item_name[]";
                os<<gen.makeUdfRef(propNameDuin, params);
                os<<"@end_member_list_item_name[]\n@begin_member_list_item_info[]";
                os<<gen.getUdfBrief(params.doc.getElementByName(propNameDuin));
                os<<"@end_member_list_item_info[]\n";
                os<<"@end_member_list_item[]\n\n";
                */
               }
            else
               {
                ::std::string methodNameDuin = ifNameDuin + ::std::string("/method:") + mit->methodInfo.name;

                //see_details_ref
                os<<"\n\n@interface_method_section["<<gen.makeLabel(methodNameDuin)<<"]"
                                                 <<"["<<gen.makeIdentName(methodNameDuin)<<"]\n";

                if (!mit->methodInfo.propertyMethod)
                   {
                    //os<<gen.getUdfFormattedFullDescription(params.doc.getElementByName(methodNameDuin));
                    os<<gen.getUdfFormattedFullDescription(&params.doc, methodNameDuin);
                   }
                else
                   {
                    ::std::string propNameDuin = ifNameDuin + ::std::string("/property:") + mit->propertyInfo.name;
                    os<<"@prop_"<<mit->methodInfo.description.brief<<"["<<gen.makeUdfRef(propNameDuin, params)<<"]";
                   }

                /*
                os<<"@begin_member_list_item[]\n@begin_member_list_item_name[]";
                os<<gen.makeUdfRef(methodNameDuin, params);
                os<<"@end_member_list_item_name[]\n@begin_member_list_item_info[]";
                if (!mit->methodInfo.propertyMethod)
                   os<<gen.getUdfBrief(params.doc.getElementByName(methodNameDuin));
                else
                   {
                    ::std::string propNameDuin = ifNameDuin + ::std::string("/property:") + mit->propertyInfo.name;
                    os<<"@prop_"<<mit->methodInfo.description.brief<<"["<<gen.makeUdfRef(propNameDuin, params)<<"]";
                   }
                   //os<<gen.getUdfBrief(params.doc.getElementByName(methodNameDuin));
                */
               }
           }


/*
    if (!i.extendsList.empty())
       {
        os<<" extends ";
        ::std::vector< ::std::string >::const_iterator eit = i.extendsList.begin();
        for(; eit!=i.extendsList.end(); ++eit)
           {
            if (eit!=i.extendsList.begin()) os<<", ";
            os<<*eit;
           }
       }
    os<<"\n"<<ind<< ::std::string(3, ' ')<<"{\n";
    ::std::vector< CInterfaceEntry >::const_iterator mit = i.methods.begin();
    for(; mit!=i.methods.end(); ++mit)
       {
        if (mit->fProperty)
           {
            if (skipProperties) continue;
           }
        else // else method
           {
            if (mit->methodInfo.propertyMethod && skipPropertyMethods) continue;
           }

        print(*mit, ind + ::std::string(4, ' '), os);
       }
    os<<ind<< ::std::string(3, ' ')<<"};\n";
*/

        os<<"\n\n\n\n\n";






        return true;
       }
};

//-----------------------------------------------------------------------------
bool CUdfGenerator::generate( ::std::ostream             &os
                            , const ::std::string        &outputFilename
                            , const CGenerationParams    &genParams
                            )
   {
    CPrintIfUdf udfPrinter(os, *this, outputFilename, genParams);

    //::std::string makeIdentName(const ::std::string &name)
    //::std::string makeLabel(const ::std::string &name)
    enumNsInterfaces(::std::string(), genParams.idl.globalNs, genParams.idl.globalNs, udfPrinter);
    return true;
   }

//-----------------------------------------------------------------------------
bool CUdfMethodGenerator::generateDeclaration( ::std::ostream                &os
                        , ::std::string                 indent
                        , const CInterfaceEntry         &iEntry
                        , const CGenerationParams       &genParams
                        , const CMethodGenerationParams &methodGenParams
                        )
   {
    return true;
   }

//-----------------------------------------------------------------------------
bool CUdfMethodGenerator::generateDefinition( ::std::ostream                &os
                       , ::std::string                 indent
                       , const CInterfaceEntry         &iEntry
                       , const CGenerationParams       &genParams
                       , const CMethodGenerationParams &methodGenParams
                       )
   {
    return true;
   }

//-----------------------------------------------------------------------------


}; // namespace cidl



