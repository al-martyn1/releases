static
char
cidl_default_options[] = 
"# Defines default command line arguments for CIDL compiler\n# if cidl.exe p"
"laced in some_dir/bin, put this file into some_dir/conf\n\n# \n\"-DAendlang"
"=\\endif\"\n# \n\"-DArussian=\\if russian\"\n\"-DAlang_ru=\\russian\"\n\"-D"
"Aendrussian=\\endlang\"\n#\n\"-DAenglish=\\if english\"\n\"-DAlang_en=\\eng"
"lish\"\n\"-DAendenglish=\\endlang\"\n#\n\"-DAdutch=\\if dutch\"\n\"-DAlang_"
"du=\\dutch\"\n\"-DAenddutch=\\endlang\"\n#\n\"-GAc++=cpp\"\n\"-GAc++=cxx\"\n"
"\"-GAudf=ud\"\n\"-GAudf=udh\"\n#\n\"-GAcpp_decl=h\"\n\"-GAcpp_impdecl=hpp\""
"\n\"-GAcpp_impdecl=h++\"\n\"-GAcpp_impl=cpp\"\n\"-GAcpp_impl=cxx\"\n\"-GAcp"
"p_impl=c++\"\n\"-GAc_impl=c\"\n";

/* Input file size: 580 */
static
size_t /* requires stddef.h to be included first */
sizeof_cidl_default_options = 550;

