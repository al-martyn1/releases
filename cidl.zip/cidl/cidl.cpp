/*!
\project CLI IDL compiler
    \libraries cli2
    \libpath
    \incpath
*/


/*
    \libpath #(BOOST.lib)
    \incpath #(BOOST.include)
*/

#define DOXY_CDOCITEM_USE_OSTREAM_OUTPUT
// line 446 

#include <cli/cli2types.h>


// warning C4748: /GS can not protect parameters and local variables from local buffer overrun because optimizations are disabled in function
#if defined(_MSC_VER) && _MSC_VER>=1400
#pragma warning (disable : 4748)
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
    #ifndef CIDL_STRUCTS_ALLOW_USE_IOSTREAM
        #define CIDL_STRUCTS_ALLOW_USE_IOSTREAM 1
    #endif
#endif

#if !defined(_FSTREAM_) && !defined(_STLP_FSTREAM) && !defined(__STD_FSTREAM__) && !defined(_CPP_FSTREAM) && !defined(_GLIBCXX_FSTREAM)
    #include <fstream>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#if !defined(_MEMORY_) && !defined(_STLP_MEMORY) && !defined(__STD_MEMORY__) && !defined(_CPP_MEMORY) && !defined(_GLIBCXX_MEMORY)
    #include <memory>
#endif


#if !defined(_INC_ERRNO) && !defined(_ERRNO_H_) && !defined(_ERRNO_H)
    #include <errno.h>
#endif

//#include <process.h>

#if !defined(_INC_STDLIB) && !defined(_STDLIB_H_) && !defined(_STDLIB_H)
    #include <stdlib.h>
#endif

/*
#if !defined(_INC_TCHAR) && !defined(_TCHAR_H_)
    #include <tchar.h>
#endif
*/

#if !defined(_LOCALE_) && !defined(_STLP_LOCALE) && !defined(__STD_LOCALE__) && !defined(_CPP_LOCALE) && !defined(_GLIBCXX_LOCALE)
    #include <locale>
#endif







//#include <boost/algorithm/string/trim.hpp>
//#include <boost/algorithm/string/predicate.hpp>
//#include <boost/regex.hpp>


#include <marty/filename.h>
#include <marty/filesys.h>
#include <marty/filesys.cpp>


#ifndef MARTY_LIBAPI_H
    #include <marty/libapi.h>
#endif

#include <cli/cli2.h>
#include <cli/cliutilx.h>


#include "../scanner/idlScanner.h"

#include "parserImpl.h"
#include "cidlGen.h"
#include "lfOps.h"
#include "defopts.c"
#include "npwtpl.c"
#include "wtpl.c"






#ifdef USE_MARTY_NAMESPACE
using namespace ::marty;
#endif


int read_config_file(const char* fname);
int parse_option(std::string s);
void print_help();

using MARTY_FILENAME_NS getPath;
using MARTY_FILENAME_NS getPathName;
using MARTY_FILENAME_NS changeExtention;
using MARTY_FILENAME_NS appendPath;
using MARTY_FILENAME_NS getFile;
using MARTY_FILENAME_NS makeCanonical;
//using MARTY_FILENAME_NS tstring;
using MARTY_FILESYSTEM_NS  getCurrentDirectory;
using MARTY_FILENAME_NS isAbsolutePath;
using MARTY_FILENAME_NS makeFullPath;


typedef ::std::basic_string< TCHAR, 
                             ::std::char_traits<TCHAR>, 
                             ::std::allocator<TCHAR> >  tstring;

inline
tstring trim_copy(const tstring &str)
   {
    return ::cli::util::trim_copy(str, ::cli::util::CIsSpace<TCHAR>());
   }

inline
void trim(tstring &str)
   {
    return ::cli::util::trim(str, ::cli::util::CIsSpace<TCHAR>());
   }


//handle_t openFile(const ::std::string &filename, fileopenmode oflag, bool createReadonly = false)

// using MARTY_FILENAME_NS
// using MARTY_FILENAME_NS
// using MARTY_FILENAME_NS
//using MARTY_FILENAME_NS

//-----------------------------------------------------------------------------
int opDetailed = 5;

std::vector<std::string> inputFiles;
//std::vector<std::string> includePathsList;
CIncludeFinderImpl       includeFinder;
//CIncludeFinder<char>           includeFinder;
int                      genFlags = 0;

::cidl::CGeneratorFabriq generatorFabriq;

::std::string   cmdOptions;

::std::map< ::std::string, ::std::string> doxyAliasises;
::std::set< ::std::string >               enabledSections;
bool                                      doxyAutoBrief = false;

::std::vector< ::std::string >            targetList;

void addDoxyAlias(const ::std::string &str);
void addDoxyEnabledSection(const ::std::string &str);
void addOutputTypeAlias(const ::std::string &str);


void addOutputTypeAlias(const ::std::string &str)
   {
    generatorFabriq.addAlias(str);
   }

void addDoxyAlias(const ::std::string &str)
   {
    if (str.empty()) return;

    ::std::string key, val;
    ::doxy::splitToPair( str, key, val, '=', true);
/*
    ::std::string::size_type pos = str.find('=');
    ::std::string key, val;
    if (pos==str.npos)
       {
        key = str;        
       }
    else
       {
        key = ::std::string(str, 0, pos);
        val = ::std::string(str, pos+1);
       }
*/
    doxyAliasises[key] = val;
   }

void addDoxyEnabledSection(const ::std::string &str)
   {
    if (str.empty()) return;
    enabledSections.insert(str);
   }

inline
void printDoc(const ::doxy::CDoxydoc &pDocRoot, const ::std::string &obj)
   {
    const ::doxy::CDoxydoc* pDoc = pDocRoot.getElementByName(obj);
    if (!pDoc)
       std::cout<<"Documentation for "<<obj<<" not found\n";
    else
       {
        std::cout<<"Documentation for "<<obj<<"\n";
        if (!pDoc->description.brief.empty())
           std::cout<<pDoc->description.brief<<"\n";
        if (!pDoc->description.detailed.empty())
           std::cout<<pDoc->description.detailed<<"\n";
       }
   
   }


//-----------------------------------------------------------------------------
int main(int argc, char* argv[])
   {    
    tstring exeName;
    MARTY_LIBAPI_NS getModuleFileName(0, exeName);
    tstring cfg1 = getPath( exeName );
    tstring cfgPath2 = appendPath(cfg1, tstring(_T("../conf")));
    tstring cfg2 = appendPath(cfgPath2, getFile(exeName));
    cfg1 = appendPath(cfg1, getFile(exeName));
    cfg1 = makeCanonical(changeExtention(cfg1, tstring(_T(".default-options"))));
    cfg2 = makeCanonical(changeExtention(cfg2, tstring(_T(".default-options"))));

    cliWriteLogString((tstring(_T("Reading conf file: ")) + cfg1 + tstring(_T("\n"))).c_str());
    // if (opDetailed>4)
    //    std::cout<<"Reading conf file: "<<cfg1<<"\n";
    int cfgRes1 = read_config_file(cfg1.c_str());

    cliWriteLogString((tstring(_T("Reading conf file: ")) + cfg2 + tstring(_T("\n"))).c_str());
    // if (opDetailed>4)
    //    std::cout<<"Reading conf file: "<<cfg2<<"\n";
    int cfgRes2 = read_config_file(cfg2.c_str());

    if (cfgRes1<0 && cfgRes2<0)
       {
        cliWriteLogString((tstring(_T("Writing default configuration files\n"))).c_str());

        MARTY_FILESYSTEM::forceCreateDirectory(cfgPath2);
        tstring cfgTemplatesPath = appendPath(cfgPath2, tstring(_T("templates")) );
        MARTY_FILESYSTEM::forceCreateDirectory( cfgTemplatesPath );
          { std::ofstream cfg(cfg2.c_str());
            if (!!cfg)
               {
                cliWriteLogString((tstring(_T("Writing 'cidl.default-options'\n"))).c_str());
                cfg<< ::std::string(cidl_default_options, sizeof_cidl_default_options);
               }
            else
               {
                cliWriteLogString((tstring(_T("Failed to write 'cidl.default-options'\n"))).c_str());
               }
               //cfg<<normalizeLineFeedsInText( :: std::string(cidl_default_options, sizeof_cidl_default_options) );
          }
          { std::ofstream cfg( appendPath(cfgTemplatesPath, tstring(_T("mparam_wrapper_template.cpp")) ).c_str() );
            if (!!cfg)
               { 
                cliWriteLogString((tstring(_T("Writing 'templates/mparam_wrapper_template.cpp'\n"))).c_str());
                cfg<< ::std::string(mparam_wrapper_template_cpp, sizeof_mparam_wrapper_template_cpp);
               }
            else
               {
                cliWriteLogString((tstring(_T("Failed to write 'templates/mparam_wrapper_template.cpp'\n"))).c_str());
               }
               //cfg<<normalizeLineFeedsInText( :: std::string(mparam_wrapper_template_cpp, sizeof_mparam_wrapper_template_cpp) );
          }
          { std::ofstream cfg( appendPath(cfgTemplatesPath, tstring(_T("wrapper_template.cpp")) ).c_str() );
            if (!!cfg)
               {
                cliWriteLogString((tstring(_T("Writing 'templates/wrapper_template.cpp'\n"))).c_str());
                cfg<< ::std::string(wrapper_template_cpp, sizeof_wrapper_template_cpp);
               }
            else
               {
                cliWriteLogString((tstring(_T("Failed to write 'templates/wrapper_template.cpp'\n"))).c_str());
               }
               //cfg<<normalizeLineFeedsInText( :: std::string(wrapper_template_cpp, sizeof_wrapper_template_cpp) );
          }

        cliWriteLogString((tstring(_T("Reading conf file: ")) + cfg2 + tstring(_T("\n"))).c_str());
        read_config_file(cfg2.c_str());
       }

    cliWriteLogString((tstring(_T("Parsing command-line arguments\n"))).c_str());

    for (int i=1; i<argc; i++)
        {
         int pr = 0;
         switch(*argv[i])
           {
            case '-':
            case '/':  pr = parse_option(argv[i]);
                       break;
            case '@':  pr = read_config_file(argv[i]+1);
                       break;
            
            default:   
                       inputFiles.push_back(argv[i]);
           };
         
         if (pr) return pr;     
        }

    cidl::CCidlErrorContext    errContext;
    std::vector<CScannerEvent> scannerEvents;
    std::vector<std::string>   processedFiles;

    std::string curDir = getCurrentDirectory();

    ::std::set<unsigned> srcFilesIds;

    for(std::vector<std::string>::const_iterator iit = inputFiles.begin();
        iit != inputFiles.end();
        ++iit)
       {
        std::string inputFileNameAsTaken = "-";
        std::string filename = "-";

        srcFilesIds.insert((unsigned)processedFiles.size());

        MARTY_FILESYSTEM_NS handle_t hFile = MARTY_FILESYSTEM_NS hStdin;
        if (*iit!="-") // file name taken, don't use stdin
           {
            inputFileNameAsTaken = *iit;
            filename = makeFullPath(curDir, *iit);
            if (opDetailed>0)
               std::cout<<filename<<"\n";

            hFile = MARTY_FILESYSTEM_NS openFile(filename, MARTY_FILESYSTEM_NS o_rdonly );
            if (hFile==MARTY_FILESYSTEM_NS hInvalidHandle)
               {
                std::cerr<<"Failed to open file "<<filename<<"\n";
                return 1;
               }
           }
        else
           {
            if (opDetailed>0)
               std::cout<<"stdin\n";
           }

        //CScannerErrorContext errContext;
        //scanner.setErrorContext(&errContext);

        
        CC2IdlScanner scanner(scannerEvents, processedFiles, filename);
        scanner.options.noDefaultCppKeywords = true;
        cidl::registerCidlKeywords(scanner);


        scanner.setDefaultPreprocessor();
        scanner.getPreprocessor()->setIncludeFinder(&includeFinder);
        scanner.setErrorContext(&errContext);

        //filename
        //std::string incGuard = convertNameToMacro(forFile);
        std::string thisFileProcessedMacro = ::std::string("_C2IDL_PROCESSING_") + ::cidl::genUtil::convertNameToMacro(inputFileNameAsTaken);
        thisFileProcessedMacro.append("=1");

        scanner.getPreprocessor()->addMacro(thisFileProcessedMacro);
        scanner.getPreprocessor()->addMacro(::std::string("_C2IDL_INVOKED=1")); // c2idl processing this file 
        scanner.getPreprocessor()->addMacro(::std::string("_C2IDL_VER=100"));   // c2idl version - 1.00
        scanner.getPreprocessor()->addMacro(::std::string("_C2IDL_OPTIONS=") + cmdOptions);


        char buf[4096];
        int readed = MARTY_FILESYSTEM_NS readFile(hFile, buf, sizeof(buf));
        while(readed>0)
           {
            for(int i=0; i<readed; ++i)
               {
                //int err = ;
                unsigned char ch = (unsigned char)buf[i];
                if (ch==0xFF) ch = 0xDF; // bug with russian small YA - switch to capital YA
                if (!scanner.put(ch))
                   {
                    //std::cerr<<"Error: "<<scanner.getError()<<" - "<<scanner.getErrorStr()<<"\n";
                    //std::cerr<<errContext.formatError(scanner.getError());
                    std::cout<<"Error: "<<scanner.getError()<<" - "<<scanner.getErrorStr()<<"\n";
                    return 2;
                   }
               }
            readed = MARTY_FILESYSTEM_NS readFile(hFile, buf, sizeof(buf));
           }

        scanner.finalize();

        if (!scannerEvents.empty() && scannerEvents.back().token==LT_END) 
           {
            scannerEvents.erase(scannerEvents.end()-1);
           }

        if (*iit!="-")
           MARTY_FILESYSTEM_NS closeFile(hFile);

        //std::string filename = *iit;

        // if (opDetailed>0)
        //    std::cout<<filename<<":\n";       
       }

    cidl::CCidlParserImpl parserImpl;
    parserImpl.resetAutomata( );
    parserImpl.pFiles = &processedFiles;

    parserImpl.setDoxyAliasises(doxyAliasises);
    parserImpl.setDoxyEnabledSections(enabledSections);
    parserImpl.setDoxyAutoBrief(doxyAutoBrief);

    std::vector<CScannerEvent>::const_iterator seIt = scannerEvents.begin();
    for( ; seIt!=scannerEvents.end(); ++seIt)
       {
        parserImpl.putEvent(*seIt);
        if (parserImpl.isInFinalState()) 
           {
            //std::cerr<<parserImpl.errContext.formatError()<<"\nState: "<<parserImpl.getCurState()<<"\n";
            std::cout<<parserImpl.errContext.formatError()<<"\nState: "<<parserImpl.getCurState()<<"\n";
            return errContext.errCode;
            //break;
           }
       }
    if (seIt==scannerEvents.end())
       {
        parserImpl.eod();
       }

    if (parserImpl.getCurState()!=cidl::CCidlParser::ST_eOk)
       {
        //std::cerr<<parserImpl.errContext.formatError()<<"\nState: "<<parserImpl.getCurState()<<"\n";
        std::cout<<parserImpl.errContext.formatError()<<"\nState: "<<parserImpl.getCurState()<<"\n";
        return errContext.errCode;
       }

    //std::cout<<"\n#############################\n";
    //std::cout<<parserImpl.nsInfo<<"\n#######\n";

    //parserImpl.nsInfo.splitProps();
    //std::cout<<parserImpl.nsInfo<<"\n#######\n";


    cidl::CIdl idl;

    idl.globalNs = parserImpl.nsInfo;

    ::std::vector<cidl::CNameDeclarationInfo> badTypes;    
    if (!idl.correctTypes(badTypes))
       {
        errContext.setBadTypesList(badTypes, &processedFiles);
        std::cout<<errContext.formatError()<<"\n";
        return errContext.errCode; //ERR_CIDL_BAD_TYPES;
       }

    idl.globalNs.splitProps(idl);

    //std::cout<<"\n#############################\n";
    //std::cout<<idl.globalNs<<"\n#######\n\n\n";

    //printDoc(parserImpl.getDoc(), ::std::string("/test1/ISomeInterface"));

    if (targetList.empty())
       {
        std::cout<<"Nothing to do: use -GO option to add targets\n";
        return 0;
       }

    for( ::std::vector< ::std::string >::const_iterator tit = targetList.begin();
         tit!=targetList.end();
         ++tit
       )
       {
        std::cout<<"Target: "<<*tit<<"\n";
        ::std::string type, file;
        if (!generatorFabriq.splitTypeAndFile(*tit, type, file))
           {
            std::cout<<"Invalid output target\n"; //- '"<<*tit<<"'\n";
            continue;
           }

        std::cout<<"Generate "<<type<<", save to '"<<file<<"'\n";

        ::std::auto_ptr< ::cidl::CIGenerator> pGen(generatorFabriq.createGenerator(type));
        if (!pGen.get())
           {
            std::cout<<"Failed to generate "<<type<<" output, unknown output type\n";
            continue;
           }

        ::std::ofstream ofs(file.c_str());
        if (!ofs)
           {
            std::cout<<"Failed to generate "<<type<<" output, can't open output file '"<<file<<"'\n";
            continue;
           }

        ::cidl::CGenerationParams params(idl, parserImpl.getDoc(), srcFilesIds, processedFiles, genFlags);

        if (!pGen->generate( ofs, file, params))
           {
            std::cout<<"Failed to generate "<<type<<" output\n";
           }
        
       }

    /*
    std::cout<<"\n";
    std::cout<<"\n";
    doxy::printDoxyDocTypes(std::cout, parserImpl.getDoc());
    std::cout<<"\n";
    std::cout<<"\n";
    */

/*
    const CDoxydoc* pDoc = parserImpl.doxer.documentation.getElementByName("/test1/ISomeInterface");
    if (!pDoc)
       std::cout<<"Documentation for "
*/

/*
    { 
     std::vector< ::std::string > nameList;
     cidl::splitFqName("::", nameList);
    }

    { 
     std::vector< ::std::string > nameList;
     cidl::splitFqName("::aa", nameList);
    }

    { 
     std::vector< ::std::string > nameList;
     cidl::splitFqName("::aa::", nameList);
    }

    { 
     std::vector< ::std::string > nameList;
     cidl::splitFqName("::aa::bb", nameList);
    }

    { 
     std::vector< ::std::string > nameList;
     cidl::splitFqName("aa::", nameList);
    }
*/

/*
    for(std::vector<CScannerEvent>::const_iterator seIt = scannerEvents.begin(); seIt!=scannerEvents.end(); ++seIt)
       {
        std::cout<<*seIt; //<<"\n";
       }
*/
    return 0;
   }

//-----------------------------------------------------------------------------
int read_config_file(const char* fname) 
{
 std::ifstream cfg(fname);
 if (!cfg)
    {
     cliWriteLogString((tstring(_T("Reading conf file '")) + tstring(fname) + tstring(_T("' failed.\n"))).c_str());
     return -1;
    }
 
 std::string cfg_line;
 std::getline(cfg,cfg_line);
 //cfg_line = ::boost::algorithm::trim_copy(cfg_line); //trim(cfg_line);  
 //cfg_line = trim_copy(cfg_line); 
 trim(cfg_line);  

 //trim(cfg_line);
 while(cfg /* && cfg_line.size() */)
   {
      int pr = 0;
      switch(cfg_line[0])
        {
         case '\"':
         case '-':
         case '/':  pr = parse_option(cfg_line.c_str());
                    break;

//         case '@':  pr = read_config_file(argv[i]+1);
//                    break;
         //default:   //std::string infile = cfg_line;
                    //infile = trim(infile);
                    //if (infile.size())
                    //   input_files.push_back(infile);
        };
//    int pr = parse_option(cfg_line.c_str());
    if (pr) return pr;
    std::getline(cfg,cfg_line);
    //cfg_line = ::boost::algorithm::trim_copy(cfg_line); //trim(cfg_line);  
    //cfg_line = trim_copy(cfg_line);
    trim(cfg_line);
/*
    if (!cfg_line.empty() && cfg_line[0]=='\"' && cfg_line[cfg_line.size()-1]=='\"')
       { cfg_line.erase(cfg_line.size()-1); cfg_line.erase(0, 1); }
*/
    //trim(cfg_line);

   }
 return 0;
}



//-----------------------------------------------------------------------------
int parse_option(std::string str)
{
 #if defined(DEBUG) || defined(_DEBUG)
 cliWriteLogString((tstring(_T("Parsing option: "))  + str + tstring(_T("\n")) ).c_str());
 #endif

 if (!str.empty() && str[0]=='\"' && str[str.size()-1]=='\"')
    { str.erase(str.size()-1); str.erase(0, 1); }

 std::string::iterator s = str.begin();

/*
 if (!str.empty() && str[0]=='\"' && str[str.size()-1]=='\"')
    {
     str.erase(str.size()-1);
     s = str.begin();
     ++s;
    }
*/
 if (str.size()<2)
    std::cout<<"Invalid command line option: '"<<str<<"'\n";

 if (*s!='-' && *s!='/')
    {
     std::cout<<"Invalid command line option: '"<<str<<"'\n";
     return 1;
    }

 if (cmdOptions.empty()) cmdOptions.append(1, ' ');
 cmdOptions.append(str);

 char key = *((++s)++);

 // if (key=='I')
 //    {
 //     add_include_path(s, !checkIncludeOnly);
 //     return 0;
 //    }


 switch(key)
   {

    // case 'w':
    //           showWhere = true;
    //           break;
    //  
    // case 'b': 
    //  
    //           if (std::string(s)=="all")
    //              {
    //               makeAllTargetsVector(buildTargetTypesList);
    //              }
    //           else
    //              {
    //               buildTargetTypesList.push_back(s);
    //              }
    //           break;
    //  
    
    // case 's': 
    //           inputFiles.push_back("-");


    case 'I':
              includeFinder.addPathList(::std::string(s,str.end()));

    case 'd': 
              if (s==str.end()) { break; }
              switch(*s)
                 {
                  case '-':
                  case '0': opDetailed = 0; break;

                  case '1': opDetailed = 1; break;
                  case '2': opDetailed = 2; break;
                  case '3': opDetailed = 3; break;
                  case '4': opDetailed = 4; break;
                  case '5': opDetailed = 5; break;
                  case '6': opDetailed = 6; break;
                  case '7': opDetailed = 7; break;
                  case '8': opDetailed = 8; break;
                  case '9': case '+': opDetailed = 9; break;
                  //case '':
                 };
              break;

    case 'D': 
             {
              char ch = *s;
              ++s;
              /*
              if (s==str.end()) 
                 {
                  break; 
                  std::cout<<"Invalid command line option: '"<<str<<"'\n";
                 }
              */
              switch(ch)
                 {
                  case 'A': addDoxyAlias(::std::string(s,str.end())); break;
                  case 'S': addDoxyEnabledSection(::std::string(s,str.end())); break;
                  case 'b': 
                            if (s==str.end()) 
                               doxyAutoBrief = true;
                            else if (*s=='-')
                               doxyAutoBrief = false;
                            else
                               doxyAutoBrief = true;
                            break;

                  default:  
                            std::cout<<"Unknown command line option: '-"<<str<<"'\n";
                            print_help();
                            return 2;
                 }
             } break;

    case 'G': 
             {
              char ch = *s;
              ++s;
              /*
              if (s==str.end()) 
                 {
                  break; 
                  std::cout<<"Invalid command line option: '"<<str<<"'\n";
                 }
              */
              switch(ch)
                 {
                  case 'A': addOutputTypeAlias(::std::string(s,str.end())); break;
                  case 'O': targetList.push_back(::std::string(s,str.end())); break;
                  case 'C': 
                            {
                             if (s==str.end()) 
                                {
                                 std::cout<<"Invalid command line option: '"<<str<<"'\n";
                                 return 2;
                                }
                             char ch = *s;
                             ++s;
                             switch(ch)
                                {
                                 case 'p': genFlags |= ::cidl::genFlagCppCliPtr_off; break;
                                 case 's': genFlags |= ::cidl::genFlagCppCliStr_off; break;
                                 case 'a': genFlags |= ::cidl::genFlagCppAllStdHeaders_off; break;
                                 case 'r': genFlags |= ::cidl::genFlagCppCliProperty_off; break;
                                 case 'e': genFlags |= ::cidl::genFlagCppCliExcept_off; break;                                 
                                 default:  
                                           std::cout<<"Unknown command line option: '-"<<str<<"'\n";
                                           print_help();
                                           return 2;
                                }
                            
                            }
                            break;
                  
                  // case 'b': 
                  //           if (s==str.end()) 
                  //              doxyAutoBrief = true;
                  //           else if (*s=='-')
                  //              doxyAutoBrief = false;
                  //           else
                  //              doxyAutoBrief = true;
                  //           break;

                  default:  
                            std::cout<<"Unknown command line option: '-"<<str<<"'\n";
                            print_help();
                            return 2;
                 }
             } break;

    case '?': 
    case 'h': 
              print_help();
              return 3;              

    default:  
              std::cout<<"Unknown command line option: '-"<<str<<"'\n";
              print_help();
              return 2;
   };
// macro_adddef("CMDOPTION", "", std::string(--s) + std::string(" "), "cmd_line", 0, 1);
 return 0;
}


//-----------------------------------------------------------------------------
void print_help()
{
 std::cout<<"c2idl - cli2 interface definition language compiler\n";
 std::cout<<"Usage: c2idl [-option [-option]] file1 file2 ...\n";
 std::cout<<"Options:\n";
 std::cout<<"  -IPathList      - semicolon separated path list.\n";
 std::cout<<"  -dN             - detail level 0-9.\n";
 std::cout<<"                    '+' sign threated as 9, '-' sign as 0.\n";
 std::cout<<"  -DX             - documentation parser options, X can be one of:\n";
 std::cout<<"                    Acmd=\\subst       - add doc command alias NAME\n";
 std::cout<<"                    Ssec               - enable section sec\n";
 std::cout<<"                    b[+|-]             - doc autobrief on|off, default - on\n";
 std::cout<<"  -GX               output generation options, X can be one of:\n";
 std::cout<<"                    Atype=alias        - add alias 'alias' for output type 'type'\n";
 std::cout<<"                    Otype,file         - generate output type 'type' to file 'file'\n";
 std::cout<<"                    CX                 - C/C++ generation options, X can be one of:\n";
 std::cout<<"                                         p - don't add #include <cli/cliptr.h>\n";
 std::cout<<"                                         s - don't add #include <cli/clistr.h>\n";
 std::cout<<"                                         e - don't add #include <cli/cliexcept.h>\n";
 std::cout<<"                                         r - don't add #include <cli/property.h>\n";
 std::cout<<"                                         a - don't add all standard includes\n";
 //std::cout<<"                  \n";

}
