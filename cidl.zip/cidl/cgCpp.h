#ifndef CIDL_CGCPP_H
#define CIDL_CGCPP_H

#ifndef CIDL_STRUCTS_ALLOW_USE_IOSTREAM
    #define CIDL_STRUCTS_ALLOW_USE_IOSTREAM 1
#endif


#include <cli/cli2types.h>

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#include <cidl/cidl.h>
#include <cidl/cidlErr.h>
#include <cidl/cidlkwd.h>
#include "cidlDefs.h"
#include "doxerImpl.h"
#include "doxy.h"

#include "cidlGen.h"


/*
 Kinds of generated sources
 1) C/C++ headers - interface declarations                *.h                   c_decl, cpp_decl     cgCppDecl.h
 2) C++ headers - interface implementation declarations   *.hpp                 cpp_impdecl          cgCppImpDecl.h
 3) C headers - interface implementation declarations     ?                     c_impdecl            cgCImpDecl.h
 4) C++ source - interface implementation                 *.cpp, *.cxx, *.c++   cpp_impl             cgCppImpl.h
 5) C source - interface implementation                   *.c                   c_impl               cgCImpl.h

"-GAcpp_decl=f"
"-GAcpp_impdecl=hpp"
"-GAcpp_impdecl=h++"
"-GAcpp_impl=cpp"
"-GAcpp_impl=cxx"
"-GAcpp_impl=c++"
"-GAc_impl=c"

*/

// TODO: make complete list of methods - both from base interfaces and cur interface - Completes
// TODO: make list of all interfaces used in methods                                 - Completes
// TODO: make fn, that creates c++ namespace prolog and store opened ns in vector to creating epilog - Completes
// TODO: sort used interfaces and place them into apropiate ns items - Completes
// TODO: for all used ifs, generate declaration, e.g.                - Completes
// namespace test{
// interface some_interface1;
// interface some_interface2;
//  }; /* namespace test */
// and so on
// TODO:

namespace cidl
{

class CCppGeneratorBase : public CIGenerator
{

    public:

        void generateHeaderProlog( ::std::ostream &os, const ::std::string &forFile, bool noReadOnlyWarning = false);
        void generateHeaderEpilog( ::std::ostream &os, const ::std::string &forFile);
};





}; // namespace cidl




#endif /* CIDL_CGCPP_H */

