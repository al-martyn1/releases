#ifndef CIDL_CIDLGEN_H
#define CIDL_CIDLGEN_H

#ifndef CIDL_STRUCTS_ALLOW_USE_IOSTREAM
    #define CIDL_STRUCTS_ALLOW_USE_IOSTREAM 1
#endif

#include <cli/cli2types.h>

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#include <cidl/cidl.h>
#include <cidl/cidlErr.h>
#include <cidl/cidlkwd.h>
#include "cidlDefs.h"
#include "doxerImpl.h"
#include "doxy.h"
#include "../scanner/scanner.h"

#ifndef CLI_CLIUTILX_H
    #include <cidl/cidlkwd.h>
#endif

#ifndef MARTY_MACROSES_H
    #include <marty/macroses.h>
#endif


namespace cidl
{


 /* static */  const int mrfFullName = 1;
 /* static */  const int mrfCheckExistence = 2;


namespace genUtil
{

template<char C>
struct CIsExactChar
{
    bool operator()(char c) const
       { return c==C; }
};

template <typename TC>
bool isUpper(const TC ch)
   {
    if (ch>=(TC)'A' && ch<=(TC)'Z') return true;
    return false;
   }

template <typename TC>
bool isLower(const TC ch)
   {
    if (ch>=(TC)'a' && ch<=(TC)'z') return true;
    return false;
   }

template <typename TC>
bool isDigit(const TC ch)
   {
    if (ch>=(TC)'0' && ch<=(TC)'9') return true;
    return false;
   }

template <typename TC>
bool isUnderscore(const TC ch)
   {
    if (ch==(TC)'_') return true;
    return false;
   }

typedef ::std::basic_string< TCHAR, 
                             ::std::char_traits<TCHAR>, 
                             ::std::allocator<TCHAR> >  tstring;

inline
::std::string ltrim_copy(const ::std::string &str)
   {
    return ::cli::util::ltrim_copy(str, ::cli::util::CIsSpace<char>());
   }

inline
::std::wstring ltrim_copy(const ::std::wstring &str)
   {
    return ::cli::util::ltrim_copy(str, ::cli::util::CIsSpace<wchar_t>());
   }

inline
void ltrim(::std::string &str)
   {
    return ::cli::util::ltrim(str, ::cli::util::CIsSpace<char>());
   }

inline
void ltrim(::std::wstring &str)
   {
    return ::cli::util::ltrim(str, ::cli::util::CIsSpace<wchar_t>());
   }

inline
::std::string rtrim_copy(const ::std::string &str)
   {
    return ::cli::util::rtrim_copy(str, ::cli::util::CIsSpace<char>());
   }

inline
::std::wstring rtrim_copy(const ::std::wstring &str)
   {
    return ::cli::util::rtrim_copy(str, ::cli::util::CIsSpace<wchar_t>());
   }

inline
void rtrim(::std::string &str)
   {
    return ::cli::util::rtrim(str, ::cli::util::CIsSpace<char>());
   }

inline
void rtrim(::std::wstring &str)
   {
    return ::cli::util::rtrim(str, ::cli::util::CIsSpace<wchar_t>());
   }

inline
::std::string trim_copy(const ::std::string &str)
   {
    return ::cli::util::trim_copy(str, ::cli::util::CIsSpace<char>());
   }

inline
::std::wstring trim_copy(const ::std::wstring &str)
   {
    return ::cli::util::trim_copy(str, ::cli::util::CIsSpace<wchar_t>());
   }

inline
void trim(::std::string &str)
   {
    return ::cli::util::trim(str, ::cli::util::CIsSpace<char>());
   }

inline
void trim(::std::wstring &str)
   {
    return ::cli::util::trim(str, ::cli::util::CIsSpace<wchar_t>());
   }

inline
void rtrim( ::std::vector< ::std::string > &strVec)
   {
    ::std::vector< ::std::string >::iterator it = strVec.begin();
    for(; it!=strVec.end(); ++it)
       {
        rtrim(*it);
       }
   }

inline
void rtrim( ::std::vector< ::std::wstring > &strVec)
   {
    ::std::vector< ::std::wstring >::iterator it = strVec.begin();
    for(; it!=strVec.end(); ++it)
       {
        rtrim(*it);
       }
   }

inline
void trim( ::std::vector< ::std::string > &strVec)
   {
    ::std::vector< ::std::string >::iterator it = strVec.begin();
    for(; it!=strVec.end(); ++it)
       {
        trim(*it);
       }
   }

inline
void trim( ::std::vector< ::std::wstring > &strVec)
   {
    ::std::vector< ::std::wstring >::iterator it = strVec.begin();
    for(; it!=strVec.end(); ++it)
       {
        trim(*it);
       }
   }



struct CToCMacroTransformator
{
    char operator()(char ch)
        { 
         //if (ch>='0' && ch<='9') return ch;
         if (isDigit(ch)) return ch;

         //if (ch>='A' && ch<='Z') return ch;
         if (isUpper(ch)) return ch;
         
         //if (ch>='a' && ch<='z') return (ch - 'a') + 'A';
         if (isLower(ch)) return (ch - 'a') + 'A';

         return '_';
        }
};

inline
::std::string changeSlash(const ::std::string &str)
   {
    ::std::string res = str;
    ::std::string::size_type i=0, size = res.size();
    for(; i!=size; ++i)
       {
        if (res[i]=='\\') res[i] = '/';
       }
    return res;
   }

inline
void printWithIndent( ::std::ostream &os, const ::std::string &ind, const ::std::vector< ::std::string > &strVec)
   {
    //::std::vector< ::std::string > lines;
    //::cli::util::splitString( str, lines, CIsExactChar<'\n'>() );
    //rtrim(strVec);
    ::std::vector< ::std::string >::const_iterator it = strVec.begin();
    for(; it!=strVec.end(); ++it)
       os<<ind<<*it<<"\n";
   }


inline
void printWithIndent( ::std::ostream &os, const ::std::string &ind, const ::std::string &str)
   {
    ::std::vector< ::std::string > lines;
    ::cli::util::splitString( str, lines, CIsExactChar<'\n'>() );
    rtrim(lines);
    printWithIndent(os, ind, lines);
   }

inline
void removeIndent( ::std::vector< ::std::string > &strVec )
   {
    ::std::string::size_type smalestIndent = 1024; //::std::string::npos;
    ::std::vector< ::std::string >::iterator it = strVec.begin();
    for(; it!=strVec.end(); ++it)
       {
        ::std::string::size_type pos = it->find_first_not_of(" \t");
        if (pos==::std::string::npos) continue;
        if (smalestIndent>pos) smalestIndent = pos;
       }
    if (smalestIndent==1024 /* ::std::string::npos */ ) return;

    it = strVec.begin();
    for(; it!=strVec.end(); ++it)
       {
        it->erase( 0, smalestIndent );
       }
   }

inline
void reindentAndPrint( ::std::ostream &os, const ::std::string &ind, const ::std::string &str)
   {
    ::std::vector< ::std::string > lines;
    ::cli::util::splitString( str, lines, CIsExactChar<'\n'>() );
    rtrim(lines);
    removeIndent(lines);
    printWithIndent(os, ind, lines);
   }


inline
::std::string convertNameToMacro(const ::std::string& text)
   {
    std::string res = text;
    std::transform(res.begin(), res.end(), res.begin(), CToCMacroTransformator());
    return res;
   }

inline
::std::string makeLabel(const ::std::string &_name /* DUIN */)
   {
    ::std::vector< ::std::string > parts;
    bool bAbsolute = false;
    ::doxy::splitIdentName( _name, parts, bAbsolute );
    ::std::vector< ::std::string >::iterator pit = parts.begin();
    std::string res;
    for(; pit!=parts.end(); ++pit)
       {
        ::std::string type, name;
        ::doxy::splitToPair( *pit, type, name, ':', false);
        res.append(1, '_');
        res.append(type);
        res.append(1, '_');
        res.append(name);
       }
    return res;
   }

inline
::std::string makeIdentName(const ::std::string &_name /* DUIN */)
   {
    ::std::vector< ::std::string > parts;
    bool bAbsolute = false;
    ::doxy::splitIdentName( _name, parts, bAbsolute );
    ::std::vector< ::std::string >::iterator pit = parts.begin();
    std::string res;
    for(; pit!=parts.end(); ++pit)
       {
        ::std::string type, name;
        ::doxy::splitToPair( *pit, type, name, ':', false);
        res.append(2, ':');
        res.append(name);
       }
    return res;           
   }

inline
::std::string makeIID(const ::std::string &_name /* DUIN */)
   {
    ::std::vector< ::std::string > parts;
    bool bAbsolute = false;
    ::doxy::splitIdentName( _name, parts, bAbsolute );
    ::std::vector< ::std::string >::iterator pit = parts.begin();
    std::string res;
    for(; pit!=parts.end(); ++pit)
       {
        ::std::string type, name;
        ::doxy::splitToPair( *pit, type, name, ':', false);
        res.append(1, '/');
        res.append(name);
       }
    return res;           
   }

inline
::std::string getNameAsOneIdent(const ::std::string &_name /* DUIN or cpp */)
   {
    ::std::string name = _name;
    if (!name.empty() && name[0]!=':')
       {
        name = makeIdentName(name);
       }
    // cpp like style ::ns1::ns2::ident
    std::vector< ::std::string > nameList;
    if (!splitFqName(name, nameList))
       return _name; // TODO: apply toCmacroTransform

    name.clear();
    std::vector< ::std::string >::const_iterator nit = nameList.begin();
    for(; nit!=nameList.end(); ++nit)
       {
        if (nit->empty()) continue;
        if (!name.empty()) name.append(1, '_');
        name.append(*nit);
       }
    return name;
   }

inline
::std::string getIdentLastName(const ::std::string &_name /* DUIN */)
   {
    ::std::vector< ::std::string > parts;
    bool bAbsolute = false;
    ::doxy::splitIdentName( _name, parts, bAbsolute );
    if (parts.empty())
       {
        return _name;
       }

    ::std::string type, name;
    ::doxy::splitToPair( parts.back(), type, name, ':', false);
    return name;
   }

inline
::std::string getBrief(const ::doxy::CDoxydoc* pDoc)
   {
    if (!pDoc || (pDoc->description.brief.empty() && pDoc->description.detailed.empty()))
       return ::std::string();
    else 
       {
        if (!pDoc->description.brief.empty())
           return pDoc->description.brief;
        else
           return pDoc->description.detailed;
       }
   }


struct width
{
    const ::std::string         &str;
    ::std::string::size_type    size;
    bool                        allowResize;
    width(const ::std::string &s, ::std::string::size_type si, bool bAr = true) : str(s), size(si), allowResize(bAr) {}
};

inline
::std::ostream& operator<<( ::std::ostream &os, const width &w)
   {
    ::std::string::size_type nSpaces = 0;
    ::std::string::size_type size = w.size;

    while(size<w.str.size() && w.allowResize)
       {
        size += w.size/2;
       }

    //if (size<=w.str.size() && w.allowResize) size <<= 1;
    if (size>w.str.size()) nSpaces = size - w.str.size();

    os<<w.str<< ::std::string(nSpaces, ' ');
    return os;
   }


struct CDoxyTagsCondTokeniser
{                                    // id, argCount pair
    std::map< ::std::string, ::std::pair<int, int> > tags;

    CDoxyTagsCondTokeniser(const CDoxyTagsCondTokeniser &d) : tags(d.tags) {}
    CDoxyTagsCondTokeniser() : tags()
       {
        tags["\n"]        = ::std::make_pair( DT_LINEFEED , 0);
        //tags["brief"]     = ::std::make_pair( DT_BRIEF , 0);
        //tags["namespace"] = ::std::make_pair( DT_NAMESPACE, -1 );
        //tags["interface"] = ::std::make_pair( DT_INTERFACE, -1 );
        //tags["method"]    = ::std::make_pair( DT_METHOD, -1 );
        //tags["property"]  = ::std::make_pair( DT_PROPERTY, -1 );
        //tags["param"]     = ::std::make_pair( DT_PARAM, -1 );
        //tags["author"]    = ::std::make_pair( DT_AUTHOR, -1 );
        //tags["date"]      = ::std::make_pair( DT_DATE, -1 );
        //tags["file"]      = ::std::make_pair( DT_FILE, -1 );
        tags["if"]        = ::std::make_pair( DT_IF    , -1 );
        tags["ifnot"]     = ::std::make_pair( DT_IFNOT , -1 );
        tags["else"]      = ::std::make_pair( DT_ELSE  , -1 );
        tags["elseif"]    = ::std::make_pair( DT_ELSEIF, -1 );
        tags["endif"]     = ::std::make_pair( DT_ENDIF , -1 );
        //tags[""] = ::std::make_pair( , );
       }

    bool operator()(const ::std::string &srcStr, int &type, int &argCount) const
       {
        std::map< ::std::string, ::std::pair<int, int> >::const_iterator it = tags.find(srcStr);
        if (it==tags.end()) return false;
        type     = it->second.first;
        argCount = it->second.second;
        return true;
       }

};


}; // namespace genUtil



const int genFlagCppCliPtr_off          = 0x0001;
const int genFlagCppCliStr_off          = 0x0002;
const int genFlagCppAllStdHeaders_off   = 0x0004;
const int genFlagCppCliProperty_off     = 0x0008;
const int genFlagCppCliExcept_off       = 0x0010;



struct CGenerationParams
{
    ::cidl::CIdl                    idl;
    ::doxy::CDoxydoc                doc;
    ::std::set<unsigned>            srcFilesId;
    std::vector< ::std::string >    srcFiles;
    int                             genFlags;

    CGenerationParams( const cidl::CIdl                      _idl
                     , const ::doxy::CDoxydoc                _doc
                     , const ::std::set<unsigned>            _srcFilesId
                     , const std::vector< ::std::string >    _srcFiles
                     , int                                   _genFlags
                     ) 
       : idl(_idl)
       , doc(_doc)
       , srcFilesId(_srcFilesId)
       , srcFiles(_srcFiles)
       , genFlags(_genFlags)
       {}

    CGenerationParams() 
       : idl()
       , doc()
       , srcFilesId()
       , srcFiles()
       , genFlags()
       {}

    CGenerationParams(const CGenerationParams &p) 
       : idl(p.idl)
       , doc(p.doc)
       , srcFilesId(p.srcFilesId)
       , srcFiles(p.srcFiles)
       , genFlags(p.genFlags)
       {}

    CGenerationParams& operator=(const CGenerationParams &p) 
       {
        if (&p==this) return *this;
        idl = p.idl;
        doc = p.doc;
        srcFilesId = p.srcFilesId;
        srcFiles = p.srcFiles;
        genFlags = p.genFlags;
        return *this;
       }

};



struct CMethodGenerationParams
{
    ::std::string  ifNameDuin ;
    ::std::string  ifIdentName;
    ::std::string  ifLabelName;
    CInterfaceInfo ifInfo;
};


struct CTypeNameCppInfo
{
    std::string             outputTypeName;
    const CInterfaceInfo   *pInterfaceInfo ; //= 0;
    const CStruct          *pStructInfo ; //= 0;
    const CEnumeration     *pEnumInfo ; //= 0;
    const CPodInfo         *pPodInfo  ; //= 0;

    void getConstRefInfo( int typeType, const ::std::string &ptrPart, ::std::string &name, bool &bRef, bool &bConst )
       {
        name = outputTypeName;
        bConst = false;
        bRef   = false;

        if (typeType==typeOfTypePod)
           {
            //name = nameInfo.pPodInfo->nativeType;
            //if (name.empty()) name = nameInfo.pPodInfo->type;
            if ( /* nameInfo. */ pPodInfo->attrs&passByRef)
               {
                bConst = true;
                bRef   = true;
               }
           }
        else if (typeType==typeOfTypeStruct)
           { // structs 
            bConst = true;
            bRef   = true;
           }
        else if (typeType==typeOfTypeInterface)
           {
            name.append(ptrPart);
           }
       }


    CTypeNameCppInfo() : outputTypeName(), pInterfaceInfo(0), pStructInfo(0), pEnumInfo(0), pPodInfo(0) {}
};



// CIGenerator Output type (C/C++)
                                        /* ���������� ���������� C/C++ (ABI compatible) - ���� ������ POD */
#define CGOTC_BOTH                     -1    
                                        /* ���������� ���������� C   (ABI compatible) - ���� ������ POD  ( ������������ ��� ��������� */
#define CGOTC_C                         0
                                        /* ���������� ���������� C++ (ABI compatible) - ���� ������ POD    ������������ ��� �������� ) */
#define CGOTC_CPP                       1
                                        /* ���������� ���������� C++ - ����������� ������������� � ���������� C++ ����� - �����, �������� (��� CLI_MONOLITHIC) */
#define CGOTC_CXX                       2
                                        /* ������� ��� ���������� - ����� �������, ��� � (�), ��������� ������������� � ABI ����������� */
#define CGOTC_CXX_WRAP                  3
                                        /* ��������������� �������� ��� - �������������� C++ ����� � POD ����� ������� */
#define CGOTC_CXX_WRAP_BEFORE_CALL      4
                                        /* ��������������� �������� ��� - �������������� POD � C++ ���� ����� ������ */
#define CGOTC_CXX_WRAP_AFTER_CALL       5
                                        /* ��������������� �������� ��� - ����� "������" ������ ���������� */
#define CGOTC_CXX_WRAP_CALL_RAW         6
                                        /* ������� ��� ������������� */
#define CGOTC_CXX_IMPL                  7


class CGeneratorFabriq;

class CIGenerator
{

    friend class CGeneratorFabriq;

    ::std::string             outputType;
    const CGeneratorFabriq   *pFabriq;

    public:
        ::std::string           getOutputType()   const { return outputType; }
        const CGeneratorFabriq* getFabriq()       const { return pFabriq; }
    
        virtual ~CIGenerator();
    
        virtual
        bool generate( ::std::ostream             &os
                     , const ::std::string        &outputFilename
                     , const CGenerationParams    &genParams
                     );

        static
        ::std::string formatErrPos( const CFilePosition &at
                                  , const std::vector< ::std::string > &files
                                  //, int code
                                  );

        ::std::string makeLabel(const ::std::string &_name /* DUIN */) const
           { return genUtil::makeLabel(_name /* DUIN */); }

        ::std::string makeIdentName(const ::std::string &_name /* DUIN */) const
           { return genUtil::makeIdentName(_name /* DUIN */); }

        ::std::string makeIID(const ::std::string &_name /* DUIN */)
           { return genUtil::makeIID(_name /* DUIN */); }

        ::std::string getNameAsOneIdent(const ::std::string &_name /* DUIN or cpp */) const
           { return genUtil::getNameAsOneIdent(_name /* DUIN or cpp */); }

        ::std::string getIdentLastName(const ::std::string &_name /* DUIN */) const
           { return genUtil::getIdentLastName(_name /* DUIN */); }

        ::std::string getUdfBrief(const ::doxy::CDoxydoc* pDoc) const
           { 
            if (!pDoc) return ::std::string("@no_description_text[null]");
            ::std::string res = genUtil::getBrief(pDoc);
            if (!res.empty()) return res;
            return ::std::string("@no_description_text[unknown_doc]"); // + + ::std::string("]");
           }

        ::std::string appendDot(const ::std::string &str)
           {
            if (str.empty() || str[str.size()-1]=='.') return str;
            ::std::string res = genUtil::rtrim_copy(str);
            //if (res[res.size()-1]==' ' || res[res.size()-1]=='\n') res[res.size()-1] = '.';
            //else                        
            if (str[str.size()-1]!='.')
               res.append( ::std::string::size_type(1), '.');
            return res;
           }

        ::std::string getUdfFormattedFullDescription(const ::doxy::CDoxydoc* pDoc, bool noParaAfterBrief = false)
           {
            if (!pDoc) return ::std::string("@no_description_text[null]");

            ::std::string res = appendDot(pDoc->description.brief);
            if (!pDoc->description.brief.empty() && !pDoc->description.detailed.empty())
               {
                //if (!noParaAfterBrief)
                   res.append("\n@para[]\n");
               }
            res.append(appendDot(pDoc->description.detailed));
            return res;
           }

        ::std::string getUdfFormattedFullDescription(const ::doxy::CDoxydoc* pDoc, const ::std::string &docFor, bool noParaAfterBrief = false)
           {
            const ::doxy::CDoxydoc* pDocFor = pDoc->getElementByName(docFor);
            if (!pDocFor) return ::std::string("@no_description_text[") + docFor + ::std::string("]");

            return getUdfFormattedFullDescription(pDocFor, noParaAfterBrief);
           }

        ::std::string makeUdfRef( const ::std::string &identDuin
                             , const CGenerationParams &genParams
                             , int flags = 0
                             )
           {
            ::std::string refName = (flags&mrfFullName) ? makeIdentName(identDuin) : getIdentLastName(identDuin);
            if ((flags&mrfCheckExistence) && !genParams.idl.isInCurrentSet(makeIdentName(identDuin), genParams.srcFilesId))
               return //::std::string("@ident[") + 
                      refName 
                      //+ ::std::string("]")
                      ;

            return ::std::string("@ref[") + makeLabel(identDuin) + ::std::string("][") + refName + ::std::string("]");
           }

        void tplLinesToDoxyItems( const ::std::vector< ::std::string >&lines
                                , ::std::vector< ::doxy::CDoxyCommentItem > &doxyItems
                                );


        ::std::string convertNameToMacro(const ::std::string& text) const
           { return genUtil::convertNameToMacro(text); }

        /* find all base interfaces and add current interface name to end of list */
        bool findAllInterfaces( const ::cidl::CInterfaceInfo &ifInfo
                              , const ::std::string &fullIfName
                              , const ::cidl::CIdl &idl
                              , ::std::vector< ::std::string > &ifs
                              );

        bool findAllInterfacesAux( const ::cidl::CInterfaceInfo &ifInfo
                              , const ::cidl::CIdl &idl
                              , ::std::vector< ::std::string > &ifs
                              , ::std::set< ::std::string> &allreadyScannedInterfaces
                              );

        // find all parent methods and owns
        bool findAllMethods( const ::cidl::CInterfaceInfo &ifInfo
                           , const ::std::string &fullIfName
                           , const ::cidl::CIdl &idl
                           , ::std::vector< ::cidl::CInterfaceEntry > &methods
                           );
        bool findAllMethodsAux( const ::cidl::CInterfaceInfo &ifInfo
                           , const ::std::string &fullIfName
                           , const ::cidl::CIdl &idl
                           , ::std::vector< ::cidl::CInterfaceEntry > &methods
                           , ::std::set< ::std::string> &allreadyScannedInterfaces
                           );

        bool findAllParamInterfaces( const ::cidl::CIdl &idl
                                   , const ::std::vector< ::cidl::CInterfaceEntry > &methods
                                   , ::std::map< ::std::string, ::std::set< ::std::string > > &paramIfs
                                   );

        bool printCppNamespaceOpen( ::std::ostream &os, const ::std::string &indent, const ::std::string &ns, ::std::vector< ::std::string > &closeReverseOrder, bool noMoreIndent = false);
        bool printCppNamespaceClose( ::std::ostream &os, const ::std::string &indent, const ::std::vector< ::std::string > &closeReverseOrder, bool noMoreIndent = false);

        bool printCppEnumValueXX( ::std::ostream &os
                                , const ::std::string &valName
                                , const ::std::string &valVal
                                , const ::std::string &enumName
                                , ::std::string &valAllreadyDefined
                                , const ::std::vector< ::std::string > *pAliasises
                                , const CPodInfo* enumPod
                                , ::std::set< ::std::string > &allreadyDefinedEnumVals
                                , const ::std::string &indent
                                ) const;
        
        bool printCppEnumValueDefine( ::std::ostream &os
                                    , const ::std::string &enumName
                                    , const ::std::string &valName
                                    , const ::std::string &valVal
                                    , ::std::string &valAllreadyDefined
                                    , const ::std::vector< ::std::string > *pAliasises
                                    , const CPodInfo* enumPod
                                    , ::std::set< ::std::string > &allreadyDefinedEnumVals
                                    , const ::std::string &indent
                                    , bool addIfdef = true
                                    ) const;

        bool printCppEnumDefines( ::std::ostream &os
                                , const ::std::string  &enumIdentName
                                , const CEnumeration &enumInfo
                                , const CPodInfo* enumPod
                                , const ::std::string &indent
                                , bool addIfdef = true
                                );


        bool printCppEnumXX( ::std::ostream &os
                           , const ::std::string  &enumIdentName
                           , const CEnumeration &enumInfo
                           , const CPodInfo* enumPod
                           , const ::std::string &__indent
                           , bool addIfdef = true
                           );

        bool printCppStructNameDefine( ::std::ostream &os
                                     , const ::std::string  &structIdentName
                                     , const ::std::string &_indent
                                     , bool bCpp
                                     , bool bStruct
                                     , bool addIfdef
                                     , bool bStructIsUnion
                                     );

        bool printCppStructNameDefines( ::std::ostream &os
                                      , const ::std::string  &structIdentName
                                      , const CStruct &structInfo
                                      , const ::std::string &_indent
                                      , bool bCpp
                                      , bool addIfdef// = true
                                      , bool bStructIsUnion
                                      );

        bool printCppInterfaceNameDefine( ::std::ostream &os
                                      , const ::std::string  &ifIdentName
                                      , const ::std::string &_indent
                                      , bool bCpp
                                      , bool addIfdef = true
                                      );

        void printCppPredeclareType( ::std::ostream &os
                                   , const ::std::string &_ident
                                   , const ::std::string &_indent
                                   , bool bCpp
                                   , bool bStruct
                                   , bool bStructIsUnion
                                   );

        bool printCppPredeclareUsedTypes( ::std::ostream &os
                                        , const ::cidl::CIdl &idl
                                        , const ::std::map< ::std::string, ::std::set< ::std::string > > typesByNs
                                        , const ::std::string &_indent
                                        , int flags
                                        , bool bCpp
                                        );

        bool printCppStructField( ::std::ostream &os
                                , const ::cidl::CIdl &idl
                                , const CStructItem &si
                                , const ::std::string &_indent
                                , const std::vector< ::std::string > &srcFiles
                                , const ::std::string &structName
                                , int cppFlag /* 0 - plain C, 1 - C++, -1 - universal */
                                );

        bool printCppStructDefinition( ::std::ostream &os
                                , const ::cidl::CIdl &idl
                                , const CStruct &structInfo
                                , const ::std::string &_indent
                                , const std::vector< ::std::string > &srcFiles
                                , const ::std::string &structName
                                , int cppFlag /* 0 - plain C, 1 - C++, -1 - universal */
                                );

        bool printUdfEnumValues( ::std::ostream &os
                               , const ::std::vector<CEnumValue> &vals
                               , const ::std::string &enumNameDuin
                               , const ::doxy::CDoxydoc &doc
                               );


        bool findReadTemplateFile( const ::std::string &tplName, ::std::string &text
                                 , const std::vector< ::std::string > &srcFiles
                                 , unsigned fileId
                                 , ::std::string &tplFoundName
                                 );
        bool findReadTemplateFileAux( const ::std::string &tplName, ::std::string &text);

        bool findReadTemplateFile( const ::std::string &tplName, ::std::vector< ::std::string > &textLines
                                 , const std::vector< ::std::string > &srcFiles
                                 , unsigned fileId
                                 , ::std::string &tplFoundName
                                 );
        bool findReadTemplateFileAux( const ::std::string &tplName, ::std::vector< ::std::string > &textLines );


        bool processTemplate( const ::std::string &tplName
                            , std::ostream &os
                            , const ::std::string &indent
                            , const std::vector< ::std::string > &srcFiles
                            , unsigned fileId
                            , const ::std::set< ::std::string > &tplEnabledSections
                            , const std::map< ::std::string, ::std::string> &_macroses
                            );

        bool formatCppType(const ::std::string &pureTypeName, const CIdl &idl, int typeType, int cppFlag, CTypeNameCppInfo & nameInfo);
/*
struct CTypeNameCppInfo
{
    std::string         outputTypeName;
    const CEnumeration *pEnumInfo ; //= 0;
    const CPodInfo     *pPodInfo  ; //= 0;
};
*/

        bool getFullTypeInfoForCppMethodDeclaration
                            ( const ::std::string &propertyOrMethodName
                            , bool bProperty
                            , const ::std::string &propertyOrMethodType
                            , const ::std::string &ifName
                            , const CIdl &idl
                            , const CFilePosition &declaredAt
                            , const std::vector< ::std::string > &srcFiles
                            , const ::std::string &paramName // not empty for method param
                            , int cppType
                            , const ::std::string &calledFrom
                            , bool allowNonRefStruct
                            // out
                            , ::std::string &ptrTypePart
                            , ::std::string &pureType
                            , int &typeType
                            , CTypeNameCppInfo &nameInfo
                            );


        bool generateCppMethodDeclaration( ::std::ostream                &os
                                         , ::std::string                 _indent
                                         , const CInterfaceEntry         &ifEntry
                                         , const CGenerationParams       &params
                                         , const CMethodGenerationParams &methodGenParams
                                         , int cppType
                                         );


        bool generateCppParameter( ::std::ostream                &os
                                 , ::std::string                 indent
                                 , const CInterfaceEntry         &ifEntry
                                 , const CParameter              &methodParam
                                 , const CGenerationParams       &genParams
                                 , const CMethodGenerationParams &methodGenParams
                                 , const std::string             &methodName
                                 , int cppType
                                 , bool stdResultMethod
                                 , ::std::string                 &tmpParamVarName
                                 )
           {
            const CIdl &idl = genParams.idl;

            ::std::string plainTypeName, ptrSuffix;
            splitTypeAndPtrSign(methodParam.type, plainTypeName, ptrSuffix);
            int typeType = idl.findTypeType(plainTypeName);

            if (typeType==typeOfTypeUnknown)
               {
                std::cout<<"Error - "<<formatErrPos( methodParam.declaredAt, genParams.srcFiles )<<" - "
                         <<methodGenParams.ifIdentName<<"::"<<methodName<<" : parameter "<<methodParam.name<<" - invalid (unknown) type.\n";
                return false;
               }

            if (methodParam.fArray && !methodParam.isFlatArray())
               {
                std::cout<<"Error - "<<formatErrPos( methodParam.declaredAt, genParams.srcFiles )<<" - "
                         <<methodGenParams.ifIdentName<<"::"<<methodName<<" : parameter "<<methodParam.name<<" - only flat arrays passing supported in current version of CLI IDL.\n";
                return false;
               }

            //int formatTypeFlags = cppType;

            CTypeNameCppInfo nameInfo;
            if (!formatCppType(plainTypeName, idl, typeType, cppType, nameInfo))
               {
                std::cout<<"Error (1) - "<<formatErrPos( methodParam.declaredAt, genParams.srcFiles )<<" - "
                         <<methodGenParams.ifIdentName<<"::"<<methodName<<" : parameter "<<methodParam.name<<" - can't get type format.\n";
                return false;
               }

            const int paramTypeWidth = 16;

            if (typeType==typeOfTypePod && !nameInfo.pPodInfo->nativeType.empty())
               {
                // POD ���, ����� high level ��������������� �++
                if (!ptrSuffix.empty())
                   { 
                    std::cout<<"Error - "<<formatErrPos( methodParam.declaredAt, genParams.srcFiles )<<" - "
                             <<methodGenParams.ifIdentName<<"::"<<methodName<<" : parameter "<<methodParam.name<<" - can't pass pointers to C++ types.\n";
                   }

                if (methodParam.fArray)
                   { 
                    std::cout<<"Error - "<<formatErrPos( methodParam.declaredAt, genParams.srcFiles )<<" - "
                             <<methodGenParams.ifIdentName<<"::"<<methodName<<" : parameter "<<methodParam.name<<" - can't pass arrays of C++ types.\n";
                   }

                // POD ���, ����� high level ��������������� �++, ���������� �� �������� ��� �� ������ (�� �� ���������)
                bool byRef = ((methodParam.direction&passByRef) || (nameInfo.pPodInfo->attrs&passByRef)) ? true : false;
                bool passConst = byRef ? true : false;

                bool outputParam = (methodParam.direction&directionOut) ? true : false;

                if (outputParam)
                   {
                    passConst = false;
                    byRef     = true;
                   }
                
                switch(cppType)
                   {
                    case CGOTC_BOTH:
                    case CGOTC_C:
                    case CGOTC_CPP: 
                            {
                             ::std::string outputTypeName(passConst ? "const " : "");
                             outputTypeName.append(nameInfo.outputTypeName);
                             outputTypeName.append(byRef ? "*" : "");
                             os /* <<indent */ <<genUtil::width(outputTypeName, paramTypeWidth)<<"  "<<methodParam.name;
                             return true;
                            }

                    case CGOTC_CXX_WRAP: // ���������� ������ - �������� C++ ������
                            /*
                            {
                             ::std::string outputTypeName(passConst ? "const " : "");
                             outputTypeName.append(nameInfo.outputTypeName);
                             outputTypeName.append(byRef ? "&" : "");
                             os<<genUtil::width(outputTypeName, paramTypeWidth)<<"  "<<methodParam.name;
                             return true;
                            }
                            */

                    case CGOTC_CXX_WRAP_BEFORE_CALL:
                    case CGOTC_CXX_WRAP_AFTER_CALL:
                    case CGOTC_CXX_WRAP_CALL_RAW:  
                         {
                          if (cppType==CGOTC_CXX_WRAP_AFTER_CALL && !outputParam)
                             return true; // do nothing, param is not output
                          
                          ::std::string tplFileNameBase("mparam_wrapper_template");
                          ::std::string tplFileName        = tplFileNameBase + ::std::string("_") + nameInfo.pPodInfo->type + ::std::string(".cpp");
                          ::std::string tplFileNameGeneric = tplFileNameBase + ::std::string(".cpp");

                          std::map< ::std::string, ::std::string> macroses;
                          macroses["ParamName"]    = methodParam.name;
                          macroses["ParamTypeProcessed"]    = nameInfo.outputTypeName;
                          //macroses["ParamTypeOrg"] = nameInfo.pPodInfo->type;
                          macroses["ParamType"] = nameInfo.pPodInfo->type;
                          macroses["ParamTypeNative"] = nameInfo.pPodInfo->getNativeTypeName();
                          macroses["ParamTypeHelper"] = nameInfo.pPodInfo->getHelperTypeName();
                          macroses["ParamTypeHelper"] = nameInfo.pPodInfo->getHelperOrBasicTypeName();
                          macroses["PassByRef"] = (byRef ? "&" : "");
                          macroses["ParamConst"] = (passConst ? "const" : "");

                          ::std::set< ::std::string > tplEnabledSections;
                          
                          if (cppType==CGOTC_CXX_WRAP)             tplEnabledSections.insert("wrapper_MethodParameter");
                          if (cppType==CGOTC_CXX_WRAP_BEFORE_CALL) tplEnabledSections.insert("conversion_Before");
                          if (cppType==CGOTC_CXX_WRAP_AFTER_CALL)  tplEnabledSections.insert("conversion_After");
                          if (cppType==CGOTC_CXX_WRAP_CALL_RAW)    tplEnabledSections.insert("conversion_Call");

                          if (methodParam.direction&directionIn)   tplEnabledSections.insert("direction_In");
                          if (methodParam.direction&directionOut)  tplEnabledSections.insert("direction_Out");
                          if ((methodParam.direction&directionInOut)==directionInOut) tplEnabledSections.insert("direction_InOut");

                          ::std::ostringstream oss;
                          if (!processTemplate( tplFileName, oss, ::std::string()
                                              , genParams.srcFiles
                                              , methodParam.declaredAt.filenameId
                                              , tplEnabledSections
                                              , macroses
                                              ))
                             {
                              if (!processTemplate( tplFileNameGeneric, oss, ::std::string()
                                                  , genParams.srcFiles
                                                  , methodParam.declaredAt.filenameId
                                                  , tplEnabledSections
                                                  , macroses
                                                  ))
                                 {
                                  std::cout<<"Can't find required template file '"<<tplFileName<<"' or '"<<tplFileNameGeneric<<"' for wrapper method generation\n";
                                  return false;
                                 }
                             }
                          ::std::string parsedTplText = oss.str();
                          for(::std::string::size_type i=0, size=parsedTplText.size(); i<size; ++i)
                             {
                              if (parsedTplText[i]=='\n' || parsedTplText[i]=='\r') parsedTplText[i] = ' ';
                             }
                          os<<genUtil::trim_copy(parsedTplText);
                          return true;
                         }

                    default:
                            std::cout<<"Error (9) - Unsupported cpp format flag "<<cppType<<"\n";
                            return false;
                   }
               }

            if (cppType==CGOTC_CXX_WRAP_CALL_RAW)
               {
                if ( typeType==typeOfTypeStruct && ptrSuffix.empty() && !(methodParam.direction&passOptional) &&
                     //(methodParam.direction&passByRef || methodParam.direction&directionOut) && 
                     !methodParam.fArray
                   )
                   os<<"&";
                os<<methodParam.name;
                return true;
               }
/*
                        if (typeType==typeOfTypeStruct && ptrSuffix.empty() && !(methodParam.direction&passOptional) &&
                            !methodParam.fArray &&
                            //((methodParam.direction&passByRef) || (methodParam.direction&directionOut)) &&
                            (cppType==CGOTC_CXX_WRAP || cppType==CGOTC_CXX_WRAP_CALL_RAW)
                            )
*/

            if (cppType!=CGOTC_BOTH && cppType!=CGOTC_C && cppType!=CGOTC_CPP && cppType!=CGOTC_CXX_WRAP)
               return true;

            // ������������ ��� ���������
            if (!ptrSuffix.empty())
               { // ���������� ���������
                // ���� �������� OUT ��� REF �� �������� ���������
                // ���� �������� IN � REF �� �������� const ���������
                if (methodParam.direction&passByRef || methodParam.direction&directionOut || methodParam.fArray)
                   { // ��������� ���������� �� ������ ��� ������������, ��� ���������� ������, ��������� ������� �����������
                    if (methodParam.direction&passByRef)
                       { // �� ������
                        if (typeType!=typeOfTypeInterface || ptrSuffix.size() > 1)
                           os<<"const ";
                        if (methodParam.fArray)
                           {
                            std::cout<<"Error: interface "<<methodGenParams.ifIdentName
                                          <<" method "<<ifEntry.methodInfo.name
                                          <<" parameter "<<methodParam.name
                                          <<": can't pass array by reference\n";
                            return false;
                           }
                       }
                    else if (!(methodParam.direction&directionOut) && methodParam.fArray)
                       {
                        if (typeType!=typeOfTypeInterface || ptrSuffix.size() > 1)
                           os<<"const ";
                       }
                    os<<nameInfo.outputTypeName<< ::std::string(ptrSuffix.size()+1, '*')<<"    "<<methodParam.name;
                    os<<" /* "; cidl::print(methodParam, ::std::string(), os, true  /* dontPrintComment */); os<<" */";
                    
                    /*
                    if (methodParam.fArray)
                       {
                        os<<"\n"<<indent<<", SIZE_T    "<<methodParam.name<<"Size // size of array "<<methodParam.name<<" //";
                        //if (pNeedWrapper) *pNeedWrapper = true;
                       }
                    */

                    return true;
                   }
                // ��������� ���������� IN
                if (typeType!=typeOfTypeInterface || ptrSuffix.size() > 1)
                   os<<"const ";
                os<<nameInfo.outputTypeName<< ::std::string(ptrSuffix.size(), '*')<<"    "<<methodParam.name;
                os<<" /* "; print(methodParam, ::std::string(), os, true  /* dontPrintComment */); os<<" */";
                return true;
               }

            /*
            if (methodParam.fArray && methodParam.isFlatArray() && !(methodParam.direction&passByRef))
               ptrSuffix.append(1, '*');
            */

            switch(typeType)
               {
                case typeOfTypeInterface:
                        if (ptrSuffix.empty() && (!methodParam.fArray || !methodParam.isFlatArray())) // ����� ������� ������� ������
                           {
                            std::cout<<"Error: interface '"<<methodGenParams.ifIdentName<<"'"
                                          <<" method '"<<ifEntry.methodInfo.name<<"'"
                                          <<" parameter '"<<methodParam.name<<"'"
                                          <<": can't pass interface object itself, can pass it only as pointer\n";
                            return false;
                           }
                        //break;

              case typeOfTypeStruct: // ����� ������, ���� ��������� ��������� ���� �������, �� ��� ����� ���������
              case typeOfTypeUnion:
                        if ( ptrSuffix.empty() && 
                             !(methodParam.direction&passByRef) && 
                             !(methodParam.direction&directionOut) && 
                             (!methodParam.fArray || !methodParam.isFlatArray())
                           )
                           {
                            std::cout<<"Error: struct '"<<methodGenParams.ifIdentName<<"'"
                                          <<" method '"<<ifEntry.methodInfo.name<<"'"
                                          <<" parameter '"<<methodParam.name<<"'"
                                          <<": can't pass struct itself, can pass it only by pointer or reference\n";
                            return false;
                           }

                        if ((typeType==typeOfTypeStruct || typeType==typeOfTypeUnion) && ptrSuffix.empty() && !(methodParam.direction&passOptional) &&
                            !methodParam.fArray &&
                            //((methodParam.direction&passByRef) || (methodParam.direction&directionOut)) &&
                            (cppType==CGOTC_CXX_WRAP || cppType==CGOTC_CXX_WRAP_CALL_RAW)
                            )
                           {                                                   // (nameInfo.pPodInfo->attrs&passByRef)
                            // for CGOTC_CXX_WRAP_CALL_RAW see line 940 - if (cppType==CGOTC_CXX_WRAP_CALL_RAW)

                            bool byRef = true; // ((methodParam.direction&passByRef) || methodParam.direction&directionOut) ? true : false;
                            bool outputParam = (methodParam.direction&directionOut) ? true : false;
                            bool passConst = outputParam ? false : true;            

                            /*
                            if (outputParam)
                               {
                                passConst = false;
                                byRef     = true;
                               }
                            */

                            if (passConst) os<<"const ";
                            os<<nameInfo.outputTypeName<< "    &"<<methodParam.name;
                            os<<" /* "; print(methodParam, ::std::string(), os, true  /* dontPrintComment */); os<<" (struct passed by ref in wrapper) */";


                            /*
                            ::std::string tplFileNameBase("mparam_wrapper_template");
                            ::std::string tplFileName        = tplFileNameBase + ::std::string(".cpp");
                            //::std::string tplFileName        = tplFileNameBase +  ::std::string("_") + nameInfo.pPodInfo->type + ::std::string(".cpp");
                            ::std::string tplFileNameGeneric = tplFileNameBase + ::std::string(".cpp");

                            std::map< ::std::string, ::std::string> macroses;
                            macroses["ParamName"]    = methodParam.name;
                            macroses["ParamTypeProcessed"]    = nameInfo.outputTypeName;
                            //macroses["ParamTypeOrg"] = nameInfo.pPodInfo->type;
                            macroses["ParamType"] = nameInfo.pPodInfo->type;
                            macroses["PassByRef"] = (byRef ? "&" : "");
                            macroses["ParamConst"] = (passConst ? "const" : "");

                            ::std::set< ::std::string > tplEnabledSections;
                            
                            if (cppType==CGOTC_CXX_WRAP)             tplEnabledSections.insert("wrapper_MethodParameter");
                            //if (cppType==CGOTC_CXX_WRAP_BEFORE_CALL) tplEnabledSections.insert("conversion_Before");
                            //if (cppType==CGOTC_CXX_WRAP_AFTER_CALL)  tplEnabledSections.insert("conversion_After");
                            if (cppType==CGOTC_CXX_WRAP_CALL_RAW)    tplEnabledSections.insert("conversion_Call");
  
                            if (methodParam.direction&directionIn)   tplEnabledSections.insert("direction_In");
                            if (methodParam.direction&directionOut)  tplEnabledSections.insert("direction_Out");
                            if ((methodParam.direction&directionInOut)==directionInOut) tplEnabledSections.insert("direction_InOut");
  
                            ::std::ostringstream oss;
                            if (!processTemplate( tplFileName, oss, ::std::string()
                                                , genParams.srcFiles
                                                , methodParam.declaredAt.filenameId
                                                , tplEnabledSections
                                                , macroses
                                                ))
                               {
                                if (!processTemplate( tplFileNameGeneric, oss, ::std::string()
                                                    , genParams.srcFiles
                                                    , methodParam.declaredAt.filenameId
                                                    , tplEnabledSections
                                                    , macroses
                                                    ))
                                   {
                                    std::cout<<"Can't find required template file '"<<tplFileName<<"' or '"<<tplFileNameGeneric<<"' for wrapper method generation\n";
                                    return false;
                                   }
                               }
                            ::std::string parsedTplText = oss.str();
                            for(::std::string::size_type i=0, size=parsedTplText.size(); i<size; ++i)
                               {
                                if (parsedTplText[i]=='\n' || parsedTplText[i]=='\r') parsedTplText[i] = ' ';
                               }
                            os<<genUtil::trim_copy(parsedTplText);
                            */
                            return true;
                           }
                        //CGOTC_CXX_WRAP
                        //CGOTC_CXX_WRAP_CALL_RAW
                      //break;

                case typeOfTypeEnum:
                        //break;

                case typeOfTypePod:

                        if (typeType==typeOfTypePod && plainTypeName == ::std::string("void") && !methodParam.fArray) // plainTypeName, ptrSuffix;
                           { // void ��� ������ ���������� ��� �� ����
                            std::cout<<"Error: interface '"<<methodGenParams.ifIdentName<<"'"
                                          <<" method '"<<ifEntry.methodInfo.name<<"'"
                                          <<" parameter '"<<methodParam.name<<"'"
                                          <<": can't pass void parameter itself, can pass it only as pointer\n";
                            return false;
                           }

                        
                        if ( methodParam.direction&passByRef || 
                             methodParam.direction&directionOut || 
                             methodParam.fArray || 
                             (typeType==typeOfTypePod && nameInfo.pPodInfo->attrs&passByRef)
                           )
                           { // ���������� ���� ��� �������� �� ������, ���� ����� ������������, ���� ������, ���� ��� ������ ������������ �� ������
                            // ��������� ������� �����������
                            if (!(methodParam.direction&directionOut))
                               { // �� �������� (������������) ��������
                                if (typeType!=typeOfTypeInterface || ptrSuffix.size() > 1)
                                   { // �� ��������� �� ��������� (����� ���� �������� �� ��������� �� ���������)
                                    os<<"const ";
                                   }
                               }
                            os<<nameInfo.outputTypeName<< ::std::string(ptrSuffix.size()+1, '*')<<"    "<<methodParam.name;
                            os<<" /* "; print(methodParam, ::std::string(), os, true  /* dontPrintComment */); os<<" */";
                            /*
                            if (methodParam.fArray)
                               {
                                os<<"\n"<<indent<<", SIZE_T    "<<methodParam.name<<"Size // size of array "<<methodParam.name<<" //";
                                //if (pNeedWrapper) *pNeedWrapper = true;
                               }
                            */
                           }
                        else // not a reference, out parameter, or an array
                           {
                            os<<nameInfo.outputTypeName<< ::std::string(ptrSuffix.size(), '*')<<"    "<<methodParam.name;
                            os<<" /* "; print(methodParam, ::std::string(), os, true  /* dontPrintComment */); os<<" */";
                           }

                        break;

                default:
                    std::cout<<"Error (2) - "<<formatErrPos( methodParam.declaredAt, genParams.srcFiles )<<" - "
                             <<methodGenParams.ifIdentName<<"::"<<methodName<<" : parameter "<<methodParam.name<<" - can't get type format.\n";
                    return false;

               }

               

/*
#define CGOTC_BOTH                     -1    // ���������� ���������� C/C++ (ABI compatible) - ���� ������ POD
#define CGOTC_C                         0    // ���������� ���������� C   (ABI compatible) - ���� ������ POD  ( ������������ ��� ���������
#define CGOTC_CPP                       1    // ���������� ���������� C++ (ABI compatible) - ���� ������ POD    ������������ ��� �������� )
#define CGOTC_CXX                       2    // ���������� ���������� C++ - ����������� ������������� � ���������� C++ ����� - �����, �������� (��� CLI_MONOLITHIC)
#define CGOTC_CXX_WRAP                  3    // ������� ��� ���������� - ����� �������, ��� � (�), ��������� ������������� � ABI �����������
#define CGOTC_CXX_WRAP_BEFORE_CALL      4    // ��������������� �������� ��� - �������������� C++ ����� � POD ����� �������
#define CGOTC_CXX_WRAP_AFTER_CALL       5    // ��������������� �������� ��� - �������������� POD � C++ ���� ����� ������
#define CGOTC_CXX_WRAP_CALL_RAW         6    // ��������������� �������� ��� - ����� "������" ������ ����������
#define CGOTC_CXX_IMPL     4    // ������� ��� �������������

struct CTypeNameCppInfo
{
    std::string             outputTypeName;
    const CInterfaceInfo   *pInterfaceInfo ; //= 0;
    const CStruct          *pStructInfo ; //= 0;
    const CEnumeration     *pEnumInfo ; //= 0;
    const CPodInfo         *pPodInfo  ; //= 0;

struct CPodInfo
{
    ::std::string  type;
    ::std::string  nativeType;
    ::std::string  helperType;
    int            attrs;
    CExtAttributes extAttrs;

methodGenParams
    ::std::string  ifNameDuin ;
    ::std::string  ifIdentName;
    ::std::string  ifLabelName;
    CInterfaceInfo ifInfo;
*/        


            return true;
          
           }



};





class CIMethodGenerator
{
    friend class CGeneratorFabriq;

    ::std::string            outputType;
    const CGeneratorFabriq  *pFabriq;

    public:
        ::std::string            getOutputType() const { return outputType; }
        const  CGeneratorFabriq* getFabriq()     const { return pFabriq; }
    
        virtual ~CIMethodGenerator();

        //CIMethodGenerator() {}

        virtual
        bool generateDeclaration( ::std::ostream                &os
                                , ::std::string                 indent
                                , const CInterfaceEntry         &ifEntry
                                , const CGenerationParams       &genParams
                                , const CMethodGenerationParams &methodGenParams
                                ) = 0;

        virtual
        bool generateDefinition( ::std::ostream                &os
                               , ::std::string                 indent
                               , const CInterfaceEntry         &ifEntry
                               , const CGenerationParams       &genParams
                               , const CMethodGenerationParams &methodGenParams
                               ) = 0;


};



class CGeneratorFabriq
{
        ::std::map< ::std::string, ::std::string > typeAliasises;

    public:

        CGeneratorFabriq() : typeAliasises() {}
        CGeneratorFabriq(const CGeneratorFabriq &gf) : typeAliasises(gf.typeAliasises) {}
        CGeneratorFabriq& operator=(const CGeneratorFabriq &gf)
           {
            if (&gf==this) return *this;
            typeAliasises = gf.typeAliasises;
            return *this;
           }

        void addAlias(const ::std::string &type, const ::std::string &alias)
           {
            typeAliasises[alias] = type;
           }

        void addAlias(const ::std::string &pair);
        ::std::string getTypeName(const ::std::string &typeOrAlias) const;

        CIGenerator* createGenerator(const ::std::string &type) const;
        CIMethodGenerator* createMethodGenerator(const ::std::string &type) const;

        bool splitTypeAndFile(const ::std::string &typeAndFile, ::std::string &type, ::std::string &file) const;

};






}; // namespace cidl




#endif /* CIDL_CIDLGEN_H */

