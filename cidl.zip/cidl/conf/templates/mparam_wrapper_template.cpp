\if wrapper_MethodParameter
    $(ParamConst) $(ParamTypeNative)    $(PassByRef)$(ParamName)
\endif
\if conversion_Before
    \if direction_In
        $(ParamTypeHelper) tmp_$(ParamName); $(ParamTypeHelper)_lightCopyTo( tmp_$(ParamName), $(ParamName));
    \else
        $(ParamTypeHelper) tmp_$(ParamName); $(ParamTypeHelper)_init( tmp_$(ParamName) );
    \endif
\endif
\if conversion_After
    \if direction_Out
        $(ParamTypeHelper)_copyFromIfModified( $(ParamName), tmp_$(ParamName));
    \endif
\endif
\if conversion_Call
    $(PassByRef)tmp_$(ParamName)
\endif