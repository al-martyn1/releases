// interface $(InterfaceFullName) wrapper
// generated from $(TemplateFileName) template file
template <
          typename smartPtrType
                              /*
                              = 
                              \if implement_iUnknown
                                  ::cli::CCliPtr< $(InterfaceUniCName) >
                              \else
                                  ::cli::CFoolishPtr< $(InterfaceUniCName) >
                              \endif
                              */
         >
class C$(InterfaceName)Wrapper
{
    public:

        typedef  C$(InterfaceName)Wrapper< smartPtrType >           wrapper_type;
        typedef  typename smartPtrType::interface_type              interface_type;        
        typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
        typedef  typename smartPtrType::pointer_type                pointer_type;          

    protected:

        // pointer to interface variable name
        // allways must be pif - autogeneration depends on this name
        smartPtrType                pif;

    public:

        C$(InterfaceName)Wrapper() : 
           pif(0) {}

        C$(InterfaceName)Wrapper( $(InterfaceName) *_pi, bool noAddRef=false) : 
           pif(_pi, noAddRef)
          { }

        operator bool() const { return bool(pif); }
        bool operator!() const { return pif.operator!(); }
        interface_pointer_type* getPP() { return pif.getPP(); }

        interface_pointer_type getIfPtr()
           {
            interface_pointer_type* ptrPtr = pif.getPP();
            if (!ptrPtr) return 0;
            return *ptrPtr;
           }

        void release()
           {
            pif.release();
           }

\if implement_iUnknown
        C$(InterfaceName)Wrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
           pif(0)
          {
           RCODE res = pif.createObject( componentId, pOuter );
           if (RC_FAIL(res))
              throw ::std::runtime_error("Failed to create requiested component");
          }

        C$(InterfaceName)Wrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
           pif(0)
          {
           if (componentId.empty())
              throw ::std::runtime_error("Empty component name taken");
           RCODE res = pif.createObject( componentId.c_str(), pOuter );
           if (RC_FAIL(res))
              throw ::std::runtime_error("Failed to create requiested component");
          }

       C$(InterfaceName)Wrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
           pif(0)
          {
           ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
           RCODE res = tmpPtr.queryInterface(pif);
           if (RC_FAIL(res))
              throw ::std::runtime_error("Requested interface not supported by object");
          }
\endif
    
        C$(InterfaceName)Wrapper(const C$(InterfaceName)Wrapper &i) : 
            pif(i.pif) { }

        ~C$(InterfaceName)Wrapper()  { }

        C$(InterfaceName)Wrapper& operator=(const C$(InterfaceName)Wrapper &i)
           {
            if (&i!=this) pif = i.pif;
            return *this;
           }

\if implement_iUnknown
        template <typename T>
        RCODE queryInterface( T **t)
          {
           return pif.queryInterface(t);
          }

        template <typename T>
        RCODE queryInterface( T &t)
          {
           t.release();
           return pif.queryInterface(t.getPP());
          }

        RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
           {
            return pif.createObject(componentId, pOuter);
           }
\endif


        // Automaticaly generated methods code goes here

$(InterfaceWrapperMethods)
    

}; // class C$(InterfaceName)Wrapper

typedef C$(InterfaceName)Wrapper< ::cli::CCliPtr< $(InterfaceUniCName)     > >  C$(InterfaceName);
typedef C$(InterfaceName)Wrapper< ::cli::CFoolishPtr< $(InterfaceUniCName) > >  C$(InterfaceName)_nrc; /* No ref counting for interface used */
typedef C$(InterfaceName)Wrapper< ::cli::CFoolishPtr< $(InterfaceUniCName) > >  C$(InterfaceName)_tmp; /* for temporary usage, same as C$(InterfaceName)_nrc */





