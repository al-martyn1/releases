#include <cidl/cidlErr.h>
#include "cidlDefs.h"


#include <stdio.h>
#include <stdarg.h>
//#include <varargs.h>
 


namespace cidl
{


std::string CDECL strprintf(const char *format, ...)
   {
    if (!format) return std::string("invalid format pointer taken");

    char buf[4096];
    va_list args;
    int len;
    va_start( args, format );

    #ifdef _WIN32
        #if _MSC_VER>=1400
        len = _vsnprintf_s(buf, sizeof(buf)-1, sizeof(buf)-1, format, args);
        #else
        len = _vsnprintf(buf, sizeof(buf)-1, format, args);
       #endif
    #else
    len = vsnprintf(buf, sizeof(buf)-1, format, args);
    #endif

    va_end( args );

    if (len<0) return std::string("vsnprintf error occurs");

    return std::string(buf, std::string::size_type(len));
   }

//-----------------------------------------------------------------------------
std::string CCidlErrorContext::formatError(int err)
   {
    if (err<ERR_CIDL_FIRST)
       return CScannerErrorContext::formatError(err);

    //char buf[4096];
    //_snprintf(buf, sizeof(buf)/sizeof(buf[0]), "Error %d - %s:%d:%d - ", err, curFile.c_str(), pos.line+1, pos.pos+1);
    //std::string res = buf;

    ::std::string res = formatErrorPrefix(err);

    switch(err)
       {
        case ERR_CIDL_TOKEN_NOT_ALLOWED_IN_CONTEXT:
            {
             res.append(strprintf("%s %s not allowed here.", getTokenTypeName(errEvt.token).c_str(), tokenTextQuote(errEvt.text).c_str()));
            } break;

        case ERR_CIDL_INTERFACES_REDECLARED:
            {
             res = ::std::string();
             ::std::vector<CNameDeclarationInfo>::const_iterator rit = redeclarations.begin();
             for(; rit!=redeclarations.end(); ++rit)
                {
                 CScannerEvent evtTmp;
                 evtTmp.startPos = rit->redeclaredAt.pos;
                 evtTmp.filenameId = rit->redeclaredAt.filenameId;
                 if (!pFiles) continue;

                 setWhere(evtTmp, *pFiles);
                 const ::std::vector< ::std::string > &files = *pFiles;

                 ::std::string strRedeclType = "<unknown>";
                 switch(rit->redeclType)
                    {
                     case CNameDeclarationInfo::typeInterface: strRedeclType = "interface";
                     case CNameDeclarationInfo::typeEnum:      strRedeclType = "enum";
                     case CNameDeclarationInfo::typeStruct:    strRedeclType = "struct";
                    }

                 ::std::string resAux = formatErrorPrefix(err) 
                                      + strRedeclType 
                                      + ::std::string(" '") 
                                      + rit->name 
                                      + ::std::string("' redeclaration, see previous declaration at ")
                                      + formatFilePos(rit->declaredAt.filenameId>=files.size() ? ::std::string("---") : files[rit->declaredAt.filenameId], rit->declaredAt.pos.line, rit->declaredAt.pos.pos)
                                      + ::std::string("\n") ;
                 res.append(resAux);
                }

            } break;

        case ERR_CIDL_BAD_TYPES:
            {
             res = ::std::string();
             ::std::vector<CNameDeclarationInfo>::const_iterator rit = redeclarations.begin();
             for(; rit!=redeclarations.end(); ++rit)
                {
                 CScannerEvent evtTmp;
                 evtTmp.startPos = rit->redeclaredAt.pos;
                 evtTmp.filenameId = rit->redeclaredAt.filenameId;
                 if (!pFiles) continue;

                 setWhere(evtTmp, *pFiles);
                 //const ::std::vector< ::std::string > &files = *pFiles;
                 
                 ::std::string resAux = formatErrorPrefix(err) 
                                      + ::std::string("invalid (unknown) type '") 
                                      + rit->name 
                                      + ::std::string("', or type is allready defined.")
                                      + ::std::string("\n") ;
                 res.append(resAux);
                }

            } break;

         

/*
        case ERR_NMDL_TYPE_ALLREADY_DECLARED:
            {
             //res.append(strprintf("type %s allready declared. See type declaration at %s.", pPrevTypeDefinition->name.c_str(), formatFilePos(pPrevTypeDefinition->declaredInFile, pPrevTypeDefinition->declaredAtPos).c_str() ));
             res.append(strprintf("type allready declared. See previous type declaration.")
                       //          , pPrevTypeDefinition->name.c_str()
                       //          , formatFilePos(pPrevTypeDefinition->declaredInFile, pPrevTypeDefinition->declaredAtPos).c_str() 
                       //          )
                       );
            } break;

        case ERR_NMDL_TYPE_REFERENCE_NOT_ALLOWED_HERE:
            {
             res.append(strprintf("reference to type \"%s\" not allowed here - type definition required.", text1.c_str()));
            } break;

        case ERR_NMDL_ANON_TYPE_NOT_ALLOWED_HERE:
            {
             res.append(strprintf("anonymous type not allowed here."));                        
            } break;

        case ERR_NMDL_INVALID_TYPE_NAME:
            {
             res.append(strprintf("invalid type name - \"%s\".", text1.c_str()));
            } break;
*/            
        
        /*
        case :
            {
             res.append(strprintf("type %s allready declared.", getTokenTypeName(errEvt.token).c_str(), tokenTextQuote(errEvt.text).c_str()));                        
            } break;

        case :
            {
             res.append(strprintf("type %s allready declared.", getTokenTypeName(errEvt.token).c_str(), tokenTextQuote(errEvt.text).c_str()));                        
            } break;
        */    
        //case :

        default: 
            res.append("Unknown CIDL error");
       
       }
    // format err here

    return res;
   }

//-----------------------------------------------------------------------------



}; // namespace cidl

