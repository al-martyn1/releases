#include <marty/filesys.h>

#ifdef USE_MARTY_NAMESPACE
using namespace ::marty;
#endif


#if !defined(PCPP_ARG_H)
    #include "../cmdline/pcpp_arg.h"
#endif

#if !defined(SCANNER_H)
    #include "../scanner/scanner.h"
#endif

#if !defined(PCPPDFA_H)
    #include "../scanner/pcppdfa.h"
#endif


#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif


#include "../udgen/udgScanner.h"

//#define STR_N_DEF_TEST          \
//"String with slashes \\
// in "



int main(int argc, char* argv[])
   {

    //int res = parce_command_line(argc, argv);

    //STR_N_DEF_TEST;

    CUdgenScanner scanner;
    scanner.setDefaultPreprocessor();

    int hFile = filesystem::hStdin; //openFile()

    char buf[4096];
    int readed = filesystem::readFile(hFile, buf, sizeof(buf));
    while(readed>0)
       {
        for(int i=0; i<readed; ++i)
           {
            if (!scanner.put((unsigned char)buf[i]))
               {
                std::cerr<<"Scanner: error "<<scanner.getError()<<" - "<<scanner.getErrorStr()<<"\n";
                return 3;
               }
           }
        readed = filesystem::readFile(hFile, buf, sizeof(buf));
       }

    scanner.finalize();
    
    return 0;
   }

