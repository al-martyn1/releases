#ifndef SRC_CIDL_ENUMS_H
#define SRC_CIDL_ENUMS_H

/* add this lines to your scr
#ifndef SRC_CIDL_ENUMS_H
    #include "enums.h"
#endif
*/

#ifndef CLI_INET_ISOCK_H
    #include <cli/inet/isock.h>
#endif

#ifndef CLI_CLI2X_H
    #include <cli/cli2x.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_VARIANT_H
    #include <cli/variant.h>
#endif

namespace cidl
{

inline
char convertCharToCpp(char ch, bool bForDefine)
{
    if (ch>='0' && ch<='9') return ch;
    if (ch>='A' && ch<='Z') return ch;
    if (ch>='a' && ch<='z') 
       {
        if (bForDefine)
           return ch - 'a' + 'A';
        return ch;
       }
    return '_';
}

inline
std::string makeCppName( const std::string & str, bool bForDefine)
{
    std::string res; res.reserve(str.size());
    std::string::size_type i = 0, size = str.size();
    for(; i!=size; ++i)
       {
        res.append(1, convertCharToCpp(str[i], bForDefine));
       }
    return res;
}


struct CNameInfo
{
    INT                        id;
    bool                       idGood;
    std::vector< std::string > aliasises;

    CNameInfo() : id(-1), idGood(false), aliasises() {}
    CNameInfo(const CNameInfo &ni) : id(ni.id), idGood(ni.idGood), aliasises(ni.aliasises) {}
    CNameInfo( const std::vector< std::string > &a ) : id(-1), idGood(false), aliasises(a) {}
    CNameInfo( const std::vector< std::string > &a, INT i ) : id(i), idGood(true), aliasises(a) {}
    CNameInfo( INT i ) : id(i), idGood(true), aliasises() {}
};

struct CAliasInfo
{
    INT                        id;
    std::string                orgName;
    CAliasInfo() : id(-1), orgName() {}
    CAliasInfo( const CAliasInfo &ai) : id(ai.id), orgName(ai.orgName) {}
    CAliasInfo( const std::string &on, INT i = -1) : id(i), orgName(on) {}
};


struct CEnumGen
{
    std::map< std::string, CNameInfo >    nameInfoMap;
    std::map< std::string, CAliasInfo >   aliasToNameMap; // built on final preparation
    INT nameCounter;

    CEnumGen() : nameInfoMap(), aliasToNameMap(), nameCounter(0) {}
    CEnumGen(const CEnumGen &eg) : nameInfoMap(eg.nameInfoMap), aliasToNameMap(eg.aliasToNameMap), nameCounter(0) {}


    bool convertToInt(const ::std::string &id, INT *pi ) const
    {
     ::cli::CiVariant v( cliGetVariant( ), true /*noAddRef*/);
     v.setString(MARTY_UTF::fromUtf8( id ));
     RCODE rc = v.convertType(CLI_VARIANTTYPE_VT_INT);
     if (rc) return false;
     if (pi)
        v.getInt(pi);
     return true;
    }

    void addName( const ::std::string &nameAndAliases, bool ignoreIds = true)
    {
        std::vector< std::string > equalNames;
        ::std::string nameAndId, aliases;
        if (::cli::util::splitToPair( nameAndAliases, ::std::string("="), nameAndId, aliases))
           {
            std::vector< std::string > tmp;
            ::cli::util::splitString( aliases, tmp, ::cli::util::CIsCharOneOf<char>(",;") );
            ::cli::util::trim(tmp, ::cli::util::CIsSpace<char>());
            for(std::vector< std::string >::const_iterator it = tmp.begin(); it!=tmp.end(); ++it)
               {
                ::std::string nn2, nn1 = ::cli::disp::impl::normalizeName(*it, &nn2);
                if (!nn1.empty()) equalNames.push_back(nn1);
                if (!nn2.empty()) equalNames.push_back(nn2);
               }
           }
     
        ::std::string name, id;
        bool hasId = ::cli::util::splitToPair( nameAndId, ::std::string("#"), name, id);
        
        ::std::string nn2, nn1 = ::cli::disp::impl::normalizeName(name, &nn2);
        if (!nn1.empty()) equalNames.push_back(nn1);
        if (!nn2.empty()) equalNames.push_back(nn2);

        INT i;
        if (!ignoreIds && hasId && !id.empty() && convertToInt(id, &i))
           {
            nameInfoMap[name] = CNameInfo(equalNames,i);
           }
        else
           {
            nameInfoMap[name] = CNameInfo(equalNames);
           }
    }

protected:

    void buildFinalMap()
    {
        std::map< std::string, CNameInfo >::const_iterator nimIt = nameInfoMap.begin();
        for(;nimIt != nameInfoMap.end(); ++nimIt)
           {
            std::string orgName = nimIt->first;
            aliasToNameMap[orgName] = CAliasInfo( ); // original name don't require to set itself in CAliasInfo
            std::vector< std::string >::const_iterator ait = nimIt->second.aliasises.begin();
            for(;ait != nimIt->second.aliasises.end(); ++ait)
               {
                if (aliasToNameMap.find(*ait)!=aliasToNameMap.end())
                   continue;
                aliasToNameMap[*ait] = CAliasInfo( orgName );
               }
           }
      
        std::map< std::string, CAliasInfo >::iterator amit = aliasToNameMap.begin();
        for(; amit != aliasToNameMap.end(); ++amit)
           {
            if (nameInfoMap[amit->first].idGood)
               {
                amit->second.id = nameInfoMap[amit->first].id;
               }
            else
               {
                amit->second.id = ++nameCounter;
                if (amit->second.orgName.empty())
                   {
                    nameInfoMap[amit->first].id = amit->second.id; // also copy id to original name map
                    nameInfoMap[amit->first].idGood = true;
                   }
               }
           }
     
        amit = aliasToNameMap.begin();
        for(; amit != aliasToNameMap.end(); ++amit)
           {
            if (!amit->second.orgName.empty())
               {
                amit->second.id = nameInfoMap[amit->second.orgName].id;
               }
           }
    }

public:

    CEnumGen getFinalMap() const
    {
     CEnumGen enumGen = *this;
     enumGen.buildFinalMap();
     return enumGen;
    }



};


inline
void makeNamesForMap( const std::wstring &ifName
                    , const std::wstring &implName
                    , const std::string &propOrMethOrIfMap
                    , const std::string &propOrMethOrIfId
                    , std::string &mapName
                    , std::string &defsBase
                    )
{
    std::string mapNameOrg = ::cli::util::toAsciPlain(ifName);
    if (!implName.empty())
       {
        if (!mapNameOrg.empty())
            mapNameOrg.append(1,'_');
        mapNameOrg.append(::cli::util::toAsciPlain(implName));
       }

    std::string constDefNameOrg = mapNameOrg;

    if (!propOrMethOrIfMap.empty())
       {
        if (!mapNameOrg.empty())
            mapNameOrg.append(1,'_');
        mapNameOrg.append(propOrMethOrIfMap);
       }

    if (!propOrMethOrIfId.empty())
       {
        if (!constDefNameOrg.empty())
            constDefNameOrg.append(1,'_');
        constDefNameOrg.append(propOrMethOrIfId);
       }

    mapName  = makeCppName(mapNameOrg, false /* not for define */ );
    defsBase = constDefNameOrg;
}


inline
std::string generateDefines( ::cidl::CEnumGen &eg
                           , const std::wstring &ifName
                           , const std::wstring &implName
                           , const std::string &propOrMethOrIfMap
                           , const std::string &propOrMethOrIfId
                           , bool bCommon
                           )
{
    std::string resStr;

    std::string mapName;
    std::string defsBase;
    makeNamesForMap( ifName, implName, propOrMethOrIfMap, propOrMethOrIfId, mapName, defsBase );

    std::string mapNameCommon;
    std::string defsBaseCommon;
    makeNamesForMap( ifName, L"common", propOrMethOrIfMap, propOrMethOrIfId, mapNameCommon, defsBaseCommon );

    std::map< std::string, CAliasInfo >::const_iterator amit = eg.aliasToNameMap.begin(); // built on final preparation
    for(; amit != eg.aliasToNameMap.end(); ++amit )
       {
        if (amit->second.orgName.empty())
           {
            std::string defName = defsBase + std::string("_");
            defName.append(amit->first);
            // constDefName.append(amit->second.orgName);
            defName = makeCppName( defName, true );
            if (bCommon)
               {
                resStr += ::cli::format::message("#define %1    %2", ::cli::arglist(defName) % amit->second.id );
                resStr += "\n";
               }
            else
               {
                std::string defNameCommon = defsBaseCommon + std::string("_");
                defNameCommon.append(amit->first);
                defNameCommon = makeCppName( defNameCommon, true );
                resStr += ::cli::format::message("#if defined(%1)", ::cli::arglist(defNameCommon) ); resStr += "\n";
                resStr += ::cli::format::message("    #define %1    %2", ::cli::arglist(defName) % defNameCommon ); resStr += "\n#else\n";
                resStr += ::cli::format::message("    #define %1    %2", ::cli::arglist(defName) % amit->second.id ); resStr += "\n#endif\n";
                resStr += "\n";
               }
           }
       }

    resStr += "\n\n";

    return resStr;
}

inline
std::string generateName2IdMap( ::cidl::CEnumGen &eg
                              , const std::wstring &ifName
                              , const std::wstring &implName
                              , const std::string &propOrMethOrIfMap
                              , const std::string &propOrMethOrIfId
                              , const std::string &mapBegin = "BEGIN_CLI_DISP_IMPL_NAME2ID_MAP"
                              , const std::string &mapEnd   = "END_CLI_DISP_IMPL_NAME2ID_MAP"
                              )
{
    std::string resStr = mapBegin + std::string("(");

    std::string mapName;
    std::string defsBase;
    makeNamesForMap( ifName, implName, propOrMethOrIfMap, propOrMethOrIfId, mapName, defsBase );

    resStr += mapName; //MARTY_UTF::toUtf8( implName );
    resStr += ")\n";
    
    std::map< std::string, CAliasInfo >::const_iterator amit = eg.aliasToNameMap.begin(); // built on final preparation
    for(; amit != eg.aliasToNameMap.end(); ++amit )
       {
        std::string constDefName = defsBase + std::string("_");
        if (amit->second.orgName.empty())
           constDefName.append(amit->first);
        else
           constDefName.append(amit->second.orgName);
        constDefName = makeCppName( constDefName, true );
        resStr += ::cli::format::message("{ \"%1\", %2 },", ::cli::arglist(amit->first) % constDefName /* amit->second.id */  );
        resStr += "\n";
       }
    resStr += std::string("{ 0, 0 }\n") + mapEnd + std::string("(");
    resStr += mapName;
    resStr += ")\n\n";

    return resStr;
}






}; // namespace cidl


#endif /* SRC_CIDL_ENUMS_H */

