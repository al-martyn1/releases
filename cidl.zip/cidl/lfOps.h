#ifndef SRC_CIDL_LFOPS_H
#define SRC_CIDL_LFOPS_H

/* add this lines to your scr
#ifndef SRC_CARNO_CARNO_LFOPS_H
    #include "lfOps.h"
#endif
*/

// Line feed operations

//-----------------------------------------------------------------------------
inline
std::string expandLineFeed( const std::string &str)
   {
    std::string res;
    res.reserve(str.size());
    std::string::size_type i = 0, size = str.size();
    for(; i!=size; ++i)
       {
        if (str[i]=='\n') res.append(1,'\r');
        res.append(1,str[i]);
       }
    return res;
   }

//-----------------------------------------------------------------------------
inline
std::wstring expandLineFeed( const std::wstring &str)
   {
    std::wstring res;
    res.reserve(str.size());
    std::wstring::size_type i = 0, size = str.size();
    for(; i!=size; ++i)
       {
        if (str[i]==L'\n') res.append(1,L'\r');
        res.append(1,str[i]);
       }
    return res;
   }

//-----------------------------------------------------------------------------
inline
std::string removeCariageReturn( const std::string &str)
   {
    std::string res;
    res.reserve(str.size());
    std::string::size_type i = 0, size = str.size();
    for(; i!=size; ++i)
       {
        if (str[i]=='\r') continue;
        res.append(1,str[i]);
       }
    return res;
   }

//-----------------------------------------------------------------------------
inline
std::wstring removeCariageReturn( const std::wstring &str)
   {
    std::wstring res;
    res.reserve(str.size());
    std::wstring::size_type i = 0, size = str.size();
    for(; i!=size; ++i)
       {
        if (str[i]=='\r') continue;
        res.append(1,str[i]);
       }
    return res;
   }

//-----------------------------------------------------------------------------
inline
std::string normalizeLineFeedsInText( const std::string &str )
   {
    #if defined(WIN32) || defined(_WIN32)
    return expandLineFeed(removeCariageReturn(str));
    #else
    return removeCariageReturn(str);
    #endif
   }

//-----------------------------------------------------------------------------
inline
std::wstring normalizeLineFeedsInText( const std::wstring &str )
   {
    #if defined(WIN32) || defined(_WIN32)
    return expandLineFeed(removeCariageReturn(str));
    #else
    return removeCariageReturn(str);
    #endif
   }




#endif /* SRC_CIDL_LFOPS_H */

