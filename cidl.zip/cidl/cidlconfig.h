#ifndef CIDL_CIDLCONFIG_H
#define CIDL_CIDLCONFIG_H

/* add this lines to your src
#ifndef CIDL_CIDLCONFIG_H
    #include "cidlconfig.h"
#endif
*/
// $

#define CIDL_MULTIPLE_EXTENDS_ALLOWED 1


#endif /* CIDL_CIDLCONFIG_H */

