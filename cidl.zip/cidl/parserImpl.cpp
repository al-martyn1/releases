#define ENABLE_SCANNER_LOGING

#include "parserImpl.h"


#ifdef CIDL_CCIDLPARSER_LOGGING_USED
    #if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
        #include <iostream>
    #endif
#endif /* NMDL_CNMDLPARSER_LOGGING_USED */

#include "../doxy/doxy.h"

extern int opDetailed; // = 5;

namespace cidl
{

//-----------------------------------------------------------------------------
#ifdef CIDL_CCIDLPARSER_LOGGING_USED
void
CCidlParserImpl::logEvent( int         eventTypeCode //!< 0x0100 - event info flag, 0x0200 - action info flag, 0 - event message, 1 - event message on inadmissible event, 0x0101 - from, 0x0102 - to, 0x0103 - event, 0x0104 - quard, 0x0201 - entry action, 0x0202 - trigger action, 0x0203 - do action, 0x0204 - exit action
        , int         fromState    //!< transition start state, can be used for event filtration
        , int         toState      //!< transition end state, can be used for event filtration
        , const char *eventMsg     //!< from/to state name, event name, guard condition, entry/trigger/do/exit action text or info message
        )
   {
    #ifdef ENABLE_SCANNER_LOGING
    if (opDetailed>=9)
       {
        if (!eventTypeCode)
        std::cout<<"----------------\n";
        std::cout<<eventMsg<<"\n";
       }
    #endif
   }
#endif /* NMDL_CNMDLPARSER_LOGGING_USED */

//-----------------------------------------------------------------------------
void
CCidlParserImpl::customResetAutomata( )
   {
    //nmdlKeywords = nmdl::getNmdlKeywords();
    //pFiles = 0;
    tempCounter = 0;
    clearAttrs();
    //curObjPath.clear();
    //prevObjPath.clear();
    #ifdef CIDL_CCIDLPARSER_TRANSITION_COVERAGE_USED
    initCoverage();
    #endif
    doxer.resetAutomata();
    return;
   }

//-----------------------------------------------------------------------------
/*
void
CCidlParserImpl::popObjPath
          ( 
          )
   {
    #ifdef CIDL_CCIDLPARSER_LOGGING_USED
    //std::cout<<"\nPop  ObjPath (before): "<<curObjPath<<"\n\n";
    #endif // CIDL_CCIDLPARSER_LOGGING_USED
    CCidlParser::popObjPath();
    #ifdef CIDL_CCIDLPARSER_LOGGING_USED
    //std::cout<<"\nPop  ObjPath (after) : "<<curObjPath<<"\n\n";
    #endif // CIDL_CCIDLPARSER_LOGGING_USED
   }

void
CCidlParserImpl::setObjPath
          ( const ::std::string  ot           //!< objType
          , const ::std::string  on           //!< objName
          )
   {
    #ifdef CIDL_CCIDLPARSER_LOGGING_USED
    //std::cout<<"\nPush ObjPath (before): "<<curObjPath<<"\n\n";
    #endif // CIDL_CCIDLPARSER_LOGGING_USED
    CCidlParser::setObjPath(ot, on);
    #ifdef CIDL_CCIDLPARSER_LOGGING_USED
    //std::cout<<"\nPush ObjPath (after) : "<<curObjPath<<"\n\n";
    #endif // CIDL_CCIDLPARSER_LOGGING_USED
   }
*/
//-----------------------------------------------------------------------------
int
CCidlParserImpl::putEvent
        ( const CScannerEvent &evt         
        )
   {
    //lastPos = evt.getStartPos();
    lastEvent = evt;
    /*
    if (!CK_SPACE(evt.token))
       {
        // call subautomata: doxer.flush();
       }
    */
    return CCidlParser::putEvent(evt);
   }

//-----------------------------------------------------------------------------
void
CCidlParserImpl::processComment
              ( const CScannerEvent &evt
              )
   {
    if (CK_COMMENT(evt.token))
       {
        ::std::string doxyText;
        int doxyType = doxy::getCStyleCommentDoxyType( evt.text, evt.token==LT_COMMENT_SINGLE_LINE, doxyText);
        if (doxyType==doxy::comentTypeNone)
           {
            //doxer.lf();
           }
        else
           {
            doxer.doxy(::doxy::CDoxyEvent(doxyType, doxyText));
           }
       }
    else
       {
        if (evt.token==LT_LINEFEED)
           {
            doxer.lf();
           }
       }
    //LT_COMMENT

/*
#define CK_COMMENT(code)      LT_IS_COMMENT(code)
#define CK_SKIPSPACE(code)    (LT_IS_WHITESPACE(code) || code==LT_END)
#define CK_SPACE(code)        (CK_SKIPSPACE(code) || CK_COMMENT(code))
*/   
   
   }



}; // namespace cidl

