#ifndef C2IDL_CIDLDEFS_H
#define C2IDL_CIDLDEFS_H

#include <cli/cli2.h>
#include <cidl/cidl.h>


#include "../scanner/scanner.h"


namespace cidl
{


struct CCidlErrorContext: public CScannerErrorContext
{
    int                                    errCode;
    CScannerEvent                          errEvt;
    ::std::vector<CNameDeclarationInfo>    redeclarations;
    const ::std::vector< ::std::string >   *pFiles;
    //ERR_CIDL_INTERFACES_REDECLARED

    CCidlErrorContext() : CScannerErrorContext(), errCode(0), errEvt(), redeclarations(), pFiles()
       {}

    std::string formatError(int err);
    std::string formatError() { return formatError(errCode); };
    
    void setErrorEvent(const CScannerEvent &evt, const std::vector<std::string> &files)
       {
        errEvt = evt;
        CScannerErrorContext::setWhere(evt, files);
       }
    void setErrorEvent(int ec, const CScannerEvent &evt, const std::vector<std::string> &files)
       {
        errCode = ec;
        errEvt = evt;
        CScannerErrorContext::setWhere(evt, files);
       }

    void setInterfaceRedeclarationsList(const ::std::vector<CNameDeclarationInfo> &redecl, const ::std::vector< ::std::string > *pf)
       {
        errCode = ERR_CIDL_INTERFACES_REDECLARED;
        pFiles = pf;
        redeclarations = redecl;
       }
    // same as above but shoreter name
    void setRedeclList(const ::std::vector<CNameDeclarationInfo> &redecl, const ::std::vector< ::std::string > *pf)
       {
        errCode = ERR_CIDL_INTERFACES_REDECLARED;
        pFiles = pf;
        redeclarations = redecl;
       }

    void setRedeclErr(const CNameDeclarationInfo &redecl, const ::std::vector< ::std::string > *pf)
       {
        ::std::vector<CNameDeclarationInfo> redeclList; 
        redeclList.push_back(redecl);
        setRedeclList(redeclList, pf);
       }


    void setBadTypesList(const ::std::vector<CNameDeclarationInfo> &redecl, const ::std::vector< ::std::string > *pf)
       {
        errCode = ERR_CIDL_BAD_TYPES;
        pFiles = pf;
        redeclarations = redecl;
       }

    
};





}; // namespace cidl


#endif /* C2IDL_CIDLDEFS_H */

