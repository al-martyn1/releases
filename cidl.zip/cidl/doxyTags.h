#ifndef CIDL_DOXYTAGS_H
#define CIDL_DOXYTAGS_H

/*

So far we have assumed that the documentation blocks are always located in front of 
the declaration or definition of a file, class or namespace or in front or after 
one of its members. Although this is often comfortable, there may sometimes be 
reasons to put the documentation somewhere else. For documenting a file this is 
even required since there is no such thing as "in front of a file".

Commands used if documentation placed anywhere 

\class is used to indicate that the comment block contains documentation for the class 
\struct to document a C-struct. 
\union to document a union. 
\enum to document an enumeration type. 
\fn to document a function. 
\var to document a variable or typedef or enum value. 
\def to document a #define. 
\typedef to document a type definition. 
\file to document a file. 
\namespace to document a namespace. 
\package to document a Java package. 
\interface to document an IDL interface. 


\brief - brief description

*/

#endif /* CIDL_DOXYTAGS_H */

