#ifndef CIDL_STRUCTS_ALLOW_USE_IOSTREAM
    #define CIDL_STRUCTS_ALLOW_USE_IOSTREAM 1
#endif

#include "cgCppDecl.h"
#include <cidl/ifenum.h>

#ifndef MARTY_MACROSES_H
    #include <marty/macroses.h>
#endif

#ifndef CIDL_CIDLCONFIG_H
    #include "cidlconfig.h"
#endif


namespace cidl
{


struct CPrintIfCppDecl
{
    ::std::ostream              &os;
    CCppIfDeclarationGenerator  &gen;
    const ::std::string         &outputFilename;
    const CGenerationParams     &params;
    ::std::map< ::std::string, ::std::set< ::std::string > > allreadyUsedTypes;

    CPrintIfCppDecl(const CPrintIfCppDecl &p)
       : os(p.os)
       , gen(p.gen)
       , outputFilename(p.outputFilename)
       , params(p.params)
       , allreadyUsedTypes(p.allreadyUsedTypes)
       {}

    CPrintIfCppDecl( ::std::ostream &_os
                    , CCppIfDeclarationGenerator &g
                    , const ::std::string &of
                    , const CGenerationParams &p
                    ) 
       : os(_os)
       , gen(g)
       , outputFilename(of)
       , params(p)
       , allreadyUsedTypes()
       {}

    bool beforeEnums()      { return true; }
    bool afterEnums()       { return true; }
    bool beforeStructs()    { return true; }
    bool afterStructs()     { return true; }
    bool beforeIfs()        { return true; }
    bool afterIfs()         { return true; }


    bool performStruct( const ::std::string  &structName
                   , const CNamespaceInfo &rootNs
                   , const CNamespaceInfo &nsi
                   , const CStruct &structInfo
                   ) // const
       {
        return performStruct(structName, gen.makeIdentName(structName), gen.makeLabel(structName), rootNs, nsi, structInfo);
       }

    bool performStruct( const ::std::string  &structNameDuin
                    , const ::std::string  &structIdentName
                    , const ::std::string  &structLabelName
                    , const CNamespaceInfo &rootNs
                    , const CNamespaceInfo &nsi
                    , const CStruct &structInfo
                    ) // const
       {
        if (!params.idl.isInCurrentSet(structIdentName, params.srcFilesId)) return true;
        if (structInfo.isDeclaration()) return true; // declaration only
        if (!structInfo.aliasFor.empty()) return true; // skip alias

        ::std::string structDefineName(structInfo.fUnion ? "UNION_" : "STRUCT_");
        structDefineName.append(gen.convertNameToMacro(gen.getNameAsOneIdent(structIdentName)));

        ::std::string nsFullName, structPlainName;
        splitFqName(structIdentName, nsFullName, structPlainName);

        os<<"\n";
        os<<"/* ------------------------------------------------------ */\n";
        if (structInfo.fUnion)
           os<<"/* Union: "<<structIdentName<<" */\n";
        else 
           os<<"/* Struct: "<<structIdentName<<" */\n";
        os<<"/* ------------------------------------------------------ */\n";
        os<<"\n";

        ::std::map< ::std::string, ::std::set< ::std::string > > foundUsedTypes;
        findUsedTypes( params.idl, structInfo, allreadyUsedTypes, foundUsedTypes, typeOfTypeStruct|typeOfTypeInterface );

        if (!foundUsedTypes.empty())
           {
            os<<"#if defined(__cplusplus) && !defined(CINTERFACE)\n\n";
                gen.printCppPredeclareUsedTypes( os, params.idl, foundUsedTypes, ::std::string(4, ' '), typeOfTypeStruct|typeOfTypeInterface, true );
            os<<"\n#else /* C-like declarations */\n\n";
                gen.printCppPredeclareUsedTypes( os, params.idl, foundUsedTypes, ::std::string(4, ' '), typeOfTypeStruct|typeOfTypeInterface, false );
            os<<"\n#endif /* end of C-like declarations */\n\n";
    
            mergeTypeNames( allreadyUsedTypes, foundUsedTypes );
           }
        else
           {
            // os<<"/* no predeclarations needed for struct "<<structIdentName<<" */\n\n";
           }

        ::std::string unionOrStruct    = structInfo.fUnion ? "UNION" : "STRUCT";
        //::std::string unionOrStructLow = structInfo.fUnion ? "union" : "struct";
        ::std::string unionOrStructLow = structInfo.fUnion ? "struct" : "struct";

        //::std::string structPlainCDefineName(structInfo.fUnion ? "UNION_" : "STRUCT_");
        //structPlainCDefineName.append(convertNameToMacro(getNameAsOneIdent(structIdentName)));
        ::std::string structPlainCDefineName = structDefineName;
        //os<<"// structDefineName: "<<structDefineName<<"\n";


        os<<"#ifdef CLI_"<<unionOrStruct<<"_NAME\n   #undef CLI_"<<unionOrStruct<<"_NAME\n#endif\n\n";
        os<<"#if defined(__cplusplus) && !defined(CINTERFACE)\n\n";
        ::std::vector< ::std::string > closeReverseOrder;
        if (!gen.printCppNamespaceOpen(os, ::std::string(4, ' '), nsFullName, closeReverseOrder))
           return false;

        os<<"    #define CLI_"<<unionOrStruct<<"_NAME                   "<<structPlainName<<"\n";

        os<<"    #ifndef "<<structPlainCDefineName<<"_PREDECLARED\n"
          <<"    #define "<<structPlainCDefineName<<"_PREDECLARED\n"
          <<"        "<<unionOrStructLow<<" "<<structPlainName<<";\n";
                 gen.printCppStructNameDefines( os, structIdentName, structInfo, ::std::string(8, ' ')  /* indent */, true  /* bCpp */, true  /* addIfdef */ , structInfo.fUnion );
        os<<"    #endif // "<<structPlainCDefineName<<"_PREDECLARED\n\n";

        os<<"#else /* C-like declarations */\n\n"
          <<"    #define CLI_"<<unionOrStruct<<"_NAME                   "<<gen.getNameAsOneIdent(structIdentName)<<"\n";
        os<<"    #ifndef "<<structPlainCDefineName<<"_PREDECLARED\n"
          <<"    #define "<<structPlainCDefineName<<"_PREDECLARED\n"
          <<"        "<<unionOrStructLow<<"  tag_"<<gen.getNameAsOneIdent(structIdentName)<<";\n"
          <<"        typedef "<<unionOrStructLow<<" tag_"<<gen.getNameAsOneIdent(structIdentName)<<" "<<gen.getNameAsOneIdent(structIdentName)<<";\n";

                 gen.printCppStructNameDefines( os, structIdentName, structInfo, ::std::string(8, ' ')  /* indent */, false  /* bCpp */, true  /* addIfdef */ , structInfo.fUnion );
        os<<"    #endif // "<<structPlainCDefineName<<"_PREDECLARED\n\n";
        os<<"#endif /* end of C-like declarations */\n\n";

        ::std::string indent((closeReverseOrder.size()+1)*4, ' ');

        if (!gen.printCppStructDefinition( os, params.idl, structInfo, indent, params.srcFiles, structIdentName, -1))
           {
            return false;
           }

        os<<"\n";

        os<<"#if defined(__cplusplus) && !defined(CINTERFACE)\n\n";
        if (!gen.printCppNamespaceClose( os, ::std::string(4, ' '), closeReverseOrder))
           return false;
        os<<"#endif\n";

        os<<"\n";

        addTypeName( params.idl, structIdentName, allreadyUsedTypes, typeOfTypeStruct );

        return true;
       }

       

    bool performEnum( const ::std::string  &enumName
                   , const CNamespaceInfo &rootNs
                   , const CNamespaceInfo &nsi
                   , const CEnumeration &enumInfo
                   ) // const
       {
        return performEnum(enumName, gen.makeIdentName(enumName), gen.makeLabel(enumName), rootNs, nsi, enumInfo);
       }

    bool performEnum( const ::std::string  &enumNameDuin
                    , const ::std::string  &enumIdentName
                    , const ::std::string  &enumLabelName
                    , const CNamespaceInfo &rootNs
                    , const CNamespaceInfo &nsi
                    , const CEnumeration &enumInfo
                    ) // const
       {
        if (!params.idl.isInCurrentSet(enumIdentName, params.srcFilesId)) 
            return true;

        const CPodInfo* enumPod = 0;

        os<<"\n";
        os<<"/* ------------------------------------------------------ */\n";
        os<<"/* Enum: "<<enumIdentName<<" */\n";
        os<<"/* ------------------------------------------------------ */\n";
        os<<"\n";

        if (!enumInfo.extAttrs.podType.empty())
           {
            enumPod = params.idl.getPodInfo(enumInfo.extAttrs.podType, ::std::string("c"), ::std::string("c++"));
           }

        if (!enumInfo.extAttrs.podType.empty() && !enumPod)
           {
            std::cout<<"Enum '"<<enumIdentName<<"' - enum POD type defined by attribute 'pod', but POD type not found - use declare_pod_type\n";
            return false;
           }

        if (!gen.printCppEnumDefines( os, enumIdentName, enumInfo, enumPod, /* indent */  ::std::string(), /* addIfdef */ true))
           return false;

        if (!gen.printCppEnumXX( os, enumIdentName, enumInfo, enumPod, /* indent */  ::std::string(), /* addIfdef */  true))
           return false;

        os<<"\n\n\n";

        return true;
       }

    bool performIf( const ::std::string  &ifName
                   , const CNamespaceInfo &rootNs
                   , const CNamespaceInfo &nsi
                   , const CInterfaceInfo &ii
                   ) // const
       {
        return performIf(ifName, gen.makeIdentName(ifName), gen.makeLabel(ifName), rootNs, nsi, ii);
       }

    bool performIf( const ::std::string  &ifNameDuin
                   , const ::std::string  &ifIdentName
                   , const ::std::string  &ifLabelName
                   , const CNamespaceInfo &rootNs
                   , const CNamespaceInfo &nsi
                   , const CInterfaceInfo &ii
                   ) // const
       {
        if (!params.idl.isInCurrentSet(ifIdentName, params.srcFilesId)) return true;
        if (ii.isDeclaration()) return true; // declaration only
        if (ii.fImplementation) return true; // now, support for implementation documentation not implemented

        if(ii.extendsList.size()>1)
          {
           #ifndef CIDL_MULTIPLE_EXTENDS_ALLOWED
           std::cout<<"Error: interface '"<<ifIdentName<<"' extends multiple interfaces. Multiple inheritance not supported\n";
           return false;
           #endif
          }

        ::std::vector< ::cidl::CInterfaceEntry > allMethods;
        //::std::vector< ::cidl::CInterfaceEntry > allProperties;
        if (!gen.findAllMethods( ii, ifIdentName, params.idl, allMethods ))
           return false; // error occurs

        
        ::std::map< ::std::string, ::std::set< ::std::string > > paramIfs;
        if (!gen.findAllParamInterfaces( params.idl, allMethods, paramIfs))
            return false;

        os<<"\n";
        os<<"/* ------------------------------------------------------ */\n";
        os<<"/* Interface: "<<ifIdentName<<" */\n";
        os<<"/* ------------------------------------------------------ */\n";
        os<<"\n";

        ::std::map< ::std::string, ::std::set< ::std::string > > foundUsedTypes;
        findUsedTypes( params.idl, ii, allreadyUsedTypes, foundUsedTypes, typeOfTypeStruct|typeOfTypeInterface );

        if (!foundUsedTypes.empty())
           {
            os<<"#if defined(__cplusplus) && !defined(CINTERFACE)\n\n";
                gen.printCppPredeclareUsedTypes( os, params.idl, foundUsedTypes, ::std::string(4, ' '), typeOfTypeInterface, true );
            os<<"\n#else /* C-like declarations */\n\n";
                gen.printCppPredeclareUsedTypes( os, params.idl, foundUsedTypes, ::std::string(4, ' '), typeOfTypeInterface, false );
            os<<"\n#endif /* end of C-like declarations */\n\n";
    
            mergeTypeNames( allreadyUsedTypes, foundUsedTypes );
           }
        else
           {
            // os<<"/* no predeclarations needed for struct "<<structIdentName<<" */\n\n";
           }

        ::std::string indent(4, ' ');
        os<<"#ifdef INTERFACE\n"
          <<"    #undef INTERFACE\n"
          <<"#endif\n\n";

        if (!ii.extendsList.empty())
            os<<"#ifdef BASE_INTERFACE\n"
              <<"    #undef BASE_INTERFACE\n"
              <<"#endif\n\n";

        ::std::string ifNs, baseIfNs, baseIfName, tmp;
        if (!splitFqName(ifIdentName, ifNs, tmp))
           {
            std::cout<<"Invalid type: "<<ifIdentName<<" (failed to split to namespace::interface)\n";
            return false;
           }

        if (!ii.extendsList.empty())
           {
            if (!splitFqName(ii.extendsList[0], baseIfNs, baseIfName))
               {
                std::cout<<"Invalid type: "<<ii.extendsList[0]<<" (failed to split to namespace::interface)\n";
                return false;
               }
           }

        ::std::string interfaceDefineName("INTERFACE_");
        interfaceDefineName.append(gen.convertNameToMacro(gen.getNameAsOneIdent(ifIdentName)));

        ::std::string iidName;
        os<<"#ifndef "<<interfaceDefineName<<"_IID\n"
          <<"    #define "<<interfaceDefineName<<"_IID"<<"    \""<<gen.makeIID(ifNameDuin)<<"\"\n"
          <<"#endif\n\n";

        os<<"#if defined(__cplusplus) && !defined(CINTERFACE)\n";
        ::std::vector< ::std::string > closeReverseOrder;
        if (!gen.printCppNamespaceOpen(os, indent, ifNs, closeReverseOrder))
           return false;
        os<<indent<<"#define INTERFACE "<<ii.name<<"\n";
        if (!ii.extendsList.empty())
           os<<indent<<"#define BASE_INTERFACE "<<ii.extendsList[0]<<"\n";


        os<<indent<<"#ifndef "<<interfaceDefineName<<"\n"
          <<indent<<"   "<<"#define "<<interfaceDefineName<<"    "<<ifIdentName<<"\n"
          <<indent<<"#endif\n";

        os<<"#else /* C-like declaration */\n";
        os<<indent<<"#define INTERFACE "<<gen.getNameAsOneIdent(ifIdentName)<<"\n";
        if (!ii.extendsList.empty())
           {
            if (ii.extendsList.size()>1)
            os<<indent<<"// Only first interface declared as base\n";
            os<<indent<<"#define BASE_INTERFACE "<<gen.getNameAsOneIdent(ii.extendsList[0])<<"\n";
           }

        os<<indent<<"#ifndef "<<interfaceDefineName<<"\n"
          <<indent<<"   "<<"#define "<<interfaceDefineName<<"    "<<gen.getNameAsOneIdent(ifIdentName)<<"\n"
          <<indent<<"#endif\n";

        os<<"#endif\n\n";

        ::std::string ifIndent;// = indent;
        ifIndent.append((closeReverseOrder.size()+1)*4, ' ');
        //os<<"\n";
        if (ii.extendsList.empty())
           os<<ifIndent<<"CLI_DECLARE_INTERFACE(INTERFACE)\n";
        else if (ii.extendsList.size()>1)
           {
            os<<ifIndent<<"CLI_DECLARE_INTERFACE"<<(unsigned)ii.extendsList.size()<<"_(INTERFACE, BASE_INTERFACE";
            for(SIZE_T i = 1; i!=ii.extendsList.size(); ++i)
               {
                ::std::string tmpInterfaceDefineName("INTERFACE_");
                tmpInterfaceDefineName.append(gen.convertNameToMacro(gen.getNameAsOneIdent(ii.extendsList[i])));
                os<<", "<<tmpInterfaceDefineName;
                //os<<", "<<gen.getNameAsOneIdent(ii.extendsList[i]);
               }
            os<<")\n";
           }
        else
           { // single base interface
            os<<ifIndent<<"CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)\n";
           }

        os<<ifIndent<<"{\n";

        //::std::auto_ptr< ::cidl::CIMethodGenerator> pMethodGen((gen.getFabriq())->createMethodGenerator(gen.getOutputType()));
        //if (pMethodGen.get())
        //   {
        CMethodGenerationParams mgParams;
        mgParams.ifNameDuin  = ifNameDuin;
        mgParams.ifIdentName = ifIdentName;
        mgParams.ifLabelName = ifLabelName;
        mgParams.ifInfo      = ii;
        //mgParams.

        ::std::string methodOrgIf;
        ::std::string methodIndent = ifIndent + ::std::string(4, ' ');

        ::std::ostringstream wrapperMethodsSS;

        ::std::vector< ::cidl::CInterfaceEntry >::const_iterator amIt = allMethods.begin();
        for(; amIt!=allMethods.end(); ++amIt)
           {
            if (methodOrgIf!=amIt->originalIfName)
               {
                methodOrgIf = amIt->originalIfName;
                os<<methodIndent<<"\n"<<methodIndent<<"/* interface "<<methodOrgIf<<" methods */\n";
               }

            if (!gen.generateCppMethodDeclaration( os, methodIndent, *amIt, params, mgParams, CGOTC_BOTH))
               return false;    
            if (!gen.generateCppMethodDeclaration( wrapperMethodsSS, ::std::string(), *amIt, params, mgParams, CGOTC_CXX_WRAP))
               return false;    
            // if (!pMethodGen->generateDeclaration( os, methodIndent, *amIt, params, mgParams))
            //    return false;    
           }
        //   } // if (pMethodGen.get())

        os<<ifIndent<<"};\n\n";


        ::std::vector< ::std::string > allIfs;
        if (!gen.findAllInterfaces( ii, ifIdentName, params.idl, allIfs))
           {
            std::cout<<"Can't find base interfaces for interface '"<<ifIdentName<<"'\n";
            return false;           
           }

        bool implement_iUnknown = false;
        if (::std::find(allIfs.begin(), allIfs.end(), ::std::string("::cli::iUnknown"))!=allIfs.end())
           {
            implement_iUnknown = true;
            //tplEnabledSections.insert("implement_iUnknown");
           }


        os<<"#if defined(__cplusplus) && !defined(CINTERFACE)\n\n";

        if ( implement_iUnknown )
           {
            //closeReverseOrder.clear();
            if (!gen.printCppNamespaceClose( os, indent, closeReverseOrder))
               return false;
        
            os<<"\n"
              <<indent<<"namespace cli{\n"
              <<indent<<"    template<> struct CIidOfImpl< "<<ifIdentName<<" >\n"
              <<indent<<"       {\n"
              <<indent<<"        static char const * getName() { ";
            if ( implement_iUnknown )
              os<<"return "<<interfaceDefineName<<"_IID;";
            else
              os<<"CLI_STATIC_CHECK(0, interface_"<<gen.getNameAsOneIdent(ifIdentName)<<"_does_not_extend_cli_iUnknown_0_cli_iidOf_not_specialized_for_this_interface); return 0;";
        
            os<<" }\n";
        
            os<<indent<<"       };\n"
              <<indent<<"    template<> struct CIidOfImpl< "<<ifIdentName<<"* >\n"
              <<indent<<"       {\n"
              //<<indent<<"        static char const * getName("<<ifIdentName<<"* const & t) { return "<<interfaceDefineName<<"_IID; }\n"
              <<indent<<"        static char const * getName() { return CIidOfImpl< "<<ifIdentName<<" > :: getName(); }\n"
              <<indent<<"       };\n"
              <<indent<<"}; // namespace cli\n\n";
              //return CIiidOfImpl<::test::IOtherTest>::getName(*t);
        
            //::std::vector< ::std::string > closeReverseOrder;
            closeReverseOrder.clear();
           }

        bool needWrapper = true;
        //const CInterfaceInfo &ii
        const ::cidl::CCppOption *pCppOption = ii.cppOptions.findOption( CK_INTERFACE
                                                               , ::marty::make_vector< ::std::string >( ::std::string("need_wrapper"), ::std::string("no_wrapper"))
                                                               );
        if (pCppOption && pCppOption->optionArgs[0]==::std::string("no_wrapper"))
           needWrapper = false;


        if (!needWrapper)
           {
            if ( !implement_iUnknown )
               { 
                if (!gen.printCppNamespaceClose( os, indent, closeReverseOrder))
                   return false;
                os<<"\n";
               }

            os<<indent<<"/* C++ wrapper generation disabled by 'cpp_option(interface, \"no_wrapper\")' in interface definition */\n"
              <<indent<<"/* To enable wrapper generation, remove \"no_wrapper\" option or add \"need_wrapper\" option after \"no_wrapper\" option */\n\n";
           }
        else
           {
            if ( implement_iUnknown )
               { 
                if (!gen.printCppNamespaceOpen(os, indent, ifNs, closeReverseOrder))
                   return false;
               }

            ::std::string clsIndent = ifIndent; // indent; 
            clsIndent.append(4, ' ');
    
    
            std::map< ::std::string, ::std::string> macroses;
            macroses["InterfaceName"]     = ii.name;
            macroses["InterfaceFullName"] = ifIdentName;
            macroses["InterfaceUniCName"]    = interfaceDefineName;
            macroses["InterfaceID"]       = interfaceDefineName + ::std::string("_IID");
    
            {
             ::std::ostringstream ossTmp;
             genUtil::printWithIndent( ossTmp, ifIndent + ::std::string(8, ' '), wrapperMethodsSS.str());
             macroses["InterfaceWrapperMethods"]  = ::std::string(8, ' ') + genUtil::ltrim_copy(ossTmp.str());
            }
            
            ::std::set< ::std::string > tplEnabledSections;
    
            if (!ii.extendsList.empty())
               {
                macroses["BaseInterface"] = ii.extendsList[0];
                macroses["Extends"] = ::std::string(": public ") + ii.extendsList[0];
                tplEnabledSections.insert("have_Base");
               }
            else
               {
                tplEnabledSections.insert("havnt_Base");
               }
    
            ::std::string tplFileName("wrapper_template");

            if (implement_iUnknown)
               {
                tplEnabledSections.insert("implement_iUnknown");
               }

            tplFileName.append(".cpp");

            if (!gen.processTemplate( tplFileName, os, ifIndent
                                    , params.srcFiles
                                    , ii.declaredAt.filenameId
                                    , tplEnabledSections
                                    , macroses
                                    ))
               {
                os<<indent<<"/* Template generation not performed */\n";
                os<<indent<<"/* template file '"<<tplFileName<<"' not found in source file directory, current directory or cidl executable file directory */\n";
               }
    
            if (!gen.printCppNamespaceClose( os, indent, closeReverseOrder))
               return false;
           }


        os<<"\n#endif\n"; // if defined(__cplusplus)

        os<<"\n\n\n\n\n";

        return true;
       }
}; // struct CPrintIfCppDecl





//-----------------------------------------------------------------------------
bool CCppIfDeclarationGenerator::generate( ::std::ostream             &os
             , const ::std::string        &outputFilename
             , const CGenerationParams    &genParams
             )
   {
    generateHeaderProlog( os, outputFilename);

    if (!(genParams.genFlags&genFlagCppAllStdHeaders_off))
       {
        os<<"/* Standard includes */\n\n";
    
        os<<"#ifndef CLI_CLI2BASE_H\n"
            "    #include <cli/cli2base.h>\n"
            "#endif\n\n";
    
        os<<"#ifndef CLI_CLI2TYPES_H\n"
            "    #include <cli/cli2types.h>\n"
            "#endif\n\n";
    
        os<<"#ifndef CLI_IIDOF_H\n"
            "    #include <cli/iidof.h>\n"
            "#endif\n\n";
    
        os<<"#ifndef CLI_IFDEFS_H\n"
            "    #include <cli/ifdefs.h>\n"
            "#endif\n\n";
    
        os<<"#ifndef CLI_CLIASSERT_H\n"
            "    #include <cli/cliassert.h>\n"
            "#endif\n\n";
    
        os<<"#ifndef CLI_IUNKNOWN_H\n"
            "    #include <cli/iunknown.h>\n"
            "#endif\n\n";
        
        if (!(genParams.genFlags&genFlagCppCliExcept_off))
            os<<"#ifndef CLI_CLIEXCEPT_H\n"
                "    #include <cli/cliexcept.h>\n"
                "#endif\n\n";

        if (!(genParams.genFlags&genFlagCppCliProperty_off))
            os<<"#ifndef CLI_PROPERTY_H\n"
                "    #include <cli/property.h>\n"
                "#endif\n\n";

        if (!(genParams.genFlags&genFlagCppCliPtr_off))
            os<<"#ifndef CLI_CLIPTR_H\n"
                "    #include <cli/cliptr.h>\n"
                "#endif\n\n";
    
        if (!(genParams.genFlags&genFlagCppCliStr_off))
            os<<"#ifndef CLI_CLISTR_H\n"
                "    #include <cli/clistr.h>\n"
                "#endif\n\n";
       }


    if (!genParams.idl.globalNs.cppIncludes.empty())
       os<<"/* User defined includes */\n\n";

    //cppDefines 
    ::std::vector<cidl::CCppInclude>::const_iterator incIt = genParams.idl.globalNs.cppIncludes.begin();
    for(; incIt!=genParams.idl.globalNs.cppIncludes.end(); ++incIt)
       {
        // ���������� ��� ������� �� ���� ������������ ������
        //if (genParams.srcFilesId.find(incIt->declaredAt.filenameId)==genParams.srcFilesId.end()) continue;
        std::string indent;
        if (incIt->includeFile.empty()) continue; // file name to include not taken
        if (!incIt->includeGuard.empty())
           {
            os<<"#ifndef "<<incIt->includeGuard<<"\n";
            indent = ::std::string(4, ' ');
           }
        os<<indent<<"#include ";
        bool needQuotes = false;
        if (incIt->includeFile[0]!='<') needQuotes = true;
        if (needQuotes)
           os<<"\""<< ::cidl::genUtil::changeSlash(incIt->includeFile)<<"\"";
        else
           os<< ::cidl::genUtil::changeSlash(incIt->includeFile);
        os<<"\n";

        if (!incIt->includeGuard.empty())
           {
            os<<"#endif\n";
           }
         os<<"\n";
        }

    if (!genParams.idl.globalNs.cppDefines.empty())
       os<<"\n\n/* User defined macroses */\n\n";

    //::std::vector<cidl::CCppInclude>::const_iterator 
    incIt = genParams.idl.globalNs.cppDefines.begin();
    for(; incIt!=genParams.idl.globalNs.cppDefines.end(); ++incIt)
       {
        if (genParams.srcFilesId.find(incIt->declaredAt.filenameId)==genParams.srcFilesId.end()) continue;
        //std::string indent;
        if (incIt->includeFile.empty()) continue; // file name to include not taken

        ::std::string::size_type bracketPos = incIt->includeFile.find('(');
        ::std::string macrosName = bracketPos==::std::string::npos ? incIt->includeFile : ::std::string(incIt->includeFile, 0, bracketPos);

        os<<"#ifndef "<<macrosName<<"\n";
        os<<"    #define "<<incIt->includeFile<<"    "<<incIt->includeGuard<<"\n";
        os<<"#endif\n\n";
       }


    CPrintIfCppDecl cppDeclPrinter(os, *this, outputFilename, genParams);

    enumNsInterfaces(::std::string(), genParams.idl.globalNs, genParams.idl.globalNs, cppDeclPrinter);

    generateHeaderEpilog( os, outputFilename);
    return true;
   }

//-----------------------------------------------------------------------------
bool CCppIfMethodGenerator::generateDeclaration( ::std::ostream                &os
                        , ::std::string                 indent
                        , const CInterfaceEntry         &iEntry
                        , const CGenerationParams       &genParams
                        , const CMethodGenerationParams &methodGenParams
                        )
   {
    if (iEntry.fProperty)
       {
        // not used, see CIGenerator::generateCppMethodDeclaration
        os<<indent<<"/* CCppIfMethodGenerator::generateDeclaration \n";
        os<<indent<<"Property: "<<iEntry.propertyInfo.name<<"\n";
        if ((iEntry.propertyInfo.direction&::cidl::directionGetSet) == ::cidl::directionGetSet)
           os<<indent<<"read/write\n";
        else if ((iEntry.propertyInfo.direction&::cidl::directionSet) == ::cidl::directionSet)
           os<<indent<<"write only\n";
        else if ((iEntry.propertyInfo.direction&::cidl::directionGet) == ::cidl::directionGet)
           os<<indent<<"read only\n";
        os<<indent<<"*/\n";
        
        /*
        iEntry.propertyInfo
        ---
        int                                 direction;   // read, write, read/write allowed
        ::std::string                       type;        // property type
        ::std::string                       name;        // property name
        ::std::vector< ::std::string >      indexTypes;  // index types list
        */

        return true;
       }
    ::std::string ptrTypePart = genParams.idl.getTypeNamePointers(iEntry.methodInfo.type);
    ::std::string pureType    = genParams.idl.getPureTypeName(iEntry.methodInfo.type);
    const CPodInfo* retPod    = genParams.idl.getPodInfo(pureType, ::std::string("c"), ::std::string("c++"));
    if (!retPod && ptrTypePart.empty())
       {
        std::cout<<"Error: interface "<<methodGenParams.ifIdentName<<" method "<<iEntry.methodInfo.name<<": return type "<<iEntry.methodInfo.type<<" is not POD no� pointer, or type not defined for C/C++ destination\n";
        return false;
       }

    os<<indent<<"CLIMETHOD";
    indent.append(9, ' '); // CLIMETHOD len

    if (iEntry.methodInfo.callType==calltypeVamethod)
       {
        indent.append(2, ' '); // VA len
        os<<"VA";
       }
    if (iEntry.methodInfo.type!= ::std::string("rcode"))
       { // stdmethod
        indent.append(2 + 2 + 2, ' '); // _( , ) len
        indent.append(retPod->type.size()+iEntry.methodInfo.name.size()+ptrTypePart.size(), ' ');
        os<<"_("<<retPod->type<<ptrTypePart<<", "<<iEntry.methodInfo.name<<") ";
       }
    else
       {
        indent.append(3, ' '); // _( , ) len
        indent.append(iEntry.methodInfo.name.size(), ' ');
        os<<"("<<iEntry.methodInfo.name<<") ";
       }
    
    os<<"(THIS";
    ::std::string closeIndent = indent;
    indent.append(5, ' '); // (THIS len
    if (!iEntry.methodInfo.parameters.empty())
       {
        os<<"_";
        //indent.append(6, ' '); // (THIS len
       }
    
    ::std::vector< CParameter >::const_iterator mpIt = iEntry.methodInfo.parameters.begin();  // 
    for(; mpIt!=iEntry.methodInfo.parameters.end(); ++mpIt)
       {
        if (mpIt==iEntry.methodInfo.parameters.begin())
           os<<" ";
        else
           os<<"\n"<<indent<<", ";
        if (!generateParameter( os, indent, iEntry, *mpIt, genParams, methodGenParams ))
           return false;
        //os<<mpIt->name; //<<;
       }

    if (iEntry.methodInfo.parameters.size()>1)
       os<<"\n"<<closeIndent;

    os<<");\n";
    //os<<"\n";
    //os<<indent<<iEntry.methodInfo.name<<"\n";
    return true;
   }

//-----------------------------------------------------------------------------
bool CCppIfMethodGenerator::generateParameter( ::std::ostream                &os
                      , ::std::string                 indent
                      , const CInterfaceEntry         &iEntry
                      , const CParameter              &methodParam
                      , const CGenerationParams       &genParams
                      , const CMethodGenerationParams &methodGenParams
                      , bool *pNeedWrapper
                      )
   {
    // struct CParameter
    // {
    //     int                                 direction;   // in, out allowed - default directionIn
    //     bool                                fArray;       // only 1 index, only SIZE_T index type
    //     ::std::string                       type;        // parameter type
    //     ::std::string                       name;        // parameter name
    // };

    const CIdl &idl = genParams.idl;

    ::std::string ptrTypePart = idl.getTypeNamePointers(methodParam.type);
    ::std::string pureType    = idl.getPureTypeName(methodParam.type);

    const CPodInfo* podInfo   = 0;

    if (idl.isPod(pureType))
       {
        podInfo = idl.getPodInfo(pureType, ::std::string("c"), ::std::string("c++"));
        if (!podInfo)
           {
            std::cout<<"Error: interface "<<methodGenParams.ifIdentName
                          <<" method "<<iEntry.methodInfo.name
                          <<" parameter "<<methodParam.name
                          <<": type "<<iEntry.methodInfo.type
                          <<" is POD, but type not defined for C/C++ destination\n";
            return false;
           }
       }
    
    // now non-zero podInfo designates that the pure type (w/o ptrs) is POD

    ::std::string decoratedPureType = pureType;
    if (!podInfo)
       { // non POD
        if (idl.isInterface(pureType))
           { // interface, need to be decorated
            decoratedPureType = ::std::string("INTERFACE_") + genUtil::convertNameToMacro(genUtil::getNameAsOneIdent(decoratedPureType));
           }
       }
    else
       { // POD type
        decoratedPureType = podInfo->type;
       }



    if (!ptrTypePart.empty())
       { // ���������� ���������
        // ���� �������� OUT ��� REF �� �������� ���������
        // ���� �������� IN � REF �� �������� const ���������
        if (methodParam.direction&passByRef || methodParam.direction&directionOut || methodParam.fArray)
           { // ��������� ���������� �� ������ ��� ������������, ��� ���������� ������, ��������� ������� �����������
            if (methodParam.direction&passByRef)
               { // �� ������
                os<<"const ";
                if (methodParam.fArray)
                   {
                    std::cout<<"Error: interface "<<methodGenParams.ifIdentName
                                  <<" method "<<iEntry.methodInfo.name
                                  <<" parameter "<<methodParam.name
                                  <<": can't pass array by reference\n";
                    return false;
                   }
               }
            else if (!(methodParam.direction&directionOut) && methodParam.fArray)
               {
                os<<"const ";
               }
            os<<decoratedPureType<< ::std::string(ptrTypePart.size()+1, '*')<<"    "<<methodParam.name;
            os<<" /* "; print(methodParam, ::std::string(), os, true  /* dontPrintComment */); os<<" */";
            
            if (methodParam.fArray)
               {
                os<<"\n"<<indent<<", SIZE_T    "<<methodParam.name<<"Size /* size of array "<<methodParam.name<<" */";
                if (pNeedWrapper) *pNeedWrapper = true;
               }

            return true;
           }
        // ��������� ���������� IN
        os<<"const "<<decoratedPureType<< ::std::string(ptrTypePart.size(), '*')<<"    "<<methodParam.name;
        os<<" /* "; print(methodParam, ::std::string(), os, true  /* dontPrintComment */); os<<" */";
        return true;
       }

    if (idl.isInterface(pureType))
       { // �� ���������, �� ���������, ������ ����������
        std::cout<<"Error: interface "<<methodGenParams.ifIdentName
                      <<" method "<<iEntry.methodInfo.name
                      <<" parameter "<<methodParam.name
                      <<": can't pass interface object itself, can pass it only as pointer\n";
        return false;
       }

    if (pureType == ::std::string("void") && !methodParam.fArray)
       { // void ��� ������ ���������� ��� �� ����
        std::cout<<"Error: interface "<<methodGenParams.ifIdentName
                      <<" method "<<iEntry.methodInfo.name
                      <<" parameter "<<methodParam.name
                      <<": can't pass void parameter itself, can pass it only as pointer\n";
        return false;
       }

    // process structs here

    // here only pods need processing
    if (methodParam.direction&passByRef || methodParam.direction&directionOut || methodParam.fArray || podInfo->attrs&passByRef)
       { // ���������� ���� ��� �������� �� ������, ���� ����� ������������, ���� ������, ���� ��� ������ ������������ �� ������
        // ��������� ������� �����������
        if (!(methodParam.direction&directionOut))
           { // �� �������� (������������) ��������
            os<<"const ";
           }
        os<<decoratedPureType<< ::std::string(ptrTypePart.size()+1, '*')<<"    "<<methodParam.name;
        os<<" /* "; print(methodParam, ::std::string(), os, true  /* dontPrintComment */); os<<" */";
        if (methodParam.fArray)
           {
            os<<"\n"<<indent<<", SIZE_T    "<<methodParam.name<<"Size /* size of array "<<methodParam.name<<" */";
            if (pNeedWrapper) *pNeedWrapper = true;
           }

        if (!podInfo->nativeType.empty())
           { // exist native to cli type conversion
            if (pNeedWrapper) *pNeedWrapper = true;
           }
       }
    else // not a reference, out parameter, or an array
       {
        os<<decoratedPureType<< ::std::string(ptrTypePart.size(), '*')<<"    "<<methodParam.name;
        os<<" /* "; print(methodParam, ::std::string(), os, true  /* dontPrintComment */); os<<" */";
       }
    //podInfo



    //const CPodInfo* retPod = genParams.idl.getPodInfo(methodParam.type, ::std::string("c"));

    // idl.getPureTypeName
    // idl.getTypeNamePointers

    //os<<methodParam.name;

    return true;
   }

bool CCppIfMethodGenerator::generateDefinition( ::std::ostream                &os
                       , ::std::string                 indent
                       , const CInterfaceEntry         &iEntry
                       , const CGenerationParams       &genParams
                       , const CMethodGenerationParams &methodGenParams
                       )
   {
    if (iEntry.fProperty) return true;
    //iEntry
    return true;
   }

//-----------------------------------------------------------------------------




}; // namespace cidl