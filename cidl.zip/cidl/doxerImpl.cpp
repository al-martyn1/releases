#define DOXY_CDOCITEM_USE_OSTREAM_OUTPUT

#include "doxerImpl.h"
#include "parserImpl.h"
#include "doxy.h"


#ifdef CIDL_CDOXER_LOGGING_USED
    #if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
        #include <iostream>
    #endif
#endif /* CIDL_CDOXER_LOGGING_USED */

//doxy.h

//-----------------------------------------------------------------------------
namespace cidl
{

namespace doxyUtil
{

struct CDoxyCidlTagsTokeniser
{                                    // id, argCount pair
    std::map< ::std::string, ::std::pair<int, int> > tags;

    CDoxyCidlTagsTokeniser(const CDoxyCidlTagsTokeniser &d) : tags(d.tags) {}
    CDoxyCidlTagsTokeniser() : tags()
       {
        tags["\n"]        = ::std::make_pair( DT_LINEFEED , 0);
        tags["brief"]     = ::std::make_pair( DT_BRIEF , 0);
        tags["namespace"] = ::std::make_pair( DT_NAMESPACE, -1 );
        tags["interface"] = ::std::make_pair( DT_INTERFACE, -1 );
        tags["method"]    = ::std::make_pair( DT_METHOD, -1 );
        tags["property"]  = ::std::make_pair( DT_PROPERTY, -1 );
        tags["param"]     = ::std::make_pair( DT_PARAM, -1 );
        tags["author"]    = ::std::make_pair( DT_AUTHOR, -1 );
        tags["date"]      = ::std::make_pair( DT_DATE, -1 );
        tags["file"]      = ::std::make_pair( DT_FILE, -1 );
        tags["if"]        = ::std::make_pair( DT_IF    , -1 );
        tags["ifnot"]     = ::std::make_pair( DT_IFNOT , -1 );
        tags["else"]      = ::std::make_pair( DT_ELSE  , -1 );
        tags["elseif"]    = ::std::make_pair( DT_ELSEIF, -1 );
        tags["endif"]     = ::std::make_pair( DT_ENDIF , -1 );
        //tags[""] = ::std::make_pair( , );
       }

    bool operator()(const ::std::string &srcStr, int &type, int &argCount) const
       {
        std::map< ::std::string, ::std::pair<int, int> >::const_iterator it = tags.find(srcStr);
        if (it==tags.end()) return false;
        type     = it->second.first;
        argCount = it->second.second;
        return true;
       }

};


}; // namespace doxyUtil

//-----------------------------------------------------------------------------
/*
#ifdef CIDL_CDOXER_LOGGING_USED
void
CDoxerImpl::logEvent( int         eventTypeCode //!< 0x0100 - event info flag, 0x0200 - action info flag, 0 - event message, 1 - event message on inadmissible event, 0x0101 - from, 0x0102 - to, 0x0103 - event, 0x0104 - quard, 0x0201 - entry action, 0x0202 - trigger action, 0x0203 - do action, 0x0204 - exit action
        , int         fromState    //!< transition start state, can be used for event filtration
        , int         toState      //!< transition end state, can be used for event filtration
        , const char *eventMsg     //!< from/to state name, event name, guard condition, entry/trigger/do/exit action text or info message
        )
   {
    //
    //if (!eventTypeCode)
    //std::cout<<"----------------\n";
    //std::cout<<eventMsg<<"\n";
    //
   }
#endif // CIDL_CDOXER_LOGGING_USED

//-----------------------------------------------------------------------------
void
CDoxerImpl::customResetAutomata( )
   {
    curObj.clear();
    prevObj.clear();
   }
*/
//-----------------------------------------------------------------------------
void
CDoxerImpl::parseDoxy
         ( const int            flags
         , const ::std::string  brief       
         , const ::std::string  detailed    
         )
   {
    //CDoxyCommentItem
    //#ifdef CIDL_CDOXER_LOGGING_USED
    //std::cout<<"Documentation for: " << (DOXY_IS_FAFTER(flags) ? prevObj : curObj) << "\n";

    //std::cout<<"!!! Prev obj: "<<objNames.getPrevName()<<"\n";
    //std::cout<<"!!! Cur obj: " <<objNames.getCurName()<< "\n";
    //std::cout<<"!!! Documentation for: " << (DOXY_IS_FAFTER(flags) ? "prev" : " cur" ) << "\n";

    /*
    std::cout<<"Documentation for: " << (DOXY_IS_FAFTER(flags) ? objNames.getPrevName() : objNames.getCurName() ) << "\n";

    //if (af) std::cout<<"After, ";
    if (DOXY_JAVADOC_AUTOBRIEF_ALLOWED(flags)) std::cout<<"Allow javadoc autobrief\n";
    if (!brief.empty())
       std::cout<<"Brief raw: "<<brief<<"\n";
    if (!detailed.empty())
       std::cout<<"Detailed raw: "<<detailed<<"\n";
    std::cout<<"---\n";
    */
    //::std::vector< ::doxy::CDoxyCommentItem > briefDoxy;
    ::std::vector< ::doxy::CDoxyCommentItem > detailedDoxy;
    doxyUtil::CDoxyCidlTagsTokeniser tokeniser;

    //splitStringDoxy(tokeniser, brief   , doxyAliasises, enabledSections, briefDoxy    );
    splitStringDoxy(tokeniser, detailed, doxyAliasises, enabledSections, detailedDoxy );

    /*
    std::cout<<"Detailed doxy:\n"<<detailedDoxy<<"\n";
    std::cout<<"----------------\n\n\n";
    */
    //#endif /* CIDL_CDOXER_LOGGING_USED */


    bool abAllowed = DOXY_JAVADOC_AUTOBRIEF_ALLOWED(flags) ? true : false;
    if (!this->autoBrief) abAllowed = false;

    bool briefAllowed = true;
    if (!brief.empty()) briefAllowed = false;

    ::std::vector< ::doxy::CDocItem > docList;

    ::doxy::parseDoxy( detailedDoxy
                     //, (DOXY_IS_FAFTER(flags) ? prevObj : curObj)
                     , (DOXY_IS_FAFTER(flags) ? objNames.getPrevName() : objNames.getCurName() )
                     , abAllowed
                     , briefAllowed
                     , docList
                     );

    if (!docList.empty() && !brief.empty())
       {
        docList[0].description.brief = brief;
       }

    /*
    std::cout<<docList;
    std::cout<<"\n----------------\n\n\n";
    */

    ::std::vector< ::doxy::CDocItem >::const_iterator dlIt = docList.begin();
    for(; dlIt!=docList.end(); ++dlIt)
       {
        /*
        std::cout<<"* setting description for "<<dlIt->docFor<<" brief: "
                 <<dlIt->description.brief<<"\nDetailed: "<<dlIt->description.detailed<<"\n";
        */
        documentation.setElementDescription(dlIt->docFor, dlIt->description, true);
       }

   }

//-----------------------------------------------------------------------------
void
CDoxerImpl::parseDoxyBuf
            ( 
            )
   {
    if (buf.empty()) return;

    //const ::doxy::CDoxyEvent &first = buf[0];

    if (buf.size()==1)
       {
        parseDoxy(buf[0].doxyType, ::std::string(), buf[0].text );
        buf.clear();
        lfCount = 0;
        return;
       }
    //else // if (buf.size()==2)
    parseDoxy(buf[1].doxyType, buf[0].text, buf[1].text );
    buf.clear();
    lfCount = 0;
   }

//-----------------------------------------------------------------------------
void CDoxerImpl::parseDoxyBufFirst ( )
   {
    if (buf.empty()) return;
    parseDoxy(buf[0].doxyType, ::std::string(), buf[0].text );
    buf.erase(buf.begin());
   }

//-----------------------------------------------------------------------------
int CDoxerImpl::flush ( )
   {
    parseDoxyBuf();
    lfCount = 0;
    return 0;
   }

//-----------------------------------------------------------------------------
int CDoxerImpl::multi ( const ::doxy::CDoxyEvent  &evt )
   {
    if (buf.empty())
       { // ������ ��������� � �����
        buf.push_back(evt);
        lfCount = 0;
        return 0;
       }
    
    if (buf.size()>=2)
       {
        parseDoxyBuf();
        buf.push_back(evt);
        lfCount = 0;
        return 0;
       }

    // here buf.size()==1
    if (buf[0].isMultiline())
       {
        parseDoxyBuf();
        buf.push_back(evt);
        lfCount = 0;
        return 0;
       }
    
    buf.push_back(evt);
    lfCount = 0;
    return 0;
   }

//-----------------------------------------------------------------------------
int CDoxerImpl::single ( const ::doxy::CDoxyEvent  &evt )
   {
    if (buf.empty())
       {
        buf.push_back(evt);
        lfCount = 0;
        return 0;
       }

    if (buf[0].isM()) // buf[0] is originaly multiline
       {
        parseDoxyBuf();
        buf.push_back(evt);
        lfCount = 0;
        return 0;
       }

/*
    if (buf.size()>=2)
       {
        parseDoxyBuf();
        buf.push_back(evt);
        lfCount = 0;
        return 0;
       }
*/
    if (buf.size()==1)
       {
        // 1 ����� �������� � ���������� ��������, ���� ��� �������� � �� ���� ���� ��������� ������
        if (DOXY_TYPES_EQUAL(buf.back().doxyType, evt.doxyType) && lfCount<2)
           {
            appendLastEvent(evt);
            lfCount = 0;
            return 0;
           }
        // 2 ����� ��������� �������
        buf.push_back(evt);
        lfCount = 0;
        return 0;
       }

    //buf.size()==2
    if (DOXY_TYPES_EQUAL(buf.back().doxyType, evt.doxyType))
       {
        if (buf[0].isMS()) // ������ �������������, ������ ���� ����� ����� ����� ��
           {
            parseDoxyBufFirst(); // ������� ������������ ������ ������ ��� detailed
            //buf.push_back(evt);
            appendLastEvent(evt);
            lfCount = 0;
            return 0;
           }
        // ������ - ������������, ������ ��� ��� ���� �������������
        appendLastEvent(evt);
        lfCount = 0;
        return 0;
       }

    // event type and buf type are not equal, and buf size ==2
    parseDoxyBuf();
    buf.push_back(evt);
    lfCount = 0;
    return 0;
   }

//-----------------------------------------------------------------------------
int CDoxerImpl::internalLf()
   {
    return 0;
   }

//-----------------------------------------------------------------------------



}; // namespace cidl


