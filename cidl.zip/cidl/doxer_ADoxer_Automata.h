#ifndef DOXER_ADOXER_AUTOMATA_H
#define DOXER_ADOXER_AUTOMATA_H

/* Warning! Automaticaly generated file, do not edit */

#include <set>
#include <map>
#include <vector>
#include <stack>
#include <string>
#include "../doxy/doxy.h"





namespace cidl {

class CDoxer {

    protected:  ::std::string        curObj      ;
    protected:  ::std::string        prevObj     ;
    protected:  ::std::vector< ::doxy::CDoxyEvent > buf         ;
    protected:  int                  curState    ; //!< Automaticaly added member for saving current automata state
    public:     static const int     ST_doxyBuf1  = 0x00000001; //!< ADoxer:DOXY_BUF1
    public:     static const int     ST_doxyBuf2  = 0x00000002; //!< ADoxer:DOXY_BUF2
    public:     static const int     ST_doxyEntry = 0x00000003; //!< ADoxer:DOXY_ENTRY
    public:     static const int     ST_intStatefinalmask = 0x80000000; //!< __int_stateFinalMask__


    public:     
        virtual
        int
        doxy
            ( const ::doxy::CDoxyEvent  evt         
            )
           {
            if (evt.getType()==DOXY_CT_JAVADOC) return multi(evt); // javaDoc, only multi line
            if (evt.getType()==DOXY_CT_DOXYGEN) return single(evt); // doxyCpp, only single line
            if (evt.getType()==DOXY_CT_QTDOC)
               {
                if (evt.doxyType&DOXY_CTF_SINGLELINE) return single(); // qtSingle
                else                                  return multi();  // qtMulti
               }
            return getCurState();
           }

    protected:  
        int
        javaDoc
               ( const ::doxy::CDoxyEvent  evt         
               )
           {
            return 0;
           }

    protected:  
        int
        qtSingle
                ( const ::doxy::CDoxyEvent  evt         
                )
           {
            return 0;
           }

    protected:  
        int
        qtMulti
               ( const ::doxy::CDoxyEvent  evt         
               )
           {
            return 0;
           }

    protected:  
        int
        doxyCpp
               ( const ::doxy::CDoxyEvent  evt         
               )
           {
            return 0;
           }

    protected:  
        virtual
        int
        single
              ( const ::doxy::CDoxyEvent  evt         
              )
           {
            /* guard variable - evt.doxyType */
            switch(this->curState)
               {
                case ST_doxyBuf1:    /* ADoxer:DOXY_BUF1 */
                                       {
                               /* State DOXY_BUF1 - exit_action empty */
                               /* Transition from DOXY_BUF1 to DOXY_BUF2 actions */
                               { appendBuf(evt); }
                               /* State DOXY_BUF2 - entry_action empty */
                            this->curState = ST_doxyBuf2;
                           }
                     break;
                case ST_doxyBuf2:    /* ADoxer:DOXY_BUF2 */
                           {
                               /* Transition from DOXY_BUF2 to DOXY_BUF2 actions */
                            this->curState = ST_doxyBuf2;
                           }
                     break;
                case ST_doxyEntry:    /* ADoxer:DOXY_ENTRY */
                                       {
                               /* State DOXY_ENTRY - exit_action empty */
                               /* Transition from DOXY_ENTRY to DOXY_BUF1 actions */
                               { appendBuf(evt); }
                               /* State DOXY_BUF1 - entry_action empty */
                            this->curState = ST_doxyBuf1;
                           }
                     break;
               };
            return this->curState;
           }

    protected:  
        virtual
        int
        multi
             ( const ::doxy::CDoxyEvent  evt         
             )
           {
            /* guard variable - evt.doxyType */
            switch(this->curState)
               {
                case ST_doxyBuf1:    /* ADoxer:DOXY_BUF1 */
                                       {
                               /* State DOXY_BUF1 - exit_action empty */
                               /* Transition from DOXY_BUF1 to DOXY_BUF2 actions */
                               { appendBuf(evt); }
                               /* State DOXY_BUF2 - entry_action empty */
                            this->curState = ST_doxyBuf2;
                           }
                     break;
                case ST_doxyBuf2:    /* ADoxer:DOXY_BUF2 */
                           {
                               /* Transition from DOXY_BUF2 to DOXY_BUF2 actions */
                            this->curState = ST_doxyBuf2;
                           }
                     break;
                case ST_doxyEntry:    /* ADoxer:DOXY_ENTRY */
                                       {
                               /* State DOXY_ENTRY - exit_action empty */
                               /* Transition from DOXY_ENTRY to DOXY_BUF1 actions */
                               { appendBuf(evt); }
                               /* State DOXY_BUF1 - entry_action empty */
                            this->curState = ST_doxyBuf1;
                           }
                     break;
               };
            return this->curState;
           }

    public:     
        virtual
        int
        flush
             ( 
             )
           {
            /* there is no guard variable */
            switch(this->curState)
               {
                case ST_doxyBuf1:    /* ADoxer:DOXY_BUF1 */
                                       {
                               /* State DOXY_BUF1 - exit_action empty */
                               /* Transition from DOXY_BUF1 to DOXY_ENTRY actions */
                               /* State DOXY_ENTRY - entry_action empty */
                            this->curState = ST_doxyEntry;
                           }
                     break;
                case ST_doxyBuf2:    /* ADoxer:DOXY_BUF2 */
                           {
                               /* Transition from DOXY_BUF2 to DOXY_BUF2 actions */
                            this->curState = ST_doxyBuf2;
                           }
                     break;
                case ST_doxyEntry:    /* ADoxer:DOXY_ENTRY */
                                       {
                               /* State DOXY_ENTRY - exit_action empty */
                               /* Transition from DOXY_ENTRY to DOXY_ENTRY actions */
                               { parseDoxyBuf(); }
                               /* State DOXY_ENTRY - entry_action empty */
                            this->curState = ST_doxyEntry;
                           }
                     break;
               };
            return this->curState;
           }

    public:     
        virtual
        int
        lf
          ( 
          )
           {
            /* there is no guard variable */
            switch(this->curState)
               {
                case ST_doxyBuf1:    /* ADoxer:DOXY_BUF1 */
                           {
                               /* Transition from DOXY_BUF1 to DOXY_BUF1 actions */
                            this->curState = ST_doxyBuf1;
                           }
                     break;
                case ST_doxyBuf2:    /* ADoxer:DOXY_BUF2 */
                           {
                               /* Transition from DOXY_BUF2 to DOXY_BUF2 actions */
                            this->curState = ST_doxyBuf2;
                           }
                     break;
                case ST_doxyEntry:    /* ADoxer:DOXY_ENTRY */
                                       {
                               /* State DOXY_ENTRY - exit_action empty */
                               /* Transition from DOXY_ENTRY to DOXY_ENTRY actions */
                               /* State DOXY_ENTRY - entry_action empty */
                            this->curState = ST_doxyEntry;
                           }
                     break;
               };
            return this->curState;
           }

    public:     
        void
        setObjName
                  ( const ::std::string  cur         
                  , const ::std::string  prev        
                  )
           {
            curObj = cur; prevObj = prev;
            flush(); // process buffered doxy's
           }

    protected:  
        virtual
        void
        parseDoxy
                 ( const int            flags        //!< after flag, allow javadoc flag etc
                 , const ::std::string  brief       
                 , const ::std::string  detailed    
                 )
           {

           }

    protected:  
        virtual
        void
        parseDoxyBuf
                    ( 
                    )
           {
            buf.clear();
           }

    protected:  
        virtual
        void
        parseDoxyBufFirst
                         ( 
                         )
           {
            buf.clear();
           }

    protected:  
        void
        clear
             ( 
             )
           {
            buf.clear();
           }

    protected:  
        virtual
        void
        appendBuf
                 ( const ::doxy::CDoxyEvent  evt         
                 )
           {
            buf.push_back(evt);
           }

    protected:  
        virtual
        void
        appendLastEvent
                       ( const ::doxy::CDoxyEvent  evt         
                       )
           {
            buf.back().text.append(1,'\n');
            buf.back().text.append(evt.text);
            buf.back().doxyType |= DOXY_CTF_MULTISINGLELINE;
           }

    protected:  
        int
        styleEqual
                  ( const ::doxy::CDoxyEvent  evt         
                  )
           {
            return DOXY_TYPES_EQUAL(buf.back().doxyType,evt.doxyType) ? 1 : 0;
           }

    protected:  
        int
        fafterEqual
                   ( const ::doxy::CDoxyEvent  evt         
                   )
           {
            return DOXY_FAFTER_EQU(buf.back().doxyType,evt.doxyType) ? 1 : 0;
           }

    protected:  
        int
        isBufMS
               ( const int  n           
               )
           {
            buf[n].isMS();
           }

    protected:  
        int
        isBufS
              ( const int  n           
              )
           {
            buf[n].isS();
           }

    protected:  
        int
        isBufM
              ( const int  n           
              )
           {
            buf[n].isM();
           }

    public:     
        int
        getCurState
                   ( 
                   ) const
           {
            return this->curState;
           }

    public:     
        int
        isInFinalState
                      ( 
                      ) const
           {
            return (this->curState & ST_intStatefinalmask) ? 1 : 0;
           }

    protected:  
        virtual
        void
        customResetAutomata
                           ( 
                           )
           {
            return;
           }

    public:     
        void
        resetAutomata
                     ( 
                     )
           {
            this->customResetAutomata(  );
            this->curState = ST_doxyEntry;
           }

    public:     
        int
        isInInadmissibleFinalState
                                  ( 
                                  )
           {
            return 0;
           }


};


}; // namespace cidl {

#endif /* DOXER_ADOXER_AUTOMATA_H */
