/* Warning! Automaticaly generated file, do not edit */

#include <stack>
#include "cidl_ACidlParser_Automata.h"


#ifndef CIDL_CCIDLPARSER_LOGGING_USED
#define CIDL_CCIDLPARSER_LOGGING_USED
#endif

#ifndef CIDL_CCIDLPARSER_TRANSITION_COVERAGE_USED
#define CIDL_CCIDLPARSER_TRANSITION_COVERAGE_USED
#endif

#ifndef CIDL_CCIDLPARSER_STACK_USED
#define CIDL_CCIDLPARSER_STACK_USED
#endif

#ifndef CIDL_CCIDLPARSER_NO_OVERFLOW_CALLS
#define CIDL_CCIDLPARSER_NO_OVERFLOW_CALLS
#endif




namespace cidl {



}; // namespace cidl {

