/*
#if !defined(MBS_PROJECT_NAME)
    #if defined(PROJECT_NAME)
        #define MBS_PROJECT_NAME PROJECT_NAME
    #endif
#endif
*/


#ifndef CLI_INET_ISOCK_H
    #include <cli/inet/isock.h>
#endif

#ifndef CLI_INET_IRESOLV_H
    #include <cli/inet/iResolv.h>
#endif

#include <cli/clicmdline.h>

#include <cli/cliutilx.h>

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#include <marty/utf.h>

#ifndef CLI_CLI2X_H
    #include <cli/cli2x.h>
#endif

#ifndef CLI_DISPIMPLHLP_H
    #include <cli/dispimplhlp.h>
#endif

#ifndef CLI_MISC_READUTILS_H
    #include <cli/misc/readutils.h>
#endif

#ifndef CLI_MISC_WRITEUTILS_H
    #include <cli/misc/writeutils.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif


#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#ifndef SRC_CIDL_ENUMS_H
    #include "enums.h"
#endif


inline
std::ostream& operator<<(std::ostream& os, const std::wstring &str)
   {
    //os<< MARTY_UTF_NS toUtf8( str );
    os<<MARTY_CON_NS str2con(str);
    return os;
   }

inline
std::ostream& operator<<(std::ostream& os, const WCHAR* &str)
   {
    os<<MARTY_CON_NS str2con(str);
    return os;
   }

using ::cli::cmd_line::optFlag;
using ::cli::cmd_line::optRequiredOption;
using ::cli::cmd_line::optValueOptional;
using ::cli::cmd_line::optValueRequired;


::cidl::CEnumGen enumGen; // global common

std::wstring outputFileName;

UINT nameCounter = 0;


//std::map< std::string, UINT, >  names;

#define OUTPUT_TYPE_PROPMAP   0
#define OUTPUT_TYPE_PROPDEFS  1
#define OUTPUT_TYPE_METHMAP   2
#define OUTPUT_TYPE_METHDEFS  3
#define OUTPUT_TYPE_IFMAP     4
#define OUTPUT_TYPE_IFDEFS    5
#define OUTPUT_TYPE_ENUMMAP     6
#define OUTPUT_TYPE_ENUMDEFS    7

std::wstring  implName = L"common";
std::wstring  ifName;

int outputType = -1;

bool generateName2IdMapOnly = false;

::cli::cmd_line::COptDescription programmCmdOpts[] = 
{ { L'h'                       , L"help"        , optFlag, 0, L"print this help string." }
, { L'V'                       , L"version"     , optFlag, 0, L"print program version number." }
, { CLI_GETOPT_WHERE_CMDID     , L"where"       , optFlag, 0, L"print program path and executable file name." }
, { CLI_GETOPT_WHERE_CMDID     , L"where-is"    , optFlag, 0, L"same as '--where'." }
, { CLI_GETOPT_WHERE_CMDID     , L"where-is-it" , optFlag, 0, L"same as '--where'." }
, { L'T'                       , L"output-type" , optRequiredOption|optValueRequired, L"type", L"Set the output type, can be one of next values: propmap, propdefs, methmap, methdefs, ifmap, ifdefs, enummap, enumdefs" }
, { L'o'                       , L"output"      , optValueRequired, L"name" , L"Set output file name" }
, { L'a'                       , L"add-name"    , optValueRequired, L"name" , L"Add value to names (property/interface list)" }
, { L'm'                       , L"implementation-name"   , optRequiredOption|optValueRequired, L"name" , L"Set the name of implementation. Default value 'common' valid only for 'methmap', 'methdefs' output types." }
, { L'i'                       , L"interface-name", optValueRequired, L"name" , L"Set the name of interface (required for prop|method maps)" }
, { L'L'                       , L"name-map-only", optFlag, 0 , L"Generate name-to-id map only, don't generate specialized maps" }

//, { L't'                       , L"disable-text-output", optFlag, 0  , L"Disable printing receiving data in text form." }
//, { L'd'                       , L"disable-dump-output", optFlag, 0  , L"Disable printing receiving data in hexadecimal dump form." }
, { 0, 0, 0, 0 }
};




inline
RCODE readLinesFromFile( const std::wstring &fileName, std::vector< std::string > &lines)
{
    ::std::string inputData;
    RCODE rc = cli::misc::utils::readFile( fileName, inputData );
    if (rc) 
       return rc;

    ::cli::util::splitString( inputData, lines, ::cli::util::CIsLinefeed<char>() );
    //::cli::util::trim(lines, ::cli::util::CIsSpace<char>());
    return EC_OK;
}



inline
RCODE parseAddNames( std::vector< std::string > &lines, bool ignoreIds, ::cidl::CEnumGen &eg)
{
    std::vector< std::string >::const_iterator lit = lines.begin();
    for(; lit!=lines.end(); ++lit)
       {
        ::std::string line = *lit;
        ::cli::util::trim(line, ::cli::util::CIsSpace<char>());
        if (line.empty()) 
           continue;
        if (line[0]=='#' || line[0]==';')
           continue;
        eg.addName( line,ignoreIds );
       }
    return EC_OK;
}

inline
RCODE parseAddNames( std::vector< std::string > &lines, bool ignoreIds )
{
    return parseAddNames( lines, ignoreIds, enumGen);
}






struct COptionHandler : public ::cli::cmd_line::COptionHandlerBase
{
    RCODE operator()( const ::cli::cmd_line::CGetoptContext &ctx
                   , wchar_t                optSelector
                   , const ::cli::cmd_line::COptDescription *pOptInfo
                   , ::cli::CArgList        argList
                   ) const
      {      
       //CArgList argList(_argList);

       switch(optSelector)
          {
           case    0: {
                       std::wstring fileName;
                       argList.getString( ctx.valueIndex, fileName);
                       std::vector< std::string > lines;
                       RCODE rc = readLinesFromFile( fileName, lines );
                       if (rc) 
                          return rc;
                       parseAddNames( lines, !(outputType == OUTPUT_TYPE_ENUMMAP || outputType == OUTPUT_TYPE_ENUMDEFS) );
                      }
                      break;

           case L'o': {
                       argList.getString( ctx.valueIndex, outputFileName);
                      }
                      break;

           case L'T': {
                       std::wstring strType;
                       argList.getString( ctx.valueIndex, strType);

                       ::cli::util::plainToLowerCase( strType );
                       if (strType==L"propmap")
                         outputType = OUTPUT_TYPE_PROPMAP;
                       else if (strType==L"propdefs")
                         outputType = OUTPUT_TYPE_PROPDEFS;
                       else if (strType==L"methmap")
                         outputType = OUTPUT_TYPE_METHMAP;
                       else if (strType==L"methdefs")
                         outputType = OUTPUT_TYPE_METHDEFS;
                       else if (strType==L"ifmap")
                         outputType = OUTPUT_TYPE_IFMAP;
                       else if (strType==L"ifdefs")
                         outputType = OUTPUT_TYPE_IFDEFS;
                       else if (strType==L"enummap")
                         outputType = OUTPUT_TYPE_ENUMMAP;
                       else if (strType==L"enumdefs")
                         outputType = OUTPUT_TYPE_ENUMDEFS;
                       else
                          return EC_COMMAND_LINE_BAD_OPTION_VALUE;
                      }
                      break;

           case L'a': {
                       std::wstring nameAndAliases;
                       argList.getString( ctx.valueIndex, nameAndAliases);
                       enumGen.addName( MARTY_UTF::toUtf8( nameAndAliases ), !(outputType == OUTPUT_TYPE_ENUMMAP || outputType == OUTPUT_TYPE_ENUMDEFS) );
                      }
                      break;

           case L'm': {
                       argList.getString( ctx.valueIndex, implName);
                      }
                      break;

           case L'i': {
                       argList.getString( ctx.valueIndex, ifName);
                      }
                      break;

           case L'L': {
                       generateName2IdMapOnly = true;
                      }
                      break;

           default  : return ::cli::cmd_line::COptionHandlerBase::operator()( ctx, optSelector, pOptInfo, argList );
          }
       return EC_OK;
      }
}; // struct COptionHandler


inline
void printVal( UINT i )
{
    std::cout<<"uint: "<<i<<"\n";
}

inline
void printVal( DWORD i )
{
    std::cout<<"dword: "<<i<<"\n";
}


void testParseNameParamPair( const std::string & str )
{
    std::string name, val;
    std::vector<std::string> indices;
    if (!::cli::disp::impl::parseNameParamPair( str, name, val, indices ))
       {
        std::cout<<"Failed to parse: "<<str<<"\n";
       }
    else
       {
        std::cout<<"Input: "<<str<<"\n"<<"Name : "<<name<<"\n";
        if (!indices.empty())
           std::cout<<"Indexes: ";
        std::vector<std::string>::const_iterator it = indices.begin();
        for(; it != indices.end(); ++it)
           {
            std::cout<<*it<<", ";
           }
        if (!indices.empty())
           std::cout<<"\n";
        std::cout<<"Value: "<<val<<"\n\n";
       }
}







CLI_MAIN( /* argList */ ) // argList - command line arguments
   {
/*
    DWORD dw = 3;
    UINT  ui = 5;
    printVal(dw);
    printVal(ui);



    testParseNameParamPair( std::string("") );
    testParseNameParamPair( std::string("name val") );
    testParseNameParamPair( std::string("name [1]val") );
    testParseNameParamPair( std::string("name [1] val") );
    testParseNameParamPair( std::string("name") );
    testParseNameParamPair( std::string("name=val") );
    testParseNameParamPair( std::string(" name = val ") );
    testParseNameParamPair( std::string("name[1] = val") );
    testParseNameParamPair( std::string("name[1 = val") );
    testParseNameParamPair( std::string("name[1][\"2\"] = val") );
    testParseNameParamPair( std::string("name[1][\"2\"] val") );
    testParseNameParamPair( std::string("name[1][\"=2\"] = val") );
    testParseNameParamPair( std::string("name[1][\"=2\"] val") );
    testParseNameParamPair( std::string("name[1]=[\"=2\"] = val") );
    testParseNameParamPair( std::string("name[1][\"]2\"] = val") );
*/

    ::cli::cmd_line::CGetoptContext getoptContext( MARTY_CON::strToWide(MBS_PROJECT_NAME) // (MBS_PROJECT_NAME)
                                                 , L""
                                                 , L"mkdisptbl"
                                                 , L"mkdisptbl 1.0" // MARTY_CON::strToWide(MBS_PROJECT_NAME)
                                                 );
    getoptContext.pOs    = & ::std::cout;
    getoptContext.pOsErr = & ::std::cerr;

    RCODE rcRes;
    if ( (rcRes = ::cli::cmd_line::getoptParse( argList, programmCmdOpts, getoptContext, COptionHandler(), ::cli::cmd_line::gfAllowLongOptAliases ) )
         != EC_OK
       )
       {
        return rcRes; // EC_COMMAND_LINE_PARSING_STOPPED;
       }

    if (outputType<0)
       return EC_COMMAND_LINE_MISSING_MANDATORY_OPTIONS;

    if (implName.empty()) // always required
       return EC_COMMAND_LINE_MISSING_MANDATORY_OPTIONS;

    if ((outputType<OUTPUT_TYPE_IFMAP) && ifName.empty())
       return EC_COMMAND_LINE_MISSING_MANDATORY_OPTIONS;

    std::wstring implNameLower = implName;
    ::cli::util::plainToLowerCase( implNameLower );
    bool bCommon = (implNameLower==L"common");

    bool bMeth = (outputType>=OUTPUT_TYPE_METHMAP && outputType<=OUTPUT_TYPE_METHDEFS);
    bool bEnum = (outputType>=OUTPUT_TYPE_ENUMMAP && outputType<=OUTPUT_TYPE_ENUMDEFS);

    if (bCommon && !(bMeth||bEnum) )
       {
        return EC_COMMAND_LINE_BAD_OPTION_VALUE;
       }


/*
#define OUTPUT_TYPE_PROPMAP   0
#define OUTPUT_TYPE_PROPDEFS  1
#define OUTPUT_TYPE_METHMAP   2
#define OUTPUT_TYPE_METHDEFS  3
#define OUTPUT_TYPE_IFMAP     4
#define OUTPUT_TYPE_IFDEFS    5

std::wstring  implName = L"common";
std::wstring  ifName;
*/

    ::cidl::CEnumGen eg = enumGen.getFinalMap();

    std::string resStr;

    switch(outputType)
       {
        case OUTPUT_TYPE_PROPMAP:
             {
              resStr = ::cidl::generateName2IdMap( eg
                                                 , ifName
                                                 , implName
                                                 , "propmap" //propOrMethOrIfMap
                                                 , "prop_id"
                                                 );
             }
             break;
        case OUTPUT_TYPE_PROPDEFS:
             {
              resStr = ::cidl::generateDefines( eg
                                              , ifName
                                              , implName
                                              , "propmap" //propOrMethOrIfMap
                                              , "prop_id"
                                              , bCommon
                                              );
             }
             break;
        case OUTPUT_TYPE_METHMAP:
             {
              resStr = ::cidl::generateName2IdMap( eg
                                                 , ifName
                                                 , implName
                                                 , "methmap" //propOrMethOrIfMap
                                                 , "meth_id"
                                                 );
             }
             break;
        case OUTPUT_TYPE_METHDEFS:
             {
              resStr = ::cidl::generateDefines( eg
                                              , ifName
                                              , implName
                                              , "methmap" //propOrMethOrIfMap
                                              , "meth_id"
                                              , bCommon
                                              );
             }
             break;
        case OUTPUT_TYPE_IFMAP:
             {
              resStr = ::cidl::generateName2IdMap( eg
                                                 , std::wstring() //ifName
                                                 , implName
                                                 , "ifmap" //propOrMethOrIfMap
                                                 , "if_id"
                                                 , generateName2IdMapOnly ? "BEGIN_CLI_DISP_DYN_INTERFACE_MAP" : "BEGIN_CLI_DISP_IMPL_NAME2ID_MAP"
                                                 , generateName2IdMapOnly ? "END_CLI_DISP_DYN_INTERFACE_MAP"   : "END_CLI_DISP_IMPL_NAME2ID_MAP"
                                                 );
             }
             break;
        case OUTPUT_TYPE_IFDEFS:
             {
              resStr = ::cidl::generateDefines( eg
                                              , std::wstring() //ifName
                                              , implName
                                              , "ifmap" //propOrMethOrIfMap
                                              , "if_id"
                                              , false
                                              );
             }
             break;
        case OUTPUT_TYPE_ENUMMAP:
             {
              resStr = ::cidl::generateName2IdMap( eg
                                              , std::wstring() //ifName
                                              , implName
                                              , "enummap" //propOrMethOrIfMap
                                              , "enum_id"
                                              );
             }
             break;
        case OUTPUT_TYPE_ENUMDEFS:
             {
              resStr = ::cidl::generateDefines( eg
                                              , std::wstring() //ifName
                                              , implName
                                              , "enummap" //propOrMethOrIfMap
                                              , "enum_id"
                                              , false
                                              );
             }
             break;

       }


    if (outputFileName.empty())
       {
        std::cout<<resStr;
       }
    else
       {
        std::string tmp;
        std::string::size_type pos = 0, size = resStr.size();
        tmp.reserve(size);
        for(; pos!=size; ++pos)
           {
            if (resStr[pos]=='\n')
               tmp.append(1, '\r');
            tmp.append(1, resStr[pos]);
           }
        return cli::misc::utils::writeFile( outputFileName, tmp );
       }

    return 0;
   }

