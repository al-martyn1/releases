#ifndef SRC_CIDL_DOXY_H
#define SRC_CIDL_DOXY_H


#ifndef DOXY_DOXY_H
    #include "../doxy/doxy.h"
#endif

#ifdef CIDL_CCIDLPARSER_LOGGING_USED
    #if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
        #include <iostream>
    #endif

#endif // CIDL_CCIDLPARSER_LOGGING_USED


#ifdef CIDL_CCIDLPARSER_LOGGING_USED
inline
::std::ostream& operator<<(::std::ostream& os, const ::doxy::CDoxyCommentItem &i)
   {
    if (!i.type) // not a doxy tag
       {
        os<<i.text;
       }
    else if (i.type==DT_LINEFEED)
       {
        os<<"\\n";
       }
    else
       {
        os<<i.text<<" ("<<i.type<<")";
        ::std::vector< ::std::string >::const_iterator pit = i.params.begin();
        for(; pit!=i.params.end(); ++pit)
           {
            //if (pit!=i.params.begin())
            os<<" "<<*pit;
           }
       }
    return os;
   }

inline
::std::ostream& operator<<(::std::ostream& os, const ::std::vector< ::doxy::CDoxyCommentItem > &i)
   {
    ::std::vector< ::doxy::CDoxyCommentItem >::const_iterator it = i.begin();
    for(; it!=i.end(); ++it)
       os<<*it<<"\n";
    return os;
   }
#endif // CIDL_CCIDLPARSER_LOGGING_USED




#endif /* SRC_CIDL_DOXY_H */

