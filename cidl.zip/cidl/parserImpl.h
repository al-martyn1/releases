#ifndef PARSERIMPL_H
#define PARSERIMPL_H

#include "cidl_ACidlParser_Automata.h"

namespace cidl
{


#ifdef __cplusplus


template <typename TSC> // TSCanner
void registerCidlKeywords(TSC &sc)
   {

    sc.addCustomKeyword("namespace", CK_NAMESPACE );
    sc.addCustomKeyword("interface", CK_INTERFACE );
    sc.addCustomKeyword("extends"  , CK_EXTENDS   );
    sc.addCustomKeyword("implements", CK_IMPLEMENTS);
    sc.addCustomKeyword("template" , CK_TEMPLATE );

    sc.addCustomKeyword("property" , CK_PROPERTY  );
    sc.addCustomKeyword("in"       , CK_IN        );
    //sc.addCustomKeyword("In"       , CK_IN        );
    //sc.addCustomKeyword("IN"       , CK_IN        );
    sc.addCustomKeyword("out"      , CK_OUT       );
    //sc.addCustomKeyword("Out"      , CK_OUT       );
    //sc.addCustomKeyword("OUT"      , CK_OUT       );
    sc.addCustomKeyword("get"      , CK_READ      );
    sc.addCustomKeyword("read"     , CK_READ      );
    sc.addCustomKeyword("set"      , CK_WRITE     );
    sc.addCustomKeyword("write"    , CK_WRITE     );
    sc.addCustomKeyword("nosizemethod", CK_NOSIZEMETHOD);
    sc.addCustomKeyword("nosize"   , CK_NOSIZEMETHOD);

    sc.addCustomKeyword("ref"      , CK_BY_REF    );
    sc.addCustomKeyword("flat"     , CK_FLAT      );
    sc.addCustomKeyword("optional" , CK_OPTIONAL  );
    
    
    sc.addCustomKeyword("suffix"   , CK_SUFFIX    );
    sc.addCustomKeyword("pack"     , CK_PACK      );
    sc.addCustomKeyword("enum"     , CK_ENUM      );
    sc.addCustomKeyword("pod"      , CK_POD       );
    sc.addCustomKeyword("struct"   , CK_STRUCT    );
    sc.addCustomKeyword("union"    , CK_UNION     );
    sc.addCustomKeyword("alias"    , CK_ALIAS     );
    sc.addCustomKeyword("cpp_include", CK_CPP_INCLUDE);
    sc.addCustomKeyword("cpp_option", CK_CPP_OPTION);
    sc.addCustomKeyword("cpp_define", CK_CPP_DEFINE);
    

    //sc.addCustomKeyword("size"     , CK_QUERY_SIZE);


    //sc.addCustomKeyword("Read"     , CK_READ      );
    //sc.addCustomKeyword("READ"     , CK_READ      );
    //sc.addCustomKeyword("Write"    , CK_WRITE     );
    //sc.addCustomKeyword("WRITE"    , CK_WRITE     );

    sc.addCustomKeyword("stdmethod", CK_STDMETHOD);
    sc.addCustomKeyword("vamethod" , CK_VAMETHOD);

    sc.addCustomKeyword("declare_pod_type", CK_DECLARE_POD_TYPE);

    

    //sc.addCustomKeyword("", );

   }

#endif


class CCidlParserImpl : public CCidlParser
{
    public:

        int
        putEvent
                ( const CScannerEvent &evt         
                );

    protected:

        #ifdef CIDL_CCIDLPARSER_LOGGING_USED
        void
        logEvent( int         eventTypeCode //!< 0x0100 - event info flag, 0x0200 - action info flag, 0 - event message, 1 - event message on inadmissible event, 0x0101 - from, 0x0102 - to, 0x0103 - event, 0x0104 - quard, 0x0201 - entry action, 0x0202 - trigger action, 0x0203 - do action, 0x0204 - exit action
                , int         fromState    //!< transition start state, can be used for event filtration
                , int         toState      //!< transition end state, can be used for event filtration
                , const char *eventMsg     //!< from/to state name, event name, guard condition, entry/trigger/do/exit action text or info message
                );
        #endif /* NMDL_CNMDLPARSER_LOGGING_USED */

        void
        customResetAutomata( );

        void
        processComment
                      ( const CScannerEvent &evt
                      );

        void
        popObjPath
                  ( 
                  );

        void
        setObjPath
                  ( const ::std::string  ot           //!< objType
                  , const ::std::string  on           //!< objName
                  );



};


}; // namespace cidl

#endif /* PARSERIMPL_H */

