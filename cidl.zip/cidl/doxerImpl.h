#ifndef CIDL_DOXERIMPL_H
#define CIDL_DOXERIMPL_H

//#include "doxer_ADoxer_Automata.h"

#include <cli/cli2types.h>

#include <string>
#include <map>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <set>
#include <map>
#include <vector>
#include <stack>
#include <string>
#include <cidl/cidl.h>
#include "../doxy/doxy.h"


namespace cidl
{

class CDoxerImpl;

struct CDoxerNamesChanhedNotifier
{
    CDoxerImpl    *pDoxer;
    CDoxerNamesChanhedNotifier(CDoxerImpl *pd) : pDoxer(pd) {}
    CDoxerNamesChanhedNotifier(const CDoxerNamesChanhedNotifier &pd) : pDoxer(pd.pDoxer) {}
    CDoxerNamesChanhedNotifier& operator=(const CDoxerNamesChanhedNotifier &pd)
       {
        if (&pd==this) return *this;
        pDoxer = pd.pDoxer;
        return *this;
       }

    void operator()();

};

/*
template <typename TNotifyObj>
class CObjectNames
*/


#if defined(_MSC_VER)
    #pragma warning( push )
    #pragma warning( disable : 4355 ) // 'this' : used in base member initializer list
#endif

class CDoxerImpl// : public CDoxer
{

    //protected:  ::std::string        curObj      ;
    //protected:  ::std::string        prevObj     ;
    protected:  ::std::vector< ::doxy::CDoxyEvent > buf         ;
    protected:  int                  lfCount     ;

    public:     

        std::map< ::std::string, ::std::string>    doxyAliasises;
        std::set< ::std::string>                   enabledSections;
        bool                                       autoBrief;

        ::doxy::CDoxydoc                           documentation;

    public:     

        ::doxy::CDoxydoc& getDoc() { return documentation; }
        const ::doxy::CDoxydoc& getDoc() const { return documentation; }

        ::cidl::CObjectNames<CDoxerNamesChanhedNotifier>   objNames;

        CDoxerImpl()
           //: curObj()
           //, prevObj()
           : buf()
           , lfCount(0)
           , doxyAliasises()
           , enabledSections()
           , autoBrief(false)
           , documentation()
           , objNames(CDoxerNamesChanhedNotifier(this))
           {}

        void
        resetAutomata
                     ( 
                     )
           {
            //curObj   = prevObj = ::std::string();
            lfCount  = 0;
            buf.clear();
           }

        void namesChangedNotification()
           {
            flush();
           }

        /*
        void
        setObjName
                  ( const ::std::string  cur         
                  , const ::std::string  prev        
                  )
           {
            curObj = cur; prevObj = prev;
            flush(); // process buffered doxy's
           }
        */

    protected:  

        int internalLf();

    public:     

        int lf ( ) { lfCount++; if (lfCount==2) internalLf(); return 0; }

        int flush ( );

    protected:  

        int multi ( const ::doxy::CDoxyEvent  &evt );
        int single ( const ::doxy::CDoxyEvent  &evt );

    public:     

        int doxy ( const ::doxy::CDoxyEvent  &evt )
           {
            if (evt.getType()==DOXY_CT_JAVADOC) return multi(evt); // javaDoc, only multi line
            if (evt.getType()==DOXY_CT_DOXYGEN) return single(evt); // doxyCpp, only single line
            if (evt.getType()==DOXY_CT_QTDOC)
               {
                if (evt.doxyType&DOXY_CTF_SINGLELINE) return single(evt); // qtSingle
                else                                  return multi(evt);  // qtMulti
               }
            return 0;
           }

    protected:  
        void
        parseDoxy
                 ( const int            flags        //!< after flag, allow javadoc flag etc
                 , const ::std::string  brief       
                 , const ::std::string  detailed    
                 );

        void parseDoxyBuf ( );
        void parseDoxyBufFirst ( );
        void appendBuf ( const ::doxy::CDoxyEvent  evt )
           {
            buf.push_back(evt);
           }

        void appendLastEvent ( const ::doxy::CDoxyEvent  evt )
           {
            buf.back().text.append(1,'\n');
            buf.back().text.append(evt.text);
            buf.back().doxyType |= DOXY_CTF_MULTISINGLELINE;
           }


    public:

    protected:

        /*
        #ifdef CIDL_CDOXER_LOGGING_USED
        void
        logEvent( int         eventTypeCode //!< 0x0100 - event info flag, 0x0200 - action info flag, 0 - event message, 1 - event message on inadmissible event, 0x0101 - from, 0x0102 - to, 0x0103 - event, 0x0104 - quard, 0x0201 - entry action, 0x0202 - trigger action, 0x0203 - do action, 0x0204 - exit action
                , int         fromState    //!< transition start state, can be used for event filtration
                , int         toState      //!< transition end state, can be used for event filtration
                , const char *eventMsg     //!< from/to state name, event name, guard condition, entry/trigger/do/exit action text or info message
                );
        #endif // CIDL_CDOXER_LOGGING_USED 

        void
        customResetAutomata( );

        void
        parseDoxy
                 ( const int            flags
                 , const ::std::string  brief       
                 , const ::std::string  detailed    
                 );

        void
        parseDoxyBuf
                    ( 
                    );

        */
};


#if defined(_MSC_VER)
    #pragma warning( pop )
#endif


inline
void CDoxerNamesChanhedNotifier::operator()()
   {
    pDoxer->namesChangedNotification();
   }


}; // namespace cidl

#endif /* CIDL_DOXERIMPL_H */

