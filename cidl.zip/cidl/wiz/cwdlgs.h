#ifndef SRC_CIDL_WIZ_CWDLGS_H
#define SRC_CIDL_WIZ_CWDLGS_H

#ifndef STRICT
#define STRICT
#endif


// ATL related preprocessor definitions
#if (_ATL_VER >= 0x0700)
    #define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS  // some CString constructors will be explicit
    #define _ATL_USE_CSTRING_FLOAT
    #define _ATL_USE_DDX_FLOAT
    #define _ATL_NO_OLD_NAMES
    #define _ATL_DISABLE_DEPRECATED
    #define _ATL_ALL_WARNINGS
    #define _ATL_NO_OLD_HEADERS_WIN64
#endif

#include <atlbase.h>
#if (_ATL_VER >= 0x0700)
    #include <atlstr.h>
    #include <atltypes.h>
#endif

// WTL related preprocessor definitions
#if (_ATL_VER >= 0x0700)
    #define _WTL_NO_WTYPES
    #define _WTL_NO_UNION_CLASSES
    #define _WTL_NO_CSTRING
#endif
#define _WTL_NEW_PAGE_NOTIFY_HANDLERS

#include <atlapp.h>
extern CAppModule _Module;

#include <atlwin.h>
#include <atlcom.h>

#include <shellapi.h>



#include <atlmisc.h>
#include <atlctl.h>
#include <atlframe.h>
#include <atlddx.h>
#include <atldlgs.h>
#include <atlctrls.h>
#include <atlctrlw.h>
#include <atlctrlx.h>
#include <atlscrl.h>


#include <marty/winapi.h>


//-----------------------------------------------------------------------------
class CComponentWizardWelcomePage
      : public CWizard97ExteriorPageImpl<CComponentWizardWelcomePage>
      //, public CTestWizardInfoRef
{
protected:
// Typedefs
    typedef CComponentWizardWelcomePage                            thisClass;
    typedef CWizard97ExteriorPageImpl<CComponentWizardWelcomePage> baseClass;

// Data members
//    CButton m_buttonSkipWelcome;
//    bool m_allowWelcomeToHide;

    CComponentWizardInfo *pInfo;

public:

    void setInfo( CComponentWizardInfo *pi ) { pInfo = pi; }

public:
// Constructors
    CComponentWizardWelcomePage(_U_STRINGorID title = (LPCTSTR)NULL)
       : baseClass(title)
       //, m_allowWelcomeToHide(true)
    { }

// Message Handlers
    enum { IDD = IDD_COMPOWIZ_WELCOME };
    BEGIN_MSG_MAP(thisClass)
        MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
        CHAIN_MSG_MAP(baseClass)
    END_MSG_MAP()

    LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
       {
        CFontHandle fontExteriorPageTitleFont(baseClass::GetExteriorPageTitleFont());
        CFontHandle fontBulletFont(baseClass::GetBulletFont());
    
        CWindow title = this->GetDlgItem(IDC_COMPOWIZ_EXTERIOR_TITLE);
        CWindow bullet1 = this->GetDlgItem(IDC_COMPOWIZ_BULLET1);
        CWindow bullet2 = this->GetDlgItem(IDC_COMPOWIZ_BULLET2);
        CWindow bullet3 = this->GetDlgItem(IDC_COMPOWIZ_BULLET3);
        //CWindow bullet4 = this->GetDlgItem(IDC_COMPOWIZ_BULLET4);
        //m_buttonSkipWelcome = this->GetDlgItem(IDC_COMPOWIZ_WELCOME_NOTAGAIN);
    
        title.SetFont(fontExteriorPageTitleFont);
        bullet1.SetFont(fontBulletFont);
        bullet2.SetFont(fontBulletFont);
        bullet3.SetFont(fontBulletFont);
        //bullet4.SetFont(fontBulletFont);
       
        return 1;
       }

// Helper methods
    //void InitializeControls(void);
    //void InitializeValues(void);
    //bool StoreValues(void);

// Overrides from base class
    int OnSetActive()
       {
        this->SetWizardButtons(PSWIZB_NEXT);
        // 0 = allow activate
        // -1 = go back to page that was active
        // page ID = jump to page
        int result = 0;
        return result;

       }

    int OnWizardNext()
       {
        // 0  = goto next page
        // -1 = prevent page change
        // >0 = jump to page by dlg ID
        return pInfo->getNextPage(IDD);
       }

    void OnHelp()
       {
       }
};


//-----------------------------------------------------------------------------
class CComponentWizardSelectInterfacesPage
      : public CWizard97InteriorPageImpl<CComponentWizardSelectInterfacesPage>
      //, public CTestWizardInfoRef
{
protected:
// Typedefs
    typedef CComponentWizardSelectInterfacesPage                            thisClass;
    typedef CWizard97InteriorPageImpl<CComponentWizardSelectInterfacesPage> baseClass;

    CComponentWizardInfo *pInfo;
    CListBox              interfaceList;
    DWORD                 prevButtons;

public:

    void setInfo( CComponentWizardInfo *pi ) { pInfo = pi; }

public:
// Constructor
    CComponentWizardSelectInterfacesPage(_U_STRINGorID title = (LPCTSTR)NULL)
        : baseClass(title)
        , prevButtons(0)
    {
        baseClass::SetHeaderTitle(_T("Select interfaces"));
        baseClass::SetHeaderSubTitle(_T("Select interfaces to be implemented by component"));
        //baseClass::SetHeaderSubTitle(_T("Select the path and filter identifying a list of files."));
    }

    enum { IDD = IDD_COMPOWIZ_INTERFACES_LIST };
    BEGIN_MSG_MAP(thisClass)
        MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
        MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
        COMMAND_ID_HANDLER(IDC_LIST_INTERFACES  , OnListEvent)
        //COMMAND_HANDLER(IDC_RADIO_FILTER_ALL, BN_CLICKED, OnClickFilterAll)
        //COMMAND_HANDLER(IDC_RADIO_FILTER_CUSTOM, BN_CLICKED, OnClickFilterCustom)
        //COMMAND_HANDLER(IDC_BTN_BROWSEPATH, BN_CLICKED, OnClickBrowsePath)
        CHAIN_MSG_MAP(baseClass)
    END_MSG_MAP()


    void setButtons(bool updateForce = false)
       {
        DWORD buttons = PSWIZB_BACK;
        if (!pInfo->selectedInterfaceIndexes.empty())
           buttons |= PSWIZB_NEXT;
        if (prevButtons!=buttons || updateForce)
           this->SetWizardButtons(buttons);
        prevButtons = buttons;
       }

    void buildSelectedInterfaceListAndLabelText()
       {
        int totalListItems = interfaceList.GetCount();
        int i = 0;
        tstring strLabel;
        pInfo->selectedInterfaceIndexes.clear();
        for(; i!=totalListItems; ++i)
           {
            int sel = interfaceList.GetSel( i );
            if (sel)
               {
                //if (!strLabel.empty())
                //   strLabel.append(_T("; "));
                strLabel.append(pInfo->allInterfaces[i]);
                strLabel.append(_T("; "));
                pInfo->selectedInterfaceIndexes.push_back(i);
               }
           }
        CWindow lbl = GetDlgItem(IDC_LABEL_INTERFACES);
        lbl.SetWindowText( strLabel.c_str() );
       }

    LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
       {
        CWaitCursor waitCursor;

        interfaceList = GetDlgItem(IDC_LIST_INTERFACES);

        ::std::vector<::std::string>::const_iterator aiIt = pInfo->allInterfaces.begin();
        for(; aiIt!=pInfo->allInterfaces.end(); ++aiIt)
           {
            //if (aiIt==pInfo->allInterfaces.begin()) interfaceList.SetCurSel( aiIt - pInfo->allInterfaces.begin() );
            interfaceList.AddString( aiIt->c_str() );
           }

        //int totalListItems = interfaceList.GetCount();
        ::std::vector< size_t >::const_iterator siIt = pInfo->selectedInterfaceIndexes.begin();
        for(; siIt!=pInfo->selectedInterfaceIndexes.end(); ++siIt )
           {
            //if (siIt==pInfo->selectedInterfaceIndexes.begin()) interfaceList.SetCurSel( *siIt );
            //if (siIt==pInfo->selectedInterfaceIndexes.begin()) interfaceList.SetAnchorIndex( *siIt );
            //if (siIt==pInfo->selectedInterfaceIndexes.begin()) interfaceList.SetCaretIndex( *siIt );
            //SetCaretIndex
            interfaceList.SetSel( *siIt, TRUE );
            //if (((int)*siIt) <totalListItems)
           }

        buildSelectedInterfaceListAndLabelText();

        if (!pInfo->selectedInterfaceIndexes.empty())
           interfaceList.SetCaretIndex(pInfo->selectedInterfaceIndexes[0]);
        else
           interfaceList.SetCaretIndex(0);
        //interfaceList.SetFocus();

        return 1;
       }

    LRESULT OnListEvent(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
       {
        //if (wNotifyCode==LBN_DBLCLK)
        buildSelectedInterfaceListAndLabelText();
        setButtons();
        int caretIdx = interfaceList.GetCaretIndex();
        //int totalListItems = interfaceList.interfaceList.GetCount();
        std::string description;

        //::std::string makeInterfacePath (const ::std::string &name)
        

        //CDoxydoc::description
        //CDoxydoc* getElementByName(const std::string &elName)
         /*     const CDoxydoc* pDoc = parserImpl.doxer.documentation.getElementByName("/test1/ISomeInterface");
    if (!pDoc)
       std::cout<<"Documentation for " */ 

        if (caretIdx>=0 && caretIdx<(int)pInfo->allInterfaces.size())
           {
            std::string duin = doxy::makeDuinFromIdent( cidl::pathNameToFqName(pInfo->allInterfaces[caretIdx]) );
            doxy::CDoxydoc* pDd = pInfo->doxyDoc.getElementByName(duin);
            if (pDd)
               {
                description = pDd->description.brief;
                if (description.empty()) description = pDd->description.detailed;
               }

            //cidl::CInterfaceInfo* pIf = pInfo->idl.findInterface(cidl::pathNameToFqName(pInfo->allInterfaces[caretIdx]));
            //if (pIf)
            //   {
            //    description = pIf->description.brief;
            //    if (description.empty()) description = pIf->description.detailed;
            //   }
           }
        CWindow lbl = GetDlgItem(IDC_LABEL_INTERFACE_DESC);
        lbl.SetWindowText( description.c_str() );
        return 0;
       }


    //IDC_LABEL_INTERFACES

    LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
       {
        bHandled = FALSE;
        //this->UninitializeControls();   
        return 0;
       }

    int OnSetActive()
       {
        //this->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);
        pInfo->checkOneOfIsIUnknown();
        setButtons(true);
        interfaceList.SetFocus();
        return 0;
       }
    
    int OnWizardNext()
       {
        return pInfo->getNextPage(IDD);
       }
    
    int OnWizardBack()
       {
        return pInfo->getPrevPage(IDD);
       }
    
    void OnHelp()
       {
        //m_pTestWizardInfo->ShowHelp(IDD);
       }

};





//-----------------------------------------------------------------------------
class CComponentWizardDelegatedInterfacesPage
      : public CWizard97InteriorPageImpl<CComponentWizardDelegatedInterfacesPage>
      //, public CTestWizardInfoRef
{
protected:
// Typedefs
    typedef CComponentWizardDelegatedInterfacesPage                            thisClass;
    typedef CWizard97InteriorPageImpl<CComponentWizardDelegatedInterfacesPage> baseClass;

    CComponentWizardInfo *pInfo;
    CListBox              interfaceList;
    //DWORD                 prevButtons;

public:

    void setInfo( CComponentWizardInfo *pi ) { pInfo = pi; }

public:
// Constructor
    CComponentWizardDelegatedInterfacesPage(_U_STRINGorID title = (LPCTSTR)NULL)
        : baseClass(title)
        //, prevButtons(0)
    {
        baseClass::SetHeaderTitle(_T("Select interfaces to be delegated"));
        baseClass::SetHeaderSubTitle(_T("Select interfaces to be delegated to other components"));
        //baseClass::SetHeaderSubTitle(_T("Select the path and filter identifying a list of files."));
    }

    enum { IDD = IDD_COMPOWIZ_INTERFACE_DELEGATES };
    BEGIN_MSG_MAP(thisClass)
        MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
        MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
        COMMAND_ID_HANDLER(IDC_LIST_INTERFACES  , OnListEvent)
        //COMMAND_HANDLER(IDC_RADIO_FILTER_ALL, BN_CLICKED, OnClickFilterAll)
        //COMMAND_HANDLER(IDC_RADIO_FILTER_CUSTOM, BN_CLICKED, OnClickFilterCustom)
        //COMMAND_HANDLER(IDC_BTN_BROWSEPATH, BN_CLICKED, OnClickBrowsePath)
        CHAIN_MSG_MAP(baseClass)
    END_MSG_MAP()

    void buildDelegateInterfaceList()
       {
        int totalListItems = interfaceList.GetCount();
        int i = 0;
        tstring strLabel;
        pInfo->delegateInterfacesIndexes.clear();
        for(; i!=totalListItems; ++i)
           {
            int sel = interfaceList.GetSel( i );
            if (sel)
               {
                pInfo->delegateInterfacesIndexes.push_back(pInfo->selectedInterfaceIndexes[i]);
               }
           }
       }

    LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
       {
        CWaitCursor waitCursor;

        interfaceList = GetDlgItem(IDC_LIST_INTERFACES);
        return 1;
       }

    LRESULT OnListEvent(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
       {
        buildDelegateInterfaceList();
        return 0;
       }

    LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
       {
        bHandled = FALSE;
        //this->UninitializeControls();   
        return 0;
       }

    int OnSetActive()
       {
        while(interfaceList.GetCount()>0)
           {
            interfaceList.DeleteString(0);
           }

        ::std::vector< size_t >::const_iterator siIt = pInfo->selectedInterfaceIndexes.begin();
        for(; siIt!=pInfo->selectedInterfaceIndexes.end(); ++siIt)
           {
            if (*siIt>= pInfo->allInterfaces.size()) continue;
            interfaceList.AddString( pInfo->allInterfaces[*siIt].c_str() );
            //++idx;
            ::std::vector< size_t >::const_iterator diIt = pInfo->delegateInterfacesIndexes.begin();
            for(; diIt!=pInfo->delegateInterfacesIndexes.end(); ++diIt)
               {
                if (*siIt==*diIt) 
                   { 
                    interfaceList.SetSel( interfaceList.GetCount()-1, TRUE ); 
                    break;
                   }
               }
           }
        return 0;
       }
    
    int OnWizardNext()
       {
        return pInfo->getNextPage(IDD);
       }
    
    int OnWizardBack()
       {
        return pInfo->getPrevPage(IDD);
       }
    
    void OnHelp()
       {
        //m_pTestWizardInfo->ShowHelp(IDD);
       }

};





//-----------------------------------------------------------------------------
class CComponentWizardInterfaceOrderPage
      : public CWizard97InteriorPageImpl<CComponentWizardInterfaceOrderPage>
      //, public CTestWizardInfoRef
{
protected:
// Typedefs
    typedef CComponentWizardInterfaceOrderPage                            thisClass;
    typedef CWizard97InteriorPageImpl<CComponentWizardInterfaceOrderPage> baseClass;

    CComponentWizardInfo *pInfo;
    CListBox              interfaceList;
    CButton               btnTop;
    CButton               btnUp;
    CButton               btnDown;
    CButton               btnBottom;
    //DWORD                 prevButtons;

public:

    void setInfo( CComponentWizardInfo *pi ) { pInfo = pi; }

public:
// Constructor
    CComponentWizardInterfaceOrderPage(_U_STRINGorID title = (LPCTSTR)NULL)
        : baseClass(title)
        //, prevButtons(0)
    {
        baseClass::SetHeaderTitle(_T("Select interface order"));
        baseClass::SetHeaderSubTitle(_T("Select interface inheritance order"));
        //baseClass::SetHeaderSubTitle(_T("Select the path and filter identifying a list of files."));
    }

    enum { IDD = IDD_COMPOWIZ_INTERFACE_ORDER };
    BEGIN_MSG_MAP(thisClass)
        MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
        MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
        COMMAND_ID_HANDLER(IDC_LIST_INTERFACES , OnListEvent)
        COMMAND_ID_HANDLER(IDC_BTN_TOP         , OnBtnTop)
        COMMAND_ID_HANDLER(IDC_BTN_UP          , OnBtnUp)
        COMMAND_ID_HANDLER(IDC_BTN_DOWN        , OnBtnDown)
        COMMAND_ID_HANDLER(IDC_BTN_BOTTOM      , OnBtnBottom)
        //COMMAND_HANDLER(IDC_RADIO_FILTER_ALL, BN_CLICKED, OnClickFilterAll)
        //COMMAND_HANDLER(IDC_RADIO_FILTER_CUSTOM, BN_CLICKED, OnClickFilterCustom)
        //COMMAND_HANDLER(IDC_BTN_BROWSEPATH, BN_CLICKED, OnClickBrowsePath)
        CHAIN_MSG_MAP(baseClass)
    END_MSG_MAP()

    void enableButton(DWORD flags, DWORD mask, CButton &btn)
       {
        if (flags&mask) btn.EnableWindow(TRUE);
        else            btn.EnableWindow(FALSE);
       }

    void setupMoveButtons()
       {
        int idx = interfaceList.GetCurSel();
        // 1 - top, 2 - up, 4 down, 8 - bottom
        DWORD flags = 0;
        if (idx>=0 && idx<(int)pInfo->selectedInterfaceIndexes.size())
           {
            if (idx>0) flags |= 3; // allow top & up
            if ((idx+1)!=(int)pInfo->selectedInterfaceIndexes.size())
               flags |= 12;
           }
        enableButton(flags, 1, btnTop   );
        enableButton(flags, 2, btnUp    );
        enableButton(flags, 4, btnDown  );
        enableButton(flags, 8, btnBottom);
       }

    LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
       {
        btnTop        = GetDlgItem(IDC_BTN_TOP   );
        btnUp         = GetDlgItem(IDC_BTN_UP    );
        btnDown       = GetDlgItem(IDC_BTN_DOWN  );
        btnBottom     = GetDlgItem(IDC_BTN_BOTTOM);
        interfaceList = GetDlgItem(IDC_LIST_INTERFACES);
        return 1;
       }

    LRESULT OnListEvent(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
       {
        setupMoveButtons();
        return 0;
       }

    LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
       {
        bHandled = FALSE;
        //this->UninitializeControls();   
        return 0;
       }


    // 1 - top, 2 - up, 4 down, 8 - bottom
    void moveListItem( int how )
       {
        int idx = interfaceList.GetCurSel();
        if (idx<0 || idx>=(int)pInfo->selectedInterfaceIndexes.size()) return; // index out of range
        int newSel = pInfo->changeSelectedInterfaceOrder( pInfo->selectedInterfaceIndexes[idx], how );
        fillList(true, newSel);
        setupMoveButtons();
       }

    LRESULT OnBtnTop(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
       {
        moveListItem(1);
        return 0;
       }

    LRESULT OnBtnUp(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
       {
        moveListItem(2);
        return 0;
       }

    LRESULT OnBtnDown(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
       {
        moveListItem(4);
        return 0;
       }

    LRESULT OnBtnBottom(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
       {
        moveListItem(8);
        return 0;
       }
    // setSel - allow set/restore sel
    // newSel - -1 - set prev sel, >=0 - set specified sel
    void fillList(bool setSel = false, int newSel = -1)
       {
        int sel = newSel; 
        if (setSel && sel<0) sel = interfaceList.GetCurSel();
        while(interfaceList.GetCount()>0)
           {
            interfaceList.DeleteString(0);
           }
        ::std::vector< size_t >::const_iterator siIt = pInfo->selectedInterfaceIndexes.begin();
        for(; siIt!=pInfo->selectedInterfaceIndexes.end(); ++siIt )
           {
            interfaceList.AddString( pInfo->allInterfaces[*siIt].c_str() );
           }
        if (setSel) interfaceList.SetCurSel(sel);
       }

    int OnSetActive()
       {
        this->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);
        fillList();
        setupMoveButtons();
        //setButtons(true);
        //interfaceList.SetFocus();
        return 0;
       }
    
    int OnWizardNext()
       {
        return pInfo->getNextPage(IDD);
       }
    
    int OnWizardBack()
       {
        return pInfo->getPrevPage(IDD);
       }
    
    void OnHelp()
       {
        //m_pTestWizardInfo->ShowHelp(IDD);
       }

};




//-----------------------------------------------------------------------------
class CComponentWizardGeneratorOptionsPage
      : public CWizard97InteriorPageImpl<CComponentWizardGeneratorOptionsPage>
      //, public CTestWizardInfoRef
{
protected:
// Typedefs
    typedef CComponentWizardGeneratorOptionsPage                            thisClass;
    typedef CWizard97InteriorPageImpl<CComponentWizardGeneratorOptionsPage> baseClass;

    CComponentWizardInfo *pInfo;
    //CListBox              interfaceList;
    CButton               btnGenerateMethods;
    CButton               btnAddQueryInterface;
    CButton               btnAddDestroyMethod;
    CButton               btnUseRefCounting;
    CButton               btnNoRefCounting;
    //CButton               btnBottom;
    //DWORD                 prevButtons;

public:

    void setInfo( CComponentWizardInfo *pi ) { pInfo = pi; }

public:
// Constructor
    CComponentWizardGeneratorOptionsPage(_U_STRINGorID title = (LPCTSTR)NULL)
        : baseClass(title)
        //, prevButtons(0)
    {
        baseClass::SetHeaderTitle(_T("Select generation options"));
        baseClass::SetHeaderSubTitle(_T("Select component code generation options"));
        //baseClass::SetHeaderSubTitle(_T("Select the path and filter identifying a list of files."));
    }

    enum { IDD = IDD_COMPOWIZ_GENERATOR_OPTIONS };
    BEGIN_MSG_MAP(thisClass)
        MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
        MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
        COMMAND_ID_HANDLER( IDC_CHECK_ADD_METHODS_PROLOG  , OnCheckAddPrologs)
        COMMAND_ID_HANDLER( IDC_CHECK_ADD_IUNKNOWN_SUPPORT, OnCheckIUnknown)
        COMMAND_ID_HANDLER( IDC_CHECK_ADD_DESTROY_IMPL    , OnCheckDestroy)
        COMMAND_ID_HANDLER( IDC_RADIO_USE_REF_COUNTING    , OnRadioUseRefCounting)
        COMMAND_ID_HANDLER( IDC_RADIO_NO_REF_COUNTING     , OnRadioNoRefCounting)
        //COMMAND_HANDLER(IDC_RADIO_FILTER_ALL, BN_CLICKED, OnClickFilterAll)
        //COMMAND_HANDLER(IDC_RADIO_FILTER_CUSTOM, BN_CLICKED, OnClickFilterCustom)
        //COMMAND_HANDLER(IDC_BTN_BROWSEPATH, BN_CLICKED, OnClickBrowsePath)
        CHAIN_MSG_MAP(baseClass)
    END_MSG_MAP()

    LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
       {
        btnGenerateMethods   = GetDlgItem( IDC_CHECK_ADD_METHODS_PROLOG );
        btnAddQueryInterface = GetDlgItem( IDC_CHECK_ADD_IUNKNOWN_SUPPORT );
        btnAddDestroyMethod  = GetDlgItem( IDC_CHECK_ADD_DESTROY_IMPL );
        btnUseRefCounting    = GetDlgItem( IDC_RADIO_USE_REF_COUNTING );
        btnNoRefCounting     = GetDlgItem( IDC_RADIO_NO_REF_COUNTING );
        //btnTop        = GetDlgItem(IDC_BTN_TOP   );
        return 1;
       }

    LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
       {
        bHandled = FALSE;
        //this->UninitializeControls();   
        return 0;
       }

    void checkEnableButtons()
       {
        btnAddQueryInterface.EnableWindow( pInfo->extendsIUnknown ? TRUE : FALSE );
        btnUseRefCounting   .EnableWindow( pInfo->extendsIUnknown&&pInfo->addQueryInterface ? TRUE : FALSE );
        btnNoRefCounting    .EnableWindow( pInfo->extendsIUnknown&&pInfo->addQueryInterface ? TRUE : FALSE );
        btnAddDestroyMethod .EnableWindow( pInfo->extendsIUnknown&&pInfo->addQueryInterface ? TRUE : FALSE );
       }

    int OnSetActive()
       {
        this->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);

        pInfo->checkOneOfIsIUnknown();

        btnGenerateMethods  .SetCheck( pInfo->generateMethods   ? BST_CHECKED : BST_UNCHECKED );
        btnAddQueryInterface.SetCheck( pInfo->addQueryInterface ? BST_CHECKED : BST_UNCHECKED );
        if (pInfo->useRefCounting) btnUseRefCounting.SetCheck(BST_CHECKED);
        else                       btnNoRefCounting .SetCheck(BST_CHECKED);
        btnAddDestroyMethod.SetCheck( pInfo->addDestroyMethod ? BST_CHECKED : BST_UNCHECKED );

        //fillList();
        //setupMoveButtons();
        //setButtons(true);
        //interfaceList.SetFocus();
        return 0;
       }

    LRESULT OnCheckAddPrologs(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
       {
        pInfo->generateMethods = (btnGenerateMethods.GetCheck()==BST_CHECKED);
        return 0;
       }

    LRESULT OnCheckIUnknown(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
       {
        pInfo->addQueryInterface = (btnAddQueryInterface.GetCheck()==BST_CHECKED);
        checkEnableButtons();
        return 0;
       }

    LRESULT OnCheckDestroy(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
       {
        pInfo->addDestroyMethod = (btnAddDestroyMethod.GetCheck()==BST_CHECKED);
        return 0;
       }

    LRESULT OnRadioUseRefCounting(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
       {
        pInfo->useRefCounting = (btnUseRefCounting.GetCheck()==BST_CHECKED);
        return 0;
       }

    LRESULT OnRadioNoRefCounting(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
       {
        pInfo->useRefCounting = !(btnNoRefCounting.GetCheck()==BST_CHECKED);
        return 0;
       }
       
    int OnWizardNext()
       {
        return pInfo->getNextPage(IDD);
       }
    
    int OnWizardBack()
       {
        return pInfo->getPrevPage(IDD);
       }
    
    void OnHelp()
       {
        //m_pTestWizardInfo->ShowHelp(IDD);
       }

};




//-----------------------------------------------------------------------------
class CComponentWizardClassNamePage
      : public CWizard97InteriorPageImpl<CComponentWizardClassNamePage>
      //, public CTestWizardInfoRef
{
protected:
// Typedefs
    typedef CComponentWizardClassNamePage                            thisClass;
    typedef CWizard97InteriorPageImpl<CComponentWizardClassNamePage> baseClass;

    CComponentWizardInfo *pInfo;
    CEdit                 edit;

    enum { IDC_EDIT = IDC_EDIT_CLASS_NAME };

public:

    void setInfo( CComponentWizardInfo *pi ) { pInfo = pi; }

public:
// Constructor
    CComponentWizardClassNamePage(_U_STRINGorID title = (LPCTSTR)NULL)
        : baseClass(title)
        //, prevButtons(0)
    {
        baseClass::SetHeaderTitle(_T("Enter class name"));
        baseClass::SetHeaderSubTitle(_T("Enter class name and optional namespace name for newly created component"));
    }

    enum { IDD = IDD_COMPOWIZ_ENTER_CLASSNAME };
    BEGIN_MSG_MAP(thisClass)
        MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
        MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
        COMMAND_ID_HANDLER( IDC_EDIT, OnClassNameEvent)
        //COMMAND_ID_HANDLER( IDC_CHECK_ADD_IUNKNOWN_SUPPORT, OnCheckIUnknown)
        CHAIN_MSG_MAP(baseClass)
    END_MSG_MAP()

    LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
       {
        edit = GetDlgItem( IDC_EDIT );
        //btnGenerateMethods   = GetDlgItem( IDC_CHECK_ADD_METHODS_PROLOG );
        return 1;
       }

    LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
       {
        bHandled = FALSE;
        //this->UninitializeControls();   
        return 0;
       }

    tstring getEditText()
       {
        TCHAR buf[1024];
        int res = edit.GetWindowText( buf, sizeof(buf)/sizeof(buf[0]));
        buf[res] = 0;
        return tstring(buf);
       }

    int OnSetActive()
       {
        this->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);
        if (pInfo->classNameAuto)
           pInfo->className = pInfo->generateClassName();
        edit.SetWindowText( pInfo->className.c_str() );
        return 0;
       }

    LRESULT OnClassNameEvent(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
       {
        tstring newText = getEditText();
        if (newText!=pInfo->className)
           {
            pInfo->className = newText;
            pInfo->classNameAuto = false;
           }
        return 0;
       }
       
    int OnWizardNext()
       {
        return pInfo->getNextPage(IDD);
       }
    
    int OnWizardBack()
       {
        return pInfo->getPrevPage(IDD);
       }
    
    void OnHelp()
       {
        //m_pTestWizardInfo->ShowHelp(IDD);
       }

};





//-----------------------------------------------------------------------------
class CComponentWizardFileNamePage
      : public CWizard97InteriorPageImpl<CComponentWizardFileNamePage>
      //, public CTestWizardInfoRef
{
protected:
// Typedefs
    typedef CComponentWizardFileNamePage                            thisClass;
    typedef CWizard97InteriorPageImpl<CComponentWizardFileNamePage> baseClass;

    CComponentWizardInfo *pInfo;
    CEdit                 edit;
    CButton               btnCheckOverwrite;

    enum { IDC_EDIT = IDC_EDIT_FILE_NAME };

public:

    void setInfo( CComponentWizardInfo *pi ) { pInfo = pi; }

public:
// Constructor
    CComponentWizardFileNamePage(_U_STRINGorID title = (LPCTSTR)NULL)
        : baseClass(title)
        //, prevButtons(0)
    {
        baseClass::SetHeaderTitle(_T("Enter file name"));
        baseClass::SetHeaderSubTitle(_T("Enter file name where generated code will be placed"));
    }

    enum { IDD = IDD_COMPOWIZ_ENTER_FILENAME };
    BEGIN_MSG_MAP(thisClass)
        MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
        MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
        COMMAND_ID_HANDLER( IDC_EDIT               , OnFileNameEvent )
        COMMAND_ID_HANDLER( IDC_BTN_BROWSEFILE     , OnBrowse        )
        COMMAND_ID_HANDLER( IDC_CHECKBOX_OVERWRITE , OnOverwrite     )
        
        //COMMAND_ID_HANDLER( IDC_CHECK_ADD_IUNKNOWN_SUPPORT, OnCheckIUnknown)
        CHAIN_MSG_MAP(baseClass)
    END_MSG_MAP()

    LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
       {
        edit = GetDlgItem( IDC_EDIT );
        btnCheckOverwrite = GetDlgItem(IDC_CHECKBOX_OVERWRITE);
        //btnGenerateMethods   = GetDlgItem( IDC_CHECK_ADD_METHODS_PROLOG );
        return 1;
       }

    LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
       {
        bHandled = FALSE;
        //this->UninitializeControls();   
        return 0;
       }

    tstring getEditText()
       {
        TCHAR buf[1024];
        int res = edit.GetWindowText( buf, sizeof(buf)/sizeof(buf[0]));
        buf[res] = 0;
        return tstring(buf);
       }

    int OnSetActive()
       {
        this->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);
        if (pInfo->fileNameAuto)
           pInfo->fileName = pInfo->generateFileName();
        edit.SetWindowText( pInfo->fileName.c_str() );

        btnCheckOverwrite.SetCheck(pInfo->overwriteOutput ? BST_CHECKED : BST_UNCHECKED);

        return 0;
       }

    LRESULT OnFileNameEvent(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
       {
        tstring newText = getEditText();
        if (newText!=pInfo->fileName)
           {
            pInfo->fileName = newText;
            pInfo->fileNameAuto = false;
           }
        return 0;
       }

    LRESULT OnBrowse(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
       {
        CFileDialog dlg( FALSE, 0, 0, OFN_NOREADONLYRETURN|OFN_OVERWRITEPROMPT
                       , _T("C/C++ header files (*.h;*.hpp)\0*.h;*.hpp\0All files\0*.*\0\0")/* lpszFilter */
                       , m_hWnd
                       );
        //CFileDialogImpl dlg( TRUE, 0, 0, 0,  _T("Permit files\0*.TXT\0ENC Permit files\0*.PMT\0All files\0*.*\0\0")/* lpszFilter */ )

        if (dlg.DoModal(m_hWnd)==IDOK)
           {
            edit.SetWindowText( dlg.m_szFileName );
            tstring newText = getEditText();
            if (newText!=pInfo->fileName)
               {
                pInfo->fileName = newText;
                pInfo->fileNameAuto = false;
               }
            if (MARTY_WINAPI::fileExist(pInfo->fileName))
               {
                pInfo->overwriteOutput = true;
                btnCheckOverwrite.SetCheck(pInfo->overwriteOutput ? BST_CHECKED : BST_UNCHECKED);
               }
           }

        return 0;
       }

    LRESULT OnOverwrite(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
       {
        pInfo->overwriteOutput = (btnCheckOverwrite.GetCheck()==BST_CHECKED);
        return 0;
       }
      
    int OnWizardNext()
       {
        return pInfo->getNextPage(IDD);
       }
    
    int OnWizardBack()
       {
        return pInfo->getPrevPage(IDD);
       }
    
    void OnHelp()
       {
        //m_pTestWizardInfo->ShowHelp(IDD);
       }

};





//-----------------------------------------------------------------------------
class CComponentWizardCompletionPage 
      : public CWizard97ExteriorPageImpl<CComponentWizardCompletionPage>
      //, public CTestWizardInfoRef
{
protected:
// Typedefs
    typedef CComponentWizardCompletionPage                             thisClass;
    typedef CWizard97ExteriorPageImpl<CComponentWizardCompletionPage>  baseClass;

// Data members
    CFont m_fontSummary;
    CRichEditCtrl m_editSummary;

    CComponentWizardInfo *pInfo;

public:

    void setInfo( CComponentWizardInfo *pi ) { pInfo = pi; }

public:
// Constructors
    CComponentWizardCompletionPage(_U_STRINGorID title = (LPCTSTR)NULL) :
        baseClass(title)
    { }

// Message Handlers
    enum { IDD = IDD_COMPOWIZ_COMPLETION };
    BEGIN_MSG_MAP(thisClass)
        MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
        CHAIN_MSG_MAP(baseClass)
    END_MSG_MAP()

    LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
       {
        CFontHandle fontExteriorPageTitleFont(baseClass::GetExteriorPageTitleFont());
    
        CWindow title = this->GetDlgItem(IDC_COMPOWIZ_EXTERIOR_TITLE);
        title.SetFont(fontExteriorPageTitleFont);
    
        m_editSummary = this->GetDlgItem(IDC_COMPOWIZ_SUMMARY);

        CLogFont logFont;
        CClientDC dc(m_hWnd);
        logFont.SetHeight(8, dc);
        ::lstrcpy(logFont.lfFaceName, _T("Courier New"));
    
        m_fontSummary.Attach(logFont.CreateFontIndirect());
        m_editSummary.SetFont(m_fontSummary);

        TEXTMETRIC tm = {0};
        CFontHandle oldFont = dc.SelectFont(m_fontSummary);
        dc.GetTextMetrics(&tm);
        dc.SelectFont(oldFont);
    
        int dialogUnitsX = ::MulDiv(4, tm.tmAveCharWidth, LOWORD(GetDialogBaseUnits()));
        int tabStops = 4*dialogUnitsX;
    
        m_editSummary.SetTabStops(tabStops);
       
        // _T("� Find files matching the filter '%s'\r\n"),
        return 1;
       }

    int OnSetActive()
    {
        this->SetWizardButtons(PSWIZB_BACK | PSWIZB_FINISH);

        m_editSummary.SetReadOnly(FALSE);
        m_editSummary.SetSelAll(); // TRUE no scroll only for std edit
        m_editSummary.ReplaceSel( pInfo->generateSummaryInfo().c_str(), FALSE ); // can't undo
        m_editSummary.SetReadOnly(TRUE);
        //m_editSummary.
        return 0;
    }
    
    int OnWizardBack()
       {
        // 0  = goto previous page
        // -1 = prevent page change
        // >0 = jump to page by dlg ID
        return pInfo->getPrevPage(IDD);
        //return pInfo->getNextPage(IDD);
    }
    
    INT_PTR OnWizardFinish()
    {
        // We could either do the work here, or in the place that
        // called DoModal on our Sheet (which for this example is CTestWizard).
        // The advantage of doing the work here is that we can prevent
        // the finish, and tell the user to go back and correct something.
        // The advantage of doing it in the caller of DoModal is
        // that the wizard isn't visible while the work is being done.
    
        // For this example, we'll do the work here (or rather call back into
        // the info class to do the work), and prevent finish if something fails.
    
        //CWaitCursor waitCursor;
    
        //bool success = m_pTestWizardInfo->FinishWizard(m_hWnd);
    
        // FALSE = allow finish
        // TRUE = prevent finish
        // HWND = prevent finish and set focus to HWND (CommCtrl 5.80 only)
        return FALSE; // success ? FALSE : TRUE;
    }
    
    void OnHelp()
    {
        //m_pTestWizardInfo->ShowHelp(IDD);
    }

};






//-----------------------------------------------------------------------------
class CComponentWizardSheet 
      : public CWizard97SheetImpl<CComponentWizardSheet>
      //, public CTestWizardInfoRef
{
protected:
// Typedefs
    typedef CComponentWizardSheet                        thisClass;
    typedef CWizard97SheetImpl<CComponentWizardSheet>    baseClass;
    //typedef CTestWizardInfoRef infoRefClass;

// Data members
   CComponentWizardWelcomePage               m_pageWelcome;
   CComponentWizardSelectInterfacesPage      m_pageSelectInterfaces;
   CComponentWizardInterfaceOrderPage        m_pageInterfaceOrder;
   CComponentWizardDelegatedInterfacesPage   m_pageDelegateInterfaces;
   CComponentWizardGeneratorOptionsPage      m_pageGeneratorOptions;
   CComponentWizardClassNamePage             m_pageClassName;
   CComponentWizardFileNamePage              m_pageFileName;
   CComponentWizardCompletionPage            m_pageCompletion;
    //CTestWizardWelcomePage m_pageWelcome;
    //CTestWizardPathFilterPage m_pagePathFiler;
    //CTestWizardFilePreviewPage m_pageFilePreview;
    //CTestWizardOutputPage m_pageOutput;
    //CTestWizardCompletionPage m_pageCompletion;

    CComponentWizardInfo *pInfo;

public:

    void setInfo( CComponentWizardInfo *pi ) 
       { 
        pInfo = pi;
        m_pageWelcome          .setInfo(pInfo);
        m_pageSelectInterfaces .setInfo(pInfo);
        m_pageInterfaceOrder   .setInfo(pInfo);
        m_pageDelegateInterfaces.setInfo(pInfo);
        m_pageGeneratorOptions .setInfo(pInfo);
        m_pageClassName        .setInfo(pInfo);
        m_pageFileName         .setInfo(pInfo);
        m_pageCompletion       .setInfo(pInfo);
       }

public:
// Constructors
    //CComponentWizardSheet(CTestWizardInfo* pTestWizardInfo, UINT uStartPage = 0, HWND hWndParent = NULL);
    CComponentWizardSheet(CComponentWizardInfo *pi, UINT uStartPage = 0, HWND hWndParent = NULL)
       : baseClass(_T("CLI Component Wizard"), IDB_COMPOWIZ_HEADER, IDB_COMPOWIZ_WATERMARK, pi->getFirstPage(), hWndParent)
       {
        setInfo( pi );
        this->AddPage(m_pageWelcome);
        this->AddPage(m_pageSelectInterfaces);
        this->AddPage(m_pageInterfaceOrder);
        this->AddPage(m_pageDelegateInterfaces);
        this->AddPage(m_pageGeneratorOptions);
        this->AddPage(m_pageClassName);
        this->AddPage(m_pageFileName);
        this->AddPage(m_pageCompletion);
       }

// Message Handlers
    BEGIN_MSG_MAP(thisClass)
        MESSAGE_HANDLER(WM_HELP, OnHelp)
        CHAIN_MSG_MAP(baseClass)
    END_MSG_MAP()

    LRESULT OnHelp(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
       {
        /*
        LPHELPINFO helpInfo = (LPHELPINFO)lParam;
        if(helpInfo)
        {
            if(helpInfo->dwContextId != 0)
            {
                // If dwContextId is set, then the control with
                // focus has a help context ID, so we'll show context help.
                m_pTestWizardInfo->ShowContextHelp(helpInfo);
            }
            else
            {
                int currentIndex = this->GetActiveIndex();
                if(currentIndex >= 0)
                {
                    int pageDialogId = this->IndexToId(currentIndex);
                    if(pageDialogId != 0)
                    {
                        m_pTestWizardInfo->ShowHelp(pageDialogId, helpInfo->iCtrlId);
                    }
                }
            }
        }
        */
        return 0;
       }
};




#endif /* SRC_CIDL_WIZ_CWDLGS_H */

