//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by compowiz.rc
//
#define IDD_COMPOWIZ_WELCOME            101
#define IDD_COMPOWIZ_INTERFACES_LIST    102
#define IDD_COMPOWIZ_INTERFACE_ORDER    103
#define IDD_COMPOWIZ_INTERFACE_DELEGATES 104
#define IDD_COMPOWIZ_GENERATOR_OPTIONS  105
#define IDD_COMPOWIZ_ENTER_CLASSNAME    106
#define IDD_COMPOWIZ_ENTER_FILENAME     107
#define IDD_COMPOWIZ_COMPLETION         108

#define IDB_COMPOWIZ_WATERMARK          110
#define IDB_COMPOWIZ_HEADER             111

#define IDC_COMPOWIZ_BULLET1            1000
#define IDC_COMPOWIZ_BULLET2            1001
#define IDC_COMPOWIZ_BULLET3            1002
#define IDC_COMPOWIZ_BULLET4            1003
#define IDC_COMPOWIZ_BULLET5            1004

#define IDC_COMPOWIZ_BULLET1_DESC       1010
#define IDC_COMPOWIZ_BULLET2_DESC       1011
#define IDC_COMPOWIZ_BULLET3_DESC       1012
#define IDC_COMPOWIZ_BULLET4_DESC       1013
#define IDC_COMPOWIZ_BULLET5_DESC       1014

#define IDC_COMPOWIZ_EXTERIOR_DESC      1020
#define IDC_COMPOWIZ_EXTERIOR_TITLE     1021
#define IDC_COMPOWIZ_WELCOME_NOTAGAIN   1022

#define IDC_COMPOWIZ_SUMMARY              1023
#define IDC_COMPOWIZ_EXTERIOR_CLICKFINISH 1024

#define IDC_LABEL_DESCRIPTION           1025
#define IDC_LIST_INTERFACES             1026
#define IDC_LABEL_INTERFACES            1027
#define IDC_LABEL_INTERFACE_DESC        1028
//IDC_BTN_PREVIEW

#define IDC_BTN_TOP                     1029
#define IDC_BTN_UP                      1030
#define IDC_BTN_DOWN                    1031
#define IDC_BTN_BOTTOM                  1032

#define IDC_CHECK_ADD_METHODS_PROLOG    1033
#define IDC_CHECK_ADD_IUNKNOWN_SUPPORT  1034
#define IDC_RADIO_USE_REF_COUNTING      1035
#define IDC_RADIO_NO_REF_COUNTING       1036
#define IDC_CHECK_ADD_DESTROY_IMPL      1037

#define IDC_EDIT_CLASS_NAME             1038
#define IDC_EDIT_FILE_NAME              1039
#define IDC_LABEL_CLASS                 1040
#define IDC_LABEL_FILE                  1041
#define IDC_BTN_BROWSEFILE              1042
#define IDC_CHECKBOX_OVERWRITE          1043


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1044
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
