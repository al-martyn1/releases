#ifndef SRC_CIDL_WIZ_COMPOWIZ_H
#define SRC_CIDL_WIZ_COMPOWIZ_H

namespace wiz
{

const int guiModeShowAll       = 2;
const int guiModeShowRequired  = 1;
const int guiModeBatch         = 0;


}; // namespace wiz


#endif /* SRC_CIDL_WIZ_COMPOWIZ_H */

