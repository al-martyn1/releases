
#include "readCode.h"

#include <cli/cli2.h>
#include <cli/cliutilx.h>

/*
GOES HERE
END

USER INCLUDES
USER GLOBALS
USER NS LOCALS
CLASS MEMBERS
CLASS MEMBERS INIT
CLASS ADDITIONAL INIT ACTIONS
ADDITIONAL CONSTRUCTORS AND DESTRUCTOR
METHOD
INTERFACE
MEMBER CODE
METHOD SIGNATURE
*/
#define RFNC_GOES_HERE                                 -2
#define RFNC_END                                       -1
#define RFNC_UNKNOWN                                   0
#define RFNC_USER_INCLUDES                             1
#define RFNC_USER_GLOBALS                              2
#define RFNC_USER_NS_LOCALS                            3
#define RFNC_CLASS_MEMBERS                             4
#define RFNC_CLASS_MEMBERS_INIT                        5
#define RFNC_CLASS_ADDITIONAL_INIT_ACTIONS             6
#define RFNC_ADDITIONAL_CONSTRUCTORS_AND_DESTRUCTOR    7
#define RFNC_METHOD                                    8
#define RFNC_INTERFACE                                 9
#define RFNC_MEMBER_CODE                               10
#define RFNC_METHOD_SIGNATURE                          11
//#define RFNC_                                          12


static
int getToken( const ::std::string &str )
   {
    static ::std::map< ::std::string , int > tokens;
    if (tokens.empty())
       {
        tokens["GOES HERE"                             ] = RFNC_GOES_HERE                             ;
        tokens["END"                                   ] = RFNC_END                                   ;
        //tokens["UNKNOWN                               "] = RFNC_UNKNOWN                               ;
        tokens["USER INCLUDES"                         ] = RFNC_USER_INCLUDES                         ;
        tokens["USER GLOBALS"                          ] = RFNC_USER_GLOBALS                          ;
        tokens["USER NS LOCALS"                        ] = RFNC_USER_NS_LOCALS                        ;
        tokens["CLASS MEMBERS"                         ] = RFNC_CLASS_MEMBERS                         ;
        tokens["CLASS MEMBERS INIT"                    ] = RFNC_CLASS_MEMBERS_INIT                    ;
        tokens["CLASS ADDITIONAL INIT ACTIONS"         ] = RFNC_CLASS_ADDITIONAL_INIT_ACTIONS         ;
        tokens["ADDITIONAL CONSTRUCTORS AND DESTRUCTOR"] = RFNC_ADDITIONAL_CONSTRUCTORS_AND_DESTRUCTOR;
        tokens["METHOD"                                ] = RFNC_METHOD                                ;
        tokens["INTERFACE"                             ] = RFNC_INTERFACE                             ;
        tokens["MEMBER CODE"                           ] = RFNC_MEMBER_CODE                           ;
        tokens["METHOD SIGNATURE"                      ] = RFNC_METHOD_SIGNATURE                      ;
       }
    ::std::map< ::std::string , int >::const_iterator it = tokens.find(str);
    if (it==tokens.end()) return RFNC_UNKNOWN;
    return it->second;
   }



inline
::std::string trim_copy(const ::std::string &str)
   {
    return ::cli::util::trim_copy(str, ::cli::util::CIsSpace<TCHAR>());
   }

inline
void trim(::std::string &str)
   {
    return ::cli::util::trim(str, ::cli::util::CIsSpace<TCHAR>());
   }

inline
void appendLine( ::std::string &collector, const ::std::string &line )
   {
    if (!collector.empty()) collector.append(1,'\n');
    collector.append(line);
   }


void readFunctionsCode( ::std::istream &in
                     , ::std::map< ::std::string, std::string> &bySignature
                     , ::std::map< ::std::string, std::string> &byName
                     )
   {
    std::string line;
    std::string collector;
    bool bCollect = false;
    ::std::string strToken, methodName, methodSignature;
    ::std::vector< ::std::string > methodInterfaces;

    while( std::getline( in, line ))
       {
        ::std::string trimmed = trim_copy(line);
        if (!::cli::util::startsWith(trimmed, std::string("//")))
           {
            if (bCollect) appendLine( collector, line );
            continue;
           }

        trimmed = trim_copy(::std::string(trimmed, 2, ::std::string::npos ));
        if (!::cli::util::startsWith(trimmed, std::string("GENERATOR:")))
           {
            if (bCollect) appendLine( collector, line );
            continue;
           }

        trimmed = trim_copy(::std::string(trimmed, 10, ::std::string::npos ));
        ::std::string::size_type defisPos =  trimmed.find_first_of( "-", 0 );
        ::std::string strTail;

        if (defisPos==::std::string::npos)
           {
            strToken = trimmed;
           }
        else
           {
            strToken = trim_copy(::std::string(trimmed, 0, defisPos ));
            strTail  = trim_copy(::std::string(trimmed, defisPos+1, ::std::string::npos ));
           }

        int token = getToken(strToken);
        if (token==RFNC_UNKNOWN)
           {
            if (bCollect) appendLine( collector, line );
            continue;
           }

        switch(token)
           {
            case RFNC_USER_INCLUDES:  
            case RFNC_USER_GLOBALS:  
            case RFNC_USER_NS_LOCALS:  
            case RFNC_CLASS_MEMBERS:  
            case RFNC_CLASS_MEMBERS_INIT:  
            case RFNC_CLASS_ADDITIONAL_INIT_ACTIONS:  
            case RFNC_ADDITIONAL_CONSTRUCTORS_AND_DESTRUCTOR:  
            case RFNC_MEMBER_CODE:  
                 {
                  int token2 = getToken(strTail);
                  if (token2==RFNC_GOES_HERE) bCollect = true;
                  else
                     {
                      bCollect = false;
                      if (token==RFNC_MEMBER_CODE)
                         {
                          if (!methodName.empty() && !collector.empty())
                             {
                              byName[methodName] = collector;
                              methodName.clear();
                             }
                          if (!methodSignature.empty() && !collector.empty())
                             {
                              bySignature[methodSignature] = collector;
                              methodSignature.clear();
                             }
                         }
                      else
                         {
                          byName[strToken] = collector;
                         }

                      collector.clear();
                     }
                 }
                 break;

            case RFNC_METHOD:  
                 methodName = strTail;
                 methodInterfaces.clear();
                 methodSignature.clear();
                 break;

            case RFNC_INTERFACE:
                 methodInterfaces.push_back(strTail);
                 break;

            case RFNC_METHOD_SIGNATURE:
                 methodSignature = strTail;
                 break;
           }
       }
   }







