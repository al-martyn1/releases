#define CIDL_STRUCTS_ALLOW_USE_IOSTREAM

#ifndef WIN32_LEAN_AND_MEAN
    #define WIN32_LEAN_AND_MEAN
#endif

#ifndef STRICT
    #define STRICT
#endif

#if !defined(_WINDOWS_)
    #include <windows.h>
#endif

#if !defined(_INC_TCHAR) && !defined(_TCHAR_H_) && !defined(_TCHAR_H)
    #include <tchar.h>
#endif

#if !defined(_FSTREAM_) && !defined(_STLP_FSTREAM) && !defined(__STD_FSTREAM__) && !defined(_CPP_FSTREAM) && !defined(_GLIBCXX_FSTREAM)
    #include <fstream>
#endif


#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif


#include <marty/filename.h>
#include <marty/filesys.h>
#include <marty/filesys.cpp>
#include <marty/libapi.h>
#include <marty/concvt.h>
#include <marty/filesys.h>


#include <cli/cli2.h>
#include <cli/cliutilx.h>

//#include <cidl/cidl.h>
//#include <cidl/cidlErr.h>
//#include <cidl/cidlkwd.h>

//#include "cidlDefs.h"
//#include "doxerImpl.h"
//#include "doxy.h"

//#include "cidlGen.h"

#include "../../scanner/idlScanner.h"
#include "../parserImpl.h"
#include "../cidlGen.h"

#include "resource.h"

#include "../cgCppImpl.h"

#ifndef __COMPOWIZ_TSTRING_DEFINED__
#define __COMPOWIZ_TSTRING_DEFINED__
typedef ::std::basic_string< TCHAR, 
                             ::std::char_traits<TCHAR>, 
                             ::std::allocator<TCHAR> >  tstring;
#endif 

#include "compowiz.h"
#include "cwinfo.h"
#include "cwdlgs.h"
#include "readCode.h"




CAppModule _Module;


int opDetailed = 5;

CIncludeFinderImpl       includeFinder;



int read_config_file(const char* fname);
int parse_option(tstring str);
void print_help();

inline
tstring trim_copy(const tstring &str)
   {
    return ::cli::util::trim_copy(str, ::cli::util::CIsSpace<TCHAR>());
   }

inline
void trim(tstring &str)
   {
    return ::cli::util::trim(str, ::cli::util::CIsSpace<TCHAR>());
   }


::std::set<std::string>                   excludedFiles;
::std::map< ::std::string, ::std::string> doxyAliasises;
::std::set< ::std::string >               enabledSections;
bool                                      doxyAutoBrief = false;
//int                                       guiMode = ::wiz::guiModeShowRequired;
int                                       guiMode = ::wiz::guiModeShowAll;
bool                                      wizShowWelcome = true;
::std::vector<::std::string>              selectedInterfaces;
::std::vector<::std::string>              delegateInterfaces;

bool allowSkipChooseGeneratorOptions = false;

bool generateMethods    = true; // prolog/epilog
bool addQueryInterface  = true; // iUnknown support
bool addDestroyMethod   = true;
bool useRefCounting     = true;

::std::string className;
::std::string fileName;

bool overwriteOutput    = true;
bool createBakFile      = false;
::std::string createBakFileName;
int     wizardStartPage = IDD_COMPOWIZ_WELCOME;


::std::vector<::std::string>  includeHeaders;



/*
namespace wiz
{
const int guiModeShowAll       = 2;
const int guiModeShowRequired  = 1;
const int guiModeBatch         = 0;
}; // namespace wiz
*/


::std::vector< ::std::string >            targetList;

void addDoxyAlias(const ::std::string &str);
void addDoxyEnabledSection(const ::std::string &str);
//void addOutputTypeAlias(const ::std::string &str);

/*
void addOutputTypeAlias(const ::std::string &str)
   {
    generatorFabriq.addAlias(str);
   }
*/

void addDoxyAlias(const ::std::string &str)
   {
    if (str.empty()) return;

    ::std::string key, val;
    ::doxy::splitToPair( str, key, val, '=', true);
/*
    ::std::string::size_type pos = str.find('=');
    ::std::string key, val;
    if (pos==str.npos)
       {
        key = str;        
       }
    else
       {
        key = ::std::string(str, 0, pos);
        val = ::std::string(str, pos+1);
       }
*/
    doxyAliasises[key] = val;
   }

void addDoxyEnabledSection(const ::std::string &str)
   {
    if (str.empty()) return;
    enabledSections.insert(str);
   }


#if !defined(_DEBUG) && defined(_WIN32)
inline
TCHAR** ParseWinMainCommandLine(int *argc, TCHAR *cmd_line)
{
    static TCHAR arg_buf[65535]; /* NOTE: I think this size is enough */
    static TCHAR *argv[512];     /* NOTE: I think that program argument 
                                    count is always less than 512 */
    int cur_arg_idx = 0;
    DWORD size = sizeof(arg_buf)/sizeof(TCHAR);
    DWORD res = GetModuleFileName( 0, arg_buf, size);
    arg_buf[res] = _T('\0');
    argv[cur_arg_idx] = arg_buf;
    TCHAR *next_arg_ptr = arg_buf + res + 1;

    argv[++cur_arg_idx] = next_arg_ptr;

    int quot_cnt = 0;

    bool slash_mod = false;
    //bool prev_quot = false;
    for (;*cmd_line && cur_arg_idx<512; cmd_line++)
        {
         if (*cmd_line==_T(' ') && !(quot_cnt%2))
            { // end of param reached
             if (slash_mod) 
                { *next_arg_ptr++ = _T('\\'); slash_mod = false; }
             *next_arg_ptr++ = _T('\0');
             argv[++cur_arg_idx] = next_arg_ptr;
             continue;
            }

         if (!slash_mod && *cmd_line==_T('\\'))
            { slash_mod = true; continue; }

         if (slash_mod)
            {
             if (*cmd_line!=_T('\\') && *cmd_line!=_T('\"'))
                *next_arg_ptr++ = _T('\\');
             *next_arg_ptr++ = *cmd_line;
             slash_mod = false;
            }
         else
            {
             if (*cmd_line==_T('\"'))
                { // quot found
                 if (*(cmd_line+1)==_T('\"'))
                    { // double quot found
                     *next_arg_ptr++ = *cmd_line++;
                     //continue;
                    }
                 else
                    { // single quot found
                     quot_cnt++;
                    }
                }
             else
                { // no quot. simple copy character
                 *next_arg_ptr++ = *cmd_line;
                }
            }
        }

    if (slash_mod) 
       { *next_arg_ptr++ = _T('\\'); }
    if (argv[cur_arg_idx]!=next_arg_ptr)
       {
        *next_arg_ptr++ = _T('\0');
        argv[++cur_arg_idx] = next_arg_ptr;
       }
    if (argc) *argc = cur_arg_idx;
/*
//    TCHAR *cmdl_ptr = cmd_line;
    bool slash_mod = false;
    for (;*cmd_line; cmd_line++)
         {
          if (!slash_mod && *cmd_line==_T('\\'))
             {
              slash_mod = true;
              continue;
             }

          if (slash_mod)
             {
              *next_arg_ptr++ = *cmd_line;              
             }


         }
*/
    return argv;
}
#endif /* !defined(_DEBUG) && defined(_WIN32) */

struct CCompowizOutput
{
   #ifdef _DEBUG
   CCompowizOutput() {}
   template<typename T>
   ::std::ostream& operator<<( const T &t)
      {
       ::std::cout<<t;
       return ::std::cout;
      }
   #else
   std::ostringstream os;
   CCompowizOutput() : os() {}
   template<typename T>
   ::std::ostream& operator<<( const T &t)
      {
       os<<t;
       return os;
      }
   ~CCompowizOutput()
      {
       #ifdef _WIN32
       if (!os.str().empty())
          ::MessageBoxA( 0, os.str().c_str(), "CLI Component Wizzard", MB_OK );
       #else
       ::std::cout<<t;
       #endif
      }
   #endif
};




#ifdef _WIN32
    #ifdef _DEBUG
    int _tmain(int argc, TCHAR* argv[])
    #else
    int WINAPI _tWinMain(HINSTANCE hInstance, HINSTANCE /*hPrevInstance*/, LPTSTR lpstrCmdLine, int nCmdShow)
    #endif
#else
    int main(int argc, char* argv[])
#endif
   {
    //typedef MARTY_FILENAME::tstring tstring;
    using MARTY_FILENAME::getPath;
    using MARTY_FILENAME::getPathName;
    using MARTY_FILENAME::changeExtention;
    using MARTY_FILENAME::appendPath;
    using MARTY_FILENAME::getFile;
    using MARTY_FILENAME::makeCanonical;
    using MARTY_FILESYSTEM::getCurrentDirectory;
    using MARTY_FILENAME::isAbsolutePath;
    using MARTY_FILENAME::makeFullPath;


    //includeHeaders.push_back("cli/implhlp.h");

    tstring exeName;
    MARTY_LIBAPI::getModuleFileName(0, exeName);
    tstring cfg1 = getPath( exeName );
    tstring cfg2 = appendPath(appendPath(cfg1, tstring(_T("../conf"))), getFile(exeName));
    cfg1 = appendPath(cfg1, getFile(exeName));
    cfg1 = makeCanonical(changeExtention(cfg1, tstring(_T(".default-options"))));
    cfg2 = makeCanonical(changeExtention(cfg2, tstring(_T(".default-options"))));

    //cliWriteLogString((tstring(_T("Reading conf file: ")) + cfg1 + tstring(_T("\n"))).c_str());
    read_config_file(MARTY_CON::strToAnsi(cfg1).c_str());

    //cliWriteLogString((tstring(_T("Reading conf file: ")) + cfg2 + tstring(_T("\n"))).c_str());
    read_config_file(MARTY_CON::strToAnsi(cfg2).c_str());

    #if !defined(_DEBUG) &&defined(_WIN32)
    int argc = 0;
    TCHAR** argv = ParseWinMainCommandLine( &argc, lpstrCmdLine );
    #endif
// #if !defined(_DEBUG) && defined(_WIN32)
// inline
// TCHAR** ParseWinMainCommandLine(int *argc, TCHAR *cmd_line)

    for (int i=1; i<argc; i++)
        {
         int pr = 0;
         switch(*argv[i])
           {
            case _T('-'):
            case _T('/'):  
                       //pr = parse_option( MARTY_CON::strToAnsi(argv[i]));
                       pr = parse_option( argv[i]);
                       break;
            case _T('@'):  
                       pr = read_config_file(MARTY_CON::strToAnsi(argv[i]+1).c_str());
                       break;
            //default:   
            //           inputFiles.push_back(argv[i]);
           };
         
         if (pr) return pr;     
        }



    //MARTY_TCSTRING 
    //::std::vector< tstring >
    std::vector<std::string> inputFiles;
    std::vector<std::string> inputFilesRelativeNames;

    /*
    std::string cliIunknownCidl = MARTY_FILENAME_NS makeCanonical("cli/iunknown.cidl");
    tstring foundIunknownCidlFilename;
    MARTY_FILESYSTEM_NS handle_t hFound = 
                                 includeFinder.searchForStandartInclude( cliIunknownCidl, foundIunknownCidlFilename );

    if (hFound==MARTY_FILESYSTEM_NS hInvalidHandle)
       { // not found
        #ifdef _DEBUG
        //std::cout<<"Base file 'iunknown.cidl' not found\n";
        #else
        // MessageBox
        #endif
       }
    else
       {
        MARTY_FILESYSTEM_NS closeFile(hFound);
        //inputFiles.push_back(MARTY_CON::strToAnsi(foundIunknownCidlFilename));
        //inputFilesRelativeNames.push_back(cliIunknownCidl);
       }

    //if (0)
       {
        //inputFiles.push_back("f:\\work\\cli2\\trunk\\include\\cli\\inet\\ipTypes.cidl");
        //inputFilesRelativeNames.push_back("cli\\inet\\ipTypes.cidl");       
       }
    */

    //includeFinder.searchByMask( MARTY_CON::strToAnsi("*.cidl"), inputFiles, &inputFilesRelativeNames);
    includeFinder.searchByMask( "*.cidl", inputFiles, &inputFilesRelativeNames);

    cidl::CCidlErrorContext    errContext;
    std::vector<CScannerEvent> scannerEvents;
    std::vector<std::string>   processedFiles;

    std::string curDir = MARTY_CON::strToAnsi(getCurrentDirectory());

    ::std::set<unsigned> srcFilesIds;
    

    #ifdef _DEBUG
    std::cout<<"Reading files\n";
    #endif

    /*
    ::std::set<std::string>  excludedFiles; // excluded from explicit parsing
    excludedFiles.insert( MARTY_FILENAME_NS makeCanonical("cli/podTypes.cidl") );
    excludedFiles.insert( MARTY_FILENAME_NS makeCanonical("cli/baseDefs.cidl") );
    excludedFiles.insert( MARTY_FILENAME_NS makeCanonical("cli/iunknown.cidl") );
    //excludedFiles.insert( MARTY_FILENAME_NS makeCanonical("cli/") );
    */

    CMacroPreprocessorBase* pMacroPreprocessor = CPrettyCppScannerBase::createDefaultPreprocessor();
    pMacroPreprocessor->addMacro(::std::string("_COMPOWIZ_INVOKED=1")); // c2idl processing this file 
    pMacroPreprocessor->addMacro(::std::string("_C2IDL_VER=100"));   // c2idl version - 1.00


    std::vector<std::string>::const_iterator  ifIt   = inputFiles.begin();
    std::vector<std::string>::const_iterator  ifrnIt = inputFilesRelativeNames.begin();
    for(; ifIt!=inputFiles.end(); ++ifIt, ++ifrnIt)
       {
        if (excludedFiles.find(*ifrnIt)!=excludedFiles.end()) continue; // 
        excludedFiles.insert(*ifrnIt);

        bool extLogging = false;

        #ifdef _DEBUG
        //std::cout<<"File: "<<*ifrnIt<<" - "<<*ifIt<<", scannerEvents: "<<(unsigned)scannerEvents.size()<<"\n";
        std::cout<<"File: "<<*ifrnIt<<" - "<<*ifIt<<", scannerEvents: "<<(unsigned)scannerEvents.size();
        #endif
        /*
        if (*ifrnIt=="cli\\gui\\types.cidl" || *ifrnIt=="cli\\inet\\ipTypes.cidl")
           {
            #ifdef _DEBUG
            std::cout<<"cli\\gui\\types.cidl\n";
            #endif
            extLogging = true;
           }
        */

        //if (scannerEvents.size()>=21760) extLogging = true;
        //if (scannerEvents.size()>=21421) extLogging = true;

        std::string inputFileNameAsTaken = *ifrnIt;
        std::string filename = *ifIt;


        #ifdef _DEBUG
        {
            bool bFound = false;
            for(std::vector<std::string>::const_iterator pfIt = processedFiles.begin(); pfIt!=processedFiles.end(); ++pfIt)
               {
                if (*pfIt==*ifIt) { bFound = true; break; }
               }
            if (!bFound)
               { 
                //std::cout<<"Not processed before: "<<*ifIt<<"\n";
               }
            //else
            //   std::cout<<"Allready processed  : "<<*ifIt<<"\n";
        }
        #endif

        srcFilesIds.insert((unsigned)processedFiles.size());

        #if defined(UNICODE) || defined(_UNICODE)
        MARTY_FILESYSTEM_NS handle_t hFile = MARTY_FILESYSTEM_NS openFile(MARTY_CON::strToWide(filename), MARTY_FILESYSTEM_NS o_rdonly );
        #else
        MARTY_FILESYSTEM_NS handle_t hFile = MARTY_FILESYSTEM_NS openFile(MARTY_CON::strToAnsi(filename), MARTY_FILESYSTEM_NS o_rdonly );
        #endif
        if (hFile==MARTY_FILESYSTEM_NS hInvalidHandle) 
           {
            #ifdef _DEBUG
            // for above std::cout<<"File: "<<*ifrnIt<<" - "<<*ifIt<<", scannerEvents: "<<(unsigned)scannerEvents.size();
            std::cout<<"\n";
            #endif
            continue; // report error
           }


        std::vector<CScannerEvent> localScannerEvents;
        CC2IdlScanner scanner(localScannerEvents, processedFiles, filename);
        scanner.options.noDefaultCppKeywords = true;
        cidl::registerCidlKeywords(scanner);

        //scanner.setDefaultPreprocessor();
        scanner.setPreprocessor(pMacroPreprocessor);
        scanner.getPreprocessor()->setIncludeFinder(&includeFinder);
        scanner.setErrorContext(&errContext);

        //filename
        //std::string incGuard = convertNameToMacro(forFile);
        //std::string thisFileProcessedMacro = ::std::string("_C2IDL_PROCESSING_") + ::cidl::genUtil::convertNameToMacro(inputFileNameAsTaken);
        //thisFileProcessedMacro.append("=1");

        //#ifdef _DEBUG
        //std::cout<<thisFileProcessedMacro<<"\n";
        //#endif

        //scanner.getPreprocessor()->addMacro(thisFileProcessedMacro);
        //scanner.getPreprocessor()->addMacro(::std::string("_COMPOWIZ_INVOKED=1")); // c2idl processing this file 
        //scanner.getPreprocessor()->addMacro(::std::string("_C2IDL_VER=100"));   // c2idl version - 1.00
        //scanner.getPreprocessor()->addMacro(::std::string("_C2IDL_OPTIONS=") + cmdOptions);

        #ifdef _DEBUG
        //if (extLogging)
        //   scanner.getPreprocessor()->dumpMacrosses(::std::cout);
        #endif

        unsigned totalReadedFromFile = 0;
        unsigned totalParsedFromFile = 0;
        bool parsingErr = false;
        char buf[4096];
        int readed = MARTY_FILESYSTEM_NS readFile(hFile, buf, sizeof(buf));
        while(readed>0 && !parsingErr)
           {
            totalReadedFromFile += (unsigned)readed;
            for(int i=0; i<readed && !parsingErr; ++i)
               {
                ++totalParsedFromFile;
                //int err = ;
                unsigned char ch = (unsigned char)buf[i];
                if (ch==(unsigned char)0xFF) ch = 0xDF; // bug with russian small YA - switch to capital YA
                if (!scanner.put(ch))
                   {
                    //std::cerr<<"Error: "<<scanner.getError()<<" - "<<scanner.getErrorStr()<<"\n";
                    //std::cerr<<errContext.formatError(scanner.getError());
                    #ifdef _DEBUG
                    std::cout<<"Scanner error: "<<scanner.getError()<<" - "<<scanner.getErrorStr()<<"\n";
                    std::cout<<errContext.formatError(scanner.getError());
                    #endif
                    //return 2;
                    parsingErr = true;
                    continue;
                   }
                #ifdef _DEBUG
                if (extLogging)
                   {
                    //std::cout<<"scannerEvents: "<<(unsigned)scannerEvents.size()<<", ch: ";
                    //if (ch<' ') std::cout<<"["<<(unsigned)ch<<"]";
                    //else        std::cout<<ch<<"";
                    //std::cout<<", state: "<<scanner.getStateCode()<<"\n";
                   }
                #endif
               }
            if (!parsingErr)
               readed = MARTY_FILESYSTEM_NS readFile(hFile, buf, sizeof(buf));
           }

        #ifdef _DEBUG
        //if (extLogging)
           {
            std::cout<<", localScannerEvents: "<<localScannerEvents.size()<<"\n";
           }
        #endif


        if (parsingErr)
           {
            #ifdef _DEBUG
            if (extLogging) std::cout<<"parsingErr\n";
            #endif
           }

        if (readed<=0)
           {
            #ifdef _DEBUG
            if (extLogging) std::cout<<"readed<=0\n";
            #endif
           }

        if (extLogging)
           {
            #ifdef _DEBUG
            std::cout<<"totalReadedFromFile: "<<totalReadedFromFile<<", totalParsedFromFile: "<<totalParsedFromFile<<"\n";
            #endif
           }

        scanner.put('\n');
        scanner.finalize();
        MARTY_FILESYSTEM_NS closeFile(hFile);

        if (!localScannerEvents.empty() && localScannerEvents.back().token==LT_END) 
           {
            localScannerEvents.erase(localScannerEvents.end()-1);
           }
        scannerEvents.insert( scannerEvents.end(), localScannerEvents.begin(), localScannerEvents.end() ) ;

        #ifdef _DEBUG

        if (extLogging)
           {
            //std::cout<<"localScannerEvents: "<<localScannerEvents.size()<<"\n";
            /*
            std::cout<<"---localScannerEvents\n";
            std::vector<CScannerEvent>::const_iterator lseIt = localScannerEvents.begin();
            for(; lseIt!=localScannerEvents.end(); ++lseIt)
               {
                std::cout<<"Event - token: "<<lseIt->token<<", text: ["<<lseIt->text<<"], at: "<<
                     CScannerErrorContext::formatFilePos( processedFiles[lseIt->filenameId], lseIt->startPos)<<"\n";
               }

            scanner.getPreprocessor()->dumpMacrosses(::std::cout);
            std::cout<<"-------\n";
            */
           }
        #endif

        scanner.releasePreprocessor();

        /*
        struct CCondition
        {
            bool               cond; // if false - all data ignored
            CConditionState    state;
            unsigned           filenameId;
            text_position_t    pos;
            CCondition(bool c, CConditionState s, int f, int p) : cond(c), state(s), filenameId(f), pos(p) {}
        };
        */

        if (pMacroPreprocessor->hasUnclosedConditions())
           {
            std::cout<<"! There is unclosed preprocessor directives:\n";
            std::vector<CCondition> cs;
            pMacroPreprocessor->getUnclosedConditions( cs );
            std::vector<CCondition>::const_iterator it = cs.begin();
            for(; it!=cs.end(); it++)
               {
                ::std::cout<<"    Mismatched endif for 'if' started at "<< CScannerErrorContext::formatFilePos( processedFiles[it->filenameId], it->pos)<<"\n";
               }
            pMacroPreprocessor->clearUnclosedConditions();
           }
       }

    delete pMacroPreprocessor;
    
    cidl::CCidlParserImpl parserImpl;
    parserImpl.resetAutomata( );
    parserImpl.pFiles = &processedFiles;

    parserImpl.setDoxyAliasises(doxyAliasises);
    parserImpl.setDoxyEnabledSections(enabledSections);
    parserImpl.setDoxyAutoBrief(doxyAutoBrief);

    #ifdef _DEBUG
    std::cout<<"Parsing files\n";
    #endif

    //unsigned curFileId
    //unsigned curFileId = (unsigned)-1;
    CScannerEvent prevEvent;
    prevEvent.filenameId = (unsigned)-1;

    
    std::vector<CScannerEvent>::const_iterator seIt = scannerEvents.begin();
    for( ; seIt!=scannerEvents.end(); ++seIt)
       {
        if (seIt->token==LT_END)
           {
            #ifdef _DEBUG
            //std::cout<<"LT_END ("<<seIt->text<<")\n";
            #endif
            continue; // don't process
           }
        parserImpl.putEvent(*seIt);
        //if (prevEvent.filenameId!=seIt->filenameId)
           {
            #ifdef _DEBUG
            /*
            std::cout<<"File: "<<CScannerErrorContext::formatFilePos( processedFiles[seIt->filenameId], seIt->curPos); // <<"\n";
            if (prevEvent.filenameId != (unsigned)-1)
               std::cout<<", "<<CScannerErrorContext::formatFilePos( processedFiles[prevEvent.filenameId], prevEvent.curPos); // <<"\n";
            std::cout<<"\n";
            */
            //std::cout<<seIt->text;
            #endif
            
            //prevEvent = *seIt;
           }

        if (parserImpl.isInFinalState()) 
           {
            //std::cerr<<parserImpl.errContext.formatError()<<"\nState: "<<parserImpl.getCurState()<<"\n";
            #ifdef _DEBUG
            std::cout<<"Parser error (1): "<<parserImpl.errContext.formatError()<<"\nState: "<<parserImpl.getCurState()<<"\n";
            std::cout<<"Scanner details:"
                     <<"\n   "<<CScannerErrorContext::formatFilePos( processedFiles[seIt->filenameId], seIt->startPos)
                     <<"\n   "<<CScannerErrorContext::formatFilePos( processedFiles[seIt->filenameId], seIt->curPos)
                     <<"\n";
            #endif
            //return errContext.errCode;
            //break;

            continue;
           }
       }
    if (seIt==scannerEvents.end())
       {
        #ifdef _DEBUG
        std::cout<<"End Of Data\n";
        #endif
        parserImpl.eod();
       }


    if (parserImpl.getCurState()!=cidl::CCidlParser::ST_eOk)
       {
        //std::cerr<<parserImpl.errContext.formatError()<<"\nState: "<<parserImpl.getCurState()<<"\n";
        #ifdef _DEBUG
        std::cout<<"Parser error (2): "<<parserImpl.errContext.formatError()<<"\nState: "<<parserImpl.getCurState()<<"\n";
        #endif
        //return errContext.errCode;
       }

    cidl::CIdl idl;

    idl.globalNs = parserImpl.nsInfo;

    ::doxy::CDoxydoc &doxyDoc = parserImpl.getDoc();

    ::std::vector<cidl::CNameDeclarationInfo> badTypes;    
    if (!idl.correctTypes(badTypes))
       {
        errContext.setBadTypesList(badTypes, &processedFiles);
        #ifdef _DEBUG
        std::cout<<"Bad types: "<<errContext.formatError()<<"\n";
        #endif
        //return errContext.errCode; //ERR_CIDL_BAD_TYPES;
       }

    idl.globalNs.splitProps(idl);

    struct CPrintInterface
    {
     void operator()(const ::std::string &nsName, const ::cidl::CInterfaceInfo &ifInfo )
        {
         #ifdef _DEBUG
         std::cout<<nsName<<"/"<<ifInfo.name<<"\n";
         #endif
        }
    };

    ::std::vector<::std::string> allInterfaces;

/*
    struct CCollectInterfaces
    {
         ::std::vector<::std::string> &allInterfaces;
         CCollectInterfaces( ::std::vector<::std::string> &ifs) : allInterfaces(ifs) {}
         void operator()(const ::std::string &nsName, const ::cidl::CInterfaceInfo &ifInfo )
            {
             allInterfaces.push_back( ::std::string("/") + nsName + ::std::string("/") + ifInfo.name );
            }
    };
*/

    //CPrintInterface prn;
    idl.globalNs.for_each_interface( CCollectInterfaces(allInterfaces) );
    ::std::sort(allInterfaces.begin(), allInterfaces.end() );

    #ifdef _DEBUG
    {
     //CCompowizOutput out;
     ::std::vector<::std::string>::const_iterator alIt = allInterfaces.begin();
     for(; alIt!=allInterfaces.end(); ++alIt)
        {
         std::cout<<*alIt<<"\n";
        }
    }
    #endif

    {
     bool hasError = false;
     CCompowizOutput out;
     ::std::vector<::std::string>::const_iterator alIt = selectedInterfaces.begin();
     for(; alIt!=selectedInterfaces.end(); ++alIt)
        {
         ::std::vector<::std::string>::const_iterator existingInterfaceIt = ::cli::util::binary_find( allInterfaces.begin(), allInterfaces.end(), *alIt );
         if (existingInterfaceIt==allInterfaces.end())
            {
             //#ifdef _DEBUG
             //std::cout<<"Interface '"<<*alIt<<"' taken as input not defined\n";
             //#endif
             out<<"Interface '"<<*alIt<<"' taken as input not defined\n";
             hasError = hasError||true; // return 0;
            }
        }

     //::std::vector<::std::string>::const_iterator 
     alIt = delegateInterfaces.begin();
     for(; alIt!=delegateInterfaces.end(); ++alIt)
        {
         ::std::vector<::std::string>::const_iterator existingInterfaceIt = ::cli::util::binary_find( allInterfaces.begin(), allInterfaces.end(), *alIt );
         if (existingInterfaceIt==allInterfaces.end())
            {
             //#ifdef _DEBUG
             //std::cout<<"Interface '"<<*alIt<<"' taken as input not defined\n";
             //#endif
             out<<"Interface '"<<*alIt<<"' taken as input for delegation not defined\n";
             hasError = hasError||true; // return 0;
            }
        }

     if (hasError) return 0;
    }

    //::doxy::CDoxydoc& doc = getDoc()

    /*

     { // print doc content
      struct CPrintDoxyContent
         {
          const ::doxy::CDoxydoc &dd;
          CPrintDoxyContent( const ::doxy::CDoxydoc &_dd) : dd(_dd) {}
          void operator()( std::ostream &os, const ::std::string &ind )
             {
              ::doxy::CDoxydoc::child_type_map::const_iterator typeIt = dd.typeBegin();
              for(; typeIt!=dd.typeEnd(); ++typeIt)
                 {
                  os<<ind<<typeIt->first<<"\n";
                  ::doxy::CDoxydoc::search_vector::const_iterator it = typeIt->second.begin();
                  for(; it!=typeIt->second.end(); ++it)
                     {
                      os<<ind<<"Key: "<< typeIt->second.key(it)<<"\n";
                      CPrintDoxyContent printer(*it);
                      printer( os, ind + ::std::string("    ") );
                     }
                 }

             }

         };

      CPrintDoxyContent printer(doxyDoc);
      printer( ::std::cout, ::std::string() );

     }


    doxy::CDoxydoc* pDd1 = doxyDoc.getElementByName("/cli/iUnknown");
    doxy::CDoxydoc* pDd2 = doxyDoc.getElementByName("/ns:cli/interface:iUnknown");

    */

    CComponentWizardInfo wizInfo;

    wizInfo.doxyDoc = doxyDoc;
    wizInfo.skipWelcomePage = !wizShowWelcome;
    wizInfo.setIdl(idl);
    wizInfo.setPreselectedInterfaces(selectedInterfaces);
    wizInfo.setDelegatedInterfaces(delegateInterfaces);
    
    wizInfo.allowSkipChooseGeneratorOptions = allowSkipChooseGeneratorOptions;

    wizInfo.checkOneOfIsIUnknown();

    wizInfo.generateMethods    = generateMethods  ; // prolog/epilog
    wizInfo.addQueryInterface  = addQueryInterface; // iUnknown support
    wizInfo.addDestroyMethod   = addDestroyMethod ;
    wizInfo.useRefCounting     = useRefCounting   ;

    if (className.empty())
       {
        wizInfo.className     = wizInfo.generateClassName();
        wizInfo.classNameAuto = true;
       }
    else
       {
        wizInfo.className     = className;
        wizInfo.classNameAuto = false;
       }

    //wizInfo.currentDir;
    MARTY_FILESYSTEM::getCurrentDirectory(wizInfo.currentDir);
    wizInfo.includePaths = includeFinder.getPathList();

    if (fileName.empty())
       {
        wizInfo.fileName     = wizInfo.generateFileName();
        wizInfo.fileNameAuto = true;
       }
    else
       {
        wizInfo.fileName     = fileName;
        wizInfo.fileNameAuto = false;
       }

    wizInfo.overwriteOutput = overwriteOutput;
    wizInfo.wizardStartPage = wizardStartPage;

    wizInfo.includeHeaders = includeHeaders;

    wizInfo.setGuiMode(guiMode);
        
    bool guiAllowContinue = true; // if no gui, continue always


    if (guiMode!=wiz::guiModeBatch)
       {
        #ifdef _WIN32
            HRESULT hRes = ::OleInitialize(NULL);
            ATLASSERT(SUCCEEDED(hRes));
        
            // this resolves ATL window thunking problem when Microsoft Layer for Unicode (MSLU) is used
            ::DefWindowProc(NULL, 0, 0, 0L);
        
            AtlInitCommonControls( ICC_WIN95_CLASSES | ICC_DATE_CLASSES | ICC_USEREX_CLASSES
                                 | ICC_COOL_CLASSES  | ICC_PAGESCROLLER_CLASS | ICC_NATIVEFNTCTL_CLASS
                                 );
        
            // We use a RichEdit control
            HINSTANCE hInstRich = ::LoadLibrary(CRichEditCtrl::GetLibraryName());
            ATLASSERT(hInstRich != NULL);
        
            #ifdef _DEBUG
            hRes = _Module.Init(NULL, (HINSTANCE)::GetModuleHandle(0) /* hInstance */ );
            #else
            hRes = _Module.Init(NULL, hInstance );
            #endif
            ATLASSERT(SUCCEEDED(hRes));
    
            CComponentWizardSheet wz(&wizInfo);
            INT_PTR result = wz.DoModal();
            if (!result)
               guiAllowContinue = false;
        
            ::FreeLibrary(hInstRich);
        
            _Module.Term();
            ::OleUninitialize();
        #endif
       }

    if (!guiAllowContinue) return 0;

    #ifdef _DEBUG
    //std::cout<<"Guard name: "<<wizInfo.generateFileNameForGuard()<<"\n";
    #endif

    //::std::map< ::std::string, std::string> codeBySignature;
    //::std::map< ::std::string, std::string> codeByName;

    if (createBakFile)
       {
        if (createBakFileName.empty())
           createBakFileName = wizInfo.fileName + ::std::string(".bak");
        #ifdef _WIN32
        ::CopyFile( wizInfo.fileName.c_str(), createBakFileName.c_str(), FALSE );
        #endif
       }

    ::std::ifstream ifs(wizInfo.fileName.c_str());
    readFunctionsCode( ifs, wizInfo.codeBySignature, wizInfo.codeByName );

    int genFlags = 0;
    ::cidl::CGeneratorFabriq generatorFabriq;

    ::std::string type = "component implementation skeleton";

    ::std::auto_ptr< ::cidl::CIGenerator> pGen(generatorFabriq.createGenerator("cpp_component_impl"));
    if (!pGen.get())
       {
        std::cout<<"Failed to generate "<<type<<" output, unknown output type\n";
       }

    cidl::CCppComponentImplGenerator *pComponentImplGen = dynamic_cast<cidl::CCppComponentImplGenerator*>(pGen.get());
    if (!pComponentImplGen)
       {
        std::cout<<"dynamic_cast failed\n";
       }
    else
       {
        pComponentImplGen->setGeneratorExInfo(&wizInfo);
       }

    ::std::ios_base::openmode oMode = ::std::ios_base::out; //  | ios_base::trunc  
    if (wizInfo.overwriteOutput) oMode |= ::std::ios_base::trunc;

    ::std::ofstream ofs(wizInfo.fileName.c_str(), oMode);
    if (!ofs)
       {
        std::cout<<"Failed to generate "<<type<<", can't open output file '"<<wizInfo.fileName<<"'\n";
       }

    ::cidl::CGenerationParams params(idl, parserImpl.getDoc(), srcFilesIds, processedFiles, genFlags);

    //if (!pGen->generate( ofs, wizInfo.fileName, params))
    if (!pGen->generate( ofs, wizInfo.generateFileNameForGuard(), params))
       {
        std::cout<<"Failed to generate "<<type<<"\n";
       }


/*
    CTestWizardSheet wizard(&m_testWizardInfo);
    INT_PTR result = wizard.DoModal();
    if(result == IDOK)
*/


    //::std::vector<::std::string>              selectedInterfaces;

    //::std::vector<::std::string>

    //::std::vector<::std::string>              selectedInterfaces;


    //iunknown.cidl

    //int getModuleFileName(ABSTRACT_MODULE_HANDLE handle, ::std::basic_string<CharType, Traits, Allocator> &retFileName)

/*
    MARTY_FILESYSTEM_NS handle_t 
    searchForStandartInclude( const MARTY_TCSTRING &includeFile, MARTY_TCSTRING &foundFilename )

                    std::string foundFilename;
                    MARTY_FILESYSTEM_NS handle_t hFoundFile = pIncludeFinder->searchForInclude( 
                                                                              pOwnerScanner->currentFileName,
                                                                              includeExpr,
                                                                              foundFilename   );
                    if (hFoundFile==MARTY_FILESYSTEM_NS hInvalidHandle) 
                       {

            char buf[4096];
            int readed = MARTY_FILESYSTEM_NS readFile(hFoundFile, buf, sizeof(buf));
            while(readed>0)
               {
                for(int i=0; i<readed; ++i)
                   {
                    unsigned char ch = (unsigned char)buf[i];
                    if (ch==0xFF) ch = 0xDF; // bug with russian small YA - switch to capital YA
                    if (!pScanner->put((unsigned char)ch))
                       {
                        pSavedOwner->errCode = pScanner->getError();
                        MARTY_FILESYSTEM_NS closeFile(hFoundFile);
                        pScanner->releasePreprocessor();
                        pOwnerScanner = pSavedOwner;

                        return pSavedOwner->errCode;
                        //std::cerr<<"Error: "<<scanner.getError()<<" - "<<scanner.getErrorStr()<<"\n";
                        //return 2;
                       }
                   }
                readed = MARTY_FILESYSTEM_NS readFile(hFoundFile, buf, sizeof(buf));
               }
    
            pScanner->finalize();
            MARTY_FILESYSTEM_NS closeFile(hFoundFile);
*/

    return 0;
   }



int read_config_file(const char* fname) 
{
 std::ifstream cfg(fname);
 std::string cfg_line;
 std::getline(cfg,cfg_line);
 //cfg_line = ::boost::algorithm::trim_copy(cfg_line); //trim(cfg_line);  
 //cfg_line = trim_copy(cfg_line); 
 trim(cfg_line);  

 if (!cfg_line.empty() && cfg_line[0]==_T('\"') && cfg_line[cfg_line.size()-1]==_T('\"'))
    { cfg_line.erase(cfg_line.size()-1); cfg_line.erase(0, 1); }

 //trim(cfg_line);
 while(cfg && cfg_line.size())
   {
      int pr = 0;
      switch(cfg_line[0])
        {
         case _T('\"'):
         case _T('-'):
         case _T('/'):
                    #if defined(UNICODE) || defined(_UNICODE)
                    pr = parse_option(MARTY_CON::strToWide(cfg_line).c_str());
                    #else
                    pr = parse_option(MARTY_CON::strToAnsi(cfg_line).c_str());
                    #endif
                    break;

//         case '@':  pr = read_config_file(argv[i]+1);
//                    break;
         //default:   //std::string infile = cfg_line;
                    //infile = trim(infile);
                    //if (infile.size())
                    //   input_files.push_back(infile);
        };
//    int pr = parse_option(cfg_line.c_str());
    if (pr) return pr;
    std::getline(cfg,cfg_line);
    //cfg_line = ::boost::algorithm::trim_copy(cfg_line); //trim(cfg_line);  
    //cfg_line = trim_copy(cfg_line);
    trim(cfg_line);

    if (!cfg_line.empty() && cfg_line[0]==_T('\"') && cfg_line[cfg_line.size()-1]==_T('\"'))
       { cfg_line.erase(cfg_line.size()-1); cfg_line.erase(0, 1); }

    //trim(cfg_line);

   }
 return 0;
}

int parse_option(tstring str)
{
 tstring::iterator s = str.begin();
 if (!str.empty() && str[0]==_T('\"') && str[str.size()-1]==_T('\"'))
    {
     str.erase(str.size()-1);
     s = str.begin();
     ++s;
    }

 //if (str.size()<2)
 //   std::cout<<"Invalid command line option: '"<<str<<"'\n";

 if (*s!=_T('-') && *s!=_T('/'))
    {
     //std::cout<<"Invalid command line option: '"<<str<<"'\n";
     return 1;
    }

// if (cmdOptions.empty()) cmdOptions.append(1, ' ');
// cmdOptions.append(str);

 char key = *((++s)++);

 switch(key)
   {
    case 'I':
             {
              ::std::string pathList(s,str.end());
              if (pathList.empty())
                 includeFinder.clearPaths();
              else
                 includeFinder.addPathList(::std::string(s,str.end()));
             }
             break;

    case 'G': 
             break;

    case 'b':
             createBakFile = true;
             createBakFileName = ::std::string(s,str.end());
             break;             

    case 'c': 
             {
              char ch = *s;
              ++s;
              allowSkipChooseGeneratorOptions = true;
              switch(ch)
                 {
                  case 'd': // delegateInterfaces
                           splitSemicolonList( ::std::string(s,str.end()), delegateInterfaces );
                           break;

                  case 'i': 
                           {
                            ::std::string addInclude(s,str.end());
                            if (addInclude.empty())
                               includeHeaders.clear();
                            else
                               includeHeaders.push_back(::std::string(s,str.end()));
                            break;
                           }
                 }
             }
             break;

    case 'g': 
             {
              char ch = *s;
              ++s;
              allowSkipChooseGeneratorOptions = true;
              switch(ch)
                 {
                  case 'm': if (s==str.end() || *s=='+') generateMethods = true;
                            else generateMethods = false;
                            break;

                  case 'u': if (s==str.end() || *s=='+') addQueryInterface = true;
                            else addQueryInterface = false;
                            break;

                  case 'd': if (s==str.end() || *s=='+') addDestroyMethod = true;
                            else addDestroyMethod = false;
                            break;

                  case 'r': if (s==str.end() || *s=='+') useRefCounting = true;
                            else useRefCounting = false;
                            break;

                  case 'c': className.assign(s,str.end());
                            break;

                  case 'f': fileName.assign(s,str.end());
                            break;

                  case 'o': if (s==str.end() || *s=='+') overwriteOutput = true;
                            else overwriteOutput = false;
                            break;
                 }
              break;
             }

    case 'e':
             excludedFiles.insert( MARTY_FILENAME_NS makeCanonical(::std::string(s,str.end())) );
             break;

    case 'Z':
             {
              char ch = *s;
              ++s;
              switch(ch)
                 {
                  case 'w': wizShowWelcome = false; break;
                  case 'p':
                           {
                            ::std::string strStartPage(s,str.end());
                            if (strStartPage=="welcome")
                               wizardStartPage = IDD_COMPOWIZ_WELCOME;
                            else if (strStartPage=="interfaces")
                               wizardStartPage = IDD_COMPOWIZ_INTERFACES_LIST;
                            else if (strStartPage=="order")
                               wizardStartPage = IDD_COMPOWIZ_INTERFACE_ORDER;
                            else if (strStartPage=="delegate")
                               wizardStartPage = IDD_COMPOWIZ_INTERFACE_DELEGATES;
                            else if (strStartPage=="options")
                               wizardStartPage = IDD_COMPOWIZ_GENERATOR_OPTIONS;
                            else if (strStartPage=="classname")
                               wizardStartPage = IDD_COMPOWIZ_ENTER_CLASSNAME;
                            else if (strStartPage=="filename")
                               wizardStartPage = IDD_COMPOWIZ_ENTER_FILENAME;
                            else if (strStartPage=="completion")
                               wizardStartPage = IDD_COMPOWIZ_COMPLETION;
                            //else if (strStartPage=="")
                            //   wizardStartPage = 
                            else
                               {
                                std::cout<<"Unknown command line option: '-"<<str<<"'\n";
                                print_help();
                                return 2;
                               }
                           }
                           break;
                  default:  
                            std::cout<<"Unknown command line option: '-"<<str<<"'\n";
                            print_help();
                            return 2;
                 };
             }             
             break;

    case 'm':
             {
              char ch = *s;
              ++s;
              switch(ch)
                 {
                  case 'a': guiMode = wiz::guiModeShowAll; break;
                  case 'r': guiMode = wiz::guiModeShowRequired; break;
                  case 'b': guiMode = wiz::guiModeBatch; break;
                  default:  
                            std::cout<<"Unknown command line option: '-"<<str<<"'\n";
                            print_help();
                            return 2;
                 };
             }

    case 'i':
             splitSemicolonList( ::std::string(s,str.end()), selectedInterfaces );
             break;

    case 'D': 
             {
              char ch = *s;
              ++s;
              /*
              if (s==str.end()) 
                 {
                  break; 
                  std::cout<<"Invalid command line option: '"<<str<<"'\n";
                 }
              */
              switch(ch)
                 {
                  case 'A': addDoxyAlias(::std::string(s,str.end())); break;
                  case 'S': addDoxyEnabledSection(::std::string(s,str.end())); break;
                  case 'b': 
                            if (s==str.end()) 
                               doxyAutoBrief = true;
                            else if (*s=='-')
                               doxyAutoBrief = false;
                            else
                               doxyAutoBrief = true;
                            break;

                  default:  
                            std::cout<<"Unknown command line option: '-"<<str<<"'\n";
                            print_help();
                            return 2;
                 }
             } break;

    case '?': 
    case 'h': 
              print_help();
              return 3;              

    default:  
              //std::cout<<"Unknown command line option: '-"<<str<<"'\n";
              print_help();
              return 2;
   };
// macro_adddef("CMDOPTION", "", std::string(--s) + std::string(" "), "cmd_line", 0, 1);
 return 0;
}


//-----------------------------------------------------------------------------
void print_help()
{
#ifdef _DEBUG
 std::cout<<"c2idl - cli2 interface definition language compiler\n";
 std::cout<<"Usage: c2idl [-option [-option]] file1 file2 ...\n";
 std::cout<<"Options:\n";
 std::cout<<"  -I                - clear INCLUDE path.\n";
 std::cout<<"  -IPathList        - semicolon separated INCLUDE path list.\n";
 std::cout<<"  -iInterfacesList  - semicolon separated list of interfaces to be implemented.\n";
 std::cout<<"  -mX               - set GUI mode, X can be one of:\n";
 std::cout<<"                      a - show all dialogs\n";
 std::cout<<"                      r - show only required dialogs\n";
 std::cout<<"                      b - batch mode, don't show any dialogs\n";

// std::cout<<"                      \n";
 std::cout<<"  -efile            - exclude file from processing\n";
 std::cout<<"                      file name must be in form relative from include folder root path\n";
 std::cout<<"  -dN               - detail level 0-9.\n";
 std::cout<<"                      '+' sign threated as 9, '-' sign as 0.\n";
 std::cout<<"  -DX               - documentation parser options, X can be one of:\n";
 std::cout<<"                      Acmd=\\subst       - add doc command alias NAME\n";
 std::cout<<"                      Ssec               - enable section sec\n";
 std::cout<<"                      b[+|-]             - doc autobrief on|off, default - on\n";
 std::cout<<"  -ZX               - GUI wizard options, X can be one of:\n";
 std::cout<<"                      w - skip welcome page\n";
 std::cout<<"                      pname - set start page to name, name can be one of:\n";
 std::cout<<"                              welcome    - opens wizard \"Welcome\" page\n";
 std::cout<<"                              interfaces - opens wizard \"Select interfaces to implement\"page\n";
 std::cout<<"                              order      - opens wizard \"Select interface inheritance order\"page\n";
 std::cout<<"                              delegate   - opens wizard \"Select interfaces to delegate\" page\n";
 std::cout<<"                              options    - opens wizard \"Select generation options\" page\n";
 std::cout<<"                              classname  - opens wizard \"Component class name\" page\n";
 std::cout<<"                              filename   - opens wizard \"Select output file\" page\n";
 std::cout<<"                              completion - opens wizard \"Completing CLI Component Wizard\" page\n";
 //std::cout<<"                              \n";
 std::cout<<"  -gX               - Code generation options, X can be one of:\n";
 std::cout<<"                      m[+|-]  - generate methods prologue/code/epilogue on/off\n";
 std::cout<<"                      u[+|-]  - add queryInterface (iUnknown support) on/off\n";
 std::cout<<"                      d[+|-]  - add destroy on/off\n";
 std::cout<<"                      r[+|-]  - use (or not use) reference counting on/off\n";
 std::cout<<"                      cName   - set component class name to Name\n";
 std::cout<<"                      fFile   - set output file\n";
 std::cout<<"                      o[+|-]  - overwrite output file on/off\n";
 std::cout<<"  -cX               - More code generation options, X can be one of:\n";
 std::cout<<"                      i       - clear common includes\n";
 std::cout<<"                      ifile   - add common include #include <file> into generated code\n";
 std::cout<<"                      dIfList - semicolon separated list of interfaces to be delegated\n";
 std::cout<<"  -bfilename        - create *.bak file 'filename'.\n";
 std::cout<<"                      if filename is empty, name construction based on output file name\n";



// std::cout<<"                      - \n";

 //std::cout<<"                  \n";
#endif
}



