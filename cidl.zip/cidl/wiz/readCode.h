#ifndef SRC_CIDL_WIZ_READCODE_H
#define SRC_CIDL_WIZ_READCODE_H


#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif


void readFunctionsCode( ::std::istream &in
                      , ::std::map< ::std::string, std::string> &bySignature
                      , ::std::map< ::std::string, std::string> &byName
                      );

#endif /* SRC_CIDL_WIZ_READCODE_H */

