#ifndef CGDOCBASE_H
#define CGDOCBASE_H

#ifndef CIDL_STRUCTS_ALLOW_USE_IOSTREAM
    #define CIDL_STRUCTS_ALLOW_USE_IOSTREAM 1
#endif

#include "cidlGen.h"
#include "doxy.h"

namespace cidl
{

class CDocBaseGenerator : public CIGenerator
{

    public:


};







}; // namespace cidl



#endif /* CGDOCBASE_H */

