#ifndef CIDL_STRUCTS_ALLOW_USE_IOSTREAM
    #define CIDL_STRUCTS_ALLOW_USE_IOSTREAM 1
#endif

#include "cidlGen.h"

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#ifndef MARTY_FILESYS_H
    #include <marty/filesys.h>
#endif

#ifndef MARTY_LIBAPI_H
    #include <marty/libapi.h>
#endif

#include "cgCpp.h"
#include "cgUdf.h"
#include "cgCppDecl.h"
#include "cgCppImpl.h"

#ifndef CIDL_CIDLCONFIG_H
    #include "cidlconfig.h"
#endif



namespace cidl
{

//-----------------------------------------------------------------------------
CIMethodGenerator::~CIMethodGenerator()
   {}

//-----------------------------------------------------------------------------
CIGenerator::~CIGenerator()
   {}

//-----------------------------------------------------------------------------
bool CIGenerator::generate( ::std::ostream             &os
                          , const ::std::string        &outputFilename
                          , const CGenerationParams    &genParams
                          )
   {
    return true;
   }

//-----------------------------------------------------------------------------
bool CIGenerator::findAllInterfaces( const ::cidl::CInterfaceInfo &ifInfo
                      , const ::std::string &fullIfName
                      , const ::cidl::CIdl &idl
                      , ::std::vector< ::std::string > &ifs
                      )
   {
    ::std::set< ::std::string> allreadyScannedInterfaces;

    // scan base interfaces for they's methods
    if (!findAllInterfacesAux( ifInfo, idl, ifs, allreadyScannedInterfaces ))
       return false;

    ifs.push_back(fullIfName);

    return true;
   }

//-----------------------------------------------------------------------------
bool CIGenerator::findAllInterfacesAux( const ::cidl::CInterfaceInfo &ifInfo
                         , const ::cidl::CIdl &idl
                         , ::std::vector< ::std::string > &ifs
                         , ::std::set< ::std::string> &allreadyScannedInterfaces
                         )
   {
    ::std::vector< ::std::string >::const_iterator elIt = ifInfo.extendsList.begin();

    // scan base interfaces for they's methods
    for(; elIt!=ifInfo.extendsList.end(); ++elIt)
       {
        if (allreadyScannedInterfaces.find(*elIt)!=allreadyScannedInterfaces.end())
           {
            #ifndef CIDL_MULTIPLE_EXTENDS_ALLOWED
            std::cout<<"Interface '"<<*elIt<<"' allready used as base interface\n";
            return false;
            #else
            continue;
            #endif
           }
        allreadyScannedInterfaces.insert(*elIt);
        ifs.push_back(*elIt);

        const CInterfaceInfo* pIf = idl.findInterface(*elIt);
        if (!pIf)
           {
            std::cout<<"Interface '"<<*elIt<<"' definition not found in processed files\n";
            return false;
           }

        ifs.push_back(*elIt);

        if (!findAllInterfacesAux( *pIf, idl, ifs, allreadyScannedInterfaces ))
           return false;
       }

    return true;   
   }

//-----------------------------------------------------------------------------
bool CIGenerator::findAllMethods( const ::cidl::CInterfaceInfo &ifInfo
                                      , const ::std::string &fullIfName
                                      , const ::cidl::CIdl &idl
                                      , ::std::vector< ::cidl::CInterfaceEntry > &methods
                                      )
   {
    ::std::set< ::std::string> allreadyScannedInterfaces;

    // scan base interfaces for they's methods
    if (!findAllMethodsAux( ifInfo, fullIfName, idl, methods, allreadyScannedInterfaces ))
       return false;

    return true;
   }
//-----------------------------------------------------------------------------
bool CIGenerator::findAllMethodsAux( const ::cidl::CInterfaceInfo &ifInfo
                                      , const ::std::string &fullIfName
                                      , const ::cidl::CIdl &idl
                                      , ::std::vector< ::cidl::CInterfaceEntry > &methods
                                      , ::std::set< ::std::string> &allreadyScannedInterfaces
                                      )
   {
    ::std::vector< ::std::string >::const_iterator elIt = ifInfo.extendsList.begin();

    // scan base interfaces for they's methods
    for(; elIt!=ifInfo.extendsList.end(); ++elIt)
       {
        if (allreadyScannedInterfaces.find(*elIt)!=allreadyScannedInterfaces.end())
           {
            #ifndef CIDL_MULTIPLE_EXTENDS_ALLOWED
            std::cout<<"Interface '"<<*elIt<<"' allready used as base interface\n";
            return false;
            #else
            continue;
            #endif
           }
        allreadyScannedInterfaces.insert(*elIt);

        const CInterfaceInfo* pIf = idl.findInterface(*elIt);
        if (!pIf)
           {
            std::cout<<"Interface '"<<*elIt<<"' definition not found in processed files\n";
            return false;
           }

        if (!findAllMethodsAux( *pIf, *elIt, idl, methods, allreadyScannedInterfaces ))
           return false;
        /*
        ::std::vector< CInterfaceEntry >::const_iterator ifEntryIt = pIf->methods.begin();
        for(; ifEntryIt!=pIf->methods.end(); ++ifEntryIt)
           {
            CInterfaceEntry ie = *ifEntryIt;
            ie.originalIfName = *elIt;
            methods.push_back(ie);
           }
        */
       }

    // scan current interface for it's methods
    ::std::vector< CInterfaceEntry >::const_iterator  ifEntryIt = ifInfo.methods.begin();
    for(; ifEntryIt!=ifInfo.methods.end(); ++ifEntryIt)
       {
        CInterfaceEntry ie = *ifEntryIt;
        ie.originalIfName = fullIfName;
        methods.push_back(ie);
       }
    return true;
   }


//-----------------------------------------------------------------------------
bool CIGenerator::findAllParamInterfaces( const ::cidl::CIdl &idl
                                              , const ::std::vector< ::cidl::CInterfaceEntry > &methods
                                              , ::std::map< ::std::string, ::std::set< ::std::string > > &paramIfs
                                              )
   {
    ::std::vector< ::cidl::CInterfaceEntry >::const_iterator mit = methods.begin();
    for(; mit!=methods.end(); ++mit)
       {
        if (mit->fProperty) continue;

        // mit->methodInfo.type ret type
        {
         ::std::string pureType = idl.getPureTypeName(mit->methodInfo.type);
         if (idl.isInterface(pureType))
            {
             ::std::string ns, iface;
             if (!splitFqName(pureType, ns, iface))
                {
                 std::cout<<"Invalid type: "<<pureType<<"\n";
                 return false;
                }
             paramIfs[ns].insert(iface);
            }
        }

        ::std::vector< CParameter >::const_iterator paramIt = mit->methodInfo.parameters.begin();
        for(; paramIt!=mit->methodInfo.parameters.end(); ++paramIt)
           {
            ::std::string pureType = idl.getPureTypeName(paramIt->type);
            if (idl.isInterface(pureType))
               {
                ::std::string ns, iface;
                if (!splitFqName(pureType, ns, iface))
                   {
                    std::cout<<"Invalid type: "<<pureType<<"\n";
                    return false;
                   }
                paramIfs[ns].insert(iface);
               }
           }
       }
    return true;
   }

//-----------------------------------------------------------------------------
void CIGenerator::tplLinesToDoxyItems( const ::std::vector< ::std::string > &lines
                                     , ::std::vector< ::doxy::CDoxyCommentItem > &doxyItems
                                     )
   {
    genUtil::CDoxyTagsCondTokeniser tokeniser;
    ::std::vector< ::std::string >::const_iterator lit = lines.begin();
    for(; lit!=lines.end(); ++lit)
       {
        if (!doxyItems.empty())
           {
            //doxyItems.push_back( ::doxy::CDoxyCommentItem( ::std::string("\n"), DT_LINEFEED) );
           }

        ::std::string s = genUtil::trim_copy(*lit);
        if (!s.empty() && (s[0]=='@' || s[0]=='\\'))
           {
            splitStringDoxyAux( tokeniser, s, 0, doxyItems );
           }
        else
           {
            doxyItems.push_back( ::doxy::CDoxyCommentItem(*lit, DT_NONE) );
           }
       }
   }

/*
struct CDoxyCommentItem
{
int                             type; // 0 - no a doxy tag, 1 - linefeed
::std::string                   text;
::std::vector< ::std::string >    params;
*/

//-----------------------------------------------------------------------------
bool CIGenerator::printCppNamespaceOpen( ::std::ostream &os, const ::std::string &_indent, const ::std::string &ns, ::std::vector< ::std::string > &closeReverseOrder, bool noMoreIndent)
   {
    ::std::vector< ::std::string > openOrder;
    if (!splitFqName(ns, openOrder) && ns!= ::std::string("::"))
       {
        std::cout<<"Invalid namespace: "<<ns<<"\n";
        return false;
       }

    ::std::string indent = _indent;
    ::std::vector< ::std::string >::const_iterator it = openOrder.begin();
    for(; it!=openOrder.end(); ++it)
       {
        if (it->empty()) continue;
        os<<indent<<"namespace "<<*it<<" {\n";
        closeReverseOrder.push_back(*it);
        if (!noMoreIndent)
           indent.append(4, ' ');
       }
    return true;
   }

//-----------------------------------------------------------------------------
bool CIGenerator::printCppNamespaceClose( ::std::ostream &os, const ::std::string &indent, const ::std::vector< ::std::string > &closeReverseOrder, bool noMoreIndent)
   {
    ::std::vector< ::std::string >::const_reverse_iterator it = closeReverseOrder.rbegin();
    for(; it!=closeReverseOrder.rend(); ++it)
       {
        if (it->empty()) continue;
        if (noMoreIndent) // os<<indent<<"}; /* namespace "<<*it<<" */\n";
           os<<indent<<"}; // namespace "<<*it<<"\n";
        else
           os<<indent<< ::std::string((closeReverseOrder.size() - (it - closeReverseOrder.rbegin()) - 1)*4, ' ')<<"}; // namespace "<<*it<<"\n";
       }
    return true;   
   }

//-----------------------------------------------------------------------------
bool CIGenerator::printCppEnumValueXX( ::std::ostream &os
                                     , const ::std::string &valName
                                     , const ::std::string &valVal
                                     , const ::std::string &enumName
                                     , ::std::string &valAllreadyDefined
                                     , const ::std::vector< ::std::string > *pAliasises
                                     , const CPodInfo* enumPod
                                     , ::std::set< ::std::string > &allreadyDefinedEnumVals
                                     , const ::std::string &indent
                                     ) const
   {
    if (allreadyDefinedEnumVals.find(valName)!=allreadyDefinedEnumVals.end())
       {
        valAllreadyDefined = valName; return false;
       }
    allreadyDefinedEnumVals.insert(valName);

    if (enumPod)
       {
        if (!valVal.empty() && valVal[0]>='0' && valVal[0]<='9') os<<indent<<"const "<<enumPod->type<<" "<<genUtil::width(valName, 16)<<" = CONSTANT_"<<enumPod->type<<"("<<valVal<<")";
        else                                                     os<<indent<<"const "<<enumPod->type<<" "<<genUtil::width(valName, 16)<<" = "<<valVal;
       }
    else
       {
        //if (vit!=enumInfo.vals.begin()) os<<",";
        //os<<"\n"<<ind2;
        os<<indent<<genUtil::width(enumName + ::std::string(1, '_') + valName, 16)<<" = "<<valVal;
       }

    if (!pAliasises) return true;

    const ::std::vector< ::std::string > &aliasises = *pAliasises;
    ::std::vector< ::std::string >::const_iterator ait = aliasises.begin();
    for(; ait!=aliasises.end(); ++ait)
       {
        if (enumPod) os<<";\n";
        else         os<<",\n";
        if (!printCppEnumValueXX( os, *ait, valVal, enumName, valAllreadyDefined
                                    , 0, enumPod, allreadyDefinedEnumVals, indent
                                ))
           return false;
       }

    return true;
   }

//-----------------------------------------------------------------------------
bool CIGenerator::printCppEnumValueDefine( ::std::ostream &os
                                         , const ::std::string &enumName
                                         , const ::std::string &valName
                                         , const ::std::string &valVal
                                         , ::std::string &valAllreadyDefined
                                         , const ::std::vector< ::std::string > *pAliasises
                                         , const CPodInfo* enumPod
                                         , ::std::set< ::std::string > &allreadyDefinedEnumVals
                                         , const ::std::string &indent
                                         , bool addIfdef
                                         ) const
   {
    if (allreadyDefinedEnumVals.find(valName)!=allreadyDefinedEnumVals.end())
       {
        valAllreadyDefined = valName; return false;
       }

    allreadyDefinedEnumVals.insert(valName);

    ::std::string enumValFullName = enumName; 
    enumValFullName.append(2, ':');
    enumValFullName.append(valName);
    ::std::string macroName = convertNameToMacro(getNameAsOneIdent(enumValFullName));
    //::std::string::size_type macroNameFieldMaxLen = 32;
    if (addIfdef)
       os<<indent<<"#ifndef "<<macroName<<"\n";

    os<<indent<<(addIfdef?"    ":"")<<"#define "<<genUtil::width(macroName, 32)<<"  ";
    if (enumPod && !valVal.empty() && valVal[0]>='0' && valVal[0]<='0')
       {
        os<<"CONSTANT_"<<enumPod->type<<"("<<valVal<<")\n";
       }
    else
       {
        os<<valVal<<"\n";
       }

    if (addIfdef)
       os<<indent<<"#endif /* "<<macroName<<" */\n\n";

    if (!pAliasises) return true;

    const ::std::vector< ::std::string > &aliasises = *pAliasises;
    ::std::vector< ::std::string >::const_iterator ait = aliasises.begin();
    for(; ait!=aliasises.end(); ++ait)
       {
        if (!printCppEnumValueDefine( os, enumName, *ait, valVal, valAllreadyDefined
                                    , 0, enumPod, allreadyDefinedEnumVals, indent, addIfdef
                                    ))
           return false;
       }

    return true;
   }

//-----------------------------------------------------------------------------
bool CIGenerator::printCppEnumDefines( ::std::ostream &os
                                     , const ::std::string  &enumIdentName
                                     , const CEnumeration &enumInfo
                                     , const CPodInfo* enumPod
                                     , const ::std::string &indent
                                     , bool addIfdef
                                     )
   {
    if (addIfdef)
       {
        ::std::string enumDefineName = "ENUM_";
        enumDefineName.append(convertNameToMacro(getNameAsOneIdent(enumIdentName)));

        os<<indent<<"#if defined(__cplusplus) && !defined(CINTERFACE)\n";

        if (!enumPod) os<<indent<<"    #define "<<genUtil::width(enumDefineName, 32)<<"    "<<enumIdentName<<"\n";
        else          os<<indent<<"    #define "<<genUtil::width(enumDefineName, 32)<<"    "<<enumPod->type<<"\n";

        os<<indent<<"#else\n";

        if (!enumPod) os<<indent<<"    #define "<<genUtil::width(enumDefineName, 32)<<"    "<<getNameAsOneIdent(enumIdentName)<<"\n";
        else          os<<indent<<"    #define "<<genUtil::width(enumDefineName, 32)<<"    "<<enumPod->type<<"\n";

        os<<indent<<"#endif\n\n";
       }

    if (addIfdef)
       os<<indent<<"/* defines allowed both for C and C++ */\n\n";

    ::std::set< ::std::string > allreadyDefinedEnumVals;
    ::std::vector<CEnumValue>::const_iterator vit = enumInfo.vals.begin();
    for(; vit!=enumInfo.vals.end(); ++vit)
       {
        ::std::string valAllreadyDefined;
        if (!printCppEnumValueDefine( os, enumIdentName, vit->name, vit->val, valAllreadyDefined
                                    , &vit->extAttrs.aliasises, enumPod, allreadyDefinedEnumVals, indent, addIfdef
                                    ))
           {
            std::cout<<"Enum '"<<enumIdentName<<"' - enum value (or alias) '"<<valAllreadyDefined<<"' allready defined.\n";
            return false;
           }
       }
    os<<"\n";
    return true;
   }

//-----------------------------------------------------------------------------
bool CIGenerator::printCppEnumXX( ::std::ostream &os
                                , const ::std::string  &enumIdentName
                                , const CEnumeration &enumInfo
                                , const CPodInfo* enumPod
                                , const ::std::string &__indent
                                , bool addIfdef
                                )
   {
    if (addIfdef)
       os<<__indent<<"#if defined(__cplusplus) && !defined(CINTERFACE)\n\n";

    ::std::string nsFullName, enumPlainName;
    splitFqName(enumIdentName, nsFullName, enumPlainName);

    ::std::string _indent = __indent;
    if (addIfdef) _indent.append( ::std::string::size_type(4), ' ');
    
    ::std::vector< ::std::string > closeReverseOrder;
    if (!printCppNamespaceOpen(os, _indent, enumPod ? enumIdentName : nsFullName, closeReverseOrder))
       return false;

    std::ostringstream pcSS;

    ::std::string indent((closeReverseOrder.size())*4, ' ');
    indent.append(_indent);

    if (!enumPod)
       {
        os  <<indent<<"enum "<<enumInfo.name<<" {\n";
        pcSS<<indent<<"enum "<<getNameAsOneIdent(enumIdentName)<<" {\n";
       }

    ::std::string ind2 = indent;
    ind2.append(4, ' ');

    ::std::set< ::std::string > allreadyDefinedEnumVals, allreadyDefinedEnumVals2;
    ::std::vector<CEnumValue>::const_iterator vit = enumInfo.vals.begin();
    for(; vit!=enumInfo.vals.end(); ++vit)
       {
        if (vit!=enumInfo.vals.begin())
           {
            if (enumPod) { os<<";\n"; pcSS<<";\n"; }
            else         { os<<",\n"; pcSS<<",\n";   }
           }

        ::std::string valAllreadyDefined;
        if (!printCppEnumValueXX( os, vit->name, vit->val, enumInfo.name, valAllreadyDefined
                                    , &vit->extAttrs.aliasises, enumPod, allreadyDefinedEnumVals, ind2
                                    ))
              {
               std::cout<<"Enum '"<<enumIdentName<<"' - enum value (or alias) '"<<valAllreadyDefined<<"' allready defined.\n";
               return false;
              }
        if (!printCppEnumValueXX( pcSS, vit->name, vit->val, getNameAsOneIdent(enumIdentName), valAllreadyDefined
                                    , &vit->extAttrs.aliasises, enumPod, allreadyDefinedEnumVals2, ind2
                                    ))
              {
               std::cout<<"Enum '"<<enumIdentName<<"' - enum value (or alias) '"<<valAllreadyDefined<<"' allready defined.\n";
               return false;
              }
       }
    if (enumPod) { os<<";\n"; pcSS<<";\n"; }


    if (!enumPod)
        {
         os  <<"\n"<<indent<<"};";
         pcSS<<"\n"<<indent<<"};";
         if (addIfdef)
            {
             os  <<" /* enum "<<enumInfo.name<<" */";
             pcSS<<" /* enum "<<enumInfo.name<<" */";
            }
         os  <<"\n";
         pcSS<<"\n";
        }

    if (!printCppNamespaceClose( os, _indent, closeReverseOrder))
       return false;

    {
     os<<_indent<<"/* ";
     if (enumPod)
        os<<"using namespace ";

     ::std::vector< ::std::string >::const_iterator it = closeReverseOrder.begin();
     for( ;it!=closeReverseOrder.end(); ++it)
        {
         os<<"::"<<*it;
        }
     if (!enumPod)
        {
         os<<"::"<<enumInfo.name;
        }
     os<<"; */\n";
    }
    

    if (addIfdef)
       {
        if (!enumPod)
           { 
            os<<_indent<<"\n#else\n\n";
            os<<pcSS.str();
           }
        os<<_indent<<"\n#endif\n\n";
       }

    return true;
   }

//-----------------------------------------------------------------------------
bool CIGenerator::printCppInterfaceNameDefine( ::std::ostream &os
                                             , const ::std::string  &ifIdentName
                                             , const ::std::string &_indent
                                             , bool bCpp
                                             , bool addIfdef
                                             )
   {
    ::std::string ifDefineName("INTERFACE_");
    ifDefineName.append(convertNameToMacro(getNameAsOneIdent(ifIdentName)));

    ::std::string ifLangName = bCpp ? ifIdentName : getNameAsOneIdent(ifIdentName);

    ::std::string indent = _indent; 
    if (addIfdef)
       indent.append(4, ' ');
    
    if (addIfdef)
       os<<_indent<<"#ifndef "<<ifDefineName<<"\n";
    os<<indent<<"#define "<<genUtil::width(ifDefineName, 32)<<"  "<<ifLangName<<"\n";
    if (addIfdef)
       os<<_indent<<"#endif\n";
    os<<"\n";

    return true;
   }
//-----------------------------------------------------------------------------
bool CIGenerator::printCppStructNameDefine( ::std::ostream &os 
                                          , const ::std::string  &structIdentName
                                          , const ::std::string &_indent
                                          , bool bCpp
                                          , bool bStruct
                                          , bool addIfdef
                                          , bool bStructIsUnion
                                          )
   {
    ::std::string structDefineName(bStruct ? (bStructIsUnion ? "UNION_" : "STRUCT_") : "INTERFACE_");
    structDefineName.append(convertNameToMacro(getNameAsOneIdent(structIdentName)));

    ::std::string structLangName = bCpp ? structIdentName : getNameAsOneIdent(structIdentName);
    ::std::string structTag = bCpp ? "" : (bStructIsUnion ? "union tag_" : "struct tag_");

    ::std::string indent = _indent; 
    if (addIfdef)
       indent.append(4, ' ');

    if (addIfdef)
       os<<_indent<<"#ifndef "<<structDefineName<<"\n";
    os<<indent<<"#define "<<genUtil::width(structDefineName, 32)<<"  "<<structTag<<structLangName<<"\n";
    if (addIfdef)
       os<<_indent<<"#endif\n";
    os<<"\n";
    return true;
   }



bool CIGenerator::printCppStructNameDefines( ::std::ostream &os
                              , const ::std::string  &structIdentName
                              , const CStruct &structInfo
                              , const ::std::string &_indent
                              , bool bCpp
                              , bool addIfdef
                              , bool bStructIsUnion
                              )
   {
    ::std::string structDefineName(bStructIsUnion ? "UNION_" : "STRUCT_");
    structDefineName.append(convertNameToMacro(getNameAsOneIdent(structIdentName)));

    ::std::string structLangName = bCpp ? structIdentName : getNameAsOneIdent(structIdentName);
    ::std::string structTag = bCpp ? "" : (bStructIsUnion ? "struct tag_" : "struct tag_");

    ::std::string indent = _indent; 
    if (addIfdef)
       indent.append(4, ' ');
    
    //CLI_STRUCT_TYPEDEF
    if (addIfdef)
       os<<_indent<<"#ifndef "<<structDefineName<<"\n";
    os<<indent<<"#define "<<genUtil::width(structDefineName, 32)<<"  "<<structTag<<structLangName<<"\n";
    if (addIfdef)
       os<<_indent<<"#endif\n";
    //os<<"\n";

    ::std::string nsFullName, structPlainName;
    splitFqName(structIdentName, nsFullName, structPlainName);

    ::std::vector< ::std::string >::const_iterator alit = structInfo.extAttrs.aliasises.begin();
    for(; alit!=structInfo.extAttrs.aliasises.end(); ++alit)
       {
        ::std::string alias = nsFullName; alias.append(2, ':'); alias.append(*alit);
        ::std::string aliasLangName = bCpp ? alias : getNameAsOneIdent(alias);

        ::std::string aliasNsFullName, aliasPlainName;
        splitFqName(aliasLangName, aliasNsFullName, aliasPlainName);

        ::std::string aliasTypedefName = bCpp ? aliasPlainName : aliasLangName;


        ::std::string aliasDefineName(bStructIsUnion ? "UNION_" : "STRUCT_");
        aliasDefineName.append(convertNameToMacro(getNameAsOneIdent(alias)));

        if (addIfdef)
           os<<_indent<<"#ifndef "<<aliasDefineName<<"\n";
        os<<indent<<"#define "<<genUtil::width(aliasDefineName, 32)<<"  "<<aliasLangName<<"\n";
        if (addIfdef)
           os<<_indent<<"#endif\n";

        //os<<_indent<<"typedef "<<genUtil::width(structDefineName, 32)<<"  "<<aliasDefineName<<";\n\n";
        os<<_indent<<"typedef "<<genUtil::width(structDefineName, 32)<<"  "<<aliasTypedefName<<";\n\n";
        

       }
    return true;
   }

//-----------------------------------------------------------------------------
void CIGenerator::printCppPredeclareType( ::std::ostream &os
                                        , const ::std::string &_ident
                                        , const ::std::string &_indent
                                        , bool bCpp
                                        , bool bStruct
                                        , bool bStructIsUnion
                                        )
   {
    // found efect of this code on interfaces predeclaration
    ::std::string ident = bCpp ? _ident : getNameAsOneIdent(_ident);
    ::std::string typeStr( bStruct ? (bStructIsUnion ? "union" : "struct") : "interface" );
    ::std::string prefix( bCpp ? typeStr : ::std::string("typedef ") + typeStr + ::std::string(" tag_") + ident);

    ::std::string ifDefineName( bStruct ? (bStructIsUnion ? "UNION_" : "STRUCT_") : "INTERFACE_" );
    ifDefineName.append(convertNameToMacro(getNameAsOneIdent(_ident)));

    if (!bCpp)
       os<<_indent<<"#ifndef "<<ifDefineName<<"_PREDECLARED\n"<<_indent<<"#define "<<ifDefineName<<"_PREDECLARED\n";

    os<<_indent<<genUtil::width(prefix, 40)<<" "<<ident<<";\n";

    if (!bCpp)
       os<<_indent<<"#endif //"<<ifDefineName<<"\n";
   }

//-----------------------------------------------------------------------------
bool CIGenerator::printCppPredeclareUsedTypes( ::std::ostream &os
                                             , const ::cidl::CIdl &idl
                                             , const ::std::map< ::std::string, ::std::set< ::std::string > > typesByNs
                                             , const ::std::string &_indent
                                             , int flags
                                             , bool bCpp
                                             )
   {
    ::std::set< ::std::string > usedNs;
    flags &= typeOfTypeInterface|typeOfTypeStruct; // clear wrong flags

    ::std::map< ::std::string, ::std::set< ::std::string > >::const_iterator nsit = typesByNs.begin();
    for(; nsit!=typesByNs.end(); ++nsit)
       {
        /*
        if (bCpp && usedNs.find(nsit->first)==usedNs.end() && !nsit->first.empty() && nsit->first!= ::std::string(2, ':'))
           {
            std::vector< ::std::string > nameList;
            splitFqName(nsit->first, nameList);
            std::vector< ::std::string >::const_iterator nit = nameList.begin();
            ::std::string nsName;
            for(; nit!=nameList.end(); ++nit)
               {
                if (nit->empty()) continue;
                if (!nsName.empty()) nsName.append(2, ':');
                nsName.append(*nit);
                if (usedNs.find(nsName)!=usedNs.end()) continue;
                os<<_indent<<"namespace "<<nsName<<"{};\n";
                usedNs.insert(nsName);
               }
            // print ns
            //os<<_indent<<"namespace "<<nsit->first<<";\n";
           }   
        */

        ::std::vector< ::std::string > closeReverseOrder;
        if (bCpp)
            printCppNamespaceOpen(os, ::std::string(4, ' '), nsit->first, closeReverseOrder);

        ::std::set< ::std::string >::const_iterator tit = nsit->second.begin();
        for(; tit!=nsit->second.end(); ++tit)
           {
            ::std::string typeFullName = mergeFqName(nsit->first, *tit);
            int typeType = idl.findTypeType(typeFullName);
            if (!(typeType&flags)) continue;
            printCppPredeclareType( os, bCpp ? *tit : typeFullName
                                  , ::std::string(closeReverseOrder.size()*4, ' ') + _indent
                                  , bCpp
                                  , typeType&typeOfTypeStruct ? true : false
                                  , typeType==typeOfTypeUnion  ? true : false
                                  );

            printCppStructNameDefine( os, typeFullName
                                    , ::std::string(closeReverseOrder.size()*4, ' ') + _indent
                                    , bCpp
                                    , typeType&typeOfTypeStruct ? true : false 
                                    , true 
                                    , typeType==typeOfTypeUnion  ? true : false
                                    );

           }

        if (bCpp)
           printCppNamespaceClose( os, ::std::string(4, ' '), closeReverseOrder);
           

        //if (bCpp)
        //   usedNs.insert(nsit->first);
       }
    return true;
   }

//-----------------------------------------------------------------------------
/*
struct CFilePosition
{
    text_position_t  pos;
    unsigned         filenameId;

struct text_position_t
{
    int    pos;
    int    line;

*/
::std::string CIGenerator::formatErrPos( const CFilePosition &at
                                       , const std::vector< ::std::string > &files
                                       //, int code
                                       )
   {
    ::std::string tire = "---";
    const ::std::string &fileName = at.filenameId>=(unsigned)files.size() ? tire : files[at.filenameId];
    return CScannerErrorContext::formatFilePos(fileName, at.pos.line, at.pos.pos);
   }

// struct CStructItem
// {
//     CFilePosition                       declaredAt;
//  
//     ::std::string                       name;
//     ::std::string                       type;
//     ::std::string                       bitCount;  // may be some identifier (macros name)
//     bool                                bArray;
//     ::std::string                       arraySize; // may be some identifier (macros name)
//  
//     int                                 attrs;
//     CExtAttributes                      extAttrs;


    // static std::string CScannerErrorContext::formatFilePos(const std::string &filename, int line, int pos);
    // static std::string CScannerErrorContext::formatFilePos(const std::string &filename, text_position_t pos);

//-----------------------------------------------------------------------------
bool CIGenerator::formatCppType(const ::std::string &pureTypeName, const CIdl &idl, int typeType, int cppFlag, CTypeNameCppInfo & nameInfo)
   {
    //int typeType = idl.findTypeType(plainTypeName);
// #define CGOTC_BOTH                     -1    // ���������� ���������� C/C++ (ABI compatible) - ���� ������ POD
// #define CGOTC_C                         0    // ���������� ���������� C   (ABI compatible) - ���� ������ POD  ( ������������ ��� ���������
// #define CGOTC_CPP                       1    // ���������� ���������� C++ (ABI compatible) - ���� ������ POD    ������������ ��� �������� )
// #define CGOTC_CXX                       2    // ���������� ���������� C++ - ����������� ������������� � ���������� C++ ����� - �����, �������� (��� CLI_MONOLITHIC)
// #define CGOTC_CXX_WRAP                  3    // ������� ��� ���������� - ����� �������, ��� � (�), ��������� ������������� � ABI �����������
// #define CGOTC_CXX_WRAP_BEFORE_CALL      4    // ��������������� �������� ��� - �������������� C++ ����� � POD ����� �������
// #define CGOTC_CXX_WRAP_AFTER_CALL       5    // ��������������� �������� ��� - �������������� POD � C++ ���� ����� ������
// #define CGOTC_CXX_WRAP_CALL_RAW         6    // ��������������� �������� ��� - ����� "������" ������ ����������
// #define CGOTC_CXX_IMPL     4    // ������� ��� �������������

    switch(typeType)
       {
        case typeOfTypeInterface:
               {
                nameInfo.pInterfaceInfo = idl.findInterface(pureTypeName);
                switch(cppFlag)
                   {
                    case CGOTC_CXX:
                    case CGOTC_CXX_WRAP:
                    case CGOTC_CXX_WRAP_BEFORE_CALL:
                    case CGOTC_CXX_WRAP_AFTER_CALL:
                    case CGOTC_CXX_WRAP_CALL_RAW:
                    case CGOTC_BOTH:  nameInfo.outputTypeName = "INTERFACE_"; 
                                      nameInfo.outputTypeName.append(convertNameToMacro(getNameAsOneIdent(pureTypeName)));
                            break;
                    case CGOTC_C:     nameInfo.outputTypeName = getNameAsOneIdent(pureTypeName);
                            break;
                    case CGOTC_CPP:   nameInfo.outputTypeName = pureTypeName;
                            break;
                    // case :  
                    //         break;
                    default:
                            std::cout<<"Error (1) - Unsupported cpp format flag "<<cppFlag<<"\n";
                            return false;
                   }
               }
               break;

        case typeOfTypeUnion:
        case typeOfTypeStruct:
               {
                nameInfo.pStructInfo = idl.findStruct(pureTypeName);
                switch(cppFlag)
                   {
                    case CGOTC_CXX:
                    case CGOTC_CXX_WRAP:
                    case CGOTC_CXX_WRAP_BEFORE_CALL:
                    case CGOTC_CXX_WRAP_AFTER_CALL:
                    case CGOTC_CXX_WRAP_CALL_RAW:
                    case CGOTC_BOTH:  nameInfo.outputTypeName = nameInfo.pStructInfo->fUnion ? "UNION_" : "STRUCT_"; 
                                      nameInfo.outputTypeName.append(convertNameToMacro(getNameAsOneIdent(pureTypeName)));
                            break;
                    case CGOTC_C:     nameInfo.outputTypeName = getNameAsOneIdent(pureTypeName);
                            break;
                    case CGOTC_CPP:   nameInfo.outputTypeName = pureTypeName;
                            break;
                    // case :  
                    //         break;
                    default:
                            std::cout<<"Error (2) - Unsupported cpp format flag "<<cppFlag<<"\n";
                            return false;
                   }
               }
               break;

        case typeOfTypeEnum:
               {
                nameInfo.pEnumInfo = idl.findEnum(pureTypeName);
                if (!nameInfo.pEnumInfo)
                   {
                    std::cout<<"Error - enum definition not found.\n";
                    return false;
                   }

                /*
                if (!nameInfo.pEnumInfo->extAttrs.podType.empty())
                   { // ext attr pod type taken
                    nameInfo.pPodInfo = idl.getPodInfo(nameInfo.pEnumInfo->extAttrs.podType, ::std::string("c++"), ::std::string("c"));
                    if (nameInfo.pPodInfo)
                       {
                        nameInfo.outputTypeName = nameInfo.pPodInfo->type;
                        if (!nameInfo.pPodInfo->nativeType.empty() || !nameInfo.pPodInfo->helperType.empty())
                           {
                            std::cout<<"Error - enum declared as used POD type '"<<nameInfo.pEnumInfo->extAttrs.podType<<"', but taken POD type ("<<nameInfo.pPodInfo->type<<") is wrapper for C++ native type '"<<nameInfo.pPodInfo->nativeType<<"' and can't be used in enum.\n";
                            return false;
                           }
                       }
                    else
                       {
                        std::cout<<"Error - enum declared as used POD type '"<<nameInfo.pEnumInfo->extAttrs.podType<<"', but POD type definition not found for C/C++.\n";
                        return false;
                       }                    
                   }
                else
                */
                   { // use enum name
                    
                    switch(cppFlag)
                       {
                        case CGOTC_CXX:
                        case CGOTC_CXX_WRAP:
                        case CGOTC_CXX_WRAP_BEFORE_CALL:
                        case CGOTC_CXX_WRAP_AFTER_CALL:
                        case CGOTC_CXX_WRAP_CALL_RAW:
                        case CGOTC_BOTH:  nameInfo.outputTypeName = "ENUM_"; nameInfo.outputTypeName.append(convertNameToMacro(getNameAsOneIdent(pureTypeName)));
                                break;
                        case CGOTC_C:     nameInfo.outputTypeName = getNameAsOneIdent(pureTypeName);
                                break;
                        case CGOTC_CPP:   nameInfo.outputTypeName = pureTypeName;
                                break;
                        // case :  
                        //         break;
                        default:
                                std::cout<<"Error (3) - Unsupported cpp format flag "<<cppFlag<<"\n";
                                return false;
                       }                    
                   }
               }
               break;

        case typeOfTypePod:
               {
                nameInfo.pPodInfo = idl.getPodInfo(pureTypeName, ::std::string("c++"), ::std::string("c"));
                if (nameInfo.pPodInfo)
                   {
                    switch(cppFlag)
                       {
                        case CGOTC_BOTH:  
                        case CGOTC_C   :  
                        case CGOTC_CPP :      nameInfo.outputTypeName = nameInfo.pPodInfo->type;
                                break;

                        case CGOTC_CXX_WRAP:  nameInfo.outputTypeName = nameInfo.pPodInfo->getNativeTypeName();
                                break;

                        case CGOTC_CXX_WRAP_BEFORE_CALL:  
                        case CGOTC_CXX_WRAP_AFTER_CALL :  
                        case CGOTC_CXX_WRAP_CALL_RAW   :  
                                              if (!nameInfo.pPodInfo->helperType.empty())
                                                 nameInfo.outputTypeName = nameInfo.pPodInfo->helperType;
                                              else
                                                 nameInfo.outputTypeName = nameInfo.pPodInfo->nativeType;
                                break;
                        // case :  
                        //         break;
                        default:            
                                std::cout<<"Error (5) - Unsupported cpp format flag "<<cppFlag<<"\n";
                                return false;
                       }

                    //nameInfo.outputTypeName = nameInfo.pPodInfo->type;
                   }
                else
                   {
                    std::cout<<"Error - POD type '"<<pureTypeName<<"' definition not found for C/C++.\n";
                    return false;
                   }
               }
               break;
       }

    return true;
   }

//-----------------------------------------------------------------------------
bool CIGenerator::printCppStructField( ::std::ostream &os
                                     , const ::cidl::CIdl &idl
                                     , const CStructItem &si
                                     , const ::std::string &_indent
                                     , const std::vector< ::std::string > &srcFiles
                                     , const ::std::string &structName
                                     , int cppFlag
                                     )
   {
    ::std::string plainTypeName, ptrSuffix;

    splitTypeAndPtrSign(si.type, plainTypeName, ptrSuffix);
    int typeType = idl.findTypeType(plainTypeName);

    if (typeType==typeOfTypeUnknown)
       {
        std::cout<<"Error - "<<formatErrPos( si.declaredAt, srcFiles )<<" - "
                 <<structName<<"::"<<si.name<<" - invalid (unknown) type.\n";
        return false;
       }

    if (!(typeType & (typeOfTypeEnum|typeOfTypePod)) && !si.bitCount.empty())
       {
        std::cout<<"Error - "<<formatErrPos( si.declaredAt, srcFiles )<<" - "
                 <<structName<<"::"<<si.name<<" - bit fields alowed only for pod or enum types.\n";
        return false;
       }

    if (si.bArray && si.arraySize.empty())
       {
        std::cout<<"Error - "<<formatErrPos( si.declaredAt, srcFiles )<<" - "
                 <<structName<<"::"<<si.name<<" - variable size arrays not supported in current version of CLI IDL.\n";
        return false;
       }

    CTypeNameCppInfo nameInfo;
    if (!formatCppType(plainTypeName, idl, typeType, cppFlag, nameInfo))
       {
        std::cout<<"Error (3) - "<<formatErrPos( si.declaredAt, srcFiles )<<" - in struct '"<<structName<<"' member '"<<si.name<<"' - can't get type format.\n";
        return false;
       }

    const int structFieldTypeWidth = 24;

    switch(typeType)
       {
        case typeOfTypeInterface:
               {
                if (ptrSuffix.empty())
                   {
                    std::cout<<"Error - "<<formatErrPos( si.declaredAt, srcFiles )<<" - "
                             <<structName<<"::"<<si.name<<" - interfaces can be used as pointers to interfaces only.\n";
                    return false;
                   }
                // ��� ���������� �� ���������� ��������� ������� �������������� �������
                os<<_indent<<genUtil::width(nameInfo.outputTypeName, structFieldTypeWidth)<<"  "<<genUtil::width(ptrSuffix, 2)<<si.name;
                if (si.bArray) os<<"["<<si.arraySize<<"]";
                os<<";\n";
               }
               break;

        case typeOfTypeUnion:
        case typeOfTypeStruct:
               {
                // ��� �������� � ���������� �� ��������� ��������� ������� �������������� �������
                os<<_indent<<genUtil::width(nameInfo.outputTypeName, structFieldTypeWidth)<<"  "<<genUtil::width(ptrSuffix, 2)<<si.name;
                if (si.bArray) os<<"["<<si.arraySize<<"]";
                os<<";\n";
               }
               break;

        case typeOfTypeEnum:
               {
                os<<_indent<<genUtil::width(nameInfo.outputTypeName, structFieldTypeWidth)<<"  "<<genUtil::width(ptrSuffix, 2)<<si.name;
                if (!si.bitCount.empty()) os<<":"<<si.bitCount;
                if (si.bArray) os<<"["<<si.arraySize<<"]";
                os<<";\n";
               }
               break;

        case typeOfTypePod:
               {
                os<<_indent<<genUtil::width(nameInfo.outputTypeName, structFieldTypeWidth)<<"  "<<genUtil::width(ptrSuffix, 2)<<si.name;
                if (!si.bitCount.empty()) os<<":"<<si.bitCount;
                if (si.bArray) os<<"["<<si.arraySize<<"]";
                os<<";\n";
               }
               break;

        default:
               std::cout<<"Error - "<<formatErrPos( si.declaredAt, srcFiles )<<" - "
                        <<structName<<"::"<<si.name<<" - invalid (unknown) type: "<<typeType<<".\n";
               return false;

       }


/*
    os<<_indent<<si.type<<"    "<<si.name;
    if (!si.bitCount.empty())  os<<":"<<si.bitCount;
    if (!si.arraySize.empty()) os<<"["<<si.arraySize<<"]";
    os<<";\n";
*/
    return true;
   }

//-----------------------------------------------------------------------------
bool CIGenerator::printCppStructDefinition( ::std::ostream &os
                                          , const ::cidl::CIdl &idl
                                          , const CStruct &structInfo
                                          , const ::std::string &_indent
                                          , const std::vector< ::std::string > &srcFiles
                                          , const ::std::string &structName
                                          , int cppFlag /* 0 - plain C, 1 - C++, -1 - universal */
                                          )
   {
    ::std::string indent = _indent;
    ::std::string nsFullName, structPlainName;
    splitFqName(structName, nsFullName, structPlainName);

    ::std::vector< ::std::string > closeReverseOrder;
    if (cppFlag>0)
       {
        if (!printCppNamespaceOpen(os, ::std::string(), nsFullName, closeReverseOrder))
           return false;
        indent.append((closeReverseOrder.size())*4, ' ');
       }

    ::std::string structDefineName(structInfo.fUnion ? "UNION_" : "STRUCT_");
    structDefineName.append(convertNameToMacro(getNameAsOneIdent(structName)));

    os<<indent<<"#ifndef "<<structDefineName<<"_DEFINED\n";
    os<<indent<<"#define "<<structDefineName<<"_DEFINED\n";
    if (structInfo.extAttrs.pack>0 && !structInfo.fUnion)
       {
        if (cppFlag<0)
           os<<indent<<"#include <cli/pshpack"<<structInfo.extAttrs.pack<<".h>\n";
        else
           os<<indent<<"#pragma pack(push,"<<structInfo.extAttrs.pack<<")\n";
       }

    if (cppFlag<0)
       {
        if (structInfo.fUnion)
           os<<indent<<"CLI_BEGIN_UNION_DECLARATION(CLI_UNION_NAME)\n";
        else
           os<<indent<<"CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)\n";
       }
    else
       {
        ::std::string tmp(structInfo.fUnion ? "struct" : "struct");
        if (cppFlag>0)
           os<<indent<<tmp<<" "<<structPlainName<<" {\n";
        else
           os<<indent<<"typedef "<<tmp<<" tag_"<<getNameAsOneIdent(structName)<<" {\n";
       }

    ::std::vector<CStructItem>::const_iterator fit = structInfo.fields.begin();
    for(; fit!=structInfo.fields.end(); ++fit)
       {                                                                      /* 0 - plain C, 1 - C++, -1 - universal */
        if (!printCppStructField( os, idl, *fit, indent + ::std::string(4, ' '), srcFiles, structName, cppFlag))
           return false;
       }

    if (cppFlag<0)
       {
        if (structInfo.fUnion)
           os<<indent<<"CLI_END_UNION_DECLARATION(CLI_UNION_NAME);\n";
        else
           os<<indent<<"CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);\n";
       }
    else
       {
        if (cppFlag>0)
           os<<indent<<"};\n";
        else
           os<<indent<<"} "<<getNameAsOneIdent(structName)<<";\n";
       }

    if (structInfo.extAttrs.pack>0 && !structInfo.fUnion)
       {
        if (cppFlag<0)
           os<<indent<<"#include <cli/poppack.h>\n";
        else
           os<<indent<<"#pragma pack(pop)\n";
       }

    os<<indent<<"#endif // "<<structDefineName<<"_DEFINED\n";

    if (cppFlag>0)
       {
        if (!printCppNamespaceClose( os, ::std::string(), closeReverseOrder))
           return false;
       }

    return true;
   }

//-----------------------------------------------------------------------------
bool CIGenerator::printUdfEnumValues( ::std::ostream &os
                                    , const ::std::vector<CEnumValue> &vals
                                    , const ::std::string &enumNameDuin
                                    , const ::doxy::CDoxydoc &doc
                                    )
   {
    os<<"@begin_enum_values_list[]\n@enum_values_list_header[]\n";
    ::std::vector<CEnumValue>::const_iterator vit = vals.begin();
    for(; vit!=vals.end(); ++vit)
       {
        ::std::string itemDUIN = enumNameDuin;
        itemDUIN.append("/val:");
        itemDUIN.append(vit->name);
        os<<"@begin_enum_values_list_item[]\n";

        os<<"@begin_enum_values_list_item_name[]"<<vit->name<<"@end_enum_values_list_item_name[]\n";
        
        os<<"@begin_enum_values_list_item_info[]\n";
        if (vit->aliasFor.empty())
           {
            //const ::doxy::CDoxydoc * pEnumValDoc = doc.getElementByName(itemDUIN);
            //os<<getUdfFormattedFullDescription(pEnumValDoc, true);
            os<<getUdfFormattedFullDescription(&doc, itemDUIN, true);
           }
        else
           {
            os<<"@enum_value_alias_for["<<vit->aliasFor<<"]";
           }
        os<<"@end_enum_values_list_item_info[]\n";
       
        os<<"@end_enum_values_list_item[]\n";
       }
    os<<"@end_enum_values_list[]\n";

    return true;           
   }

//-----------------------------------------------------------------------------
bool CIGenerator::findReadTemplateFile( const ::std::string &tplNameOnly, ::std::string &text
                                      , const std::vector< ::std::string > &srcFiles
                                      , unsigned fileId
                                      , ::std::string &tplFoundName
                                      )
   {
    using MARTY_LIBAPI_NS getModuleFileName;
    using MARTY_FILENAME_NS getPath;
    using MARTY_FILENAME_NS appendPath;
    using MARTY_FILENAME_NS makeCanonical;
    using MARTY_FILESYSTEM_NS getCurrentDirectory;

    ::std::string exeName;
    if (getModuleFileName(0, exeName))
       exeName.clear();

    //::std::string exePath = getPath(exeName);
    ::std::string srcPath;

    if (fileId<srcFiles.size())
       {
        srcPath = makeCanonical(getPath(srcFiles[fileId]));
       }
    

    if (!srcPath.empty())
       {
        ::std::string 
        tplName = makeCanonical(
                                 appendPath(
                                             srcPath,
                                             tplNameOnly
                                           )
                               );
    
        if (findReadTemplateFileAux( tplName, text))
           {
            //std::cout<<"Found template file: "<<tplName<<"\n";
            tplFoundName = tplName;
            return true;
           }
        //std::cout<<"Template file: "<<tplName<<" not found\n";
       }


    ::std::string curPath = makeCanonical(getCurrentDirectory());
    if (!curPath.empty() && curPath!=srcPath)
       {
        ::std::string 
        tplName = makeCanonical(
                                 appendPath(
                                             curPath,
                                             tplNameOnly
                                           )
                               );
        if (findReadTemplateFileAux( tplName, text))
           {
            //std::cout<<"Found template file: "<<tplName<<"\n";
            tplFoundName = tplName;
            return true;
           }
        //std::cout<<"Template file: "<<tplName<<" not found\n";
       }

    ::std::string 
    tplName = makeCanonical(
                             appendPath(
                                         appendPath( 
                                                     getPath(exeName),
                                                     ::std::string("../conf/templates/")
                                                   ),
                                         tplNameOnly
                                       )
                           );

    if (findReadTemplateFileAux( tplName, text))
       {
        //std::cout<<"Found template file: "<<tplName<<"\n";
        tplFoundName = tplName;
        return true;
       }
    //std::cout<<"Template file: "<<tplName<<" not found\n";


    return false;
   }

//-----------------------------------------------------------------------------
struct CAppenderLF
{
    ::std::string &str;
    CAppenderLF(::std::string &s) : str(s) {}
    CAppenderLF(const CAppenderLF &a) : str(a.str) {}
    bool operator()(const char *buf, unsigned len)
       {
        if (!str.empty()) str.append( ::std::string::size_type(1), '\n');
        //if (!str.empty()) 
        str.append( buf, ::std::string::size_type(len));
        return true;
       }
};

// CIGenerator::
bool CIGenerator::findReadTemplateFileAux( const ::std::string &tplName, ::std::string &text)
   {
    MARTY_FILESYSTEM_NS handle_t hCliConfHandle = //findCliConfig(foundConfFile);
                                 MARTY_FILESYSTEM_NS openFile(tplName, MARTY_FILESYSTEM_NS o_rdonly);
    if (hCliConfHandle != MARTY_FILESYSTEM_NS hInvalidHandle)
       {
        CAppenderLF appender(text);
        MARTY_FILESYSTEM_NS readFileLines<CAppenderLF, 4096, '\n'>(hCliConfHandle, appender);
        MARTY_FILESYSTEM_NS closeFile(hCliConfHandle);
        return true;
       }
    return false;
   }

//-----------------------------------------------------------------------------
bool CIGenerator::findReadTemplateFile( const ::std::string &tplNameOnly, ::std::vector< ::std::string > &textLines
                                      , const std::vector< ::std::string > &srcFiles
                                      , unsigned fileId
                                      , ::std::string &tplFoundName
                                      )
   {
    using MARTY_LIBAPI_NS getModuleFileName;
    using MARTY_FILENAME_NS getPath;
    using MARTY_FILENAME_NS appendPath;
    using MARTY_FILENAME_NS makeCanonical;
    using MARTY_FILESYSTEM_NS getCurrentDirectory;

    ::std::string exeName;
    if (getModuleFileName(0, exeName))
       exeName.clear();

    //::std::string exePath = getPath(exeName);
    ::std::string srcPath;

    if (fileId<srcFiles.size())
       {
        srcPath = makeCanonical(getPath(srcFiles[fileId]));
       }
    

    if (!srcPath.empty())
       {
        ::std::string 
        tplName = makeCanonical(
                                 appendPath(
                                             srcPath,
                                             tplNameOnly
                                           )
                               );
    
        if (findReadTemplateFileAux( tplName, textLines))
           {
            //std::cout<<"Found template file: "<<tplName<<"\n";
            tplFoundName = tplName;
            return true;
           }
        //std::cout<<"Template file: "<<tplName<<" not found\n";
       }


    ::std::string curPath = makeCanonical(getCurrentDirectory());
    if (!curPath.empty() && curPath!=srcPath)
       {
        ::std::string 
        tplName = makeCanonical(
                                 appendPath(
                                             curPath,
                                             tplNameOnly
                                           )
                               );
        if (findReadTemplateFileAux( tplName, textLines))
           {
            //std::cout<<"Found template file: "<<tplName<<"\n";
            tplFoundName = tplName;
            return true;
           }
        //std::cout<<"Template file: "<<tplName<<" not found\n";
       }

    ::std::string 
    tplName = makeCanonical(
                             appendPath(
                                         appendPath( 
                                                     getPath(exeName),
                                                     ::std::string("../conf/templates/")
                                                   ),
                                         tplNameOnly
                                       )
                           );

    if (findReadTemplateFileAux( tplName, textLines))
       {
        //std::cout<<"Found template file: "<<tplName<<"\n";
        tplFoundName = tplName;
        return true;
       }
    //std::cout<<"Template file: "<<tplName<<" not found\n";


    return false;
   }
//-----------------------------------------------------------------------------
struct CAppenderVector
{
    ::std::vector< ::std::string > &strVec;
    CAppenderVector(::std::vector< ::std::string > &sv) : strVec(sv) {}
    CAppenderVector(const CAppenderVector &a) : strVec(a.strVec) {}
    bool operator()(const char *buf, unsigned len)
       {
        //if (!str.empty()) str.append( ::std::string::size_type(1), '\n');
        //if (!str.empty()) 
        //str.append( buf, ::std::string::size_type(len));
        strVec.push_back( ::std::string( buf, ::std::string::size_type(len)) );
        return true;
       }
};

//-----------------------------------------------------------------------------
bool CIGenerator::findReadTemplateFileAux( const ::std::string &tplName, ::std::vector< ::std::string > &textLines )
   {
    MARTY_FILESYSTEM_NS handle_t hCliConfHandle = //findCliConfig(foundConfFile);
                                 MARTY_FILESYSTEM_NS openFile(tplName, MARTY_FILESYSTEM_NS o_rdonly);
    if (hCliConfHandle != MARTY_FILESYSTEM_NS hInvalidHandle)
       {
        CAppenderVector appender(textLines);
        MARTY_FILESYSTEM_NS readFileLines<CAppenderVector, 4096, '\n'>(hCliConfHandle, appender);
        MARTY_FILESYSTEM_NS closeFile(hCliConfHandle);
        return true;
       }
    return false;
   }

//-----------------------------------------------------------------------------
bool CIGenerator::processTemplate( const ::std::string &tplName
                                 , std::ostream &os
                                 , const ::std::string &indent
                                 , const std::vector< ::std::string > &srcFiles
                                 , unsigned fileId
                                 , const ::std::set< ::std::string > &tplEnabledSections
                                 , const std::map< ::std::string, ::std::string> &_macroses
                                 )
   {
    ::std::vector< ::std::string > tplTextLines;
    ::std::string tplFoundName;
    if (!findReadTemplateFile(tplName, tplTextLines, srcFiles, fileId, tplFoundName))
       {
        return false;
       }

    std::map< ::std::string, ::std::string> macroses = _macroses;
    macroses["TemplateFileName"] = tplFoundName;
    genUtil::rtrim(tplTextLines);

    ::std::vector< ::doxy::CDoxyCommentItem > tplDoxy;
    ::std::vector< ::doxy::CDoxyCommentItem > tplDoxyRes;
    tplLinesToDoxyItems( tplTextLines, tplDoxy );
    ::doxy::doxyProcessIfs(tplDoxy, tplEnabledSections, tplDoxyRes);

    tplTextLines.clear();
    ::std::vector< ::doxy::CDoxyCommentItem >::const_iterator tdit = tplDoxyRes.begin();
    for(; tdit!=tplDoxyRes.end(); ++tdit)
       {
        tplTextLines.push_back(tdit->asText());
       }

    ::std::vector< ::std::string >::iterator 
    it = tplTextLines.begin();
    for(; it!=tplTextLines.end(); ++it)
       {
        *it = marty::macro::substMacroses(macroses, *it, false, false);
       }

    genUtil::printWithIndent( os, indent, tplTextLines);

    return true;
   }

//-----------------------------------------------------------------------------
bool CIGenerator::getFullTypeInfoForCppMethodDeclaration
                                 ( const ::std::string &propertyOrMethodName
                                 , bool bProperty
                                 , const ::std::string &propertyOrMethodType
                                 , const ::std::string &ifName
                                 , const CIdl &idl
                                 , const CFilePosition &declaredAt
                                 , const std::vector< ::std::string > &srcFiles
                                 , const ::std::string &paramName // not empty for method param
                                 , int cppType
                                 , const ::std::string &calledFrom
                                 , bool allowNonRefStruct
                                 // out
                                 , ::std::string &ptrTypePart
                                 , ::std::string &pureType
                                 , int &typeType
                                 , CTypeNameCppInfo &nameInfo
                                 )
   {
    splitTypeAndPtrSign(propertyOrMethodType, pureType, ptrTypePart);

    typeType = idl.findTypeType(pureType);
    if (typeType==typeOfTypeUnknown)
       {
        std::cout<<"Error ("<<calledFrom<<") - "<<formatErrPos( declaredAt, srcFiles )
                 <<" - interface "<< ifName /* methodGenParams.ifIdentName */ 
                 <<" "<< (bProperty?"property":"method")<<" "<<propertyOrMethodName /* ifEntry.propertyInfo.name */ 
                 <<(!paramName.empty() ? " parameter ":"")<<(!paramName.empty() ? paramName.c_str():"")
                 <<": "<<(!bProperty&&paramName.empty()?" return ":"")
                 <<"type '"<<propertyOrMethodType<<"'."
                 <<" is unknown\n";
        return false;
       }
    //CTypeNameCppInfo nameInfo;
    if (!formatCppType(pureType, idl, typeType, cppType, nameInfo))
       {
        std::cout<<"Error ("<<calledFrom<<") - "<<formatErrPos( declaredAt, srcFiles )
                 <<" - interface "<< ifName /* methodGenParams.ifIdentName */ 
                 <<" "<< (bProperty?"property":"method")<<" "<<propertyOrMethodName /* ifEntry.propertyInfo.name */ 
                 <<(!paramName.empty() ? " parameter ":"")<<(!paramName.empty() ? paramName.c_str():"")
                 <<": "<<(!bProperty&&paramName.empty()?" return ":"")
                 <<"type '"<<propertyOrMethodType<<"'.\n";
        return false;
       }

    if ((!nameInfo.pEnumInfo && !nameInfo.pPodInfo && ptrTypePart.empty() && !allowNonRefStruct) || (typeType==typeOfTypeInterface && ptrTypePart.size()!=1))
       {
        std::cout<<"Error ("<<calledFrom<<") - " //- "<<formatErrPos( declaredAt, srcFiles )
                 <<"interface "<< ifName /* methodGenParams.ifIdentName */ 
                 <<" "<< (bProperty?"property":"method")<<" "<<propertyOrMethodName /* ifEntry.propertyInfo.name */ 
                 <<(!paramName.empty() ? " parameter ":"")<<(!paramName.empty() ? paramName.c_str():"")
                 <<": "<<(!bProperty&&paramName.empty()?" return ":"")
                 <<"type '"<<propertyOrMethodType<<"' is not POD nor pointer, or type not defined for C/C++ destination.\n";
        return false;
       }
    return true;
   }

//-----------------------------------------------------------------------------
struct CTmpTypeInfo
   {
    ::std::string typeName;
    ::std::string paramName;
    ::std::string ptrPart;
    bool bConst;
    bool bRef;
   };

bool CIGenerator::generateCppMethodDeclaration( ::std::ostream                &os
                                              , ::std::string                 _indent
                                              , const CInterfaceEntry         &ifEntry
                                              , const CGenerationParams       &params
                                              , const CMethodGenerationParams &methodGenParams
                                              , int cppType
                                              )
   {
    //if (ifEntry.fProperty) return true;

    ::std::string indent = _indent;

    const CIdl &idl = params.idl;


    if (ifEntry.fProperty)
       {
        if (cppType==CGOTC_CXX_WRAP)
           {
            ::std::string fnIndent = indent;
            fnIndent.append(4,' ');

            bool resultByRef    = false;
            bool resultUseConst = false;
            ::std::string resultTypeName;
            //::std::string resultPtrPart;

            os<<indent<<"#if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)\n\n";

            ::std::vector< ::std::pair< ::std::string, ::std::string> > fnParams;
            fnParams.push_back( ::std::make_pair( ifEntry.propertyInfo.type, ::std::string("_") + ifEntry.propertyInfo.name ) );
            ::std::vector< ::std::string >::const_iterator idxIt = ifEntry.propertyInfo.indexTypes.begin();
            unsigned idxNo = 0;
            for(; idxIt!=ifEntry.propertyInfo.indexTypes.end(); ++idxIt, ++idxNo)
               {
                std::ostringstream tmpOs;
                tmpOs<<"idx"<<(idxNo+1);
                fnParams.push_back( ::std::make_pair( *idxIt, tmpOs.str() ) );
               }

                                       // gcc fails with default template arg #2
            //::std::vector< CTmpTypeInfo, ::std::allocator<CTmpTypeInfo> > typeInfos;
            ::std::vector< CTmpTypeInfo > typeInfos;

            ::std::vector< ::std::pair< ::std::string, ::std::string> >::const_iterator paramsIt = fnParams.begin();
            for(; paramsIt!=fnParams.end(); ++paramsIt)
               {
                ::std::string ptrTypePart;
                ::std::string pureType;
                //splitTypeAndPtrSign(ifEntry.propertyInfo.type, pureType, ptrTypePart);
                //splitTypeAndPtrSign(paramsIt->first, pureType, ptrTypePart);
                //paramsIt->first
    
                int propertyTypeType = 0;
                CTypeNameCppInfo nameInfo;
    
                if (!getFullTypeInfoForCppMethodDeclaration( ifEntry.propertyInfo.name // propertyOrMethodName
                                                           , true // bProperty
                                                           , paramsIt->first // pureType // ifEntry.propertyInfo.type // propertyOrMethodType
                                                           , methodGenParams.ifIdentName // ifName
                                                           , idl
                                                           , ifEntry.propertyInfo.declaredAt
                                                           , params.srcFiles
                                                           , ::std::string() // paramName // not empty for method param
                                                           , cppType
                                                           , "GCMD1"
                                                           , (paramsIt==fnParams.begin() ? true : false)
                                                           // out
                                                           , ptrTypePart
                                                           , pureType
                                                           , propertyTypeType // typeType
                                                           , nameInfo
                                                           )
                   ) return false;

                
                CTmpTypeInfo ti;
                //ti.paramName = paramsIt->second + ptrTypePart;
                ti.paramName = paramsIt->second;
                ti.ptrPart   = ptrTypePart;
                //os<<"/* nameInfo.outputTypeName: "<<nameInfo.outputTypeName<<" */";
                nameInfo.getConstRefInfo( propertyTypeType, ptrTypePart, ti.typeName, ti.bRef, ti.bConst );
                typeInfos.push_back(ti);
                if (resultTypeName.empty()) 
                   {
                    if (propertyTypeType==typeOfTypeInterface)
                       {
                       }
                    resultTypeName = ti.typeName;
                    //resultPtrPart  = ptrTypePart;
                    resultByRef    = ti.bRef;
                    resultUseConst = ti.bConst;
                   }
               } // for

            typeInfos.erase(typeInfos.begin());
            fnParams.erase(fnParams.begin());

            ::std::string propertyDeclSuffix;

            if ((ifEntry.propertyInfo.direction&::cidl::directionGet) == ::cidl::directionGet)
               {
                propertyDeclSuffix.append(1, 'R');
                ::std::string retValAndFnName = resultTypeName;
                //if ()
                retValAndFnName.append(" get_");
                retValAndFnName.append(ifEntry.propertyInfo.name);

                bool bFirstParam = true;

                //os<<indent<<resultTypeName<<" get_"<<ifEntry.propertyInfo.name<<"( ";
                os<<indent<<retValAndFnName<<"( ";

                ::std::vector< CTmpTypeInfo >::const_iterator tiIt = typeInfos.begin();
                for(; tiIt!=typeInfos.end(); ++tiIt)
                   {
                    if (!bFirstParam) os<<", ";
                    bFirstParam = false;

                    if (tiIt->bConst) os<<"const ";
                    os<<tiIt->typeName<<" ";
                    if (tiIt->bRef) os<<"&";
                    os<<tiIt->paramName;
                                        
                    if (typeInfos.size()>1) os<<"\n"<<indent << ::std::string(retValAndFnName.size(), ' ');
                    else                   os<<" ";
                   }

                os<<")\n";
                os<<indent<<"   {\n";

                os<<fnIndent<<resultTypeName<<" tmpVal;\n";
                os<<fnIndent<<"RCODE res = "<<ifEntry.propertyInfo.name<<"Get( ";
                if (!resultByRef) os<<"&";
                os<<"tmpVal";

                paramsIt = fnParams.begin();
                bFirstParam = true;
                for(; paramsIt!=fnParams.end(); ++paramsIt)
                   {
                    os<<", ";
                    os<<paramsIt->second;
                   }
                os<<");\n";
                os<<fnIndent<<"CLI_CHECK_GET_PROPERTY_RESULT(res);\n";
                os<<fnIndent<<"return tmpVal;\n";
                os<<indent<<"   }\n\n";
               } // if


            if ((ifEntry.propertyInfo.direction&::cidl::directionSet) == ::cidl::directionSet)
               {
                propertyDeclSuffix.append(1, 'W');
                os<<indent<<"void set_"<<ifEntry.propertyInfo.name<<"( ";

                ::std::vector< CTmpTypeInfo >::const_iterator tiIt = typeInfos.begin();
                for(; tiIt!=typeInfos.end(); ++tiIt)
                   {
                    if (tiIt->bConst) os<<"const ";
                    os<<tiIt->typeName<<" ";
                    if (tiIt->bRef) os<<"&";
                    os<<tiIt->paramName;
                                        
                    if (typeInfos.size()>1) os<<"\n"<<indent << ::std::string(ifEntry.propertyInfo.name.size()+9, ' ');
                    else                   os<<" ";
                    os<<", ";
                   }

                //os<<fnIndent;
                if (resultUseConst) os<<"const ";
                os<<resultTypeName<<" ";
                if (resultByRef) os<<"&";
                os<<"_"<<ifEntry.propertyInfo.name<<"\n";

                os<< ::std::string(ifEntry.propertyInfo.name.size()+9, ' ')<<")\n";
                os<<indent<<"   {";
                if (!fnParams.empty())
                   {
                    if (fnParams.size()>1) os<<" // MS style - indeces are before value, need reorder";
                    else                   os<<" // MS style - index goes before value, need reorder";
                   }
                os<<indent<<"\n";
                os<<fnIndent<<"RCODE res = "<<ifEntry.propertyInfo.name<<"Set( _"<<ifEntry.propertyInfo.name<<"";
                paramsIt = fnParams.begin();
                for(; paramsIt!=fnParams.end(); ++paramsIt)
                   {
                    //if (paramsIt!=fnParams.begin()) 
                    os<<", ";
                    os<<paramsIt->second;
                   }
                os<<" );\n";
                os<<fnIndent<<"CLI_CHECK_SET_PROPERTY_RESULT(res);\n";
                os<<indent<<"   }\n\n";
               }

            if (!fnParams.empty() && !(ifEntry.propertyInfo.direction&::cidl::noSizeMethod))
               {
                // ::std::vector< ::std::pair< ::std::string, ::std::string> >::const_iterator 
                paramsIt = fnParams.begin();
                unsigned idxIdx = 1;
                for(; paramsIt!=fnParams.end(); ++paramsIt, ++idxIdx)
                   {
                    os<<"SIZE_T size";
                    if (fnParams.size()>1) os<<idxIdx;
                    os<<"_"<<ifEntry.propertyInfo.name<<"( ";
                    for(unsigned i=1; i!=idxIdx; ++i)
                       {
                        if (i>1) os<<", ";
                        os<<"SIZE_T idx"<<i;
                       }
                    os<<" )\n";
                    os<<"   {\n";
                    os<<"    SIZE_T size;\n";
                    os<<"    RCODE res = "<<ifEntry.propertyInfo.name<<"Size";
                    if (fnParams.size()>1) os<<idxIdx;
                    os<<"( &size";
                    for(unsigned i=1; i!=idxIdx; ++i)
                       {
                        os<<", idx"<<i;
                       }
                    os<<" );\n";
                    os<<"    CLI_CHECK_PROPERTY_SIZE_RESULT(res);\n";
                    os<<"    return size;\n";
                    os<<"   }\n\n";
                   }
               }

            if (!ifEntry.propertyInfo.indexTypes.empty())
               {
                ::std::ostringstream tmpOs;
                tmpOs<<"_IDX"<<(unsigned)ifEntry.propertyInfo.indexTypes.size();
                propertyDeclSuffix.append(tmpOs.str());
               }

            os<<indent<<"#if !defined(CLI_WRAPPER_NO_PROPERTIES)\n";   

            os<<indent<<"/* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC \"offsetof problem\"\n";
            os<<indent<<"   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */\n";
            os<<indent<<"CLI_DECLARE_PROPERTY_"<<propertyDeclSuffix<<"(" 
              <<"wrapper_type, "
              <<resultTypeName<<", "
              <<ifEntry.propertyInfo.name;

            ::std::vector< CTmpTypeInfo >::const_iterator tiIt = typeInfos.begin();
            //if (tiIt!=typeInfos.end()) ++tiIt;
            for(; tiIt!=typeInfos.end(); ++tiIt)
               os<<", "<<tiIt->typeName;

            os<<" );\n";

            os<<indent<<"#endif /* CLI_WRAPPER_NO_PROPERTIES */\n";

            os<<indent<<"\n#endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */\n";

            os<<"\n\n";
            //nameInfo.CPodInfo->nativeType
            /*
            struct CPodInfo
            {
                ::std::string  type;
                ::std::string  nativeType;
                ::std::string  helperType;
                int            attrs;
                CExtAttributes extAttrs;
            */

            /*
            struct CTypeNameCppInfo
            {
                std::string             outputTypeName;
                const CInterfaceInfo   *pInterfaceInfo ; //= 0;
                const CStruct          *pStructInfo ; //= 0;
                const CEnumeration     *pEnumInfo ; //= 0;
                const CPodInfo         *pPodInfo  ; //= 0;
            
                CTypeNameCppInfo() : outputTypeName(), pInterfaceInfo(0), pStructInfo(0), pEnumInfo(0), pPodInfo(0) {}
            };
            */
            //passByRef


            /*
            */

            /*
            idl.findTypeType(pureType);
            if (propertyTypeType==typeOfTypeUnknown)
               {
                std::cout<<"Error - "<<formatErrPos( ifEntry.propertyInfo.declaredAt, params.srcFiles )
                         <<" - interface "<<methodGenParams.ifIdentName<<" property "<<ifEntry.propertyInfo.name
                         <<": type "<<ifEntry.propertyInfo.type
                         <<" is unknown\n";
                return false;
               }

            CTypeNameCppInfo nameInfo;
            if (!formatCppType(pureType, idl, propertyTypeType, cppType, nameInfo))
               {
                std::cout<<"Error - "<<formatErrPos( ifEntry.propertyInfo.declaredAt, params.srcFiles )
                         <<" - in interface '"<<methodGenParams.ifIdentName<<"'"
                         <<" property '"<<ifEntry.propertyInfo.name<<"' type '"<<ifEntry.propertyInfo.type<<"'.\n";
                return false;
               }

            if (!nameInfo.pEnumInfo && !nameInfo.pPodInfo && ptrTypePart.empty())
               {
                std::cout<<"Error: interface "<<methodGenParams.ifIdentName<<" property "<<ifEntry.propertyInfo.name
                         <<": type "<<ifEntry.propertyInfo.type
                         <<" is not POD nor pointer, or type not defined for C/C++ destination\n";
                return false;
               }

            ::std::string outputRetType = nameInfo.outputTypeName + ptrTypePart;
            */
        
            /*
            iEntry.propertyInfo
            ---
            int                                 direction;   // read, write, read/write allowed
            ::std::string                       type;        // property type
            ::std::string                       name;        // property name
            ::std::vector< ::std::string >      indexTypes;  // index types list
            */
           }
        return true;
       }


    if (cppType==CGOTC_CXX_WRAP && ( ifEntry.methodInfo.name==::std::string("addRef") 
                                  || ifEntry.methodInfo.name==::std::string("release") 
                                  || ifEntry.methodInfo.name==::std::string("queryInterface"))
       )
       return true;

    //::std::string ptrTypePart = params.idl.getTypeNamePointers(ifEntry.methodInfo.type);
    //::std::string pureType    = params.idl.getPureTypeName(ifEntry.methodInfo.type);
    ::std::string ptrTypePart;
    ::std::string pureType;
    splitTypeAndPtrSign(ifEntry.methodInfo.type, pureType, ptrTypePart);

    int typeType = idl.findTypeType(pureType);

    bool stdResultMethod = false;

    if (typeType==typeOfTypeUnknown)
       {
        std::cout<<"Error - "<<formatErrPos( ifEntry.methodInfo.declaredAt, params.srcFiles )
                 <<" - interface "<<methodGenParams.ifIdentName<<" method "<<ifEntry.methodInfo.name
                 <<": return type "<<ifEntry.methodInfo.type
                 <<" is unknown\n";
        //std::cout<<"Error - "<<formatErrPos( ifEntry.methodInfo.declaredAt, params.srcFiles )<<" - "
        //         <<structName<<"::"<<si.name<<" - invalid (unknown) type.\n";
        return false;
       }

    CTypeNameCppInfo nameInfo;
    if (!formatCppType(pureType, params.idl, typeType, cppType, nameInfo))
       {
        std::cout<<"Error - "<<formatErrPos( ifEntry.methodInfo.declaredAt, params.srcFiles )
                 <<" - in interface '"<<methodGenParams.ifIdentName<<"'"
                 <<" method '"<<ifEntry.methodInfo.name<<"' return type '"<<ifEntry.methodInfo.type<<"'.\n";
        return false;
       }


    /* nameInfo.pEnumInfo ; //= 0;
     * nameInfo.pPodInfo  ; //= 0;
     */

    //const CPodInfo* retPod    = params.idl.getPodInfo(pureType, ::std::string("c"), ::std::string("c++"));
    if (!nameInfo.pEnumInfo && !nameInfo.pPodInfo && ptrTypePart.empty())
       {
        std::cout<<"Error: interface "<<methodGenParams.ifIdentName<<" method "<<ifEntry.methodInfo.name
                 <<": return type "<<ifEntry.methodInfo.type
                 <<" is not POD nor pointer, or type not defined for C/C++ destination\n";
        return false;
       }

    ::std::string outputRetType = nameInfo.outputTypeName + ptrTypePart;
    ::std::string closeIndent; // = indent;

    if (outputRetType==::std::string("RCODE"))
       stdResultMethod = true;

    bool voidReturn = false;
    if (outputRetType==::std::string("VOID"))
       voidReturn = true;


    switch(cppType)
       {
        case CGOTC_C:     //std::cout<<"Error - (6) Unsupported cpp format flag "<<cppType<<"\n";
                          //return false;
                //break;
        case CGOTC_CPP:   //std::cout<<"Error - (7) Unsupported cpp format flag "<<cppType<<"\n";
                          //return false;
                //break;
        case CGOTC_BOTH:  os<<indent<<"CLIMETHOD"; indent.append(9, ' '); // CLIMETHOD len
                          if (ifEntry.methodInfo.callType==calltypeVamethod)
                             { os<<"VA"; indent.append(2, ' '); /* VA len */ }
                          if (!stdResultMethod)
                             { 
                              indent.append(2 + 2 + 2, ' '); // _( , ) len
                              indent.append(outputRetType.size()+ifEntry.methodInfo.name.size(), ' ');
                              os<<"_("<<outputRetType<<", "<<ifEntry.methodInfo.name<<") ";
                             }
                          else
                             {
                              indent.append(3, ' '); // () len
                              indent.append(ifEntry.methodInfo.name.size(), ' ');
                              os<<"("<<ifEntry.methodInfo.name<<") ";
                             }
                          os<<"(THIS";
                          closeIndent = indent;
                          indent.append(5, ' '); // (THIS len
                          if (!ifEntry.methodInfo.parameters.empty())
                              os<<"_";

                break;


        case CGOTC_CXX_WRAP:  
                              //indent.append(2 + 2 + 2, ' '); // _( , ) len
                              indent.append(outputRetType.size()+ifEntry.methodInfo.name.size() + 1, ' ');
                              os<<outputRetType<<" "<<ifEntry.methodInfo.name<<"( ";
                              closeIndent = indent;
                break;
        /* case :  
         *         break;
         */
        default:
                          std::cout<<"Error - (8) Unsupported cpp format flag "<<cppType<<"\n";
                          return false;
       }

    ::std::ostringstream beforeCall;
    ::std::ostringstream afterCall;
    ::std::ostringstream callRaw;

    if (cppType==CGOTC_CXX_WRAP)
       {
        /*
        if (calltypeVamethod)
           callRaw<<_indent<<""<<outputRetType<<" res = ";
        else 
           callRaw<<_indent<<"return ";
        */
        callRaw<<"pif->"<<ifEntry.methodInfo.name<<"(";
       }

    ::std::vector< CParameter >::const_iterator mpIt = ifEntry.methodInfo.parameters.begin();  // 
    for(; mpIt!=ifEntry.methodInfo.parameters.end(); ++mpIt)
       {
        if (cppType==CGOTC_C || cppType==CGOTC_CPP || cppType==CGOTC_BOTH || cppType==CGOTC_CXX_WRAP)
           {
            if (mpIt==ifEntry.methodInfo.parameters.begin())
               {
                if (cppType==CGOTC_C || cppType==CGOTC_CPP || cppType==CGOTC_BOTH) os<<" ";
               }
            else
               os<<"\n"<<indent<<", ";

            ::std::string tmpParamVarName;
            if (!generateCppParameter( os, indent, ifEntry, *mpIt, params, methodGenParams, mpIt->name, cppType, stdResultMethod, tmpParamVarName ))
               return false;

            if (cppType==CGOTC_CXX_WRAP)
               {
                if (mpIt!=ifEntry.methodInfo.parameters.begin())
                   callRaw<<", ";

                if ( /* stdResultMethod &&  */ !generateCppParameter( beforeCall, indent, ifEntry, *mpIt, params, methodGenParams, mpIt->name, CGOTC_CXX_WRAP_BEFORE_CALL, stdResultMethod, tmpParamVarName ))
                   return false;
                beforeCall<<"\n";

                if (stdResultMethod)
                   {
                    ::std::string::size_type afterSize = afterCall.str().size();
                    if (!generateCppParameter( afterCall , indent, ifEntry, *mpIt, params, methodGenParams, mpIt->name, CGOTC_CXX_WRAP_AFTER_CALL , stdResultMethod, tmpParamVarName ))
                       return false;
                    if (afterSize!=afterCall.str().size()) afterCall<<"\n";
                   }
                   
                if (!generateCppParameter( callRaw   , indent, ifEntry, *mpIt, params, methodGenParams, mpIt->name, CGOTC_CXX_WRAP_CALL_RAW, stdResultMethod, tmpParamVarName ))
                   return false;
               }
            //os<<mpIt->name; //<<;
           }
       }

    if (ifEntry.methodInfo.parameters.size()>1)
       os<<"\n"<<closeIndent;

    os<<")";
    if (cppType==CGOTC_BOTH)
       {
        os<<" PURE;";
       }
    else if (cppType==CGOTC_CXX_WRAP)
       {
        os<<"\n"<<_indent<<"   {\n"<<_indent;
        indent = _indent + ::std::string(4, ' ');

        // if (stdResultMethod && !beforeCall.str().empty())
        if (!beforeCall.str().empty())
           {
            genUtil::printWithIndent( os, indent, beforeCall.str());
            //os<<""<<indent<<""<<outputRetType<<" res = ";
           }
        //else if (!voidReturn)
        //   os<<indent<<"return /* 1 */";
        /*
        if (stdResultMethod && !beforeCall.str().empty() && !afterCall.str().empty())
           os<<""<<indent<<""<<outputRetType<<" res = ";
        else if (!voidReturn)
           os<<indent<<"return ";
        */

        /*
        if (stdResultMethod)
           {
            if (!beforeCall.str().empty() && !afterCall.str().empty())
               os<<""<<indent<<""<<outputRetType<<" res = ";
           }
        else 
           {
            if (!voidReturn)
               os<<indent<<"return ";
           }
        */

        if (!voidReturn)
           {
            if (!afterCall.str().empty())
               os<<""<<indent<<""<<outputRetType<<" res = ";
            else
               os<<""<<indent<<"return ";
           }

        os<<callRaw.str()<<");"<<"\n";
        //if (stdResultMethod && !beforeCall.str().empty() && !afterCall.str().empty())
        if (!beforeCall.str().empty() && !afterCall.str().empty())
           {
            if (stdResultMethod)
               {
                os<<indent<<"if (RCOK(res))\n"<<indent<<"   {\n";
                genUtil::printWithIndent( os, indent + ::std::string(4, ' '), afterCall.str());
                os<<""<<indent<<"   }\n";
               }
            else
               {
                genUtil::printWithIndent( os, indent, afterCall.str());
               }
           }
        //if (stdResultMethod && !afterCall.str().empty())
        if (!voidReturn && !afterCall.str().empty())
           os<<indent<<"return res;\n";
        os<<_indent<<"   }\n";
       }

    os<<"\n";

    //os<<"\n";
    //os<<indent<<ifEntry.methodInfo.name<<"\n";
    return true;
   
   }
//-----------------------------------------------------------------------------
// CIGenerator::












//-----------------------------------------------------------------------------
void CGeneratorFabriq::addAlias(const ::std::string &pair)
   {
    ::std::string type, alias;
    ::doxy::splitToPair( pair, type, alias, '=', true);
    if (alias.empty()) alias = type;
    addAlias(type, alias);
   }

//-----------------------------------------------------------------------------
::std::string CGeneratorFabriq::getTypeName(const ::std::string &typeOrAlias) const
   {
    ::std::map< ::std::string, ::std::string >::const_iterator it = typeAliasises.find(typeOrAlias);
    if (it==typeAliasises.end()) return typeOrAlias; // no alias found
    return it->second;
   }

//-----------------------------------------------------------------------------
CIGenerator* CGeneratorFabriq::createGenerator(const ::std::string &type) const
   {
    CIGenerator* res = 0;
    if (type== ::std::string("udf"))
       {
        res = new CUdfGenerator();
       }
    else if (type== ::std::string("c_decl") || type== ::std::string("cpp_decl"))
       {
        res = new CCppIfDeclarationGenerator();
       }
    else if (type== ::std::string("c_component_impl") || type== ::std::string("cpp_component_impl"))
       {
        res = new CCppComponentImplGenerator();
       }

    if (res)
       {
        res->outputType = type;
        res->pFabriq    = this;
       }

    //CIGenerator
    return res;
   }

CIMethodGenerator* CGeneratorFabriq::createMethodGenerator(const ::std::string &type) const
   {
    CIMethodGenerator* res = 0;
    if (type== ::std::string("udf"))
       {
        res = new CUdfMethodGenerator();
       }
    else if (type== ::std::string("c_decl") || type== ::std::string("cpp_decl"))
       {
        res = new CCppIfMethodGenerator();
       }

    if (res)
       {
        res->outputType = type;
        res->pFabriq    = this;
       }

    return res;
   }

//-----------------------------------------------------------------------------
bool CGeneratorFabriq::splitTypeAndFile(const ::std::string &typeAndFile, ::std::string &type, ::std::string &file) const
   {
    //::std::string type, file;
    ::doxy::splitToPair( typeAndFile, type, file, ',', false);
    if (type.empty())
       {
        type = MARTY_FILENAME_NS getExtention( file );
        if (!type.empty() && type[0]=='.')
           {
            type.erase(0, 1);
           }
       }
    type = getTypeName(type); 
    return !type.empty() && !file.empty();
   }




}; // namespace cidl

