static
char
mparam_wrapper_template_cpp[] = 
"\\if wrapper_MethodParameter\n    $(ParamConst) $(ParamTypeNative)    $(Pas"
"sByRef)$(ParamName)\n\\endif\n\\if conversion_Before\n    \\if direction_In"
"\n        $(ParamTypeHelper) tmp_$(ParamName); $(ParamTypeHelper)_lightCopy"
"To( tmp_$(ParamName), $(ParamName));\n    \\else\n        $(ParamTypeHelper"
") tmp_$(ParamName); $(ParamTypeHelper)_init( tmp_$(ParamName) );\n    \\end"
"if\n\\endif\n\\if conversion_After\n    \\if direction_Out\n        $(Param"
"TypeHelper)_copyFromIfModified( $(ParamName), tmp_$(ParamName));\n    \\end"
"if\n\\endif\n\\if conversion_Call\n    $(PassByRef)tmp_$(ParamName)\n\\endi"
"f";

/* Input file size: 588 */
static
size_t /* requires stddef.h to be included first */
sizeof_mparam_wrapper_template_cpp = 571;

