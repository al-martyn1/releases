#define UART2_TX_GPIO                                 GPIOA
#define UART2_TX_GPIO_PIN_NO                          2
#define UART2_TX_GPIO_PIN_ADDR                        UMBA_PINADDR_PA2
#define UART2_TX_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PA2, UMBA_GPIO_DIRECTION_OUT
#define UART2_TX_GPIO_PIN_SOURCE                      GPIO_PinSource2
#define UART2_TX_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_OUT

#define UART2_RX_GPIO                                 GPIOA
#define UART2_RX_GPIO_PIN_NO                          3
#define UART2_RX_GPIO_PIN_ADDR                        UMBA_PINADDR_PA3
#define UART2_RX_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PA3, UMBA_GPIO_DIRECTION_IN
#define UART2_RX_GPIO_PIN_SOURCE                      GPIO_PinSource3
#define UART2_RX_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_IN

#define UART1_TX_GPIO                                 GPIOB
#define UART1_TX_GPIO_PIN_NO                          10
#define UART1_TX_GPIO_PIN_ADDR                        UMBA_PINADDR_PB10
#define UART1_TX_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PB10, UMBA_GPIO_DIRECTION_OUT
#define UART1_TX_GPIO_PIN_SOURCE                      GPIO_PinSource10
#define UART1_TX_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_OUT

#define UART1_RX_GPIO                                 GPIOB
#define UART1_RX_GPIO_PIN_NO                          11
#define UART1_RX_GPIO_PIN_ADDR                        UMBA_PINADDR_PB11
#define UART1_RX_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PB11, UMBA_GPIO_DIRECTION_IN
#define UART1_RX_GPIO_PIN_SOURCE                      GPIO_PinSource11
#define UART1_RX_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_IN
