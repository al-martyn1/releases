// USB-CAN.PrjPcb - Generator: h_conf

// USB-CAN.PrjPcb - Netlist_1

// MCU DD2 STM32F105RCT6 peripherals

// DD1

#define UART2_TX_GPIO                                 GPIOA
#define UART2_TX_GPIO_PIN_NO                          2
#define UART2_TX_GPIO_PIN_ADDR                        UMBA_PINADDR_PA2
#define UART2_TX_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PA2, UMBA_GPIO_DIRECTION_OUT
#define UART2_TX_GPIO_PIN_SOURCE                      GPIO_PinSource2
#define UART2_TX_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_OUT

#define UART2_RX_GPIO                                 GPIOA
#define UART2_RX_GPIO_PIN_NO                          3
#define UART2_RX_GPIO_PIN_ADDR                        UMBA_PINADDR_PA3
#define UART2_RX_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PA3, UMBA_GPIO_DIRECTION_IN
#define UART2_RX_GPIO_PIN_SOURCE                      GPIO_PinSource3
#define UART2_RX_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_IN

#define UART1_TX_GPIO                                 GPIOB
#define UART1_TX_GPIO_PIN_NO                          10
#define UART1_TX_GPIO_PIN_ADDR                        UMBA_PINADDR_PB10
#define UART1_TX_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PB10, UMBA_GPIO_DIRECTION_OUT
#define UART1_TX_GPIO_PIN_SOURCE                      GPIO_PinSource10
#define UART1_TX_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_OUT

#define UART1_RX_GPIO                                 GPIOB
#define UART1_RX_GPIO_PIN_NO                          11
#define UART1_RX_GPIO_PIN_ADDR                        UMBA_PINADDR_PB11
#define UART1_RX_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PB11, UMBA_GPIO_DIRECTION_IN
#define UART1_RX_GPIO_PIN_SOURCE                      GPIO_PinSource11
#define UART1_RX_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_IN




// VD9

#define SWDIO_GPIO                                    GPIOA
#define SWDIO_GPIO_PIN_NO                             13
#define SWDIO_GPIO_PIN_ADDR                           UMBA_PINADDR_PA13
#define SWDIO_GPIO_PIN_ADDR_DIR                       UMBA_PINADDR_PA13, UMBA_GPIO_DIRECTION_OUT
#define SWDIO_GPIO_PIN_SOURCE                         GPIO_PinSource13
#define SWDIO_GPIO_PIN_DIRECTION                      UMBA_GPIO_DIRECTION_OUT

#define SWCLK_GPIO                                    GPIOA
#define SWCLK_GPIO_PIN_NO                             14
#define SWCLK_GPIO_PIN_ADDR                           UMBA_PINADDR_PA14
#define SWCLK_GPIO_PIN_ADDR_DIR                       UMBA_PINADDR_PA14, UMBA_GPIO_DIRECTION_OUT
#define SWCLK_GPIO_PIN_SOURCE                         GPIO_PinSource14
#define SWCLK_GPIO_PIN_DIRECTION                      UMBA_GPIO_DIRECTION_OUT

#define SWD_TRACE_GPIO                                GPIOB
#define SWD_TRACE_GPIO_PIN_NO                         3
#define SWD_TRACE_GPIO_PIN_ADDR                       UMBA_PINADDR_PB3
#define SWD_TRACE_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PB3, UMBA_GPIO_DIRECTION_OUT
#define SWD_TRACE_GPIO_PIN_SOURCE                     GPIO_PinSource3
#define SWD_TRACE_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT





// CAN1

#define CAN1_RX_GPIO                                  GPIOB
#define CAN1_RX_GPIO_PIN_NO                           8
#define CAN1_RX_GPIO_PIN_ADDR                         UMBA_PINADDR_PB8
#define CAN1_RX_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PB8, UMBA_GPIO_DIRECTION_OUT
#define CAN1_RX_GPIO_PIN_SOURCE                       GPIO_PinSource8
#define CAN1_RX_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define CAN1_TX_GPIO                                  GPIOB
#define CAN1_TX_GPIO_PIN_NO                           9
#define CAN1_TX_GPIO_PIN_ADDR                         UMBA_PINADDR_PB9
#define CAN1_TX_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PB9, UMBA_GPIO_DIRECTION_OUT
#define CAN1_TX_GPIO_PIN_SOURCE                       GPIO_PinSource9
#define CAN1_TX_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT




// CAN2

#define CAN2_RX_GPIO                                  GPIOB
#define CAN2_RX_GPIO_PIN_NO                           5
#define CAN2_RX_GPIO_PIN_ADDR                         UMBA_PINADDR_PB5
#define CAN2_RX_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PB5, UMBA_GPIO_DIRECTION_OUT
#define CAN2_RX_GPIO_PIN_SOURCE                       GPIO_PinSource5
#define CAN2_RX_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define CAN2_TX_GPIO                                  GPIOB
#define CAN2_TX_GPIO_PIN_NO                           6
#define CAN2_TX_GPIO_PIN_ADDR                         UMBA_PINADDR_PB6
#define CAN2_TX_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PB6, UMBA_GPIO_DIRECTION_OUT
#define CAN2_TX_GPIO_PIN_SOURCE                       GPIO_PinSource6
#define CAN2_TX_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT




// USB

#define USB_N_GPIO                                    GPIOA
#define USB_N_GPIO_PIN_NO                             11
#define USB_N_GPIO_PIN_ADDR                           UMBA_PINADDR_PA11
#define USB_N_GPIO_PIN_ADDR_DIR                       UMBA_PINADDR_PA11, UMBA_GPIO_DIRECTION_OUT
#define USB_N_GPIO_PIN_SOURCE                         GPIO_PinSource11
#define USB_N_GPIO_PIN_DIRECTION                      UMBA_GPIO_DIRECTION_OUT

#define USB_P_GPIO                                    GPIOA
#define USB_P_GPIO_PIN_NO                             12
#define USB_P_GPIO_PIN_ADDR                           UMBA_PINADDR_PA12
#define USB_P_GPIO_PIN_ADDR_DIR                       UMBA_PINADDR_PA12, UMBA_GPIO_DIRECTION_OUT
#define USB_P_GPIO_PIN_SOURCE                         GPIO_PinSource12
#define USB_P_GPIO_PIN_DIRECTION                      UMBA_GPIO_DIRECTION_OUT




// Unclassified

#define LED_GPIO                                      GPIOC
#define LED_GPIO_PIN_NO                               4
#define LED_GPIO_PIN_ADDR                             UMBA_PINADDR_PC4
#define LED_GPIO_PIN_ADDR_DIR                         UMBA_PINADDR_PC4, UMBA_GPIO_DIRECTION_OUT
#define LED_GPIO_PIN_SOURCE                           GPIO_PinSource4
#define LED_GPIO_PIN_DIRECTION                        UMBA_GPIO_DIRECTION_OUT

#define CAN2_TRAFFIC_GPIO                             GPIOB
#define CAN2_TRAFFIC_GPIO_PIN_NO                      2
#define CAN2_TRAFFIC_GPIO_PIN_ADDR                    UMBA_PINADDR_PB2
#define CAN2_TRAFFIC_GPIO_PIN_ADDR_DIR                UMBA_PINADDR_PB2, UMBA_GPIO_DIRECTION_OUT
#define CAN2_TRAFFIC_GPIO_PIN_SOURCE                  GPIO_PinSource2
#define CAN2_TRAFFIC_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_OUT

#define CAN2_STATE_GPIO                               GPIOB
#define CAN2_STATE_GPIO_PIN_NO                        1
#define CAN2_STATE_GPIO_PIN_ADDR                      UMBA_PINADDR_PB1
#define CAN2_STATE_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PB1, UMBA_GPIO_DIRECTION_OUT
#define CAN2_STATE_GPIO_PIN_SOURCE                    GPIO_PinSource1
#define CAN2_STATE_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define CAN1_TRAFFIC_GPIO                             GPIOB
#define CAN1_TRAFFIC_GPIO_PIN_NO                      0
#define CAN1_TRAFFIC_GPIO_PIN_ADDR                    UMBA_PINADDR_PB0
#define CAN1_TRAFFIC_GPIO_PIN_ADDR_DIR                UMBA_PINADDR_PB0, UMBA_GPIO_DIRECTION_OUT
#define CAN1_TRAFFIC_GPIO_PIN_SOURCE                  GPIO_PinSource0
#define CAN1_TRAFFIC_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_OUT

#define CAN1_STATE_GPIO                               GPIOC
#define CAN1_STATE_GPIO_PIN_NO                        5
#define CAN1_STATE_GPIO_PIN_ADDR                      UMBA_PINADDR_PC5
#define CAN1_STATE_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PC5, UMBA_GPIO_DIRECTION_OUT
#define CAN1_STATE_GPIO_PIN_SOURCE                    GPIO_PinSource5
#define CAN1_STATE_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT




