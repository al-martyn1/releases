#pragma once

#include "uart/uart_handle.h"
#include "can/i_can.h"
#include "umba/dump.h"

#include "lawicel_slcan.h"

#include "periph_drivers/serial/can_device_base.h"
#include "periph_drivers/serial/can_handle.h"


#ifdef USE_LOUT
    extern umba::SimpleFormatter          lout;
#endif

namespace umba
{



class LawicelSlcanSlaveStm32 : public slcan::LawicelSlcanSlaveImplBase
{

    virtual void logCommand( const char *pCmdText )
    {
        using namespace umba::omanip;

        umba::time_service::TimeTick tickNow   = umba::time_service::getCurTimeMs();
        #ifdef USE_LOUT
        lout<<"CH"<<portNumber<<" ("<<tickNow<<"): "<<pCmdText<<"\n"<<flush;
        #endif
    }

    virtual void logCommandError()
    {
        using namespace umba::omanip;

        umba::time_service::TimeTick tickNow   = umba::time_service::getCurTimeMs();

        #ifdef USE_LOUT
        lout<<"CH"<<portNumber<<" ("<<tickNow<<"): ERROR!!!\n"<<flush;
        #endif
    }

    virtual void logSentReply( const char *pReply, std::size_t nBytes )
    {
         using namespace umba::omanip;

         if (nBytes>32)
            nBytes = 32;

        umba::time_service::TimeTick tickNow   = umba::time_service::getCurTimeMs();

        char buf[128];
        #ifdef USE_LOUT
        lout<<"CH"<<portNumber<<": Sent reply ("<<tickNow<<"): " <<umba::dump( &buf[0], (const uint8_t*)pReply, nBytes) << "\n"<<flush;
        #endif
    }


    virtual bool setCanState( CanState canState
                            , uint32_t canSpeed = 0 //!< Only for canState's canLoopback, canListen or canActive
                            )
    {
        /*
        canInactive,
        canLoopback, // active in loopback mode
        canListen,   // active in listen mode (silent)
        canActive    // active in normal mode
        */
        umba::periph::drivers::CanDeviceBase *pCanDevice = dynamic_cast<umba::periph::drivers::CanDeviceBase*>(m_pCanHandle);
        if (!pCanDevice)
            return false;

        switch(canState)
        {
            case CanState::canInactive:
                           pCanDevice->close();
                           return true;

            case CanState::canLoopback:
                           return false;

            case CanState::canListen:
                           pCanDevice->open( canSpeed, true );
                           return true;

            case CanState::canActive:
                           pCanDevice->open( canSpeed, false );
                           return true;
        }

        return false;
    }

    virtual bool canSend( const umba::periph::CanFrame &canFrame )
    {
        m_pCanHandle->transmitMessage(canFrame);
        return true;
    }

    virtual CanStatusFlags getCanStatusFlags()
    {
        //isReadyToTransmit
        unsigned flags = 0;


        if (!m_pCanHandle->isReadyToTransmit())
        {
            flags |= (unsigned)CanStatusFlags::transmitFifoFull;
        }

        //umba::periph::drivers::CanDeviceBase *pCanDevice = dynamic_cast<umba::periph::drivers::CanDeviceBase*>(m_pCanHandle);
        umba::periph::drivers::CommDevice<CAN_TypeDef*> *pCommDevice = dynamic_cast< umba::periph::drivers::CommDevice<CAN_TypeDef*> * >(m_pCanHandle);
        if (pCommDevice)
        {
            //umba::periph::CanBusStatus
            unsigned busStatus = pCommDevice->getCommBusStatus();

            if (busStatus & (unsigned)umba::periph::CanBusStatus::warning)
                flags |= (unsigned)CanStatusFlags::errorWarning;

            if (busStatus & (unsigned)umba::periph::CanBusStatus::passive)
                flags |= (unsigned)CanStatusFlags::errorPassive;

            if (busStatus & (unsigned)umba::periph::CanBusStatus::busOff)
                flags |= (unsigned)CanStatusFlags::busError;
        }

        return (CanStatusFlags)flags;
/*
        unsigned canErr = (unsigned)m_pCanHandle->getErrorState( );
        // umba::periph::CanError

        uint8_t canStatusFlags = 0;

        if (canErr = (unsigned)umba::periph::CanError)

enum class CanError : unsigned
{
    noError           = 0,  // 000: No Error
    stuffError        = 1,  // 001: Stuff Error
    formError         = 2,  // 010: Form Error
    ackError          = 3,  // 011: Acknowledgment Error
    recessiveBitError = 4,  // 100: Bit recessive Error
    dominantBitError  = 5,  // 101: Bit dominant Error
    crcError          = 6,  // 110: CRC Error
    softError         = 7   // 111: Set by software
};
*/

        //CanStatusFlags canStatusFlags = (CanStatusFlags)0

        //return (CanStatusFlags)0;
/*
    enum class CanStatusFlags : uint8_t
    {
        receiveFifoFull   = 0x01,
        transmitFifoFull  = 0x02,
        errorWarning      = 0x04,
        dataOverrun       = 0x08,
        errorPassive      = 0x20,
        arbitrationLost   = 0x40,
        busError          = 0x80
    };
*/
    }

    virtual void waitUartDataSent( uint32_t speed, std::size_t nBytes )
    {
        while( !m_pUartHandle->isTransmitComplete()) {}
    }

    virtual void setUartSpeed( uint32_t speed )
    {
        while( !m_pUartHandle->isTransmitComplete()) {}
        m_pUartHandle->changeBaudrate( speed / 2 ); // hack
    }

    virtual void uartSend( const uint8_t *pData, std::size_t nBytes )
    {
        while( !m_pUartHandle->isTransmitComplete()) {}
        m_pUartHandle->sendLocalArray(pData, nBytes);
        logSentReply( (const char *)pData, nBytes );
    }

    LawicelSlcanSlaveStm32(  )
    : LawicelSlcanSlaveImplBase(0, 9, 8) // , uint8_t _uartMaxSpeedIndex, uint8_t _canMaxSpeedIndex = 8
    , m_pUartHandle(0)
    , m_pCanHandle(0)
    {
    }

public:

    LawicelSlcanSlaveStm32( uint8_t _portNumber, uart::Handle *pUartHandle, umba::periph::drivers::CanHandle *pCanHandle)
    : slcan::LawicelSlcanSlaveImplBase(_portNumber, 9, 8) // , uint8_t _uartMaxSpeedIndex, uint8_t _canMaxSpeedIndex = 8
    , m_pUartHandle(pUartHandle)
    , m_pCanHandle(pCanHandle)
    {
    }


    virtual
    void pollUart( )
    {
        while(m_pUartHandle->isNewByte())
        {
            uint8_t newByte = m_pUartHandle->getByte();
            receiveByte( newByte );
        }

    }

    virtual bool tryReceiveCanMessageRetransmittToUart()
    {
        umba::periph::drivers::CanFrame      msg;
        umba::periph::drivers::CanFrameInfo  frameInfo;
        if (!m_pCanHandle->tryToReceiveEx( msg, frameInfo ))
            return false;

        std::size_t nBytesToSend = generateFrameTransmitRequest( msg, frameInfo );
        requestBuf[nBytesToSend++] = cr;
        if (crlfMode)
           requestBuf[nBytesToSend++] = lf;

        uartSend( &requestBuf[0], nBytesToSend );

        return true;
    }


    virtual
    void pollCan( )
    {
        if (!autoPoll)
            return;

        if (canState!=CanState::canListen && canState!=CanState::canActive) return;

        while(tryReceiveCanMessageRetransmittToUart())
        {}
    }


protected:

    uart::Handle                     *m_pUartHandle;
    umba::periph::drivers::CanHandle *m_pCanHandle;

}; // class LawicelSlcanSlaveStm32


    /*
        ICan

        virtual ReturnState transmitMessage( const CanMessage & msg ) = 0; 
        
        // прием
        virtual bool tryToReceive( CanMessage & msg ) = 0;

        virtual bool isReadyToTransmit( void ) = 0;

        virtual bool areAllTransmitsComplete( void ) = 0;

    */



} // namespace umba

