#pragma once

#include "impl_base.h"

#include "umba/time_service.h"

#include <string>


namespace slcan
{

class LawicelSlcanMasterImplBase : public LawicelSlcanImplBase
{

public:

    LawicelSlcanMasterImplBase( uint8_t _uartMaxSpeedIndex, uint8_t _canMaxSpeedIndex = 8)
    : LawicelSlcanImplBase(true, _uartMaxSpeedIndex, _canMaxSpeedIndex)
    {}


protected:


    struct ReplyInfo
    {
        char                          code;
        uint8_t                       byteData;
        umba::periph::CanFrame        frame;
        umba::periph::CanFrameInfo    frameInfo;
        std::string                   stringInfo;
    }

    typedef umba::containers::static_cycle_deque<ReplyInfo>                           reply_queue_container_type;
    typedef umba::containers::safe_queue< ReplyInfo, reply_queue_container_type >     reply_queue_type;


    std::string  versionNumberString  ;
    std::string  serialNumberString   ;
    std::string  internalInterfaceName; // Ex
    std::string  deviceTypeName       ; // Ex

    volatile std::size_t  goodReplyCounter  ;
    volatile std::size_t  errReplyCounter   ;
    volatile std::size_t  emptyReplyCounter ;

    reply_queue_type      replyQueue;


    void clearDeviceInfo()                {         versionNumberString  .clear();    serialNumberString.clear();    internalInterfaceName.clear();    deviceTypeName .clear();    }
    bool isAnyDeviceInfoReceived()  const { return !versionNumberString  .empty() || !serialNumberString.empty() || !internalInterfaceName.empty() || !deviceTypeName .empty(); }
    bool isBaseDeviceInfoReceived() const { return !versionNumberString  .empty() && !serialNumberString.empty(); }
    bool isExDeviceInfoReceived()   const { return !internalInterfaceName.empty() && !deviceTypeName    .empty(); }
    bool isAllDeviceInfoReceived()  const { return isBaseDeviceInfoReceived() && isExDeviceInfoReceived(); }

    void clearReplies()
    {
        replyQueue.clear();
    }

    void pushReply( char code, const umba::periph::CanFrame &frame, const umba::periph::CanFrameInfo &frameInfo )
    {
        ReplyInfo ri;
        ri.code      = code;
        ri.frame     = frame;
        ri.frameInfo = frameInfo;
        replyQueue.push(ri);
    }

    void pushReply( char code, const std::string &stringInfo )
    {
        ReplyInfo ri;
        ri.code        = code;
        ri.stringInfo  = stringInfo;
        replyQueue.push(ri);
    }

    void pushReply( char code )
    {
        ReplyInfo ri;
        ri.code        = code;
        replyQueue.push(ri);
    }

    void pushReply( char code, uint8_t byteData )
    {
        ReplyInfo ri;
        ri.code        = code;
        ri.byteData    = byteData;
        replyQueue.push(ri);
    }


    void clearReplyCounters()
    {
        goodReplyCounter  = 0;
        errReplyCounter   = 0;
        emptyReplyCounter = 0;
    }

    void sendScanRequests( uint32_t curSpeed, std::size_t & reqCnt )
    {
        static char *scanRequest = "\r\r\rV\rN\r"; // "Ni\rNn\r";
        std::size_t len = std::strlen(scanRequest);
        uartSend( (const uint8_t*)scanRequest, len );
        waitUartDataSent(curSpeed, len);
        ++reqCnt;
    }

    void parseIncomingFrameAndPush( char frameCode /* t/T/r/R */ )
    {
        umba::periph::CanFrame     frame;
        umba::periph::CanFrameInfo frameInfo;

        if (!parseFrameTransmitRequest( frame, (frameCode=='R' || frameCode=='T') ? 8 : 3, frameInfo ))
            return;

        pushReply( frameCode, frame, frameInfo );
    }





public:

    // in locking mode
    uint8_t scanUartForDevice( bool dontTestSlowSpeeds = true )
    {
        // V[CR], N[CR], Ni[CR], Nn[CR]

        uint8_t uartSpeedCode = 0;
        for(; uartSpeedCode<=uartMaxSpeedIndex; ++uartSpeedCode)
        {
            uint32_t speed = getUartSpeedTable()[uartSpeedCode];
            setUartSpeed(speed);
            clearDeviceInfo();
            slReset();

            umba::time_service::TimeTick tickStart = umba::time_service::getCurTimeMs();
            umba::time_service::TimeTick tickNow   = umba::time_service::getCurTimeMs();

            // 2400/10 = 240 байт в секунду
            // 9600/10 = 960 байт в секунду
            // V[CR]   : "V1234[CR]"   - 6
            // VN[CR]  : "VNRTC USB-CAN Adapter[CR]" - 22
            // N[CR]   : "NRTC0[CR]"   - 6
            // NI[CR]  : "NICAN0[CR]"  - 7
            // 6+6+7+22 = 41 - на  2400  - 170 ms, пусть будет 200
            //               - на  9600  - 42 ms, пусть будет 50
            //               - на 19200  - 21 ms, пусть будет 30

            // Всего - 10 скоростей, по 50 ms на одну скорость - 0.5 + 0.2 итого 0.7, 0.7*256 = 179.2 сек. на 256 возможных портов. Хм, долго
            // Если менять периоды динамически, то 8*30+50+200    = 490 мс, немного получше
	        //                                     7*24+30+50+200 = 448 мс, ещё немного получше, 114.688 на 256 возможных портов. Не айс, но на треть сократили.
            //                                     7*24+30        = 198 мс - уже круто, 50 секунд, на 20 портов - 4 секунды
            // Надо будет проверить надёжность нахождения девайсов таким образом
            // При 150 мс ожидания - работает, минимум - 130, печаль

            if (speed<=9600u && dontTestSlowSpeeds)
                continue;

            if (!openUart())
                continue;

            umba::time_service::TimeTick maxTick = 150; // 130 - good, but 150 is better 1000; // 24;

            if (speed==2400u)
                maxTick = 200;
            else if (speed==9600u)
                maxTick = 50;
            else if (speed==19200u)
                maxTick = 30;

            const umba::time_service::TimeTick halfMaxTick = maxTick/2;

            umba::time_service::TimeTick ticksElapsed = tickNow - tickStart;


            std::size_t reqCnt = 0;
            sendScanRequests(speed, reqCnt);

            std::size_t pollCount = 0;


            while( !isAllDeviceInfoReceived() && ticksElapsed<maxTick)
            {
                pollUart(); 
                pollCount++;
                tickNow      = umba::time_service::getCurTimeMs();
                ticksElapsed = tickNow - tickStart;
                if (ticksElapsed>=halfMaxTick && reqCnt<2)
                    sendScanRequests(speed, reqCnt);
            }

            closeUart();

            if (isAnyDeviceInfoReceived())
                break;

        } // for(; uartSpeedCode<=uartMaxSpeedIndex; ++uartSpeedCode)

        if (isAnyDeviceInfoReceived())
            return uartSpeedCode;

        return (uint8_t)-1;
    }

    virtual void processError()
    { 
        ++errReplyCounter;
        pushReply( (char)bell );
    }


    bool waitForEmptyReply( umba::time_service::TimeTick tickWait )
    {
        volatile std::size_t prev = emptyReplyCounter;

        umba::time_service::TimeTick tickStart = umba::time_service::getCurTimeMs();
        umba::time_service::TimeTick tickNow   = umba::time_service::getCurTimeMs();

        umba::time_service::TimeTick ticksElapsed = tickNow - tickStart;
        while(ticksElapsed<tickWait && prev == emptyReplyCounter)
        {
            pollUart();
            tickNow      = umba::time_service::getCurTimeMs();
            ticksElapsed = tickNow - tickStart;
        }

        return prev != emptyReplyCounter;
    }


    virtual bool processReply()
    {
        // Конечный CR в буффер не помещается

        if (bufPos<1)
        {
            //return false;
            //uartSend( cr ); // Ok
            ++emptyReplyCounter;
            pushReply( (char)cr );
            return true;
        }

        uint8_t cmd = commandBuf[0];

        std::size_t dataLen = bufPos - 1;

        const char *strData = (const char *)&commandBuf[1];

        switch(cmd)
        {
            // Setup CAN bit rate
            case 'S':  return true;

            // Open the CAN channel
            case 'O':  return true;

            // Open the CAN channel intlisten only mode (silent/receving)
            case 'L':  return true;

            // Close the CAN channel
            case 'C':  return true;

            // Received standard CAN frame
            case 't':
                parseIncomingFrameAndPush('t');
                return true;

            // Received extended CAN frame
            case 'T':
                parseIncomingFrameAndPush('T');
                return true;

            // Received standard RTR CAN frame
            case 'r':
                parseIncomingFrameAndPush('r');
                return true;

            // Received extended RTR CAN frame
            case 'R':
                parseIncomingFrameAndPush('R');
                return true;

            case 'P': return true;


            case 'A': pushReply( 'A' ); return true;


            case 'F':
            {
                if (dataLen!=2)
                    return false;

                unsigned flags = 0;
                for(auto i = 0u; i!=2; ++i)
                {
                    int d = umba::parse_utils::toDigit( strData[i] );
                    if (d<0 || d>15)
                        return false;

                    flags <<= 4;
                    flags |= (unsigned)d;
                }

                //UNDONE: !!! Need to process flags

                return true;
            }


            case 'X':
                if (dataLen>0)
                    pushReply('X', (uint8_t)*strData - '0');
                else
                    pushReply( (char)cr );
                return true;


            case 'Z': 
                      //pushReply( 'Z' );
                      return true;

            case 'z':
                      pushReply( 'z' );
                      return true;


            // UART baud rate setup
            case 'U':
                      //pushReply( 'U' );
                      return true;


            // Get version number both hardware and software
            case 'V':
            {
                if (bufPos>1) // reply
                {
                    uint8_t subCommand = commandBuf[1];
                    if (subCommand=='+')
                    {
                        // return interface name
                        strData++; dataLen--;
                        deviceTypeName = std::string(strData, dataLen); 
                        pushReply( 'v', std::string(strData, dataLen) );
                    }
                    else
                    {
                        if (dataLen>4)
                            dataLen = 4;
                        versionNumberString = std::string(strData, dataLen);
                        pushReply( 'V', std::string(strData, dataLen) );
                    }
                }
                return true;
            }

            // Get serial number - we use the portNumber as serial to identify port on the our device
            case 'N':
            {
                if (bufPos>1) // reply
                {
                    uint8_t subCommand = commandBuf[1];
                    if (subCommand=='+')
                    {
                        // return interface name
                        strData++; dataLen--;
                        internalInterfaceName = std::string(strData, dataLen); 
                        pushReply( 'n', std::string(strData, dataLen) );
                    }
                    else
                    {
                        if (dataLen>4)
                            dataLen = 4;
                        serialNumberString = std::string(strData, dataLen);
                        pushReply( 'N', std::string(strData, dataLen) );
                    }
                }
                
                return true;
            }


            default: return false;
        }

        return false;
    }

}; // class LawicelSlcanMasterImplBase




} // namespace slcan

