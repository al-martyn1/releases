#pragma once

#include "impl_base.h"

namespace slcan
{


class LawicelSlcanSlaveImplBase : public LawicelSlcanImplBase
{

protected:



    virtual bool setCanState( CanState canState
                            , uint32_t canSpeed = 0 //!< Only for canState's canLoopback, canListen or canActive
                            )
    {
        return false; // Переопределить в наследнике
    }

    virtual bool canSend( const umba::periph::CanFrame &canFrame )
    {
        return false; // Переопределить в наследнике
    }

    virtual CanStatusFlags getCanStatusFlags()
    {
        return (CanStatusFlags)0;
    }

    virtual bool tryReceiveCanMessageRetransmittToUart()
    {
        return true;
    }


    uint8_t     portNumber; // 0 or 1
    CanState    canState;
    uint8_t     canSpeedCode;



    virtual bool processCommand()
    {
        if (bufPos<1)
        {
            //return false;
            uartSendCommand( cr ); // Ok
            return true;
        }

        uint8_t cmd = commandBuf[0];

        switch(cmd)
        {
            // Setup CAN bit rate
            case 'S':
            {
                if (bufPos<2)
                    return false;

                if (canState!=canInactive)
                    return false;

                int d = umba::parse_utils::toDigit( commandBuf[1] );
                if (d<0)
                    return false;

                uint8_t canSpeedCodeTmp = (uint8_t)d;
                if (canSpeedCodeTmp>canMaxSpeedIndex)
                    return false;

                canSpeedCode = canSpeedCodeTmp;
                uartSendCommand(ok);
                return true;
            }


            // Setup bit rate with BTR0/BTR1 - not supported
            case 's':
                return false;


            // Open the CAN channel
            case 'O':
            {
                if (canState!=canInactive)
                    return false;

                uint32_t canSpeed = getCanSpeedTable()[canSpeedCode];

                if (!setCanState( canActive, canSpeed ))
                    return false;
            
                canState = canActive;
                uartSendCommand(ok);
                return true;
            }


            // Open the CAN channel in listen only mode (silent/receving)
            case 'L':
            {
                if (canState!=canInactive)
                    return false;

                uint32_t canSpeed = getCanSpeedTable()[canSpeedCode];

                if (!setCanState( canListen, canSpeed ))
                    return false;
            
                canState = canListen;
                uartSendCommand(ok);
                return true;
            }


            // Close the CAN channel
            case 'C':
            {
                if (canState==canInactive)
                    return false;

                if (!setCanState( canInactive, 0 /* canSpeed */  ))
                    return false;

                canState = canInactive;
                uartSendCommand(ok);
                return true;
            }

            // Transmit standard CAN_frame
            case 't':
            {
                if (canState!=canActive)
                    return false;

                umba::periph::CanFrame     canFrame;
                umba::periph::CanFrameInfo frameInfo;
                if (!parseFrameTransmitRequest( canFrame, 3  /* caIdLen */, frameInfo))
                    return false;

                if ((canFrame.can_id&CAN_SFF_MASK)!=canFrame.can_id) // check id is in valid range
                    return false;

                if (!canSend( canFrame ))
                    return false;

                if (!autoPoll)
                {
	                    uartSendCommand(ok);
                }
                else
                {
                    commandBuf[0] = 'z';
                    uartSendCommandBuf(1);
                }

                return true;
            }


            // Transmit extended CAN_frame
            case 'T':
            {
                if (canState!=canActive)
                    return false;

                umba::periph::CanFrame canFrame;
                umba::periph::CanFrameInfo frameInfo;
                if (!parseFrameTransmitRequest( canFrame, 8  /* caIdLen */, frameInfo))
                    return false;

                if ((canFrame.can_id&CAN_EFF_MASK)!=canFrame.can_id) // check id is in valid range
                    return false;

                canFrame.can_id |= CAN_EFF_FLAG;

                if (!canSend( canFrame ))
                    return false;

                if (!autoPoll)
                {
                    uartSendCommand(ok);
                }
                else
                {
                    commandBuf[0] = 'Z';
                    uartSendCommandBuf(1);
                }

                return true;
            }


            // Transmit standard CAN_frame
            case 'r':
            {
                if (canState!=canActive)
                    return false;

                umba::periph::CanFrame canFrame;
                umba::periph::CanFrameInfo frameInfo;
                if (!parseFrameTransmitRequest( canFrame, 3  /* caIdLen */, frameInfo))
                    return false;

                if ((canFrame.can_id&CAN_SFF_MASK)!=canFrame.can_id) // check id is in valid range
                    return false;

                canFrame.can_id |= CAN_RTR_FLAG;

                if (!canSend( canFrame ))
                    return false;

                if (!autoPoll)
                {
                    uartSendCommand(ok);
                }
                else
                {
                    commandBuf[0] = 'z';
                    uartSendCommandBuf(1);
                }

                return true;
            }


            // Transmit extended CAN_frame
            case 'R':
            {
                if (canState!=canActive)
                    return false;

                umba::periph::CanFrame canFrame;
                umba::periph::CanFrameInfo frameInfo;
                if (!parseFrameTransmitRequest( canFrame, 8  /* caIdLen */, frameInfo))
                    return false;

                if ((canFrame.can_id&CAN_EFF_MASK)!=canFrame.can_id) // check id is in valid range
                    return false;

                canFrame.can_id |= CAN_EFF_FLAG | CAN_RTR_FLAG;

                if (!canSend( canFrame ))
                    return false;

                if (!autoPoll)
                {
                    uartSendCommand(ok);
                }
                else
                {
                    commandBuf[0] = 'Z';
                    uartSendCommandBuf(1);
                }

                return true;
            }


            case 'P':
            {
                if (canState==canInactive)
                    return false;

                if (autoPoll)
                    return false;

                if (!tryReceiveCanMessageRetransmittToUart())
                    uartSendCommand(ok);

                return true;
            }


            case 'A':
            {
                if (canState==canInactive)
                    return false;

                if (autoPoll)
                    return false;

                unsigned sentCounter = 0;
                while (tryReceiveCanMessageRetransmittToUart())
                {
                    sentCounter++;
                }

                //if (sentCounter>0)
                {
                    commandBuf[0] = 'A';
                    uartSendCommandBuf(1);
                }

                //uartSendCommand(ok);
                return true;
            }


            case 'F':
            {
                if (canState==canInactive)
                    return false;

                uint8_t flags = (uint8_t)getCanStatusFlags();
                umba::dumpSolid( (char*)&commandBuf[1], (const uint8_t *)&flags, sizeof(flags) );
                uartSendCommandBuf(3);
                return true;
            }

            case 'X':
            {
                if (canState!=canInactive)
                    return false;

                if (bufPos<2) // extention: X[CR] return current autopoll mode
                {
                    commandBuf[1] = autoPoll ? '1' : '0';
                    uartSendCommandBuf(2);
                    return true;
                }
                else
                {
                    if (commandBuf[1]=='0')
                        autoPoll = false;
                    else if (commandBuf[1]=='1')
                        autoPoll = true;
                    else
                        return false;
                }

                uartSendCommand(ok);
                return true;
            }


            case 'Z':
            {
                if (canState!=canInactive)
                    return false;

                if (bufPos<2) // extention: Z[CR] return current autopoll mode
                {
                    commandBuf[1] = sendTimestamp ? '1' : '0';
                    uartSendCommandBuf(2);
                    return true;
                }
                else
                {
                    if (commandBuf[1]=='0')
                        sendTimestamp = false;
                    else if (commandBuf[1]=='1')
                        sendTimestamp = true;
                    else if (commandBuf[1]=='C')
                    {
                        if (bufPos<3)
                        {
                            commandBuf[2] = sendSeqNumber ? '1' : '0';
                            uartSendCommandBuf(3);
                            return true;
                        }
                        if (commandBuf[2]=='0')
                            sendSeqNumber = false;
                        else if (commandBuf[2]=='1')
                            sendSeqNumber = true;
                        else
                            return false;
                    }
                    else
                        return false;
                }

                uartSendCommand(ok);
                return true;
            }


            // UART baud rate setup
            case 'U':
            {
                if (bufPos<2)
                    return false;

                int d = umba::parse_utils::toDigit( commandBuf[1] );
                if (d<0)
                    return false;

                uint8_t uartSpeedCode = (uint8_t)d;
                if (uartSpeedCode>uartMaxSpeedIndex)
                    return false;

                uint32_t speed = getUartSpeedTable()[uartSpeedCode];
                uartSendCommand( cr ); // Ok
                setUartSpeed(speed);
                //uartSend( &commandBuf[0], 2 ); // Send echo on new speed
                return true;
            }

            // Get version number both hardware and software
            case 'V':
            {
                if (bufPos>1) // extention
                {
                    uint8_t subCommand = commandBuf[1];
                    if (subCommand=='+')
                    {
                        crlfMode = true;
                        std::strcpy( (char*)&commandBuf[1], "+RTC USB-CAN Adapter" );
                        uartSendCommandBuf(std::strlen((char*)&commandBuf[0]));
                    }
                    else if (subCommand=='-')
                    {
                        crlfMode = false;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    auto tmp = versionCode;
                    for(auto i=0u; i!=4; ++i)
                    {
                        commandBuf[1+i] = umba::format_utils::digitToChar(tmp&0x0F, umba::format_utils::CaseParam::upper);
                        tmp>>=4;
                    }
                    std::reverse((char*)&commandBuf[1], (char*)&commandBuf[1+4]);
                    uartSendCommandBuf(5);
                }

                return true;
            }

            // Get serial number - we use the portNumber as serial to identify port on the our device
            case 'N':
            {
                if (bufPos>1) // extention
                {
                    uint8_t subCommand = commandBuf[1];
                    if (subCommand=='+')
                    {
                        // return interface name
                        crlfMode = true;
                        std::memcpy( (void*)&commandBuf[2], "CAN0", 4 );
                        commandBuf[5] += portNumber;
                        uartSendCommandBuf(6);
                    }
                    else if (subCommand=='-')
                    {
                        crlfMode = false;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    auto tmp = serialNumber;
                    for(auto i=0u; i!=4; ++i)
                    {
                        commandBuf[1+i] = umba::format_utils::digitToChar(tmp&0x0F, umba::format_utils::CaseParam::upper);
                        tmp>>=4;
                    }
                    std::reverse((char*)&commandBuf[1], (char*)&commandBuf[1+4]);
                    uartSendCommandBuf(5);
                }
                
                return true;
            }


            default: return false;
        }

        return false;
    }


public:

    LawicelSlcanSlaveImplBase( uint8_t _portNumber, uint8_t _uartMaxSpeedIndex, uint8_t _canMaxSpeedIndex = 8)
    : LawicelSlcanImplBase(false, _uartMaxSpeedIndex, _canMaxSpeedIndex)
    , portNumber(_portNumber)
    , canState(canInactive)
    , canSpeedCode(4) /* 125K */
    {}

}; // class LawicelSlcanSlaveImplBase






} // namespace slcan

