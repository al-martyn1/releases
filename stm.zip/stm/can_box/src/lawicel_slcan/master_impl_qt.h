#pragma once

#include "master_impl_base.h"
#include "umba/time_service.h"

#include <QSerialPort>
#include <QTest>


#ifdef USE_LOUT
    extern umba::SimpleFormatter          lout;
#endif



namespace umba
{

class LawicelSlcanMasterQtImpl : public slcan::LawicelSlcanMasterImplBase
{

public:

    static void configureSerialPort( QSerialPort &qSerialPort )
    {
        qSerialPort.setDataBits(QSerialPort::Data8);
        qSerialPort.setFlowControl(QSerialPort::NoFlowControl);
        qSerialPort.setParity(QSerialPort::NoParity);
        qSerialPort.setStopBits(QSerialPort::OneStop);
        qSerialPort.setReadBufferSize(1024);
    }

    LawicelSlcanMasterQtImpl( uint8_t _uartMaxSpeedIndex = 9, uint8_t _canMaxSpeedIndex = 8)
    : slcan::LawicelSlcanMasterImplBase(_uartMaxSpeedIndex, _canMaxSpeedIndex)
    , m_qSerialPort()
    {
        configureSerialPort(m_qSerialPort);
    }

    void setUartPort( QString portName )
    {
        m_qSerialPort.setPortName( portName ); 
    }

    virtual void setUartSpeed( uint32_t speed )
    {
        m_qSerialPort.setBaudRate( (QSerialPort::BaudRate)speed, QSerialPort::AllDirections);
    }

    virtual bool openUart()
    {
        if (!m_qSerialPort.open(QIODevice::ReadWrite))
            return false;
        //m_qSerialPort.clear();
        m_qSerialPort.readAll();

        // Possible bug!!!
        while(m_qSerialPort.waitForReadyRead(100));
        {
            m_qSerialPort.clear(QSerialPort::AllDirections);
        }
        m_qSerialPort.readAll();

        return true;
    }

    virtual bool closeUart()
    {
        m_qSerialPort.close();
        return true;
    }

    bool canReadUart() // const
    {
        char data;
        if (m_qSerialPort.peek( &data, (qint64)1 )==1)
            return true;
        return false;
    }

    virtual void waitUartDataSent( uint32_t speed, std::size_t nBytes )
    {
        // Байт в секунду = speed/10
        umba::time_service::TimeTick waitMs = nBytes*1000/(speed/10);
        umba::time_service::delayMs(waitMs);
    }

    virtual void pollUart( )
    {
        QTest::qWait(0);

        if (!m_qSerialPort.waitForReadyRead(5))
            return;

        if (!canReadUart())
            return;

        char buf[1024];
        auto bytesReaded = m_qSerialPort.read( (char*)&buf[0], 1024 );
        if (bytesReaded==(qint64)-1)
        {
            return ;
        }

        std::size_t i = 0, size = (std::size_t)bytesReaded;
        for(; i!=size; ++i)
        {
            receiveByte(buf[i]);
        }

    }

    virtual void uartSend( const uint8_t *pData, std::size_t nBytes )
    {
        m_qSerialPort.write( (const char*)pData, nBytes );
    }

protected:

    QSerialPort            m_qSerialPort;


};






} // namespace umba

