#pragma once


#include "umba/dump.h"
#include "umba/parse_utils.h"
#include "umba/format_utils.h"

#include "periph/can_defs.h"

#ifdef USE_LOUT
    #include "umba/simple_formatter.h"
#endif

#include  <cstring>
#include  <algorithm>



namespace slcan
{


class LawicelSlcanImplBase
{

public:

    enum CanState
    {
        canInactive,
        canLoopback, // active in loopback mode
        canListen,   // active in listen mode (silent)
        canActive    // active in normal mode
    };

    enum class CanStatusFlags : uint8_t
    {
        receiveFifoFull   = 0x01,
        transmitFifoFull  = 0x02,
        errorWarning      = 0x04,
        dataOverrun       = 0x08,
        errorPassive      = 0x20,
        arbitrationLost   = 0x40,
        busError          = 0x80
    };


protected:

    static const uint8_t cr   = 13;
    static const uint8_t ok   = 13; // alias for cr
    static const uint8_t lf   = 10;
    static const uint8_t bell =  7;

    static const uint8_t maxCommandLen = 62;

    uint8_t     commandBuf[ maxCommandLen + 2 ];
    uint8_t     bufPos;
    bool        masterMode;
    uint16_t    versionCode;
    uint16_t    serialNumber;

    bool        autoPoll;
    bool        crlfMode;
    bool        sendTimestamp;
    bool        sendSeqNumber;

    uint8_t     uartMaxSpeedIndex; // 6 or 9 for extra speeds
    uint8_t     canMaxSpeedIndex ; // 8

    uint8_t     requestBuf[ maxCommandLen + 2 ];

    const uint32_t *getUartSpeedTable()
    {
        static uint32_t tbl[] = {  230400u // U0
                                ,  115200u // U1
                                ,   57600u // U2
                                ,   38400u // U3
                                ,   19200u // U4
                                ,    9600u // U5
                                //,    4800u // а где оно?
                                ,    2400u // U6

                                // extra
                                , 1843200u // U7
                                ,  921600u // U8
                                ,  460800u // U9
                                };
        return &tbl[0];
    }

    const uint32_t *getCanSpeedTable()
    {
        static uint32_t tbl[] = {   10000u // U0
                                ,   20000u // U1 
                                ,   50000u // U2
                                ,  100000u // U3
                                ,  125000u // U4
                                ,  250000u // U5
                                ,  500000u // U6
                                ,  800000u // U7
                                , 1000000u // U8
                                };
        return &tbl[0];
    }


    virtual bool processCommand()  { return false; }
    virtual bool processReply()    { return false; }
    virtual void processError()    { }

    bool processPacketImpl()
    {
        //if (bufPos>=UMBA_COUNT_OF(commandBuf))
        if (bufPos>=maxCommandLen)
            return false;

        if (masterMode)
            return processReply();

        return processCommand();
    }

    bool processPacket()
    {
        bool res = processPacketImpl();
        bufPos = 0; // clear buf
        std::memset( &commandBuf[0], 0, maxCommandLen+1 );
        return res;
    }


    void slReset()
    {
        bufPos  = 0;
    }

    virtual void logCommand( const char *pCmdText )  {}
    virtual void logSentReply( const char *pReply, std::size_t nBytes )  {}
    virtual void logCommandError()  {}

    virtual void setUartSpeed( uint32_t speed ) = 0;
    virtual bool openUart()  { return false; }
    virtual bool closeUart() { return false; }
    virtual void pollUart( ) = 0;
    virtual void waitUartDataSent( uint32_t speed, std::size_t nBytes ) {}
    virtual void uartSend( const uint8_t *pData, std::size_t nBytes ) = 0;

    void uartSendByte( const uint8_t byte )
    {
        uartSend( &byte, 1 );
    }

    void uartSendCommandBuf( std::size_t nBytes, bool appendCr = true )
    {
        if (appendCr)
        {
            commandBuf[nBytes++] = cr;
            if (crlfMode)
               commandBuf[nBytes++] = lf;
        }
        uartSend( &commandBuf[0], nBytes );
    }

    void uartSendCommand( uint8_t code )
    {
        std::size_t nBytes = 0;
        commandBuf[nBytes++] = code;
        if (code==cr)
        {
            if (crlfMode)
               commandBuf[nBytes++] = lf;
        }

        uartSend( &commandBuf[0], nBytes );
    }


    std::size_t generateFrameTransmitRequest( const umba::periph::CanFrame &canFrame, const umba::periph::CanFrameInfo &frameInfo )
    {
        std::size_t  canIdLen = 3;
        uint32_t     canId    = canFrame.can_id;

        std::size_t pos = 0;

        if (canId&CAN_EFF_FLAG) // extended frame
        {
            if (canId&CAN_RTR_FLAG)
                requestBuf[pos] = (uint8_t)'R';
            else
                requestBuf[pos] = (uint8_t)'T';

            canIdLen = 8;

            canId = canId & CAN_SFF_MASK;
        }
        else // standard frame
        {
            if (canId&CAN_RTR_FLAG)
                requestBuf[pos] = (uint8_t)'r';
            else
                requestBuf[pos] = (uint8_t)'t';

            canIdLen = 3;

            canId = canId & CAN_EFF_MASK;
        }

        pos++;

        std::size_t reverseStartPos = pos;
        for( std::size_t i=0; i!=canIdLen; ++i )
        {
            requestBuf[pos++] = umba::format_utils::digitToChar( (unsigned)(canId&0x0F), umba::format_utils::CaseParam::upper );
            canId >>= 4;
        }

        std::reverse( &requestBuf[reverseStartPos], &requestBuf[pos] );

        unsigned dlc = (unsigned)canFrame.can_dlc;
        if (dlc>8)
            dlc = 8;

        requestBuf[pos++] = umba::format_utils::digitToChar( dlc, umba::format_utils::CaseParam::upper );

        for (unsigned i=0; i!=dlc; ++i)
        {
            requestBuf[pos++] = umba::format_utils::digitToChar( (canFrame.data[i]>>4)&0x0F, umba::format_utils::CaseParam::upper );
            requestBuf[pos++] = umba::format_utils::digitToChar( (canFrame.data[i]   )&0x0F, umba::format_utils::CaseParam::upper );
        }

        if (sendTimestamp && (frameInfo.flags&frameInfo.flagTimeStamp))
        {
            reverseStartPos = pos;
            uint32_t timeStamp = frameInfo.timeStamp;
            for( std::size_t i=0; i!=8; ++i )
            {
                requestBuf[pos++] = umba::format_utils::digitToChar( (unsigned)(timeStamp&0x0F), umba::format_utils::CaseParam::upper );
                timeStamp >>= 4;
            }
            std::reverse( &requestBuf[reverseStartPos], &requestBuf[pos] );
        }

        if (sendSeqNumber && (frameInfo.flags&frameInfo.flagSeqNumber))
        {
            requestBuf[pos++] = (uint8_t)'Q';

            reverseStartPos = pos;
            uint32_t seqNumber = frameInfo.seqNumber;
            for( std::size_t i=0; i!=8; ++i )
            {
                requestBuf[pos++] = umba::format_utils::digitToChar( (unsigned)(seqNumber&0x0F), umba::format_utils::CaseParam::upper );
                seqNumber >>= 4;
            }
            std::reverse( &requestBuf[reverseStartPos], &requestBuf[pos] );
        }

        return pos; // +dlc;
    }

    bool parseFrameTransmitRequest( umba::periph::CanFrame &canFrameParseTo, size_t canIdLen /* 3 or 8 */, umba::periph::CanFrameInfo &frameInfo )
    {
        // tiiil...  - t10021133 - ID=0x100, 2 bytes length
        // riiil       t0200     - ID=0x020, 0 bytes length

        if (bufPos<5)
            return false;

        size_t idx = 1;

        //uint32_t canId = 0;
        canFrameParseTo.can_id = 0;

        for( size_t i=0; i!=canIdLen; ++i, ++idx)
        {
            if (idx>=bufPos)
                return false;

            int d = umba::parse_utils::toDigit( commandBuf[idx] );
            if (d<0 || d>=16) // check that is hex digit
                return false;

            canFrameParseTo.can_id <<= 4;
            canFrameParseTo.can_id |= (uint32_t)d;
        }

        if (idx>=bufPos)
            return false;

        int d = umba::parse_utils::toDigit( commandBuf[idx++] );
        if (d<0 || d>=8) // check that is '0'-'8' digit
            return false;

        if (idx>=bufPos)
            return false;

        canFrameParseTo.can_dlc = (uint8_t)d;

        std::memset( (void*)&canFrameParseTo.data[0], 0, 8 );

        for(uint8_t i=0; i!=canFrameParseTo.can_dlc; ++i)
        {
            for(uint8_t b=0; b!=2; ++b, ++idx)
            {
                if (idx>=bufPos)
                    return false;

                int d = umba::parse_utils::toDigit( commandBuf[idx] );
                if (d<0 || d>=16) // check that is hex digit
                    return false;

                canFrameParseTo.data[i] <<= 4;
                canFrameParseTo.data[i]  |= (uint8_t)d;
            }
        }

        if (idx>=bufPos)
            return true;

        while(frameInfo.flags!=frameInfo.flagAllGood)
        {
            uint32_t *pTarget = &frameInfo.timeStamp;
            uint8_t flag = frameInfo.flagTimeStamp;
            if (commandBuf[idx]=='Q')
            {
                pTarget = &frameInfo.seqNumber;
                ++idx;
                flag = frameInfo.flagSeqNumber
            }

            uint32_t &target = *pTarget;
            target = 0;

            for( std::size_t i=0; i!=8; ++i, ++idx )
            {
                if (idx>=bufPos)
                    return true;

                int d = umba::parse_utils::toDigit( commandBuf[idx] );
                if (d<0 || d>=16) // check that is hex digit
                    return true;

                target<<=4;
                target |= (uint32_t)d;
            }

            frameInfo.flags |= flag;
        }

        return true;
    }

    

public:

    LawicelSlcanImplBase( bool _masterMode, uint8_t _uartMaxSpeedIndex, uint8_t _canMaxSpeedIndex = 8 )
    : bufPos(0), masterMode(_masterMode), versionCode(0x1013), serialNumber(0x1234)
    , autoPoll(false)
    , crlfMode(false)
    , sendTimestamp(false)
    , sendSeqNumber(false)
    , uartMaxSpeedIndex(_uartMaxSpeedIndex), canMaxSpeedIndex(_canMaxSpeedIndex)
    {}

    void setVersionCode(uint16_t v)
    {
        versionCode = v;
    }

    void receiveByte( uint8_t b )
    {
        if (b==lf)
            return; // Always skip LFs

        if (b==bell && masterMode)
        {
            processError();
            slReset();
            return;
        }

        if (b==cr)
        {
             commandBuf[bufPos] = 0; // Делаем ASCII-Z строку
             if (!masterMode)
                 logCommand((const char*)&commandBuf[0]);

             if (masterMode)
             {
                 processPacket();
             }
             else
             {
                 if (!processPacket())
                 {
                     uartSendCommand(bell);
                     logCommandError();
                 }
             }

             slReset();
             return;
        }

        //if (bufPos<UMBA_COUNT_OF(commandBuf)) // буфер полон
        if (bufPos<maxCommandLen) // буфер не забит
            commandBuf[bufPos++] = b;

    }


}; // class LawicelSlcanImplBase






} // namespace slcan

