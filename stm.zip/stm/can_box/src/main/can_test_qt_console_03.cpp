#include <QCoreApplication>
#include <QUuid>
#include <QTextStream>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QTest>
#include <QCanBus>

#include <iostream>

#include "umba/umba.h"
#include "ihc/i_octet_stream.h"
#include "ihc/octet_stream_qserialport.h"
#include "ihc/octet_stream_qfiledevice.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"




umba::StdStreamCharWriter    charWritter(std::cout);
umba::SimpleFormatter  lout(&charWritter);


using namespace umba::omanip;





int main(int argc, char *argv[])
{
    using namespace umba::omanip;

    lout << "At start of main"<<endl;
    QCoreApplication app(argc, argv);
    QCoreApplication::setApplicationName("can_test_qt_console");
    QCoreApplication::setApplicationVersion("1.0");

    QStringList	canPlugins = QCanBus::instance()->plugins();
    qDebug().nospace().noquote() << "CAN plugins:";
    qDebug().nospace().noquote() << canPlugins << "\n";

    for (int i = 0; i < canPlugins.size(); ++i)
    {
        QString canPlugin = canPlugins.at(i);

        qDebug().nospace().noquote() << "Looking for '" <<canPlugin<<"' CAN devices";

        QString errorMessage;
        QList<QCanBusDeviceInfo> availableDevices = QCanBus::instance()->availableDevices( canPlugin, &errorMessage );

        if (!errorMessage.isEmpty())
        {
           qDebug().nospace().noquote() << "Error: " << errorMessage;
        }
        else
        {
            for (int i = 0; i < availableDevices.size(); ++i)
            {
                const QCanBusDeviceInfo &info = availableDevices.at(i);

                qDebug().nospace().noquote() << "    "
                                             << "Channel: "<< info.channel() << ", "
                                             << "Name: " << info.name() << " (" << info.description() << "), "
                                             << "FD: " << (info.hasFlexibleDataRate()?"YES":"NO") << ", "
                                             << "Serial: " << info.serialNumber()
                                             ;
            }

        }
    }




    //QList<QCanBusDeviceInfo> availableDevices = QCanBus::instance()->availableDevices(const QString &plugin, QString *errorMessage = nullptr) const
    

    /*
    QString errorString;
    const QList<QCanBusDeviceInfo> devices = QCanBus::instance()->availableDevices(QStringLiteral("socketcan"), &errorString);
    if (!errorString.isEmpty())
        qDebug() << errorString;
    */


    lout<<"Exiting\n"; // <<

    return 0;

}


