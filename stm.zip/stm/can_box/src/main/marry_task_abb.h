#pragma once

#include <string.h>

/*

01.01 Motor speed used
Index   : 0x4001
SubIndex: 1
DataType: INTEGER32
Request : 0x601 : 40 01 40 01 00 00 00 00
Response: 0x581 : 43 01 40 01 2E 8C FF FF
Value   : 0xFFFF8C2E (-29650)

01.07 Motor current
Index   : 0x4001
SubIndex: 7
DataType: INTEGER32
Request : 0x601 : 40 01 40 07 00 00 00 00
Response: 0x581 : 43 01 40 07 7A 0E 00 00
Value   : 0x0E7A (3706)

01.10 Motor torque
Index   : 0x4001
SubIndex: 10
DataType: INTEGER32
Request : 0x601 : 40 01 40 0A 00 00 00 00
Response: 0x581 : 43 01 40 0A E8 FF FF FF
Value   : 0xFFFFFFE8 (-24)

*/

class AbbSumulTask
{

public:

    AbbSumulTask(umba::periph::drivers::CanHandle *pCanHandle) : m_pCanHandle(pCanHandle) {}


protected:

    umba::periph::drivers::CanHandle *m_pCanHandle;

    int32_t m_speed   = -29650 ; // 0x01u
    int32_t m_current =   3706 ; // 0x07u
    int32_t m_torque  =    -24 ; // 0x0Au

    /*
    static uint8_t  m_speedRequest  [4] = { 0x40u, 0x01u, 0x40u, 0x01u };
    static uint8_t  m_currentRequest[4] = { 0x40u, 0x01u, 0x40u, 0x07u };
    static uint8_t  m_torqueRequest [4] = { 0x40u, 0x01u, 0x40u, 0x0Au };
    */
    static const uint8_t  m_requestPrefix [3];

public:

    void work()
    {
        umba::periph::drivers::CanFrame canFrame;
        if (m_pCanHandle->tryToReceive(canFrame))
        {
            if (canFrame.can_id==0x601 && canFrame.can_dlc==8 && memcmp( &canFrame.data[0], &m_requestPrefix[0], 3)==0)
            {
                canFrame.can_id  = 0x581;
                canFrame.data[0] =  0x43;

                switch(canFrame.data[3])
                {
                    case 0x01u: memcpy( &canFrame.data[4], (void*)&m_speed, 4 );
                                if (m_pCanHandle->isReadyToTransmit())
                                    m_pCanHandle->transmitMessage(canFrame);
                                break;

                    case 0x07u: memcpy( &canFrame.data[4], (void*)&m_current, 4 );
                                if (m_pCanHandle->isReadyToTransmit())
                                    m_pCanHandle->transmitMessage(canFrame);
                                break;

                    case 0x0Au: memcpy( &canFrame.data[4], (void*)&m_torque, 4 );
                                if (m_pCanHandle->isReadyToTransmit())
                                    m_pCanHandle->transmitMessage(canFrame);
                                break;
                };
            }
        }
    }


}; // class AbbSumulTask


