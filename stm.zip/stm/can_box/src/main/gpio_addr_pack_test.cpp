#include "uart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/time_service.h"
#include "periph/gpio.h"

#include "usb-can-config.h"


/*
UMBA_PERIPH_DECLARE_PIN( pinMainLed         , LED );

#define LED_GPIO                                      GPIOC
#define LED_GPIO_PIN_NO                               4
#define LED_GPIO_PIN_ADDR                             UMBA_PINADDR_PC4
#define LED_GPIO_PIN_ADDR_DIR                         UMBA_PINADDR_PC4, UMBA_GPIO_DIRECTION_OUT
#define LED_GPIO_PIN_SOURCE                           GPIO_PinSource4
#define LED_GPIO_PIN_DIRECTION                        UMBA_GPIO_DIRECTION_OUT
*/



#ifdef LOG_TO_UART
    umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart2 ) /* .setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false ) */ ;
#else    
    umba::SwvCharWritter               charWritter;
#endif

umba::SimpleFormatter          lout(&charWritter);


#if defined(GPIO_PACK)

    typedef uint32_t   PackedAddr;

    inline PackedAddr packAddr(umba::periph::GpioPinAddr pa)
    {
        return umba::periph::packGpioPinAddr(pa);
    }

    inline umba::periph::GpioPinAddr unpackAddr(PackedAddr pa)
    {
        return umba::periph::unpackGpioPinAddr(pa);
    }

#elif defined(GPIO_SUPERPACK)

    typedef uint16_t   PackedAddr;

    inline PackedAddr packAddr(umba::periph::GpioPinAddr pa)
    {
        return umba::periph::superpackGpioPinAddr(pa);
    }

    inline umba::periph::GpioPinAddr unpackAddr(PackedAddr pa)
    {
        return umba::periph::superunpackGpioPinAddr(pa);
    }

#else

    typedef umba::periph::GpioPinAddr PackedAddr;

    inline PackedAddr packAddr(umba::periph::GpioPinAddr pa)
    {
        return pa;
    }

    inline umba::periph::GpioPinAddr unpackAddr(PackedAddr pa)
    {
        return pa;
    }

#endif

struct PinAddrHolder
{
    PackedAddr addrMainLed;

    PackedAddr addrCanTraffic1;
    PackedAddr addrCanState1  ;

    PackedAddr addrCanTraffic2;
    PackedAddr addrCanState2  ;

};




int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    PinAddrHolder pah;
    pah.addrMainLed     = packAddr(LED_GPIO_PIN_ADDR         );
    pah.addrCanTraffic1 = packAddr(CAN1_TRAFFIC_GPIO_PIN_ADDR);
    pah.addrCanState1   = packAddr(CAN1_STATE_GPIO_PIN_ADDR  );
    pah.addrCanTraffic2 = packAddr(CAN2_TRAFFIC_GPIO_PIN_ADDR);
    pah.addrCanState2   = packAddr(CAN2_STATE_GPIO_PIN_ADDR  );



    uart::uart3.init( UART1_RX_GPIO, UART1_RX_GPIO_PIN_NO
                    , UART1_TX_GPIO, UART1_TX_GPIO_PIN_NO
                    , 115200 // 57600 // 230400
                    );

    uart::uart2.init( UART2_RX_GPIO, UART2_RX_GPIO_PIN_NO
                    , UART2_TX_GPIO, UART2_TX_GPIO_PIN_NO
                    , 115200 // 57600 /* 115200 */
                    );

    using namespace umba::omanip;

    lout<<"Hello"<<endl;


    //UMBA_PERIPH_DECLARE_PIN( pinMainLed         , LED );
    UMBA_PERIPH_DECLARE_PIN_EX( pinMainLed    , unpackAddr(pah.addrMainLed    ), UMBA_GPIO_DIRECTION_OUT );
    UMBA_PERIPH_DECLARE_PIN_EX( pinCanTraffic1, unpackAddr(pah.addrCanTraffic1), UMBA_GPIO_DIRECTION_OUT );
    UMBA_PERIPH_DECLARE_PIN_EX( pinCanState1  , unpackAddr(pah.addrCanState1  ), UMBA_GPIO_DIRECTION_OUT );
    UMBA_PERIPH_DECLARE_PIN_EX( pinCanTraffic2, unpackAddr(pah.addrCanTraffic2), UMBA_GPIO_DIRECTION_OUT );
    UMBA_PERIPH_DECLARE_PIN_EX( pinCanState2  , unpackAddr(pah.addrCanState2  ), UMBA_GPIO_DIRECTION_OUT );

    using namespace umba::periph;

    pinMainLed     = false;
    pinCanTraffic1 = true ;
    pinCanState1   = true ;
    pinCanTraffic2 = false;
    pinCanState2   = false;

    unsigned cnt = 0;

    while(1)
    {
        if (cnt&1)
            pinMainLed        = !pinMainLed;

        pinCanTraffic1    = !pinCanTraffic1;
        pinCanState1      = !pinCanState1  ;
        pinCanTraffic2    = !pinCanTraffic2;
        pinCanState2      = !pinCanState2  ;

        umba::time_service::delayMs(100);

        if (cnt%10 == 0)
           lout<<"Pulse: "<<cnt<<endl;
        cnt++;
    }

    return 0;
}


