#pragma once

#include <string.h>

/*

01.01 Motor speed used
Index   : 0x4001
SubIndex: 1
DataType: INTEGER32
Request : 0x601 : 40 01 40 01 00 00 00 00
Response: 0x581 : 43 01 40 01 2E 8C FF FF
Value   : 0xFFFF8C2E (-29650)

01.07 Motor current
Index   : 0x4001
SubIndex: 7
DataType: INTEGER32
Request : 0x601 : 40 01 40 07 00 00 00 00
Response: 0x581 : 43 01 40 07 7A 0E 00 00
Value   : 0x0E7A (3706)

01.10 Motor torque
Index   : 0x4001
SubIndex: 10
DataType: INTEGER32
Request : 0x601 : 40 01 40 0A 00 00 00 00
Response: 0x581 : 43 01 40 0A E8 FF FF FF
Value   : 0xFFFFFFE8 (-24)

*/

class MerryTestTask
{

public:

    MerryTestTask(umba::periph::drivers::CanHandle *pCanHandle) : m_pCanHandle(pCanHandle)
    {
        m_lastActionTick = umba::time_service::getCurTimeMs();
    }


protected:

    umba::periph::drivers::CanHandle *m_pCanHandle;
    umba::time_service::TimeTick      m_lastActionTick;
    size_t                            m_curRequestedValIdx = 0;

    static const uint8_t  m_requestPrefix  [3];
    static const uint8_t  m_responsePrefix [3];
    static const uint8_t  m_valuesRequested[3];

public:

    void work()
    {
        // Receive replies

        umba::periph::drivers::CanFrame canFrame;
        if (m_pCanHandle->tryToReceive(canFrame))
        {
            if (canFrame.can_id==0x581 && canFrame.can_dlc==8 && memcmp( &canFrame.data[0], &m_responsePrefix [0], 3)==0)
            {
                //canFrame.data[0] = 0x43;

                int32_t val;

                switch(canFrame.data[3])
                {
                    case 0x01u: memcpy( (void*)&val, &canFrame.data[4], 4 ); // speed
                                #ifndef NO_LOG
                                    lout<<"Speed: "<<val<<"\n";
                                #endif
                                break;

                    case 0x07u: memcpy( (void*)&val, &canFrame.data[4], 4 ); // current
                                #ifndef NO_LOG
                                    lout<<"Current: "<<val<<"\n";
                                #endif
                                break;

                    case 0x0Au: memcpy( (void*)&val, &canFrame.data[4], 4 ); // torque
                                #ifndef NO_LOG
                                    lout<<"Torque: "<<val<<"\n";
                                #endif
                                break;
                };
            }
        }

        // Send queries
        umba::time_service::TimeTick tickNow = umba::time_service::getCurTimeMs();
        if ( (tickNow-m_lastActionTick)>300 ) // 300 ms
        {
            memset( &canFrame, 0, sizeof(canFrame) );

            canFrame.can_id = 0x601;

            memcpy( &canFrame.data[0], &m_requestPrefix[0], 3 ); // prefix

            canFrame.data[3] = m_valuesRequested[m_curRequestedValIdx];

            ++m_curRequestedValIdx;
            if (m_curRequestedValIdx>2)
                m_curRequestedValIdx = 0;

            canFrame.can_dlc = 8;

            if (m_pCanHandle->isReadyToTransmit())
            {
                m_pCanHandle->transmitMessage(canFrame);
            }

            m_lastActionTick = umba::time_service::getCurTimeMs();

        }

    }


}; // class AbbSumulTask


