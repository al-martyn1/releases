/*! \file
\brief Пример конфигурации кучи. Копируется в папку config и там настраивается
*/

#include "umba/preprocessor.h"
#include "umba/memory_pools_impl.h"


namespace umba
{

// Пул, работающий только на выделение
#ifdef UMBA_TOO_LOW_MEM
     UMBA_MEM_POOL_FIXED_POOL_ALLOCATE_STATIC_RAW_MEM_SIMPLE(growingRawMemory, 6 *  256);
#else
    UMBA_MEM_POOL_FIXED_POOL_ALLOCATE_STATIC_RAW_MEM_SIMPLE(growingRawMemory,  8 * 1024);
#endif

memory::GrowingMemoryPool growingMemoryPool = memory::GrowingMemoryPool( growingRawMemory, sizeof(growingRawMemory) );

/*
#if !(defined(__x86_64__) || defined(_____LP64_____) || defined(_WIN64))
    #define USE_FIXED_POOL_4
#endif

#ifdef USE_FIXED_POOL_4
    #define DYN_POOL_FIRST_LEVEL 2
#else
    #define DYN_POOL_FIRST_LEVEL 3
#endif


size_t calculateRawChunkSize(size_t chunkItemSize); // chunkItemSize 4, 8, 16, 32 etc
size_t calculateRawChunkSize(size_t chunkItemSize)
{
    return 0;

}
*/
// Пулы кусочков, размер настраивается индивидуально для каждого размера кусочка
// Размеры кусочков являются степенями двойки
// Неиспользуемые размеры кусочков:
//   а) если это большие, с конца, коментируем в трех местах (Raw/Pool/Table) и тогда вообще ничего не объявляется
//   б) если есть пропуски - т.е. 4, 8, 16 - нужны, 32 - не нужен, 64, 128 - опять нужны,
//      тогда просто задаем fixedPoolRaw_X минимального размера

// Объявляем сырые массивы для пулов - настраиваем макс кол-во кусочков здесь
/*
#ifdef USE_FIXED_POOL_4
UMBA_MEM_POOL_FIXED_POOL_ALLOCATE_STATIC_RAW_MEM( fixedPoolRaw_4   , 4   ,   64 );
#endif                                                                   
UMBA_MEM_POOL_FIXED_POOL_ALLOCATE_STATIC_RAW_MEM( fixedPoolRaw_8   , 8   ,   64 );
UMBA_MEM_POOL_FIXED_POOL_ALLOCATE_STATIC_RAW_MEM( fixedPoolRaw_16  , 16  ,   64 );
UMBA_MEM_POOL_FIXED_POOL_ALLOCATE_STATIC_RAW_MEM( fixedPoolRaw_32  , 32  ,   32 );
UMBA_MEM_POOL_FIXED_POOL_ALLOCATE_STATIC_RAW_MEM( fixedPoolRaw_64  , 64  ,   32 );
UMBA_MEM_POOL_FIXED_POOL_ALLOCATE_STATIC_RAW_MEM( fixedPoolRaw_128 , 128 ,    8 );
UMBA_MEM_POOL_FIXED_POOL_ALLOCATE_STATIC_RAW_MEM( fixedPoolRaw_256 , 256 ,    8 );
UMBA_MEM_POOL_FIXED_POOL_ALLOCATE_STATIC_RAW_MEM( fixedPoolRaw_512 , 512 ,    4 );
UMBA_MEM_POOL_FIXED_POOL_ALLOCATE_STATIC_RAW_MEM( fixedPoolRaw_1024, 1024,    2 );
UMBA_MEM_POOL_FIXED_POOL_ALLOCATE_STATIC_RAW_MEM( fixedPoolRaw_2048, 2048,    1 );

// Объявляем пулы
#ifdef USE_FIXED_POOL_4
static FixedSizeMemoryPool   fixedPool_4    ( fixedPoolRaw_4   , sizeof(fixedPoolRaw_4   ), 4    );
#endif
static FixedSizeMemoryPool   fixedPool_8    ( fixedPoolRaw_8   , sizeof(fixedPoolRaw_8   ), 8    );
static FixedSizeMemoryPool   fixedPool_16   ( fixedPoolRaw_16  , sizeof(fixedPoolRaw_16  ), 16   );
static FixedSizeMemoryPool   fixedPool_32   ( fixedPoolRaw_32  , sizeof(fixedPoolRaw_32  ), 32   );
static FixedSizeMemoryPool   fixedPool_64   ( fixedPoolRaw_64  , sizeof(fixedPoolRaw_64  ), 64   );
static FixedSizeMemoryPool   fixedPool_128  ( fixedPoolRaw_128 , sizeof(fixedPoolRaw_128 ), 128  );
static FixedSizeMemoryPool   fixedPool_256  ( fixedPoolRaw_256 , sizeof(fixedPoolRaw_256 ), 256  );
static FixedSizeMemoryPool   fixedPool_512  ( fixedPoolRaw_512 , sizeof(fixedPoolRaw_512 ), 512  );
static FixedSizeMemoryPool   fixedPool_1024 ( fixedPoolRaw_1024, sizeof(fixedPoolRaw_1024), 1024 );
static FixedSizeMemoryPool   fixedPool_2048 ( fixedPoolRaw_2048, sizeof(fixedPoolRaw_2048), 2048 );

// Объявляем таблицу пулов
static 
IMemoryPool* fixedPools[] = {
                             #ifdef USE_FIXED_POOL_4
                               &fixedPool_4   ,
                             #endif
                               &fixedPool_8   
                             , &fixedPool_16  
                             , &fixedPool_32  
                             , &fixedPool_64  
                             , &fixedPool_128 
                             , &fixedPool_256 
                             , &fixedPool_512 
                             , &fixedPool_1024
                             , &fixedPool_2048
                             };
*/
// Динамический кусковой пул
static 
memory::DynamicMemoryPool dynamicMemoryPool = memory::DynamicMemoryPool(  );
//DynamicMemoryPool dynamicMemoryPool(&fixedPools[0], UMBA_COUNT_OF(fixedPools), DYN_POOL_FIRST_LEVEL);


// Объявляем глобальные указатели на пулы
memory::IMemoryPool* globalStaticMemoryPool  = &growingMemoryPool;
memory::IMemoryPool* globalHeapMemoryPool    = &dynamicMemoryPool;


}; // namespace umba


