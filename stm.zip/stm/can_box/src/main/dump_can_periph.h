
void dumpAllCanPeriph()
{
    #ifndef NO_LOG

        lout<<"!!!\n";
        umba::periph::dump( lout, RCC  , "RCC" );
        lout<<"!!!\n";
        umba::periph::dump( lout, AFIO , "AFIO");
        lout<<"!!!\n";
        umba::periph::dump( lout, NVIC , "NVIC");
        lout<<"!!!\n";
        umba::periph::dump( lout, GPIOA, "GPIOA");
        lout<<"!!!\n";
        umba::periph::dump( lout, GPIOB, "GPIOB");
        lout<<"!!!\n";
        umba::periph::dump( lout, CAN1 , "CAN1");
       
        lout<<"---------------------------------------------------------------------------------------------------------\n";
        lout<<"\n"<<umba::omanip::flush;

    #endif
}

