
#include "uart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/time_service.h"

#include "can/can_handle.h"
#include "periph/periph.h"
#include "periph/dump.h"

#include "usb-can-config.h"
#include "lawicel_slcan/lawicel_slcan_stm32.h"

#include "can_event_handler_test_impl.h"

#include "periph_drivers/serial/can_device_base.h"
#include "periph_drivers/serial/can_handle.h"

#include <cstring>

/*! \mainpage USB-CAN Адаптер

 TestMainPage

 \section test_groupping Тестирование групп

 Описание групп тут - https://www.doxygen.nl/manual/grouping.html
 Пункт меню "Группы"

 Заметки по проекту доступны в пункте меню "Описания"


 https://sandyxiongjing.gitbooks.io/coide-dev-manual/content/07-Document-for-Code/07.02-Use-markdown-in-doxygen.html


 https://stackoverflow.com/questions/4823468/comments-in-markdown   


 https://www.doxygen.nl/manual/markdown.html


 https://www.doxygen.nl/manual/markdown.html


 https://stackoverflow.com/questions/19704822/how-to-use-markdown-pages-and-doxygen-groups

//! \\cond Doxygen_Suppress_Not_Documented
#define UMBA_STATIC_ASSERT3(X, L)                UMBA_STATIC_ASSERT_MSG(X, at_line_##L)
#define UMBA_STATIC_ASSERT2(X, L)                UMBA_STATIC_ASSERT3(X, L)
//! \\endcond


 */


/*!
    \page CAN_BOX_USB_CAN_Protocol Заметки по протоколу обмена с USB-CAN адаптером.
   
    На просторах интернета найден какой-то протокол (Lawicel SLCAN), который:
    -# прокидывает CAN через UART в комп,
    -# вроде в линупсе работает искаропки.
   
    Краткое описание.

   
    Текстовый, плохо, но таки человеко-читаемый протокол.
    Символ \b \c CR (0x0D) указывает окончание команды (или ответа, или сам по себе - пустой OK-ответ).
    Символ \b \c BELL (0x07) в ответе указывает на ошибку.
   
    Команды:
   
    \li Sn[CR] - Setup with standard CAN bit-rates where n is 0-8.
        Returns: CR (Ascii 13) for OK or BELL (Ascii 7) for ERROR.

    \li sxxyy[CR] - Setup with BTR0/BTR1 CAN bit-rates where xx and yy is a hex value. (не реализуем, оно похоже зависит от железки
        , на которой изначально поднимался протокол).

    \li O[CR] - Open the CAN channel in normal mode (sending & receiving).
        Returns: CR (Ascii 13) for OK or BELL (Ascii 7) for ERROR.

    \li L[CR] - Open the CAN channel in listen only mode (receiving).
        Returns: CR (Ascii 13) for OK or BELL (Ascii 7) for ERROR.

    \li C[CR] - Close the CAN channel.
        Returns: CR (Ascii 13) for OK or BELL (Ascii 7) for ERROR.

    \li tiiildd...[CR] - Transmit a standard (11bit) CAN frame.
        Returns: If Auto Poll is disabled (default) the CAN232 replies
        CR (Ascii 13) for OK or BELL (Ascii 7) for ERROR.
        If Auto Poll is enabled (see X command) the CAN232
        replies z[CR] for OK or BELL (Ascii 7) for ERROR.

    \li Tiiiiiiiildd...[CR] - Transmit an extended (29bit) CAN frame.
        Returns: If Auto Poll is disabled (default) the CAN232 replies
        CR (Ascii 13) for OK or BELL (Ascii 7) for ERROR.
        If Auto Poll is enabled (see X command) the CAN232
        replies Z[CR] for OK or BELL (Ascii 7) for ERROR.

    \li riiil[CR] - Transmit an standard RTR (11bit) CAN frame.
        Returns: If Auto Poll is disabled (default) the CAN232 replies
        CR (Ascii 13) for OK or BELL (Ascii 7) for ERROR.
        If Auto Poll is enabled (see X command) the CAN232
        replies z[CR] for OK or BELL (Ascii 7) for ERROR.

    \li Riiiiiiiil[CR] - Transmit an extended RTR (29bit) CAN frame.
        Returns: If Auto Poll is disabled (default) the CAN232 replies
        CR (Ascii 13) for OK or BELL (Ascii 7) for ERROR.
        If Auto Poll is enabled (see X command) the CAN232
        replies z[CR] for OK or BELL (Ascii 7) for ERROR.

    \li P[CR] - Poll incomming FIFO for CAN frames (single poll).
        Returns: A CAN frame with same formatting as when sending
        frames and ends with a CR (Ascii 13) for OK. If there
        are no pendant frames it returns only CR. If CAN
        channel isn’t open it returns BELL (Ascii 7). If the
        TIME STAMP is enabled, it will reply back the time
        in milliseconds as well after the last data byte (before
        the CR). For more information, see the Z command.

    \li A[CR] - Polls incomming FIFO for CAN frames (all pending frames).
        Returns: CAN frames with same formatting as when sending
        frames seperated with a CR (Ascii 13). When all
        frames are polled it ends with an A and
        a CR (Ascii 13) for OK. If there are no pending
        frames it returns only an A and CR. If CAN
        channel isn’t open it returns BELL (Ascii 7). If the
        TIME STAMP is enabled, it will reply back the time
        in milliseconds as well after the last data byte (before
        the CR). For more information, see the Z command.

    \li F[CR] - Read Status Flags.
        Returns: An F with 2 bytes BCD hex value plus CR (Ascii 13)
        for OK. If CAN channel isn’t open it returns BELL
        (Ascii 7). This command also clear the RED Error
        LED. See availible errors below. E.g. F01[CR]
          -  Bit 0 CAN receive FIFO queue full
          -  Bit 1 CAN transmit FIFO queue full
          -  Bit 2 Error warning (EI), see SJA1000 datasheet
          -  Bit 3 Data Overrun (DOI), see SJA1000 datasheet
          -  Bit 4 Not used.
          -  Bit 5 Error Passive (EPI), see SJA1000 datasheet
          -  Bit 6 Arbitration Lost (ALI), see SJA1000 datasheet *
          -  Bit 7 Bus Error (BEI), see SJA1000 datasheet **

    \li Xn[CR] - Sets Auto Poll/Send ON/OFF for received frames. (расширил)
        Example 1: X0[CR] - Turn OFF the Auto Poll/Send feature (default).
        Example 2: X1[CR] - Turn ON the Auto Poll/Send feature.
        Returns: CR (Ascii 13) for OK or BELL (Ascii 7) for ERROR.

    \li Wn[CR] - Filter mode setting (не реализуем, см. sxxyy[CR]).
    \li Mxxxxxxxx[CR] - Sets Acceptance Code Register (ACn Register of SJA1000) (не реализуем, см. sxxyy[CR]).
    \li mxxxxxxxx[CR] - Sets Acceptance Mask Register (AMn Register of SJA1000) (не реализуем, см. sxxyy[CR]).

    \li Un[CR] - Setup UART with a new baud rate where n is 0-6 (расширил более скоростными бодрейтами).

    \li V[CR] - Get Version number of both CAN232 hardware and software.
        V+[CR] - return adapter name string "RTC USB-CAN Adapter"

    \li N[CR]  - Get Serial number of the CAN232 (расширил).
        N+[CR] - return interface name CAN0/CAN1
        Расширенные команды автоматичкески включают режим вывода CR LF - чтобы в терминале можно было удобно работать

    \li Qn[CR] Auto Startup feature (from power on). (пока не реализовано)

    \li Zn[CR] Sets Time Stamp ON/OFF for received frames only. (пока не реализовано)




    См. документацию в каталоге \b \c doc.


    Файл: \b \c main/can_box.cpp, проект: \b \c can_box.uvprojx

*/


// Project defines: USE_UART1, USE_UART2, CAN1_ENABLE, CAN2_ENABLE

UMBA_PERIPH_DECLARE_PIN( pinMainLed         , LED );

/*
UMBA_PERIPH_DECLARE_PIN( pinCanTrafficLed1  , CAN1_TRAFFIC );
UMBA_PERIPH_DECLARE_PIN( pinCanStateLed1    , CAN1_STATE );
UMBA_PERIPH_DECLARE_PIN( pinCanTrafficLed2  , CAN2_TRAFFIC );
UMBA_PERIPH_DECLARE_PIN( pinCanStateLed2    , CAN2_STATE );
*/

#ifdef LOG_TO_UART
    umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart2 ) /* .setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false ) */ ;
#else    
    umba::SwvCharWritter               charWritter;
#endif

umba::SimpleFormatter          lout(&charWritter);



#define TEST_LOG_CAN_IRQ


using namespace umba::omanip;

#include "dump_can_periph.h"



int main(void)
{
    umba::time_service::init();
    umba::time_service::start();


    uart::uart3.init( UART1_RX_GPIO, UART1_RX_GPIO_PIN_NO
                    , UART1_TX_GPIO, UART1_TX_GPIO_PIN_NO
                    , 57600
                    );

    uart::uart2.init( UART2_RX_GPIO, UART2_RX_GPIO_PIN_NO
                    , UART2_TX_GPIO, UART2_TX_GPIO_PIN_NO
                    , 57600
                    );

    #ifdef LOG_TO_UART
    charWritter.setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
    #endif    
    
    lout<<"OSCCLK : "<<umba::periph::clockGetFreq(umba::periph::ClockBus::OSCCLK )<<"\n";
    lout<<"CORECLK: "<<umba::periph::clockGetFreq(umba::periph::ClockBus::CORECLK)<<"\n";
    lout<<"SYSCLK: "<<umba::periph::clockGetFreq(umba::periph::ClockBus::SYSCLK)<<"\n";
    lout<<"AHB   : "<<umba::periph::clockGetFreq(umba::periph::ClockBus::AHB   )<<"\n";
    lout<<"APB1  : "<<umba::periph::clockGetFreq(umba::periph::ClockBus::APB1  )<<"\n";
    lout<<"APB2  : "<<umba::periph::clockGetFreq(umba::periph::ClockBus::APB2  )<<"\n";


    // inline binding to pins
    umba::periph::drivers::CanHandle canDevice1( umba::periph::drivers::CommSizes{ umba::periph::drivers::RxSize(15)
                                                                                , umba::periph::drivers::TxSize(15)
                                                                                }
                                              , CAN1
                                              , CAN1_RX_GPIO_PIN_ADDR
                                              , CAN1_TX_GPIO_PIN_ADDR );
    umba::periph::drivers::CanHandle canDevice2( umba::periph::drivers::CommSizes{ umba::periph::drivers::RxSize(15)
                                                                                , umba::periph::drivers::TxSize(15)
                                                                                }
                                              , CAN1
                                              , CAN1_RX_GPIO_PIN_ADDR
                                              , CAN1_TX_GPIO_PIN_ADDR );

    //canDevice.open(125000);



    using namespace umba::omanip;

    lout<<"Starting..."<<endl<<flush;



    // uint32_t uintArray[] = { 0u, 1u, 2u, 3u };
    // const std::size_t sizeOfUintsFull = sizeof (uintArray);
    // const std::size_t sizeOfUintsItem = sizeof (uintArray[0]);
    //  
    // const std::size_t numUints = UMBA_COUNT_OF(uintArray);

    //using namespace slcan;
    umba::LawicelSlcanSlaveStm32 lawicelSlaves[] = { umba::LawicelSlcanSlaveStm32( (uint8_t)0  /* _portNumber */ , &uart::uart3, &canDevice1 )
                                                   , umba::LawicelSlcanSlaveStm32( (uint8_t)1  /* _portNumber */ , &uart::uart2, &canDevice1 )
                                                   };
    const std::size_t numSlaves = 2;

    // const std::size_t sizeOfFull = sizeof (lawicelSlaves);  
    // const std::size_t sizeOfItem = sizeof (lawicelSlaves[0]);
    //  
    // const std::size_t numSlaves = UMBA_COUNT_OF(lawicelSlaves);

    using namespace umba::periph;

    pinMainLed        = false;

    /*
    pinCanTrafficLed1 = false;
    pinCanStateLed1   = false;
    pinCanTrafficLed2 = false;
    pinCanStateLed2   = false;
    */


    lout<<"Started\n";


    unsigned cnt = 0;

    while(1)
    {
        //umba::time_service::delayMs(10);
        //++cnt;
        /*
        if ((cnt%100)==0)
        {
            if (canDevice.isReadyToTransmit())
            {
                // bool 
                static const uint8_t testData[8] = { 0x01u, 0x02u, 0x03u, 0x04u, 0x05u, 0x06u, 0x07u, 0x08u };
                umba::periph::drivers::CanFrame canFrame;
                canFrame.can_id  = 0x123;
                canFrame.can_dlc = 5;
                std::memcpy( &canFrame.data[0], &testData[0], 8);
                canDevice.transmitMessage(canFrame);
            }

            lout<<"Pilse: "<<cnt<<"\n";
            pinMainLed = !pinMainLed;
        }

        umba::periph::drivers::CanFrame canFrame;
        if (canDevice.tryToReceive(canFrame))
        {
            char dumpBuf[32];
            lout<<"CAN1: "<<hex<<canFrame.can_id<<": "<<umba::dump( &dumpBuf[0], &canFrame.data[0], canFrame.can_dlc )<<"\n";
        }
        */

        for( size_t i=0; i!=numSlaves; ++i )
        {
            lawicelSlaves[i].pollUart( );
            lawicelSlaves[i].pollCan( );
        }
        
    }

    return 0;
}
