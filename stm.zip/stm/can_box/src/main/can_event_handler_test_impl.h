#pragma once


#include "uart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/time_service.h"

#include "periph/periph.h"
#include "periph/can.h"


extern umba::SimpleFormatter  lout;

struct TestCanEventHandler : public umba::periph::traits::ICanEventHandler
{

    virtual void handleCanEventTx   ( unsigned txMailboxNo, umba::periph::CanTxStatus txStatus ) override
    {
        //lout<<"CAN TX\n";
    }

    virtual void handleCanEventRx   ( unsigned fifoNo     , umba::periph::CanRxStatus rxStatus, unsigned pendingMessagesCount ) override
    {
        //lout<<"CAN RX\n";
    }

    virtual void handleCanEventError( umba::periph::CanInterruptFlags flags, umba::periph::CanError lastErrCode, unsigned rxErrCounter, unsigned txErrCounter ) override
    {
        //lout<<"CAN ERR\n";
    }


}; // TestCanEventHandler


