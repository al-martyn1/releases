/*! \file
    \brief Поднят отладочный UART
 */

#include "uart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/time_service.h"

#include "periph/periph.h"
#include "periph/stm32_discovery.h"

#include "stm_serial_bootloader_hw_config.h"


#ifdef LOG_TO_UART
    umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart2 ) /* .setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false ) */ ;
#else    
    umba::SwvCharWritter               charWritter;
#endif

umba::SimpleFormatter          lout(&charWritter);



int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    using namespace umba::omanip;

    USART_InitTypeDef uart3_InitStruct;

    uart3_InitStruct.USART_BaudRate = 57600; // 115200 // 57600 // 230400;
    uart3_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    uart3_InitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    uart3_InitStruct.USART_Parity     = USART_Parity_Even; // USART_Parity_Odd USART_Parity_No
    uart3_InitStruct.USART_StopBits   = USART_StopBits_1;
    uart3_InitStruct.USART_WordLength = USART_WordLength_9b; // USART_WordLength_8b

    using uart::uart2;
    using uart::uart3;

    uart3.initExtended( UART1_RX_GPIO, UART1_RX_GPIO_PIN_NO
                            , UART1_TX_GPIO, UART1_TX_GPIO_PIN_NO
                            , uart3_InitStruct
                            , 0 // rs485Port
                            , 0 // rs485Pin
                    );

    uart2.init( UART2_RX_GPIO, UART2_RX_GPIO_PIN_NO
              , UART2_TX_GPIO, UART2_TX_GPIO_PIN_NO
              , 115200 // 57600 /* 115200 */
              );

    lout<<"Hello, world!"<<endl;

    //while( !uart2.isTransmitComplete()) {}
    //uart2.sendLocalArray("Hello, Serial!\n", 15);
    
    while(1)
    {
        //umba::time_service::delayMs(DELAY);
        while( !uart3.isTransmitComplete()) {}
        uart3.sendByte(0x5A); // ASCII 'Z'


        //lout<<"Hello, world!"<<endl;
       
        //while( !uart2.isTransmitComplete()) {}
        //uart2.sendLocalArray("Hello, Serial!\n", 15);

    }

    return 0;
}




