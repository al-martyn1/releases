/*! \file
    \brief Коннект с STM'овским бутлоадером по шоколаду
 */

#include "uart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/time_service.h"
#include "umba/dump.h"

#include "periph/periph.h"
#include "periph/stm32_discovery.h"

#include "stm_serial_bootloader_hw_config.h"

#include "periph_drivers/soft_timer/simple_ms.h"

#include "stm32_bootloader/uart_detection.h"
#include "stm32_bootloader/uart_comm.h"
#include "stm32_bootloader/bootloader_master.h"

#include <cstring>



UMBA_PERIPH_DECLARE_PIN_EX( pinBoot0, UMBA_PINADDR_PB12, UMBA_GPIO_DIRECTION_OUT ); // PB12 connected to BOOT0
UMBA_PERIPH_DECLARE_PIN_EX( pinBoot1, UMBA_PINADDR_PB13, UMBA_GPIO_DIRECTION_OUT ); // PB13 connected to BOOT1
UMBA_PERIPH_DECLARE_PIN_EX( pinNRST , UMBA_PINADDR_PC15, UMBA_GPIO_DIRECTION_OUT ); // PC15 connected to NRST


#ifdef LOG_TO_UART
    umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart2 ) /* .setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false ) */ ;
#else    
    umba::SwvCharWritter               charWritter;
#endif

umba::SimpleFormatter          lout(&charWritter);




int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    using namespace umba::omanip;


    using uart::uart2;
    uart2.init( UART2_RX_GPIO, UART2_RX_GPIO_PIN_NO
              , UART2_TX_GPIO, UART2_TX_GPIO_PIN_NO
              , 115200 // 57600 /* 115200 */
              );

    lout<<"-------------"<<endl;
    lout<<"Hello, world!"<<endl;


    lout<<"Starting bootloader detection procedure"<<endl;

    stm32::bootloader::BootPins<umba::periph::GpioPin> bootPins;
    bootPins.pPinBoot0 = &pinBoot0;
    bootPins.pPinBoot1 = &pinBoot1;
    bootPins.pPinRst   = &pinNRST ;

    stm32::bootloader::DetectionParams detectionParams; // Use default params

    typedef stm32::bootloader::BootloaderMaster< uart::Handle, umba::periph::GpioPin> BootloaderMaster;

    BootloaderMaster bootloaderMaster = BootloaderMaster( &uart::uart3, bootPins, detectionParams, 10 /* readTimeout */ );

    auto ec = bootloaderMaster.connect();

    using stm32::bootloader::toString;

    if (ec!=stm32::bootloader::ErrorCode::ok)
    {
        lout<<"Connect to bootloader failed: "<<toString(ec)<<endl;
    }
    else
    {
        lout<<"Connected to bootloader"<<endl;
        lout<<"Try to read memory"<<endl;

        uint32_t addressToReadFrom = 0x8000000u;
        uint8_t buf[32]; // 256
        char bufDump[256*3+6];
        std::size_t readedBytes;
        ec = bootloaderMaster.readMem(addressToReadFrom , &buf[0], UMBA_COUNT_OF(buf), readedBytes );
        
        if (ec!=stm32::bootloader::ErrorCode::ok)
        {
            lout<<"Read failed: "<<toString(ec)<<endl;
        }
        else
        {
            lout<<"Slave device mem at "<<hex<<addressToReadFrom<<": "<<umba::dump(&bufDump[0], &buf[0], readedBytes)<<endl;
            lout<<flush;
        }

        /*
        lout<<"Try to jump to 0x8000000u"<<endl;
        ec = bootloaderMaster.go(addressToReadFrom);
        
        if (ec!=stm32::bootloader::ErrorCode::ok)
        {
            lout<<"Go failed: "<<toString(ec)<<endl;
        }
        else
        {
            lout<<"Jump done"<<endl;
        }
        */
        // Original bytes 00 08 00 20 B9 06 00 08 C1 06 00 08 C3 06 00 08 C5 06 00 08 C7 06 00 08 C9 06 00 08 00 00 00 00

        // Save original bytes
        uint8_t savedBytes[8];
        std::memcpy( &savedBytes[0], &buf[0], 8 );

        // Write test bytes
        lout<<"Try to write memory"<<endl;
        uint8_t bytesToWrite[8] = { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08 };
        ec = bootloaderMaster.writeMem(addressToReadFrom , &bytesToWrite[0], UMBA_COUNT_OF(bytesToWrite) );
        if (ec!=stm32::bootloader::ErrorCode::ok)
        {
            lout<<"Write failed: "<<toString(ec)<<endl;
        }

        // Read written data
        lout<<"Read written data"<<endl;
        ec = bootloaderMaster.readMem(addressToReadFrom , &buf[0], UMBA_COUNT_OF(buf), readedBytes );
        if (ec!=stm32::bootloader::ErrorCode::ok)
        {
            lout<<"Read failed: "<<toString(ec)<<endl;
        }
        else
        {
            lout<<"Slave device mem at "<<hex<<addressToReadFrom<<": "<<umba::dump(&bufDump[0], &buf[0], readedBytes)<<endl;
            lout<<flush;
        }

        lout<<"Restore original bytes"<<endl;
        ec = bootloaderMaster.writeMem(addressToReadFrom , &savedBytes[0], UMBA_COUNT_OF(savedBytes) );
        if (ec!=stm32::bootloader::ErrorCode::ok)
        {
            lout<<"Write failed: "<<toString(ec)<<endl;
        }

        lout<<"Erasing flash"<<endl;
        ec = bootloaderMaster.eraseAll( );
        if (ec!=stm32::bootloader::ErrorCode::ok)
        {
            lout<<"Erase flash failed: "<<toString(ec)<<endl;
        }
        else
        {
            lout<<"Erase flash done"<<endl;
        }


        //ErrorCode writeMem( uint32_t addr, const uint8_t *pBuf, std::size_t numBytesToWrite )

    }


    while(1)
    {
    }

}


