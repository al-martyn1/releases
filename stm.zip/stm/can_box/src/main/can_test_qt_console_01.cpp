#include <QCoreApplication>
#include <QUuid>
#include <QTextStream>
#include <QSerialPort>
#include <QTest>

#include <iostream>

#include "umba/umba.h"
#include "ihc/i_octet_stream.h"
#include "ihc/octet_stream_qserialport.h"
#include "ihc/octet_stream_qfiledevice.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"
#include "umba/parse_utils.h"
#include "umba/exception.h"


//#include "helpers.h"

// #include "ihc/octet_stream_qfiledevice.h"

#include "lawicel_slcan/master_impl_qt.h"


umba::StdStreamCharWriter    charWritter(std::cout);
umba::SimpleFormatter  lout(&charWritter);


using namespace umba::omanip;



int main(int argc, char *argv[])
{
    using namespace umba::omanip;

    lout << "At start of main"<<endl;
    QCoreApplication app(argc, argv);
    QCoreApplication::setApplicationName("can_test_qt_console");
    QCoreApplication::setApplicationVersion("1.0");

    std::string portName;

    if (argc>1)
        portName = argv[1];
    //if (argc>2)
    //    dataFile = argv[2];

    //if (portName.empty())
    {
        //lout<<"Device definition filename required\n";
        //return 1;
    }

    try
    {
        umba::LawicelSlcanMasterQtImpl master;
        master.setUartPort("COM39");
        uint8_t scanRes = master.scanUartForDevice( true /* dontTestSlowSpeeds */ );

        if (scanRes==(uint8_t)-1)
        {
            lout<<"Scan failed\n";
        }
        else
        {
            lout<<"Scan ok, speed code: "<<(unsigned)scanRes<<"\n";
        }


    // QTest::qWait(10);
    /*
    QSerialPort            qSerialPort;
    qSerialPort.setPortName( QString(portName.c_str())); 
    qSerialPort.setDataBits(QSerialPort::Data8);
    qSerialPort.setBaudRate(QSerialPort::Baud115200, QSerialPort::AllDirections);
    qSerialPort.setFlowControl(QSerialPort::NoFlowControl);
    qSerialPort.setParity(QSerialPort::NoParity);
    qSerialPort.setStopBits(QSerialPort::OneStop);
    qSerialPort.setReadBufferSize(1024);

    if (!qSerialPort.open(QIODevice::ReadWrite)
     )
    {
        lout<<error<<"Failed to open serial device '"<<portName<<"'\n";
        return 0;
    }

    virtual
    bool canRead() override
    {
        char data;
        if (m_serialPort.peek( &data, 1 )==1)
            return true;
        return false;
    }

    virtual
    umba::Result<StreamSize> read( StreamOctetType *pBuf, StreamSize bufSize ) override
    {
        QTest::qWait(0); // allow Qt to run some internal code
        // If in main loop (console app, as sample) no calls to 
        // QCoreApplication::processEvents();
        // the serial port always read zero count bytes

        auto bytesReaded = m_serialPort.read( (char*)pBuf, bufSize );
        if (bytesReaded==(qint64)-1)
        {
            //throw std::runtime_error("Serial port read failed");
            return QSerialPortErrorToUmbaError( m_serialPort.error() );
        }

        return (StreamSize)bytesReaded;
    }

    virtual
    bool canWrite(StreamSize nOctets) override
    {
        return true; // Любой разумный объем можно отправить
    }

    virtual
    umba::Result<StreamSize> write( const StreamOctetType *pData, StreamSize nOctets) override
    {
        auto bytesWritten = m_serialPort.write( (const char*)pData, nOctets );
        if (bytesWritten==(qint64)-1)
        {
            //throw std::runtime_error("Serial port write failed");
            return QSerialPortErrorToUmbaError( m_serialPort.error() );
        }

        if (nOctets!=(StreamSize)bytesWritten)
        {
            //return QSerialPortErrorToUmbaError( m_serialPort.error() );
            //throw std::runtime_error("Serial port write failed - not all data written");
        }

        return bytesWritten;
    }

    virtual
    umba::Result<StreamSize> write( const char *pData, size_t dataSize ) override
    {
        //UMBA_ASSERT( dataSize >= 0 );
        return write( (const StreamOctetType *)pData, (StreamSize)dataSize);
    }
    
    */

    }
    catch( const umba::FileParsingException &e )
    {
        lout<<e.getFileName()<<":"<<e.getLineNumber()<<": Error: "<<e.what()<<"\n";
        //return 1;
    }
    catch( const umba::FileException &e )
    {
        lout<<e.getFileName()<<": Error: "<<e.what()<<"\n";
        //return 1;
    }
    catch( const std::exception &e )
    {
        lout<<"Error: "<<e.what()<<"\n";
        //return 1;
    }
    catch( ... )
    {
        lout<<"Error: unknown error\n";
        //return 1;
    }


    


    lout<<"Exiting\n"; // <<

    return 0;

}


