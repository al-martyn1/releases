/*! \file
    \brief Коннект с STM'овским бутлоадером по шоколаду
 */

#include "uart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/time_service.h"
#include "umba/dump.h"

#include "periph/periph.h"
#include "periph/stm32_discovery.h"

#include "stm_serial_bootloader_hw_config.h"

#include "periph_drivers/soft_timer/simple_ms.h"

#include "stm32_bootloader/uart_detection.h"
#include "stm32_bootloader/uart_comm.h"




UMBA_PERIPH_DECLARE_PIN_EX( pinBoot0, UMBA_PINADDR_PB12, UMBA_GPIO_DIRECTION_OUT ); // PB12 connected to BOOT0
UMBA_PERIPH_DECLARE_PIN_EX( pinBoot1, UMBA_PINADDR_PB13, UMBA_GPIO_DIRECTION_OUT ); // PB13 connected to BOOT1
UMBA_PERIPH_DECLARE_PIN_EX( pinNRST , UMBA_PINADDR_PC15, UMBA_GPIO_DIRECTION_OUT ); // PC15 connected to NRST


#ifdef LOG_TO_UART
    umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart2 ) /* .setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false ) */ ;
#else    
    umba::SwvCharWritter               charWritter;
#endif

umba::SimpleFormatter          lout(&charWritter);




int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    using namespace umba::omanip;


    using uart::uart2;
    uart2.init( UART2_RX_GPIO, UART2_RX_GPIO_PIN_NO
              , UART2_TX_GPIO, UART2_TX_GPIO_PIN_NO
              , 115200 // 57600 /* 115200 */
              );

    lout<<"Hello, world!"<<endl;

    //while( !uart2.isTransmitComplete()) {}
    //uart2.sendLocalArray("Hello, Serial!\n", 15);

    lout<<"Starting bootloader detection procedure"<<endl;

    umba::periph::drivers::SoftTimerSimpleMs timer;
    ISerialPort *pUart = &uart::uart3;

    stm32::bootloader::DetectionParams detectionParams; // Use default params
    unsigned detectedSpeed = stm32::bootloader::detection( uart::uart3
                                                         , pinBoot0
                                                         , pinBoot1
                                                         , pinNRST 
                                                         , timer
                                                         , detectionParams
                                                         );
    if (detectedSpeed!=0)
    {
        lout<<"Found active STM32 bootloader with "<<detectedSpeed<<" bauds speed"<<endl;

        using stm32::bootloader::OpCode;
        using stm32::bootloader::ControlCode;
        using stm32::bootloader::toString;


        OpCode opCode = OpCode::getVer;

        lout<<"--"<<endl<<"Sending '"<<toString(opCode)<<"' command"<<endl;

        timer.setTimeout(5); // Byte receiving timeout

        ControlCode ackCode = stm32::bootloader::sendOpCodeReadAck( pUart
                                                                  , opCode
                                                                  , timer
                                                                  );

        lout<<"Received reply code : "<<toString(ackCode)<<" ("<<hex<<(uint8_t)ackCode<<")"<<endl;

        if (ackCode==ControlCode::ack)
        {
            // Read remaining data
            uint8_t buf[128];        
            std::size_t readedBytes = stm32::bootloader::readBytes( pUart, &buf[0], UMBA_COUNT_OF(buf), timer );
            lout<<"Received reply size: "<<readedBytes<<" bytes"<<endl;

            if (!readedBytes)
            {
                lout<<"Error: no data"<<endl;
            }
            else
            {
                char bufDump[128*3+6];
                lout<<"Reply raw data: "<<umba::dump(&bufDump[0], &buf[0], readedBytes)<<endl;
                lout<<flush;
                if (buf[readedBytes-1]!=(uint8_t)ControlCode::ack)
                {
                    lout<<"Error: wrong final code"<<toString((ControlCode)buf[readedBytes-1])<<" ("<<hex<<(uint8_t)ackCode<<")"<<endl;
                }
                else
                {
                    readedBytes--;
                    /*
                    uint8_t checkSum = stm32::bootloader::calcCheckSum( &buf[0], readedBytes );
                    if (checkSum)
                        lout<<"CheckSum mismatch "<<hex<<(uint8_t)checkSum<<endl;
                    readedBytes--;
                    */
                    lout<<"Reply data: "<<umba::dump(&bufDump[0], &buf[0], readedBytes)<<endl;
                    lout<<flush;
                    // 0x0B^0x22^0x00^0x01^0x02^0x11^0x21^0x31^0x43^0x63^0x73^0x82^0x92

                }
            
            }
            //char bufDump[128*3+6];
        }
        else
        {
            lout<<"Reply is wrong"<<endl;
        }



        opCode = OpCode::getVerAndRdp;

        lout<<"---"<<endl<<"Sending '"<<toString(opCode)<<"' command"<<endl;

        timer.setTimeout(5); // Byte receiving timeout

        ackCode = stm32::bootloader::sendOpCodeReadAck( pUart
                                                      , opCode
                                                      , timer
                                                      );

        lout<<"Received reply code : "<<toString(ackCode)<<" ("<<hex<<(uint8_t)ackCode<<")"<<endl;

        if (ackCode==ControlCode::ack)
        {
            // Read remaining data
            uint8_t buf[128];        
            std::size_t readedBytes = stm32::bootloader::readBytes( pUart, &buf[0], UMBA_COUNT_OF(buf), timer );
            lout<<"Received reply size: "<<readedBytes<<" bytes"<<endl;

            if (!readedBytes)
            {
                lout<<"Error: no data"<<endl;
            }
            else
            {
                char bufDump[128*3+6];
                lout<<"Reply raw data: "<<umba::dump(&bufDump[0], &buf[0], readedBytes)<<endl;
                lout<<flush;
                if (buf[readedBytes-1]!=(uint8_t)ControlCode::ack)
                {
                    lout<<"Error: wrong final code"<<toString((ControlCode)buf[readedBytes-1])<<" ("<<hex<<(uint8_t)ackCode<<")"<<endl;
                }
                else
                {
                    readedBytes--;
                    /*
                    uint8_t checkSum = stm32::bootloader::calcCheckSum( &buf[0], readedBytes );
                    if (checkSum)
                        lout<<"CheckSum mismatch "<<hex<<(uint8_t)checkSum<<endl;
                    readedBytes--;
                    */
                    lout<<"Reply data: "<<umba::dump(&bufDump[0], &buf[0], readedBytes)<<endl;
                    lout<<flush;

                }
            
            }
            //char bufDump[128*3+6];
        }
        else
        {
            lout<<"Reply is wrong"<<endl;
        }



        opCode = OpCode::getId;

        lout<<"---"<<endl<<"Sending '"<<toString(opCode)<<"' command"<<endl;

        timer.setTimeout(5); // Byte receiving timeout

        ackCode = stm32::bootloader::sendOpCodeReadAck( pUart
                                                      , opCode
                                                      , timer
                                                      );

        lout<<"Received reply code : "<<toString(ackCode)<<" ("<<hex<<(uint8_t)ackCode<<")"<<endl;

        if (ackCode==ControlCode::ack)
        {
            // Read remaining data
            uint8_t buf[128];        
            std::size_t readedBytes = stm32::bootloader::readBytes( pUart, &buf[0], UMBA_COUNT_OF(buf), timer );
            lout<<"Received reply size: "<<readedBytes<<" bytes"<<endl;

            if (!readedBytes)
            {
                lout<<"Error: no data"<<endl;
            }
            else
            {
                char bufDump[128*3+6];
                lout<<"Reply raw data: "<<umba::dump(&bufDump[0], &buf[0], readedBytes)<<endl;
                lout<<flush;
                if (buf[readedBytes-1]!=(uint8_t)ControlCode::ack)
                {
                    lout<<"Error: wrong final code"<<toString((ControlCode)buf[readedBytes-1])<<" ("<<hex<<(uint8_t)ackCode<<")"<<endl;
                }
                else
                {
                    readedBytes--;
                    /*
                    uint8_t checkSum = stm32::bootloader::calcCheckSum( &buf[0], readedBytes );
                    if (checkSum)
                        lout<<"CheckSum mismatch "<<hex<<(uint8_t)checkSum<<endl;
                    readedBytes--;
                    */
                    lout<<"Reply data: "<<umba::dump(&bufDump[0], &buf[0], readedBytes)<<endl;
                    lout<<flush;

                }
            
            }
            //char bufDump[128*3+6];
        }
        else
        {
            lout<<"Reply is wrong"<<endl;
        }




    }
    else
    {
        lout<<"STM32 bootloader not found"<<endl;
    }

    while(1)
    {
    }

}


