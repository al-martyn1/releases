/*! \file
    \brief Коннект с STM'овским бутлоадером на говне
 */

#include "uart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/time_service.h"

#include "periph/periph.h"
#include "periph/stm32_discovery.h"

#include "stm_serial_bootloader_hw_config.h"

#include "periph_drivers/soft_timer/simple_ms.h"



UMBA_PERIPH_DECLARE_PIN_EX( pinBoot0, UMBA_PINADDR_PB12, UMBA_GPIO_DIRECTION_OUT ); // PB12 connected to BOOT0
UMBA_PERIPH_DECLARE_PIN_EX( pinBoot1, UMBA_PINADDR_PB13, UMBA_GPIO_DIRECTION_OUT ); // PB13 connected to BOOT1
UMBA_PERIPH_DECLARE_PIN_EX( pinNRST , UMBA_PINADDR_PC15, UMBA_GPIO_DIRECTION_OUT ); // PC15 connected to NRST


#ifdef LOG_TO_UART
    umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart2 ) /* .setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false ) */ ;
#else    
    umba::SwvCharWritter               charWritter;
#endif

umba::SimpleFormatter          lout(&charWritter);




int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    using namespace umba::omanip;

    USART_InitTypeDef uart3_InitStruct;

    uart3_InitStruct.USART_BaudRate = 115200;// 9600; // 115200 // 57600 // 230400;
    uart3_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    uart3_InitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    uart3_InitStruct.USART_Parity     = USART_Parity_Even; // USART_Parity_Odd USART_Parity_No
    uart3_InitStruct.USART_StopBits   = USART_StopBits_1;
    uart3_InitStruct.USART_WordLength = USART_WordLength_9b; // USART_WordLength_8b

    using uart::uart2;
    using uart::uart3;

    uart3.initExtended( UART1_RX_GPIO, UART1_RX_GPIO_PIN_NO
                            , UART1_TX_GPIO, UART1_TX_GPIO_PIN_NO
                            , uart3_InitStruct
                            , 0 // rs485Port
                            , 0 // rs485Pin
                    );

    auto &flasherUart = uart3;

    uart2.init( UART2_RX_GPIO, UART2_RX_GPIO_PIN_NO
              , UART2_TX_GPIO, UART2_TX_GPIO_PIN_NO
              , 115200 // 57600 /* 115200 */
              );

    lout<<"Hello, world!"<<endl;

    //while( !uart2.isTransmitComplete()) {}
    //uart2.sendLocalArray("Hello, Serial!\n", 15);

    lout<<"Starting Bootloading procedure"<<endl;

    umba::periph::drivers::SoftTimerSimpleMs timer;


    // STM32F103RB (on F1 Discovery board) uses Pattern 1   Boot0(pin) = 1 and Boot1(pin) = 0
    pinBoot0 = 1;
    pinBoot1 = 0;

    timer.reset(50);
    timer.wait();
    //umba::time_service::delayMs(50);

    pinNRST  = 0;
    timer.reset(50);
    timer.wait();
    //umba::time_service::delayMs(50);
    pinNRST  = 1;

    timer.reset(50);
    timer.wait();
    //umba::time_service::delayMs(50);

    // Revert boot pins
    pinBoot0 = 1;
    pinBoot1 = 0;
    timer.reset(50);
    timer.wait();
    //umba::time_service::delayMs(50);
    
    timer.reset(5000); // 5 seconds to ping slave

    umba::periph::drivers::SoftTimerSimpleMs timerReply(200); // 200 ms waiting for reply

    uint8_t  replyByte = 0;

    //unsigned pingCnt = 0;
    //while(pingCnt<1000u)
    while(!timer.isTimedOut())
    {
        //pingCnt++;

        //umba::time_service::delayMs(10); // 10ms*1000u = 1000 seconds
        while( !flasherUart.isTransmitComplete()) {}
        flasherUart.sendByte(0x7F);
        while( !flasherUart.isTransmitComplete()) {}

        timerReply.reset();
        //unsigned waitCnt   = 0;
        
        //while(waitCnt<25u)
        while(!timerReply.isTimedOut())
        {
            //waitCnt++;
            if (flasherUart.isNewByte())
            {
                replyByte = flasherUart.getByte();
                lout<<"Received reply: "<<hex<<(uint16_t)replyByte<<endl;
                break;
            }
            umba::time_service::delayMs(1);
        }

        //if (!timerReply.isTimedOut())
        if (replyByte!=0)
        {
            // received good reply
            break;
        }

    }

    //if (pingCnt<1000u)
    if (replyByte!=0)
    {
        // received good reply
    }
    else
    {
        lout<<"No reply from peer"<<endl;
    }


    while(1)
    {
        //umba::time_service::delayMs(DELAY);
        //while( !uart3.isTransmitComplete()) {}
        //uart3.sendByte(0x5A); // ASCII 'Z'


        //lout<<"Hello, world!"<<endl;
       
        //while( !uart2.isTransmitComplete()) {}
        //uart2.sendLocalArray("Hello, Serial!\n", 15);

    }

    return 0;
}




