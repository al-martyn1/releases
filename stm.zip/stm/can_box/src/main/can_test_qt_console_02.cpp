#include <QCoreApplication>
#include <QUuid>
#include <QTextStream>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QTest>

#include <iostream>

#include "umba/umba.h"
#include "ihc/i_octet_stream.h"
#include "ihc/octet_stream_qserialport.h"
#include "ihc/octet_stream_qfiledevice.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"
#include "umba/parse_utils.h"
#include "umba/exception.h"
#include "umba/algoritms.h"



//#include "helpers.h"

// #include "ihc/octet_stream_qfiledevice.h"

#include "lawicel_slcan/master_impl_qt.h"


umba::StdStreamCharWriter    charWritter(std::cout);
umba::SimpleFormatter  lout(&charWritter);


using namespace umba::omanip;


inline
uint64_t calcCanSamplePointFit( uint64_t v1, uint64_t v2 )
{
    int64_t i = (int64_t)v1 - (int64_t)v2;
    if (i<0)
        return (uint64_t)(-i);
    return (uint64_t)i;
}

inline
bool calcCanTimings( uint64_t freq, uint64_t baudRate, unsigned takenPermille, uint16_t &prescaler, uint16_t &bs1, uint16_t &bs2)
{
    // SJW assumed that is 1
    uint16_t maxBs1   = 16; // PHASE_SEG1
    uint16_t maxBs2   = 8;  // PHASE_SEG2

    bool bestFound           = false;
    uint16_t bestPrescaler   = 0;
    uint16_t bestBs1         = 0;
    uint16_t bestBs2         = 0;
    unsigned bestPermilleErr = 0;

    int16_t curPrescaler = 1;
    for(; true; ++curPrescaler)
    {
        uint64_t sfreq = freq / curPrescaler;
        uint64_t nTQ = sfreq / baudRate;

        if (curPrescaler > 1024)
            break;

        if ( nTQ > (uint64_t)(1 + maxBs1 + maxBs2) )
           continue;

        if ( nTQ <= 3 )
            break;

        uint64_t checkFreq = nTQ*baudRate;
        uint64_t diffPermille = 1000*checkFreq / sfreq;
        int delta = 1000 - (int)diffPermille;
        if (delta<0)
            delta = -delta;

        if (delta>2)
        //if (checkFreq != sfreq)
           continue;

        for (uint16_t bs1 = maxBs1; bs1 > 1 ; --bs1)
            for(uint16_t bs2 = maxBs2; bs2 > 0 ; --bs2)
            {
                if ((1+bs1+bs2)!=nTQ)
                    continue;

                unsigned curPermille = 1000*(1+bs1) / (1+bs1+bs2);
                unsigned curPermilleErr = (unsigned)calcCanSamplePointFit( curPermille, takenPermille );
                if (!bestFound)
                {
                    bestFound        = true;
                    bestPrescaler    = curPrescaler;
                    bestBs1          = bs1;
                    bestBs2          = bs2;
                    bestPermilleErr  = curPermilleErr;
                }
                else
                {
                    if (bestPermilleErr > curPermilleErr)
                    {
                        bestPrescaler    = curPrescaler;
                        bestBs1          = bs1;
                        bestBs2          = bs2;
                        bestPermilleErr  = curPermilleErr;
                    }
                }
            }
    }

    if (!bestFound)
        return bestFound;

    prescaler = bestPrescaler - 1;
    bs1 = bestBs1 - 1;
    bs2 = bestBs2 - 1;
    return true;

}



int main(int argc, char *argv[])
{
    using namespace umba::omanip;

    lout << "At start of main"<<endl;
    QCoreApplication app(argc, argv);
    QCoreApplication::setApplicationName("can_test_qt_console");
    QCoreApplication::setApplicationVersion("1.0");

    uint16_t prescaler = 0;
    uint16_t bs1       = 0;
    uint16_t bs2       = 0;

    bool tmRes = calcCanTimings( 36000000 /* freqBusCan */ , 115200, 875 /* takenPermille */ , prescaler, bs1, bs2 );


    //std::vector<std::string> allPorts = umba::algoritms::generate_strings< std::string, unsigned, std::vector<std::string> >(std::string("COM%d"), 1u, 256u+1u);

    //std::string portName;

    //if (argc>1)
    //    portName = argv[1];
    //if (argc>2)
    //    dataFile = argv[2];

    //if (portName.empty())
    {
        //lout<<"Device definition filename required\n";
        //return 1;
    }

    try
    {
        QList<QSerialPortInfo> allPorts = QSerialPortInfo::availablePorts();
        //QList<QSerialPortInfo>::const_iterator pit = allPorts.begin();

        for( const auto &portInfo : allPorts)
        {
            auto portName = portInfo.portName();
            lout<<"Scaning "<<portName.toStdString()<<" - ";

            umba::LawicelSlcanMasterQtImpl master;

            master.setUartPort(portName);
            uint8_t scanRes = master.scanUartForDevice( true /* dontTestSlowSpeeds */ );
           
            if (scanRes==(uint8_t)-1)
            {
                lout<<"Scan failed\n";
            }
            else
            {
                lout<<"Scan ok, speed code: "<<(unsigned)scanRes<<"\n";
            }
        }

    // QTest::qWait(10);
    /*
    QSerialPort            qSerialPort;
    qSerialPort.setPortName( QString(portName.c_str())); 
    qSerialPort.setDataBits(QSerialPort::Data8);
    qSerialPort.setBaudRate(QSerialPort::Baud115200, QSerialPort::AllDirections);
    qSerialPort.setFlowControl(QSerialPort::NoFlowControl);
    qSerialPort.setParity(QSerialPort::NoParity);
    qSerialPort.setStopBits(QSerialPort::OneStop);
    qSerialPort.setReadBufferSize(1024);

    if (!qSerialPort.open(QIODevice::ReadWrite)
     )
    {
        lout<<error<<"Failed to open serial device '"<<portName<<"'\n";
        return 0;
    }

    virtual
    bool canRead() override
    {
        char data;
        if (m_serialPort.peek( &data, 1 )==1)
            return true;
        return false;
    }

    virtual
    umba::Result<StreamSize> read( StreamOctetType *pBuf, StreamSize bufSize ) override
    {
        QTest::qWait(0); // allow Qt to run some internal code
        // If in main loop (console app, as sample) no calls to 
        // QCoreApplication::processEvents();
        // the serial port always read zero count bytes

        auto bytesReaded = m_serialPort.read( (char*)pBuf, bufSize );
        if (bytesReaded==(qint64)-1)
        {
            //throw std::runtime_error("Serial port read failed");
            return QSerialPortErrorToUmbaError( m_serialPort.error() );
        }

        return (StreamSize)bytesReaded;
    }

    virtual
    bool canWrite(StreamSize nOctets) override
    {
        return true; // Любой разумный объем можно отправить
    }

    virtual
    umba::Result<StreamSize> write( const StreamOctetType *pData, StreamSize nOctets) override
    {
        auto bytesWritten = m_serialPort.write( (const char*)pData, nOctets );
        if (bytesWritten==(qint64)-1)
        {
            //throw std::runtime_error("Serial port write failed");
            return QSerialPortErrorToUmbaError( m_serialPort.error() );
        }

        if (nOctets!=(StreamSize)bytesWritten)
        {
            //return QSerialPortErrorToUmbaError( m_serialPort.error() );
            //throw std::runtime_error("Serial port write failed - not all data written");
        }

        return bytesWritten;
    }

    virtual
    umba::Result<StreamSize> write( const char *pData, size_t dataSize ) override
    {
        //UMBA_ASSERT( dataSize >= 0 );
        return write( (const StreamOctetType *)pData, (StreamSize)dataSize);
    }
    
    */

    }
    catch( const umba::FileParsingException &e )
    {
        lout<<e.getFileName()<<":"<<e.getLineNumber()<<": Error: "<<e.what()<<"\n";
        //return 1;
    }
    catch( const umba::FileException &e )
    {
        lout<<e.getFileName()<<": Error: "<<e.what()<<"\n";
        //return 1;
    }
    catch( const std::exception &e )
    {
        lout<<"Error: "<<e.what()<<"\n";
        //return 1;
    }
    catch( ... )
    {
        lout<<"Error: unknown error\n";
        //return 1;
    }


    


    lout<<"Exiting\n"; // <<

    return 0;

}


