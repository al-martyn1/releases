/*! \file
    \brief Коннект с STM'овским бутлоадером по шоколаду
 */

#include "uart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/time_service.h"

#include "periph/periph.h"
#include "periph/stm32_discovery.h"

#include "stm_serial_bootloader_hw_config.h"

#include "periph_drivers/soft_timer/simple_ms.h"

#include "stm32_bootloader/uart_detection.h"



UMBA_PERIPH_DECLARE_PIN_EX( pinBoot0, UMBA_PINADDR_PB12, UMBA_GPIO_DIRECTION_OUT ); // PB12 connected to BOOT0
UMBA_PERIPH_DECLARE_PIN_EX( pinBoot1, UMBA_PINADDR_PB13, UMBA_GPIO_DIRECTION_OUT ); // PB13 connected to BOOT1
UMBA_PERIPH_DECLARE_PIN_EX( pinNRST , UMBA_PINADDR_PC15, UMBA_GPIO_DIRECTION_OUT ); // PC15 connected to NRST


#ifdef LOG_TO_UART
    umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart2 ) /* .setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false ) */ ;
#else    
    umba::SwvCharWritter               charWritter;
#endif

umba::SimpleFormatter          lout(&charWritter);




int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    using namespace umba::omanip;


    using uart::uart2;
    uart2.init( UART2_RX_GPIO, UART2_RX_GPIO_PIN_NO
              , UART2_TX_GPIO, UART2_TX_GPIO_PIN_NO
              , 115200 // 57600 /* 115200 */
              );

    lout<<"Hello, world!"<<endl;

    //while( !uart2.isTransmitComplete()) {}
    //uart2.sendLocalArray("Hello, Serial!\n", 15);

    lout<<"Starting bootloader detection procedure"<<endl;

    umba::periph::drivers::SoftTimerSimpleMs timer;

    stm32::bootloader::DetectionParams detectionParams; // Use default params
    unsigned detectedSpeed = stm32::bootloader::detection( uart::uart3
                                                         , pinBoot0
                                                         , pinBoot1
                                                         , pinNRST 
                                                         , timer
                                                         , detectionParams
                                                         );
    if (detectedSpeed!=0)
    {
        lout<<"Found STM32 active bootloader with "<<detectedSpeed<<" bauds speed"<<endl;
    }
    else
    {
        lout<<"STM32 bootloader not found"<<endl;
    }

    while(1)
    {
    }

}


