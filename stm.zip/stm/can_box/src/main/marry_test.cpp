#include "uart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/time_service.h"

#include "can/can_handle.h"
#include "periph/periph.h"
#include "periph/dump.h"

#include "usb-can-config.h"
#include "lawicel_slcan/lawicel_slcan_stm32.h"

#include "can_event_handler_test_impl.h"

#include "periph_drivers/serial/can_device_base.h"
#include "periph_drivers/serial/can_handle.h"

#include <cstring>

// add USE_UART2, USE_UART3 defs
//#define NO_LOG


/*!
   \page CAN_BOX_MARRY_TEST Стенд для проверки Карусели

    В цикле крутятся две задачи:

    -# \c AbbSumulTask (\c marry_task_abb.h) - Симулятор ABB-шкафа - отвечает на запрос необходимых параметров.
       Проверен при помощи программы CANOpen DeviceExporer - отвечает идентчно тому, как это делает шкаф.

    -# \c MerryTestTask (\c marry_task_merry.h) - Отправляет запросы, аналогичто тому, как это должна Карусель.

    Если соединить CANы, то они разговаривают друг с другом.

    Стенд позволяет проверить алгоритм Карусели, и проверить саму Карусель, подменяя ABB-шкаф.

    Файл: \b \c main/marry_test.cpp, проект: \b \c marry_test.uvprojx

 */



#include "marry_task_abb.h"
#include "marry_task_merry.h"


// Project defines: USE_UART1, USE_UART2, CAN1_ENABLE, CAN2_ENABLE


#ifdef USE_LOUT

    #ifdef UMBA_WIN32_USED

        umba::StdStreamCharWriter    charWritter(std::cout);

    #else

        #ifdef LOG_TO_UART
            umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart2 ) /* .setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false ) */ ;
        #else    
            umba::SwvCharWritter               charWritter;
        #endif

    #endif
        
    // add 'extern umba::SimpleFormatter lout;' to other files
    umba::SimpleFormatter          lout(&charWritter);

#endif




const uint8_t  AbbSumulTask::m_requestPrefix [3] = { 0x40u, 0x01u, 0x40u };

const uint8_t  MerryTestTask::m_requestPrefix  [3] = { 0x40u, 0x01u, 0x40u };
const uint8_t  MerryTestTask::m_responsePrefix [3] = { 0x43u, 0x01u, 0x40u };
const uint8_t  MerryTestTask::m_valuesRequested[3] = { 0x01u, 0x07u, 0x0Au };


#include "dump_can_periph.h"


int main(void)
{
    umba::time_service::init();
    umba::time_service::start();

    #ifndef NO_LOG
        uart::uart3.init( UART1_RX_GPIO, UART1_RX_GPIO_PIN_NO
                        , UART1_TX_GPIO, UART1_TX_GPIO_PIN_NO
                        , 115200 // 57600 // 230400
                        );
       
        uart::uart2.init( UART2_RX_GPIO, UART2_RX_GPIO_PIN_NO
                        , UART2_TX_GPIO, UART2_TX_GPIO_PIN_NO
                        , 115200 // 57600 /* 115200 */
                        );
    #endif

    #ifndef NO_LOG

        #ifdef LOG_TO_UART
        charWritter.setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
        #endif    
         
        lout<<"OSCCLK : "<<umba::periph::clockGetFreq(umba::periph::ClockBus::OSCCLK )<<"\n";
        lout<<"CORECLK: "<<umba::periph::clockGetFreq(umba::periph::ClockBus::CORECLK)<<"\n";
        lout<<"SYSCLK: "<<umba::periph::clockGetFreq(umba::periph::ClockBus::SYSCLK)<<"\n";
        lout<<"AHB   : "<<umba::periph::clockGetFreq(umba::periph::ClockBus::AHB   )<<"\n";
        lout<<"APB1  : "<<umba::periph::clockGetFreq(umba::periph::ClockBus::APB1  )<<"\n";
        lout<<"APB2  : "<<umba::periph::clockGetFreq(umba::periph::ClockBus::APB2  )<<"\n";

    #endif

    // inline binding to pins
    umba::periph::drivers::CanHandle merryCan( umba::periph::drivers::CommSizes{ 16, 0 }, CAN1, CAN1_RX_GPIO_PIN_ADDR, CAN1_TX_GPIO_PIN_ADDR );
    umba::periph::drivers::CanHandle abbCan  ( umba::periph::drivers::CommSizes{ 16, 0 }, CAN2, CAN2_RX_GPIO_PIN_ADDR, CAN2_TX_GPIO_PIN_ADDR );

    merryCan.open(125000);
    abbCan  .open(125000);

    //dumpAllCanPeriph(); // CAN1

    AbbSumulTask   abbSumulTask(&abbCan);
    MerryTestTask  merryTestTask(&merryCan);
    


    #ifndef NO_LOG
    using namespace umba::omanip;
    lout<<"Starting..."<<endl<<flush;
    #endif

    #ifndef NO_LOG
    lout<<"Started\n";
    #endif

    unsigned cnt = 0;

    while(1)
    {
        abbSumulTask.work();
        merryTestTask.work();
    }

    return 0;
}
