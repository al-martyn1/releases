#include "uart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/time_service.h"

#include "can/can_handle.h"
#include "periph/periph.h"
#include "periph/dump.h"

#include "usb-can-config.h"
#include "lawicel_slcan/lawicel_slcan_stm32.h"

#include "can_event_handler_test_impl.h"

#include "periph_drivers/serial/can_device_base.h"
#include "periph_drivers/serial/can_handle.h"

#include <cstring>

/*!
   \page CAN_BOX_CAN_TEST Тест CAN

    Буферизация.
    Если TxSize задать равным нулю, то будет использоваться только аппаратный буфер.

    При старте происходит массовая отсылка сообщений CAN на адрес 404.
    Проверяем при помощи PACNView (теоретически можно приспособить второй порт CAN).

    Если задан размер буфера 15, то проходят все 15 сообщений.
    Если задан размер буфера 0, то проходит только 3 сообщения (используется только аппаратная буферизация).

    В основном цикле по софт таймеру (1 сек) отсылаются сообщения на адрес 123.

    Файл: main/can_test.cpp, проект: \b \c can_test.uvprojx

 */


// Project defines: USE_UART1, USE_UART2, CAN1_ENABLE, CAN2_ENABLE

UMBA_PERIPH_DECLARE_PIN( pinMainLed         , LED );

/*
UMBA_PERIPH_DECLARE_PIN( pinCanTrafficLed1  , CAN1_TRAFFIC );
UMBA_PERIPH_DECLARE_PIN( pinCanStateLed1    , CAN1_STATE );
UMBA_PERIPH_DECLARE_PIN( pinCanTrafficLed2  , CAN2_TRAFFIC );
UMBA_PERIPH_DECLARE_PIN( pinCanStateLed2    , CAN2_STATE );
*/


#ifdef USE_LOUT

    #ifdef UMBA_WIN32_USED

        umba::StdStreamCharWriter    charWritter(std::cout);

    #else

        #ifdef LOG_TO_UART
            umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart2 ) /* .setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false ) */ ;
        #else    
            umba::SwvCharWritter               charWritter;
        #endif

    #endif
        
    // add 'extern umba::SimpleFormatter lout;' to other files
    umba::SimpleFormatter          lout(&charWritter);

#endif




using namespace umba::omanip;

#include "dump_can_periph.h"



int main(void)
{
    umba::time_service::init();
    umba::time_service::start();


    // For log
    uart::uart2.init( UART2_RX_GPIO, UART2_RX_GPIO_PIN_NO
                    , UART2_TX_GPIO, UART2_TX_GPIO_PIN_NO
                    , 115200 // 57600 /* 115200 */
                    );

    #ifdef LOG_TO_UART
    charWritter.setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
    #endif    
    
    lout<<"OSCCLK : "<<umba::periph::clockGetFreq(umba::periph::ClockBus::OSCCLK )<<"\n";
    lout<<"CORECLK: "<<umba::periph::clockGetFreq(umba::periph::ClockBus::CORECLK)<<"\n";
    lout<<"SYSCLK: "<<umba::periph::clockGetFreq(umba::periph::ClockBus::SYSCLK)<<"\n";
    lout<<"AHB   : "<<umba::periph::clockGetFreq(umba::periph::ClockBus::AHB   )<<"\n";
    lout<<"APB1  : "<<umba::periph::clockGetFreq(umba::periph::ClockBus::APB1  )<<"\n";
    lout<<"APB2  : "<<umba::periph::clockGetFreq(umba::periph::ClockBus::APB2  )<<"\n";


    // inline binding to pins
    umba::periph::drivers::CanHandle canDevice( umba::periph::drivers::CommSizes{ umba::periph::drivers::RxSize(15)
                                                                                , umba::periph::drivers::TxSize(0)
                                                                                }
                                              , CAN1
                                              , CAN1_RX_GPIO_PIN_ADDR
                                              , CAN1_TX_GPIO_PIN_ADDR );

    canDevice.open(125000);



    umba::periph::drivers::CanFrame canFrame;
    std::memset( &canFrame, 0, sizeof(canFrame) );
    canFrame.can_id = 0x404;
    for(uint8_t i=0; i!=8; ++i)
        canFrame.data[i] = i;
    canFrame.can_dlc = 8;

    for(unsigned i=0; i!=15; ++i)
        canDevice.transmitMessage(canFrame);



    using namespace umba::omanip;

    lout<<"Starting..."<<endl<<flush;


    using namespace umba::periph;

    pinMainLed        = false;

    lout<<"Started\n";


    unsigned cnt = 0;

    while(1)
    {
        umba::time_service::delayMs(10);
        ++cnt;

        if ((cnt%100)==0)
        {
            if (canDevice.isReadyToTransmit())
            {
                // bool 
                static const uint8_t testData[8] = { 0x01u, 0x02u, 0x03u, 0x04u, 0x05u, 0x06u, 0x07u, 0x08u };
                umba::periph::drivers::CanFrame canFrame;
                canFrame.can_id  = 0x123;
                canFrame.can_dlc = 5;
                std::memcpy( &canFrame.data[0], &testData[0], 8);
                canDevice.transmitMessage(canFrame);
            }

            lout<<"Pilse: "<<cnt<<"\n";
            pinMainLed = !pinMainLed;
        }

        umba::periph::drivers::CanFrame canFrame;
        if (canDevice.tryToReceive(canFrame))
        {
            char dumpBuf[32];
            lout<<"CAN1: "<<hex<<canFrame.can_id<<": "<<umba::dump( &dumpBuf[0], &canFrame.data[0], canFrame.can_dlc )<<"\n";
        }

    }

    return 0;
}
