#include "uart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/time_service.h"

#include "periph/periph.h"
#include "periph/stm32_discovery.h"





#if defined(BLINK_FAST)
    UMBA_PERIPH_DECLARE_PIN( pinBlinkingLed , STM32_DISCOVERY_LED_GREEN );   // LD3 PC9
    #define DELAY 100
#else
    UMBA_PERIPH_DECLARE_PIN( pinBlinkingLed , STM32_DISCOVERY_LED_BLUE  );   // LD4 PC8
    #define DELAY 250
#endif


int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    pinBlinkingLed = false;
    
    while(1)
    {
        umba::time_service::delayMs(DELAY);
        pinBlinkingLed = !pinBlinkingLed;
    }

    return 0;
}




