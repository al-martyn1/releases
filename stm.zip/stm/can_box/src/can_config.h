/***************************************************************************************************
    настройки can
***************************************************************************************************/

#pragma once

#include "project_config.h"

// у нас есть can1
//#define CAN1_ENABLE

// размер приемного кольцевого буфера в сообщениях
const static uint32_t rx_buffer_size = 255;
 
 
static constexpr uint32_t rx_buf_min = 0;
static constexpr uint32_t rx_buf_max = 15;
static constexpr uint32_t tx_buf_min = 16;
static constexpr uint32_t tx_buf_max = 31;
