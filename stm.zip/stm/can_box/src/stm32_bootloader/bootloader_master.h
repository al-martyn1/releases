#pragma once

//----------------------------------------------------------------------------
/*! \file
    \brief Мастер (прошивальщик) по протоколу бутлоадера STM32

    См. STM AN3155 Application note - USART protocol used in the STM32 bootloader
 */

//----------------------------------------------------------------------------

#include "opcodes.h"
#include "patterns.h"
#include "uart_comm.h"
#include "uart_configure.h"
#include "uart_detection.h"

#ifdef USE_LOUT
    #include "umba/simple_formatter.h"
#endif

#include "periph_drivers/soft_timer/simple_ms.h"

#include "umba/stl.h"
#include "umba/bits.h"
#include <cstring>




//----------------------------------------------------------------------------
// stm32::bootloader
namespace stm32 {
namespace bootloader{

//! Коды ошибок при операциях со слейвом
enum class ErrorCode : unsigned
{
    ok              = 0x0000 , //!< Нет ошибки
    //err             = 0x00FF , //!< Какая-то ошибка

    notSup          = 0x0001 , //!< Команда не поддерживается
    noData          = 0x0002 , //!< Ожидаются данные, но они не пришли
    len             = 0x0003 , //!< Указаное в посылке число байт данных не совпадает с фактически принятым
    checkSum        = 0x0004 , //!< Ошибка контрольной суммы

    detectFail      = 0x0005 , //!< Не удалось найти устройство

    noAck           = 0x0006 , //!< Отсутствует Ack в конце посылки
    badAddr         = 0x0007 , //!< readMem/writeMem/erase - при отсылке адреса не приходит ack - неверный адрес
    badSize         = 0x0008 , //!< readMem/writeMem/erase - неверное количество байт
    wrongReply      = 0x0009 , //!< Пришло что-то, но не то, что ожидали, и неверныйтого размера
    writeFail       = 0x000A , //!< Ошибка записи
    eraseFail       = 0x000B , //!< Ошибка стирания

               
    // При соединении выполняются три базовые команды - OpCode::getVer, OpCode::getVerAndRdp, OpCode::getId. Одна из них вызвала ошибку


    connectMask     = 0x0F00 , //!< Маска стадии коннекта - get/rdp/gid
    detailsMask     = 0x00FF , //!< Маска деталей ошибки данной стадии коннекта

    get_base        = 0x0100 , //!< Ошибка команды OpCode::getVer, детали в младшей части
    rdp_base        = 0x0200 , //!< Ошибка команды OpCode::getVerAndRdp, детали в младшей части
    gid_base        = 0x0300 , //!< Ошибка команды OpCode::getId, детали в младшей части

    get_notSup      = 0x0101 , //!< getVer - Команда не поддерживается
    get_noData      = 0x0102 , //!< getVer - Ожидаются данные, но они не пришли
    get_len         = 0x0103 , //!< getVer - Указаное в посылке число байт данных не совпадает с фактически принятым
    get_checkSum    = 0x0104 , //!< getVer - Ошибка контрольной суммы
    get_noAck       = 0x0105 , //!< getVer - Отсутствует Ack в конце посылки

    rdp_notSup      = 0x0201 , //!< OpCode::getVerAndRdp - Команда не поддерживается
    rdp_noData      = 0x0202 , //!< OpCode::getVerAndRdp - Ожидаются данные, но они не пришли
    rdp_len         = 0x0203 , //!< OpCode::getVerAndRdp - Указаное в посылке число байт данных не совпадает с фактически принятым
    rdp_checkSum    = 0x0204 , //!< OpCode::getVerAndRdp - Ошибка контрольной суммы
    rdp_noAck       = 0x0205 , //!< OpCode::getVerAndRdp - Отсутствует Ack в конце посылки

    gid_notSup      = 0x0301 , //!< OpCode::getId - Команда не поддерживается
    gid_noData      = 0x0302 , //!< OpCode::getId - Ожидаются данные, но они не пришли
    gid_len         = 0x0303 , //!< OpCode::getId - Указаное в посылке число байт данных не совпадает с фактически принятым
    gid_checkSum    = 0x0304 , //!< OpCode::getId - Ошибка контрольной суммы
    gid_noAck       = 0x0305 , //!< OpCode::getId - Отсутствует Ack в конце посылки
    
};

inline
const char* toString( ErrorCode ec )
{
    switch(ec)
    {
        case ErrorCode::ok          : return "Ok";

        case ErrorCode::notSup      : return "Not supported";
        case ErrorCode::noData      : return "No required data";
        case ErrorCode::len         : return "Data lenght mismatch";
        case ErrorCode::checkSum    : return "CheckSum mismatch";
        case ErrorCode::noAck       : return "Final Ack missing";
        case ErrorCode::badAddr     : return "Invalid address";
        case ErrorCode::badSize     : return "Invalid data lenght";
        case ErrorCode::wrongReply  : return "Wrong reply";
        case ErrorCode::writeFail   : return "Write failed";
        case ErrorCode::eraseFail   : return "Erase failed";

        case ErrorCode::detectFail  : return "Slave detection failure";

        case ErrorCode::get_notSup  : return "GetVer - Not supported";       
        case ErrorCode::get_noData  : return "GetVer - No required data";    
        case ErrorCode::get_len     : return "GetVer - Data lenght mismatch";
        case ErrorCode::get_checkSum: return "GetVer - CheckSum mismatch";   
        case ErrorCode::get_noAck   : return "GetVer - final Ack missing";   

        case ErrorCode::rdp_notSup  : return "GetVerAndRdp - Not supported";       
        case ErrorCode::rdp_noData  : return "GetVerAndRdp - No required data";    
        case ErrorCode::rdp_len     : return "GetVerAndRdp - Data lenght mismatch";
        case ErrorCode::rdp_checkSum: return "GetVerAndRdp - CheckSum mismatch";   
        case ErrorCode::rdp_noAck   : return "GetVerAndRdp - final Ack missing";   

        case ErrorCode::gid_notSup  : return "GetId - Not supported";       
        case ErrorCode::gid_noData  : return "GetId - No required data";    
        case ErrorCode::gid_len     : return "GetId - Data lenght mismatch";
        case ErrorCode::gid_checkSum: return "GetId - CheckSum mismatch";   
        case ErrorCode::gid_noAck   : return "GetId - final Ack missing";   

        default                     : 
                                      return "Unknown error";
    }
}

//----------------------------------------------------------------------------




//----------------------------------------------------------------------------
//! Пины для управления слейвом
template<typename TPinType>
struct BootPins
{
    typedef TPinType PinType;

    PinType  *pPinBoot0;
    PinType  *pPinBoot1;
    PinType  *pPinRst  ;
};

//----------------------------------------------------------------------------




//----------------------------------------------------------------------------
//! Мастер (прошивальщик) по протоколу бутлоадера STM32
/*! При стирании флеша ответ приходит после стирания. Это занимает довольно много времени.
    На F103 это занимает 22 милисекунды. По умолчанию используем 200 мс - полагаю, этого хватит для флешки любого объема
 */
template<typename CommDevice, typename PinType>
class BootloaderMaster
{

public:

    //------------------------------
    //! Конструктор
    BootloaderMaster( CommDevice *pCommDevice
                    , const BootPins<PinType> &bootPins
                    , DetectionParams detectionParams = DetectionParams()
                    , umba::time_service::TimeTick readTimeout  = 5
                    , umba::time_service::TimeTick eraseTimeout = 200
                    )
    : m_pCommDevice(pCommDevice)
    , m_bootPins(bootPins)
    , m_detectionParams(detectionParams)
    , m_readTimeout(readTimeout)
    , m_eraseTimeout(eraseTimeout)
    , m_timer()

    , m_numberOfSupportedCommands(0)
    , m_connected(false)
    , m_speed(0)
    , m_bootloaderVersion(0)
    , m_pidLen(0)
    {}

    //------------------------------
    DetectionParams getDetectionParams() const                         { return m_detectionParams; }            //!< Возвращает DetectionParams
    void setDetectionParams( const DetectionParams detectionParams )   { m_detectionParams = detectionParams; } //!< Устанавливает DetectionParams

    //------------------------------
    umba::time_service::TimeTick getReadTimeout() const                { return m_readTimeout; }                //!< Возвращает таймаут чтения одного байта
    void setReadTimeout( umba::time_service::TimeTick readTimeout )    { m_readTimeout = readTimeout; }         //!< Устанавливает таймаут чтения одного байта

    //------------------------------
    umba::time_service::TimeTick getEraseTimeout() const               { return m_eraseTimeout; }               //!< Возвращает таймаут ответа при стирании флеша
    void setEraseTimeout( umba::time_service::TimeTick eraseTimeout )  { m_eraseTimeout = eraseTimeout; }       //!< Устанавливает таймаут ответа при стирании флеша

    //------------------------------
    //! Возвращает true, если начальный диалог с бутлоадером и запрос базовых характеристик прошел успешно - соединение установлено
    bool isConnected() const
    {
        return m_connected;
    }

    //------------------------------
    //! Сбрасывает соединение с бутлоадером
    void disconnect()
    {
        m_connected                   = false;
        m_bootloaderVersion           = 0;
        m_numberOfSupportedCommands   = 0;
    }

    //------------------------------
    //! Устанавливает соединение с бутлоадером - производит поиск (детект) бутлоадера, и запрашивает базовые характеристики
    ErrorCode connect()
    {
        ErrorCode ec = detect();
        if (ec!=ErrorCode::ok)
            return ec;

        ec = getVer();
        if (ec!=ErrorCode::ok)
            return (ErrorCode)( ((unsigned)ec) | ((unsigned)ErrorCode::get_base) );

        ec = getVerAndRdp();
        if (ec!=ErrorCode::ok)
            return (ErrorCode)( ((unsigned)ec) | ((unsigned)ErrorCode::rdp_base) );

        ec = getId();
        if (ec!=ErrorCode::ok)
            return (ErrorCode)( ((unsigned)ec) | ((unsigned)ErrorCode::gid_base) );

        m_connected = true;

        return ec;
    }

    //------------------------------
    //! Проверяет команду, доступна ли она для выполнения бутлоадером
    bool isCommandSupported( OpCode opcode )
    {
        UMBA_ASSERT(isConnected());

        for(std::size_t i=0; i!=m_numberOfSupportedCommands; ++i)
        {
            if (m_supportedCommands[i]==(uint8_t)opcode)
                return true;
        }

        return false;
    }

    //------------------------------
    //! Производит чтение блока памяти (от 1 до 256 байт)
    ErrorCode readMem( uint32_t addr, uint8_t *pBuf, std::size_t numBytesToRead, std::size_t &nReaded )
    {
        UMBA_ASSERT(isConnected());
        UMBA_ASSERT(isCommandSupported(OpCode::readMem));

        m_timer.setTimeout(m_readTimeout); // Byte receiving timeout

        ErrorCode res = ErrorCode::ok;

        ControlCode ackCode = sendOpCodeReadAck( m_pCommDevice, OpCode::readMem, m_timer );
        if (!isGoodControlCode( ackCode, res, ErrorCode::notSup ))
            return res;

        // Send memory address to read from
        res = sendAddressReadAck( addr );
        if (res!=ErrorCode::ok)
            return res;

        // Send number of bytes to read
        res = sendNumberOfBytesReadAck( numBytesToRead );
        if (res!=ErrorCode::ok)
            return res;

        // Reading bytes
        nReaded = readBytes( m_pCommDevice, pBuf, numBytesToRead, m_timer );

        return ErrorCode::ok;
    }

    //------------------------------
    //! Производит переходапо адресу
    ErrorCode go( uint32_t addr )
    {
        UMBA_ASSERT(isConnected());
        UMBA_ASSERT(isCommandSupported(OpCode::go));

        m_timer.setTimeout(m_readTimeout); // Byte receiving timeout

        ErrorCode res = ErrorCode::ok;

        ControlCode ackCode = sendOpCodeReadAck( m_pCommDevice, OpCode::go, m_timer );
        if (!isGoodControlCode( ackCode, res, ErrorCode::notSup ))
            return res;

        // Send memory address to read from
        res = sendAddressReadAck( addr );
        if (res!=ErrorCode::ok)
            return res;

        return ErrorCode::ok;
    }

    //------------------------------
    //! Производит запись блока памяти (от 1 до 256 байт)
    ErrorCode writeMem( uint32_t addr, const uint8_t *pBuf, std::size_t numBytesToWrite )
    {
        UMBA_ASSERT(numBytesToWrite<=256);
        UMBA_ASSERT(numBytesToWrite);

        UMBA_ASSERT(isConnected());
        UMBA_ASSERT(isCommandSupported(OpCode::writeMem));

        m_timer.setTimeout(m_readTimeout); // Byte receiving timeout

        ErrorCode res = ErrorCode::ok;

        ControlCode ackCode = sendOpCodeReadAck( m_pCommDevice, OpCode::writeMem, m_timer );
        if (!isGoodControlCode( ackCode, res, ErrorCode::notSup ))
            return res;

        // Send memory address to write to
        res = sendAddressReadAck( addr );
        if (res!=ErrorCode::ok)
            return res;

        // Send number of bytes to write
        uint8_t numBytes = (uint8_t)(numBytesToWrite-1);
        uint8_t checkSum = calcCheckSum( &numBytes, 1 );
        sendData( m_pCommDevice, numBytes );

        sendDataAndCheckSum( m_pCommDevice, pBuf, numBytesToWrite, checkSum  /* checkSumInitial */ );

        ackCode = readAck( m_pCommDevice, m_timer );
        if (!isGoodControlCode( ackCode, res, ErrorCode::writeFail ))
            return res;

        return ErrorCode::ok;
    }

    //------------------------------
    //! Стираем всю память
    ErrorCode eraseAll( )
    {
        UMBA_ASSERT(isConnected());

        m_timer.setTimeout(m_readTimeout); // Byte receiving timeout

        if (isCommandSupported(OpCode::erase))
            return eraseCommandImpl();
        if (isCommandSupported(OpCode::eraseEx))
            return eraseExCommandImpl();

        return ErrorCode::notSup;
    }



protected:


    //------------------------------
    //! Реализация команды стирания. Стираем всю память, отдельное постраничное стирание не реализуем
    ErrorCode eraseCommandImpl( )
    {
        ErrorCode res = ErrorCode::ok;

        ControlCode ackCode = sendOpCodeReadAck( m_pCommDevice, OpCode::erase, m_timer );
        if (!isGoodControlCode( ackCode, res, ErrorCode::notSup ))
            return res;

        uint8_t eraseAll = 0xFFu; // Erase all pages - global erase request
        sendDataAndCheckSum ( m_pCommDevice, &eraseAll, 1, 0xFF ); // checkSum is a complemented byte, not XOR of data bytes

        m_timer.setTimeout(m_eraseTimeout);

        ackCode = readAck(m_pCommDevice, m_timer);
        if (!isGoodControlCode( ackCode, res, ErrorCode::eraseFail))
            return res;

        return ErrorCode::ok;
    }

    //------------------------------
    //! Реализация команды расширенного стирания. Стираем всю память, отдельное постраничное стирание не реализуем
    ErrorCode eraseExCommandImpl( )
    {
        ErrorCode res = ErrorCode::ok;

        ControlCode ackCode = sendOpCodeReadAck( m_pCommDevice, OpCode::eraseEx, m_timer );
        if (!isGoodControlCode( ackCode, res, ErrorCode::notSup ))
            return res;

        uint16_t eraseAll = 0xFFFFu; // Erase all pages - global erase request
        sendDataAndCheckSum ( m_pCommDevice, (const uint8_t*)&eraseAll, 2 );

        m_timer.setTimeout(m_eraseTimeout);

        ackCode = readAck(m_pCommDevice, m_timer);
        if (!isGoodControlCode( ackCode, res, ErrorCode::eraseFail))
            return res;

        return ErrorCode::ok;
    }


    //------------------------------
    //! Отсылка адреса - для команд чтения/записи памяти, команды перехода, и тп
    ErrorCode sendAddressReadAck( uint32_t addr )
    {
        uint8_t buf[4];

        // Send address
        umba::bits::serializeMsbFirst( addr, &buf[0], 4 ); // Force serialize to 4 bytes
        sendDataAndCheckSum ( m_pCommDevice, &buf[0], 4 );

        ErrorCode res = ErrorCode::ok;

        ControlCode ackCode = readAck(m_pCommDevice, m_timer);
        if (!isGoodControlCode( ackCode, res, ErrorCode::badAddr))
            return res;

        return ErrorCode::ok;
    }

    //------------------------------
    //! Отсылка количества байт для чтения/записи памяти и тп
    ErrorCode sendNumberOfBytesReadAck( std::size_t numDataBytes )
    {
        UMBA_ASSERT(numDataBytes<=256);
        UMBA_ASSERT(numDataBytes);

        uint8_t data = (uint8_t)(numDataBytes-1);

        ErrorCode res = ErrorCode::ok;

        sendDataAndCheckSum ( m_pCommDevice, &data, 1, 0xFF ); // checkSum is a complemented byte, not XOR of data bytes
        ControlCode ackCode = readAck(m_pCommDevice, m_timer);
        if (!isGoodControlCode( ackCode, res, ErrorCode::badSize))
            return res;

        return ErrorCode::ok;
    }

    //------------------------------
    //! Возвращает true, если cc==ControlCode::ack, и false в других случаях, формируя код ошибки в res. Если cc==ControlCode::nack, то res устанавливается в errOnNack
    bool isGoodControlCode( ControlCode cc, ErrorCode &res, ErrorCode errOnNack = ErrorCode::notSup )
    {
        if (cc==ControlCode::nop)
            res = ErrorCode::noAck;
        else if (cc==ControlCode::err)
            res = ErrorCode::wrongReply;
        else if (cc==ControlCode::nack)
            res = errOnNack; // ErrorCode::badAddr;
        else 
            return true;

        return false;
    }

    //------------------------------
    //! Производит поиск (детект) бутлоадера
    ErrorCode detect()
    {
        m_speed = detection( m_pCommDevice
                           , *m_bootPins.pPinBoot0
                           , *m_bootPins.pPinBoot1
                           , *m_bootPins.pPinRst  
                           , m_timer
                           , m_detectionParams
                           );
        if (!m_speed)
           return ErrorCode::detectFail;

        return ErrorCode::ok;
    }

    //------------------------------
    //! Отсылка generic команды и вычитка ответа
    ErrorCode sendGenericCommandAndReadReply( OpCode opcode, uint8_t *pBuf, std::size_t bufSize, std::size_t &readedBytes )
    {
        m_timer.setTimeout(m_readTimeout); // Byte receiving timeout

        ControlCode ackCode = sendOpCodeReadAck( m_pCommDevice, opcode, m_timer );

        if (ackCode!=ControlCode::ack)
            return ErrorCode::notSup;

        
        readedBytes = readBytes( m_pCommDevice, pBuf, bufSize, m_timer );
        if (!readedBytes)
            return ErrorCode::noData;

        #if defined(USE_LOUT)
        /*
        using namespace umba::omanip;
        lout<<"Received reply size: "<<readedBytes<<" bytes"<<endl;
        char bufDump[128*3+6];
        lout<<"Reply raw data: "<<umba::dump(&bufDump[0], pBuf, readedBytes)<<endl;
        lout<<flush;
        */
        #endif
        if (pBuf[readedBytes-1]!=(uint8_t)ControlCode::ack)
            return ErrorCode::noAck;

        readedBytes--; // rtrim ack

        return ErrorCode::ok;
    }

    //------------------------------
    //! Команда getVer - получение версии и списка поддерживаемых команд
    ErrorCode getVer()
    {
        uint8_t buf[64];
        std::size_t readedBytes;
        ErrorCode ec = sendGenericCommandAndReadReply( OpCode::getVer, &buf[0], UMBA_COUNT_OF(buf), readedBytes );

        if (ec!=ErrorCode::ok)
            return ec;

        std::size_t seqLen = (std::size_t)buf[0]; // переданная длина последовательности
        seqLen++; // была передана длина-1

        readedBytes--; // ltrim DATA LEN FIELD
        if (readedBytes!=(std::size_t)seqLen)
            return ErrorCode::len; // lenght mismatch

        const uint8_t *pData = &buf[0];
        pData++; // skip seq lenght, moving to data

        m_bootloaderVersion = *pData;

        pData++;
        readedBytes--;

        m_numberOfSupportedCommands = readedBytes;
        if (m_numberOfSupportedCommands>UMBA_COUNT_OF(m_supportedCommands))
            m_numberOfSupportedCommands = UMBA_COUNT_OF(m_supportedCommands);

        std::memcpy( &m_supportedCommands[0], pData, m_numberOfSupportedCommands );

        return ErrorCode::ok;
    }

    //------------------------------
    //! Команда getVerAndRdp - получение версии и option bytes
    ErrorCode getVerAndRdp()
    {
        uint8_t buf[16];        
        std::size_t readedBytes;
        ErrorCode ec = sendGenericCommandAndReadReply( OpCode::getVerAndRdp, &buf[0], UMBA_COUNT_OF(buf), readedBytes );

        if (ec!=ErrorCode::ok)
            return ec;

        if (readedBytes!=3)
            return ErrorCode::len; // lenght mismatch

        // ignore version field
        std::memcpy( &m_optionBytes[0], &buf[1], 2 );

        return ErrorCode::ok;
    }

    //------------------------------
    //! Команда getId - получение product ID
    ErrorCode getId()
    {
        uint8_t buf[16];        
        std::size_t readedBytes;
        ErrorCode ec = sendGenericCommandAndReadReply( OpCode::getId, &buf[0], UMBA_COUNT_OF(buf), readedBytes );

        if (ec!=ErrorCode::ok)
            return ec;

        std::size_t seqLen = (std::size_t)buf[0]; // переданная длина последовательности
        seqLen++; // была передана длина-1

        readedBytes--; // ltrim DATA LEN FIELD
        if (readedBytes!=(std::size_t)seqLen)
            return ErrorCode::len; // lenght mismatch

        const uint8_t *pData = &buf[0];
        pData++; // skip seq lenght, moving to data

        m_pidLen = readedBytes;
        if (m_pidLen>UMBA_COUNT_OF(m_pid))
            m_pidLen = UMBA_COUNT_OF(m_pid);

        std::memcpy( &m_pid[0], &buf[1], m_pidLen );

        return ErrorCode::ok;
    }

    //------------------------------


protected:

    //------------------------------
    typedef umba::periph::drivers::SoftTimerSimpleMs  SoftTimerSimpleMs;  //!< Тип таймера для таймаутов
    typedef umba::time_service::TimeTick              TimeTick;           //!< Тип тика

    CommDevice          *m_pCommDevice;               //!< Коммуникационное устройство
    BootPins<PinType>    m_bootPins;                  //!< Пины для управления слейвом
    DetectionParams      m_detectionParams;           //!< Параметры поиска слейва
    TimeTick             m_readTimeout;               //!< Таймаут чтения одного байта
    TimeTick             m_eraseTimeout;              //!< Таймаут ответа при стирании флеша
    SoftTimerSimpleMs    m_timer;                     //!< Таймер для таймаутов

    std::size_t          m_numberOfSupportedCommands; //!< Число поддержимых команд (размер списка)
    uint8_t              m_supportedCommands[32];     //!< Поддерживаемые команды
    bool                 m_connected;                 //!< Признак активного подключения
    unsigned             m_speed;                     //!< Скорость, на которой обнаружен слейв
    uint8_t              m_bootloaderVersion;         //!< Версия бутлоадера
    uint8_t              m_optionBytes[2];            //!< Опцион байты

    // PID stands for product ID, returned by GetId opcode
    std::size_t          m_pidLen;                    //!< Длина идентификатора Product ID
    uint8_t              m_pid[32];                   //!< Идентификатор Product ID


}; // class BootloaderMaster



} // namespace bootloader
} // namespace stm32

