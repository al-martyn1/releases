#pragma once

//----------------------------------------------------------------------------
/*! \file
    \brief Обнаружение STM32 bootloader'а по UART'у
 */

//----------------------------------------------------------------------------

#include "uart/uart_handle.h"
#include "periph/periph.h"
#include "periph/gpio.h"
#include "umba/time_service.h"
#include "periph_drivers/soft_timer/simple_ms.h"

#include "uart_configure.h"
#include "opcodes.h"
#include "patterns.h"


//----------------------------------------------------------------------------
// stm32::bootloader
namespace stm32 {
namespace bootloader{



//----------------------------------------------------------------------------
//! Параметры поиска STM32 bootloader'а
struct DetectionParams
{
    typedef umba::time_service::TimeTick  TimeTick; //!< Укоротили имя TimeTick'а

    BootPatterns bootsPatterns = { 0x01, 0x00 };

    TimeTick    timeoutBootsToRst        = 2; //!< Таймаут после установки BOOT1/BOOT0 до поднятия RST, мс
    TimeTick    timeoutRstPulse          = 2; //!< Длительность RST, мс
    TimeTick    timeoutRstToBoots        = 2; //!< Таймаут после сброса RST до переустановки BOOT1/BOOT0, мс
    TimeTick    timeoutRstToNegotiation  = 2; //!< Таймаут после процедуры сброса до начала процесса разговора

    TimeTick    timeoutReply             = 30; //!< Таймаут ожидания ответа на единичный запрос
    std::size_t numTries                 =  3; //!< Количество запросов/попыток установки связи

    bool        nRst                     = true; //!< RST - инверсный

}; // struct DetectionParams

//----------------------------------------------------------------------------




//----------------------------------------------------------------------------
//! Применяет паттерн бут пинов на GPIO пины
inline
void applyBootPinsPattern( unsigned                pattern
                         , umba::periph::GpioPin   &pinBoot0
                         , umba::periph::GpioPin   &pinBoot1
                         )
{
    pinBoot0 = pattern&1;
    pinBoot1 = (pattern>>1)&1;
}

//----------------------------------------------------------------------------
//! Пытается связаться с ведомым, используя настроенный на некую скорость UART
inline
bool detectionStep( ISerialPort                               *pUart
                  , umba::periph::GpioPin                     &pinBoot0
                  , umba::periph::GpioPin                     &pinBoot1
                  , umba::periph::GpioPin                     &pinRst
                  , umba::periph::drivers::SoftTimerSimpleMs  &timer
                  , const DetectionParams                     &detectionParams
                  )
{
    bool rstNormalVal = detectionParams.nRst ? true : false;

    // Синхронизация с тиком таймера - иначе первый таймаут получается в пределах от N-1 до N
    timer.reset(1);
    timer.wait();

    // Устанавливаем конфигурацию BOOT пинов и делаем паузу
    applyBootPinsPattern(detectionParams.bootsPatterns.beforeReset, pinBoot0, pinBoot1);
    timer.reset(detectionParams.timeoutBootsToRst);
    timer.wait();

    // Активируем линию RST и делаем паузу
    pinRst = !rstNormalVal;
    timer.reset(detectionParams.timeoutRstPulse);
    timer.wait();

    // Возвращаем линию RST в нормальное состояние и делаем паузу
    pinRst = rstNormalVal;
    timer.reset(detectionParams.timeoutRstToBoots);
    timer.wait();

    // Восстанавливаем BOOT пины и делаем паузу
    applyBootPinsPattern(detectionParams.bootsPatterns.afterReset, pinBoot0, pinBoot1);
    timer.reset(detectionParams.timeoutRstToNegotiation);
    timer.wait();

    for( std::size_t nTry=0; nTry!=detectionParams.numTries; ++nTry )
    {
        pUart->waitTransmitComplete();
        pUart->sendByte( (uint8_t)ControlCode::abr ); // 0x7F
        pUart->waitTransmitComplete();

        timer.reset(detectionParams.timeoutReply);
        while(!timer.isTimedOut())
        {
            if (pUart->isNewByte())
            {
                uint8_t replyByte = pUart->getByte();
                if (replyByte==(uint8_t)ControlCode::ack) // 0x79
                    return true;
            }
        }
    }

    return false;
}

//----------------------------------------------------------------------------
//! Пытается связаться с ведомым на разных стандартных скоростях
/*! \returns Скорость, на которой удалось связаться с UART'ом, или 0 в случае неуспеха
 */
inline
unsigned detection_impl( uart::Handle                         *pUart
                  , umba::periph::GpioPin                     &pinBoot0
                  , umba::periph::GpioPin                     &pinBoot1
                  , umba::periph::GpioPin                     &pinRst
                  , umba::periph::drivers::SoftTimerSimpleMs  &timer
                  , const DetectionParams                     &detectionParams
                  )
{
    static unsigned speedTable[7] = { 115200u
                                    ,  57600u
                                    ,  38400u
                                    ,  19200u
                                    ,   9600u
                                    ,   4800u
                                    ,   2400u
                                    };
    for( auto i=0u; i!=7; ++i)
    {
        configureUart( pUart, speedTable[i] );
        if (detectionStep( pUart, pinBoot0, pinBoot1, pinRst, timer, detectionParams ))
            return speedTable[i];

    }

    return 0;

}

//----------------------------------------------------------------------------
//! Пытается связаться с ведомым на разных стандартных скоростях
/*! 
    Если не удалось связаться с бутлоадером с маленькими таймаутами, то производится удвоение таймаутов заданное число раз.

    \returns  Скорость, на которой удалось связаться с UART'ом, или 0 в случае неуспеха.
 */
inline
unsigned detection( uart::Handle                              *pUart
                  , umba::periph::GpioPin                     &pinBoot0
                  , umba::periph::GpioPin                     &pinBoot1
                  , umba::periph::GpioPin                     &pinRst
                  , umba::periph::drivers::SoftTimerSimpleMs  &timer
                  , DetectionParams                           &detectionParams
                  , std::size_t                                numOfTimeoutTries = 4
                  )
{
    for( auto i=0u; i!=numOfTimeoutTries; ++i)
    {
        unsigned res = detection_impl( pUart
                                     , pinBoot0
                                     , pinBoot1
                                     , pinRst
                                     , timer
                                     , detectionParams
                                     );
        if (res)
            return res;

        detectionParams.timeoutBootsToRst       = detectionParams.timeoutBootsToRst       *2;
        detectionParams.timeoutRstPulse         = detectionParams.timeoutRstPulse         *2;
        detectionParams.timeoutRstToBoots       = detectionParams.timeoutRstToBoots       *2;
        detectionParams.timeoutRstToNegotiation = detectionParams.timeoutRstToNegotiation *2;
        
        detectionParams.timeoutReply            = detectionParams.timeoutReply*4/3;

    }

    return 0;

}

//----------------------------------------------------------------------------



} // namespace bootloader
} // namespace stm32

