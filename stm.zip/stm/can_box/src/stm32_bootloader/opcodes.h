#pragma once

//----------------------------------------------------------------------------
/*! \file
    \brief Коды операций (команд) и управляющие коды протокола бутлоадера STM32

    См. STM AN3155 Application note - USART protocol used in the STM32 bootloader
 */

//----------------------------------------------------------------------------

#include "uart/uart_handle.h"
#include "periph/periph.h"
#include "periph/gpio.h"
#include "umba/time_service.h"
#include "periph_drivers/soft_timer/simple_ms.h"


//----------------------------------------------------------------------------
// stm32::bootloader
namespace stm32 {
namespace bootloader{

//----------------------------------------------------------------------------
//! Управляющие коды протокола бутлоадера
enum class ControlCode : uint8_t
{
    nop   = 0x00, //!< Технический опкод. Этого кода нет в протоколе, он возвращается в некоторых случаях, когда ждём ответа, но он не приходит
    err   = 0xFF, //!< Технический опкод. Этого кода нет в протоколе, он возвращается в некоторых случаях, когда ждём ack/nack, а приходит что-то ещё.

    nack  = 0x1F, //!< Отказ
    ack   = 0x79, //!< Подтверждение

    abr   = 0x7F  //!< Автободрейт - стартовый байт, который начинает общение после сброса. Больше нигде не используется

};

//----------------------------------------------------------------------------

inline
const char* toString( ControlCode cc )
{
    switch(cc)
    {
        case ControlCode::nop : return "NOP";
        case ControlCode::err : return "ERR";
        case ControlCode::nack: return "NACK";
        case ControlCode::ack : return "ACK";
        case ControlCode::abr : return "ABR";
        default:                return "<UNKNOWN>";
    }
}


//----------------------------------------------------------------------------
//! Коды операций (команд) протокола бутлоадера
/*! См. STM AN3155 Раздел 3 Bootloader command set (стр. 7)

    \note 1. If a denied command is received or an error occurs during the command execution, the bootloader sends
             NACK byte and goes back to command checking.
    \note 2. Read protection. When the RDP (Read protection) option is active, only this limited subset of commands is
             available. All other commands are NACK-ed and have no effect on the device. Once the RDP has been
             removed, the other commands become active.
    \note 3. Refer to STM32 product datasheets and to AN2606 to know the valid memory areas for these commands.
    \note 4. Erase (x043) and Extended Erase (0x44) are exclusive. A device can support either the Erase command or the Extended Erase command, but not both.
 */
enum class OpCode : uint8_t
{
    getVer          = 0x00, //!< Gets the version and the allowed commands supported by the current version of the bootloader (see note 2).
    getVerAndRdp    = 0x01, //!< Get Version & Read Protection Status(2) 0x01 Gets the bootloader version and the Read protection status of the Flash memory (see note 2).
    getId           = 0x02, //!< Gets the chip ID (see note 2).
    readMem         = 0x11, //!< Reads up to 256 bytes of memory starting from an address specified by the application (see note 3).
    go              = 0x21, //!< Jumps to user application code located in the internal Flash memory or in the SRAM (see note 3).
    writeMem        = 0x31, //!< Writes up to 256 bytes to the RAM or Flash memory starting from an address specified by the application (see note 3).
    erase           = 0x43, //!< Erases from one to all the Flash memory pages (see notes 3, 4).
    eraseEx         = 0x44, //!< Erases from one to all the Flash memory pages using two byte addressing mode (available only for v3.0 USART bootloader versions and above) (see notes 3, 4).
    writeProtect    = 0x63, //!< Enables the write protection for some sectors.
    writeUnprotect  = 0x73, //!< Disables the write protection for all Flash memory sectors.
    readProtect     = 0x82, //!< Enables the read protection.
    readUnprotect   = 0x92, //!< Disables the read protection (see note 2).
    getCrc          = 0xA1  //!< Get Checksum 0xA1 Computes a CRC value on a given memory area with a size multiple of 4 bytes.

};


inline
const char* toString( OpCode oc )
{
    switch(oc)
    {
        case OpCode::getVer           : return "Get Version";
        case OpCode::getVerAndRdp     : return "Get Version & RDP Status";
        case OpCode::getId            : return "Gets chip ID";
        case OpCode::readMem          : return "Read Mem";
        case OpCode::go               : return "Go (Jump)";
        case OpCode::writeMem         : return "Write Mem";
        case OpCode::erase            : return "Erase";
        case OpCode::eraseEx          : return "Erase Extended";
        case OpCode::writeProtect     : return "Write Protect";
        case OpCode::writeUnprotect   : return "Write Unprotect";
        case OpCode::readProtect      : return "Read Protect";
        case OpCode::readUnprotect    : return "Read Unprotect";
        case OpCode::getCrc           : return "Get Checksum";
        default                     : return "<UNKNOWN>";
    }
}



} // namespace bootloader
} // namespace stm32

