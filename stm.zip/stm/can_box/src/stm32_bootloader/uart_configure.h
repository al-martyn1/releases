#pragma once

//----------------------------------------------------------------------------
/*! \file
    \brief Настрока UART'а для работы с STM32 bootloader'ом
 */

//----------------------------------------------------------------------------

#include "uart/uart_handle.h"
#include "periph/periph.h"
#include "periph/gpio.h"
#include "umba/time_service.h"
#include "periph_drivers/soft_timer/simple_ms.h"

//----------------------------------------------------------------------------
// stm32::bootloader
namespace stm32 {
namespace bootloader{

inline
void configureUart( uart::Handle *pUart, unsigned speed )
{
    if (pUart->isInited())
    {
        pUart->changeBaudrate(speed);
        return;
    }

    USART_InitTypeDef uart_InitStruct;

    uart_InitStruct.USART_BaudRate = speed;
    uart_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    uart_InitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    uart_InitStruct.USART_Parity     = USART_Parity_Even; // USART_Parity_Odd USART_Parity_No
    uart_InitStruct.USART_StopBits   = USART_StopBits_1;
    uart_InitStruct.USART_WordLength = USART_WordLength_9b; // USART_WordLength_8b

    pUart->initExtended( UART1_RX_GPIO, UART1_RX_GPIO_PIN_NO
                       , UART1_TX_GPIO, UART1_TX_GPIO_PIN_NO
                       , uart_InitStruct
                       , 0 // rs485Port
                       , 0 // rs485Pin
                       );

}


} // namespace bootloader
} // namespace stm32

