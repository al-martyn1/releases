#pragma once

//----------------------------------------------------------------------------
/*! \file
    \brief Описания для stm32_bootloader артефактов
 */

//----------------------------------------------------------------------------

//! Всё, что относится к микроконтроллерам STM32
namespace stm32 {


//! STM32 Bootloader
namespace bootloader{


} // namespace bootloader
} // namespace stm32

