#pragma once

//----------------------------------------------------------------------------
/*! \file
    \brief Адаптер доступа к памяти через бутлоадер STM32
 */

//----------------------------------------------------------------------------
#include "bootloader_master.h"



//----------------------------------------------------------------------------
// stm32::bootloader
namespace stm32 {
namespace bootloader{


class BootloaderMemoryAccessAdapter
{

public:

    BootloaderMemoryAccessAdapter( BootloaderMaster *pBootloaderMaster )
    : m_pBootloaderMaster(pBootloaderMaster) {}

    bool readMemory ( uint32_t addr, uint8_t *pBuf, std::size_t numBytes ) const
    {
        UMBA_ASSERT(m_pBootloaderMaster);

        std::size_t nReaded;

        ErrorCode ec = m_pBootloaderMaster->readMem( addr, pBuf, numBytes, nReaded );

        if (ec!=ErrorCode::ok)
            return false;

        if (nReaded!=numBytes)
            return false;

        return true;
    }

    bool writeMemory( uint32_t addr, const uint8_t *pBuf, std::size_t numBytes ) const
    {
        UMBA_ASSERT(m_pBootloaderMaster);

        ErrorCode ec = m_pBootloaderMaster->writeMem( addr, pBuf, numBytes );

        if (ec!=ErrorCode::ok)
            return false;

        return true;
    }


protected:
    BootloaderMaster    *m_pBootloaderMaster;

}; // class BootloaderMemoryAccessAdapter


} // namespace bootloader
} // namespace stm32

