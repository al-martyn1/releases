#pragma once

//----------------------------------------------------------------------------
/*! \file
    \brief Паттерны BOOT0/BOOT1 для активации бутлоадера STM32
 */

//----------------------------------------------------------------------------

#include "uart/uart_handle.h"
#include "periph/periph.h"
#include "periph/gpio.h"
#include "umba/time_service.h"
#include "periph_drivers/soft_timer/simple_ms.h"


//----------------------------------------------------------------------------
// stm32::bootloader
namespace stm32 {
namespace bootloader{



//----------------------------------------------------------------------------
/* See AN2606 Application note. STM32 microcontroller system memory boot mode.

   Table 2. Bootloader activation patterns (pg 23) in "4.1 Bootloader activation" section
   (BFB2 - Boot from Bank2 option byte)

   Pattern 1   Boot0(pin) = 1 and Boot1(pin) = 0
   Pattern 2   Boot0(pin) = 1 and nBoot1(bit) = 1
   Pattern 3   Boot0(pin) = 1, Boot1(pin) = 0 and BFB2(bit) = 1
               Boot0(pin) = 0, BFB2(bit) = 0 and both banks do not contain valid code
               Boot0(pin) = 1, Boot1(pin) = 0, BFB2(bit) = 0 and both banks do not contain valid code
   Pattern 4   Boot0(pin) = 1, Boot1(pin) = 0 and BFB2(bit) = 1
               Boot0(pin) = 0, BFB2(bit) = 0 and both banks do not contain valid code
               Boot0(pin) = 1, Boot1(pin) = 0 and BFB2(bit) = 0
   Pattern 5   Boot0(pin) = 1, Boot1(pin) = 0 and BFB2(bit) = 0
               Boot0(pin) = 0, BFB2(bit) = 1 and both banks do not contain valid code
               Boot0(pin) = 1, Boot1(pin) = 0 and BFB2 (bit) = 1
   Pattern 6   Boot0(pin) = 1, nBoot1(bit) = 1 and nBoot0_SW(bit) = 1
               nBoot0(bit) = 0, nBoot1(bit) = 1 and nBoot0_SW(bit) = 0
               Boot0(pin) = 0, nBoot0_SW(bit) = 1 and main Flash memory empty
               nBoot0(bit) = 1, nBoot0_SW(bit)=0 and main Flash memory empty
   Pattern 7   Boot0(pin) = 1, nBoot1(bit) = 1 and BFB2(bit) = 0
               Boot0(pin) = 0, BFB2(bit) = 1 and both banks do not contain valid code
               Boot0(pin) = 1, nBoot1(bit) = 1 and BFB2(bit) = 1
   Pattern 8   Boot(pin) = 0 and BOOT_ADD0(optionbyte) = 0x0040
               Boot(pin) = 1 and BOOT_ADD1(optionbyte) = 0x0040
   Pattern 9   nDBANK(bit) = 1, Boot(pin) = 0 and BOOT_ADD0(optionbyte) = 0x0040
               nDBANK(bit) = 1, Boot(pin) = 1 and BOOT_ADD1(optionbyte) = 0x0040
               nDBANK(bit) = 0, nDBOOT(bit) = 1, Boot(pin) = 0 and BOOT_ADD0(optionbyte) = 0x0040
               nDBANK(bit) = 0, nDBOOT(bit) = 1, Boot(pin) = 1 and BOOT_ADD1(optionbyte) = 0x0040
               nDBANK(bit) = 0, nDBOOT(bit) = 0, BOOT_ADDx(optionbyte) out of memory range or in ICP memory range
               nDBANK(bit) = 0, nDBOOT(bit) = 0, BOOT_ADDx(optionbyte) in Flash memory range and both banks do not contain valid code
   Pattern 10  Boot(pin) = 0 and BOOT_ADD0(optionbyte) = 0x1FF0
               Boot(pin) = 1 and BOOT_ADD1(optionbyte) = 0x1FF0
   Pattern 11  nBoot0(bit) = 0, nBoot1(bit) = 1, nBOOT0_SEL(bit) = 1 and BOOT_LOCK(bit) = 0
               Boot0(pin) = 1, nBoot1(bit) = 1 and nBOOT0_SEL (bit) = 1
               nBoot0(bit) = 1, nBOOT0_SEL(bit) = 1, BOOT_LOCK(bit) = 0 and main Flash memory empty
               Boot0(pin) = 0, nBOOT0_SEL(bit) = 0, BOOT_LOCK(bit) = 0 and main Flash memory empty
               BOOT_LOCK(bit) = 1 and main Flash memory empty
   Pattern 12  TZen = 0, Boot0(pin) = 0, nSWBoot0(bit) = 1 and NSBOOTADD0 [24:0] = 0x017F200
               TZen = 0, Boot0(pin) = 1, nSWBoot0(bit) = 1 and NSBOOTADD1 [24:0] = 0x017F200
               TZen = 0, nBoot0(bit) = 0, nSWBoot0(bit) = 0 and NSBOOTADD1 [24:0] = 0x017F200
               TZen = 0, nBoot0(bit) = 1, nSWBoot0(bit) = 0 and NSBOOTADD0 [24:0] = 0x017F200
               TZen = 1, Boot0(pin) = 0, nSWBoot0(bit) = 1 and SECBOOTADD0 [24:0] = 0x01FF000 & RSSCMD = 0
               TZen = 1, Boot0(pin) = 1, nSWBoot0 (bit) = 1 & RSSCMD = 0, BOOT_LOCK=0 or (BOOT_LOCK = 1 and SECBOOTADD0 [24:0] = 0x01FF000)
               TZen = 1, nBoot0(bit) = 1, nSWBoot0 (bit) = 0 and SECBOOTADD0 [24:0] = 0x01FF000 & RSSCMD = 0, BOOT_LOCK=0 or (BOOT_LOCK = 1 and SECBOOTADD0 [24:0] = 0x01FF000)
               TZen = 1, nBoot0(bit) = 0, nSWBoot0 (bit) = 0 & RSSCMD = 0, BOOT_LOCK=0 or BOOT_LOCK = 1 and SECBOOTADD1 [24:0] = 0x01FF000
               TZen = 1, RSSCMD = 0x1C0, BOOT_LOCK=0 or (BOOT_LOCK = 1 and SECBOOTADD0 [24:0] = 0x01FF000)
   Pattern 13  nBoot0(bit) = 0, nBoot1(bit) = 1 and nSWBoot0(bit) = 0
               nBoot0(bit) = 1, nBoot1(bit) = 1, nSWBoot0(bit) = 0 and user Flash empty
               nBoot1(bit) = 1, nSWBoot0(bit) = 1 and Boot0(pin) = 1
               nBoot1(bit) = 1, nSWBoot0(bit) = 1, Boot0(pin) = 0 and user Flash empty
   Pattern 14  BOOT_LOCK(bit) = 0, nBoot1(bit) = 1, Boot0(pin) = 1 and nSWBoot0(bit) = 1
               BOOT_LOCK(bit) = 0, nBoot1(bit) = 1, nBoot0(bit) 0 and nSWBoot0(bit) = 0
               BOOT_LOCK(bit) = 0, Boot0(pin) = 0, nSWBoot0(bit) = 1, BFB2(bit)=1 and both banks do not contain valid code
               BOOT_LOCK(bit) = 0, nBoot0(bit), nSWBoot0(bit) = 0, BFB2(bit)=1 and both banks do not contain valid code
   Pattern 15  BOOT_LOCK(bit)=0, Boot0(pin) = 1, nBoot1(bit) = 1 and nBoot0_SW(bit) = 1
               BOOT_LOCK(bit)=0, nBoot0(bit) = 0, nBoot1(bit) = 1 and nBoot0_SW(bit) = 0
   Pattern 16  Boot0(pin) = 1, nBoot1(bit) = 1 and nBoot0_SW(bit) = 1
               nBoot0(bit) = 0, nBoot1(bit) = 1 and nBoot0_SW(bit) = 0
               Boot0(pin) = 0, nBoot0_SW(bit) = 1 and main Flash memory empty

   
   Для примера, паттерн 3 для соток XL

   For XL-density devices, when booting from the main Flash memory, you have an option to
   boot from any of two memory banks. By default, boot from Flash memory bank 1 is selected.
   You can choose to boot from Flash memory bank 2 by clearing the BFB2 bit in the user
   option bytes. When this bit is cleared and the boot pins are in the boot from main Flash
   memory configuration, the device boots from system memory, and the boot loader jumps to
   execute the user application programmed in Flash memory bank 2. For further details refer
   to AN2606.

 */

//----------------------------------------------------------------------------

//! Хранит паттерны для ног BOOT0/BOOT1, бит 0 - BOOT0, бит 1 - BOOT1
struct BootPatterns
{
    unsigned beforeReset; //!< Устанавливается до сигнала Reset
    unsigned afterReset;  //!< Устанавливается после сигнала Reset
};



} // namespace bootloader
} // namespace stm32

