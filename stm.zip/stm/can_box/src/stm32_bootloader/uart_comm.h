#pragma once

//----------------------------------------------------------------------------
/*! \file
    \brief Коммуникация по UART'у с бутлоадером STM32

    См. STM AN3155 Application note - USART protocol used in the STM32 bootloader
 */

//----------------------------------------------------------------------------

#include "uart/uart_handle.h"
#include "periph/periph.h"
#include "periph/gpio.h"
#include "umba/time_service.h"
#include "periph_drivers/soft_timer/simple_ms.h"
#include "opcodes.h"


//----------------------------------------------------------------------------
// stm32::bootloader
namespace stm32 {
namespace bootloader{


//----------------------------------------------------------------------------
//! Вычисляет контрольную сумму по XOR
uint8_t calcCheckSum( const uint8_t *pData, std::size_t nBytes, uint8_t checkSumInitial = 0x00 )
{
    uint8_t checkSum = checkSumInitial;
    const uint8_t *pDataEnd = pData+nBytes;

    for(; pData!=pDataEnd; ++pData)
        checkSum ^= *pData;

    return checkSum;
}

//----------------------------------------------------------------------------
//! Отправляет данные в UART. Блокирующий режим
inline
void sendData( ISerialPort *pUart, const uint8_t *pData, std::size_t nBytes )
{
    pUart->waitTransmitComplete();
    pUart->sendStaticArray( pData, nBytes );
    pUart->waitTransmitComplete();
}

//----------------------------------------------------------------------------
//! Отправляет данные в UART. Блокирующий режим
inline
void sendData( ISerialPort *pUart, uint8_t byte )
{
    pUart->waitTransmitComplete();
    pUart->sendStaticArray( &byte, 1 );
    pUart->waitTransmitComplete();
}

//----------------------------------------------------------------------------
//! Отправляет данные для бутлоадера, дополняя их контрольной суммой по XOR. Блокирующий режим
inline
void sendDataAndCheckSum( ISerialPort *pUart, const uint8_t *pData, std::size_t nBytes, uint8_t checkSumInitial = 0x00 )
{
    sendData( pUart, pData, nBytes );
    uint8_t checkSum = calcCheckSum( pData, nBytes, checkSumInitial );
    sendData( pUart, checkSum );
}

//----------------------------------------------------------------------------
//! Отправляет команду (опкод) для бутлоадера, дополняя её комплементарной парой (XOR с 0xFF). Блокирующий режим
inline
void sendOpCode( ISerialPort *pUart, OpCode opCode )
{
     sendDataAndCheckSum( pUart, (const uint8_t*)&opCode, 1, 0xFFu );
}

//----------------------------------------------------------------------------
//! Считывает из порта максимум bufSize байт, если на таймере истекает таймаут при приёме одного байта, то приём завершается.
/*! Таймер должен быть настроен на требуемый таймаут. 
    При приёме очередного байта таймер начинает новый отсчет.
 */
inline
std::size_t readBytes( ISerialPort *pUart, uint8_t *pData, std::size_t bufSize
                     , umba::periph::drivers::SoftTimerSimpleMs  &timer
                     )
{
    std::size_t recvCount = 0;

    UMBA_ASSERT(bufSize!=0);

    timer.reset();
    while(!timer.isTimedOut())
    {
        if (pUart->isNewByte())
        {
            pData[recvCount++] = pUart->getByte();
            if (recvCount==bufSize)
                break;
            timer.reset();
        }
    }
    
    return recvCount;
}

//----------------------------------------------------------------------------
//! Вычитывает ответ ack/nack (ждёт ответ по таймеру). Блокирующий режим
/*! Таймер должен быть настроен на требуемый таймаут. 
 */
inline
ControlCode readAck( ISerialPort *pUart
                   , umba::periph::drivers::SoftTimerSimpleMs  &timer
                   )
{
     uint8_t buf[1];
     std::size_t nReaded = readBytes( pUart, &buf[0], UMBA_COUNT_OF(buf), timer );
     
     if (!nReaded)
         return ControlCode::nop;

     switch(buf[0])
     {
         case (unsigned)ControlCode::nack: 
         case (unsigned)ControlCode::ack: 
              return (ControlCode)buf[0];
         default:
              return ControlCode::err;
     }

}

//----------------------------------------------------------------------------
//! Отправляет команду (опкод) для бутлоадера, дополняя её контрольной суммой по XOR, и ждёт ответ по таймеру. Блокирующий режим
/*! Таймер должен быть настроен на требуемый таймаут. 
 */
inline
ControlCode sendOpCodeReadAck( ISerialPort *pUart, OpCode opCode
                             , umba::periph::drivers::SoftTimerSimpleMs  &timer
                             )
{
     sendOpCode( pUart, opCode );
     return readAck(pUart, timer);
}



} // namespace bootloader
} // namespace stm32

