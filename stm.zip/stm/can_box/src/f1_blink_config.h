#pragma once


#define HSE         8000000
#define FREQ       72000000
#define USB_OTG

#define UMBA_STRICT
// #define UMBA_USE_QT
#define USE_FULL_ASSERT

#define UMBA_MM
#define LOG_TO_UART
#define USE_LOUT


// #define CAN1_ENABLE
// #define CAN2_ENABLE

// #define USE_CAN1
// #define USE_CAN2

// #define USE_UART1
// #define USE_UART2
// #define USE_UART3
// #define USE_UART4
// #define USE_UART5
// #define USE_UART6
// #define USE_UART7
// #define USE_UART8
// #define USE_UART9
// #define USE_UART10

// #define USE_DMA1_CH0
// #define USE_DMA1_CH1
// #define USE_DMA1_CH2
// #define USE_DMA1_CH3
// #define USE_DMA1_CH4
// #define USE_DMA1_CH5
// #define USE_DMA1_CH6
// #define USE_DMA1_CH7

// #define USE_DMA2_CH0
// #define USE_DMA2_CH1
// #define USE_DMA2_CH2
// #define USE_DMA2_CH3
// #define USE_DMA2_CH4
// #define USE_DMA2_CH5
// #define USE_DMA2_CH6
// #define USE_DMA2_CH7

// #define USE_EXTI0
// #define USE_EXTI1
// #define USE_EXTI2
// #define USE_EXTI3
// #define USE_EXTI4
// #define USE_EXTI5
// #define USE_EXTI6
// #define USE_EXTI7
// #define USE_EXTI8
// #define USE_EXTI9
// #define USE_EXTI10
// #define USE_EXTI11
// #define USE_EXTI12
// #define USE_EXTI13
// #define USE_EXTI14
// #define USE_EXTI15

// #define USE_SPI1
// #define USE_SPI2
// #define USE_SPI3
// #define USE_SPI4
// #define USE_SPI5
// #define USE_SPI6


#include "periph/periph_use_compat.h"

