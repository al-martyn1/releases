#pragma once


#include "umba/umba.h"
#include "umba/critical_section.h"
#include "umba/preprocessor.h"
#include "periph/periph.h"


namespace umba
{
namespace periph
{
namespace drivers
{

//----------------------------------------------------------------------------
// Communication device basics

struct CommDevicePinConfig
{
    umba::periph::GpioPinAddr  rxPinAddr      = umba::periph::invalid_pin_addr ;
    umba::periph::GpioPinAddr  txPinAddr      = umba::periph::invalid_pin_addr ;
    umba::periph::GpioPinAddr  extraPinAddr   = umba::periph::invalid_pin_addr ; // RS485 direction switching pin, or CAN power, or some other - depends on target
    bool                       extraPinDefVal = false;

    //static const umba::periph::GpioPinAddr invalid_pin_addr = umba::periph::invalid_pin_addr ;
};


struct CommParams
{
    unsigned   speed       = 0;
    bool       silent      = false; // read only for UART/RS485, silent fpor CAN
    unsigned   samplePoint = 0;    // Used for CAN, in permille
};


#define UMBA_PERIPH_DRV_COMM_SIZE_DECLARE( Klasse ) \
                                                    \
struct Klasse                                       \
{                                                   \
    std::size_t value;                              \
    Klasse(std::size_t sz) : value(sz) {}           \
    operator std::size_t() const                    \
    { return value; }                               \
};

UMBA_PERIPH_DRV_COMM_SIZE_DECLARE(RxSize)
UMBA_PERIPH_DRV_COMM_SIZE_DECLARE(TxSize)

struct CommSizes
{
    size_t  rxSize;
    size_t  txSize; // sometimes no meaning when hardware queue used (CAN)
};

//----------------------------------------------------------------------------





//----------------------------------------------------------------------------
class CommDeviceBase
{

    UMBA_NON_COPYABLE_CLASS(CommDeviceBase)

public:

    typedef umba::periph::GpioPinAddr    PinAddr;

/*
    void                           *m_pHwHandle;

protected:

    bool                            m_initialized = false;
    CommParams                      m_params      ;
    CommDevicePinConfig             m_pinConfig   ;
    mutable umba::CriticalSection   m_Lock        ; // UMBA_CRITICAL_SECTION(m_Lock);
*/
    CommDeviceBase(CommSizes sizes, void *pHwHandle)                                        : m_sizes(sizes), m_pHwHandle(pHwHandle), m_params(), m_pinConfig(), m_Lock() {}
    CommDeviceBase(CommSizes sizes, void *pHwHandle, const CommDevicePinConfig &pinConfig)  : m_sizes(sizes), m_pHwHandle(pHwHandle), m_params(), m_pinConfig(pinConfig), m_Lock() {}
    CommDeviceBase(CommSizes sizes, void *pHwHandle, PinAddr rxPinAddr, PinAddr txPinAddr ) : m_sizes(sizes), m_pHwHandle(pHwHandle), m_params(), m_pinConfig(), m_Lock()
    {
        //bindPinConfig(rxPinAddr, txPinAddr );
        m_pinConfig.rxPinAddr    = rxPinAddr   ;
        m_pinConfig.txPinAddr    = txPinAddr   ;
    }

    CommDeviceBase(CommSizes sizes, void *pHwHandle, PinAddr rxPinAddr, PinAddr txPinAddr, PinAddr extraPinAddr, bool extraPinDefVal = false)
                                                                           : m_sizes(sizes), m_pHwHandle(pHwHandle), m_params(), m_pinConfig(), m_Lock()
    {
        //bindPinConfig(rxPinAddr, txPinAddr, extraPinAddr, extraPinDefVal );
        m_pinConfig.rxPinAddr       = rxPinAddr     ;
        m_pinConfig.txPinAddr       = txPinAddr     ;
        m_pinConfig.extraPinAddr    = extraPinAddr  ;
        m_pinConfig.extraPinDefVal  = extraPinDefVal;
    }


    void bindPinConfig(const CommDevicePinConfig &pinConfig)
    {
        checkOpened( false /* required current state */ , m_initialized ); // Changing params not allowed on opened device
        m_pinConfig = pinConfig;
    }

    void bindPinConfig(PinAddr rxPinAddr, PinAddr txPinAddr )
    {
        checkOpened( false /* required current state */ , m_initialized ); // Changing params not allowed on opened device
        m_pinConfig.rxPinAddr    = rxPinAddr   ;
        m_pinConfig.txPinAddr    = txPinAddr   ;
    }

    void bindPinConfig(PinAddr rxPinAddr, PinAddr txPinAddr, PinAddr extraPinAddr, bool extraPinDefVal = false)
    {
        checkOpened( false /* required current state */ , m_initialized ); // Changing params not allowed on opened device
        m_pinConfig.rxPinAddr       = rxPinAddr     ;
        m_pinConfig.txPinAddr       = txPinAddr     ;
        m_pinConfig.extraPinAddr    = extraPinAddr  ;
        m_pinConfig.extraPinDefVal  = extraPinDefVal;
    }

    CommDevicePinConfig pinConfig() const
    {
        return m_pinConfig;
    }


    unsigned speed() const
    {
        return m_params.speed;
    }

    void setSpeed(unsigned speed)
    {
        checkOpened( false /* required current state */ , m_initialized ); // Changing params not allowed on opened device
        m_params.speed = speed;
    }
    
    bool silent() const
    {
        return m_params.silent;
    }

    void setSilent(bool silent)
    {
        checkOpened( false /* required current state */ , m_initialized ); // Changing params not allowed on opened device
        m_params.silent = silent;
    }

    unsigned samplePoint() const
    {
        return m_params.silent;
    }

    void setSamplePoint(unsigned samplePoint)
    {
        checkOpened( false /* required current state */ , m_initialized ); // Changing params not allowed on opened device
        m_params.samplePoint = samplePoint;
    }

    CommParams commParams() const
    {
        return m_params;
    }

    void setCommParams( const CommParams &params)
    {
        checkOpened( false /* required current state */ , m_initialized ); // Changing params not allowed on opened device
        m_params = params;
    }

    CommSizes commSizes() const
    {
        return m_sizes;
    }

    bool isOpened() const
    {
        //UMBA_CRITICAL_SECTION(m_Lock);
        return m_initialized;
    }

    bool resetDevice()
    {
        return resetDeviceImpl();
    }

    bool open( unsigned speed, bool silent = false, unsigned samplePoint = 0)
    {
        m_params.speed       = speed ;
        m_params.silent      = silent;
        m_params.samplePoint = samplePoint;
        return open();
    }

    bool open()
    {
        UMBA_CRITICAL_SECTION(m_Lock);

        if (checkOpened( false /* required current state */ , m_initialized ))
            return true;

        if (!openImpl())
            return false;

        m_initialized = true;
        return true;
    }

    bool close()
    {
        UMBA_CRITICAL_SECTION(m_Lock);

        if (checkOpened( true /* required current state */ , m_initialized ))
            return true;

        if (!closeImpl())
            return false;

        m_initialized = false;
        return true;
    }

    //! Возвращает статус шины, значение зависит от конкретного типа устройства
    virtual
    unsigned getCommBusStatus()
    {
        return 0;
    }
    

protected:

    template<typename HardwarePointerType>
    HardwarePointerType getHwHandleImpl() const
    {
        return (HardwarePointerType)m_pHwHandle;
    }

    // return true if no more actions required
    virtual bool checkOpened( bool requiredState, bool currentState ) = 0; // Can throw exception or assertion
    virtual bool checkWritible( bool requiredState, bool currentState ) = 0; // Can throw exception or assertion

    virtual bool openImpl() = 0;
    virtual bool closeImpl() = 0;
    virtual bool resetDeviceImpl()
    {
        // By default we only reopen
        UMBA_CRITICAL_SECTION(m_Lock);
        close();
        return open();
    }




private:

    CommSizes                       m_sizes       ;
    void                           *m_pHwHandle;

protected:

    bool                            m_initialized = false;
    CommParams                      m_params      ;
    CommDevicePinConfig             m_pinConfig   ;
    mutable umba::CriticalSection   m_Lock        ; // UMBA_CRITICAL_SECTION(m_Lock);

}; // class CommDeviceBase

//----------------------------------------------------------------------------





//----------------------------------------------------------------------------
#define UMBA_PERIPH_DRV_COMM_DEVICE_PASSING_CONSTRUCTORS( thisClass, thisHandleType, parentClass, parentHandleType ) \
    thisClass(CommSizes sizes, thisHandleType pHwHandle)                                                                                          : parentClass(sizes, (parentHandleType)pHwHandle) {} \
    thisClass(CommSizes sizes, thisHandleType pHwHandle, const CommDevicePinConfig &pinConfig)                                                    : parentClass(sizes, (parentHandleType)pHwHandle, pinConfig) {} \
    thisClass(CommSizes sizes, thisHandleType pHwHandle, PinAddr rxPinAddr, PinAddr txPinAddr )                                                   : parentClass(sizes, (parentHandleType)pHwHandle, rxPinAddr, txPinAddr ) {} \
    thisClass(CommSizes sizes, thisHandleType pHwHandle, PinAddr rxPinAddr, PinAddr txPinAddr, PinAddr extraPinAddr, bool extraPinDefVal = false) : parentClass(sizes, (parentHandleType)pHwHandle, rxPinAddr, txPinAddr, extraPinAddr, extraPinDefVal ) {}


#define UMBA_PERIPH_DRV_COMM_DEVICE_PASSING_CONSTRUCTORS_CALL_INIT_BUFFERS( thisClass, thisHandleType, parentClass, parentHandleType ) \
    thisClass(CommSizes sizes, thisHandleType pHwHandle)                                                                                          : parentClass(sizes, (parentHandleType)pHwHandle) { initBuffers(); } \
    thisClass(CommSizes sizes, thisHandleType pHwHandle, const CommDevicePinConfig &pinConfig)                                                    : parentClass(sizes, (parentHandleType)pHwHandle, pinConfig) { initBuffers(); } \
    thisClass(CommSizes sizes, thisHandleType pHwHandle, PinAddr rxPinAddr, PinAddr txPinAddr )                                                   : parentClass(sizes, (parentHandleType)pHwHandle, rxPinAddr, txPinAddr ) { initBuffers(); } \
    thisClass(CommSizes sizes, thisHandleType pHwHandle, PinAddr rxPinAddr, PinAddr txPinAddr, PinAddr extraPinAddr, bool extraPinDefVal = false) : parentClass(sizes, (parentHandleType)pHwHandle, rxPinAddr, txPinAddr, extraPinAddr, extraPinDefVal ) { initBuffers(); }

//----------------------------------------------------------------------------





//----------------------------------------------------------------------------
template<typename HardwarePointerType>
class CommDevice : public CommDeviceBase
{

public: 

    typedef CommDeviceBase::PinAddr    PinAddr;

    UMBA_PERIPH_DRV_COMM_DEVICE_PASSING_CONSTRUCTORS(CommDevice, HardwarePointerType, CommDeviceBase, void*)

protected:

    HardwarePointerType getHwHandle() const { return getHwHandleImpl<HardwarePointerType>(); }

}; // class CommDevice

//----------------------------------------------------------------------------



} // namespace drivers
} // namespace periph
} // namespace umba

