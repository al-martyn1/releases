#pragma once

#include "umba/umba.h"
#include "umba/preprocessor.h"
#include "periph/periph.h"
#include "can_defs.h"


namespace umba
{
namespace periph
{
namespace drivers
{

    
// класс-база для can - совместимый с классическим CANом
class ICan
{

public:
        
    // Чтобы не ругались компиляторы
    virtual ~ICan()
    {
    }
    
    /*
    // параметры фильров
    virtual void addFilter( const CanFilter & filterParams, const uint32_t num ) = 0;
    
    virtual uint32_t getFilterCapacity() const = 0;
    */

    virtual bool init(void) = 0;

    // сброс
    virtual bool deInit(void) = 0;

    // проверка на инициализацию
    virtual bool isInited(void) = 0;        
    
    // отправка
    virtual bool transmitMessage( const CanFrame & msg ) = 0; 
    
    // прием
    virtual bool tryToReceive( CanFrame & msg ) = 0;
    virtual bool tryToReceiveEx( CanFrame & msg, CanFrameInfo &info ) = 0;
    
    // проверка на ошибку - не упало ли все
    virtual CanError getErrorState( void ) = 0;
    
    virtual void clearError( void ) = 0;
    
    //virtual uint32_t getPlatformSpecificError( void ) = 0;

    // мьютекс
    /*
    virtual bool isLocked( void ) = 0;
        
    virtual void lock( void ) = 0;

    virtual void unLock( void ) = 0;
    */
    
    virtual bool isReadyToTransmit( void ) = 0;

    virtual bool areAllTransmitsComplete( void ) = 0;

}; // class ICan



} // namespace drivers
} // namespace periph
} // namespace umba

