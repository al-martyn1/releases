#pragma once

#include "comm_device.h"
#include "can_defs.h"
#include "containers/static_cycle_deque.h"
#include "containers/helpers.h"
#include "containers/queue.h"

#include "periph/can.h"
#include "umba/time_service.h"


namespace umba
{
namespace periph
{
namespace drivers
{

//----------------------------------------------------------------------------
class CanDeviceBase : public CommDevice< CAN_TypeDef* >
                    , public umba::periph::ICanEventHandler
{

public: 

    typedef CommDevice< CAN_TypeDef* > :: PinAddr    PinAddr;


    //UMBA_PERIPH_DRV_COMM_DEVICE_PASSING_CONSTRUCTORS(CanDeviceBase, CAN_TypeDef*, CommDevice, CAN_TypeDef*)
    UMBA_PERIPH_DRV_COMM_DEVICE_PASSING_CONSTRUCTORS_CALL_INIT_BUFFERS(CanDeviceBase, CAN_TypeDef*, CommDevice, CAN_TypeDef*)

protected:

    //------------------------------
    // return true if no more actions required
    virtual bool checkOpened( bool requiredState, bool currentState ) override // Can throw exception or assertion
    {
        if (requiredState!=currentState)
        {
            UMBA_ASSERT_FAIL(); // or throw or simple pass
            return true;
        }

        return false;
    }

    virtual bool checkWritible( bool requiredState, bool currentState ) override // Can throw exception or assertion
    {
        return true;
    }

    //------------------------------
    virtual bool openImpl() override
    {
        UMBA_ASSERT( m_pinConfig.rxPinAddr != umba::periph::invalid_pin_addr );
        UMBA_ASSERT( m_pinConfig.txPinAddr != umba::periph::invalid_pin_addr );

        umba::periph::periphInit( getHwHandle()
                                , m_pinConfig.rxPinAddr // m_pinConfig.rxPinAddr.port, m_pinConfig.rxPinAddr.pinNo
                                , m_pinConfig.txPinAddr // m_pinConfig.txPinAddr.port, m_pinConfig.txPinAddr.pinNo
                                //, umba::periph::CanInterruptFlags { umba::periph::CanInterruptFlags::maskAllFlags & ~umba::periph::CanInterruptFlags::maskAllErrors }
                                , umba::periph::CanInterruptFlags { umba::periph::CanInterruptFlags::maskAllFlags }
                                , m_params.speed
                                , m_params.silent
                                , umba::periph::canNoLoopback
                                , umba::periph::canTxPriorityOrder
                                , m_params.samplePoint==0 ? (unsigned)750 : m_params.samplePoint // 875 : m_params.samplePoint // 700
                                );

        umba::periph::periphInstallIrqHandler( getHwHandle(), (umba::periph::ICanEventHandler*)this );
       
        umba::periph::periphInitIrq( getHwHandle(), 0 /* prio */ , 0 /* subPrio */  );
       
        umba::periph::canDefaultInitFilters( getHwHandle() );

        m_seqCounter = 0;
        m_rxQueue.clear();
        m_txQueue.clear();

        return true;
    }

    virtual bool closeImpl() override
    {
        //umba::periph::traits::periphReset( getHwHandle() );
        umba::periph::periphSoftReset( getHwHandle() );
        umba::periph::periphDisableIrq( getHwHandle() );
        return true;
    }


    //------------------------------

    virtual void handleCanEventTx   ( unsigned txMailboxNo, umba::periph::CanTxStatus txStatus ) override
    {
        //UMBA_CRITICAL_SECTION(m_Lock);

        // txStatus==umba::periph::CanTxStatus{umba::periph::CanTxStatus::ok}

        if (umba::periph::serialIsReadyToTransmit( getHwHandle() ))
        {
            if (!m_txQueue.empty())
            {
                CanFrame msg = m_txQueue.front();
                if (umba::periph::serialTransmit( getHwHandle(), msg ))
                    m_txQueue.pop();
            }
        }
/*
struct CanTxStatus
{
    typedef unsigned value_type;

    static const unsigned ok               = 1;
    static const unsigned arbitrationLost  = 2;
    static const unsigned txError          = 4;

    virtual bool tryToReceive( CanFrame & msg ) override
    {
        if (m_rxDeque.empty())
            return false;

        msg = m_rxDeque.front();
        m_rxDeque.pop_front();

*/
    }


    virtual void handleCanEventRx   ( unsigned fifoNo     , umba::periph::CanRxStatus rxStatus, unsigned pendingMessagesCount ) override
    {
        //UMBA_CRITICAL_SECTION(m_Lock);

        CanFrame canFrame;
        // while( umba::periph::traits::canFifoGetMessagesPendingCount( getHwHandle(), fifoNo )>0
        //     && umba::periph::traits::canFifoGetDataUnchecked( getHwHandle(), canFrame.can_id, canFrame.can_dlc, &canFrame.data[0], fifoNo)
        //      )
        while( umba::periph::serialGetPendingCount( getHwHandle(), fifoNo )>0
            && umba::periph::serialReceive( getHwHandle(), canFrame, fifoNo)
             )
        {
            if (m_initialized)
            {
                ReceivedCanFrameInfo rcv;
                rcv.frame               = canFrame;
                rcv.frameInfo.seqNumber = m_seqCounter++;
                rcv.frameInfo.timeStamp = (uint32_t)umba::time_service::getCurTimeMs();
                rcv.frameInfo.flags     = rcv.frameInfo.flagAllGood;
                m_rxQueue.push(rcv);
            }
        }
    }


    virtual void handleCanEventError( umba::periph::CanInterruptFlags flags, umba::periph::CanError lastErrCode, unsigned rxErrCounter, unsigned txErrCounter ) override
    {
        UMBA_CRITICAL_SECTION(m_Lock);
        m_lastError    = lastErrCode;
        m_rxErrCounter = rxErrCounter;
        m_txErrCounter = txErrCounter;
    }

    //------------------------------

    bool canTransmitOrBufferize( )
    {
        return umba::periph::serialIsReadyToTransmit( getHwHandle() ) || umba::containers::safe_available_capacity(m_txQueue);
    }

    bool transmitOrBufferize( const CanFrame &msg )
    {
        if ( umba::periph::serialIsReadyToTransmit( getHwHandle() ) && umba::periph::serialTransmit( getHwHandle(), msg ))
        {
            return true;
        }

        return m_txQueue.push(msg);
    }

    //------------------------------

    void initBuffers()
    {
        m_rxQueue.reserve( commSizes().rxSize );
        m_txQueue.reserve( commSizes().txSize );
    }


protected:

    virtual
    unsigned getCommBusStatus() override
    {
        return (unsigned)umba::periph::canGetBusStatus( getHwHandle() );
    }


    // RX
    typedef umba::containers::static_cycle_deque<ReceivedCanFrameInfo>                           input_queue_container_type;
    typedef umba::containers::safe_queue< ReceivedCanFrameInfo, input_queue_container_type >     input_queue_type;

    // TX
    typedef umba::containers::static_cycle_deque<CanFrame>                                       output_queue_container_type;
    typedef umba::containers::safe_queue< CanFrame, output_queue_container_type >                output_queue_type;


    input_queue_type     m_rxQueue;
    output_queue_type    m_txQueue;

    CanError       m_lastError;
    unsigned       m_rxErrCounter;
    unsigned       m_txErrCounter;
    uint32_t       m_seqCounter;


};

//----------------------------------------------------------------------------




} // namespace drivers
} // namespace periph
} // namespace umba

