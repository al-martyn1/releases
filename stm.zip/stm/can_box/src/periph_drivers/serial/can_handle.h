#pragma once

#include "can_device_base.h"
#include "i_can.h"


namespace umba
{
namespace periph
{
namespace drivers
{

class CanHandle : public CanDeviceBase
                , public ICan
{

public: 

    typedef CommDevice< CAN_TypeDef* > :: PinAddr    PinAddr;

    UMBA_PERIPH_DRV_COMM_DEVICE_PASSING_CONSTRUCTORS(CanHandle, CAN_TypeDef*, CanDeviceBase, CAN_TypeDef*)

    virtual bool init(void) override
    {
        return open();
    }

    // сброс
    virtual bool deInit(void) override
    {
        return close();
    }

    // проверка на инициализацию
    virtual bool isInited(void) override
    {
        return isOpened();
    }

    // отправка
    virtual bool transmitMessage( const CanFrame & msg ) override
    {
        //return umba::periph::serialTransmit( getHwHandle(), msg );
        return transmitOrBufferize(msg);
    }
    
    // прием
    virtual bool tryToReceive( CanFrame & msg ) override
    {
        if (m_rxQueue.empty())
            return false;

        auto info = m_rxQueue.pop();
        msg = info.frame;

        return true;
    }

    virtual bool tryToReceiveEx( CanFrame & msg, CanFrameInfo &frameInfo ) override
    {
        if (m_rxQueue.empty())
            return false;

        auto info = m_rxQueue.pop();
        msg       = info.frame;
        frameInfo = info.frameInfo;

        return true;
    }

    
    // проверка на ошибку - не упало ли все
    virtual CanError getErrorState( void ) override
    {
        return m_lastError;
    }
    
    virtual void clearError( void ) override
    {
        m_lastError = CanError::noError;
    }
    
    //virtual uint32_t getPlatformSpecificError( void ) = 0;

    // мьютекс
    /*
    virtual bool isLocked( void ) = 0;
        
    virtual void lock( void ) = 0;

    virtual void unLock( void ) = 0;
    */
    
    virtual bool isReadyToTransmit( void ) override
    {
        //return umba::periph::serialIsReadyToTransmit( getHwHandle() );
        return canTransmitOrBufferize();
    }

    virtual bool areAllTransmitsComplete( void ) override
    {
        return umba::periph::serialAreAllTransmitsComplete(getHwHandle()) && m_txQueue.empty();
    
    }



}; // class CanHandle





} // namespace drivers
} // namespace periph
} // namespace umba

