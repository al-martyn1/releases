#pragma once

#include "umba/umba.h"
#include "periph/periph.h"


namespace umba
{
namespace periph
{
namespace drivers
{

typedef umba::periph::CanFrame           CanFrame;
typedef umba::periph::CanError           CanError;
typedef umba::periph::CanFrameInfo       CanFrameInfo;
typedef umba::periph::CanBusStatus       CanBusStatus;

struct ReceivedCanFrameInfo
{
    CanFrame      frame;
    CanFrameInfo  frameInfo;
};


} // namespace drivers
} // namespace periph
} // namespace umba

