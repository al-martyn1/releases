#pragma once

//----------------------------------------------------------------------------
/*!
\file
\brief Софтварный легковесный милисекундный таймер
*/

//----------------------------------------------------------------------------

#include "umba/umba.h"
#include "umba/preprocessor.h"
#include "umba/time_service.h"
#include "umba/basic_interfaces.h"

// umba::periph::drivers

//----------------------------------------------------------------------------
namespace umba {
namespace periph {
namespace drivers {



//----------------------------------------------------------------------------
//! Софтварный легковесный милисекундный таймер
/*!
    Срабатывает однократно и требует ручного перезапуска,
    либо периодически. 

    После создания не активен, требует перезапуска методом reset.

    Не является потокобезопасным.

 */
class SoftTimerSimpleMs
{
    typedef umba::time_service::TimeTick TimeTick;   //!< Тип тиков

    UMBA_NON_COPYABLE_CLASS(SoftTimerSimpleMs)

public:

    //! Конструктор, создаёт неактивный таймер. 
    SoftTimerSimpleMs( TimeTick timeout = 0    //!< Таймаут. При нулевом таймауте таймер не будет срабатывать.
                     , bool autoReset = false  //!< Признак автоматического перезапуска
                     ) 
    : m_timeout(timeout), m_startTick(0), m_autoReset(autoReset), m_active(0)
    {}

    //! Устанавливает таймаут без перезапуска таймера
    void setTimeout( TimeTick newTimeout )  { m_timeout = newTimeout; }

    //! Возвращает текущее значение таймаута
    TimeTick getTimeout( ) const            { return m_timeout; }

    //! Устанавливает значение признака автоматического перезапуска
    void setAutoreset( bool autoReset )     { m_autoReset = autoReset; }
    //! Возвращает значение признака автоматического перезапуска
    bool getAutoreset( ) const              { return m_autoReset; }

    //! Перезапускает таймер с текущим интервалом
    void reset( )
    {
        m_startTick = umba::time_service::getCurTimeMs();
        m_active    = true;
    }

    //! Задает новый интервал и перезапускает таймер
    void reset( TimeTick newTimeout )
    {
        m_timeout = newTimeout;
        reset( );
    }

    //! Возвращает true, если таймер активен
    bool isActive() const  { return m_active; }

    //! Проверяет истечение таймаута и перезапускает таймер, если autoReset включен
    /*! Срабатывает ровно один раз, поэтому если состояние срабатывания нужно в нескольких местах, его нужно сразу сохранить в переменную.
     */
    bool isTimedOut() const
    {
        bool res = false;

        if (!m_timeout || !m_active)
            return res;

        TimeTick tickNow  = umba::time_service::getCurTimeMs();
        TimeTick tickDiff = tickNow - m_startTick;

        res = tickDiff>=m_timeout ? true : false;
        if (!res)
            return res;

        if (m_autoReset)
            m_startTick = tickNow;
        else
            m_active = false;

        return res;
    }

    //! Производит блокирующее ожидание готовности таймера
    void wait() const { while(!isTimedOut()) {} }


protected:

    TimeTick          m_timeout;    //!< Период срабатывания
    mutable TimeTick  m_startTick;  //!< Стартовый тик
    bool              m_autoReset;  //!< Признак автоматического перезапуска
    mutable bool      m_active;     //!< Признак активности

}; // class SoftTimerSimpleMs




} // namespace drivers
} // namespace periph
} // namespace umba

