Pumba Wizardry is a tool for easy creation of the wizards for processes automation.

* Wizardry - term that means workshop of the magic (like blacksmith and a smithy, forge or a blacksmith's shop).

Let's automate red tape, bureaucracy and trivial rounds.

Follow the link: [https://github.com/al-martyn1/pumba-wizardry](https://github.com/al-martyn1/pumba-wizardry)

https://www.doxygen.nl/manual/markdown.html#md_page_header