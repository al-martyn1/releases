#pragma once

#include "robot.h"

namespace robot
{

// Делаем плоский список всех слейв устройств всех шин мастер-устройства, без рекурсии
/*
struct DeviceSlavesFlatListItem
{
    LinkPort      port;
    DeviceInfo   *pDevice;
};
*/

inline
std::vector< DeviceInfo* > makeRobotSlavesFlatVector( const DeviceInfo &rootDevice )
{
    std::vector< DeviceInfo* > slavesFlatVector;

    DeviceInfo::BusMap::const_iterator bit = rootDevice.buses.begin();
    for(; bit != rootDevice.buses.end(); ++bit)
    {
        size_t idx = 0, size = bit->second.devices.size();
        for(; idx!=size; ++idx)
        {
            if (bit->second.devices[idx].parentBus== LinkPort::getInvalidValue())
                throw std::runtime_error("Unexpected invalid device bus");

            const DeviceInfo *pDeviceInfo = &bit->second.devices[idx];
            slavesFlatVector.push_back( (DeviceInfo *)pDeviceInfo );
        }
    }

    return slavesFlatVector;
}




} // namespace robot


