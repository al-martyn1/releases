#pragma once

#include "robot.h"
#include "umba/string_plus.h"

#include <set>

/* Нужно уметь фильтровать сообщения.
   Фильтровать нужно по:
       1) Шине
       2) Адресу устройства
       3) Имени регистра

   Фильтры:
     UART1/0x12/error,alert,warning
     UART1,UART2/0x13/error,alert,warning
     UART1/0x12/*
     * /0x13,0x12/error
     * / * /error

   RO-регистры имеют адреса от 0 до 127;
   WO-регистры (RW) имеют адреса от 128 до 255.

*/


namespace robot
{


struct LinkPortAndDeviceAddrKey
{
    LinkPort     linkPort;
    unsigned     deviceAddr;

    int compare(const LinkPortAndDeviceAddrKey &other) const
    {
        int linkPortCmpRes = linkPort.compare( other.linkPort );
        if (linkPortCmpRes!=0)
            return linkPortCmpRes;

        if ( deviceAddr < other.deviceAddr )
            return -1;
        if ( deviceAddr > other.deviceAddr )
            return 1;

        return 0;
    }

    bool operator<( const LinkPortAndDeviceAddrKey &other ) const
    {
        return compare(other)<0;
    }

    bool operator>( const LinkPortAndDeviceAddrKey &other ) const
    {
        return compare(other)>0;
    }

}; // struct LinkPortAndDeviceAddrKey




struct SimpleFilter
{

    static
    std::vector<SimpleFilter> fromFiltersString( const std::vector<std::string> &strs, const std::vector< robot::DeviceInfo* > &devices )
    {
        std::vector<SimpleFilter> res;

        for( auto str : strs )
        {
            umba::string_plus::trim( str );
            if (str.empty())
                continue;

            res.push_back( fromFilterString(str, devices) );
        }

        return res;
    }


    static
    std::vector<SimpleFilter> fromFiltersString( const std::string &strs, const std::vector< robot::DeviceInfo* > &devices )
    {
        std::vector<std::string> filterStrings = umba::string_plus::split( strs, ';', false  /* skipEmpty */ );
        return fromFiltersString( filterStrings, devices );
    }


    static
    SimpleFilter fromFilterString( const std::string &str, const std::vector< robot::DeviceInfo* > &devices )
    {
        SimpleFilter res;

        std::vector<std::string> tokens = umba::string_plus::split( str, '/', false  /* skipEmpty */ );
        if (tokens.size()<3)
        {
            throw std::runtime_error("Too few filter parameters. Filter must contain three parts, separated by '/' symbol");
        }
        if (tokens.size()>3)
        {
            throw std::runtime_error("Too many filter parameters. Filter must contain three parts, separated by '/' symbol");
        }

        for( auto &t : tokens ) umba::string_plus::trim( t );

        const std::string & busFilterStr  = tokens[0];
        const std::string & addrFilterStr = tokens[1];
        const std::string & regFilterStr  = tokens[2];

        if (busFilterStr.empty())
        {
            throw std::runtime_error("Empty bus name (bus link port) filter part");
        }

        if (addrFilterStr.empty())
        {
            throw std::runtime_error("Empty device address filter part");
        }

        if (regFilterStr.empty())
        {
            throw std::runtime_error("Empty register names filter part");
        }

        if (busFilterStr!="*")
        {
            std::vector<std::string> busFilterTokens = umba::string_plus::split( busFilterStr, ',', false  /* skipEmpty */ );
            for( auto &f : busFilterTokens )
            {
                umba::string_plus::trim( f );

                if (f.empty())
                {
                    throw std::runtime_error("Empty bus name (bus link port) filter part");
                }

                auto linkPort = linkPortFromStringThrown( f );

                bool found = false;
                for (auto pDevice : devices)
                {
                    if (pDevice->parentBus == linkPort)
                    {
                        found = true;
                        break;
                    }
                }

                if (!found)
                {
                    throw std::runtime_error( std::string("Bus name (bus link port) filter '") + f + std::string("' - not found in the device configuration") );
                }

                res.m_portFilters.insert(linkPort);
            }
        }

        if (addrFilterStr!="*")
        {
            std::vector<std::string> addrFilterTokens = umba::string_plus::split( addrFilterStr, ',', false  /* skipEmpty */ );
            for( auto &f : addrFilterTokens )
            {
                umba::string_plus::trim( f );

                if (f.empty())
                {
                    throw std::runtime_error("Empty device address filter part");
                }

                unsigned addrFilter = (unsigned)std::stoul( f, 0, 0 );

                bool found = false;
                for (auto pDevice : devices)
                {
                    if (pDevice->address == addrFilter && res.isDeviceMatchesBusLinkPortFilter(*pDevice))
                    {
                        found = true;
                        break;
                    }
                }

                if (!found)
                {
                    throw std::runtime_error( std::string("No bus (bus link port) found in '") + busFilterStr + std::string("' for device address '") + f + std::string("'") );
                }

                res.m_addrFilters.insert(addrFilter);
            }
        }

        struct NamePair
        {
            std::string ns;
            std::string regNameFilter;
            std::string refName;
        };


        if (regFilterStr=="*")
        {
            res.m_anyReg = true;
        }
        else
        {
            res.m_anyReg = false;
            std::vector< NamePair > regNames;

            std::vector<std::string> regFilterTokens = umba::string_plus::split( regFilterStr, ',', false  /* skipEmpty */ );


            for( auto &f : regFilterTokens )
            {
                umba::string_plus::trim( f );

                if (f.empty())
                {
                    throw std::runtime_error("Empty register name part");
                }

                std::string regNameLower = umba::string_plus::tolower_copy(f);

                if (res.m_regNameMap.find(regNameLower)==res.m_regNameMap.end())
                {
                    res.m_regNameMap[regNameLower] = res.m_regNames.size();
                    res.m_regNames.push_back(f);
                }

                if (umba::string_plus::starts_with_and_strip(regNameLower, "ro."))
                {
                    if (regNameLower.empty())
                    {
                        throw std::runtime_error("Empty register name part");
                    }
                    regNames.push_back( NamePair{ "ro", umba::string_plus::trim_copy(regNameLower), f } );
                }
                else if (umba::string_plus::starts_with_and_strip(regNameLower, "rw.") || umba::string_plus::starts_with_and_strip(regNameLower, "wo."))
                {
                    if (regNameLower.empty())
                    {
                        throw std::runtime_error("Empty register name part");
                    }
                    regNames.push_back( NamePair{ "rw", umba::string_plus::trim_copy(regNameLower), f } );
                }
                else
                {
                    regNames.push_back( NamePair{ "ro", umba::string_plus::trim_copy(regNameLower), f } );
                    regNames.push_back( NamePair{ "rw", umba::string_plus::trim_copy(regNameLower), f } );
                }
            }


            std::map< std::string, size_t> usageCounts;

            for( const auto &np : regNames )
            {
                bool isRw = np.ns=="rw";

                for (auto pDevice : devices)
                {
                    if (!res.isDeviceMatchesBusLinkPortFilter(*pDevice))
                        continue;
                    if (!res.isDeviceMatchesAddress(*pDevice))
                        continue;

                    std::vector<size_t> regMatches = findTableRegNameMatches( isRw ? &pDevice->rwTable : &pDevice->roTable // regs::IRegTableForUi *pRegTable
                                                                            , np.regNameFilter
                                                                            , isRw ? makeRwFlag() : (size_t)0
                                                                            );
                    usageCounts[ np.refName ] += regMatches.size();

                    // std::map< LinkPortAndDeviceAddrKey , std::set<size_t> >  m_regFilters; // логические регистры. У RW старшиый бит установлен
                    LinkPortAndDeviceAddrKey key;
                    key.linkPort   = pDevice->parentBus;
                    key.deviceAddr = pDevice->address;

                    for( const auto &regMatch : regMatches )
                    {
                        res.m_regFilters[key].insert(regMatch);
                    }

                } // for (auto pDevice : devices)

            } // for( const auto &np : regNames )

            std::map< std::string, size_t>::const_iterator ucIt = usageCounts.begin();
            for(; ucIt != usageCounts.end(); ++ucIt)
            {
                if (ucIt->second==0)
                {
                    throw std::runtime_error( std::string("Register name filter '") + ucIt->first + std::string("' doesn't match any register in devices under Bus/Address filters") );
                }
            }

        } // if (regFilterStr=="*")

        return res;
    }

    bool isMatches( LinkPort linkPort, unsigned deviceAddr, size_t regNumber, bool rwReg ) const
    {
        if (!isMatchesBusLinkPortFilter(linkPort))
            return false;

        if (!isMatchesAddress(deviceAddr))
            return false;

        if (m_anyReg)
            return true;

        LinkPortAndDeviceAddrKey key = LinkPortAndDeviceAddrKey{ linkPort, deviceAddr };

        std::map< LinkPortAndDeviceAddrKey , std::set<size_t> >::const_iterator rfIt = m_regFilters.find(key);
        if (rfIt==m_regFilters.end())
            return false;

        const std::set<size_t> &regSet = rfIt->second;
        size_t idxToFind = regNumber | (rwReg ? makeRwFlag() : (size_t)0);
        if (regSet.find(idxToFind)==regSet.end())
            return false;

        return true;
    }

    bool isMatches( const DeviceInfo &device, size_t regNumber, bool rwReg ) const
    {
        return isMatches( device.parentBus, device.address, regNumber, rwReg );
    }


protected:


    bool isMatchesBusLinkPortFilter( LinkPort linkPort ) const
    {
        if (m_portFilters.empty())
            return true;

        return m_portFilters.find( linkPort ) != m_portFilters.end();
    }


    bool isMatchesAddress( unsigned deviceAddr ) const
    {
        if (m_addrFilters.empty())
            return true;

        return m_addrFilters.find( deviceAddr ) != m_addrFilters.end();
    }

    bool isDeviceMatchesBusLinkPortFilter( const DeviceInfo &device ) const
    {
        return isMatchesBusLinkPortFilter(device.parentBus);
    }

    bool isDeviceMatchesAddress( const DeviceInfo &device ) const
    {
        return isMatchesAddress(device.address);
    }


    /*
    bool isDeviceMatchesRegNumber( const DeviceInfo &device, size_t regNumber, bool rwReg ) const
    {
    
    }
    */

    static
    size_t makeRwFlag()
    {
        size_t mask = ~(size_t)0;
        return mask - (mask>>1);
    }


    static
    std::vector<size_t> findTableRegNameMatches( regs::IRegTableForUi *pRegTable, const std::string &regNameToMatch, size_t mask )
    {
        std::vector<size_t> matchedIndexes;

        size_t regNum = 0, numRegs = pRegTable->getNumOfRegs();
        for(; regNum!=numRegs; ++regNum)
        {
            const char *pName = pRegTable->regGetName(regNum);
            if (!pName)
                continue;

            std::string regName = umba::string_plus::tolower_copy(pName);
            if (regName.empty())
                continue;

            if (regName.find(regNameToMatch)==regName.npos)
                continue;

            matchedIndexes.push_back(regNum | mask);
        }

        return matchedIndexes;
    }





    std::set<LinkPort>                                       m_portFilters; // if empty any port allowed

    std::set<unsigned>                                       m_addrFilters;

    // Фильтров может и не быть, если заданные имена не содержатся ни в одном устройстве
    // Эту ситуацию нужно отличать от того, когда задана *
    bool                                                     m_anyReg;
    std::map< LinkPortAndDeviceAddrKey , std::set<size_t> >  m_regFilters; // логические регистры. У RW старшиый бит установлен

    std::map< std::string, size_t >                          m_regNameMap;
    std::vector< std::string>                                m_regNames;


};




struct SimpleFilterRule
{
    const umba::Ini::LineInfo     lineInfo;

    std::string                   name;

    std::vector<SimpleFilter>     filters;
    std::vector<SimpleFilter>     excludes;

    bool isClean() const
    {
        return name.empty() && filters.empty() && excludes.empty();
    }

    std::string getEmptyRequiredFieldName() const
    {
        if (name.empty())
            return "name";
        if (filters.empty())
            return "filter";
        return std::string();
    }

    SimpleFilterRule()
    : lineInfo()
    , name()
    , filters()
    , excludes()
    {}

    SimpleFilterRule( const SimpleFilterRule &r )
    : lineInfo(r.lineInfo)
    , name(r.name)
    , filters(r.filters)
    , excludes(r.excludes)
    {}

    SimpleFilterRule( const umba::Ini::LineInfo &li )
    : lineInfo(li)
    , name()
    , filters()
    , excludes()
    {}

}; // struct SimpleFilterRule



struct SimpleFilterSet;

SimpleFilterSet readFilterSetImpl( const std::string &fileName, const std::vector< robot::DeviceInfo* > &flatSlaves );


struct SimpleFilterSet
{
    DeviceVersionInfo               versionInfo;
    std::vector<SimpleFilterRule>   rules;

    static
    SimpleFilterSet readFromIni( const std::string &fileName, const std::vector< robot::DeviceInfo* > &flatSlaves )
    {
        return readFilterSetImpl( fileName, flatSlaves );
    }


}; // struct SimpleFilterRule


struct SimpleFilterSetIniHandler
{

    SimpleFilterSetIniHandler( const std::vector< robot::DeviceInfo* > &devices )
    : m_devices(devices)
    , m_filterSet()
    {}


    bool operator()( const umba::Ini::LineInfo &lineInfo ) const
    {
        if (lineInfo.isEmpty() || lineInfo.isComment())
            return true;

        if (lineInfo.isSection("filter"))
        {
            m_readFilters = true;

            if (!m_filterSet.rules.empty())
            {
                std::string requiredField = m_filterSet.rules.back().getEmptyRequiredFieldName();
                if (!requiredField.empty())
                {
                    throw umba::FileParsingException( std::string("Filter - required '") + requiredField + std::string("' parameter"), m_filterSet.rules.back().lineInfo.getFileName(), m_filterSet.rules.back().lineInfo.getLineNumber() );
                }
            }

            m_filterSet.rules.push_back(SimpleFilterRule(lineInfo));

            return true;
        }
        else if (lineInfo.isSection())
        {
            throw umba::FileParsingException( std::string("Unknown section '") + lineInfo.getName() + std::string("'"), lineInfo.getFileName(), lineInfo.getLineNumber() );
        }
        else
        {
            if (m_readFilters)
            {
                if (lineInfo.isValue("name"))
                {
                    if (!m_filterSet.rules.back().name.empty())
                    {
                        throw umba::FileParsingException( std::string("Parameter 'name' already taken"), lineInfo.getFileName(), lineInfo.getLineNumber() );
                    }
                    m_filterSet.rules.back().name = lineInfo.getValue<std::string>( );
                    return true;
                }
                else
                {
                    try
                    {
                        if (lineInfo.isValue("filter"))
                        {
                            if (m_filterSet.rules.empty())
                                throw std::runtime_error("Unexpected condition on 'filter' parameter");
                            m_filterSet.rules.back().filters.push_back( SimpleFilter::fromFilterString( lineInfo.getValue<std::string>( ), m_devices ) );
                            return true;
                        }
                        else if (lineInfo.isValue("exclude"))
                        {
                            if (m_filterSet.rules.empty())
                                throw std::runtime_error("Unexpected condition on 'filter' parameter");
                            m_filterSet.rules.back().excludes.push_back( SimpleFilter::fromFilterString( lineInfo.getValue<std::string>( ), m_devices ) );
                            return true;
                        }
                    }
                    catch( const std::exception &e )
                    {
                        throw umba::FileParsingException( e.what(), lineInfo.getFileName(), lineInfo.getLineNumber() );
                    }
                    catch(...)
                    {
                        throw umba::FileParsingException( "Unknown error", lineInfo.getFileName(), lineInfo.getLineNumber() );
                    }
                }

                throw umba::FileParsingException( std::string("Unknown parameter '") + lineInfo.getName() + std::string("'"), lineInfo.getFileName(), lineInfo.getLineNumber() );

            }
            else
            {
                if (lineInfo.isValue("codename"))
                {
                    m_filterSet.versionInfo.codename = lineInfo.getValue<std::string>( );
                    return true;
                }
                else if (lineInfo.isValue("version"))
                {
                    m_filterSet.versionInfo.version = lineInfo.getValue<std::string>( );
                    return true;
                }
                else if (lineInfo.isValue("version-hash"))
                {
                    m_filterSet.versionInfo.versionHash = lineInfo.getValue<std::string>( );
                    return true;
                }
                else if (lineInfo.isValue("home-url"))
                {
                    m_filterSet.versionInfo.homeUrl = lineInfo.getValue<std::string>( );
                    return true;
                }
                else if (lineInfo.isValue("source-location"))
                {
                    m_filterSet.versionInfo.sourceLocation = lineInfo.getValue<std::string>( );
                    return true;
                }
           
                throw umba::FileParsingException( std::string("Unknown parameter '") + lineInfo.getName() + std::string("'"), lineInfo.getFileName(), lineInfo.getLineNumber() );
           
            }
        
        }

        return true;
    }


    SimpleFilterSet getFilterSet() const
    {
        return m_filterSet;
    }


protected:

    const std::vector< robot::DeviceInfo* > &m_devices;
    mutable SimpleFilterSet                  m_filterSet;
    mutable bool                             m_readFilters = false;

}; // struct SimpleFilterSetIniHandler




inline
SimpleFilterSet readFilterSetImpl( const std::string &fileName, const std::vector< robot::DeviceInfo* > &flatSlaves )
{
    umba::Ini filtersConfigIni;
    if (!filtersConfigIni.readFrom(fileName))
        throw umba::FileException( std::string("Failed to read filters INI"), fileName );

    SimpleFilterSetIniHandler filterSetIniHandler(flatSlaves);
    filtersConfigIni.parse( filterSetIniHandler );
    return filterSetIniHandler.getFilterSet();
}





} // namespace robot


