#pragma once

#include "umba/string_plus.h"
#include "umba/enum_helpers.h"
#include "umba/exception.h"
#include "umba/ini.h"
#include "robot/robot.h"


#include <vector>
#include <set>
#include <exception>
#include <stdexcept>
#include <stack>
#include <iostream>


namespace robot
{




struct RobotIniHandler
{
    RobotIniHandler( const LinkTypeSortOrderRemap &busOrder, bool flatMode, const std::string &busRemapSectionName = std::string(), const std::string &importPath = std::string(), bool convert485 = false )
    : m_deviceStack()
    , m_flatMode( true /* flatMode */ ) //UNDONE: flat mode used always, argument ignored!!!
    , m_busRemapSectionName(busRemapSectionName)
    , m_importPath(importPath)
    , m_convert485(convert485)
    {}


    LinkPort linkPortFromString( const std::string &name, const umba::Ini::LineInfo &lineInfo ) const
    {
        try
        {
            return linkPortFromStringThrown( name );
        }
        catch( const std::exception &e )
        {
            throw umba::FileParsingException( e.what(), lineInfo.getFileName(), lineInfo.getLineNumber() );
        }
        catch( ... )
        {
            throw umba::FileParsingException( "Unknown error", lineInfo.getFileName(), lineInfo.getLineNumber() );
        }
    }

    bool parseParameters( const umba::Ini::LineInfo &lineInfo ) const
    {
        //----------------

        if (m_deviceStack.empty())
            throw umba::FileParsingException( std::string("Parameters found before any device definition"), lineInfo.getFileName(), lineInfo.getLineNumber() );

        DeviceInfo *pDeviceInfo = &m_deviceStack.top();

        bool rootDevice = true;
        if (m_deviceStack.size()>1)
             rootDevice = false;

        auto currentBus = pDeviceInfo->currentBus;

        DeviceInfo::BusMap::iterator busIt = pDeviceInfo->buses.find(pDeviceInfo->currentBus);
        if (busIt != m_deviceStack.top().buses.end() && !busIt->second.devices.empty())
        {
            pDeviceInfo = & busIt->second.devices.back();
            rootDevice  = false;
        }
            
        //m_deviceStack.top().currentBus

        //busRemap

        if (m_readingMode == ReadingMode::device)
        {
            if (lineInfo.isValue("address"))
            {
                unsigned addr = 0;

                if (pDeviceInfo->parentBus==LinkPort::getInvalidValue())
                {
                    throw umba::FileParsingException( std::string("Device bus not defined"), lineInfo.getFileName(), lineInfo.getLineNumber() );
                }
                else if (pDeviceInfo->parentBus.linkType==LinkType::uart || pDeviceInfo->parentBus.linkType==LinkType::rs485)
                {
                    addr = lineInfo.getValue( 0u, GanjubusAddressValidator() );
                }
                else if (pDeviceInfo->parentBus.linkType==LinkType::can)
                {
                    addr = lineInfo.getValue( 0u, CanabusAddressValidator() );
                }
                else
                {
                    throw umba::FileParsingException( std::string("Unknown device bus"), lineInfo.getFileName(), lineInfo.getLineNumber() );
                }

                pDeviceInfo->address = addr;

                return true;

            }
            else if (lineInfo.isValue("name"))
            {
                pDeviceInfo->name = lineInfo.getValue( umba::Ini::CppNameValidator() );
                return true;
            }
            else if (lineInfo.isValue("display-name"))
            {
                pDeviceInfo->displayName = lineInfo.getValue<std::string>( );
                return true;
            }
            else if (lineInfo.isValue("uplink-port"))
            {
                std::string linkPortStr = lineInfo.getValue<std::string>();
                //LinkPort busName;
                try
                {
                    pDeviceInfo->parentBus = linkPortFromStringThrown( linkPortStr );
                }
                catch( const std::exception &e )
                {
                    throw umba::FileParsingException( e.what(), lineInfo.getFileName(), lineInfo.getLineNumber() );
                }
                catch( ... )
                {
                    throw umba::FileParsingException( "Unknown error", lineInfo.getFileName(), lineInfo.getLineNumber() );
                }

                return true;
            }
            else if (lineInfo.isValue("baudrate"))
            {
                pDeviceInfo->baudrate = lineInfo.getValue<unsigned>();
                return true;
            }
            else
            {
                if (!rootDevice)
                {
                    if (lineInfo.isValue("file"))
                    {
                        pDeviceInfo->definitionFile = lineInfo.getValue<std::string>( );
                        return true;
                    }
                    else if (lineInfo.isValue("device"))
                    {
                        pDeviceInfo->definitionDevice = lineInfo.getValue<std::string>( );
                        return true;
                    }
                }
                else
                {
                
                    if (lineInfo.isValue("import-path"))
                    {
                        pDeviceInfo->importPath = lineInfo.getValue<std::string>( );
                        return true;
                    }
                    else if (lineInfo.isValue("codename"))
                    {
                        pDeviceInfo->versionInfo.codename = lineInfo.getValue<std::string>( );
                        return true;
                    }
                    else if (lineInfo.isValue("version"))
                    {
                        pDeviceInfo->versionInfo.version = lineInfo.getValue<std::string>( );
                        return true;
                    }
                    else if (lineInfo.isValue("version-hash"))
                    {
                        pDeviceInfo->versionInfo.versionHash = lineInfo.getValue<std::string>( );
                        return true;
                    }
                    else if (lineInfo.isValue("home-url"))
                    {
                        pDeviceInfo->versionInfo.homeUrl = lineInfo.getValue<std::string>( );
                        return true;
                    }
                    else if (lineInfo.isValue("source-location"))
                    {
                        pDeviceInfo->versionInfo.sourceLocation = lineInfo.getValue<std::string>( );
                        return true;
                    }

                    /*
                    else if (lineInfo.isValue("baudrate"))
                    {
                        pDeviceInfo->baudrate = lineInfo.getValue<unsigned>();
                        return true;
                    }
                    else if (lineInfo.isValue("uplink-port"))
                    {
                        std::string linkPortStr = lineInfo.getValue<std::string>();
                        //LinkPort busName;
                        try
                        {
                            pDeviceInfo->parentBus = linkPortFromStringThrown( linkPortStr );
                        }
                        catch( const std::exception &e )
                        {
                            throw umba::FileParsingException( e.what(), lineInfo.getFileName(), lineInfo.getLineNumber() );
                        }
                        catch( ... )
                        {
                            throw umba::FileParsingException( "Unknown error", lineInfo.getFileName(), lineInfo.getLineNumber() );
                        }

                        return true;
                    }
                    */
                }

                throw umba::FileParsingException( std::string("Unknown parameter '") + lineInfo.getName() + std::string("'"), lineInfo.getFileName(), lineInfo.getLineNumber() );
            }

        }
        else if (m_readingMode == ReadingMode::remap)
        {
            auto remapKey = this->linkPortFromString( lineInfo.getName()           , lineInfo );
            auto remapVal = this->linkPortFromString( lineInfo.getValueStringAsIs(), lineInfo );
            m_deviceStack.top().busRemap[remapKey] = remapVal;
            return true;
        }
        else if (m_readingMode == ReadingMode::remapIgnored)
        {
            return true;
        }
        else if (m_readingMode == ReadingMode::bus)
        {
            DeviceInfo::BusMap::iterator busIt = m_deviceStack.top().buses.find(m_deviceStack.top().currentBus);
            if (busIt == m_deviceStack.top().buses.end())
                throw umba::FileParsingException( std::string("Unexpected runtime error - bus not found"), lineInfo.getFileName(), lineInfo.getLineNumber() );

            auto busName = busIt->first;
           
            //m_deviceStack.top().currentBus = busName;

            if (lineInfo.isValue("name"))
            {
                busIt->second.name = lineInfo.getValue( umba::Ini::CppNameValidator() );
                return true;
            }
            else if (lineInfo.isValue("display-name"))
            {
                busIt->second.displayName = lineInfo.getValue<std::string>( );
                return true;
            }
            else if (lineInfo.isValue("baudrate"))
            {
                busIt->second.baudrate = lineInfo.getValue<unsigned>();
                return true;
            }
            else if (lineInfo.isValue("protocol"))
            {
                busIt->second.protocolVersion = lineInfo.getValue<umba::NameVersion>();
                return true;
            }
            else if (lineInfo.isValue("rs485"))
            {
                busIt->second.rs485 = lineInfo.getValue<bool>();
                if (busIt->second.rs485 && m_convert485)
                {
                    auto busInfo = busIt->second;
                    if (busInfo.port.linkType==LinkType::uart || busInfo.port.linkType==LinkType::rs485)
                    {
                        // Lets rename bus
                        busInfo.port.linkType = LinkType::rs485;
                        m_deviceStack.top().buses.erase(busIt);
                        m_deviceStack.top().buses[busInfo.port] = busInfo;
                        m_deviceStack.top().currentBus = busInfo.port;
                    }
                    else
                    {
                        throw umba::FileParsingException( std::string("Parameter 'rs485' not allowed for this type of bus"), lineInfo.getFileName(), lineInfo.getLineNumber() );
                    }
                }
                return true;
            }
            else
            {
                throw umba::FileParsingException( std::string("Unknown parameter '") + lineInfo.getName() + std::string("'"), lineInfo.getFileName(), lineInfo.getLineNumber() );
            }
        }
        else
        {
            throw umba::FileParsingException( std::string("Parameters found before any device definition"), lineInfo.getFileName(), lineInfo.getLineNumber() );
        }
    
        return false;
    }

    //----------------
    bool operator()( const umba::Ini::LineInfo &lineInfo ) const
    {
        if (lineInfo.isEmpty() || lineInfo.isComment())
            return true;

        using std::cout;

        auto curLevel = lineInfo.getLevel();

        //if (lineInfo.isSection())
        //    cout<<"Line: "<<lineInfo.getText()<<"\n";


        if (m_flatMode)
        {
            //cout<<"CP01\n";
            if (lineInfo.isSection("device"))
            {
                if (m_deviceStack.empty())
                {
                    //cout<<"CP02\n";
                    // Самое начало документа - встретили описание корневого устройства
                    // Simple put found device to top
                    m_deviceStack.push( DeviceInfo(m_busOrder, lineInfo) );
                    m_readingMode = ReadingMode::device;
                    return true;
                }

                auto currentBus = m_deviceStack.top().currentBus; //  pParentDeviceInfo->currentBus;
                DeviceInfo::BusMap::iterator busIt = m_deviceStack.top().buses.find(currentBus);
                if (busIt == m_deviceStack.top().buses.end())
                    throw umba::FileParsingException( std::string("Unexpected runtime error - bus not found"), lineInfo.getFileName(), lineInfo.getLineNumber() );

                BusInfo &busInfo = busIt->second;
                busInfo.devices.push_back( DeviceInfo(m_busOrder, lineInfo, m_deviceStack.top().currentBus) ); // задаем текущую шину как родительскую

                m_readingMode = ReadingMode::device;

                return true;
            }
            else if (lineInfo.isSection())
            {
                if (m_deviceStack.empty())
                    throw umba::FileParsingException( std::string("Unexpected runtime error - no devices defined at all"), lineInfo.getFileName(), lineInfo.getLineNumber() );

                if (!m_busRemapSectionName.empty() && lineInfo.isSection(m_busRemapSectionName))
                {
                    if (m_deviceStack.size()>1)
                        throw umba::FileParsingException( std::string("Bus remap section found not under root device"), lineInfo.getFileName(), lineInfo.getLineNumber() );
                    m_readingMode = ReadingMode::remap;
                    return true;
                }

                if (lineInfo.nameEndsWith("bus-remap"))
                {
                    if (m_deviceStack.size()>1)
                        throw umba::FileParsingException( std::string("Bus remap section found not under root device"), lineInfo.getFileName(), lineInfo.getLineNumber() );
                    m_readingMode = ReadingMode::remapIgnored;
                    return true;
                }

                std::string secName = lineInfo.getName();
                LinkPort busName = this->linkPortFromString( secName, lineInfo );

                DeviceInfo::BusMap::iterator busIt = m_deviceStack.top().buses.find(busName);
                if (busIt != m_deviceStack.top().buses.end())
                    throw umba::FileParsingException( std::string("Bus '") + secName + std::string("' already defined"), lineInfo.getFileName(), lineInfo.getLineNumber() );

                m_deviceStack.top().currentBus = busName;

                //m_deviceStack.top().buses[]
                m_deviceStack.top().buses[busName] = BusInfo( busName, lineInfo );

                m_readingMode = ReadingMode::bus;
            }
            else if (lineInfo.isValue())
            {
                return parseParameters( lineInfo );
            }
            else
            {
                throw umba::FileParsingException( std::string("Unknown section found -  '") + lineInfo.getName() + std::string("'"), lineInfo.getFileName(), lineInfo.getLineNumber() );
            }
        }


        if (lineInfo.isSection("device"))
        {
            cout<<"CP01\n";

            if (m_deviceStack.empty())
            {
                cout<<"CP02\n";
                // Самое начало документа - встретили описание корневого устройства
                // Simple put found device to top
                m_deviceStack.push( DeviceInfo(m_busOrder, lineInfo) );
                return true;
            }

            cout<<"CP03\n";

            auto currentBus = m_deviceStack.top().currentBus; //  pParentDeviceInfo->currentBus;
            DeviceInfo::BusMap::iterator busIt = m_deviceStack.top().buses.find(currentBus);
            if (busIt == m_deviceStack.top().buses.end())
                throw umba::FileParsingException( std::string("Unexpected runtime error - bus not found"), lineInfo.getFileName(), lineInfo.getLineNumber() );

            BusInfo &busInfo = busIt->second;

            // Here we have a parent device and current bus

            auto busLevel = busInfo.lineInfo.getLevel();
            if (curLevel>=busLevel)
            {
                cout<<"CP04\n";
                // device правее или на уровне шины - он принадлежит шине
                busInfo.devices.push_back( DeviceInfo(m_busOrder, lineInfo, m_deviceStack.top().currentBus) ); // задаем текущую шину как родительскую
            }
            else
            {
                cout<<"CP05\n";
                throw umba::FileParsingException( std::string("Unexpected runtime error - UNDONE"), lineInfo.getFileName(), lineInfo.getLineNumber() );
            }

            cout<<"CP06\n";

            return true;

        }
        // Tree mode parsing
        //UNDONE: flat mode used always!!!
        else if (lineInfo.isSection())
        {
            if (m_deviceStack.empty())
                throw umba::FileParsingException( std::string("Unexpected runtime error - no devices defined at all"), lineInfo.getFileName(), lineInfo.getLineNumber() );


            std::string secName = lineInfo.getName();
            LinkPort linkPort;

            //cout<<"CP08\n";

            try
            {
                linkPort = linkPortFromStringThrown( secName );
            }
            catch( const std::exception &e )
            {
                throw umba::FileParsingException( e.what(), lineInfo.getFileName(), lineInfo.getLineNumber() );
            }
            catch( ... )
            {
                throw umba::FileParsingException( "Unknown error", lineInfo.getFileName(), lineInfo.getLineNumber() );
            }

            //cout<<"CP09\n";


            // у нас нас есть устройство на вершине стека
            DeviceInfo *pDeviceInfo = &m_deviceStack.top();

            auto currentBus = pDeviceInfo->currentBus;

            if (currentBus==LinkPort::getInvalidValue())
            {
                // У устройства на вершине еще нет текущей шины

            }
            else
            {


            }
        
        }

        //return false;
        return true;

    }

    DeviceInfo getRobotDeviceInfo() const
    {
        //return m_deviceInfoRoot;
        if (m_deviceStack.empty())
            throw std::invalid_argument("No device taken in INI");

        while(m_deviceStack.size()>1)
            insertTopToItsParent( umba::Ini::LineInfo(), true /* checkStack */ );

        m_deviceStack.top().buildDeviceMaps();
        m_deviceStack.top().validate(true);
        m_deviceStack.top().loadRegisters( m_importPath );

        return m_deviceStack.top();
    }

protected:

    enum ReadingMode
    {
        initial  ,
        device   ,
        remap    ,
        remapIgnored,
        bus
    };

    LinkTypeSortOrderRemap          m_busOrder;
    bool                            m_flatMode   = false;
    std::string                     m_busRemapSectionName;
    std::string                     m_importPath;
    bool                            m_convert485 = false;

    mutable std::stack<DeviceInfo>  m_deviceStack;
    mutable ReadingMode             m_readingMode = ReadingMode::initial;
    mutable size_t                  m_lastIndent  = 0;
    //mutable std::string             m_currentBusName;

    void insertTopToItsParent( const umba::Ini::LineInfo &lineInfo, bool checkStack ) const
    {
        DeviceInfo prevTop = m_deviceStack.top();
        m_deviceStack.pop();
        // Нужно втащить снятое в родителя
        if (m_deviceStack.empty() && checkStack)
            throw umba::FileParsingException( std::string("Unexpected runtime error - empty stack detected"), lineInfo.getFileName(), lineInfo.getLineNumber() );
        m_deviceStack.top().buses[prevTop.parentBus].devices[prevTop.address] = prevTop; // Нужно проверить - нет ли такого адреса
    }
                    


    
}; // struct RobotIniHandler






} // namespace regs


