#pragma once

#include "umba/string_plus.h"
#include "umba/enum_helpers.h"
#include "umba/exception.h"
#include "umba/ini.h"
#include "umba/name_version.h"
#include "regs/dynamic_reg_table.h"
#include "regs/dynamic_reg_table_cheader_import.h"
#include "regs/print_regs.h"


#include <vector>
#include <set>
#include <exception>
#include <stdexcept>
#include <stack>
#include <iostream>


namespace robot
{


//-----------------------------------------------------------------------------

enum class LinkType
{
    unknown ,  // 0
    uart    ,
    rs485   ,
    can     ,
    total      // Всего значений - 4

};


//--------------------------------------

// "Портит" аргумент
inline
LinkType linkTypeFromStringDestructive( std::string &name )
{
    umba::string_plus::trim(name);
    name = umba::string_plus::toupper_copy(name);
    if (umba::string_plus::starts_with_and_strip( name, "UART" ) || umba::string_plus::starts_with_and_strip( name, "USART" ))
    {
        return LinkType::uart;
    }
    if (umba::string_plus::starts_with_and_strip( name, "RS485#" ) || umba::string_plus::starts_with_and_strip( name, "RS485_" ) || umba::string_plus::starts_with_and_strip( name, "RS485" ))
    {
        return LinkType::rs485;
    }
    else if (umba::string_plus::starts_with_and_strip( name, "CAN" ))
    {
        return LinkType::can;
    }
    else // unknown interface
    {
        return LinkType::unknown; // return invalid value
    }
}

//--------------------------------------

// "Портит" аргумент
inline
LinkType linkTypeFromStringDestructiveThrown( std::string &name )
{
    std::string nameCopy = name;
    auto lt = linkTypeFromStringDestructive(name);
    if (lt==LinkType::unknown)
        throw std::invalid_argument(std::string("Invalid link type value: \'") + nameCopy + std::string("\'") );
    return lt;
}

//--------------------------------------
inline
LinkType linkTypeFromString( std::string name )
{
    return linkTypeFromStringDestructive(name);
}

//--------------------------------------
inline
LinkType linkTypeFromStringThrown( std::string name )
{
    return linkTypeFromStringDestructiveThrown(name);
}

//--------------------------------------
inline
std::string linkTypeToString( LinkType linkType, bool forValidPort )
{
    switch(linkType)
    {
        case LinkType::uart:
             return std::string("UART");

        case LinkType::rs485:
             return forValidPort ? std::string("RS485#") : std::string("RS485");

        case LinkType::can:
             return std::string("CAN");

        //case LinkPort:::
        //     return std::string("") + std::to_string(linkPort.portNumber);

        default:
             return std::string("UNKNOWN");
    }
}

//-----------------------------------------------------------------------------







//-----------------------------------------------------------------------------

struct LinkPort
{
    LinkType    linkType;
    unsigned    portNumber;

    static
    LinkPort getInvalidValue()
    {
        return LinkPort{ LinkType::unknown, 0 };
    }

    int compare( const LinkPort &other ) const
    {
        if ( (unsigned)linkType < (unsigned)other.linkType )
            return -1;
        if ( (unsigned)linkType > (unsigned)other.linkType )
            return  1;

        if ( portNumber < other.portNumber )
            return -1;
        if ( portNumber > other.portNumber )
            return  1;

        return 0;
    }

    bool operator==( LinkPort lpLeft ) const
    {
        return linkType   == lpLeft.linkType
            && portNumber == lpLeft.portNumber ;
    }

    bool operator!=( LinkPort lpLeft ) const
    {
        return linkType   != lpLeft.linkType
            || portNumber != lpLeft.portNumber ;
    }

    bool operator<(LinkPort lpLeft) const
    {
        return compare(lpLeft) < 0;
    }

};

//--------------------------------------
inline
LinkPort linkPortFromStringThrown( std::string name )
{
    LinkPort linkPort = { linkTypeFromStringDestructiveThrown(name), 0 };

    if (linkPort.linkType==LinkType::unknown)
        return linkPort;

    linkPort.portNumber = (unsigned)std::stoul( name, 0, 10 );
    return linkPort;
}

//--------------------------------------
inline
LinkPort linkPortFromString( std::string name )
{
    try
    {
        return linkPortFromStringThrown( name );
    }
    catch(...)
    {
        return LinkPort { LinkType::unknown, 0 }; // годно для определения типа интерфейса, без его номера
                                                  // для полностью определенного интерфейса должен быть задан корректный тип и номер, отличный от нуля
    }
}

//--------------------------------------
inline
std::string linkPortToString( LinkPort linkPort )
{
    std::string res = linkTypeToString( linkPort.linkType, linkPort.portNumber!=0 /* forValidPort */ );

    if (linkPort.portNumber!=0)
    {
        res += std::to_string(linkPort.portNumber);
    }

    return res;

}










// std::vector<EnumType> enumValuesToVector( EnumType eb, EnumType ee, bool inclusiveEnd = false )

struct LinkTypeSortOrderRemap
{

    LinkTypeSortOrderRemap()
    : m_remap()
    {
        initRemap( std::vector<LinkType>{ LinkType::uart, LinkType::rs485, LinkType::can } );
    }

    LinkTypeSortOrderRemap( const LinkTypeSortOrderRemap &remap)
    : m_remap(remap.m_remap)
    {
    }

    LinkTypeSortOrderRemap( const std::vector<LinkType> &order )
    : m_remap()
    {
        initRemap( order );
    }

    LinkTypeSortOrderRemap( const std::vector<std::string> &order )
    : m_remap()
    {
        std::vector<LinkType> linkTypeOrder;
        for( const auto o : order )
        {
            linkTypeOrder.push_back(linkTypeFromStringThrown( o ));
        }
        initRemap( linkTypeOrder );
    }

    size_t operator()( LinkType lt ) const
    {
        size_t idx = (size_t)lt;
        if (idx>=m_remap.size())
            return (size_t)-1;

        return m_remap[idx];
    }

protected:

    void initRemap( std::vector<LinkType> order )
    {
        if (order.size() > (((size_t)LinkType::total))-1)
            throw std::invalid_argument("Too many values for remap (LinkTypeSortOrderRemap)");

        {
            auto allEnumms = umba::enumValuesToVector( LinkType::unknown, LinkType::total, false /* inclusiveEnd */  );
            m_remap.resize( allEnumms.size(), 0 );
            order.insert( order.end(), allEnumms.begin(), allEnumms.end() );
        }

        std::set<LinkType> usedEnums;

        size_t sortOrder = 0;
        for( size_t i=0; i!=order.size(); ++i)
        {
            size_t idx = (size_t)order[sortOrder];
            if (idx>=m_remap.size())
                throw std::invalid_argument("Invalid value for remap (LinkTypeSortOrderRemap)");

            if (usedEnums.find(order[sortOrder])!=usedEnums.end())
                continue;

            usedEnums.insert(order[sortOrder]);
            m_remap[idx] = sortOrder;

            ++sortOrder;
        }

        //m_remap[(size_t)LinkType::unknown] = sortOrder;
    }



    std::vector<unsigned> m_remap;

}; // struct LinkTypeSortOrderRemap



struct LinkTypeLess
{
    LinkTypeLess( const LinkTypeSortOrderRemap &remap )
    : m_remap(remap)
    {}

    LinkTypeLess( const LinkTypeLess &lpl )
    : m_remap(lpl.m_remap)
    {}

    bool operator()( LinkType lt1, LinkType lt2 ) const
    {
        return m_remap(lt1) < m_remap(lt2);
    }

protected:

    LinkTypeSortOrderRemap m_remap;
};



struct LinkPortLess
{
    LinkPortLess(  )
    : m_remap(LinkTypeSortOrderRemap( std::vector<std::string>() ) )
    {}

    LinkPortLess( const LinkTypeSortOrderRemap &remap )
    : m_remap(remap)
    {}

    LinkPortLess( const LinkPortLess &lpl )
    : m_remap(lpl.m_remap)
    {}

    bool operator()( LinkPort lp1, LinkPort lp2 ) const
    {
        size_t s1 = m_remap(lp1.linkType);
        size_t s2 = m_remap(lp2.linkType);

        if (s1<s2) return true;
        if (s1>s2) return false;

        return lp1.portNumber < lp2.portNumber;
    }


protected:

    LinkTypeSortOrderRemap m_remap;
}; // struct LinkPortLess







struct DeviceInfo;

template<typename StreamType>
inline
void printDeviceInfo( StreamType &s, const DeviceInfo deviceInfo, size_t indent );


struct BusInfo
{
    LinkPort                        port;
    bool                            rs485;
    std::string                     name;
	std::string                     displayName;
    unsigned                        baudrate;
    //std::map<unsigned, DeviceInfo>  devices;
    std::vector<DeviceInfo>         devices;
    std::map<unsigned, size_t>      devicesMap; // addr->index, build after all

    umba::Ini::LineInfo             lineInfo;

    umba::NameVersion               protocolVersion;


    // return number of devices
    size_t size()  const { return devices.size(); }
    bool   empty() const { return devices.empty(); }


    BusInfo( )
    : port()
    , rs485(false)
    , name()
    , displayName()
    , baudrate(0)
    , devices()
    , devicesMap()
    , lineInfo()
    {}

    BusInfo( LinkPort lp, const umba::Ini::LineInfo &li )
    : port(lp)
    , rs485(false)
    , name()
    , displayName()
    , baudrate(0)
    , devices()
    , devicesMap()
    , lineInfo(li)
    {}

    void clear()
    {
        port = LinkPort::getInvalidValue(); // LinkPort::invalid_value;
        name.clear();
        displayName.clear();
        baudrate = 0;
        devices.clear();
        devicesMap.clear();
    }

    std::string getBusDisplayName() const
    {
        LinkPort tmp = port;
        if (tmp.linkType==LinkType::rs485)
        {
            tmp.linkType = LinkType::uart;
            return linkPortToString( tmp ) + std::string("/RS485");
        }

        return linkPortToString( tmp );
    }

    std::string getDisplayName() const
    {
        if (displayName.empty())
            return name;
        return displayName;
    }
    
    void validate( bool bRoot ) const;
    void buildDeviceMaps();
    void loadRegisters( const std::string &importPath );


}; // struct BusInfo

template<typename StreamType>
inline
void printBusInfo( StreamType &s, const BusInfo busInfo, bool printRegs, size_t indent )
{
    std::string curIndentStr = std::string( indent+2, ' ' );
    s<<std::string( indent, ' ' )<<"["<<linkPortToString(busInfo.port)<<"]\n";
    s<<curIndentStr<<"name        : "<<busInfo.name<<"\n";
    s<<curIndentStr<<"displayName : "<<busInfo.displayName<<"\n";
    s<<curIndentStr<<"baudrate    : "<<busInfo.baudrate<<"\n";

    if (!busInfo.protocolVersion.name.empty())
    {
        s<<curIndentStr<<"protocol    : "<< busInfo.protocolVersion.name<<" "<< busInfo.protocolVersion.version.majorVersion<<"."<< busInfo.protocolVersion.version.minorVersion<<"\n";
    }

    for( const auto &d : busInfo.devices )
    {
        printDeviceInfo( s, d, printRegs, indent+2 );
    }
}




/* Как сравнивать версии?

   У нас есть описание устройства конкретной версии, и это - основное.
   К устройству могут быть какие-то доп файлы, и нам надо знать, 
   совместимы ли описания в этих файлах с версией устройства.

   Хэш - однозначно определяет конкретную версию, но версии с разными хэшами
   в "интерфейсной" части могут быть идентичными, и, соответственно, совместимыми.

   При изменении устройства (новое оборудование, и тп) - интерфейсная часть скорее всего
   изменится, и это должно быть отражено в строке версии. Строка версии - необязательно
   что-то числовое, там может быть всё что угодно.

   Поэтому сравниваем codename и version.
	   Если у устройства не задана версия (version), то у доп файлов
   версия тоже не нужна

*/

enum class DeviceVersionCompareLevel
{
    dontCheck,
    codenameAllowAny,
    versionAllowAny,  // codename - strict
    strict            // codename - strict, version - strict
};



struct DeviceVersionInfo
{
    std::string    codename;
    std::string    version;
    std::string    versionHash;    // version-hash
    std::string    homeUrl;        // home-url
    std::string    sourceLocation; // source-location

    void clear()
    {
        codename      .clear(); 
        version       .clear();
        versionHash   .clear();
        homeUrl       .clear();
        sourceLocation.clear();
    }


    bool isEqualVersion( const DeviceVersionInfo &other, DeviceVersionCompareLevel versionCompareLevel = DeviceVersionCompareLevel::versionAllowAny ) const
    {
        if (versionCompareLevel==DeviceVersionCompareLevel::dontCheck)
            return true;

        if (codename.empty())
            return true; // кодовое имя не задано, значит - подходит всё

        if ((other.codename.empty() || other.codename=="*") && versionCompareLevel==DeviceVersionCompareLevel::codenameAllowAny)
            return true; // кодовое имя задано, но допустимо любое

        if (codename!=other.codename)
            return false;

        if (version.empty())
            return true; // версия не задана, значит - подходит всё

        if ((other.version.empty() || other.version=="*") && versionCompareLevel==DeviceVersionCompareLevel::versionAllowAny)
            return true; // версия задана, но допустимо любая

        if (version!=other.version)
            return false;

        return true;
    }
/*
    codename     = Warrior18
    version      = Warrior2018
    version-hash = 69adea67492a040587cc35473db37ac1ea2948c2
    home-url         = http://gitblit.dep111.rtc.local/summary/;jsessionid=1ops6pxasgb4pyr6pi6gy72o5?r=Warrior-18/Firmware/Mainboard.git
    source-location       = http://gitblit.dep111.rtc.local/r/Warrior-18/Firmware/Mainboard.git
*/

}; // struct DeviceVersion


struct DeviceInfo
{
    friend struct BusInfo;

    typedef std::map<LinkPort, BusInfo, LinkPortLess >  BusMap;
    typedef std::map<LinkPort, LinkPort >               BusRemap;

    DeviceVersionInfo        versionInfo;

    unsigned                 address;
    std::string              name;
    std::string              displayName;
    std::string              definitionFile;
    std::string              definitionDevice;

    std::string              importPath; // only in root device
                             
    unsigned                 baudrate; // only for root device for main uplink baudrate

    BusMap                   buses;
    BusRemap                 busRemap;

    umba::Ini::LineInfo      lineInfo;

    LinkPort                 uplinkPort; // port in slave device
    LinkPort                 parentBus;  // in parent device
    LinkPort                 currentBus; // in this device

    regs::DynamicRegTable    rwTable;
    regs::DynamicRegTable    roTable;



    DeviceInfo( )
    : versionInfo()
    , address( (unsigned)-1 )
    , name()
    , displayName()
    , definitionFile()
    , definitionDevice()
    , baudrate(0)
    , buses( LinkPortLess() )
    , busRemap()
    , lineInfo()
    , uplinkPort()
    , parentBus()
    , currentBus()
    , rwTable()
    , roTable()
    {}

    DeviceInfo( const LinkTypeSortOrderRemap &busOrder )
    : versionInfo()
    , address( (unsigned)-1 )
    , name()
    , displayName()
    , definitionFile()
    , definitionDevice()
    , baudrate(0)
    , buses( LinkPortLess(busOrder) )
    , busRemap()
    , lineInfo()
    , uplinkPort()
    , parentBus()
    , currentBus()
    , rwTable()
    , roTable()
    {}

    DeviceInfo( const LinkTypeSortOrderRemap &busOrder, const umba::Ini::LineInfo &li, LinkPort pbn = LinkPort::getInvalidValue(), LinkPort cbn = LinkPort::getInvalidValue() )
    : versionInfo()
    , address( (unsigned)-1 )
    , name()
    , displayName()
    , definitionFile()
    , definitionDevice()
    , baudrate(0)
    , buses( LinkPortLess(busOrder) )
    , busRemap()
    , lineInfo(li)
    , uplinkPort()
    , parentBus(pbn)
    , currentBus(cbn)
    , rwTable()
    , roTable()
    {}

    DeviceInfo( const DeviceInfo &di )
    : versionInfo(di.versionInfo)
    , address(di.address)
    , name(di.name)
    , displayName(di.displayName)
    , definitionFile(di.definitionFile)
    , definitionDevice(di.definitionDevice)
    , baudrate(di.baudrate)
    , buses( di.buses )
    , busRemap( di.busRemap )
    , lineInfo( di.lineInfo )
    , uplinkPort(di.uplinkPort)
    , parentBus(di.parentBus)
    , currentBus(di.currentBus)
    , rwTable(di.rwTable)
    , roTable(di.roTable)
    {}

    void clear()
    {
        versionInfo.clear();
        address = (unsigned)-1;
        name.clear();
        displayName.clear();
        definitionFile.clear();
        definitionDevice.clear();
        baudrate = 0;
        buses.clear();
        rwTable.clear();
        roTable.clear();
    }

    std::string getDisplayName() const
    {
        if (displayName.empty())
            return name;
        return displayName;
    }

    void validate( bool bRoot ) const
    {
        if (!bRoot)
        {
            if (address == (unsigned)-1)
                throw umba::FileParsingException( "Device address not defined", lineInfo.getFileName(), lineInfo.getLineNumber() );
        }

        for( auto fs : buses )
        {
            fs.second.validate( false );
        }
    }
    
    void buildDeviceMaps()
    {
        for( auto fs : buses )
        {
            fs.second.buildDeviceMaps();
        }
    }


    void loadRegisters( std::string importPathOverride )
    {
        if (importPathOverride.empty())
            importPathOverride = importPath;
        for( auto &fs : buses )
        {
            fs.second.loadRegisters( importPathOverride );
        }
    }

    
    LinkPort remapBus( LinkPort lp ) const
    {
        if (busRemap.empty()) return lp;

        BusRemap::const_iterator brmIt = busRemap.find(lp);
        if (brmIt == busRemap.end())
            return lp;

        return brmIt->second;
    }

protected:

    void loadRegistersImpl( const std::string &importPathOverride )
    {
        if (definitionFile.empty())
        {
            throw umba::FileParsingException( "Registry definition file - name not taken", lineInfo.getFileName(), lineInfo.getLineNumber() );
        }

        #if defined(WIN32) || defined(_WIN32)
        const char pathSep = '\\';
        #else
        const char pathSep = '/';
        #endif


        std::string configFileName = lineInfo.getFileName();

        // lineInfo.getFileName()

        std::string basePath = importPathOverride;

        if (!basePath.empty() && (basePath.back()=='/' || basePath.back()=='\\'))
            basePath.erase(basePath.size()-1);

        if (umba::string_plus::starts_with( basePath, "." ))
        {
            size_t slashPos = configFileName.find_last_of("/\\");
            if (slashPos!=std::string::npos)
            {
                basePath = std::string( configFileName, 0, slashPos) + std::string(1, pathSep) + basePath;
            }
        }

        if (basePath.empty())
        {
            size_t slashPos = configFileName.find_last_of("/\\");
           
            if (slashPos!=std::string::npos)
            {
                basePath.assign( configFileName, 0, slashPos);
            }
        }

        bool isAbs = false; // also uniz abs path
        if (definitionFile[0]=='\\' || definitionFile[0]=='/')
            isAbs = true;
        #if defined(WIN32) || defined(_WIN32)
        if (!isAbs && definitionFile.size()>1 && definitionFile[1]==':' )
           isAbs = true; // drive letter found
        if (!isAbs && definitionFile.size()>1 && definitionFile[0]=='\\' && definitionFile[1]=='\\')
           isAbs = true; // network or NT name
        #endif

        std::string filenameToOpen;
        if (!isAbs && !basePath.empty())
           filenameToOpen = basePath + std::string(1, pathSep) + definitionFile;
        else
           filenameToOpen = definitionFile;


        size_t slashPos2 = filenameToOpen.find_last_of("/\\");
        size_t dotPos    = filenameToOpen.find_last_of(".");

        std::string ext;

        if (dotPos!=std::string::npos && (slashPos2==std::string::npos || slashPos2<dotPos))
            ext.assign(filenameToOpen, dotPos+1);

        ext = umba::string_plus::toupper_copy(ext);

        if (ext=="H")
        {
            // read C Header file (GReader format)
            if (!regs::import::cheaderSimple( filenameToOpen, rwTable, roTable ))
                throw umba::FileParsingException( std::string("Failed to read registry definition file (Greader H format) - '") + filenameToOpen + std::string("'"), lineInfo.getFileName(), lineInfo.getLineNumber() );

        }
        else
        {
            // RDL?
            throw umba::FileParsingException( std::string("Unsupported registry definition file format - '") + ext + std::string("'"), lineInfo.getFileName(), lineInfo.getLineNumber() );
        }


        //umba::string_plus::tolower_copy(str);

        /* 5x5 - 25 см2      400 шт
           10x10 - 100 см2   100 шт
           15x15 - 225 см2    45 шт
           100x100 = 10000 см2


        
        */



    }


/*
    void validate( bool bRoot ) const
    {
        if (port==LinkPort::getInvalidValue())
            throw umba::FileParsingException( "Invalid bus port", lineInfo.getFileName(), lineInfo.getLineNumber() );

        for( const auto & d : devices )
        {
            d.validate();
        }
    }

    void buildDeviceMaps()
    {
        size_t pos = 0, size = devices.size();
        for(; pos!=size; ++pos)
        {
            if (devicesMap.find(devices[pos].address) != devicesMap.end())
                throw umba::FileParsingException( "Device address already in use", devices[pos].lineInfo.getFileName(), devices[pos].lineInfo.getLineNumber() );
            devicesMap[ devices[pos].address ] = pos;
            devices[pos].buildDeviceMaps();
        }
    }

*/
    


};



inline
void BusInfo::validate( bool bRoot ) const
{
    if (port==LinkPort::getInvalidValue())
        throw umba::FileParsingException( "Invalid bus port", lineInfo.getFileName(), lineInfo.getLineNumber() );

    if (protocolVersion.name.empty())
        throw umba::FileParsingException( "Unknown bus protocol - protocol not taken", lineInfo.getFileName(), lineInfo.getLineNumber() );

    if (port.linkType==LinkType::uart || port.linkType==LinkType::rs485)
    {
        // ganjubus
        if (protocolVersion.compare( "ganjubus", umba::NumericVersion::any() ) != 0 )
            throw umba::FileParsingException( "Taken protocol not compatible with this bus type", lineInfo.getFileName(), lineInfo.getLineNumber() );
    }
    else if (port.linkType==LinkType::can)
    {
        if ( protocolVersion.compare("canabus", umba::NumericVersion{1,0} )==0
          || protocolVersion.compare("canabus", umba::NumericVersion{1,1} )==0 // same as canabus-plus
          || protocolVersion.compare("canabus-plus", umba::NumericVersion::any() )==0 // canabus-plus
          || protocolVersion.compare("ganjubus", umba::NumericVersion{2,0} )==0 // ganjubus/2.0
          || protocolVersion.compare("ganjubus", umba::NumericVersion{2,1} )==0 // ganjubus/2.0
           )
        {
            // Do nothing
        }
        else
        {
            throw umba::FileParsingException( "Taken protocol not compatible with this bus type", lineInfo.getFileName(), lineInfo.getLineNumber() );
        }
    }

    for( const auto & d : devices )
    {
        d.validate(false);
    }
}

inline
void BusInfo::buildDeviceMaps()
{
    size_t pos = 0, size = devices.size();
    for(; pos!=size; ++pos)
    {
        if (devicesMap.find(devices[pos].address) != devicesMap.end())
            throw umba::FileParsingException( "Device address already in use", devices[pos].lineInfo.getFileName(), devices[pos].lineInfo.getLineNumber() );
        devicesMap[ devices[pos].address ] = pos;
        devices[pos].buildDeviceMaps();
    }
}

inline
void BusInfo::loadRegisters( const std::string &importPath  )
{
    for( auto & d : devices )
    {
        d.loadRegistersImpl( importPath );
    }
}



template<typename StreamType>
inline
void printDeviceInfo( StreamType &s, const DeviceInfo &deviceInfo, bool printRegs, size_t indent = 0, bool recursivePrint = true )
{
    // StreamType - на самом деле может быть только umba::SimpleFormatter, 
    // просто лень было подключать тут еще и ту либу, и выписывать конкретный тип.
    // 

    using namespace umba::omanip;

    std::string curIndentStr = std::string( indent+2, ' ' );
    s<<std::string( indent, ' ' )<<"[device]\n";

    if (!deviceInfo.versionInfo.codename.empty())
        s<<curIndentStr<<"codename         : "<<deviceInfo.versionInfo.codename<<"\n";
    if (!deviceInfo.versionInfo.version.empty())
        s<<curIndentStr<<"version          : "<<deviceInfo.versionInfo.version<<"\n";
    if (!deviceInfo.versionInfo.versionHash.empty())
        s<<curIndentStr<<"version-hash     : "<<deviceInfo.versionInfo.versionHash<<"\n";
    if (!deviceInfo.versionInfo.homeUrl.empty())
        s<<curIndentStr<<"home-url         : "<<deviceInfo.versionInfo.homeUrl<<"\n";
    if (!deviceInfo.versionInfo.sourceLocation.empty())
        s<<curIndentStr<<"source-location  : "<<deviceInfo.versionInfo.sourceLocation<<"\n";

    s<<curIndentStr<<"address          : "<<hex<<(uint8_t)deviceInfo.address<<"\n";
    s<<curIndentStr<<"name             : "<<deviceInfo.name<<"\n";
    s<<curIndentStr<<"displayName      : "<<deviceInfo.displayName<<"\n";
    if (!deviceInfo.definitionFile.empty())
        s<<curIndentStr<<"definitionFile   : "<<deviceInfo.definitionFile<<"\n";
    if (!deviceInfo.definitionDevice.empty())
        s<<curIndentStr<<"definitionDevice : "<<deviceInfo.definitionDevice<<"\n";
    //if (deviceInfo.parentBus!=LinkPort::getInvalidValue())
    if (deviceInfo.uplinkPort!=LinkPort::getInvalidValue())
        s<<curIndentStr<<"uplink-port      : "<<linkPortToString(deviceInfo.uplinkPort)<<"\n";
    if (deviceInfo.baudrate)
        s<<curIndentStr<<"baudrate         : "<<deviceInfo.baudrate<<"\n";

    if (printRegs)
    {
        s<<curIndentStr<<"  RW Regs:\n";
        regs::printRegs( s, (regs::IRegTableForUiEx*)&deviceInfo.rwTable, false /* true */ , curIndentStr + "    " );
        s<<curIndentStr<<"  RO Regs:\n";
        regs::printRegs( s, (regs::IRegTableForUiEx*)&deviceInfo.roTable, false /* true */ , curIndentStr + "    " );
    }

    if (!recursivePrint)
        return;

    for( const auto &bp : deviceInfo.buses )
    {
        printBusInfo( s, bp.second, printRegs, indent+4 );
    }
}

/*

struct DeviceInfo
{
    typedef std::map<LinkPort, BusInfo, LinkPortLess >  BusMap;

    unsigned                 address;
    std::string              name;
    std::string              displayName;
    std::string              definitionFile;
    std::string              definitionDevice;
                             
    unsigned                 baudrate; // only for root device for main uplink baudrate

    BusMap                   buses;

    umba::Ini::LineInfo      lineInfo;

    LinkPort                 parentBus;  // in parent device
    LinkPort                 currentBus; // in this device


inline
void parseDeviceInfo( DeviceInfo & deviceInfo, const umba::Ini &ini, const LinkTypeSortOrderRemap &busOrder )
{

}

inline
void parseBusInfo( BusInfo & busInfo, const umba::Ini &ini, const LinkTypeSortOrderRemap &busOrder )
{

}

inline
DeviceInfo parseDeviceIni( const umba::Ini &ini, const LinkTypeSortOrderRemap &busOrder )
{

}
*/

struct AddressValidatorBase
{

    AddressValidatorBase( const char *validatorName, unsigned mn, unsigned mx )
    : m_validatorName(validatorName)
    , m_min(mn)
    , m_max(mx)
    {}

    unsigned operator()( const umba::Ini::LineInfo &lineInfo, unsigned value ) const
    {
        return validate(lineInfo, value, m_validatorName);
    }

protected:

    void doThrow( const umba::Ini::LineInfo &lineInfo, const std::string &validatorName ) const
    {
        throw umba::FileParsingException( std::string("Address value '") 
                                        + lineInfo.getValue<std::string>() + std::string("' in parameter '") 
                                        + lineInfo.getName() + std::string("' is not in valid range - valid ") 
                                        + validatorName + std::string(" required")
                                        , lineInfo.getFileName()
                                        , lineInfo.getLineNumber()
                                        );
    }

    unsigned validate(const umba::Ini::LineInfo &lineInfo, unsigned value, const std::string &validatorName) const
    {
        if ( value>=m_min && value<=m_max )
            return value;
        doThrow( lineInfo, validatorName );
        return 0;
    }

    const char *m_validatorName = "UnsignedValidator";
    unsigned m_min = 0;
    unsigned m_max = 0;

}; // struct AddressValidatorBase


struct CanabusAddressValidator : AddressValidatorBase
{
    // Адреса 62 и 63 зарезервированы и не могут быть использованы.
    // Адрес 0 соответствует широковещательной передаче
    // Адрес 61 используется ведущим при обращении к любому устройству в шине
    CanabusAddressValidator()
    : AddressValidatorBase( "Canabus Address", 1u, 60u )
    {}
};


struct GanjubusAddressValidator : AddressValidatorBase
{
    // Адрес 0 соответствует широковещательной передаче
    // Адрес 255 используется ведущим при обращении к любому устройству в шине, вне зависимости от его адреса

    GanjubusAddressValidator()
    : AddressValidatorBase( "Ganjubus Address", 1u, 254u )
    {}
};


// CanabusAddressValidator
// GanjubusAddressValidator



} // namespace regs


