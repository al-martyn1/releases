/*! \file
\brief Реализация 
*/

#pragma once

#include "../stream_protocol_impl_base.h"
#include "../packet_composer_impl_base.h"
#include "../packet_parser_impl_base.h"
#include "umba/time_service.h"
#include "umba/parse_utils.h"



namespace umba
{
namespace protocols
{


template <size_t BufSize>
struct GolemPacketComposer : public PacketComposerImplBase<BufSize>
{
/*
    typedef PacketComposerImplBase<BufSize>    BaseComposer;

    UMBA_BEGIN_INTERFACE_MAP_EX( BaseComposer )
         UMBA_IMPLEMENT_INTERFACE( IPacketComposer )
    UMBA_END_INTERFACE_MAP()
*/

    virtual
    StreamSize composeTo( const StreamOctetType * pkt, StreamSize pktSize, StreamOctetType * buf, StreamSize bufSize, const AddressInfo *pAddressInfo ) override
    {
        StreamSize minSize = std::min(pktSize, bufSize);
        memcpy( buf, pkt, minSize );

        if ( (pktSize+1) < bufSize )
            buf[pktSize]   = 0x0D;
        if ( (pktSize+2) < bufSize )
            buf[pktSize+1] = 0x0A;
        return pktSize+2;
    }

}; // struct GolemPacketComposer



template<size_t BufSize>
struct GolemPacketParser : public PacketParserImplBase<BufSize>
{
    typedef PacketParserImplBase<BufSize> BaseImpl;
/*
    typedef PacketParserImplBase<BufSize>     BaseParser;

    UMBA_BEGIN_INTERFACE_MAP_EX( BaseParser )
         UMBA_IMPLEMENT_INTERFACE( IPacketParser )
         UMBA_IMPLEMENT_INTERFACE( umba::ICompletionHandler )
    UMBA_END_INTERFACE_MAP()
*/

    virtual
    void receiveData( StreamOctetType *pData, StreamSize dataLen ) override
    {
        for( StreamSize i = 0; i!=dataLen; ++i )
           receiveOctet( pData[i] );
    }

    virtual
    void reset() override
    {
        m_dataLen = 0;
        m_receiveLineState = receiveLineStart;
    }

    virtual
    void onComplete( unsigned customEventId //!< Some user defined code
                   ) override
    {
        if (customEventId==(unsigned)CompletionEvents::receiveCompleted)
        {
            // each packet ends with line "* " - skip it
            if (m_dataLen==2 && m_buf[0]==0x2A && m_buf[1]==0x20)
            {
                m_dataLen = 0;
                m_receiveLineState = receiveLineStart;
            }

        }
    }

protected:

    using BaseImpl::m_dataLen;
    using BaseImpl::m_buf;
    using BaseImpl::putOctet;
    using BaseImpl::isBufferOverflowed;
    using BaseImpl::getFirstFreeOctet;
    using BaseImpl::callHandler;
    
    //using BaseImpl::*;
    
    
    void receiveOctet( StreamOctetType o )
    {
        if (m_receiveLineState==receiveLineStart)
        {
             if (umba::parse_utils::isWhitespace( o ))
                 return;
             m_dataLen = 0;
             putOctet( o );
             //recvBuf[0] = o;
             //recvCount  = 1;
             m_receiveLineState = receiveLineNext;
        }
        else
        {
            if ( o == 0x0D )
            {
                //processRecvBuf();
                size_t bytesToSkip = 0;
                while( bytesToSkip < m_dataLen && (m_buf[bytesToSkip]=='*' || m_buf[bytesToSkip]==' ' || m_buf[bytesToSkip]=='\r' || m_buf[bytesToSkip]=='\n') )
                     ++bytesToSkip;

                if (bytesToSkip>0)
                {
                    size_t bytesRemain = m_dataLen - bytesToSkip;
                    if (bytesRemain)
                    {
                        memmove( &m_buf[0], &m_buf[bytesToSkip], bytesRemain );
                        m_dataLen = bytesRemain;
                    }
                    else
                    {
                        m_dataLen = 0;
                    }
                }

                if (m_dataLen)
                {
                    * getFirstFreeOctet() = 0; // we warrantee that buffer is zero terminated
                    callHandler();
                }
                //m_buf, m_dataLen
                //recvCount = 0;
                m_dataLen = 0;
                m_receiveLineState = receiveLineStart;
            }
            else
            {
                //if (m_dataLen>=UMBA_COUNT_OF(m_buf))
                if (isBufferOverflowed())
                {
                    return;
                }
                else
                {
                    //recvBuf[recvCount++] = o;
                    putOctet( o );
                }
            }
        }
    }

    enum ReceiveLineState
    {
        receiveLineStart,
        receiveLineNext
    };

    ReceiveLineState  m_receiveLineState = receiveLineStart;


}; // struct GolemPacketParser




struct GolemProtocolImplBase : public umba::protocols::IStreamProtocolImplBase< umba::protocols::IStreamProtocol >
{
    typedef umba::protocols::IStreamProtocolImplBase< umba::protocols::IStreamProtocol > BaseProtocol;

    using umba::protocols::IStreamProtocolImplBase< umba::protocols::IStreamProtocol >::sendPacket;

    virtual
    umba::Error sendPacket( const StreamOctetType *pkt, StreamSize pktSize, const AddressInfo *pAddressInfo ) override
    {
        if (pkt && pktSize)
            m_lastCommand = *pkt;

        auto res = m_pComposer->compose(pkt, pktSize, pAddressInfo);

        m_state = MachineState::commandPause;

        m_lastCommandTick = umba::time_service::getCurTimeMs();

        return res;
    }


    virtual
    void poll() override
    {
        BaseProtocol::poll();
    }

    virtual
    bool isReadyForPoll() override
    {
        //return true;
        // в состоянии ожидания можем принимать данные
        // не можем принимать данные, когда держим паузу после отсылки команды
        // Это нужно, чтобы накопить данных в COM-порту.
        // Тогда мы начинаем их вычитывать, и когда данные заканчиваются
        // мы понимаем, что пакет от голого закончился
        if (m_state == MachineState::commandPause)
        {
            if ( isGolemReadReplyDelayElapsed() )
            {
                m_state = MachineState::receivingReply;
            }
            else
            {
                return false;
            }
        }

        //if ( canSendCommand() && isDatalinkHalfTimedout( ) )
        
        return true;
    }

    virtual
    bool isReadyForPing() override
    {
        if (!canSendCommand())
            return false;

        if (getTickElapsedFromLastCommand() < m_pingPeriod)
            return false;

        return true;
        //return canSendCommand();

        //umba::time_service::TimeTick  m_pingPeriod = 0;
    }


    //void resetParser() override

    virtual
    void reset() override
    {
        BaseProtocol::reset();
        m_state = MachineState::idling;
        clearLastSentCommand(); // m_lastCommand = 0; // no command
    }

    // !!! А нафуа?
    bool isIdle() const
    {
        return m_state == MachineState::idling;
    }

    virtual
    bool canSend() override
    {
        return canSendCommand();
    }

    bool canSendCommand() const
    {
        return m_state == MachineState::idling;
    }

    umba::time_service::TimeTick setGolemReadReplyDelayPeriod( umba::time_service::TimeTick p )
    {
        std::swap( m_golemReadReplyDelayPeriod, p );
        return p;
    }

    umba::time_service::TimeTick getGolemReadReplyDelayPeriod( ) const
    {
        return m_golemReadReplyDelayPeriod;
    }

    char getLastSentCommand() const
    {
        return m_lastCommand;
    }

    void clearLastSentCommand()
    {
        m_lastCommand = 0;
    }

private:

    virtual
    void onPing( ) override
    {
        // ничего не делаем, так как это только протокол обмена, о самих пакетах знает только конкретный тип голема
    }

    virtual
    void handleParsedPacket( const BaseProtocol::StreamOctetType *pkt, BaseProtocol::StreamSize pktSize, const AddressInfo *pAddressInfo ) override
    {
        StreamOctetType res = parseGolemPacket( pkt, pktSize );

        // Пришел валидный пакет
        if (res)
        {
           updateDatalinkStamp(); // пора обновить счетчик таймаута данных
        }

        // clearLastSentCommand(); а вот это сами плс в обработчике
    }

    virtual
    void onComplete( unsigned customEventId ) override
    {
        BaseProtocol::onComplete(customEventId);
        if (customEventId==(unsigned)CompletionEvents::receiveCompleted)
        {
            m_state = MachineState::idling;
            clearLastSentCommand(); // m_lastCommand = 0; // no command
        }
        else if (customEventId==(unsigned)CompletionEvents::receiveStarted)
        {
            if (m_state==MachineState::idling)
                m_state = MachineState::receivingReply;
        }
    }

    umba::time_service::TimeTick getTickElapsedFromLastCommand() const
    {
        return umba::time_service::getCurTimeMs() - m_lastCommandTick;
    }

    bool isGolemReadReplyDelayElapsed() const
    {
        return m_golemReadReplyDelayPeriod < getTickElapsedFromLastCommand();
    }



    //! Разбор пакета от голого
    /*! Должен возвращать код команды - C/D/F/I/K/M/P/R/S/T/W/
     */
    virtual
    StreamOctetType parseGolemPacket( const BaseProtocol::StreamOctetType *pkt, BaseProtocol::StreamSize pktSize ) = 0;

    enum class MachineState
    {
        idling,
        commandPause,
        receivingReply
    };

    MachineState                  m_state       = MachineState::idling;
    StreamOctetType               m_lastCommand = 0; // no command

    umba::time_service::TimeTick  m_lastCommandTick = 0;
    umba::time_service::TimeTick  m_golemReadReplyDelayPeriod = 100;


// 0 - Сидим ждем, парсим приходящее. 
//     Из приходящего может придти стартовое сообщение, если Голем вдруг ресетнулся.
//     Больше ничего он самопроизвольно не отсылает
// 1 Отправляем команду
// 2 Ждем 100 мс
// 3 Начинаем прием
// ...
//   Профит! Гото 


}; // struct GolemProtocolImplBase


/*
GOLEM V1A
Commands:
C[<nn>]        - [Set] or read DU channel number, <nn>-number of channel
D<n>           - Display debug information, <n> - 0-off,1-Status,2-Status+Error
F[<xxxxxxxxxx>]- [Set] or read frequency of video transmitter,
                 <xxxxxxxxxx>-frequency in hertz (102000000..123000000)
I              - Display psramemers
K[<b>]         - [Set] or read camera keys, <b> 0-All keys release U-Up Press D-Down press
                 L-Left press R-Right press S-Set press
L<k3><k2><k1><k0> - Set scrambler key
M[<z>]         - [Set] or scrembler mode, <z> 0-off 1-on
P[<yyy>]       - [Set] or read power of video transmitter, <yyy>-power level (0..255)
R              - Reset
S              - Display status information
T              - Get volage and temperatures
V[<z>]         - [Set] or read video transmitter mode, <z> 0-off 1-on
W              - write settings in to flash memory
*
*/


// R reply and on start message
//GOLEM V1A (C) SET-1 2015-2018
//* Init SLAVE
//Channel00 [0]
//Calibrate [0]
//Start

//C00
//C01 [0]
//P100

// T
// Vinp= 4.962 V12=12.025 T=40

// V, V0, V1
// VideoTransmitter - ON
// VideoTransmitter - OFF

// F, FXXXXXXXXXXX
// F1230000000 - on simple query
// F1150000000 Hz - on set command

// S
// Disconnected
/*
    const uint8_t disconnected_str[] = "Disconnected";
    const uint8_t disconnected_str_len = 12;
    const uint8_t rssi_str[] = "RSSI L";
    const uint8_t rssi_str_len = 6;
    const uint8_t lqi_str[] = "LQI ";
    const uint8_t lqi_str_len = 4;
*/
// P=ххх RSSI L=-хх R=-хх LQI L=хх R=хх
// I
// C00
// F1230000000
// P100
// VideoTransmitter - ON
// Scrambler - OFF

// L, LXXXX, M, M0, M1
// Scrambler - ON
// Scrambler - OFF

// W
//   Settint is writed
// *




} // namespace protocols
} // namespace umba
