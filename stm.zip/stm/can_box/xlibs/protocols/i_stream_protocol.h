/*! \file
\brief Интерфейс
*/

#pragma once

#include "umba/basic_interfaces.h"

#include "i_packet_composer.h"
#include "i_packet_parser.h"

#include "umba/time_service.h"




namespace umba
{
namespace protocols
{



//! Обобщенный интерфейс потокового протокола 
interface IStreamProtocol : inherits umba::IUnknown 
                          //, public umba::IPollCapable
                          //, public umba::ICompletionHandler
                          //, protected IComposedPacketHandler
                          //, protected IParsedPacketHandler
{

    UMBA_DECLARE_INTERFACE_ID(0xC91E9618);

    typedef umba::ihc::StreamSize       StreamSize;
    typedef umba::ihc::StreamDiff       StreamDiff;
    typedef umba::ihc::StreamOctetType  StreamOctetType;
   
    const StreamSize StreamSizeNPos = umba::ihc::StreamSizeNPos;

    //! Устанавливает режим "владельца" для обработчиков
    /*! В режиме владельца объект протокола удаляет все объекты, 
        которые добавлены - потокии, хэндлеры, и тп
     */
    virtual
    bool setOwnerMode( bool ownerMode ) = 0;


    //! Устанавливает поток данных
    virtual
    umba::ihc::IOctetIOStream* setStream(umba::ihc::IOctetIOStream *pStream) = 0;

    //! Возвращает ранее установленный канальный поток
    virtual
    umba::ihc::IOctetIOStream* getStream() = 0;


    //! Устанавливает собирателя пакетов
    virtual
    IPacketComposer* setPacketComposer(IPacketComposer *pComposer) = 0;

    //! Возвращает ранее установленный собиратель пакетов
    virtual
    IPacketComposer* getPacketComposer() = 0;

    //! Устанавливает разбирателя пакетов
    virtual
    IPacketParser* setPacketParser(IPacketParser *pParser) = 0;

    //! Возвращает ранее установленный разбиратель пакетов
    virtual
    IPacketParser* getPacketParser() = 0;


    //! Принимает данные из буфера. Не вызывает onRawReceived
    virtual
    void receiveData( StreamOctetType *pData, StreamSize dataLen ) = 0;

    //! Принимает данные из установленного потока
    /*! Принимает данные из установленного потока и возвращает 
        количество принятых октетов.
     */
    virtual
    umba::Result<StreamSize> receive( ) = 0;

    //! Формирует канальный пакет и отправляет его
    virtual
    umba::Error sendPacket( const StreamOctetType *pkt, StreamSize pktSize, const AddressInfo *pAddressInfo ) = 0;

    virtual
    umba::Error sendPacket( const StreamOctetType *pkt, StreamSize pktSize ) = 0;

    virtual
    bool canSend() = 0;

    //! Сброс - установка состояния парсера в начальное
    virtual
    void resetParser() = 0;

    //! Полный сброс протокола
    virtual
    void reset() = 0;

    //! Задает фиксированный момент времени (фиксирует метку времени)
    /*! Если не задано, то используется текущее время.
        Следует использовать при "воспроизведении" записанных с временными метками данных
     */
    virtual 
    void setFixedTimestamp( umba::time_service::TimeTick timestamp ) = 0;

    // Сбрасывает фиксацию метки времени
    virtual 
    void resetFixedTimestamp( ) = 0;

    virtual 
    umba::time_service::TimeTick getTimestamp( ) = 0;

    //! Сохраняет указатель на AddressTraits
    /*! AddressTraits - должен быть глобальный/статический объект, или динамический объект,
        время жизни которого гарантированно дольше времени жизни объекта протокола.
     */
    virtual
    void setAddressTraits( const AddressTraits *pAddressTraits) = 0;

    //! Возвращает сохраненный указатель на AddressTraits
    virtual
    const AddressTraits* getAddressTraits() = 0;

    //! Устанавливает собственный адрес
    /*! Собственный адрес используется, когда в метод makeWellKnownAddress
        передается WellKnownAddress::self.
        Данный метод копирует адрес

     */
    virtual
    umba::Error setSelfAddress( const AddressInfo ai ) = 0;

    virtual
    umba::Result<AddressInfo> getSelfAddress( ) = 0;


    //! Заполняет pAddrBuf указанным хорошоизвестным адресом и возвращает AddressInfo.
    /*! Длины буфера должно гарантированно хватать.
        Если pAddrBuf==0, возвращает umba::errors::invalid_param.
        Если AddressTraits не задан для протокола, возвращает umba::errors::invalid_prerequisites
        Если хорошоизвестный адрес не поддерживается, возвращает umba::errors::wellknown_addr_not_supported

        Мастер/клиент обычно отправляет на адрес слейва/сервера, или на один из хорошоизвестных адресов.
        При отправке слейвы/сервера обычно отправляют свой адрес. 
        В случае слейва/сервера должно быть достаточно только вызова данной функции.
     */
    virtual
    umba::Result<AddressInfo> makeWellKnownAddress( WellKnownAddress wka, void *pAddrBuf ) = 0;

    //! Производит проверку валидности адреса.
    /*! Если в качестве адреса передан нулевой указатель, такой адрес будет считаться валидным.
        Протоколы, которые требуют обязательного наличия адреса, должны переопределять данные метод.
        Проверки производятся по заданным AddressTraits. Если AddressTraits не заданы, то 
        будет возвращено umba::errors::invalid_prerequisites
     */
    virtual
    umba::Error isAddressValid( const AddressInfo *pAddressInfo) = 0;


}; // interface IStreamProtocol



//! Used for bus streams
interface IStreamMultiAddrProtocol : public IStreamProtocol
{

    UMBA_DECLARE_INTERFACE_ID(0x9C3C541C);

    virtual 
    unsigned getAddrFrom( ) = 0;

    virtual 
    bool setAddrTo( unsigned addr ) = 0; // return false if addr is invalid for protocol bus

    virtual 
    unsigned getAddrTo( ) = 0;

};




} // namespace protocols
} // namespace umba











