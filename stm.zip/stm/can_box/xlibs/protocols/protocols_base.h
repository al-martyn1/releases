/*! \file
\brief Реализация 
*/

#pragma once

#include <cstring>


#include "umba/umba.h"
#include "umba/errors.h"
#include "umba/basic_interfaces.h"
#include "ihc/i_octet_stream.h"

namespace umba
{
namespace protocols
{

typedef umba::ihc::StreamSize       StreamSize;
typedef umba::ihc::StreamDiff       StreamDiff;
typedef umba::ihc::StreamOctetType  StreamOctetType;

const StreamSize StreamSizeNPos = umba::ihc::StreamSizeNPos;


enum class CompletionEvents
{
    receiveStarted,
    receiveCompleted
};




#include "umba/pushpack1.h"
struct GenericPeerAddress
{
    uint8_t    address[32];
};
#include "umba/packpop.h"


#include "umba/pushpack1.h"
struct IpAddressV4
{
    uint32_t   address;
    uint16_t   port;
};
#include "umba/packpop.h"

#include "umba/pushpack1.h"
struct IpAddressV6
{
    uint8_t    address[16];
    uint16_t   port;
};
#include "umba/packpop.h"


struct AddressInfo
{
    size_t               addressSize;
    GenericPeerAddress  *pAddress;

    int compare( const AddressInfo &other ) const
    {
        if (!addressSize && !other.addressSize)
           return 0; // eq

        if (addressSize!=other.addressSize)
           return addressSize < other.addressSize ? -1 : 1;

        if (!pAddress || !other.pAddress)
           return 0; // eq

        return std::memcmp( (void*)pAddress, (void*)other.pAddress, addressSize );
    }

    // buf size must be enough
    void copyToBuf( void* pBuf ) const
    {
        UMBA_ASSERT(pBuf);
        if ( pBuf==(void*)pAddress )
            return; // dont need to copy

        std::memcpy( pBuf, (void*)pAddress, addressSize );
    }

};


struct AddressTraits
{
    size_t                 addressSize        = 0;
    GenericPeerAddress     *pAddressRangeMin  = 0;
    GenericPeerAddress     *pAddressRangeMax  = 0;
    GenericPeerAddress     *pAddressBroadcast = 0;
    GenericPeerAddress     *pAddressAnycast   = 0;
};

enum class WellKnownAddress
{
    broadcast,
    anycast,
    range_first,
    range_last,
    self
};



} // namespace protocols
} // namespace umba



