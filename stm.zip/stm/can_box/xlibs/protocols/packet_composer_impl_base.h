/*! \file
\brief Реализация 
*/

#pragma once

#include "i_packet_composer.h"

#include <utility>


namespace umba
{
namespace protocols
{


//! Базовая реализация композитора пакетов
template <size_t BufSize>
struct PacketComposerImplBase : implements IPacketComposer // : inherits IUnknown
{

    UMBA_BEGIN_INTERFACE_MAP( )
         UMBA_IMPLEMENT_INTERFACE( IPacketComposer )
    UMBA_END_INTERFACE_MAP()

    virtual
    IComposedPacketHandler* setHandler( IComposedPacketHandler *pktHandler ) override
    {
        std::swap(pktHandler, m_pHandler);
        return pktHandler;
    }

    virtual
    IComposedPacketHandler* getHandler( ) override
    {
        return m_pHandler;
    }

    virtual
    umba::Error compose( const StreamOctetType * pkt, StreamSize pktSize, const AddressInfo *pAddressInfo ) override
    {
        UMBA_ASSERT(m_pHandler);

        StreamSize composedSize = composeTo( pkt, pktSize, m_buf, BufSize, pAddressInfo );
        if (composedSize<BufSize)
        {
            return m_pHandler->handleComposedPacket( m_buf, composedSize, pAddressInfo );
        }
        else
        {
            return m_pHandler->handleComposeError( m_buf, composedSize, umba::errors::too_much, pAddressInfo );
            //return umba::errors::too_much;
        }
    }


protected:

    IComposedPacketHandler *m_pHandler = 0;

    StreamOctetType         m_buf[BufSize];


}; // interface IPacketComposer


} // namespace protocols
} // namespace umba


