/*! \file
\brief Реализация 
*/

#pragma once

#include "i_packet_parser.h"

#include <utility>


namespace umba
{
namespace protocols
{

//! Базовая реализация разборщика пакетов
template<size_t BufSize>
struct PacketParserImplBase : implements IPacketParser, implements umba::ICompletionHandler
{

    UMBA_BEGIN_INTERFACE_MAP_EX( IPacketParser )
         //UMBA_IMPLEMENT_INTERFACE( IPacketParser )
         UMBA_IMPLEMENT_INTERFACE( umba::ICompletionHandler )
    UMBA_END_INTERFACE_MAP()

    virtual
    IParsedPacketHandler* setHandler( IParsedPacketHandler *pktHandler ) override
    {
        std::swap(pktHandler, m_pHandler);
        return pktHandler;
    }

    virtual
    IParsedPacketHandler* getHandler( ) override
    {
        return m_pHandler;
    }


protected:

    void putOctet( StreamOctetType octet )
    {
        if (m_dataLen<BufSize)
           m_buf[m_dataLen] = octet;
        m_dataLen++;
    }

    bool isBufferOverflowed()
    {
        return m_dataLen >= BufSize;
    }

    // in some cases we need to make buffered string ASCII-zeroed
    // If we have buffer filled full, it make cause that last byte will be corrupted
    StreamOctetType* getFirstFreeOctet()
    {
        if (m_dataLen >= BufSize)
            return &m_buf[BufSize-1]; // cause a buffer corruption
        else
            return &m_buf[m_dataLen];
    }

    void notifyError( umba::Error err, const AddressInfo *pAddressInfo = 0 )
    {
        UMBA_ASSERT(m_pHandler);
        m_pHandler->handleParseError( m_buf, m_dataLen, err, pAddressInfo );
    }

    void notifyOutOfSync( )
    {
        notifyError(umba::errors::out_of_sync);
    }

    void notifyCrcError( bool headerError = false, const AddressInfo *pAddressInfo = 0 )
    {
        notifyError( headerError ? umba::errors::header_crc_error : umba::errors::crc_error, pAddressInfo );
    }

    void notifyInvalidHeader()
    {
        notifyError(umba::errors::invalid_protocol_headeer);
    }

    void callHandler( const AddressInfo *pAddressInfo = 0 )
    {
        UMBA_ASSERT(m_pHandler);
        if (isBufferOverflowed())
            notifyError(umba::errors::too_much_data);
        else
            m_pHandler->handleParsedPacket( m_buf, m_dataLen, pAddressInfo );
    }


    IParsedPacketHandler *m_pHandler = 0;

    StreamOctetType       m_buf[BufSize];
    StreamSize            m_dataLen = 0;

}; // interface PacketParserImplBase


} // namespace protocols
} // namespace umba


