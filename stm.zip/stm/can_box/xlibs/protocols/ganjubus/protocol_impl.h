#pragma once

#include "protocol_impl_base.h"

namespace umba {
namespace protocols {
namespace ganjubus {

typedef ProtocolImplBase   ProtocolImpl;

typedef PacketParserBase<256> PacketParser;


} // namespace ganjubus
} // namespace protocols
} // namespace umba
