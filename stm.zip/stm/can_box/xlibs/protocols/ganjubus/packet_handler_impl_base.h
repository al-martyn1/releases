#pragma once

namespace umba {
namespace protocols {
namespace ganjubus {


interface IPacketHandlerImplBase : inherits IPacketHandler
{

    //UMBA_BEGIN_INTERFACE_MAP_EX( IPacketHandler )
         //UMBA_IMPLEMENT_INTERFACE( BaseProtocol )
    //UMBA_END_INTERFACE_MAP()

    UMBA_BEGIN_INTERFACE_MAP( )
         UMBA_IMPLEMENT_INTERFACE( IPacketHandler )
    UMBA_END_INTERFACE_MAP()

    UMBA_IMPLEMENT_QUERY_INTERFACE()

//    virtual
//    void parseGanjubusPacket( const Packet *pkt, const AddressInfo *pPeerAddr ) = 0;

};



} // namespace ganjubus
} // namespace protocols
} // namespace umba
