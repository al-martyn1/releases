/*! \file
\brief Реализация 
*/

#pragma once

#include "../stream_protocol_impl_base.h"
#include "../packet_composer_impl_base.h"
#include "../packet_parser_impl_base.h"
#include "umba/time_service.h"
#include "umba/parse_utils.h"
#include "umba/alloca.h"

#include "scrypto/crc.h"

#include "protocol_defs.h"
#include "i_packet_handler.h"


namespace umba {
namespace protocols {
namespace ganjubus {


template<size_t BufSize>
struct PacketParserBase : public PacketParserImplBase<BufSize>
{
    typedef PacketParserImplBase<BufSize> BaseImpl;


    /*
        typedef PacketParserImplBase<BufSize>     BaseParser;
    
        UMBA_BEGIN_INTERFACE_MAP_EX( BaseParser )
             UMBA_IMPLEMENT_INTERFACE( IPacketParser )
             UMBA_IMPLEMENT_INTERFACE( umba::ICompletionHandler )
        UMBA_END_INTERFACE_MAP()
    */

    virtual
    void receiveData( StreamOctetType *pData, StreamSize dataLen ) override
    {
        for( StreamSize i = 0; i!=dataLen; ++i )
           receiveOctet( pData[i] );
    }

    virtual
    void reset() override
    {
        m_dataLen = 0;
        //m_receiveLineState = receiveLineStart;
        m_parsedPacketHeader.version = m_parsedPacketHeader.version.any(); // same as inavalid
        m_headerSize            = 0; // 0 - invalid, 4/5 - valid
        m_scanMode              = false;
        m_state                 = State::RECV_HEADER1;
    }

    virtual
    void onComplete( unsigned customEventId //!< Some user defined code
                   ) override
    {
        if (customEventId==(unsigned)CompletionEvents::receiveCompleted)
        {
        }
    }

protected:


    /* 
       RECV_HEADER1 - стартовое состояние. Принимаем байты, пока меньше 4х в буфере.
       Приняли 4 байта 
           пока не стартовый байт и буфер не пуст
               сдвигаем содержимое буфера в начало на байт, уменьшая счетчик m_dataLen (отбрасываем первый байт)

           если найден стартовый байт и detectProtocolVersion() == true
               переходим в состояние RECV_HEADER2

       RECV_HEADER2
           Принимаем байты, пока в буфере их меньше, чем размер заголовка

           Проверяем CRC - ok?
              да, m_scanMode = false;
                  state = RECV_DATA
               
        анализируем первый байт
        ...

     */

    uint8_t isStartByte( uint8_t b ) const
    {
        for( size_t i=0; i!=m_allowedStartBytesNumber; ++i )
        {
            if ( b==m_allowedStartBytes[i] )
                return b;
        }

        return 0;
    }


    bool detectProtocolVersion( uint8_t startByte )
    {
        switch(startByte)
        {
            case 0xBB: m_parsedPacketHeader.version.majorVersion = 1;
                       m_parsedPacketHeader.version.minorVersion = 0;
                       m_headerSize = 4;
                       return true;

            case 0xA0:
            case 0xA1: m_parsedPacketHeader.version.majorVersion = 2;
                       m_parsedPacketHeader.version.minorVersion = 0;
                       m_headerSize = 4;
                       return true;

            case 0xB0:
            case 0xB1: m_parsedPacketHeader.version.majorVersion = 2;
                       m_parsedPacketHeader.version.minorVersion = 0;
                       m_headerSize = 5;
                       return true;

            default:   return false;
        }
    }


    void setScanMode( bool scanMode )
    {
        if ( m_scanMode==scanMode )
            return;

        if (!m_scanMode) // Prev state is regular mode
            notifyOutOfSync(); // Goes to scan mode

        m_scanMode = scanMode;
    }

    void shiftInputBuf()
    {
        if (!m_dataLen)
            return;
        std::memmove( &m_buf[0], &m_buf[1], m_dataLen-1 );
        --m_dataLen;
    }

    bool unpackHeader()
    {
        /*
          G1 Заголовок 4 байта, CRC - в 4ом последнем ([3])
                             размер - в 3м            ([2])
          Длина пакета включает в себя заголовок и все CRC
          Вторая CRC считается вместе с заголовком.
        
        
          G2 Короткий пакет
             Заголовок 4 байта, CRC - в 4ом последнем ([3])
                             размер - младшие 4 бита в 3м, упакован вместе со счетчиком ([2])
        
          G2 Длинный пакет
             Заголовок 5 байт, CRC   - в 5ом последнем ([4])
                             размер  - в 4м            ([3])
                             счетчик - в 3м            ([2])
        
          Длина пакета - только данные и второй CRC.
          Вторая CRC также только на данные
        */

        m_parsedPacketHeader.channelType = ChannelType::uart;
        m_parsedPacketHeader.seqTotal = 1;
        m_parsedPacketHeader.seqNum   = 0;
        m_parsedPacketHeader.cycleCnt = 0;
        m_parsedPacketHeader.prio     = false;

        //uint8_t crcReceived = 0;

        if (m_parsedPacketHeader.version.compare(1,0)==0)
        {
            //crcReceived        = m_buf[3];
            //m_receivedDataSize = (size_t)m_buf[2];
            m_rawPacketFullLen   = (size_t)m_buf[2];
            m_parsedPacketHeader.dataSize = m_rawPacketFullLen - 4 - 1; // Вычитаем размер заголовка и размер последнего CRC
            if (m_rawPacketFullLen<7 || m_rawPacketFullLen>16)
                return false;
        }
        else // G2
        {
            if (m_headerSize==4)
            {
                //crcReceived        = m_buf[3];
                m_parsedPacketHeader.dataSize = (size_t)(m_buf[2]&0x0F);
                m_parsedPacketHeader.cycleCnt = (m_buf[2]&0xF0)>>4;
                m_rawPacketFullLen            = m_parsedPacketHeader.dataSize + m_headerSize + 1;
            }
            else
            {
                //crcReceived        = m_buf[4];
                m_parsedPacketHeader.dataSize = (size_t)(m_buf[3]);
                m_parsedPacketHeader.cycleCnt = m_buf[2];
                m_rawPacketFullLen            = m_parsedPacketHeader.dataSize + m_headerSize + 2;
            }
        }

        return true;
    
    }


    enum class State
    {
        //WAIT_START_SIGN,
        RECV_HEADER1,
        RECV_HEADER2,
        RECV_DATA
    };


    // notifyOutOfSync( )
    // putOctet( StreamOctetType octet )
    void receiveOctet( StreamOctetType o )
    {
        switch(m_state)
        {
            //case State::WAIT_START_SIGN:
            case State::RECV_HEADER1:
                 {
                     putOctet( o );
                     if (m_dataLen<4)
                         return;

                     auto sb = isStartByte(m_buf[0]);
                     if ( !sb || !detectProtocolVersion(sb))
                     {
                         // Сдвигаем содержимое буфера, выталкиваем левый байт
                         shiftInputBuf();
                         setScanMode(true);
                         return;
                     }

                     m_state = State::RECV_HEADER2;
                     setScanMode(false);
                     return;
                 }

            case State::RECV_HEADER2:
                 {
                UMBA_ASSERT(m_headerSize != 0);

                     putOctet( o );
                     if (m_dataLen<m_headerSize)
                         return;

                     UMBA_ASSERT(m_headerSize != 0);


                     // Если мы считаем CRC не включая саму CRC, то должны получить значение CRC, равное принятой в пакете
                     // Если мы считаем CRC вместе с принятой CRC, то должны получить 0
                     uint8_t crcFail  = scrypto::crc8( &m_buf[0], m_headerSize, 0x31u /* poly */
                                                     , false /* reversePoly */, false /* reverseCalc */, false /* reverseOut */
                                                     , 0xFFu /*initVal*/, 0x00u /*resXor*/
                                                     );

                     if (crcFail || !unpackHeader())
                     {
                         if (crcFail)
                             notifyCrcError( true );
                         else
                             notifyInvalidHeader();

                         shiftInputBuf();
                         setScanMode(true);
                         m_state = State::RECV_HEADER1;
                         return;
                     }

                     setScanMode(false);
                     m_state = State::RECV_DATA;

                 } // case

            case State::RECV_DATA:
                 {
                     putOctet( o );

                     if (m_dataLen<m_rawPacketFullLen)
                         return;

                     AddressInfo peerAddr = { 1, (GenericPeerAddress*)&m_buf[1] };


                     // Ничего не проверяем, так как часть данных пакета была отброшена
                     if (isBufferOverflowed())
                     {
                         callHandler( &peerAddr ); //!!! exctratc addr here
                         m_dataLen = 0;
                         setScanMode(false);
                         m_state = State::RECV_HEADER1;
                         return;
                     }


                     size_t   crcBits     = 8;
                     uint16_t crcReceived = (uint16_t)m_buf[m_dataLen-1];
                     size_t   calcLen     = m_dataLen - 1; 
                     const uint8_t *pDataCalcOn = &m_buf[0];

                     if (m_parsedPacketHeader.version.compare(2,0)==0)
                     {
                         pDataCalcOn += m_headerSize;
                         calcLen = m_parsedPacketHeader.dataSize;

                         if (m_headerSize==5)
                         {
                             crcReceived = ((uint16_t)m_buf[m_dataLen-2]) | (((uint16_t)m_buf[m_dataLen-1])<<8);
                             crcBits     = 16;
                         }
                     }

                     uint8_t crcCalculated = 0;
                     if ( m_parsedPacketHeader.version.compare(2,0)==0 && m_headerSize==5 )
                     {
                         crcCalculated  = scrypto::crcVs16( pDataCalcOn, calcLen, crcBits, 0x1021u /* poly */
                                                          , false /* reversePoly */, false /* reverseCalc */, false /* reverseOut */
                                                          , 0xFFFFu /*initVal*/, 0x00u /*resXor*/
                                                          );
                     }
                     else
                     {
                         crcCalculated  = scrypto::crcVs16( pDataCalcOn, calcLen, crcBits, 0x31u /* poly */
                                                          , false /* reversePoly */, false /* reverseCalc */, false /* reverseOut */
                                                          , 0xFFu /*initVal*/, 0x00u /*resXor*/
                                                          );
                     }

                     //callHandler

                     if (crcCalculated!=crcReceived)
                     {
                         notifyCrcError( false, &peerAddr );
                         shiftInputBuf();
                         setScanMode(true);
                         m_state = State::RECV_HEADER1;
                         return;
                     }


                     // препаре дата хере

                     const uint8_t *pData = &m_buf[0] + m_headerSize;

                     m_parsedPacketHeader.fcodeRaw = (*pData) & 0x0F;
                     m_parsedPacketHeader.ack      = (AckCode)(((*pData)>>4) & 0x0F);

                     if ( m_parsedPacketHeader.version.compare(2,0)==0)
                     {
                         // Get direction from packet start code
                         m_parsedPacketHeader.dir = (m_buf[0] & 1) ? PacketDirection::fromSlaveToMaster : PacketDirection::fromMasterToSlave ;
                         // Для второй версии ганжубуса трансляция FCode не требуется - они описаны в соответствии с ним
                         m_parsedPacketHeader.fcode = (FCode)m_parsedPacketHeader.fcodeRaw;
                     }
                     else
                     {
                         // Примем, что направление определяется старшим битом Ack'а
                         m_parsedPacketHeader.dir = ((uint8_t)m_parsedPacketHeader.ack) & 0x08 ? PacketDirection::fromSlaveToMaster : PacketDirection::fromMasterToSlave ;

                         if (m_parsedPacketHeader.ack==AckCode::ack || m_parsedPacketHeader.ack==AckCode::answer)
                         {
                             // Для других ack-кодов трансляция fcode не предусмотрена
                             switch( m_parsedPacketHeader.fcodeRaw )
                             {
                                 case umba::protocols::ganjubus::legacy::ganjubusV1::FCode::deviceSpecific1:       m_parsedPacketHeader.fcode = FCode::deviceSpecific1 ; break;
                                 case umba::protocols::ganjubus::legacy::ganjubusV1::FCode::deviceSpecific2:       m_parsedPacketHeader.fcode = FCode::deviceSpecific2 ; break; // сейчас по факту не используется, но есть в спеке Г1 - необходим пересмотр спеки
                                 case umba::protocols::ganjubus::legacy::ganjubusV1::FCode::writeRange     :       m_parsedPacketHeader.fcode = FCode::writeRange8     ; break;
                                 case umba::protocols::ganjubus::legacy::ganjubusV1::FCode::writeSeries    :       m_parsedPacketHeader.fcode = FCode::writeSeries8    ; break;
                                 case umba::protocols::ganjubus::legacy::ganjubusV1::FCode::deviceSpecific3:       m_parsedPacketHeader.fcode = FCode::deviceSpecific3 ; break; // сейчас по факту не используется, но есть в спеке Г1 - необходим пересмотр спеки
                                 case umba::protocols::ganjubus::legacy::ganjubusV1::FCode::readRange      :       m_parsedPacketHeader.fcode = FCode::readRange8      ; break;
                                 case umba::protocols::ganjubus::legacy::ganjubusV1::FCode::readSeries     :       m_parsedPacketHeader.fcode = FCode::readSeries8     ; break;
                                 case umba::protocols::ganjubus::legacy::ganjubusV1::FCode::deviceSpecific4:       m_parsedPacketHeader.fcode = FCode::deviceSpecific4 ; break;
                                 default:                                         m_parsedPacketHeader.fcode = FCode::invalidCode; 
                             }
                         }
                     }

                     // m_parsedPacketHeader.dataSize - размер данных
                     // pData - указатель на данные пакета

                     // Тут варианты такие:
                     // 1) На стеке выделить место, скопировать туда универсальный заголовок и данные
                     //    Этот вариант требует места на стеке, но может быть полезен при отладке - не затирает исходные данные
                     // 2) Подвинуть данные в буфере и скопировать туда заголовок


                     // Сделаю пока первое на скорую руку

                     PacketHeader *pPacketHeader = (PacketHeader*)alloca( sizeof(m_parsedPacketHeader) + m_parsedPacketHeader.dataSize );
                     memcpy( (void*)pPacketHeader, (void*)&m_parsedPacketHeader, sizeof(m_parsedPacketHeader) );
                     memcpy( (void*)((&pPacketHeader)+1), (void*)pData, m_parsedPacketHeader.dataSize );

                     UMBA_ASSERT(m_pHandler);
                     m_pHandler->handleParsedPacket( (uint8_t*)pPacketHeader, sizeof(m_parsedPacketHeader) + m_parsedPacketHeader.dataSize, &peerAddr );

                     // нужно расширить место под универсальный заголовок пакета
                     // 

                     //m_state = State::RECV_HEADER1;
                     //setScanMode(false);
                     reset();
                 }
        };
    }


    uint8_t m_allowedStartBytes[5] = { 0xBB, 0xA0, 0xA1, 0xB0, 0xB1 };
    size_t  m_allowedStartBytesNumber = 5;

    size_t        m_headerSize            = 0; // 0 - invalid, 4/5 - valid
    bool          m_scanMode              = false;
    State         m_state                 = State::RECV_HEADER1;
    size_t        m_rawPacketFullLen      = 0; // полный размер сырого пакета, который необходимо принять, включая все CRC
    PacketHeader  m_parsedPacketHeader    ;
    

}; // struct PacketParserBase



struct ProtocolImplBase : public umba::protocols::IStreamProtocolImplBase< umba::protocols::IStreamProtocol >
{
    typedef umba::protocols::IStreamProtocolImplBase< umba::protocols::IStreamProtocol > BaseProtocol;

    typedef umba::protocols::ganjubus::PacketHeader PacketHeader;
    typedef umba::protocols::AddressInfo            AddressInfo;

    using umba::protocols::IStreamProtocolImplBase< umba::protocols::IStreamProtocol >::sendPacket;



    


    virtual
    umba::Error sendPacket( const StreamOctetType *pkt, StreamSize pktSize, const AddressInfo *pAddressInfo ) override
    {
        auto res = m_pComposer->compose(pkt, pktSize, pAddressInfo);

        //m_state = MachineState::commandPause;

        //m_lastCommandTick = umba::time_service::getCurTimeMs();

        return res;
    }


    virtual
    void poll() override
    {
        BaseProtocol::poll();
    }

    virtual
    bool isReadyForPoll() override
    {
        return true;
    }

    virtual
    bool isReadyForPing() override
    {
        return false;
    }

    virtual
    void reset() override
    {
        BaseProtocol::reset();
    }

    virtual
    bool canSend() override
    {
        return canSendCommand();
    }

    bool canSendCommand() const
    {
        return true; // m_state == MachineState::idling;
    }

    virtual
    void setGanjubusPacketHandler( IPacketHandler *pHandler )
    {
        m_pHandler = pHandler;
    }

    virtual
    ~ProtocolImplBase()
    {
        if (m_ownerMode)
            delete m_pHandler;
    }

private:

    virtual
    void onPing( ) override
    {
        // ничего не делаем, так как это только протокол обмена, о самих пакетах знает только конкретный тип голема
    }

    virtual
    void handleParsedPacket( const BaseProtocol::StreamOctetType *pkt, BaseProtocol::StreamSize pktSize, const AddressInfo *pAddressInfo ) override
    {
        //StreamOctetType res = parseGolemPacket( pkt, pktSize );
        parseGanjubusPacket( (const PacketHeader *)pkt, (const uint8_t*)(((const PacketHeader *)pkt)+1), pAddressInfo);
    }

    virtual
    void onComplete( unsigned customEventId ) override
    {
        BaseProtocol::onComplete(customEventId);
        if (customEventId==(unsigned)CompletionEvents::receiveCompleted)
        {
            //m_state = MachineState::idling;
            //clearLastSentCommand(); // m_lastCommand = 0; // no command
        }
        else if (customEventId==(unsigned)CompletionEvents::receiveStarted)
        {
            //if (m_state==MachineState::idling)
            //    m_state = MachineState::receivingReply;
        }
    }

    //! Разбор пакета ганжубуса
    virtual
    void parseGanjubusPacket( const PacketHeader *pPktHeader, const StreamOctetType *pPktData, const AddressInfo *pPeerAddr )
    {
        if (m_pHandler)
            m_pHandler->parseGanjubusPacket( pPktHeader, pPktData, pPeerAddr );
    }


protected:


    IPacketHandler    *m_pHandler = 0;


}; // struct ProtocolImplBase







} // namespace ganjubus
} // namespace protocols
} // namespace umba


