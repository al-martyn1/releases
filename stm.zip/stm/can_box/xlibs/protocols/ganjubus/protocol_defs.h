#pragma once

#include "umba/numeric_version.h"

#include "../stream_protocol_impl_base.h"
#include "../packet_composer_impl_base.h"
#include "../packet_parser_impl_base.h"




/*  Ганжубус - http://wiki.dep111.rtc.local/protocols:milliganjubus

    G-байт
    G-байт состоит из двух тетрад. Старшая - Ack, младшая - F-code.
    
    В тетраде Ack могут быть следующие коды:
    
    0x0 - запрос ведущего устройства;
    0xA - ответ на запрос ведомого устройства;
    0xE - ответ - сообщение об ошибке.
    В тетраде F-code содержится код функции, описывающий, что необходимо сделать с данными:
    
    1 - Запись WO-регистра;
    2 - WR (Write Range) Запись диапазона WO-регистров (от 1 до 8 WO-регистров, имеющих идущие подряд номера);
    3 - WS (Write Series) Запись серии разрозненных WO-регистров (от 1 до 5);
    4 - Чтение RO регистра;
    5 - RR (Read Range)  Чтение диапазона регистров (от 1 до 8 регистров, имеющих идущие подряд номера);
    6 - RS (Read Series) Чтение серии разрозненных регистров (от 1 до 5).
    

    ---------------

    Канабус  - http://wiki.dep111.rtc.local/protocols:cannabus
               http://wiki.dep111.rtc.local/protocols:cannabus_plus
    
      Номер бита     10 9                 8 7 6 5 4 3 2                1 0
      Содержание     Код типа сообщения   Адрес ведомого устройства    Код функции    

      Код типа сообщения
    
      высокоприоритетное сообщение ведущего (код 0b00) - запрос на чтение или запись с максимальным приоритетом,
                                       ведомый отвечает (при необходимости) сообщением с нормальным приоритетом;
                                       RWRHP - read/write request (high priority)
      высокоприоритетное сообщение ведомого (код 0b01) - передается без запроса ведущего в случае нештатных ситуаций,
                                       содержит значения заранее определенных регистров, имеет формат ответа на запрос 
                                       на чтение серии (см. ниже);
                                       SS - slave status
      запрос ведущего (код 0b10) - запрос на чтение или запись, передаваемый от ведущего к ведомому;
                                       RWR
      ответ ведомого (код 0b11)  - ответ на запрос ведущего; может содержать:
          подтверждение - в случае корректного запроса на запись;
          содержимое регистров - в случае корректного запроса на чтение;
          сообщение об ошибке - в случае некорректного запроса.    
                                       RPL - reply
      
      
      Код функции

      запись диапазона (код 0b00) – запись от одного до шести WO-регистров, имеющих идущие подряд номера; Write Range - WR
      запись серии (код 0b01) – запись от одного до четырех WO-регистров, расположенных в любом месте регистрового пространства ведомого; Write Series - WS
      чтение диапазона (код 0b10) – чтение от одного до шести регистров любого типа, имеющих идущие подряд номера; Read Range - RR
      чтение серии (код 0b11) – чтение от одного до четырех регистров любого типа, расположенных в любом месте регистрового пространства ведомого. Read Series - RS


                             Канабус                         |       Ганжубус             |      Ганжубус 2           
                                                             |                            |                          
      Код типа сообщения (КТС) (1)      Код функции (КФ)     |    Ack            F-code   |   Ack            F-code
                                                             |                            |                        
      00  RWRHP  RW Request HP       00  WR  Write Range     |    0x0             2 WR    |   0x0             3 WR8 
      00  RWRHP  RW Request HP       01  WS  Write Series    |    0x0             3 WS    |   0x0             9 WS8 
      00  RWRHP  RW Request HP       10  RR  Read Range      |    0x0             5 RR    |   0x0             0 RR8 
      00  RWRHP  RW Request HP       11  RS  Read Series     |    0x0             6 RS    |   0x0             6 RS8 
      01  SS     Slave Status        00  WR  Write Range     |    0xA / 0xE (2)   2 WR    |   0xA / 0xE (2)   3 WR8
      01  SS     Slave Status        01  WS  Write Series    |    0xA / 0xE (2)   3 WS    |   0xA / 0xE (2)   9 WS8
      01  SS     Slave Status        10  RR  Read Range      |    0xA / 0xE (2)   5 RR    |   0xA / 0xE (2)   0 RR8
      01  SS     Slave Status        11  RS  Read Series     |    0xA / 0xE (2)   6 RS    |   0xA / 0xE (2)   6 RS8
      10  RWR    RW Request          00  WR  Write Range     |    0x0             2 WR    |   0x0             3 WR8
      10  RWR    RW Request          01  WS  Write Series    |    0x0             3 WS    |   0x0             9 WS8
      10  RWR    RW Request          10  RR  Read Range      |    0x0             5 RR    |   0x0             0 RR8
      10  RWR    RW Request          11  RS  Read Series     |    0x0             6 RS    |   0x0             6 RS8
      11  RPL    Slave Reply         00  WR  Write Range     |    0xA / 0xE       2 WR    |   0xA / 0xE       3 WR8
      11  RPL    Slave Reply         01  WS  Write Series    |    0xA / 0xE       3 WS    |   0xA / 0xE       9 WS8
      11  RPL    Slave Reply         10  RR  Read Range      |    0xA / 0xE       5 RR    |   0xA / 0xE       0 RR8
      11  RPL    Slave Reply         11  RS  Read Series     |    0xA / 0xE       6 RS    |   0xA / 0xE       6 RS8

      1 - КТС
        младший бит: 0 - Master request, 1 - Slave Reply
        старший бит - приоритетность, для ответов - признак - sync/async

      2 - Не реализовано в Ганжубусе. Теоретически, при использовании Ганжубуса 
          в режиме p2p подобные сообщения можно посылать

      0xA / 0xE - ответ или ошибка. В Ганжубусе - 1 байт с кодом ошибки.
      В Канабусе ошибка передается пустым пакетом без уточнения её вида.

      Коды функции Ганжубус F-code
      1 - Запись WO-регистра;
      4 - Чтение RO регистра;


      Ганжабус или Канжубус? Кунжутис? Канабис? Jubus?


      Адреса

      Ганжубус в1
          1-254 - просто адреса
          0     - broadcast
          255   - anycast

      Канабус
          1-122 - просто адреса
          0     - broadcast
          123   - anycast (на самом деле в доке такого нет, и канабус в чистом виде не используется, поэтому я взял для унификации)

      Канабус+
          1-60 - просто адреса
          0     - broadcast
          61    - anycast


      Ганжубус в2/UART
          1-254 - просто адреса
          0     - broadcast
          255   - anycast

      Ганжубус в2/CAN
          1-122 - просто адреса
          0     - broadcast
          123   - anycast


      G1 Заголовок 4 байта, CRC - в 4ом последнем
                         размер - в 3м 
      Длина пакета включает в себя заголовок и все CRC
      Вторая CRC считается вместе с заголовком.


      G2 Короткий пакет
         Заголовок 4 байта, CRC - в 4ом последнем
                         размер - младшие 4 бита в 3м, упакован вместе со счетчиком

      G2 Длинный пакет
         Заголовок 5 байт, CRC   - в 5ом последнем
                         размер  - в 4м 
                         счетчик - в 3м

      Длина пакета - только данные и второй CRC.
      Вторая CRC также только на данные


*/


namespace umba
{
namespace protocols
{
namespace ganjubus
{


//! Ошибки ганжубуса - возвращаются сервером (слейвом) на запросы мастера (клиента)
enum class ErrorCode
{
    noError   = 0, // - не используется на канальном уровне
    badGByte  = 1, // - в запросе содержался неверный G-байт;
    badReg    = 2, // - в запросе содержался неверный адрес регистра;
    badSize   = 3, // - в запросе содержалось неверное количество данных;
    cmdFailed = 4  // - невозможно выполнить команду
};

//! Направление пакета
enum class PacketDirection
{
    fromMasterToSlave  = 0, 
    fromClientToServer = 0,

    fromSlaveToMaster  = 1, 
    fromServerToClient = 1
};

//! Коды Ack
enum class AckCode
{
    ack     = 0x0,
    reply   = 0xA,
    answer  = 0xA,
    error   = 0xE
};

/* Эти коды используются для общения пользователем протокола и соответствуют кода G2.
   При работе по старым протоколам эти значения конвертируются в соответствующие коды протокола.
   Со старыми протоколами совместимы только 8ми-битные коды.

   deviceSpecific коды мапятся в полном объеме.
   В Canabus (Plus) влезают все четыре кода
   В GanjubusV1 есть два свободных кода. Еще два являются дублирующими и не используются, и надо поменять спеку

 */

//! Коды функций 
enum class FCode
{
    readRange8     = 0,
    readRange16    = 1,
    readRange32    = 2,

    writeRange8    = 3,
    writeRange16   = 4,
    writeRange32   = 5,

    readSeries8    = 6,
    readSeries16   = 7,
    readSeries32   = 8,

    writeSeries8   = 9,
    writeSeries16  = 10,
    writeSeries32  = 11,

    deviceSpecific1 = 12,
    deviceSpecific2 = 13,
    deviceSpecific3 = 14,
    deviceSpecific4 = 15,

    invalidCode     = 0xFF // Ошибка при конвертации FCode - принятый код не может быть транслирован. Данное значение не используется на транспортном уровне

};


namespace legacy
{

namespace canabus
{

enum class FCode
{
    writeRange   = 0,
    writeSeries  = 1,
    readRange    = 2,
    readSeries   = 3
}; // enum class FCode

} // namespace canabus


namespace ganjubusV1
{

enum class FCode
{
    deviceSpecific1 = 0,
    deviceSpecific2 = 1,

    //writeRegister   = 1, deprecated
    writeRange      = 2,
    writeSeries     = 3,

    deviceSpecific3 = 4,
    //readRegister    = 4, deprecated
    readRange       = 5,
    readSeries      = 6,

    deviceSpecific4 = 7

}; // enum class FCode

} // namespace canabus

} // namespace legacy






enum class ChannelType
{
    uart          ,
    serial = uart ,
    can

};


struct PacketHeader
{
    //uint8_t              version ; // Версия протокола, разбита на тетрады MAJOR.MINOR
    umba::NumericVersion version;
    ChannelType          channelType; // Тип канала передачи

    PacketDirection      dir     ; // Направление пакета - получаем из маркерного байта ганжубуса 2 или из кода типа сообщения CAN, для первого ганжубуса извлекаем из Ack 
    bool                 prio    ; // Приоритет (если от мастера) или признак асинхронного сообщения - сообщения, отосланного без запроса 
                                   // false - low priority/sync packet, true - high priority/async packet
                                   // в серийном и первом ганжубусе всегда равно false и игнорируется

    uint8_t              cycleCnt; // Всегда 0 для G1 - не используется
    uint8_t              seqTotal; // Всего пакетов в серии - всегда 1, кроме G2 over CAN
    uint8_t              seqNum  ; // Номер пакета в серии  - всегда 0, кроме G2 over CAN
    uint8_t              fcodeRaw; // Сырой FCode, как принято на канальном уровне
    AckCode              ack     ;
    FCode                fcode   ;
    ErrorCode            errorCode;
    size_t               dataSize;

};

/*
struct Packet
{
};
*/

// https://ru.stackoverflow.com/questions/426296/%D0%98%D1%81%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5-%D0%BC%D0%B0%D1%81%D1%81%D0%B8%D0%B2%D0%B0-%D0%BD%D1%83%D0%BB%D0%B5%D0%B2%D0%BE%D0%B3%D0%BE-%D1%80%D0%B0%D0%B7%D0%BC%D0%B5%D1%80%D0%B0
// https://devblogs.microsoft.com/oldnewthing/?p=38043


//void parseGanjubusPacket( const Packet *pkt, const AddressInfo *pPeerAddr ) = 0;




} // namespace ganjubus
} // namespace protocols
} // namespace umba
