#pragma once

#include "protocol_impl_base.h"

namespace umba {
namespace protocols {
namespace ganjubus {

interface IPacketHandler : inherits umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0x039F7618);

    virtual
    void parseGanjubusPacket( const PacketHeader *pPktHeader, const StreamOctetType *pPktData, const AddressInfo *pPeerAddr ) = 0;

}; // interface IPacketHandler


} // namespace ganjubus
} // namespace protocols
} // namespace umba


