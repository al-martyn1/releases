/*! \file
\brief Реализация 
*/

#pragma once

#include "i_stream_protocol.h"
#include "datalink_impl_base.h"
#include "i_raw_data_events.h"

#include "umba/basic_interfaces_impl.h"



#include <utility>

namespace umba
{
namespace protocols
{

// Работает так : http://ideone.com/qFiwbU
// Не работает так: http://ideone.com/u0NEAz
// Хочется, как не работает
// Что примерно хочется: http://ideone.com/beCbyn

//! Обобщенный интерфейс потокового протокола 
template< typename BaseProtocol = IStreamProtocol > // or use IStreamMultiAddrProtocol
struct IStreamProtocolImplBase : implements BaseProtocol
                               , implements umba::IPollCapable
                               , implements umba::ICompletionHandler
                               , implements IComposedPacketHandler
                               , implements IParsedPacketHandler
                               , implements IRawDataEvents
                               , implements IPingRequestHandler
                               , public     DatalinkImplBase
                               , public     umba::PingRequestGeneratorImplBase


{

    UMBA_BEGIN_INTERFACE_MAP_EX( BaseProtocol )

         //UMBA_IMPLEMENT_INTERFACE( BaseProtocol )
         UMBA_IMPLEMENT_INTERFACE( umba::IPollCapable )
         UMBA_IMPLEMENT_INTERFACE( umba::ICompletionHandler )
         UMBA_IMPLEMENT_INTERFACE( IComposedPacketHandler )
         UMBA_IMPLEMENT_INTERFACE( IParsedPacketHandler )
         UMBA_IMPLEMENT_INTERFACE( IRawDataEvents )
         UMBA_IMPLEMENT_INTERFACE( IPingRequestGenerator )
         // UMBA_IMPLEMENT_INTERFACE( IPingRequestHandler ) - а вот его - не публикуем, ибо нефик -  унаследовались от него только ради onPing, причем сугубо для внутреннего потребления

         // From DatalinkImplBase
         UMBA_IMPLEMENT_INTERFACE( IDatalinkEvents  )
         UMBA_IMPLEMENT_INTERFACE( IDatalinkPrivate )
         UMBA_IMPLEMENT_INTERFACE( IDatalink        )
         //UMBA_IMPLEMENT_INTERFACE( )

    UMBA_END_INTERFACE_MAP()

    virtual
    bool setOwnerMode( bool ownerMode ) override
    {
        bool res = m_ownerMode;
        m_ownerMode = ownerMode;
        return res;
    }

    virtual
    void poll() override
    {
        if (isReadyForPoll())
        {
            auto recvRes = receive();
            if (!recvRes)
            {
                onComplete( (unsigned)CompletionEvents::receiveCompleted );
            }
            else
            {
                // что-то приняли
                onComplete( (unsigned)CompletionEvents::receiveStarted );
            }

        }

        checkCarrier();
        checkDatalink();

        if (m_pingPeriod)
        {
            // если кто-то ведет обмен данными и штамп данных обновляется, то пинги не нужны
            if (isDatalinkCustomPeriodTimedout( m_pingPeriod ) ) 
            {
                if (isReadyForPing()) // если занят, то пинг не генериться
                    onPing();
            }
        }
    }

    //! Устанавливает канальный поток
    virtual
    umba::ihc::IOctetIOStream* setStream(umba::ihc::IOctetIOStream *pStream) override
    {
        std::swap(m_pStream, pStream);
        return pStream;
    }

    //! Возвращает ранее установленный канальный поток
    virtual
    umba::ihc::IOctetIOStream* getStream() override
    {
        return m_pStream;
    }

    //! Устанавливает собирателя пакетов
    virtual
    IPacketComposer* setPacketComposer(IPacketComposer *pComposer) override
    {
        std::swap(m_pComposer, pComposer);
        if (pComposer)
            pComposer->setHandler(0);
        if (m_pComposer)
            m_pComposer->setHandler(this);
        return pComposer;
    }

    //! Возвращает ранее установленный собиратель пакетов
    virtual
    IPacketComposer* getPacketComposer() override
    {
        return m_pComposer;
    }

    //! Устанавливает разбирателя пакетов
    virtual
    IPacketParser* setPacketParser(IPacketParser *pParser) override
    {
        std::swap(m_pParser, pParser);
        if (pParser)
            pParser->setHandler(0);
        if (m_pParser)
            m_pParser->setHandler(this);
        return pParser;
    }

    //! Возвращает ранее установленный разбиратель пакетов
    virtual
    IPacketParser* getPacketParser() override
    {
        return m_pParser;
    }



    //! Принимает данные из буфера. Не вызывает onRawReceived
    virtual
    void receiveData( StreamOctetType *pData, StreamSize dataLen ) override
    {
        if (!m_pParser)
            return;

        m_pParser->receiveData(pData, dataLen);
    }

    //! Принимает данные из установленного потока
    virtual
    umba::Result<StreamSize> receive( ) override
    {
        UMBA_ASSERT(m_pStream);

        if (!m_pStream->canRead())
            return 0;

        StreamOctetType buf[32];
        //StreamSize numReaded = m_pStream->read( buf, UMBA_COUNT_OF(buf) );
        auto res = m_pStream->read( buf, UMBA_COUNT_OF(buf) );

        if (!res.isSuccess())
            return res;

        if (res.value)
        {
            updateCarrierStamp();
            onRawReceived( buf, res.value );
            m_pParser->receiveData(buf, res.value);
        }

        return res.value;
    }

    //! Формирует канальный пакет и отправляет его
    virtual
    umba::Error sendPacket( const StreamOctetType *pkt, StreamSize pktSize, const AddressInfo *pAddressInfo ) override
    {
        return m_pComposer->compose(pkt, pktSize, pAddressInfo);
    }

    virtual
    umba::Error sendPacket( const StreamOctetType *pkt, StreamSize pktSize ) override
    {
        return sendPacket( pkt, pktSize );
    }

    virtual
    void resetParser() override
    {
        if (!m_pParser)
            return;

        m_pParser->reset();
    }

    virtual
    void reset() override
    {
        resetParser();
    }

    virtual
    bool isReadyForPing() override
    {
        // По умолчанию - готов к пингам
        return true;
    }

protected:

    virtual
    void onComplete( unsigned customEventId ) override
    {
        if (customEventId==(unsigned)CompletionEvents::receiveCompleted)
        {
            if (auto res = m_pParser->queryInterface<umba::ICompletionHandler>())
            {
                res.value->onComplete(customEventId);
            }
            //m_pParser->onComplete(customEventId);
        }
    }


    //! Принимает пакет протокола, подготовленный для канального уровня, и отправляет его в поток
    /*! Не следует вызывать этот метод напрямую.
     */
    virtual
    umba::Error handleComposedPacket( const StreamOctetType *pkt, StreamSize pktSize, const AddressInfo *pAddressInfo ) override
    {
        UMBA_ASSERT(m_pStream);
        onRawSend( pkt, pktSize );
        m_pStream->write( pkt, pktSize );
        return umba::errors::ok; //UNDONE: !!! stream 'write' method need to be refactored and must return result code
    }


    //! Вызывается при приеме порции данных, следует использовать для нужд логгирования.
    virtual
    void onRawReceived( const StreamOctetType *pData, StreamSize dataSize ) override
    {
        // Затычка, можно не переопределять в наследниках, если протоколирование не нужно
    }
    
    //! Вызывается при отправке порции данных (перед), следует использовать для нужд логгирования.
    virtual
    void onRawSend( const StreamOctetType *pData, StreamSize dataSize ) override
    {
        // Затычка, можно не переопределять в наследниках, если протоколирование не нужно
    }



    //----------------------

    //! Вызывается при ошибке формирования канального пакета
    /*! Не следует вызывать этот метод напрямую.
        Переопределяется в конкретной реализации.
     */
    virtual
    umba::Error handleComposeError( const StreamOctetType *pkt, StreamSize pktSize, umba::Error errCode, const AddressInfo *pAddressInfo ) override
    {
        UMBA_ASSERT(errCode!=umba::errors::too_much_data); // данные не помещаются во внутренний буфер - нужно увеличить буфер композера
        return errCode;
    }

    //! Вызывается при ошибке разбора канального пакета
    /*! Не следует вызывать этот метод напрямую.
        Переопределяется в конкретной реализации.
     */
    virtual
    void handleParseError  ( const StreamOctetType *pkt, StreamSize pktSize, umba::Error parseRes, const AddressInfo *pAddressInfo ) override
    {
        // Хорошо бы сделать ассерт, но если этот метод забыть переопределить, то при слишком длинном сообщении
        // прошивка упадет. А так как предполагается, что это будет происходить редко - ведь размер буфер будет
        // выбираться изначально достаточным.
    }

    virtual
    void onPing( ) override
    {
    }

    virtual 
    void setFixedTimestamp( umba::time_service::TimeTick timestamp ) override
    {
        m_fixedTimestamp = timestamp;
    }

    virtual 
    void resetFixedTimestamp( ) override
    {
        m_fixedTimestamp = 0;
    }

    virtual 
    umba::time_service::TimeTick getTimestamp( ) override
    {
        return m_fixedTimestamp ? m_fixedTimestamp : umba::time_service::getCurTimeMs();
    }

    //! Сохраняет указатель на AddressTraits
    /*! AddressTraits - должен быть глобальный/статический объект, или динамический объект,
        время жизни которого гарантированно дольше времени жизни объекта протокола.
     */
    virtual
    void setAddressTraits( const AddressTraits *pAddressTraits) override
    {
        m_pAddressTraits = pAddressTraits;
    }

    //! Возвращает сохраненный указатель на AddressTraits
    virtual
    const AddressTraits* getAddressTraits() override
    {
        return m_pAddressTraits;
    }

    //! Устанавливает собственный адрес
    /*! Собственный адрес используется, когда в метод makeWellKnownAddress
        передается WellKnownAddress::self.
        Данный метод копирует адрес

     */
    virtual
    umba::Error setSelfAddress( const AddressInfo ai ) override
    {
        return umba::errors::not_implemented;
    }

    virtual
    umba::Result<AddressInfo> getSelfAddress( ) override
    {
        return umba::Error(umba::errors::not_implemented);
    }


    //! Заполняет pAddrBuf указанным хорошоизвестным адресом и возвращает AddressInfo.
    /*! Длины буфера должно гарантированно хватать.
        Если pAddrBuf==0, возвращает umba::errors::invalid_param.
        Если AddressTraits не задан для протокола, возвращает umba::errors::invalid_prerequisites
        Если хорошоизвестный адрес не поддерживается, возвращает umba::errors::wellknown_addr_not_supported

        Мастер/клиент обычно отправляет на адрес слейва/сервера, или на один из хорошоизвестных адресов.
        При отправке слейвы/сервера обычно отправляют свой адрес. 
        В случае слейва/сервера должно быть достаточно только вызова данной функции.
     */
    virtual
    umba::Result<AddressInfo> makeWellKnownAddress( WellKnownAddress wka, void *pAddrBuf ) override
    {
        if (!pAddrBuf)
            return umba::Error(umba::errors::invalid_param);

        const AddressTraits* pAddrTraits = getAddressTraits();
        if (!pAddrTraits)
            return umba::Error(umba::errors::invalid_prerequisites);

        AddressInfo ai = { 0, 0 };

        switch( wka )
        {
            case WellKnownAddress::broadcast   : ai = AddressInfo{ pAddrTraits->addressSize, pAddrTraits->pAddressBroadcast }; break;
            case WellKnownAddress::anycast     : ai = AddressInfo{ pAddrTraits->addressSize, pAddrTraits->pAddressAnycast   }; break;
            case WellKnownAddress::range_first : ai = AddressInfo{ pAddrTraits->addressSize, pAddrTraits->pAddressRangeMin  }; break;
            case WellKnownAddress::range_last  : ai = AddressInfo{ pAddrTraits->addressSize, pAddrTraits->pAddressRangeMax  }; break;
            case WellKnownAddress::self        : 
                                               {
                                                   auto selfAddrRes = getSelfAddress( );
                                                   if (selfAddrRes.isSuccess())
                                                      ai = AddressInfo{ selfAddrRes.value.addressSize, selfAddrRes.value.pAddress };
                                                   break;
                                               }
                                                 
            //default: return umba::Error(umba::errors::unknown_bus_addr);
        }

        if ( !ai.addressSize || !ai.pAddress )
           return umba::Error(umba::errors::wellknown_addr_not_supported);

        ai.copyToBuf( pAddrBuf );

        return AddressInfo{ ai.addressSize, (GenericPeerAddress*)pAddrBuf };
    }

    //! Производит проверку валидности адреса.
    /*! Если в качестве адреса передан нулевой указатель, такой адрес будет считаться валидным.
        Протоколы, которые требуют обязательного наличия адреса, должны переопределять данные метод.
        Проверки производятся по заданным AddressTraits. Если AddressTraits не заданы, то 
        будет возвращено umba::errors::invalid_param (!!! наверное нужно придумать более другой код ошибки).
     */
    virtual
    umba::Error isAddressValid( const AddressInfo *pAddressInfo ) override
    {
        if (!pAddressInfo)
            return umba::Error(umba::errors::ok);

        const AddressTraits* pAddrTraits = getAddressTraits(); 
        if (!pAddrTraits)
            return umba::Error(umba::errors::invalid_prerequisites);   // Или ассертнуть?

        if (pAddressInfo->addressSize!=pAddrTraits->addressSize)
            return umba::Error(umba::errors::invalid_bus_addr);

        if (pAddrTraits->pAddressBroadcast)
        {
            if ( pAddressInfo->compare( AddressInfo{ pAddrTraits->addressSize, pAddrTraits->pAddressBroadcast } ) == 0 )
                return umba::Error(umba::errors::ok);
        }

        if (pAddrTraits->pAddressAnycast)
        {
            if ( pAddressInfo->compare( AddressInfo{ pAddrTraits->addressSize, pAddrTraits->pAddressAnycast } ) == 0 )
                return umba::Error(umba::errors::ok);
        }

        if (pAddrTraits->pAddressRangeMin)
        {
            if ( pAddressInfo->compare( AddressInfo{ pAddrTraits->addressSize, pAddrTraits->pAddressRangeMin } ) < 0 )
                return umba::Error(umba::errors::invalid_bus_addr); 
        }

        if (pAddrTraits->pAddressRangeMax)
        {
            if ( pAddressInfo->compare( AddressInfo{ pAddrTraits->addressSize, pAddrTraits->pAddressRangeMax } ) > 0 )
                return umba::Error(umba::errors::invalid_bus_addr); 
        }

        return umba::Error(umba::errors::ok);

    }

    virtual
    ~IStreamProtocolImplBase() override
    {
        if (!m_ownerMode)
            return;

        delete m_pStream;
        delete m_pComposer;
        delete m_pParser;
    }

protected:

    umba::ihc::IOctetIOStream         *m_pStream   = 0;
    IPacketComposer                   *m_pComposer = 0;
    IPacketParser                     *m_pParser   = 0;

    umba::time_service::TimeTick       m_fixedTimestamp = 0;
    const AddressTraits               *m_pAddressTraits = 0;
    bool                               m_ownerMode = false;


}; // IStreamProtocolImplBase


} // namespace protocols
} // namespace umba

