#pragma once

#include <cstddef>

#include "umba/allocator.h"
#include "containers/reserve_size.h"


// umba::containers::
namespace umba{
namespace containers{


//! Клас циклического буфера (очереди) со статическим буфером, размер которого задаётся единожды
/*!
    // UNDONE: Итераторы сделаем потом, если будет нужно
    // Но вообще это очередь FIFO, у неё вроде итераторов не должно быть

    // UNDONE: Возможно, стоит сделать специализацию для интегральных типов

    // NOTE: Является потокобезопасным контейнером (lock free), если только один поток читает с одного конца очереди, 
       а другой пишет в другой конец очереди, при этом читающий должен проверять наличие доступного элемента для чтения,
       а пишуший - доступность свободного места перед записью элемента.

       Все другие варианты 

       Lock free for single reader and single writter

 */
template< typename T, typename AllocatorType = umba::static_allocator<T> >
class static_cycle_deque
{

public:

    typedef    T                      value_type;

    typedef    size_t                 size_type;
    typedef    std::ptrdiff_t         difference_type;

    typedef    value_type&            reference;
    typedef    const value_type&      const_reference;
    typedef    value_type*            pointer;
    typedef    const value_type*      const_pointer;

    typedef AllocatorType                                                       allocator_type;
    typedef typename allocator_type::template rebind< value_type >::other       item_allocator_type;


    // UNDONE: allocator_type

    //typedef    XXX iterator
    //typedef    XXX const_iterator
    //reverse_iterator          std::reverse_iterator<iterator>
    //const_reverse_iterator    std::reverse_iterator<const_iterator>

    void reserve( size_type sz )
    {
        UMBA_ASSERT(m_pBuf==0); // Space can be reserved only once

        m_capacity = sz;
        initStorage();
    }

    static_cycle_deque() : m_allocator(AllocatorType())
    {
    }

    static_cycle_deque( umba::reserve_size rs ) : m_allocator(AllocatorType())
    {
        m_capacity = rs.get_reserve_size();
        initStorage();
    }

protected:

    //size_type           m_bufSize  = 0;
    size_type           m_capacity = 0;
    //size_type           m_sizeMask = 0; // BufSize - 1; - same as capacity

    value_type         *m_pBuf    = 0;
    size_type           m_headIdx = 0;
    size_type           m_tailIdx = 0; // points to the empty cell after last filled
    allocator_type      m_allocator;


    void initStorage()
    {
        //UMBA_ASSERT( m_capacity != 0 );
        if (!m_capacity)
            return;


        // We need buffer with power of two size, and capacity will be BufSize-1.

        size_type allocSize = 1;
        for(; m_capacity>=allocSize; allocSize<<=1 )
        {
            if (!allocSize)
            {
                UMBA_ASSERT_FAIL(); // overflow detected - too much capacity requested
            }
        }

        // adjust capacity to real value
        m_capacity = allocSize - 1;

        m_pBuf = item_allocator_type( m_allocator ).allocate( allocSize );
        //m_pItemsStorage = m_allocator.allocate( m_capacity );
        UMBA_ASSERT( m_pBuf != 0 ); // allocator is non-throwing
    }



    void destructHelper( value_type *p )
    {
        p->~value_type();
    }

    void constructHelper( value_type *p )
    {
        new (p) T();
    }

    void constructHelper( value_type *p, const value_type &v )
    {
        new (p) T( v );
    }

    void moveHelper( value_type *to, const value_type *from )
    {
        constructHelper( to, *from );
        destructHelper( from );
    }


public:

    bool empty() const
    {
        if (!m_pBuf) // calling empty() allowed while storage not initialized
            return true;

        //UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

        return m_headIdx==m_tailIdx;
    }

    size_type size() const
    {
        if (!m_pBuf) // calling size() allowed while storage not initialized
            return 0;

        //UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

        return (m_tailIdx - m_headIdx) & m_capacity; // SizeMask;
    }

    size_type max_size() const // standard method or my own?
    {
        return m_capacity; // BufSize - 1;
    }

    // NOTE: В deque такого нет, это из vector'а. Пусть будет? Или в итоге код получится несовместимым с std контейнерами?
    size_type capacity() const
    {
        return m_capacity; // BufSize - 1;
    }

    void shrink_to_fit() { }


    void clear()
    {
        for( ; m_headIdx!=m_tailIdx; m_headIdx = (m_headIdx+1) & m_capacity /* SizeMask */  )
        {
            destructHelper( &m_pBuf[m_headIdx] );
        }

        m_headIdx = m_tailIdx = 0;
    }

    // NOTE: при добавлении везде меняем соответствующий индекс, а затем вызываем конструктор
    // При удалении сначала разрушаем, а потом меняем индекс.
    // Т.е. резервируем место сразу, а отдаем в последний момент.
    // Это необходимо для потокобезопасности случая одного писателя в хвост и одного читателя в гриву
    // Читатель должен проверять empty() перед чтением
    // Писатель должен проверять size()!=max_size() перед записью

    // Не стандартная версия insert'а
    // Вставляет value перед элементом, на который указывает pos.
    // Возвращает индекс вставленного элемента
    size_type insert( size_type pos, const T& value )
    {
        UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

        if (!pos)
        {
            push_front( value );
            return pos;
        }
        else if ( pos >= size() )
        {
            push_back( value );
            return size()-1;
        }

        // UMBA_ASSERT( m_headIdx!=m_tailIdx );

        // Теперь нам нужно переместить всё на один шаг дальше.

        m_tailIdx = (m_tailIdx+1) & m_capacity; // SizeMask;  // сразу - на следующую пустую

        size_type indexPutTo = (m_headIdx+pos) & m_capacity; // SizeMask;

        size_type idx = m_tailIdx;
        for(; idx!=indexPutTo; idx = (idx-1) & m_capacity /* SizeMask */ )
        {
            moveHelper( &m_pBuf[idx], &m_pBuf[(idx-1) & m_capacity /* SizeMask */ ] );
        }

        constructHelper( &m_pBuf[indexPutTo], value );

        return pos;
    }

    // Не стандартная версия erase'а
    // Удаляет элемент на заданной индексом pos позиции
    // Возвращает индекс элемента, следующего за удаленным
    size_type erase( size_type pos )
    {
        UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

        if (!pos)
        {
            pop_front( );
            return pos;
        }
        else if ( pos >= size() )
        {
            pop_back( );
            return size()-1;
        }

        UMBA_ASSERT( m_headIdx!=m_tailIdx ); // не должен быть пустым

        size_type indexEraseWhere = (m_headIdx+pos) & m_capacity; // SizeMask;

        // Теперь нам нужно переместить всё на один шаг ближе.

        // Но перед этим - разрушить элемент
        destructHelper( &m_pBuf[indexEraseWhere] );

        for( ; indexEraseWhere!=m_tailIdx; indexEraseWhere = (indexEraseWhere+1) & m_capacity /* SizeMask */  )
        {
            moveHelper( &m_pBuf[indexEraseWhere], &m_pBuf[(indexEraseWhere+1) & m_capacity /* SizeMask */ ] );
        }

        m_tailIdx = (m_tailIdx-1) & m_capacity; // SizeMask;  // на предыдущую пустую

        return pos;
    }


    // UNDONE: void push_back( T&& value ); (начиная с C++11)
    void push_back( const T& value )
    {
        UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

        size_type oldTaleIdx = m_tailIdx;
        m_tailIdx = (m_tailIdx+1) & m_capacity; // SizeMask;  // на следующую пустую
        UMBA_ASSERT( m_headIdx!=m_tailIdx );

        constructHelper( &m_pBuf[oldTaleIdx], value );
    }

    // UNDONE: template< class... Args > void emplace_back( Args&&... args );

    void pop_back()
    {
        UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

        UMBA_ASSERT( m_tailIdx!=m_headIdx );
        size_t newTailIdx = (m_tailIdx-1) & m_capacity; // SizeMask; // На предыдущую заполненную

        destructHelper( &m_pBuf[newTailIdx] );

        m_tailIdx = newTailIdx;
    }

    // UNDONE: void push_front( T&& value ); (начиная с C++11)
    void push_front( const T& value )
    {
        UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

        m_headIdx = (m_headIdx-1)& m_capacity; // SizeMask;  // На предыдущую пустую
        UMBA_ASSERT( m_tailIdx!=m_headIdx );

        constructHelper( &m_pBuf[m_headIdx], value );
    }

    // UNDONE: template< class... Args > void emplace_front( Args&&... args ); (начиная с C++11)

    void pop_front()
    {
        UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

        size_type newHeadIdx = (m_headIdx+1) & m_capacity; // SizeMask;  // На следующую заполненную
        destructHelper( &m_pBuf[m_headIdx] );
        m_headIdx = newHeadIdx;
    }

    void resize( size_type newSize ) // (начиная с C++11)
    {
        UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

         if ( newSize > size() )
         {
             while( newSize > size() )
             {
                 push_back( T() );
             }
         }
         else
         {
             while( newSize < size() )
             {
                 pop_back( );
             }
         }

    }

    void resize( size_type newSize, const value_type& value) // (начиная с C++11)
    {
        UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

        if ( newSize > size() )
        {
            while( newSize > size() )
            {
                push_back( value );
            }
        }
        else
        {
            while( newSize < size() )
            {
                pop_back( );
            }
        }
    }

    // UNDONE: void swap( static_cycle_deque &other )


    reference       at( size_type pos )
    {
        UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

        UMBA_ASSERT( pos < size() );
        return m_pBuf[ (m_headIdx + pos) & m_capacity /* SizeMask */  ];
    }

    const_reference at( size_type pos ) const
    {
        UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

        UMBA_ASSERT( pos < size() );
        return m_pBuf[ (m_headIdx + pos) & m_capacity /* SizeMask */  ];
    }

    reference       operator[]( size_type pos )
    {
        UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

        UMBA_ASSERT( pos < size() ); //  мы всех обманем, индекс тоже с проверкой
        return m_pBuf[ (m_headIdx + pos) & m_capacity /* SizeMask */  ];
    }

    const_reference operator[]( size_type pos ) const
    {
        UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

        UMBA_ASSERT( pos < size() ); //  мы всех обманем, индекс тоже с проверкой
        return m_pBuf[ (m_headIdx + pos) & m_capacity /* SizeMask */  ];
    }

    reference front()
    {
        UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

        UMBA_ASSERT( !empty() );
        return m_pBuf[ m_headIdx ];
    }

    const_reference front() const
    {
        UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

        UMBA_ASSERT( !empty() );
        return m_pBuf[ m_headIdx ];
    }

    reference back()
    {
        UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

        UMBA_ASSERT( !empty() );
        return m_pBuf[ m_tailIdx ];
    }

    const_reference back() const
    {
        UMBA_ASSERT(m_pBuf!=0); // Space not reserved. Please call 'reserve' first

        UMBA_ASSERT( !empty() );
        return m_pBuf[ m_tailIdx ];
    }

    void swap( static_cycle_deque &deq )
    {
        std::swap( this->m_capacity   , deq.m_capacity );
        std::swap( this->m_pBuf       , deq.m_pBuf );
        std::swap( this->m_headIdx    , deq.m_headIdx );
        std::swap( this->m_tailIdx    , deq.m_tailIdx );
        std::swap( this->m_allocator  , deq.m_allocator );
    }


}; // class static_cycle_deque




} // namespace containers
} // namespace umba

