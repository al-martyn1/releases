#pragma once

#include "umba/stl.h"
#include "umba/assert.h"
#include "umba/allocator.h"
#include "umba/utility.h"
#include "containers/reserve_size.h"
#include "containers/helpers.h"

#include <iterator>


#ifdef WIN32
    #include <string>
    #include <sstream>
#endif


//----------------------------------------------------------------------------
#define UMBA_CONTAINER_FORWARD_TYPEDEFS( ContanerClassName )                  \
    typedef ContanerClassName  container_type;                                \
    typedef typename ContanerClassName :: value_type        value_type     ;  \
    typedef typename ContanerClassName :: size_type         size_type      ;  \
    typedef typename ContanerClassName :: reference         reference      ;  \
    typedef typename ContanerClassName :: const_reference   const_reference;


#define UMBA_CONTAINER_DELEGATE_SIZE_METHODS( containerRef )                  \
    void shrink_to_fit()         { umba::utility::optional_shrink_to_fit(containerRef); } \
    void reserve( size_type sz ) { containerRef.reserve(sz);       }          \
    bool empty() const           { return containerRef.empty();    }          \
    size_type size() const       { return containerRef.size();     }          \
    size_type capacity() const   { return containerRef.capacity(); }

    // void shrink_to_fit()         { return containerRef.shrink_to_fit(); }

#define UMBA_CONTAINER_DELEGATE_SWAP( thisKlasse, containerRef )              \
    void swap( thisKlasse &q ) { containerRef . swap( q . containerRef ); }


#define UMBA_CONTAINER_DELEGATE_FRONT_BACK_METHODS( containerRef )            \
    reference front()             { return containerRef.front(); }            \
    const_reference front() const { return containerRef.front(); }            \
    reference back()              { return containerRef.back() ; }            \
    const_reference back() const  { return containerRef.back() ; }

#define UMBA_CONTAINER_IMPLEMENT_UNDERLYING_CONTAINER( containerRef )            \
    container_type&       underlying_container()       { return containerRef; }  \
    const container_type& underlying_container() const { return containerRef; }

//----------------------------------------------------------------------------




//----------------------------------------------------------------------------
namespace umba{
namespace containers{




//----------------------------------------------------------------------------
// Container can be
// static_cycle_deque<T>
// static_list<T>

template< class T
        , class Container
        >
class ref_queue_base
{

    UMBA_NON_COPYABLE_CLASS(ref_queue_base)

//protected:
//
//    ref_queue_base( const ref_queue_base &r ) : m_containerRef(r.m_containerRef) {}
//    ref_queue_base& operator=(const ref_queue_base &);

public:

    UMBA_CONTAINER_FORWARD_TYPEDEFS( Container )

    UMBA_CONTAINER_DELEGATE_SIZE_METHODS( m_containerRef )
    UMBA_CONTAINER_DELEGATE_SWAP( ref_queue_base, m_containerRef )
    UMBA_CONTAINER_DELEGATE_FRONT_BACK_METHODS( m_containerRef )
    UMBA_CONTAINER_IMPLEMENT_UNDERLYING_CONTAINER( m_containerRef )

    ref_queue_base( Container &c ) : m_containerRef(c) {}

    void clear()
    {
        this->m_containerRef.clear();
    }

    T pop( )
    {
        T t = front();
        this->m_containerRef.pop_front();
        return t;
    }

protected:

    container_type  &m_containerRef;

}; // class ref_queue_base

//----------------------------------------------------------------------------




//----------------------------------------------------------------------------
template< class T
        , class Container
        >
class ref_queue : public ref_queue_base< T, Container >
{

    UMBA_NON_COPYABLE_CLASS(ref_queue)

//protected:
//
//    ref_queue( const ref_queue &r ) : ref_queue_base(r) {}

public:

    UMBA_CONTAINER_FORWARD_TYPEDEFS( Container )

    ref_queue( Container &c ) : ref_queue_base< T, Container >(c) {}

    bool push( const value_type& value )
    {
        this->m_containerRef.push_back(value);
        return true;
    }

}; // class ref_queue

//----------------------------------------------------------------------------




//----------------------------------------------------------------------------
template< class T
        , class Container
        >
class safe_ref_queue : public ref_queue_base< T, Container >
{

    UMBA_NON_COPYABLE_CLASS(safe_ref_queue)

// protected:
//  
//     safe_ref_queue( const safe_ref_queue &r ) : ref_queue_base(r) {}

public:

    UMBA_CONTAINER_FORWARD_TYPEDEFS( Container )

    safe_ref_queue( Container &c ) : ref_queue_base< T, Container >(c) {}

    bool push( const value_type& value )
    {
        if (umba::containers::safe_available_capacity( *this ) > 0)
        {
           this->m_containerRef.push_back(value);
           return true;
        }

        return false;
    }

}; // class safe_ref_queue

//----------------------------------------------------------------------------







//----------------------------------------------------------------------------
// Container can be
// static_cycle_deque<T>
// static_list<T>

template< class T
        , class Container
        >
class queue_base
{

public:

    UMBA_CONTAINER_FORWARD_TYPEDEFS( Container )

    UMBA_CONTAINER_DELEGATE_SIZE_METHODS( m_container )
    UMBA_CONTAINER_DELEGATE_SWAP( queue_base, m_container )
    UMBA_CONTAINER_DELEGATE_FRONT_BACK_METHODS( m_container )
    UMBA_CONTAINER_IMPLEMENT_UNDERLYING_CONTAINER( m_container )

    queue_base( )                     : m_container()  {}
    queue_base( const Container  &c ) : m_container(c) {}
    queue_base( const queue_base &r ) : m_container(r.m_container) {}

    queue_base& operator=( const queue_base &r )
    {
        if (&r==this)
            return *this;

        queue_base q = queue_base(r);

        swap(q);

        return *this;
    }

    void clear()
    {
        this->m_container.clear();
    }

    T pop( )
    {
        T t = front();
        this->m_container.pop_front();
        return t;
    }

protected:

    container_type  m_container;

}; // class queue_base

//----------------------------------------------------------------------------




//----------------------------------------------------------------------------
template< class T
        , class Container
        >
class queue : public queue_base< T, Container >
{

public:

    UMBA_CONTAINER_FORWARD_TYPEDEFS( Container )

    queue( )                    : queue_base< T, Container >()  {}
    queue( const Container &c ) : queue_base< T, Container >(c) {}
    queue( const queue< T, Container > &r ) : queue_base< T, Container >(r) {}
    queue< T, Container > & operator=( const queue< T, Container > &r ) { queue_base< T, Container > ::operator=(r); return *this; }

    bool push( const value_type& value )
    {
        this->m_container.push_back(value);
        return true;
    }

}; // class queue

//----------------------------------------------------------------------------




//----------------------------------------------------------------------------
template< class T
        , class Container
        >
class safe_queue : public queue_base< T, Container >
{

public:

    UMBA_CONTAINER_FORWARD_TYPEDEFS( Container )

    safe_queue( )                    : queue_base< T, Container >()  {}
    safe_queue( const Container &c ) : queue_base< T, Container >(c) {}
    safe_queue( const safe_queue< T, Container > &r ) : queue_base< T, Container >(r) {}
    safe_queue< T, Container > & operator=( const safe_queue< T, Container > &r ) { queue_base< T, Container > ::operator=(r); return *this; }

    bool push( const value_type& value )
    {
        if (umba::containers::safe_available_capacity( *this ) > 0)
        {
           this->m_container.push_back(value);
           return true;
        }

        return false;
    }

}; // class safe_queue




} // namespace containers
} // namespace umba


