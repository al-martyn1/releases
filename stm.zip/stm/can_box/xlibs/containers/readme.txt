CRTP - Curiously recurring template pattern - https://ru.wikipedia.org/wiki/Curiously_recurring_template_pattern
