#pragma once

#include "umba/stl.h"

// umba::containers::
namespace umba{
namespace containers{

// Подсчет места, доступного без переаллокации
template<typename ContainerType> inline
typename ContainerType::size_type
safe_available_capacity( const ContainerType &container )
{
    return container.capacity() - container.size();
}


// https://habr.com/ru/post/205772/
// http://scrutator.me/post/2017/04/10/has_function_metaprogramming.aspx


} // namespace containers
} // namespace umba

