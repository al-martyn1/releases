#pragma once

#include "numerics_base.h"

namespace scalcus
{

//-----------------------------------------------------------------------------
// radians to degrees
inline
float radianToDegree( float r )
{
    return 180.0f * r / math_constants<float>::pi;
}

inline
double radianToDegree( double r )
{
    return 180.0  * r / math_constants<double>::pi;
}

//-----------------------------------------------------------------------------
inline
float degreeToRadian( float d )
{
    return math_constants<float>::pi * d/180.0f;
}

inline
double degreeToRadian( double d )
{
    return math_constants<double>::pi * d/180.0;
}

//-----------------------------------------------------------------------------
// convert from range (-pi, pi) to range (0, 2pi)
inline
float radianPiTo2Pi( float r )
{
    return (r < 0.0f) ? (2*math_constants<float>::pi + r) : (r);
}

inline
double radianPiTo2Pi( double r )
{
    return (r < 0.0 ) ? (2*math_constants<double>::pi + r) : (r);
}

//-----------------------------------------------------------------------------
// convert from range (-180, 180) to range (0, 360)
inline
float degree180To360( float r )
{
    return (r < 0.0f) ? (360.0f + r) : (r);
}

inline
double degree180To360( double r )
{
    return (r < 0.0 ) ? (360.0  + r) : (r);
}

//-----------------------------------------------------------------------------
inline
float radianMod2Pi( float r )
{
    return std::fmod( r, 2*math_constants<float>::pi );
}

//-----------------------------------------------------------------------------
inline
double radianMod2Pi( double r )
{
    return std::fmod( r, 2*math_constants<double>::pi );
}

//-----------------------------------------------------------------------------
inline
float degreeMod360( float r )
{
    return std::fmod( r, 360.0f );
}

//-----------------------------------------------------------------------------
inline
double degreeMod360( double r )
{
    return std::fmod( r, 360.0 );
}





// 1) делить на ноль - нельзя

//    На самом деле можно, но нам всё равно надо проверять, не? Чтобы не поделить 0 на 0
// деление на ноль вполне работает на плавающий числах
//http://ideone.com/Sb30I8

// https://habr.com/ru/post/112953/


//   
// 2) (модуль установлен в начальное положение камерой вверх)
//    При вращении по часовой на первых 90 градусах x = -1 ..  0 ; y = 0 .. 1
//                                         далее    x =  0 .. -1 ; y = 1 .. 0
//    tan =  y/x
//    при прохождении x через точку 0 (y при этом проходит через 1)
//    имеем 1/0 - равно бесконечности, но с разным знаком 
//    Арктангенс - функция нечетная, и меняет знак результата вслед за знаком аргумента
//    И это проблема - угол у нас из -90 прыгнет сразу в +90 и будет уменьшаться до 0
//    Если y > 0, то смотрим вправо, и тогда можно считать угол как - ( 180 - (положительный угол) )
//    = -180 + (положительный угол)
//    Если Y < 0, то смотрим влево, и имеет всё ровно тоже, с точностью до знака числа
//    - от 0 до 90 градусов знак положительный, затем меняется и от -90 подходит к 0: 180 + (отрицательный)

// Были приведены рассуждения для вершины

// y - numerator
// x - denominator

inline
float arctangent( float numerator, float denominator )
{
    // отнормируем на всякий случай
    // или не надо?
    float len = std::sqrt( numerator*numerator + denominator*denominator);
    numerator   /= len;
    denominator /= len;

    if ( scalcus::isZero(std::abs(denominator)) )
    {
        if (numerator<0)
        {
            return   math_constants<float>::pi;
        }
        else
        {
            return - math_constants<float>::pi;
        }
    }
    else
    {
        float res = std::atan( numerator / denominator );

        if (numerator>0)
        {
            if (res<0)
                return res;
            return - math_constants<float>::pi + res;
        }
        else
        {
            if (res>0)
                return res;
            return math_constants<float>::pi + res;
        }
    }
}

inline
double arctangent( double numerator, double denominator )
{
    // отнормируем на всякий случай
    // или не надо?
    double len = std::sqrt( numerator*numerator + denominator*denominator);
    numerator   /= len;
    denominator /= len;

    if ( scalcus::isZero(std::abs(denominator)) )
    {
        if (numerator<0)
        {
            return   math_constants<double>::pi;
        }
        else
        {
            return - math_constants<double>::pi;
        }
    }
    else
    {
        double res = std::atan( numerator / denominator );

        if (numerator>0)
        {
            if (res<0)
                return res;
            return - math_constants<double>::pi + res;
        }
        else
        {
            if (res>0)
                return res;
            return math_constants<double>::pi + res;
        }
    }
}






} // namespace scalcus


