Simple calculations and primitive math
