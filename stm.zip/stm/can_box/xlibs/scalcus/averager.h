#pragma once



#include <algorithm>


namespace scalcus
{


template< typename ValueType, typename SumType, size_t MaxSize = 64u >
class Averager
{

public:

    void reset()
    {
        m_numStored = 0;
    }

    void setMaxCount( size_t maxNumber )
    {
        m_maxNumber = maxNumber;
        if (m_maxNumber>MaxSize)
            m_maxNumber = MaxSize;
        reset();
    }

    ValueType getMax()
    {
        ValueType m = 0;
        const ValueType * b = &m_values[0];
        const ValueType * e = &m_values[m_numStored];

        if (b!=e)
        {
            m = *b;
            ++b;
        }

        for( ; b!=e; ++b )
        {

            if (m<*b)
                m = *b;
        }

        return m;
    }

    ValueType getMin()
    {
        ValueType m = 0;
        const ValueType * b = &m_values[0];
        const ValueType * e = &m_values[m_numStored];

        if (b!=e)
        {
            m = *b;
            ++b;
        }

        for( ; b!=e; ++b )
        {

            if (m>*b)
                m = *b;
        }

        return m;
    }

    ValueType getAverageValue( )
    {
        //UMBA_RTKOS_LOG<<"A :    ";

        // simple print it
        printVals(&m_values[0], &m_values[m_numStored]);

        return calcAverageValue( &m_values[0], &m_values[m_numStored] );
    }

    ValueType getMedianValue( )
    {
        ValueType    values[MaxSize];

        //UMBA_RTKOS_LOG<<"M :    ";

        for(size_t i=0; i!=m_numStored; ++i)
        {
            values[i] = m_values[i];
        }

        printVals(&values[0], &values[m_numStored]);

        std::sort( &values[0], &values[m_numStored] );
        //UMBA_RTKOS_LOG<<"    S  ";
        printVals(&values[0], &values[m_numStored]);

        return values[m_numStored/2];
    }

    ValueType getAverageMedianValue( )
    {
        ValueType    values[MaxSize];
        
        //UMBA_RTKOS_LOG<<"MA:    ";

        for(size_t i=0; i!=m_numStored; ++i)
        {
            values[i] = m_values[i];
        }

        printVals(&values[0], &values[m_numStored]);

        std::sort( &values[0], &values[m_numStored] );

        //UMBA_RTKOS_LOG<<"    S  ";
        printVals(&values[0], &values[m_numStored]);

        size_t windowSize   = m_numStored / 2;
        size_t windowOffset = m_numStored / 4;
        if (windowSize>=16)
        {
            windowSize   = m_numStored / 4;
            windowOffset = m_numStored / 8;
        }

        return calcAverageValue( &values[windowOffset], &values[windowOffset+windowSize] );
    }

    void addValue( ValueType curVal )
    {
        m_values[m_curIndex++] = curVal;

        m_numStored++;

        if (m_numStored>m_maxNumber)
            m_numStored = m_maxNumber;

        if (m_curIndex>=m_numStored) // wrap index
            m_curIndex = 0;
    }


protected:


    ValueType calcAverageValue( const ValueType *B, const ValueType *E  )
    {
        //size_t cnt = 0;
        const ValueType *orgB = B;
        SumType sum = 0;
        for( ; B!=E; ++B )
        {
            sum += (SumType)*B;
        }

        return (ValueType)( sum / (SumType)(E-orgB) );
    }

    void printVals( const ValueType *B, const ValueType *E  )
    {
        for( ; B!=E; ++B )
        {
            //UMBA_RTKOS_LOG<<umba::omanip::width(3)<<*B<<" ";
        }
        //UMBA_RTKOS_LOG<<"\n";
    }
    


    ValueType    m_values[MaxSize];
    size_t       m_maxNumber = MaxSize;
    size_t       m_numStored = 0;
    size_t       m_curIndex  = 0;


};


constexpr size_t  average_times_1  =  1;
constexpr size_t  average_times_2  =  2;
constexpr size_t  average_times_3  =  3;
constexpr size_t  average_times_4  =  4;
constexpr size_t  average_times_5  =  5;
constexpr size_t  average_times_6  =  6;
constexpr size_t  average_times_7  =  7;
constexpr size_t  average_times_8  =  8;
constexpr size_t  average_times_9  =  9;
constexpr size_t  average_times_10 = 10;
constexpr size_t  average_times_11 = 11;
constexpr size_t  average_times_12 = 12;
constexpr size_t  average_times_13 = 13;
constexpr size_t  average_times_14 = 14;
constexpr size_t  average_times_15 = 15;
constexpr size_t  average_times_16 = 16;
constexpr size_t  average_times_17 = 17;
constexpr size_t  average_times_18 = 18;
constexpr size_t  average_times_19 = 19;
constexpr size_t  average_times_20 = 20;
constexpr size_t  average_times_21 = 21;
constexpr size_t  average_times_22 = 22;
constexpr size_t  average_times_23 = 23;
constexpr size_t  average_times_24 = 24;
constexpr size_t  average_times_25 = 25;
constexpr size_t  average_times_26 = 26;
constexpr size_t  average_times_27 = 27;
constexpr size_t  average_times_28 = 28;
constexpr size_t  average_times_29 = 29;
constexpr size_t  average_times_30 = 30;
constexpr size_t  average_times_31 = 31;
constexpr size_t  average_times_32 = 32;
constexpr size_t  average_times_33 = 33;
constexpr size_t  average_times_34 = 34;
constexpr size_t  average_times_35 = 35;
constexpr size_t  average_times_36 = 36;
constexpr size_t  average_times_37 = 37;
constexpr size_t  average_times_38 = 38;
constexpr size_t  average_times_39 = 39;
constexpr size_t  average_times_40 = 40;
constexpr size_t  average_times_41 = 41;
constexpr size_t  average_times_42 = 42;
constexpr size_t  average_times_43 = 43;
constexpr size_t  average_times_44 = 44;
constexpr size_t  average_times_45 = 45;
constexpr size_t  average_times_46 = 46;
constexpr size_t  average_times_47 = 47;
constexpr size_t  average_times_48 = 48;
constexpr size_t  average_times_49 = 49;
constexpr size_t  average_times_50 = 50;
constexpr size_t  average_times_51 = 51;
constexpr size_t  average_times_52 = 52;
constexpr size_t  average_times_53 = 53;
constexpr size_t  average_times_54 = 54;
constexpr size_t  average_times_55 = 55;
constexpr size_t  average_times_56 = 56;
constexpr size_t  average_times_57 = 57;
constexpr size_t  average_times_58 = 58;
constexpr size_t  average_times_59 = 59;
constexpr size_t  average_times_60 = 60;
constexpr size_t  average_times_61 = 61;
constexpr size_t  average_times_62 = 62;
constexpr size_t  average_times_63 = 63;
constexpr size_t  average_times_64 = 64;
constexpr size_t  average_times_65 = 65;
constexpr size_t  average_times_66 = 66;
constexpr size_t  average_times_67 = 67;
constexpr size_t  average_times_68 = 68;
constexpr size_t  average_times_69 = 69;
constexpr size_t  average_times_70 = 70;
constexpr size_t  average_times_71 = 71;
constexpr size_t  average_times_72 = 72;
constexpr size_t  average_times_73 = 73;
constexpr size_t  average_times_74 = 74;
constexpr size_t  average_times_75 = 75;
constexpr size_t  average_times_76 = 76;
constexpr size_t  average_times_77 = 77;
constexpr size_t  average_times_78 = 78;
constexpr size_t  average_times_79 = 79;
constexpr size_t  average_times_80 = 80;
constexpr size_t  average_times_81 = 81;
constexpr size_t  average_times_82 = 82;
constexpr size_t  average_times_83 = 83;
constexpr size_t  average_times_84 = 84;
constexpr size_t  average_times_85 = 85;
constexpr size_t  average_times_86 = 86;
constexpr size_t  average_times_87 = 87;
constexpr size_t  average_times_88 = 88;
constexpr size_t  average_times_89 = 89;
constexpr size_t  average_times_90 = 90;
constexpr size_t  average_times_91 = 91;
constexpr size_t  average_times_92 = 92;
constexpr size_t  average_times_93 = 93;
constexpr size_t  average_times_94 = 94;
constexpr size_t  average_times_95 = 95;
constexpr size_t  average_times_96 = 96;
constexpr size_t  average_times_97 = 97;
constexpr size_t  average_times_98 = 98;
constexpr size_t  average_times_99 = 99;
constexpr size_t  average_times_100 = 100;


} // namespace scalcus

