#pragma once

#include "percent.h"


namespace scalcus
{

class PidController
{

public:

    PidController( double Kp = 1.0
                 , double Ki = 0.0
                 , double Kd = 0.0
                 , double limMinus = -10.0
                 , double limPlus  =  10.0
                 )
    : m_Kp(Kp)
    , m_Ki(Ki)
    , m_Kd(Kd)
    , m_prevEt(0.0)
    , m_prevI(0.0)
    , m_limMinus(limMinus)
    , m_limPlus (limPlus )
    {
    }

    //! Следует вызывать сброс в тех случаях, когда нет возможности "перерегулирования" вниз
    //! что вызывает накопление интегральной части
    void reset()
    {
        m_prevI  = 0.0;
        m_prevEt = 0.0;
    }

    void setScales( double kP, double kI, double kD )
    {
        m_Kp = kP;
        m_Ki = kI;
        m_Kd = kD;
        reset();
    }

    void setLimits( double limMinus, double limPlus )
    {
        m_limMinus = m_limMinus;
        m_limPlus  = m_limPlus ;
    }

    double getKp() const
    {
        return m_Kp;
    }

    double getKi() const
    {
        return m_Ki;
    }

    double getKd() const
    {
        return m_Kd;
    }

    double getIntegral()
    {
        return m_prevI;
    }

    void clamp( double &v, double limMinus, double limPlus)
    {
        /*
        if( v > limPlus )
            v = limPlus;

        else if( v < limMinus )
            v = limMinus;
        */
    }

    double calculateImpact( double setValue, double curValue, double timeScale )
    {
        #ifdef SIMPLE_PID_USE_SIMPLE_SCALE
        double Kp = m_Kp*timeScale;
        double Ki = m_Ki*timeScale;
        double Kd = m_Kd*timeScale;
        #else
        double Kp = m_Kp; // *timeScale;
        double Ki = m_Ki*timeScale;
        double Kd = m_Kd/timeScale;
        #endif

        //SMP_PID_BLOCKING_PRINT("Base   Kx -                      Kp: %8.6f, Ki: %8.6f, Kd: %8.6f\n",            m_Kp, m_Ki, m_Kd );
        //SMP_PID_BLOCKING_PRINT("Scaled Kx - timeScale: %8.6f, Kp: %8.6f, Ki: %8.6f, Kd: %8.6f\n", timeScale,   Kp,   Ki,   Kd );
        //SMP_PID_BLOCKING_PRINT("setValue: %8.6f, curValue: %8.6f\n", setValue, curValue );

        double et = setValue - curValue;

        //SMP_PID_BLOCKING_PRINT("et: %8.6f, prev: %8.6f\n", et, m_prevEt);

        double P = Kp * et;

        //SMP_PID_BLOCKING_PRINT("P: %8.6f\n", P);

        double I = m_prevI + Ki * et;

        //SMP_PID_BLOCKING_PRINT("I: %8.6f, I(t-1): %8.6f \n", I, m_prevI);

        double deltaEt = et - m_prevEt;
        double D = Kd * ( deltaEt );

        //SMP_PID_BLOCKING_PRINT("D: %8.6f, deltaEt: %8.6f \n", D, deltaEt);

        m_prevEt = et;
        m_prevI  = I;

        clamp( m_prevI, m_limMinus, m_limMinus );

        double res = P + I + D;

        //SMP_PID_BLOCKING_PRINT("Impact: %8.6f (%8.6f + %8.6f + %8.6f)\n\n\n", res, P, I, D );

        return res;
    }


    template< typename MasterType, typename SlaveType>
    SlaveType calculateImpact( MasterType setVal   , MasterType curVal
                             , MasterType masterMin, MasterType masterMax
                             , SlaveType  slaveMin , SlaveType  slaveMax
                             , double timeScale
                             )
    {
        MasterType setValPermille = calcPermille< MasterType >( setVal, masterMin, masterMax );
        MasterType curValPermille = calcPermille< MasterType >( curVal, masterMin, masterMax );
        MasterType impactPermille = calculateImpact( setValPermille, curValPermille, timeScale );
        
        MasterType impactPermilleNormalized = impactPermille;

        //clamp( m_prevI, limMinus, limMinus );
        if (impactPermilleNormalized < (MasterType)0)
        {
            impactPermilleNormalized = (MasterType)0;
            //reset();
         }

        if (impactPermilleNormalized > (MasterType)1000)
        {
            impactPermilleNormalized = (MasterType)1000;
        }

        SlaveType res = calcValueFromPermille( impactPermille, slaveMin , slaveMax );
        if (res<slaveMin)
            res = slaveMin;

        if (res>slaveMax)
            res = slaveMax;

        return res;
    }

private:

    double m_Kp;
    double m_Ki;
    double m_Kd;

    double m_prevEt;
    double m_prevI;

    double m_limMinus;
    double m_limPlus;

}; // class PidController




} // namespace scalcus

