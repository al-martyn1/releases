#pragma once

namespace scalcus
{

constexpr int signum( int64_t t )
{
    return t<0 ? -1 : ( t>0 ? 1 : 0 );
}

constexpr int signum( int32_t t )
{
    return t<0 ? -1 : ( t>0 ? 1 : 0 );
}

constexpr int signum( int16_t t )
{
    return t<0 ? -1 : ( t>0 ? 1 : 0 );
}

constexpr int signum( int8_t t )
{
    return t<0 ? -1 : ( t>0 ? 1 : 0 );
}

constexpr int signum( uint64_t t )
{
    return t>0 ? 1 : 0;
}

constexpr int signum( uint32_t t )
{
    return t>0 ? 1 : 0;
}

constexpr int signum( uint16_t t )
{
    return t>0 ? 1 : 0;
}

constexpr int signum( uint8_t t )
{
    return t>0 ? 1 : 0;
}

constexpr int signum( float t )
{
    return t<(-0.0f) ? -1 : ( t>(+0.0f) ? 1 : 0 );
}

constexpr int signum( double t )
{
    return t<(-0.0) ? -1 : ( t>(+0.0) ? 1 : 0 );
}







} // namespace scalcus

