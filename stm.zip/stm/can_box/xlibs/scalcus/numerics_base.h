#pragma once

#include <cmath>

namespace scalcus
{


// https://ru.wikipedia.org/wiki/%D0%9A%D0%B0%D1%82%D0%B5%D0%B3%D0%BE%D1%80%D0%B8%D1%8F:%D0%9C%D0%B0%D1%82%D0%B5%D0%BC%D0%B0%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B8%D0%B5_%D0%BA%D0%BE%D0%BD%D1%81%D1%82%D0%B0%D0%BD%D1%82%D1%8B
// https://ru.wikipedia.org/wiki/%D0%9C%D0%B0%D1%82%D0%B5%D0%BC%D0%B0%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B0%D1%8F_%D0%BA%D0%BE%D0%BD%D1%81%D1%82%D0%B0%D0%BD%D1%82%D0%B0
template<typename T>
struct math_constants
{
};

 // 7-8 десятичных цифр
template<>
struct math_constants<float>
{
    typedef float value_type;
    // https://en.wikipedia.org/wiki/Pi
    // 3.14159265358979323846264338327950288
    constexpr static value_type pi          = 3.1415926536f;
    constexpr static value_type pi_2        = pi/2.0f;
    constexpr static value_type pi_3        = pi/3.0f;
    constexpr static value_type pi_4        = pi/4.0f;

    // https://ru.wikipedia.org/wiki/%D0%9C%D0%B0%D1%82%D0%B5%D0%BC%D0%B0%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B0%D1%8F_%D0%BA%D0%BE%D0%BD%D1%81%D1%82%D0%B0%D0%BD%D1%82%D0%B0
    // 2.71828182845904523536028747135266249775724709369995
    constexpr static value_type e           = 2.7182818285f;

    // https://en.wikipedia.org/wiki/Square_root_of_2
    // 1.41421356237309504880168872420969807856967187537694807317667973799
    constexpr static value_type sqrt2       = 1.4142135624f;

    // https://en.wikipedia.org/wiki/Square_root_of_3
    // 1.73205080756887729352744634150587236694280525381038062805580
    constexpr static value_type sqrt3       = 1.7320508076f;

    // https://en.wikipedia.org/wiki/Square_root_of_5    
    // 2.23606797749978969640917366873127623544061835961152572427089
    constexpr static value_type sqrt5       = 2.2360679775f;
    
};

 // 15-6 десятичных цифр
template<>
struct math_constants<double>
{
    typedef double value_type;
    // https://en.wikipedia.org/wiki/Pi
    // 3.14159265358979323846264338327950288
    constexpr static value_type pi          = 3.14159265358979323846264338327950288;
    constexpr static value_type pi_2        = pi/2.0f;
    constexpr static value_type pi_3        = pi/3.0f;
    constexpr static value_type pi_4        = pi/4.0f;

    // https://ru.wikipedia.org/wiki/%D0%9C%D0%B0%D1%82%D0%B5%D0%BC%D0%B0%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B0%D1%8F_%D0%BA%D0%BE%D0%BD%D1%81%D1%82%D0%B0%D0%BD%D1%82%D0%B0
    // 2.71828182845904523536028747135266249775724709369995
    constexpr static value_type e           = 2.71828182845904523536028747135266249775724709369995;

    // https://en.wikipedia.org/wiki/Square_root_of_2
    // 1.41421356237309504880168872420969807856967187537694807317667973799
    constexpr static value_type sqrt2       = 1.41421356237309504880168872420969807856967187537694807317667973799;

    // https://en.wikipedia.org/wiki/Square_root_of_3
    // 1.73205080756887729352744634150587236694280525381038062805580
    constexpr static value_type sqrt3       = 1.73205080756887729352744634150587236694280525381038062805580;

    // https://en.wikipedia.org/wiki/Square_root_of_5    
    // 2.23606797749978969640917366873127623544061835961152572427089
    constexpr static value_type sqrt5       = 2.23606797749978969640917366873127623544061835961152572427089;
    
};

 // XZ десятичных цифр
template<>
struct math_constants<long double>
{
    typedef long double value_type;
    // https://en.wikipedia.org/wiki/Pi
    // 3.14159265358979323846264338327950288
    constexpr static value_type pi          = 3.14159265358979323846264338327950288;
    constexpr static value_type pi_2        = pi/2.0f;
    constexpr static value_type pi_3        = pi/3.0f;
    constexpr static value_type pi_4        = pi/4.0f;

    // https://ru.wikipedia.org/wiki/%D0%9C%D0%B0%D1%82%D0%B5%D0%BC%D0%B0%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B0%D1%8F_%D0%BA%D0%BE%D0%BD%D1%81%D1%82%D0%B0%D0%BD%D1%82%D0%B0
    // 2.71828182845904523536028747135266249775724709369995
    constexpr static value_type e           = 2.71828182845904523536028747135266249775724709369995;

    // https://en.wikipedia.org/wiki/Square_root_of_2
    // 1.41421356237309504880168872420969807856967187537694807317667973799
    constexpr static value_type sqrt2       = 1.41421356237309504880168872420969807856967187537694807317667973799;

    // https://en.wikipedia.org/wiki/Square_root_of_3
    // 1.73205080756887729352744634150587236694280525381038062805580
    constexpr static value_type sqrt3       = 1.73205080756887729352744634150587236694280525381038062805580;

    // https://en.wikipedia.org/wiki/Square_root_of_5    
    // 2.23606797749978969640917366873127623544061835961152572427089
    constexpr static value_type sqrt5       = 2.23606797749978969640917366873127623544061835961152572427089;
    
};


                                     


template< typename T >
inline
bool isZero( T t )
{
    return t==0;
}

template< typename T >
inline
bool isInf( T t )
{
    return std::isinf( t );
}

template< typename T >
inline
bool isNan( T t )
{
    return std::isnan( t );
}

//template<typename T>
//std::abs


} // namespace scalcus

