#pragma once

#include <utility>
#include "umba/time_service.h"
#include "umba/assert.h"


namespace scalcus
{

/*
    Задаем пары - входная скорость в процентах -> время, за которое привод прошел от нуля до максимума.
    Задаются точки, в которых угловой коэффициент графика меняется.
    Теперь, для каждой скорости мы можем посчитать реальную скорость перемещения в ппг/сек,
    и, зная реальную скорость и прошедшее время, мы можем приблизительно вычислить текущую позицию

    Первая точка задает минимально допустимую скорость, последняя - максимальную.

    Максимальное время прохождения диапазона 4294.967 секунд

*/

class DcMotorPositioningHelper
{

public:

    typedef umba::time_service::TimeTick      TimeTick;
    typedef std::pair<unsigned, TimeTick>     SpeedTimePair; 

    DcMotorPositioningHelper( float range, float zeroOffset, SpeedTimePair *pSpeedToTime, size_t speedToTimeSize )
    : m_range(range)
    , m_zeroOffset(zeroOffset)
    , m_pSpeedToTime(pSpeedToTime)
    , m_speedToTimeSize(speedToTimeSize)
    {
        UMBA_ASSERT( m_speedToTimeSize >= 1 );
        UMBA_ASSERT( m_pSpeedToTime );

        // по дефолту - нет коррекции
        m_maxSpeedTimeCorrection = m_pSpeedToTime[m_speedToTimeSize-1].second;
    }

    void setMaxSpeedTimeCorrection( TimeTick maxSpeedTimeCorrection )
    {
        if (!maxSpeedTimeCorrection)
            return;
        m_maxSpeedTimeCorrection = maxSpeedTimeCorrection;
    }

    unsigned getSpeedMin() const
    {
        UMBA_ASSERT( m_speedToTimeSize >= 1 );
        UMBA_ASSERT( m_pSpeedToTime );
        
        return m_pSpeedToTime[0].first;
    }

    unsigned getSpeedMax() const
    {
        UMBA_ASSERT( m_speedToTimeSize >= 1 );
        UMBA_ASSERT( m_pSpeedToTime );

        return m_pSpeedToTime[m_speedToTimeSize-1].first;
    }

    int8_t adjustSpeed( int8_t s ) const
    {
        int8_t sAbs  = s<0 ? -s : s;
        int8_t sSign = s<0 ? -1 : 1;

        int8_t min8 = (int8_t)getSpeedMin();
        int8_t max8 = (int8_t)getSpeedMax();

        if (sAbs<min8)
            sAbs = min8;

        if (sAbs>max8)
            sAbs = max8;

        return sAbs*sSign;
    }

    TimeTick getSpeedMaxTime() const
    {
        UMBA_ASSERT( m_speedToTimeSize >= 1 );
        UMBA_ASSERT( m_pSpeedToTime );

        return m_pSpeedToTime[m_speedToTimeSize-1].second;
    }

    TimeTick getMaxSpeedTime() const
    {
        return getSpeedMaxTime();
    }

    // in parrots per sec - pps
    float calcRealSpeed( unsigned motorSpeedPercent ) const
    {
        UMBA_ASSERT( m_speedToTimeSize >= 1 );
        UMBA_ASSERT( m_pSpeedToTime );

        size_t i = 0, N = m_speedToTimeSize-1;
        for(; i!=N; ++i)
        {
            unsigned stepSpeedMin = m_pSpeedToTime[i].first;
            unsigned stepSpeedMax = m_pSpeedToTime[i+1].first;
            if (motorSpeedPercent>=stepSpeedMin && motorSpeedPercent<=stepSpeedMax)
               break;
        }

        if (i==N)
        {
            // Не попали ни в один диапазон
            if (motorSpeedPercent<m_pSpeedToTime[0].first)
                i = 0;
            else if (motorSpeedPercent>m_pSpeedToTime[m_speedToTimeSize-1].first)
                i = m_speedToTimeSize-1;
        }
        //UMBA_ASSERT( i!=N );

        TimeTick tableMaxSpeedTick = m_pSpeedToTime[m_speedToTimeSize-1].second;

        UMBA_ASSERT( m_maxSpeedTimeCorrection != 0 ); // must be set

        unsigned correctionPermille = 1000 * tableMaxSpeedTick / m_maxSpeedTimeCorrection;

        unsigned dSpeedCur   = motorSpeedPercent - m_pSpeedToTime[i].first;
        unsigned dSpeedRange = m_pSpeedToTime[i+1].first - m_pSpeedToTime[i].first;

        // Время прохождения должно убывать при увеличении скорости. Или хотя бы не уменьшаться
        TimeTick dT = m_pSpeedToTime[i].second - m_pSpeedToTime[i+1].second;

        TimeTick timeForTakenSpeed = m_pSpeedToTime[i].second - (TimeTick)(dT*dSpeedCur / dSpeedRange);

        TimeTick timeForTakenSpeedCorrected = 1000 * timeForTakenSpeed / correctionPermille;

        float t = (float)(timeForTakenSpeedCorrected) / 1000.0f;

        return m_range / t;
    }

    float calcRealSpeed( int motorSpeedPercent ) const
    {
        if (motorSpeedPercent < 0)
            return -calcRealSpeed( (unsigned)-motorSpeedPercent );
        return calcRealSpeed( (unsigned)motorSpeedPercent );
    }

    float calcDistance( int motorSpeedPercent, TimeTick workingTime ) const
    {
        return calcRealSpeed( motorSpeedPercent ) * (((float)workingTime) / 1000.0f)*m_scale;
    }

    void setScale( float scale )
    {
        m_scale = scale;
    }

    float getRange() const
    {
        return m_range;
    }

    float getZeroOffset() const
    {
        return m_zeroOffset;
    }
/*
    float getZeroAdjusted( float value ) const
    {
        return value - m_zeroOffset;
    }
*/

protected:

    float               m_range;
    float               m_zeroOffset;
    float               m_scale = 1.0f;

    SpeedTimePair      *m_pSpeedToTime;
    size_t              m_speedToTimeSize;

    TimeTick            m_maxSpeedTimeCorrection = 0; // Текущее измеренное время прохода на маскимальной скорости - для коррекции табличных данных

}; // class DcMotorPositioningHelper


} // namespace scalcus

