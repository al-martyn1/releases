#pragma once

#include "umba/umba.h"
#include "umba/assert.h"

#include "numerics_base.h"

namespace scalcus
{


// round - https://en.cppreference.com/w/cpp/numeric/math/round

// Computes the nearest integer value to arg (in floating-point format), rounding halfway cases away from zero
template< typename T>
inline
long lround( T t )
{
    if (isZero(t))
        return 0;

    UMBA_ASSERT(!isInf(t));
    UMBA_ASSERT(!isNan(t));

    if ( t < (T)0.0 )
        return (long)( t - (T)0.5 );
    else
        return (long)( t + (T)0.5 );
}

// Computes the nearest integer value to arg (in floating-point format), rounding halfway cases away from zero
template< typename T>
inline
T round( T t )
{
    if (isZero(t) || isInf(t))
        return t;

    return (T)lround(t);
}


// floor - https://en.cppreference.com/w/cpp/numeric/math/floor
// ceil  - https://en.cppreference.com/w/cpp/numeric/math/ceil




} // namespace scalcus

