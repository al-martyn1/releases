#pragma once


namespace scalcus
{


//-----------------------------------------------------------------------------
template<typename T>
inline
T calcPercent(T val, T rangeMin, T rangeMax)
{
    T range = rangeMax - rangeMin;
    T valShifted = val - rangeMin;
    return ((T)100)*valShifted/range;
}

//-----------------------------------------------------------------------------
template<typename T>
inline
T calcPermille(T val, T rangeMin, T rangeMax)
{
    T range = rangeMax - rangeMin;
    T valShifted = val - rangeMin;
    return ((T)1000)*valShifted/range;
}

//-----------------------------------------------------------------------------
template<typename TP, typename T>
inline
T calcValueFromPermille(TP permille, T rangeMin, T rangeMax)
{
    T range = rangeMax - rangeMin;
    return rangeMin + range * (T)permille / ((T)1000);
}

//-----------------------------------------------------------------------------
template<typename TP, typename T>
inline
T calcValueFromPercent(TP permille, T rangeMin, T rangeMax)
{
    T range = rangeMax - rangeMin;
    return rangeMin + range * (T)permille / ((T)100);
}






} // namespace scalcus



