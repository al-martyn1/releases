#pragma once

#include "numerics_base.h"
#include "averager.h"
#include "can.h"
#include "percent.h"
#include "pid.h"
#include "pwm.h"
#include "round.h"
#include "signum.h"
#include "trigonom.h"

#include "dc_motor_positioning.h"
