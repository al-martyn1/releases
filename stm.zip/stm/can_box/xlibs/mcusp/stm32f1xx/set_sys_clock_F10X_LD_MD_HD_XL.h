static void SetSysClock(void)
{

#if defined(DISABLE_FREQ_USAGE) || !defined(FREQ)

    #ifdef SYSCLK_FREQ_HSE
      SetSysClockToHSE();
    #elif defined SYSCLK_FREQ_24MHz
      SetSysClockTo24();
    #elif defined SYSCLK_FREQ_36MHz
      SetSysClockTo36();
    #elif defined SYSCLK_FREQ_48MHz
      SetSysClockTo48();
    #elif defined SYSCLK_FREQ_56MHz
      SetSysClockTo56();  
    #elif defined SYSCLK_FREQ_72MHz
      SetSysClockTo72();
    #endif

#else

    

#if 0

    MCUSP_MACRO_CONCAT_EXPAND2( SetSysClockTo , FREQ )();

#else

// Сопировал из трешки, там все работает, а в сотке - непонятно. Куб одно показывает, реф ман - совсе м другое.
// Поэтому пока оставил первый вараинт, который на говне

// UPD Таки надо переделывать, потому что я сам не понял, что сделал, а именно - самое главное - независимость от кварца 
// я так и не переделал. Собирался, да забыл.

// У сотки ёбанная схема тактирования, но можно забить хрен на всякие PLL2/PLL3. Тем более, в Кубе так и сделано



  __IO uint32_t StartUpCounter = 0, HSEStatus = 0;
  
  /* SYSCLK, HCLK, PCLK2 and PCLK1 configuration ---------------------------*/    
  /* Enable HSE */    
  RCC->CR |= ((uint32_t)RCC_CR_HSEON);
 
  /* Wait till HSE is ready and if Time out is reached exit */
  do
  {
    HSEStatus = RCC->CR & RCC_CR_HSERDY;
    StartUpCounter++;  
  } while((HSEStatus == 0) && (StartUpCounter != HSE_STARTUP_TIMEOUT));

  if ((RCC->CR & RCC_CR_HSERDY) != RESET)
  {
    HSEStatus = (uint32_t)0x01;
  }
  else
  {
    HSEStatus = (uint32_t)0x00;
  }  

  if (HSEStatus == (uint32_t)0x01)
  {

        {
            #if defined(STM32_FEATURE_NUM_FREQ)
                const uint32_t maxHCLK = STM32_FEATURE_NUM_FREQ;
                const uint32_t maxAPB2 = STM32_FEATURE_NUM_FREQ;
                const uint32_t maxAPB1 = STM32_FEATURE_NUM_FREQ / 2;
            #else
                const uint32_t maxHCLK = 72*1000*1000,
                const uint32_t maxAPB1 = 36*1000*1000,
                const uint32_t maxAPB2 = 72*1000*1000,
            #endif

            const uint32_t hse = HSE_VALUE;

            #if (HSE_VALUE < 4000000u)
                #error "HSE_VALUE must be between 4000000 and 16000000"
            #endif

            #if (HSE_VALUE >16000000u)
                #error "HSE_VALUE must be between 4000000 and 16000000"
            #endif

            //uint8_t 
            unsigned
                      foundGoodScales = 0;

            //uint8_t   
            unsigned  //PREDIV2     = 0
                    //, PLL2MUL     = 0
                      PREDIV1     = 0
                    , PLLMUL      = 0
                    , OTGFSPRE    = 0
                    , HPRE        = 0
                    , PPRE1       = 0
                    , PPRE2       = 0;

            //uint32_t  
            unsigned
                      SYSCLK_FREQ = 0
                    , HCLK_FREQ   = 0 // AHB
                    , APB1_FREQ   = 0 // PCLK1
                    , APB2_FREQ   = 0 // PCLK2
                    ;
             
                                                      // 1101   0111   0110   0101   0100   0011   0010  
            //static const uint8_t PLLMUL_values   [7] = { 0x0Du, 0x07u, 0x06u, 0x05u, 0x04u, 0x03u, 0x02u };
            //static const uint8_t PLLMUL_factors  [7] = {   13u,    9u,    8u,    7u,    6u,    5u,    4u };
            //static const uint8_t PLLMUL_divisors [7] = {    2u,    1u,    1u,    1u,    1u,    1u,    1u };

            // PLLMUL 0 -> x2
            // PLLMUL 1 -> x3

            /*
            OTGFSPRE: Bit 22 of RCC->CFGR - USB OTG FS prescaler
            Set and cleared by software to generate the 48 MHz USB OTG FS clock. This bit must be valid
            before enabling the OTG FS clock in the RCC_APB1ENR register. This bit can not be cleared if the OTG FS clock is enabled.
                0: PLL VCO (2 × PLLCLK) clock is divided by 3 (PLL must be configured to output 72 MHz)
                1: PLL VCO (2 × PLLCLK) clock is divided by 2 (PLL must be configured to output 48 MHz)
            */
            static const uint8_t OTGFSPRE_values   [2] = { 0x0u, 0x1u };
            static const uint8_t OTGFSPRE_divisors [2] = {   3u,   2u };


            /* HPRE[3:0]: Bits 7:4 of RCC->CFGR - AHB prescaler
            0xxx: SYSCLK not divided
            1000: SYSCLK divided by 2
            1001: SYSCLK divided by 4
            1010: SYSCLK divided by 8
            1011: SYSCLK divided by 16
            1100: SYSCLK divided by 64
            1101: SYSCLK divided by 128
            1110: SYSCLK divided by 256
            1111: SYSCLK divided by 512
            */
                                               // 0xxx (0000)  1000   1001   1010   1011   1100   1101   1110   1111
            static const uint8_t HPRE_values   [9] = { 0x00u, 0x08u, 0x09u, 0x0Au, 0x0Bu, 0x0Cu, 0x0Du, 0x0Eu, 0x0Fu };
            /* calc divisor as
               uint32_t HPRE_divisor = HPRE_values[i]==0 ? 1 : (1<<((HPRE_values[i]&7)+1))
            */


            /*  PPRE1[2:0]: Bits 10:8 of RCC->CFGR - APB Low-speed prescaler (APB1)
                0xx: HCLK not divided
                100: HCLK divided by 2
                101: HCLK divided by 4
                110: HCLK divided by 8
                111: HCLK divided by 16
                Same as PPRE2
            */

            static const uint8_t PPRE1_values   [5] = { 0u, 4u,  5u,  6u,   7u };
            static const uint8_t PPRE1_divisors [5] = { 1u, 2u,  4u,  8u,  16u };


            /* PPRE2[2:0]: Bits 13:11 of RCC->CFGR - APB high-speed prescaler (APB2)
                0xx: HCLK not divided
                100: HCLK divided by 2
                101: HCLK divided by 4
                110: HCLK divided by 8
                111: HCLK divided by 16
                Same as PPRE1
            */
                                               // 0xx (000) 100  101  110  111
            static const uint8_t PPRE2_values   [5] = { 0u, 4u,  5u,  6u,   7u };
            static const uint8_t PPRE2_divisors [5] = { 1u, 2u,  4u,  8u,  16u };


            unsigned PREDIV1_idx = 0;

            unsigned PLLMUL_idx  = 0;

            uint32_t PREDIV1_divisor = 0;
            uint32_t PLL_InputFreq   = 0;

            uint32_t PLLMUL_factor  = 0;

            uint32_t PLL_OutputFreq = 0;

            unsigned PREDIV1_idx_end = 2;

            PREDIV1_idx = 0;
            
            for(; PREDIV1_idx!=PREDIV1_idx_end; ++PREDIV1_idx)
            {
                PREDIV1_divisor = PREDIV1_idx + 1;
                PLL_InputFreq   = hse / PREDIV1_divisor;

                PREDIV1 = PREDIV1_idx;
            
                {
                    PLLMUL_idx = 0;
                   
                    for(; PLLMUL_idx!=16; ++PLLMUL_idx)
                    {
                        unsigned  usbGood = 0;
                        PLLMUL_factor  = PLLMUL_idx+2;
                        PLL_OutputFreq = PLL_InputFreq * PLLMUL_factor;

                        /* STM32F100xx - Caution: The PLL output frequency must be in the 16-24 MHz range.
                           STM32F10X   - Caution: The PLL output frequency must not exceed 72 MHz.
                         */

                        #if defined(STM32F100)
                            if (PLL_OutputFreq<16000000u || PLL_OutputFreq>24000000u)
                                continue;
                        #else
                            if (PLL_OutputFreq>72000000u)
                                continue;
                        #endif

                        PLLMUL = PLLMUL_idx;
                   
                        #if defined(USB_OTG) || defined(USB_NO_OTG) || defined(USB_FS)
                            {
                                uint32_t USB_InputFreq = PLL_OutputFreq * 2;
                                unsigned  USB_idx = 0;

                                for(; USB_idx!=2; ++USB_idx)
                                {
                                    uint32_t USB_divisor = OTGFSPRE_divisors[USB_idx];
                                    uint32_t USB_Freq = USB_InputFreq / USB_divisor;
                                    if (USB_Freq==48000000)
                                    {
                                        OTGFSPRE = OTGFSPRE_values[USB_idx];
                                        usbGood  = 1;
                                        break;
                                    }
                                }
                            }

                        #else

                            usbGood = 1; // USB_not used, mark as always good

                        #endif

                        if (!usbGood)
                            continue;

                        SYSCLK_FREQ = PLL_OutputFreq;

                        if (SYSCLK_FREQ!=FREQ)
                            continue;

                        foundGoodScales = 1;

                        // And we need to find god dividers for AHB/APB buses

                        {
                            unsigned HPRE_idx = 0;
                            for(; HPRE_idx!=9; ++HPRE_idx)
                            {
                                uint32_t HPRE_divisor = HPRE_values[HPRE_idx]==0 ? 1 : (1<<((HPRE_values[HPRE_idx]&7)+1));
                                HCLK_FREQ = SYSCLK_FREQ / HPRE_divisor;
                                if (HCLK_FREQ<=maxHCLK)
                                {
                                    HPRE = HPRE_values[HPRE_idx];
                                    break;
                                }
                            }
                        }

                        {
                            unsigned PPRE1_idx = 0;
                            for(; PPRE1_idx!=5; ++PPRE1_idx)
                            {
                                uint32_t PPRE1_divisor = PPRE1_divisors[PPRE1_idx];
                                APB1_FREQ = HCLK_FREQ  / PPRE1_divisor;
                                if (APB1_FREQ<=maxAPB1)
                                {
                                    PPRE1 = PPRE1_values[PPRE1_idx];
                                    break;
                                }
                            }
                        }

                        {
                            unsigned PPRE2_idx = 0;
                            for(; PPRE2_idx!=5; ++PPRE2_idx)
                            {
                                uint32_t PPRE2_divisor = PPRE2_divisors[PPRE2_idx];
                                APB2_FREQ = HCLK_FREQ  / PPRE2_divisor;
                                if (APB2_FREQ<=maxAPB2)
                                {
                                    PPRE2 = PPRE2_values[PPRE2_idx];
                                    break;
                                }
                            }
                        }

                        if (foundGoodScales)
                            break;

                    } // for(size_t PLLMUL_idx

                } // extra scope

                if (foundGoodScales)
                    break;
            
            } // for(size_t PREDIV1_idx


            if (!foundGoodScales)
            {
                SystemInit_HandleClockInitFails();
            }


            // Фикс для совместимости с SPL
            if (HPRE==7)
                HPRE = 0;

            if (PPRE1==3)
                PPRE1 = 0;

            if (PPRE2==3)
                PPRE2 = 0;

            
            RCC->CFGR &= ~(  1<<22); // USBPRE / Bit 22 OTGFSPRE
            RCC->CFGR |= ((uint32_t)OTGFSPRE)<<22;

            RCC->CFGR &= ~(0xF<<18); // Bits 21:18 PLLMUL[3:0]: PLL multiplication factor
            RCC->CFGR |= ((uint32_t)PLLMUL)<<18;

            RCC->CFGR &= ~(  1<<17); // PLLXTPRE
            RCC->CFGR |= ((uint32_t)(PREDIV1&1))<<17;


            RCC->CFGR |= (  1<<16); // PLLSRC 
                                     // 1: Clock from PREDIV1 selected as PLL input clock

            RCC->CFGR &= ~(  7<<11); // PPRE2
            RCC->CFGR |= ((uint32_t)PPRE2)<<11;

            RCC->CFGR &= ~(  7<< 8); // PPRE1
            RCC->CFGR |= ((uint32_t)PPRE1)<<8;

            RCC->CFGR &= ~(0xF<< 4); // HPRE
            RCC->CFGR |= ((uint32_t)HPRE)<<4;

            /* CL - Connectivity line
               STM32F105VC/RC/VB/RB/V8/R8
               STM32F107VC/RC/VB/RB
             */
            #if defined(STM32F100)
                RCC->CFGR2 &= ~ (0xF)   ; // Clear PREDIV1
                RCC->CFGR2 |= (uint32_t)PREDIV1; // (PREDIV-1);
            #endif

            /* Enable Prefetch Buffer */
            FLASH->ACR |= FLASH_ACR_PRFTBE;

            FLASH->ACR &= ~(1<<3); // Bit 3 HLFCYA: Flash half cycle access enable
            // Half-cycle access cannot be used when there is a prescaler different from 1 on the AHB clock.
            if ( HPRE < 8 )
            {
                // AHB prescaler == 1
                //FLASH->ACR |= 1<<3;
                FLASH->ACR &= ~(1<<3); // half cycle
            }

            // Bits 2:0 LATENCY[2:0]: Latency
            // These bits represent the ratio of the HCLK period to the Flash access time.
            // 000: Zero wait state, if 0 < HCLK ≤ 24 MHz
            // 001: One wait state, if 24 MHz < HCLK ≤ 48 MHz
            // 010: Two wait sates, if 48 < HCLK ≤ 72 MHz

            uint32_t flashLatency = 0;
            if (HCLK_FREQ > 48000000)
                flashLatency = 2;
            else
            if (HCLK_FREQ > 24000000)
                flashLatency = 1;

            /* Flash 2 wait state */
            FLASH->ACR &= ~7; // Bits 2:0 LATENCY[2:0]: Latency
            FLASH->ACR |= flashLatency;

            //FLASH->ACR &= ~(1<<3); // half cycle

        }

    /* Enable PLL */
    //RCC->CR |= RCC_CR_PLLON;
    
    /* Wait till PLL is ready */
    //while((RCC->CR & RCC_CR_PLLRDY) == 0)
    //{
    //}

    {
        const uint32_t bit_pll_on   = 1<<24;
        const uint32_t bit_pll_rdy  = 1<<25;
        //const uint32_t bit_pll2_on  = 1<<26;
        //const uint32_t bit_pll2_rdy = 1<<27;

        const uint32_t bits_both_pll_rdy = bit_pll_rdy; // | bit_pll2_rdy;

        RCC->CR |= bit_pll_on; // | bit_pll2_on;

        while((RCC->CR&bits_both_pll_rdy)!=bits_both_pll_rdy) {}

    }
    
    /* Select PLL as system clock source */
    RCC->CFGR &= (uint32_t)((uint32_t)~(RCC_CFGR_SW));
    RCC->CFGR |= (uint32_t)RCC_CFGR_SW_PLL;
    
    /* Wait till PLL is used as system clock source */
    while ((RCC->CFGR & (uint32_t)RCC_CFGR_SWS) != (uint32_t)0x08)
    {
    }

  }
  else
  { /* If HSE fails to start-up, the application will have wrong clock 
         configuration. User can add here some code to deal with this error */
      SystemInit_HandleClockInitFails();
  }
#endif /* if 0 */


#endif

 /* If none of the define above is enabled, the HSI is used as System clock
    source (default after reset) */ 
}
