#pragma once

#include <stdint.h>

#include "cmsis_compiler.h"


// #include "inc/stm32f0xx_devices.h"
#include "inc/stm32f1xx_devices.h"
// #include "inc/stm32f2xx_devices.h"
#include "inc/stm32f3xx_devices.h"
#include "inc/stm32f4xx_devices.h"
// #include "inc/stm32f7xx_devices.h"
// #include "inc/stm32l0xx_devices.h"
#include "inc/stm32l1xx_devices.h"
//#include "inc/stm32l4xx_devices.h"
#include "inc/mdr1986bexx_devices.h"


#ifdef __cplusplus

extern     void SystemInit_HandleClockInitFails() __attribute__((weak));

#else

extern "C" void SystemInit_HandleClockInitFails() __attribute__((weak));

#endif


#if !defined(STM32F0_SERIES) && !defined(STM32F1_SERIES) && !defined(STM32F2_SERIES) && !defined(STM32F3_SERIES) && !defined(STM32F4_SERIES) && !defined(STM32F7_SERIES)\
                             && !defined(STM32L0_SERIES) && !defined(STM32L1_SERIES) && !defined(STM32L4_SERIES) \
                             && !defined(MILANDR)

    #error "Unknown target MCU"

#endif


#if !defined(CORTEX_M0) && !defined(CORTEX_M1) && !defined(CORTEX_M3) && !defined(CORTEX_M4) && !defined(CORTEX_M7)

    #error "Unknown target MCU Core"

#endif

// Helper used in cases without umba lib
//! Стрингификация - промежуточный макрос
#define MCUSP_STRINGIFY_HELPER(x)       #x

//! Стрингификация
#define MCUSP_STRINGIFY(x)              MCUSP_STRINGIFY_HELPER(x)

#define MCUSP_MACRO_EXPAND_HELPER(x)    x
#define MCUSP_MACRO_EXPAND(x)           MCUSP_MACRO_EXPAND_HELPER(x)

#define MCUSP_MACRO_CONCAT_EXPAND2_HELPER(a,b)    a##b
#define MCUSP_MACRO_CONCAT_EXPAND2(a,b)           MCUSP_MACRO_CONCAT_EXPAND2_HELPER(a,b)



// Define old cool macsos

#if defined(STM32F1_SERIES)


#elif defined(STM32F3_SERIES)

    // Old STM32F30X but supported definition
    #if defined(STM32F303)
        //#define STM32F30X
    #endif



    // 303xB, 303xC
    /*
    #if defined(STM32F303CB) || \
        defined(STM32F303CC) || \
        defined(STM32F303RB) || \
        defined(STM32F303RC) || \
        defined(STM32F303VB) || \
        defined(STM32F303VC)

        #define STM32F303xBxC
    
    // STM32F303xD STM32F303xE
    #elif defined(STM32F303RD) || \
          defined(STM32F303RE) || \
          defined(STM32F303VD) || \
          defined(STM32F303VE) || \
          defined(STM32F303ZD) || \
          defined(STM32F303ZE)
    
        #define STM32F303xDxE
        // STM32F303Rx STM32F303Vx STM32F303Zx
    
    #elif defined(STM32F303C6) || \
          defined(STM32F303C8) || \
          defined(STM32F303K6) || \
          defined(STM32F303K8) || \
          defined(STM32F303R6) || \
          defined(STM32F303R8)
    
        #define STM32F303x6x8
    
    #elif defined(STM32F358CC) || \
          defined(STM32F358RC) || \
          defined(STM32F358VC)

          #define STM32F358xC

    #elif defined(STM32F398VE)

          #define STM32F398xE

    #endif 
    */

    #if defined(STM32F301x8)

        #define STM32F301x6x8

    #elif defined(STM32F302x8)

        #define STM32F302x6x8

    #elif defined(STM32F302xC)

        #define STM32F302xBxC

    #elif defined(STM32F302xE)

        #define STM32F302xDxE

    #elif defined(STM32F303x8)

        #define STM32F303x6x8

    #elif defined(STM32F303xC)

        #define STM32F303xBxC

    #elif defined(STM32F303xE)

        #define STM32F303xDxE

    #elif defined(STM32F334x8)

        #define STM32F334x6x8

    #elif defined(STM32F373xC)

        #define STM32F373xBxC

    #elif defined(STM32F318xx)

        #define STM32F318x6x8

    #elif defined(STM32F328xx)

        #define STM32F328x6x8

    #elif defined(STM32F358xx)

        #define STM32F358xBxC

    #elif defined(STM32F378xx)

        #define STM32F378xBxC
        #define STM32F378xDxE

    #elif defined(STM32F398xx)

        #define STM32F398xDxE

    #endif

    /*
       Макрос STM32F303x8 ни как не используется и не проверяется 
       Там проверка такая:
       #if !defined (STM32F303xC) && !defined (STM32F334x8) && !defined (STM32F302x8) && !defined (STM32F303xE)
         #error "Please select first the target STM32F30X device used in your application (in stm32f30x.h file)"
       #endif

       Просто дописать STM32F303x8 в условие - не помогает, так как многие определения структур и перечислений зависят
       от перечисленных макросов, например typedef enum IRQn

       Попробуем одновременно к STM32F303x8 задать и STM32F303xC.

       При этом в нашем коде следует использовать определения STM32F303x6x8 и STM32F303xBxC, чтобы не попасться 
       на эту затычку.
    */

    #if defined(STM32F303x8)
        #define STM32F303xC
    #endif
   
    
    

#elif defined(STM32F4_SERIES)

    /*

    F4 MCUs

    STM32F401CB  STM32F401RB  STM32F401VB  STM32F401CC  STM32F401RC  STM32F401VC  STM32F401CD  STM32F401RD  STM32F401VD  STM32F401CE  STM32F401RE  STM32F401VE
    STM32F410CB  STM32F410RB  STM32F410TB  STM32F410C8  STM32F410R8  STM32F410T8  
    STM32F411CC  STM32F411RC  STM32F411VC  STM32F411CE  STM32F411RE  STM32F411VE
    STM32F412CE  STM32F412CG  STM32F412RE  STM32F412RG  STM32F412VE  STM32F412VG  STM32F412ZE  STM32F412ZG
    STM32F413ZH  STM32F413CH  STM32F413RH  STM32F413VH  STM32F413MH  STM32F413ZG  STM32F413CG  STM32F413RG  STM32F413VG  STM32F413MG
    STM32F423ZH  STM32F423CH  STM32F423RH  STM32F423VH  STM32F423MH
    STM32F405RG  STM32F405VG  STM32F405ZG  STM32F405OG  STM32F405OE
    STM32F407VG  STM32F407IG  STM32F407ZG  STM32F407VE  STM32F407ZE  STM32F407IE
    STM32F415RG  STM32F415VG  STM32F415ZG  STM32F415OG
    STM32F417VG  STM32F417IG  STM32F417ZG  STM32F417VE  STM32F417ZE  STM32F417IE
    STM32F427AG  STM32F427VG  STM32F427ZG  STM32F427IG  STM32F427AI  STM32F427VI  STM32F427ZI  STM32F427II
    STM32F429AG  STM32F429VG  STM32F429ZG  STM32F429IG  STM32F429AI  STM32F429VI  STM32F429ZI  STM32F429II  STM32F429VE  STM32F429ZE  STM32F429IE  
                 STM32F429BG  STM32F429BI  STM32F429BE  STM32F429NG  STM32F429NI  STM32F429NE
    STM32F437VG  STM32F437ZG  STM32F437IG  STM32F437AI  STM32F437VI  STM32F437ZI  STM32F437II
    STM32F439VG  STM32F439VI  STM32F439ZG  STM32F439ZI  STM32F439IG  STM32F439II  STM32F439BG  STM32F439BI  STM32F439NG  STM32F439NI  STM32F439AI
    STM32F446MC  STM32F446RC  STM32F446VC  STM32F446ZC  STM32F446ME  STM32F446RE  STM32F446VE  STM32F446ZE
    STM32F469AE  STM32F469AG  STM32F469AI  STM32F469IE  STM32F469IG  STM32F469II  STM32F469BE  STM32F469BG  STM32F469BI  STM32F469NE
                 STM32F469NG  STM32F469NI  STM32F469VE  STM32F469VG  STM32F469VI  STM32F469ZE  STM32F469ZG  STM32F469ZI
    STM32F479AG  STM32F479AI  STM32F479IG  STM32F479II  STM32F479BG  STM32F479BI  STM32F479NG  STM32F479NI  STM32F479VG  STM32F479VI  STM32F479ZG  STM32F479ZI


    F4 MCU Family defines

    STM32F401xx
    STM32F410xx
    STM32F411xx
    STM32F412xx
    STM32F413xx
    STM32F423xx
    STM32F405xx
    STM32F407xx
    STM32F415xx
    STM32F417xx
    STM32F427xx
    STM32F429xx
    STM32F437xx
    STM32F439xx
    STM32F446xx
    STM32F469xx
    STM32F479xx

    STM32F40_41xxx
    STM32F413_423xx
    STM32F427_437xx
    STM32F429_439xx
    STM32F469_479xx

    STM32F401xx
    STM32F410xx
    STM32F411xE
    STM32F412xG
    STM32F446xx

    */



    #ifdef STM32F401
        #ifndef STM32F401xx
            #define STM32F401xx
        #endif
    #endif

    #ifdef STM32F410
        #ifndef STM32F410xx
            #define STM32F410xx
        #endif
    #endif

    #ifdef STM32F411
        #ifndef STM32F411xx
            #define STM32F411xx
        #endif
    #endif

    #ifdef STM32F412
        #ifndef STM32F412xx
            #define STM32F412xx
        #endif
    #endif

    #ifdef STM32F413
        #ifndef STM32F413xx
            #define STM32F413xx
        #endif
    #endif

    #ifdef STM32F423
        #ifndef STM32F423xx
            #define STM32F423xx
        #endif
    #endif

    #ifdef STM32F405
        #ifndef STM32F405xx
            #define STM32F405xx
        #endif
    #endif

    #ifdef STM32F407
        #ifndef STM32F407xx
            #define STM32F407xx
        #endif
    #endif

    #ifdef STM32F415
        #ifndef STM32F415xx
            #define STM32F415xx
        #endif
    #endif

    #ifdef STM32F417
        #ifndef STM32F417xx
            #define STM32F417xx
        #endif
    #endif

    #ifdef STM32F427
        #ifndef STM32F427xx
            #define STM32F427xx
        #endif
    #endif

    #ifdef STM32F429
        #ifndef STM32F429xx
            #define STM32F429xx
        #endif
    #endif

    #ifdef STM32F437
        #ifndef STM32F437xx
            #define STM32F437xx
        #endif
    #endif

    #ifdef STM32F439
        #ifndef STM32F439xx
            #define STM32F439xx
        #endif
    #endif

    #ifdef STM32F446
        #ifndef STM32F446xx
            #define STM32F446xx
        #endif
    #endif

    #ifdef STM32F469
        #ifndef STM32F469xx
            #define STM32F469xx
        #endif
    #endif

    #ifdef STM32F479
        #ifndef STM32F479xx
            #define STM32F479xx
        #endif
    #endif
/*
    #ifdef 
        #ifndef 
            #define 
        #endif
    #endif
*/

    #if defined(STM32F401) || defined(STM32F405) || defined(STM32F407) || defined(STM32F410) || defined(STM32F411) || defined(STM32F412) || defined(STM32F413) || defined(STM32F415)
        #ifndef STM32F40_41xxx
            #define STM32F40_41xxx
        #endif
    #endif
  
    #if defined(STM32F413) || defined(STM32F423)
        #ifndef STM32F413_423xx
            #define STM32F413_423xx
        #endif
    #endif
  
    #if defined(STM32F427) || defined(STM32F437)
        #ifndef STM32F427_437xx
            #define STM32F427_437xx
        #endif
    #endif
  
    #if defined(STM32F429) || defined(STM32F439)
        #ifndef STM32F429_439xx
            #define STM32F429_439xx
        #endif
    #endif
  
    #if defined(STM32F469) || defined(STM32F479)
        #ifndef STM32F469_479xx
            #define STM32F469_479xx
        #endif
    #endif

#elif defined(STM32L1_SERIES)

#elif defined(MILANDR)

#endif



// HSE and FREQ checks&definitions

#if !defined(HSE)

    #if !defined(HSE_VALUE)

        //#error "Use 'HSE=NNNNNNN' to define both HSE_VALUE and USE_HSE"
        #if defined(__CC_ARM)
            #warning "Use new 'HSE=NNNNNNN' macro to define both HSE_VALUE and USE_HSE. Currently internal oscilator is used"
        #else
            #pragma message("Use new 'HSE=NNNNNNN' macro to define both HSE_VALUE and USE_HSE. Currently internal oscilator is used")
        #endif

    #else

        #define HSE HSE_VALUE

    #endif

#else // defined(HSE)

    #if defined(HSE_VALUE)
        #error "HSE and HSE_VALUE defined both"
    #endif

    #define HSE_VALUE HSE

#endif


#if defined(HSE_VALUE)

    #if !defined(USE_HSE)
        #define USE_HSE 1
    #endif

    #if (HSE_VALUE < 4000000) || (HSE_VALUE > 26000000)
        #error "HSE_VALUE must be between from 4000000 to 26000000"
    #endif

#endif




#if !defined(DISABLE_FREQ_USAGE)

    // New clock configuration scheme is used (not disabled)

    #if !defined(VOLTAGE)

        #define VOLTAGE 30

    #endif

    #if VOLTAGE < 17

        #error "MCU voltage is out of range (too low)"

    #elif VOLTAGE <= 21

        #define VOLTAGE_RANGE     3

    #elif VOLTAGE <= 24

        #define VOLTAGE_RANGE     2

    #elif VOLTAGE <= 27

        #define VOLTAGE_RANGE     1

    #elif VOLTAGE <= 36

        #define VOLTAGE_RANGE     0

    #else

        #error "MCU voltage is out of range (too high)"

    #endif

    #define VOLTAGE_RANGE_21  3
    #define VOLTAGE_RANGE_24  2
    #define VOLTAGE_RANGE_27  1
    #define VOLTAGE_RANGE_36  0



    // Prechecks for FREQ
    #if !defined(FREQ)
    
        // If default max freq defined for this MCU, use it
        #if defined(STM32_FEATURE_NUM_FREQ)
            #define FREQ STM32_FEATURE_NUM_FREQ
        #endif
    
    #endif


    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES)
    
        // Stolen from system_stm32f10x.h
        #if defined (STM32F10X_LD_VL) || (defined STM32F10X_MD_VL) || (defined STM32F10X_HD_VL)
    
            #if defined(FREQ)
    
                #if FREQ>24000000
                    #error "STM32F1xx LDVD/MDVL/HDVL devices supports only 24000000 Hz max frequency"
                #endif
    
            #else
    
                #define FREQ  24000000
    
            #endif
    
        #else
    
            #if defined(FREQ)
    
                // На самом деле это максималочки, проверять их так не совсем корректно
                // А может, и не максималочки вовсе, а просто круглые значения с потолка
    
                //#if FREQ!=24000000 && FREQ!=36000000 && FREQ!=48000000 && FREQ!=56000000 && FREQ!=72000000
                //    #error "STM32F1/3xx devices supports only 24000000/36000000/48000000/56000000/72000000 Hz frequency"
                //#endif
    
            #else
        
                #define FREQ  72000000
                #if defined(__CC_ARM)
                    #warning "STM32F1/3xx - FREQ not defined, used default 72000000, but valid values also are 24000000/36000000/48000000/56000000"
                #else
                    #pragma message("STM32F1/3xx - FREQ not defined, used default 72000000, but valid values also are 24000000/36000000/48000000/56000000")
                #endif
    
            #endif
    
        #endif
    
    #elif defined(STM32F4_SERIES)
    
            #if !defined(FREQ)

                // Зададим максималочки

                #if   defined(STM32F401xx)

                    #define FREQ 84000000
                
                #elif defined(STM32F410xx) || defined(STM32F411xx) || defined(STM32F412xx) || \
                      defined(STM32F413xx) || defined(STM32F423xx)

                    #define FREQ 100000000
                    
                #elif defined(STM32F405xx) || defined(STM32F407xx) || defined(STM32F415xx) || \
                      defined(STM32F417xx)

                    #define FREQ 168000000
                    
                #elif defined(STM32F427xx) || defined(STM32F429xx) || defined(STM32F437xx) || \
                      defined(STM32F439xx) || defined(STM32F446xx) || defined(STM32F469xx) || \
                      defined(STM32F479xx)

                    #define FREQ 180000000

                #else

                    #error "Please select the target STM32F4xx device used in your application or define FREQ macro"
                    
                #endif

            #endif

            // Проверим максималочки

            #if   defined(STM32F401xx)

                #if FREQ>84000000
                    #error "Too big FREQ value for this MCU"
                #endif
            
            #elif defined(STM32F410xx) || defined(STM32F411xx) || defined(STM32F412xx) || \
                  defined(STM32F413xx) || defined(STM32F423xx)

                #if FREQ>100000000
                    #error "Too big FREQ value for this MCU"
                #endif
                
            #elif defined(STM32F405xx) || defined(STM32F407xx) || defined(STM32F415xx) || \
                  defined(STM32F417xx)

                #if FREQ>168000000
                    #error "Too big FREQ value for this MCU"
                #endif
                
            #elif defined(STM32F427xx) || defined(STM32F429xx) || defined(STM32F437xx) || \
                  defined(STM32F439xx) || defined(STM32F446xx) || defined(STM32F469xx) || \
                  defined(STM32F479xx)

                #if FREQ>180000000
                    #error "Too big FREQ value for this MCU"
                #endif
                
            #endif
    
    #else // UNKNOWN_SERIES
    
        #error "Usupported MCU family detected, please defined FREQ value manualy"
    
    #endif // *_SERIES


    #if defined(FREQ)

        // Simple test that freq is aliquot to 100000 KHz
        #if ((FREQ / 100000)*100000) != FREQ
            #error "Invalid MCU core frequncy taken - check the FREQ macro definition"
        #endif

        #if defined(MCU_DETECTION_MESSAGE)

            // Тут, сцуко, никак нельзя вывести значение макроса, поэтому делаем в тупую для основных значений
            #if FREQ==24000000
                #if defined(__CC_ARM)
                    #warning "Note: Selected MCU FREQ: 24000000"
                #else
                    #pragma message( "Note: Selected MCU FREQ: 24000000" )
                #endif
            #elif FREQ==36000000
                #if defined(__CC_ARM)
                    #warning "Note: Selected MCU FREQ: 36000000"
                #else
                    #pragma message( "Note: Selected MCU FREQ: 36000000" )
                #endif
            #elif FREQ==48000000
                #if defined(__CC_ARM)
                    #warning "Note: Selected MCU FREQ: 48000000"
                #else
                    #pragma message( "Note: Selected MCU FREQ: 48000000" )
                #endif
            #elif FREQ==56000000
                #if defined(__CC_ARM)
                    #warning "Note: Selected MCU FREQ: 56000000"
                #else
                    #pragma message( "Note: Selected MCU FREQ: 56000000" )
                #endif
            #elif FREQ==72000000
                #if defined(__CC_ARM)
                    #warning "Note: Selected MCU FREQ: 72000000"
                #else
                    #pragma message( "Note: Selected MCU FREQ: 72000000" )
                #endif
            #elif FREQ==80000000
                #if defined(__CC_ARM)
                    #warning "Note: Selected MCU FREQ: 80000000"
                #else
                    #pragma message( "Note: Selected MCU FREQ: 80000000" )
                #endif
            #elif FREQ==84000000
                #if defined(__CC_ARM)
                    #warning "Note: Selected MCU FREQ: 84000000"
                #else
                    #pragma message( "Note: Selected MCU FREQ: 84000000" )
                #endif
            #elif FREQ==100000000
                #if defined(__CC_ARM)
                    #warning "Note: Selected MCU FREQ: 100000000"
                #else
                    #pragma message( "Note: Selected MCU FREQ: 100000000" )
                #endif
            #elif FREQ==168000000
                #if defined(__CC_ARM)
                    #warning "Note: Selected MCU FREQ: 168000000"
                #else
                    #pragma message( "Note: Selected MCU FREQ: 168000000" )
                #endif
            #elif FREQ==180000000
                #if defined(__CC_ARM)
                    #warning "Note: Selected MCU FREQ: 180000000"
                #else
                    #pragma message( "Note: Selected MCU FREQ: 180000000" )
                #endif
            #else
                #if defined(__CC_ARM)
                    #warning "Note: Selected MCU FREQ: unknown"
                #else
                    #pragma message( "Note: Selected MCU FREQ: unknown" )
                #endif
            #endif
       
        #endif /* defined(MCU_DETECTION_MESSAGE) */

    #endif


#endif // !defined(DISABLE_FREQ_USAGE)

/*
PLLP: Main PLL (PLL) division factor for main system clock.
      Set and cleared by software to control the frequency of the general PLL output clock.

      The software has to set these bits correctly not to exceed 168 MHz on this domain.

PLL output clock frequency = VCO frequency / PLLP with PLLP = 2, 4, 6, or 8


PLLN:
VCO output frequency = VCO input frequency x PLLN, 50 <= PLLN <= 432


PLLM: Division factor for the main PLL (PLL) and audio PLL (PLLI2S) input clock
Set and cleared by software to divide the PLL and PLLI2S input clock before the VCO.

VCO input frequency = PLL input clock frequency / PLLM with 2 ≤ PLLM ≤ 63
*/

/*
#ifdef USE_HSE

    #if   defined(STM32F401xx)
        uint32_t SystemCoreClock = 84000000;
    
    #elif defined(STM32F410xx) || defined(STM32F411xx) || defined(STM32F412xx) || \
          defined(STM32F413xx) || defined(STM32F423xx)
        uint32_t SystemCoreClock = 100000000;
        
    #elif defined(STM32F405xx) || defined(STM32F407xx) || defined(STM32F415xx) || \
          defined(STM32F417xx)
        uint32_t SystemCoreClock = 168000000;
        
    #elif defined(STM32F427xx) || defined(STM32F429xx) || defined(STM32F437xx) || \
          defined(STM32F439xx) || defined(STM32F446xx) || defined(STM32F469xx) || \
          defined(STM32F479xx)
        uint32_t SystemCoreClock = 180000000;
    #else
        #error "Please select the target STM32F4xx device used in your application"
        
    #endif
    
#else // USE_HSE / // Если тактируемся от внутреннего источника
////////////////////////////////////////////////////////////////////////////////

        uint32_t SystemCoreClock = 16000000;

////////////////////////////////////////////////////////////////////////////////
// МОДИФИЦИРОВАНО! 
#endif // USE_HSE 
*/








#if defined(DEFINE_FPU_MPU)

    #ifdef __FPU_PRESENT
        #undef __FPU_PRESENT
        #define __FPU_PRESENT 1U
    #endif
     
    #ifdef __MPU_PRESENT
        #undef __MPU_PRESENT
        #define __MPU_PRESENT 1U
    #endif

#endif /* defined(DEFINE_FPU_MPU) */


#if defined(STM32F1_SERIES)

    #include "stm32f1xx/inc/stm32f10x.h"
    #include "stm32f1xx/inc/system_stm32f10x.h"

#elif defined(STM32F3_SERIES)

    #include "stm32f3xx/inc/stm32f30x.h"
    #include "stm32f3xx/inc/system_stm32f30x.h"

#elif defined(STM32F4_SERIES)

    #include "stm32f4xx/inc/stm32f4xx.h"
    #include "stm32f4xx/inc/system_stm32f4xx.h"

#elif defined(STM32L1_SERIES)

    #include "stm32l1xx/inc/stm32l1xx.h"
    #include "stm32l1xx/inc/system_stm32l1xx.h"

#elif defined(MILANDR)

#endif


#if defined(CORTEX_M0)
    #include "core_cm0.h"
#elif defined(CORTEX_M1)
    //#include ""
#elif defined(CORTEX_M3)
    #include "core_cm3.h"
#elif defined(CORTEX_M4)
    #include "core_cm4.h"
#elif defined(CORTEX_M7)
    #include "core_cm7.h"
#endif


