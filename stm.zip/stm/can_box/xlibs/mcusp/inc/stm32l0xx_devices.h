#pragma once

// Automatically umba-mm-pdsc generated file
// Universal definitions file for STM32/derived devices - C language

// input  : stm32l0xx_devices.xml
// output : ..\inc\stm32l0xx_devices.h

#if !defined(STM32L0XX_DEVICES_XML____INC_STM32L0XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00)
#define STM32L0XX_DEVICES_XML____INC_STM32L0XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00

// name     : STM32L011D3
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L011
#if defined(STM32L011D3)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L011D3"
            #else
                #pragma message("Note: Selected MCU - STM32L011D3")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

#endif /* defined(STM32L011D3) */


// name     : STM32L011D4
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L011
#if defined(STM32L011D4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L011D4"
            #else
                #pragma message("Note: Selected MCU - STM32L011D4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

#endif /* defined(STM32L011D4) */


// name     : STM32L011E4
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L011
#if defined(STM32L011E4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L011E4"
            #else
                #pragma message("Note: Selected MCU - STM32L011E4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

#endif /* defined(STM32L011E4) */


// name     : STM32L011F3
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L011
#if defined(STM32L011F3)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L011F3"
            #else
                #pragma message("Note: Selected MCU - STM32L011F3")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

#endif /* defined(STM32L011F3) */


// name     : STM32L011F4
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L011
#if defined(STM32L011F4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L011F4"
            #else
                #pragma message("Note: Selected MCU - STM32L011F4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

#endif /* defined(STM32L011F4) */


// name     : STM32L011G3
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L011
#if defined(STM32L011G3)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L011G3"
            #else
                #pragma message("Note: Selected MCU - STM32L011G3")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

#endif /* defined(STM32L011G3) */


// name     : STM32L011G4
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L011
#if defined(STM32L011G4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L011G4"
            #else
                #pragma message("Note: Selected MCU - STM32L011G4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

#endif /* defined(STM32L011G4) */


// name     : STM32L011K3
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L011
#if defined(STM32L011K3)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L011K3"
            #else
                #pragma message("Note: Selected MCU - STM32L011K3")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

#endif /* defined(STM32L011K3) */


// name     : STM32L011K4
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L011
#if defined(STM32L011K4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L011K4"
            #else
                #pragma message("Note: Selected MCU - STM32L011K4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L011)
        #define STM32L011
    #endif

#endif /* defined(STM32L011K4) */


// name     : STM32L021D4
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L021
#if defined(STM32L021D4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L021D4"
            #else
                #pragma message("Note: Selected MCU - STM32L021D4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L021)
        #define STM32L021
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L021)
        #define STM32L021
    #endif

#endif /* defined(STM32L021D4) */


// name     : STM32L021F4
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L021
#if defined(STM32L021F4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L021F4"
            #else
                #pragma message("Note: Selected MCU - STM32L021F4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L021)
        #define STM32L021
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L021)
        #define STM32L021
    #endif

#endif /* defined(STM32L021F4) */


// name     : STM32L021G4
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L021
#if defined(STM32L021G4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L021G4"
            #else
                #pragma message("Note: Selected MCU - STM32L021G4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L021)
        #define STM32L021
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L021)
        #define STM32L021
    #endif

#endif /* defined(STM32L021G4) */


// name     : STM32L021K4
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L021
#if defined(STM32L021K4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L021K4"
            #else
                #pragma message("Note: Selected MCU - STM32L021K4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L021)
        #define STM32L021
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L021)
        #define STM32L021
    #endif

#endif /* defined(STM32L021K4) */


// name     : STM32L031C4
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L031
#if defined(STM32L031C4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L031C4"
            #else
                #pragma message("Note: Selected MCU - STM32L031C4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

#endif /* defined(STM32L031C4) */


// name     : STM32L031C6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L031
#if defined(STM32L031C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L031C6"
            #else
                #pragma message("Note: Selected MCU - STM32L031C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

#endif /* defined(STM32L031C6) */


// name     : STM32L031E4
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L031
#if defined(STM32L031E4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L031E4"
            #else
                #pragma message("Note: Selected MCU - STM32L031E4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

#endif /* defined(STM32L031E4) */


// name     : STM32L031E6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L031
#if defined(STM32L031E6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L031E6"
            #else
                #pragma message("Note: Selected MCU - STM32L031E6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

#endif /* defined(STM32L031E6) */


// name     : STM32L031F4
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L031
#if defined(STM32L031F4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L031F4"
            #else
                #pragma message("Note: Selected MCU - STM32L031F4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

#endif /* defined(STM32L031F4) */


// name     : STM32L031F6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L031
#if defined(STM32L031F6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L031F6"
            #else
                #pragma message("Note: Selected MCU - STM32L031F6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

#endif /* defined(STM32L031F6) */


// name     : STM32L031G4
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L031
#if defined(STM32L031G4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L031G4"
            #else
                #pragma message("Note: Selected MCU - STM32L031G4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

#endif /* defined(STM32L031G4) */


// name     : STM32L031G6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L031
#if defined(STM32L031G6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L031G6"
            #else
                #pragma message("Note: Selected MCU - STM32L031G6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

#endif /* defined(STM32L031G6) */


// name     : STM32L031K4
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L031
#if defined(STM32L031K4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L031K4"
            #else
                #pragma message("Note: Selected MCU - STM32L031K4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

#endif /* defined(STM32L031K4) */


// name     : STM32L031K6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L031
#if defined(STM32L031K6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L031K6"
            #else
                #pragma message("Note: Selected MCU - STM32L031K6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L031)
        #define STM32L031
    #endif

#endif /* defined(STM32L031K6) */


// name     : STM32L041C4
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L041
#if defined(STM32L041C4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L041C4"
            #else
                #pragma message("Note: Selected MCU - STM32L041C4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L041)
        #define STM32L041
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L041)
        #define STM32L041
    #endif

#endif /* defined(STM32L041C4) */


// name     : STM32L041C6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L041
#if defined(STM32L041C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L041C6"
            #else
                #pragma message("Note: Selected MCU - STM32L041C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L041)
        #define STM32L041
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L041)
        #define STM32L041
    #endif

#endif /* defined(STM32L041C6) */


// name     : STM32L041F6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L041
#if defined(STM32L041F6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L041F6"
            #else
                #pragma message("Note: Selected MCU - STM32L041F6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L041)
        #define STM32L041
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L041)
        #define STM32L041
    #endif

#endif /* defined(STM32L041F6) */


// name     : STM32L041G6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L041
#if defined(STM32L041G6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L041G6"
            #else
                #pragma message("Note: Selected MCU - STM32L041G6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L041)
        #define STM32L041
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L041)
        #define STM32L041
    #endif

#endif /* defined(STM32L041G6) */


// name     : STM32L041K6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L041
#if defined(STM32L041K6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L041K6"
            #else
                #pragma message("Note: Selected MCU - STM32L041K6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L041)
        #define STM32L041
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L041)
        #define STM32L041
    #endif

#endif /* defined(STM32L041K6) */


// name     : STM32L041E6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L041
#if defined(STM32L041E6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L041E6"
            #else
                #pragma message("Note: Selected MCU - STM32L041E6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L041)
        #define STM32L041
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L041)
        #define STM32L041
    #endif

#endif /* defined(STM32L041E6) */


// name     : STM32L051C6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L051
#if defined(STM32L051C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L051C6"
            #else
                #pragma message("Note: Selected MCU - STM32L051C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L051)
        #define STM32L051
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L051)
        #define STM32L051
    #endif

#endif /* defined(STM32L051C6) */


// name     : STM32L051C8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L051
#if defined(STM32L051C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L051C8"
            #else
                #pragma message("Note: Selected MCU - STM32L051C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L051)
        #define STM32L051
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L051)
        #define STM32L051
    #endif

#endif /* defined(STM32L051C8) */


// name     : STM32L051K6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L051
#if defined(STM32L051K6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L051K6"
            #else
                #pragma message("Note: Selected MCU - STM32L051K6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L051)
        #define STM32L051
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    27
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L051)
        #define STM32L051
    #endif

#endif /* defined(STM32L051K6) */


// name     : STM32L051K8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L051
#if defined(STM32L051K8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L051K8"
            #else
                #pragma message("Note: Selected MCU - STM32L051K8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L051)
        #define STM32L051
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    27
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L051)
        #define STM32L051
    #endif

#endif /* defined(STM32L051K8) */


// name     : STM32L051R6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L051
#if defined(STM32L051R6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L051R6"
            #else
                #pragma message("Note: Selected MCU - STM32L051R6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L051)
        #define STM32L051
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L051)
        #define STM32L051
    #endif

#endif /* defined(STM32L051R6) */


// name     : STM32L051R8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L051
#if defined(STM32L051R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L051R8"
            #else
                #pragma message("Note: Selected MCU - STM32L051R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L051)
        #define STM32L051
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L051)
        #define STM32L051
    #endif

#endif /* defined(STM32L051R8) */


// name     : STM32L051T6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L051
#if defined(STM32L051T6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L051T6"
            #else
                #pragma message("Note: Selected MCU - STM32L051T6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L051)
        #define STM32L051
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L051)
        #define STM32L051
    #endif

#endif /* defined(STM32L051T6) */


// name     : STM32L051T8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L051
#if defined(STM32L051T8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L051T8"
            #else
                #pragma message("Note: Selected MCU - STM32L051T8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L051)
        #define STM32L051
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L051)
        #define STM32L051
    #endif

#endif /* defined(STM32L051T8) */


// name     : STM32L052C6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L052
#if defined(STM32L052C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L052C6"
            #else
                #pragma message("Note: Selected MCU - STM32L052C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L052)
        #define STM32L052
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TOUCH)
        #define STM32_FEATURE_NUM_TOUCH    24
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L052)
        #define STM32L052
    #endif

#endif /* defined(STM32L052C6) */


// name     : STM32L052C8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L052
#if defined(STM32L052C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L052C8"
            #else
                #pragma message("Note: Selected MCU - STM32L052C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L052)
        #define STM32L052
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TOUCH)
        #define STM32_FEATURE_NUM_TOUCH    24
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L052)
        #define STM32L052
    #endif

#endif /* defined(STM32L052C8) */


// name     : STM32L052K6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L052
#if defined(STM32L052K6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L052K6"
            #else
                #pragma message("Note: Selected MCU - STM32L052K6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L052)
        #define STM32L052
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    27
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TOUCH)
        #define STM32_FEATURE_NUM_TOUCH    24
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L052)
        #define STM32L052
    #endif

#endif /* defined(STM32L052K6) */


// name     : STM32L052K8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L052
#if defined(STM32L052K8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L052K8"
            #else
                #pragma message("Note: Selected MCU - STM32L052K8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L052)
        #define STM32L052
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    27
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TOUCH)
        #define STM32_FEATURE_NUM_TOUCH    24
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L052)
        #define STM32L052
    #endif

#endif /* defined(STM32L052K8) */


// name     : STM32L052R6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L052
#if defined(STM32L052R6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L052R6"
            #else
                #pragma message("Note: Selected MCU - STM32L052R6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L052)
        #define STM32L052
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TOUCH)
        #define STM32_FEATURE_NUM_TOUCH    24
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L052)
        #define STM32L052
    #endif

#endif /* defined(STM32L052R6) */


// name     : STM32L052R8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L052
#if defined(STM32L052R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L052R8"
            #else
                #pragma message("Note: Selected MCU - STM32L052R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L052)
        #define STM32L052
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TOUCH)
        #define STM32_FEATURE_NUM_TOUCH    24
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L052)
        #define STM32L052
    #endif

#endif /* defined(STM32L052R8) */


// name     : STM32L052T6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L052
#if defined(STM32L052T6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L052T6"
            #else
                #pragma message("Note: Selected MCU - STM32L052T6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L052)
        #define STM32L052
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TOUCH)
        #define STM32_FEATURE_NUM_TOUCH    24
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L052)
        #define STM32L052
    #endif

#endif /* defined(STM32L052T6) */


// name     : STM32L052T8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L052
#if defined(STM32L052T8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L052T8"
            #else
                #pragma message("Note: Selected MCU - STM32L052T8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L052)
        #define STM32L052
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TOUCH)
        #define STM32_FEATURE_NUM_TOUCH    24
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L052)
        #define STM32L052
    #endif

#endif /* defined(STM32L052T8) */


// name     : STM32L053C6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L053
#if defined(STM32L053C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L053C6"
            #else
                #pragma message("Note: Selected MCU - STM32L053C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L053)
        #define STM32L053
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TOUCH)
        #define STM32_FEATURE_NUM_TOUCH    24
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L053)
        #define STM32L053
    #endif

#endif /* defined(STM32L053C6) */


// name     : STM32L053C8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L053
#if defined(STM32L053C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L053C8"
            #else
                #pragma message("Note: Selected MCU - STM32L053C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L053)
        #define STM32L053
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TOUCH)
        #define STM32_FEATURE_NUM_TOUCH    24
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L053)
        #define STM32L053
    #endif

#endif /* defined(STM32L053C8) */


// name     : STM32L053R6
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L053
#if defined(STM32L053R6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L053R6"
            #else
                #pragma message("Note: Selected MCU - STM32L053R6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L053)
        #define STM32L053
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TOUCH)
        #define STM32_FEATURE_NUM_TOUCH    24
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L053)
        #define STM32L053
    #endif

#endif /* defined(STM32L053R6) */


// name     : STM32L053R8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L053
#if defined(STM32L053R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L053R8"
            #else
                #pragma message("Note: Selected MCU - STM32L053R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L053)
        #define STM32L053
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TOUCH)
        #define STM32_FEATURE_NUM_TOUCH    24
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L053)
        #define STM32L053
    #endif

#endif /* defined(STM32L053R8) */


// name     : STM32L062K8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L062
#if defined(STM32L062K8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L062K8"
            #else
                #pragma message("Note: Selected MCU - STM32L062K8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L062)
        #define STM32L062
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    27
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TOUCH)
        #define STM32_FEATURE_NUM_TOUCH    24
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L062)
        #define STM32L062
    #endif

#endif /* defined(STM32L062K8) */


// name     : STM32L063C8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L063
#if defined(STM32L063C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L063C8"
            #else
                #pragma message("Note: Selected MCU - STM32L063C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L063)
        #define STM32L063
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TOUCH)
        #define STM32_FEATURE_NUM_TOUCH    24
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L063)
        #define STM32L063
    #endif

#endif /* defined(STM32L063C8) */


// name     : STM32L063R8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L063
#if defined(STM32L063R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L063R8"
            #else
                #pragma message("Note: Selected MCU - STM32L063R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L063)
        #define STM32L063
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TOUCH)
        #define STM32_FEATURE_NUM_TOUCH    24
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L063)
        #define STM32L063
    #endif

#endif /* defined(STM32L063R8) */


// name     : STM32L071C8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L071
#if defined(STM32L071C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L071C8"
            #else
                #pragma message("Note: Selected MCU - STM32L071C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

#endif /* defined(STM32L071C8) */


// name     : STM32L071CB
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L071
#if defined(STM32L071CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L071CB"
            #else
                #pragma message("Note: Selected MCU - STM32L071CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

#endif /* defined(STM32L071CB) */


// name     : STM32L071CZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L071
#if defined(STM32L071CZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L071CZ"
            #else
                #pragma message("Note: Selected MCU - STM32L071CZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

#endif /* defined(STM32L071CZ) */


// name     : STM32L071K8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L071
#if defined(STM32L071K8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L071K8"
            #else
                #pragma message("Note: Selected MCU - STM32L071K8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

#endif /* defined(STM32L071K8) */


// name     : STM32L071KB
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L071
#if defined(STM32L071KB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L071KB"
            #else
                #pragma message("Note: Selected MCU - STM32L071KB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

#endif /* defined(STM32L071KB) */


// name     : STM32L071KZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L071
#if defined(STM32L071KZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L071KZ"
            #else
                #pragma message("Note: Selected MCU - STM32L071KZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

#endif /* defined(STM32L071KZ) */


// name     : STM32L071RB
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L071
#if defined(STM32L071RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L071RB"
            #else
                #pragma message("Note: Selected MCU - STM32L071RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

#endif /* defined(STM32L071RB) */


// name     : STM32L071RZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L071
#if defined(STM32L071RZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L071RZ"
            #else
                #pragma message("Note: Selected MCU - STM32L071RZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

#endif /* defined(STM32L071RZ) */


// name     : STM32L071V8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L071
#if defined(STM32L071V8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L071V8"
            #else
                #pragma message("Note: Selected MCU - STM32L071V8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

#endif /* defined(STM32L071V8) */


// name     : STM32L071VB
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L071
#if defined(STM32L071VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L071VB"
            #else
                #pragma message("Note: Selected MCU - STM32L071VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

#endif /* defined(STM32L071VB) */


// name     : STM32L071VZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L071
#if defined(STM32L071VZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L071VZ"
            #else
                #pragma message("Note: Selected MCU - STM32L071VZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L071)
        #define STM32L071
    #endif

#endif /* defined(STM32L071VZ) */


// name     : STM32L072CB
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L072
#if defined(STM32L072CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L072CB"
            #else
                #pragma message("Note: Selected MCU - STM32L072CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

#endif /* defined(STM32L072CB) */


// name     : STM32L072CZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L072
#if defined(STM32L072CZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L072CZ"
            #else
                #pragma message("Note: Selected MCU - STM32L072CZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

#endif /* defined(STM32L072CZ) */


// name     : STM32L072KB
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L072
#if defined(STM32L072KB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L072KB"
            #else
                #pragma message("Note: Selected MCU - STM32L072KB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

#endif /* defined(STM32L072KB) */


// name     : STM32L072KZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L072
#if defined(STM32L072KZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L072KZ"
            #else
                #pragma message("Note: Selected MCU - STM32L072KZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

#endif /* defined(STM32L072KZ) */


// name     : STM32L072RB
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L072
#if defined(STM32L072RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L072RB"
            #else
                #pragma message("Note: Selected MCU - STM32L072RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

#endif /* defined(STM32L072RB) */


// name     : STM32L072RZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L072
#if defined(STM32L072RZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L072RZ"
            #else
                #pragma message("Note: Selected MCU - STM32L072RZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

#endif /* defined(STM32L072RZ) */


// name     : STM32L072V8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L072
#if defined(STM32L072V8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L072V8"
            #else
                #pragma message("Note: Selected MCU - STM32L072V8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

#endif /* defined(STM32L072V8) */


// name     : STM32L072VB
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L072
#if defined(STM32L072VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L072VB"
            #else
                #pragma message("Note: Selected MCU - STM32L072VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

#endif /* defined(STM32L072VB) */


// name     : STM32L072VZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L072
#if defined(STM32L072VZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L072VZ"
            #else
                #pragma message("Note: Selected MCU - STM32L072VZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L072)
        #define STM32L072
    #endif

#endif /* defined(STM32L072VZ) */


// name     : STM32L073CB
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L073
#if defined(STM32L073CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L073CB"
            #else
                #pragma message("Note: Selected MCU - STM32L073CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L073)
        #define STM32L073
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L073)
        #define STM32L073
    #endif

#endif /* defined(STM32L073CB) */


// name     : STM32L073CZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L073
#if defined(STM32L073CZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L073CZ"
            #else
                #pragma message("Note: Selected MCU - STM32L073CZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L073)
        #define STM32L073
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L073)
        #define STM32L073
    #endif

#endif /* defined(STM32L073CZ) */


// name     : STM32L073RB
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L073
#if defined(STM32L073RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L073RB"
            #else
                #pragma message("Note: Selected MCU - STM32L073RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L073)
        #define STM32L073
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L073)
        #define STM32L073
    #endif

#endif /* defined(STM32L073RB) */


// name     : STM32L073RZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L073
#if defined(STM32L073RZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L073RZ"
            #else
                #pragma message("Note: Selected MCU - STM32L073RZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L073)
        #define STM32L073
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L073)
        #define STM32L073
    #endif

#endif /* defined(STM32L073RZ) */


// name     : STM32L073V8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L073
#if defined(STM32L073V8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L073V8"
            #else
                #pragma message("Note: Selected MCU - STM32L073V8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L073)
        #define STM32L073
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L073)
        #define STM32L073
    #endif

#endif /* defined(STM32L073V8) */


// name     : STM32L073VB
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L073
#if defined(STM32L073VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L073VB"
            #else
                #pragma message("Note: Selected MCU - STM32L073VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L073)
        #define STM32L073
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L073)
        #define STM32L073
    #endif

#endif /* defined(STM32L073VB) */


// name     : STM32L073VZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L073
#if defined(STM32L073VZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L073VZ"
            #else
                #pragma message("Note: Selected MCU - STM32L073VZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L073)
        #define STM32L073
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L073)
        #define STM32L073
    #endif

#endif /* defined(STM32L073VZ) */


// name     : STM32L081CZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L081
#if defined(STM32L081CZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L081CZ"
            #else
                #pragma message("Note: Selected MCU - STM32L081CZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L081)
        #define STM32L081
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L081)
        #define STM32L081
    #endif

#endif /* defined(STM32L081CZ) */


// name     : STM32L081KZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L081
#if defined(STM32L081KZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L081KZ"
            #else
                #pragma message("Note: Selected MCU - STM32L081KZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L081)
        #define STM32L081
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L081)
        #define STM32L081
    #endif

#endif /* defined(STM32L081KZ) */


// name     : STM32L082KB
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L082
#if defined(STM32L082KB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L082KB"
            #else
                #pragma message("Note: Selected MCU - STM32L082KB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L082)
        #define STM32L082
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L082)
        #define STM32L082
    #endif

#endif /* defined(STM32L082KB) */


// name     : STM32L082KZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L082
#if defined(STM32L082KZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L082KZ"
            #else
                #pragma message("Note: Selected MCU - STM32L082KZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L082)
        #define STM32L082
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L082)
        #define STM32L082
    #endif

#endif /* defined(STM32L082KZ) */


// name     : STM32L082CZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L082
#if defined(STM32L082CZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L082CZ"
            #else
                #pragma message("Note: Selected MCU - STM32L082CZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L082)
        #define STM32L082
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L082)
        #define STM32L082
    #endif

#endif /* defined(STM32L082CZ) */


// name     : STM32L083CB
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L083
#if defined(STM32L083CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L083CB"
            #else
                #pragma message("Note: Selected MCU - STM32L083CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L083)
        #define STM32L083
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L083)
        #define STM32L083
    #endif

#endif /* defined(STM32L083CB) */


// name     : STM32L083CZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L083
#if defined(STM32L083CZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L083CZ"
            #else
                #pragma message("Note: Selected MCU - STM32L083CZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L083)
        #define STM32L083
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L083)
        #define STM32L083
    #endif

#endif /* defined(STM32L083CZ) */


// name     : STM32L083RB
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L083
#if defined(STM32L083RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L083RB"
            #else
                #pragma message("Note: Selected MCU - STM32L083RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L083)
        #define STM32L083
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L083)
        #define STM32L083
    #endif

#endif /* defined(STM32L083RB) */


// name     : STM32L083RZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L083
#if defined(STM32L083RZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L083RZ"
            #else
                #pragma message("Note: Selected MCU - STM32L083RZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L083)
        #define STM32L083
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L083)
        #define STM32L083
    #endif

#endif /* defined(STM32L083RZ) */


// name     : STM32L083V8
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L083
#if defined(STM32L083V8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L083V8"
            #else
                #pragma message("Note: Selected MCU - STM32L083V8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L083)
        #define STM32L083
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L083)
        #define STM32L083
    #endif

#endif /* defined(STM32L083V8) */


// name     : STM32L083VB
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L083
#if defined(STM32L083VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L083VB"
            #else
                #pragma message("Note: Selected MCU - STM32L083VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L083)
        #define STM32L083
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L083)
        #define STM32L083
    #endif

#endif /* defined(STM32L083VB) */


// name     : STM32L083VZ
// core     : Cortex-M0+
// family   : STM32L0 Series
// subfamily: STM32L083
#if defined(STM32L083VZ)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L083VZ"
            #else
                #pragma message("Note: Selected MCU - STM32L083VZ")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L0_SERIES)
        #define STM32L0_SERIES
    #endif

    #if !defined(STM32L083)
        #define STM32L083
    #endif

    #if !defined(CORTEX_M0PLUS)
        #define CORTEX_M0PLUS
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    7
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_MEMORYOTHER)
        #define STM32_FEATURE_NUM_MEMORYOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_OTHER)
        #define STM32_FEATURE_NUM_OTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L083)
        #define STM32L083
    #endif

#endif /* defined(STM32L083VZ) */


#endif /* defined(STM32L0XX_DEVICES_XML____INC_STM32L0XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00) */

