#pragma once

// Automatically umba-mm-pdsc generated file
// Universal definitions file for STM32/derived devices - C language

// input  : stm32f1xx_devices.xml
// output : ..\inc\stm32f1xx_devices.h

#if !defined(STM32F1XX_DEVICES_XML____INC_STM32F1XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00)
#define STM32F1XX_DEVICES_XML____INC_STM32F1XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00

// name     : STM32F100C4
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100C4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100C4"
            #else
                #pragma message("Note: Selected MCU - STM32F100C4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD_VL)
        #define STM32F10X_LD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100C4) */


// name     : STM32F100C6
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100C6"
            #else
                #pragma message("Note: Selected MCU - STM32F100C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD_VL)
        #define STM32F10X_LD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100C6) */


// name     : STM32F100C8
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100C8"
            #else
                #pragma message("Note: Selected MCU - STM32F100C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD_VL)
        #define STM32F10X_MD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100C8) */


// name     : STM32F100CB
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100CB"
            #else
                #pragma message("Note: Selected MCU - STM32F100CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD_VL)
        #define STM32F10X_MD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100CB) */


// name     : STM32F100R4
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100R4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100R4"
            #else
                #pragma message("Note: Selected MCU - STM32F100R4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD_VL)
        #define STM32F10X_LD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100R4) */


// name     : STM32F100R6
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100R6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100R6"
            #else
                #pragma message("Note: Selected MCU - STM32F100R6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD_VL)
        #define STM32F10X_LD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100R6) */


// name     : STM32F100R8
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100R8"
            #else
                #pragma message("Note: Selected MCU - STM32F100R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD_VL)
        #define STM32F10X_MD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100R8) */


// name     : STM32F100RB
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100RB"
            #else
                #pragma message("Note: Selected MCU - STM32F100RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD_VL)
        #define STM32F10X_MD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100RB) */


// name     : STM32F100RC
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100RC"
            #else
                #pragma message("Note: Selected MCU - STM32F100RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    11
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD_VL)
        #define STM32F10X_HD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100RC) */


// name     : STM32F100RD
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100RD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100RD"
            #else
                #pragma message("Note: Selected MCU - STM32F100RD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    11
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD_VL)
        #define STM32F10X_HD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100RD) */


// name     : STM32F100RE
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100RE"
            #else
                #pragma message("Note: Selected MCU - STM32F100RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    11
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD_VL)
        #define STM32F10X_HD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100RE) */


// name     : STM32F100V8
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100V8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100V8"
            #else
                #pragma message("Note: Selected MCU - STM32F100V8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD_VL)
        #define STM32F10X_MD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100V8) */


// name     : STM32F100VB
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100VB"
            #else
                #pragma message("Note: Selected MCU - STM32F100VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD_VL)
        #define STM32F10X_MD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100VB) */


// name     : STM32F100VC
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100VC"
            #else
                #pragma message("Note: Selected MCU - STM32F100VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    11
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD_VL)
        #define STM32F10X_HD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100VC) */


// name     : STM32F100VD
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100VD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100VD"
            #else
                #pragma message("Note: Selected MCU - STM32F100VD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    11
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD_VL)
        #define STM32F10X_HD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100VD) */


// name     : STM32F100VE
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100VE"
            #else
                #pragma message("Note: Selected MCU - STM32F100VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    11
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD_VL)
        #define STM32F10X_HD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100VE) */


// name     : STM32F100ZC
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100ZC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100ZC"
            #else
                #pragma message("Note: Selected MCU - STM32F100ZC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    112
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    11
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD_VL)
        #define STM32F10X_HD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100ZC) */


// name     : STM32F100ZD
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100ZD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100ZD"
            #else
                #pragma message("Note: Selected MCU - STM32F100ZD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    112
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    11
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD_VL)
        #define STM32F10X_HD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100ZD) */


// name     : STM32F100ZE
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F100
#if defined(STM32F100ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F100ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F100ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F100)
        #define STM32F100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    24000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    112
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    11
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD_VL)
        #define STM32F10X_HD_VL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F100ZE) */


// name     : STM32F101C4
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101C4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101C4"
            #else
                #pragma message("Note: Selected MCU - STM32F101C4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD)
        #define STM32F10X_LD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101C4) */


// name     : STM32F101C6
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101C6"
            #else
                #pragma message("Note: Selected MCU - STM32F101C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD)
        #define STM32F10X_LD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101C6) */


// name     : STM32F101C8
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101C8"
            #else
                #pragma message("Note: Selected MCU - STM32F101C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101C8) */


// name     : STM32F101CB
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101CB"
            #else
                #pragma message("Note: Selected MCU - STM32F101CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101CB) */


// name     : STM32F101R4
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101R4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101R4"
            #else
                #pragma message("Note: Selected MCU - STM32F101R4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD)
        #define STM32F10X_LD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101R4) */


// name     : STM32F101R6
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101R6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101R6"
            #else
                #pragma message("Note: Selected MCU - STM32F101R6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD)
        #define STM32F10X_LD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101R6) */


// name     : STM32F101R8
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101R8"
            #else
                #pragma message("Note: Selected MCU - STM32F101R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101R8) */


// name     : STM32F101RB
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101RB"
            #else
                #pragma message("Note: Selected MCU - STM32F101RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101RB) */


// name     : STM32F101RC
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101RC"
            #else
                #pragma message("Note: Selected MCU - STM32F101RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101RC) */


// name     : STM32F101RD
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101RD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101RD"
            #else
                #pragma message("Note: Selected MCU - STM32F101RD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101RD) */


// name     : STM32F101RE
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101RE"
            #else
                #pragma message("Note: Selected MCU - STM32F101RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101RE) */


// name     : STM32F101RF
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101RF)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101RF"
            #else
                #pragma message("Note: Selected MCU - STM32F101RF")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_XL)
        #define STM32F10X_XL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101RF) */


// name     : STM32F101RG
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101RG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101RG"
            #else
                #pragma message("Note: Selected MCU - STM32F101RG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_XL)
        #define STM32F10X_XL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101RG) */


// name     : STM32F101T4
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101T4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101T4"
            #else
                #pragma message("Note: Selected MCU - STM32F101T4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    26
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD)
        #define STM32F10X_LD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101T4) */


// name     : STM32F101T6
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101T6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101T6"
            #else
                #pragma message("Note: Selected MCU - STM32F101T6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    26
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD)
        #define STM32F10X_LD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101T6) */


// name     : STM32F101T8
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101T8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101T8"
            #else
                #pragma message("Note: Selected MCU - STM32F101T8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    26
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101T8) */


// name     : STM32F101TB
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101TB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101TB"
            #else
                #pragma message("Note: Selected MCU - STM32F101TB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    26
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101TB) */


// name     : STM32F101V8
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101V8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101V8"
            #else
                #pragma message("Note: Selected MCU - STM32F101V8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101V8) */


// name     : STM32F101VB
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101VB"
            #else
                #pragma message("Note: Selected MCU - STM32F101VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101VB) */


// name     : STM32F101VC
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101VC"
            #else
                #pragma message("Note: Selected MCU - STM32F101VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101VC) */


// name     : STM32F101VD
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101VD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101VD"
            #else
                #pragma message("Note: Selected MCU - STM32F101VD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101VD) */


// name     : STM32F101VE
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101VE"
            #else
                #pragma message("Note: Selected MCU - STM32F101VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101VE) */


// name     : STM32F101VF
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101VF)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101VF"
            #else
                #pragma message("Note: Selected MCU - STM32F101VF")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_XL)
        #define STM32F10X_XL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101VF) */


// name     : STM32F101VG
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101VG"
            #else
                #pragma message("Note: Selected MCU - STM32F101VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_XL)
        #define STM32F10X_XL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101VG) */


// name     : STM32F101ZC
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101ZC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101ZC"
            #else
                #pragma message("Note: Selected MCU - STM32F101ZC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    112
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101ZC) */


// name     : STM32F101ZD
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101ZD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101ZD"
            #else
                #pragma message("Note: Selected MCU - STM32F101ZD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    112
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101ZD) */


// name     : STM32F101ZE
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F101ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    112
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101ZE) */


// name     : STM32F101ZF
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101ZF)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101ZF"
            #else
                #pragma message("Note: Selected MCU - STM32F101ZF")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    112
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_XL)
        #define STM32F10X_XL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101ZF) */


// name     : STM32F101ZG
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F101
#if defined(STM32F101ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F101ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F101ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F101)
        #define STM32F101
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    112
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_XL)
        #define STM32F10X_XL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F101ZG) */


// name     : STM32F102C4
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F102
#if defined(STM32F102C4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F102C4"
            #else
                #pragma message("Note: Selected MCU - STM32F102C4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F102)
        #define STM32F102
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD)
        #define STM32F10X_LD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F102C4) */


// name     : STM32F102C6
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F102
#if defined(STM32F102C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F102C6"
            #else
                #pragma message("Note: Selected MCU - STM32F102C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F102)
        #define STM32F102
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD)
        #define STM32F10X_LD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F102C6) */


// name     : STM32F102C8
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F102
#if defined(STM32F102C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F102C8"
            #else
                #pragma message("Note: Selected MCU - STM32F102C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F102)
        #define STM32F102
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F102C8) */


// name     : STM32F102CB
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F102
#if defined(STM32F102CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F102CB"
            #else
                #pragma message("Note: Selected MCU - STM32F102CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F102)
        #define STM32F102
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F102CB) */


// name     : STM32F102R4
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F102
#if defined(STM32F102R4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F102R4"
            #else
                #pragma message("Note: Selected MCU - STM32F102R4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F102)
        #define STM32F102
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD)
        #define STM32F10X_LD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F102R4) */


// name     : STM32F102R6
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F102
#if defined(STM32F102R6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F102R6"
            #else
                #pragma message("Note: Selected MCU - STM32F102R6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F102)
        #define STM32F102
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD)
        #define STM32F10X_LD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F102R6) */


// name     : STM32F102R8
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F102
#if defined(STM32F102R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F102R8"
            #else
                #pragma message("Note: Selected MCU - STM32F102R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F102)
        #define STM32F102
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F102R8) */


// name     : STM32F102RB
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F102
#if defined(STM32F102RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F102RB"
            #else
                #pragma message("Note: Selected MCU - STM32F102RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F102)
        #define STM32F102
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F102RB) */


// name     : STM32F103C4
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103C4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103C4"
            #else
                #pragma message("Note: Selected MCU - STM32F103C4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD)
        #define STM32F10X_LD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103C4) */


// name     : STM32F103C6
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103C6"
            #else
                #pragma message("Note: Selected MCU - STM32F103C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD)
        #define STM32F10X_LD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103C6) */


// name     : STM32F103C8
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103C8"
            #else
                #pragma message("Note: Selected MCU - STM32F103C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103C8) */


// name     : STM32F103CB
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103CB"
            #else
                #pragma message("Note: Selected MCU - STM32F103CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103CB) */


// name     : STM32F103R4
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103R4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103R4"
            #else
                #pragma message("Note: Selected MCU - STM32F103R4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD)
        #define STM32F10X_LD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103R4) */


// name     : STM32F103R6
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103R6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103R6"
            #else
                #pragma message("Note: Selected MCU - STM32F103R6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD)
        #define STM32F10X_LD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103R6) */


// name     : STM32F103R8
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103R8"
            #else
                #pragma message("Note: Selected MCU - STM32F103R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103R8) */


// name     : STM32F103RB
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103RB"
            #else
                #pragma message("Note: Selected MCU - STM32F103RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103RB) */


// name     : STM32F103RC
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103RC"
            #else
                #pragma message("Note: Selected MCU - STM32F103RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103RC) */


// name     : STM32F103RD
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103RD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103RD"
            #else
                #pragma message("Note: Selected MCU - STM32F103RD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103RD) */


// name     : STM32F103RE
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103RE"
            #else
                #pragma message("Note: Selected MCU - STM32F103RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103RE) */


// name     : STM32F103RF
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103RF)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103RF"
            #else
                #pragma message("Note: Selected MCU - STM32F103RF")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_XL)
        #define STM32F10X_XL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103RF) */


// name     : STM32F103RG
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103RG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103RG"
            #else
                #pragma message("Note: Selected MCU - STM32F103RG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_XL)
        #define STM32F10X_XL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103RG) */


// name     : STM32F103T4
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103T4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103T4"
            #else
                #pragma message("Note: Selected MCU - STM32F103T4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    26
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD)
        #define STM32F10X_LD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103T4) */


// name     : STM32F103T6
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103T6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103T6"
            #else
                #pragma message("Note: Selected MCU - STM32F103T6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    26
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_LD)
        #define STM32F10X_LD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103T6) */


// name     : STM32F103T8
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103T8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103T8"
            #else
                #pragma message("Note: Selected MCU - STM32F103T8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    26
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103T8) */


// name     : STM32F103TB
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103TB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103TB"
            #else
                #pragma message("Note: Selected MCU - STM32F103TB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    26
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103TB) */


// name     : STM32F103V8
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103V8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103V8"
            #else
                #pragma message("Note: Selected MCU - STM32F103V8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103V8) */


// name     : STM32F103VB
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103VB"
            #else
                #pragma message("Note: Selected MCU - STM32F103VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_MD)
        #define STM32F10X_MD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103VB) */


// name     : STM32F103VC
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103VC"
            #else
                #pragma message("Note: Selected MCU - STM32F103VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103VC) */


// name     : STM32F103VD
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103VD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103VD"
            #else
                #pragma message("Note: Selected MCU - STM32F103VD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103VD) */


// name     : STM32F103VE
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103VE"
            #else
                #pragma message("Note: Selected MCU - STM32F103VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103VE) */


// name     : STM32F103VF
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103VF)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103VF"
            #else
                #pragma message("Note: Selected MCU - STM32F103VF")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    14
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_XL)
        #define STM32F10X_XL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103VF) */


// name     : STM32F103VG
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103VG"
            #else
                #pragma message("Note: Selected MCU - STM32F103VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    14
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_XL)
        #define STM32F10X_XL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103VG) */


// name     : STM32F103ZC
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103ZC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103ZC"
            #else
                #pragma message("Note: Selected MCU - STM32F103ZC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    112
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103ZC) */


// name     : STM32F103ZD
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103ZD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103ZD"
            #else
                #pragma message("Note: Selected MCU - STM32F103ZD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    112
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103ZD) */


// name     : STM32F103ZE
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F103ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    112
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_HD)
        #define STM32F10X_HD
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103ZE) */


// name     : STM32F103ZF
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103ZF)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103ZF"
            #else
                #pragma message("Note: Selected MCU - STM32F103ZF")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    112
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    14
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_XL)
        #define STM32F10X_XL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103ZF) */


// name     : STM32F103ZG
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F103
#if defined(STM32F103ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F103ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F103ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F103)
        #define STM32F103
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    112
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    14
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_XL)
        #define STM32F10X_XL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F103ZG) */


// name     : STM32F105R8
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F105
#if defined(STM32F105R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F105R8"
            #else
                #pragma message("Note: Selected MCU - STM32F105R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F105)
        #define STM32F105
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_CL)
        #define STM32F10X_CL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F105R8) */


// name     : STM32F105RB
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F105
#if defined(STM32F105RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F105RB"
            #else
                #pragma message("Note: Selected MCU - STM32F105RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F105)
        #define STM32F105
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_CL)
        #define STM32F10X_CL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F105RB) */


// name     : STM32F105RC
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F105
#if defined(STM32F105RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F105RC"
            #else
                #pragma message("Note: Selected MCU - STM32F105RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F105)
        #define STM32F105
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_CL)
        #define STM32F10X_CL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F105RC) */


// name     : STM32F105V8
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F105
#if defined(STM32F105V8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F105V8"
            #else
                #pragma message("Note: Selected MCU - STM32F105V8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F105)
        #define STM32F105
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_CL)
        #define STM32F10X_CL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F105V8) */


// name     : STM32F105VB
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F105
#if defined(STM32F105VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F105VB"
            #else
                #pragma message("Note: Selected MCU - STM32F105VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F105)
        #define STM32F105
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_CL)
        #define STM32F10X_CL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F105VB) */


// name     : STM32F105VC
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F105
#if defined(STM32F105VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F105VC"
            #else
                #pragma message("Note: Selected MCU - STM32F105VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F105)
        #define STM32F105
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_CL)
        #define STM32F10X_CL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F105VC) */


// name     : STM32F107RB
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F107
#if defined(STM32F107RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F107RB"
            #else
                #pragma message("Note: Selected MCU - STM32F107RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F107)
        #define STM32F107
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_CL)
        #define STM32F10X_CL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F107RB) */


// name     : STM32F107RC
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F107
#if defined(STM32F107RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F107RC"
            #else
                #pragma message("Note: Selected MCU - STM32F107RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F107)
        #define STM32F107
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_CL)
        #define STM32F10X_CL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F107RC) */


// name     : STM32F107VB
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F107
#if defined(STM32F107VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F107VB"
            #else
                #pragma message("Note: Selected MCU - STM32F107VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F107)
        #define STM32F107
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_CL)
        #define STM32F10X_CL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F107VB) */


// name     : STM32F107VC
// core     : Cortex-M3
// family   : STM32F1 Series
// subfamily: STM32F107
#if defined(STM32F107VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F107VC"
            #else
                #pragma message("Note: Selected MCU - STM32F107VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F1_SERIES)
        #define STM32F1_SERIES
    #endif

    #if !defined(STM32F107)
        #define STM32F107
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    80
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F10X_CL)
        #define STM32F10X_CL
    #endif

    #if !defined(STM32F1xx)
        #define STM32F1xx
    #endif

#endif /* defined(STM32F107VC) */


#endif /* defined(STM32F1XX_DEVICES_XML____INC_STM32F1XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00) */

