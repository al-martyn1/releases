#pragma once

// Automatically umba-mm-pdsc generated file
// Universal definitions file for STM32/derived devices - C language

// input  : stm32f0xx_devices.xml
// output : ..\inc\stm32f0xx_devices.h

#if !defined(STM32F0XX_DEVICES_XML____INC_STM32F0XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00)
#define STM32F0XX_DEVICES_XML____INC_STM32F0XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00

// name     : STM32F030C6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F030
#if defined(STM32F030C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F030C6"
            #else
                #pragma message("Note: Selected MCU - STM32F030C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F030)
        #define STM32F030
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    39
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F030x6)
        #define STM32F030x6
    #endif

#endif /* defined(STM32F030C6) */


// name     : STM32F030C8
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F030
#if defined(STM32F030C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F030C8"
            #else
                #pragma message("Note: Selected MCU - STM32F030C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F030)
        #define STM32F030
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    39
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F030x8)
        #define STM32F030x8
    #endif

#endif /* defined(STM32F030C8) */


// name     : STM32F030CC
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F030
#if defined(STM32F030CC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F030CC"
            #else
                #pragma message("Note: Selected MCU - STM32F030CC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F030)
        #define STM32F030
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    39
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F030xC)
        #define STM32F030xC
    #endif

#endif /* defined(STM32F030CC) */


// name     : STM32F030F4
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F030
#if defined(STM32F030F4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F030F4"
            #else
                #pragma message("Note: Selected MCU - STM32F030F4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F030)
        #define STM32F030
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    15
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F030x6)
        #define STM32F030x6
    #endif

#endif /* defined(STM32F030F4) */


// name     : STM32F030K6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F030
#if defined(STM32F030K6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F030K6"
            #else
                #pragma message("Note: Selected MCU - STM32F030K6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F030)
        #define STM32F030
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    26
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F030x6)
        #define STM32F030x6
    #endif

#endif /* defined(STM32F030K6) */


// name     : STM32F030R8
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F030
#if defined(STM32F030R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F030R8"
            #else
                #pragma message("Note: Selected MCU - STM32F030R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F030)
        #define STM32F030
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    55
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F030x8)
        #define STM32F030x8
    #endif

#endif /* defined(STM32F030R8) */


// name     : STM32F030RC
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F030
#if defined(STM32F030RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F030RC"
            #else
                #pragma message("Note: Selected MCU - STM32F030RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F030)
        #define STM32F030
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    39
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F030xC)
        #define STM32F030xC
    #endif

#endif /* defined(STM32F030RC) */


// name     : STM32F031C4
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F031
#if defined(STM32F031C4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F031C4"
            #else
                #pragma message("Note: Selected MCU - STM32F031C4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F031)
        #define STM32F031
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    39
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F031C4) */


// name     : STM32F031C6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F031
#if defined(STM32F031C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F031C6"
            #else
                #pragma message("Note: Selected MCU - STM32F031C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F031)
        #define STM32F031
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    39
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F031x6)
        #define STM32F031x6
    #endif

#endif /* defined(STM32F031C6) */


// name     : STM32F031E6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F031
#if defined(STM32F031E6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F031E6"
            #else
                #pragma message("Note: Selected MCU - STM32F031E6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F031)
        #define STM32F031
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    20
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F031x6)
        #define STM32F031x6
    #endif

#endif /* defined(STM32F031E6) */


// name     : STM32F031F4
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F031
#if defined(STM32F031F4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F031F4"
            #else
                #pragma message("Note: Selected MCU - STM32F031F4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F031)
        #define STM32F031
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    12
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    13
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F031F4) */


// name     : STM32F031F6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F031
#if defined(STM32F031F6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F031F6"
            #else
                #pragma message("Note: Selected MCU - STM32F031F6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F031)
        #define STM32F031
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    12
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    13
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F031x6)
        #define STM32F031x6
    #endif

#endif /* defined(STM32F031F6) */


// name     : STM32F031G4
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F031
#if defined(STM32F031G4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F031G4"
            #else
                #pragma message("Note: Selected MCU - STM32F031G4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F031)
        #define STM32F031
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    21
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F031G4) */


// name     : STM32F031G6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F031
#if defined(STM32F031G6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F031G6"
            #else
                #pragma message("Note: Selected MCU - STM32F031G6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F031)
        #define STM32F031
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    21
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F031x6)
        #define STM32F031x6
    #endif

#endif /* defined(STM32F031G6) */


// name     : STM32F031K4
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F031
#if defined(STM32F031K4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F031K4"
            #else
                #pragma message("Note: Selected MCU - STM32F031K4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F031)
        #define STM32F031
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    27
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F031K4) */


// name     : STM32F031K6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F031
#if defined(STM32F031K6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F031K6"
            #else
                #pragma message("Note: Selected MCU - STM32F031K6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F031)
        #define STM32F031
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    27
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F031x6)
        #define STM32F031x6
    #endif

#endif /* defined(STM32F031K6) */


// name     : STM32F038C6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F038
#if defined(STM32F038C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F038C6"
            #else
                #pragma message("Note: Selected MCU - STM32F038C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F038)
        #define STM32F038
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    39
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F038xx)
        #define STM32F038xx
    #endif

#endif /* defined(STM32F038C6) */


// name     : STM32F038E6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F038
#if defined(STM32F038E6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F038E6"
            #else
                #pragma message("Note: Selected MCU - STM32F038E6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F038)
        #define STM32F038
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    20
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F038xx)
        #define STM32F038xx
    #endif

#endif /* defined(STM32F038E6) */


// name     : STM32F038F6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F038
#if defined(STM32F038F6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F038F6"
            #else
                #pragma message("Note: Selected MCU - STM32F038F6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F038)
        #define STM32F038
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    12
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    13
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F038xx)
        #define STM32F038xx
    #endif

#endif /* defined(STM32F038F6) */


// name     : STM32F038G6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F038
#if defined(STM32F038G6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F038G6"
            #else
                #pragma message("Note: Selected MCU - STM32F038G6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F038)
        #define STM32F038
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    21
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F038xx)
        #define STM32F038xx
    #endif

#endif /* defined(STM32F038G6) */


// name     : STM32F038K6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F038
#if defined(STM32F038K6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F038K6"
            #else
                #pragma message("Note: Selected MCU - STM32F038K6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F038)
        #define STM32F038
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    27
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F038xx)
        #define STM32F038xx
    #endif

#endif /* defined(STM32F038K6) */


// name     : STM32F042C4
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F042
#if defined(STM32F042C4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F042C4"
            #else
                #pragma message("Note: Selected MCU - STM32F042C4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F042)
        #define STM32F042
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    5
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    38
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F042C4) */


// name     : STM32F042C6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F042
#if defined(STM32F042C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F042C6"
            #else
                #pragma message("Note: Selected MCU - STM32F042C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F042)
        #define STM32F042
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    5
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    38
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F042x6)
        #define STM32F042x6
    #endif

#endif /* defined(STM32F042C6) */


// name     : STM32F042F4
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F042
#if defined(STM32F042F4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F042F4"
            #else
                #pragma message("Note: Selected MCU - STM32F042F4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F042)
        #define STM32F042
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    12
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    5
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F042F4) */


// name     : STM32F042F6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F042
#if defined(STM32F042F6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F042F6"
            #else
                #pragma message("Note: Selected MCU - STM32F042F6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F042)
        #define STM32F042
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    12
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    5
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F042x6)
        #define STM32F042x6
    #endif

#endif /* defined(STM32F042F6) */


// name     : STM32F042G4
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F042
#if defined(STM32F042G4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F042G4"
            #else
                #pragma message("Note: Selected MCU - STM32F042G4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F042)
        #define STM32F042
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    5
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    24
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F042G4) */


// name     : STM32F042G6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F042
#if defined(STM32F042G6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F042G6"
            #else
                #pragma message("Note: Selected MCU - STM32F042G6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F042)
        #define STM32F042
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    5
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    24
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F042x6)
        #define STM32F042x6
    #endif

#endif /* defined(STM32F042G6) */


// name     : STM32F042K4
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F042
#if defined(STM32F042K4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F042K4"
            #else
                #pragma message("Note: Selected MCU - STM32F042K4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F042)
        #define STM32F042
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    5
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    28
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F042K4) */


// name     : STM32F042K6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F042
#if defined(STM32F042K6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F042K6"
            #else
                #pragma message("Note: Selected MCU - STM32F042K6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F042)
        #define STM32F042
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    5
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    28
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F042x6)
        #define STM32F042x6
    #endif

#endif /* defined(STM32F042K6) */


// name     : STM32F042T6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F042
#if defined(STM32F042T6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F042T6"
            #else
                #pragma message("Note: Selected MCU - STM32F042T6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F042)
        #define STM32F042
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    5
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    30
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F042x6)
        #define STM32F042x6
    #endif

#endif /* defined(STM32F042T6) */


// name     : STM32F048C6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F048
#if defined(STM32F048C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F048C6"
            #else
                #pragma message("Note: Selected MCU - STM32F048C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F048)
        #define STM32F048
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    5
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    38
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F048xx)
        #define STM32F048xx
    #endif

#endif /* defined(STM32F048C6) */


// name     : STM32F048G6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F048
#if defined(STM32F048G6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F048G6"
            #else
                #pragma message("Note: Selected MCU - STM32F048G6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F048)
        #define STM32F048
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    5
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    24
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F048xx)
        #define STM32F048xx
    #endif

#endif /* defined(STM32F048G6) */


// name     : STM32F048T6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F048
#if defined(STM32F048T6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F048T6"
            #else
                #pragma message("Note: Selected MCU - STM32F048T6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F048)
        #define STM32F048
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DMA)
        #define STM32_FEATURE_NUM_DMA    5
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    30
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F048xx)
        #define STM32F048xx
    #endif

#endif /* defined(STM32F048T6) */


// name     : STM32F051C4
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F051
#if defined(STM32F051C4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F051C4"
            #else
                #pragma message("Note: Selected MCU - STM32F051C4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F051)
        #define STM32F051
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    39
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F051C4) */


// name     : STM32F051C6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F051
#if defined(STM32F051C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F051C6"
            #else
                #pragma message("Note: Selected MCU - STM32F051C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F051)
        #define STM32F051
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    39
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F051C6) */


// name     : STM32F051C8
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F051
#if defined(STM32F051C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F051C8"
            #else
                #pragma message("Note: Selected MCU - STM32F051C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F051)
        #define STM32F051
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    39
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F051x8)
        #define STM32F051x8
    #endif

#endif /* defined(STM32F051C8) */


// name     : STM32F051K4
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F051
#if defined(STM32F051K4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F051K4"
            #else
                #pragma message("Note: Selected MCU - STM32F051K4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F051)
        #define STM32F051
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    27
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F051K4) */


// name     : STM32F051K6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F051
#if defined(STM32F051K6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F051K6"
            #else
                #pragma message("Note: Selected MCU - STM32F051K6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F051)
        #define STM32F051
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    27
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F051K6) */


// name     : STM32F051K8
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F051
#if defined(STM32F051K8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F051K8"
            #else
                #pragma message("Note: Selected MCU - STM32F051K8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F051)
        #define STM32F051
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    27
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F051x8)
        #define STM32F051x8
    #endif

#endif /* defined(STM32F051K8) */


// name     : STM32F051R4
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F051
#if defined(STM32F051R4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F051R4"
            #else
                #pragma message("Note: Selected MCU - STM32F051R4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F051)
        #define STM32F051
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    55
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F051R4) */


// name     : STM32F051R6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F051
#if defined(STM32F051R6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F051R6"
            #else
                #pragma message("Note: Selected MCU - STM32F051R6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F051)
        #define STM32F051
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    55
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F051R6) */


// name     : STM32F051R8
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F051
#if defined(STM32F051R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F051R8"
            #else
                #pragma message("Note: Selected MCU - STM32F051R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F051)
        #define STM32F051
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    55
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F051x8)
        #define STM32F051x8
    #endif

#endif /* defined(STM32F051R8) */


// name     : STM32F051T8
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F051
#if defined(STM32F051T8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F051T8"
            #else
                #pragma message("Note: Selected MCU - STM32F051T8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F051)
        #define STM32F051
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    29
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F051x8)
        #define STM32F051x8
    #endif

#endif /* defined(STM32F051T8) */


// name     : STM32F058C8
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F058
#if defined(STM32F058C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F058C8"
            #else
                #pragma message("Note: Selected MCU - STM32F058C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F058)
        #define STM32F058
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    39
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F058xx)
        #define STM32F058xx
    #endif

#endif /* defined(STM32F058C8) */


// name     : STM32F058R8
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F058
#if defined(STM32F058R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F058R8"
            #else
                #pragma message("Note: Selected MCU - STM32F058R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F058)
        #define STM32F058
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    55
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F058xx)
        #define STM32F058xx
    #endif

#endif /* defined(STM32F058R8) */


// name     : STM32F058T8
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F058
#if defined(STM32F058T8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F058T8"
            #else
                #pragma message("Note: Selected MCU - STM32F058T8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F058)
        #define STM32F058
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    28
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F058xx)
        #define STM32F058xx
    #endif

#endif /* defined(STM32F058T8) */


// name     : STM32F070C6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F070
#if defined(STM32F070C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F070C6"
            #else
                #pragma message("Note: Selected MCU - STM32F070C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F070)
        #define STM32F070
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    87
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F070x6)
        #define STM32F070x6
    #endif

#endif /* defined(STM32F070C6) */


// name     : STM32F070CB
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F070
#if defined(STM32F070CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F070CB"
            #else
                #pragma message("Note: Selected MCU - STM32F070CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F070)
        #define STM32F070
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F070xB)
        #define STM32F070xB
    #endif

#endif /* defined(STM32F070CB) */


// name     : STM32F070F6
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F070
#if defined(STM32F070F6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F070F6"
            #else
                #pragma message("Note: Selected MCU - STM32F070F6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F070)
        #define STM32F070
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    87
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F070x6)
        #define STM32F070x6
    #endif

#endif /* defined(STM32F070F6) */


// name     : STM32F070RB
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F070
#if defined(STM32F070RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F070RB"
            #else
                #pragma message("Note: Selected MCU - STM32F070RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F070)
        #define STM32F070
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F070xB)
        #define STM32F070xB
    #endif

#endif /* defined(STM32F070RB) */


// name     : STM32F071C8
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F071
#if defined(STM32F071C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F071C8"
            #else
                #pragma message("Note: Selected MCU - STM32F071C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F071)
        #define STM32F071
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F071C8) */


// name     : STM32F071CB
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F071
#if defined(STM32F071CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F071CB"
            #else
                #pragma message("Note: Selected MCU - STM32F071CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F071)
        #define STM32F071
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F071xB)
        #define STM32F071xB
    #endif

#endif /* defined(STM32F071CB) */


// name     : STM32F071RB
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F071
#if defined(STM32F071RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F071RB"
            #else
                #pragma message("Note: Selected MCU - STM32F071RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F071)
        #define STM32F071
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    7
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F071xB)
        #define STM32F071xB
    #endif

#endif /* defined(STM32F071RB) */


// name     : STM32F071V8
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F071
#if defined(STM32F071V8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F071V8"
            #else
                #pragma message("Note: Selected MCU - STM32F071V8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F071)
        #define STM32F071
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    87
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    9
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F071V8) */


// name     : STM32F071VB
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F071
#if defined(STM32F071VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F071VB"
            #else
                #pragma message("Note: Selected MCU - STM32F071VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F071)
        #define STM32F071
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    87
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    9
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F071xB)
        #define STM32F071xB
    #endif

#endif /* defined(STM32F071VB) */


// name     : STM32F072C8
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F072
#if defined(STM32F072C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F072C8"
            #else
                #pragma message("Note: Selected MCU - STM32F072C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F072)
        #define STM32F072
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F072C8) */


// name     : STM32F072CB
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F072
#if defined(STM32F072CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F072CB"
            #else
                #pragma message("Note: Selected MCU - STM32F072CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F072)
        #define STM32F072
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F072xB)
        #define STM32F072xB
    #endif

#endif /* defined(STM32F072CB) */


// name     : STM32F072R8
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F072
#if defined(STM32F072R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F072R8"
            #else
                #pragma message("Note: Selected MCU - STM32F072R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F072)
        #define STM32F072
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F072R8) */


// name     : STM32F072RB
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F072
#if defined(STM32F072RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F072RB"
            #else
                #pragma message("Note: Selected MCU - STM32F072RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F072)
        #define STM32F072
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F072xB)
        #define STM32F072xB
    #endif

#endif /* defined(STM32F072RB) */


// name     : STM32F072V8
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F072
#if defined(STM32F072V8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F072V8"
            #else
                #pragma message("Note: Selected MCU - STM32F072V8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F072)
        #define STM32F072
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    87
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F072V8) */


// name     : STM32F072VB
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F072
#if defined(STM32F072VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F072VB"
            #else
                #pragma message("Note: Selected MCU - STM32F072VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F072)
        #define STM32F072
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    87
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F072xB)
        #define STM32F072xB
    #endif

#endif /* defined(STM32F072VB) */


// name     : STM32F078CB
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F078
#if defined(STM32F078CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F078CB"
            #else
                #pragma message("Note: Selected MCU - STM32F078CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F078)
        #define STM32F078
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F078xx)
        #define STM32F078xx
    #endif

#endif /* defined(STM32F078CB) */


// name     : STM32F078RB
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F078
#if defined(STM32F078RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F078RB"
            #else
                #pragma message("Note: Selected MCU - STM32F078RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F078)
        #define STM32F078
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F078xx)
        #define STM32F078xx
    #endif

#endif /* defined(STM32F078RB) */


// name     : STM32F078VB
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F078
#if defined(STM32F078VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F078VB"
            #else
                #pragma message("Note: Selected MCU - STM32F078VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F078)
        #define STM32F078
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    86
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F078xx)
        #define STM32F078xx
    #endif

#endif /* defined(STM32F078VB) */


// name     : STM32F091CB
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F091
#if defined(STM32F091CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F091CB"
            #else
                #pragma message("Note: Selected MCU - STM32F091CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F091)
        #define STM32F091
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    38
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    8
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F091CB) */


// name     : STM32F091CC
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F091
#if defined(STM32F091CC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F091CC"
            #else
                #pragma message("Note: Selected MCU - STM32F091CC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F091)
        #define STM32F091
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    38
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    8
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F091xC)
        #define STM32F091xC
    #endif

#endif /* defined(STM32F091CC) */


// name     : STM32F091RB
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F091
#if defined(STM32F091RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F091RB"
            #else
                #pragma message("Note: Selected MCU - STM32F091RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F091)
        #define STM32F091
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    8
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F091RB) */


// name     : STM32F091RC
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F091
#if defined(STM32F091RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F091RC"
            #else
                #pragma message("Note: Selected MCU - STM32F091RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F091)
        #define STM32F091
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    52
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    8
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F091xC)
        #define STM32F091xC
    #endif

#endif /* defined(STM32F091RC) */


// name     : STM32F091VB
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F091
#if defined(STM32F091VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F091VB"
            #else
                #pragma message("Note: Selected MCU - STM32F091VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F091)
        #define STM32F091
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    8
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F091VB) */


// name     : STM32F091VC
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F091
#if defined(STM32F091VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F091VC"
            #else
                #pragma message("Note: Selected MCU - STM32F091VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F091)
        #define STM32F091
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    19
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    88
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    8
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F091xC)
        #define STM32F091xC
    #endif

#endif /* defined(STM32F091VC) */


// name     : STM32F098CC
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F098
#if defined(STM32F098CC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F098CC"
            #else
                #pragma message("Note: Selected MCU - STM32F098CC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F098)
        #define STM32F098
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    8
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F098xx)
        #define STM32F098xx
    #endif

#endif /* defined(STM32F098CC) */


// name     : STM32F098RC
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F098
#if defined(STM32F098RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F098RC"
            #else
                #pragma message("Note: Selected MCU - STM32F098RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F098)
        #define STM32F098
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    8
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F098xx)
        #define STM32F098xx
    #endif

#endif /* defined(STM32F098RC) */


// name     : STM32F098VC
// core     : Cortex-M0
// family   : STM32F0 Series
// subfamily: STM32F098
#if defined(STM32F098VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F098VC"
            #else
                #pragma message("Note: Selected MCU - STM32F098VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F0_SERIES)
        #define STM32F0_SERIES
    #endif

    #if !defined(STM32F098)
        #define STM32F098
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    48000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    87
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    8
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F098xx)
        #define STM32F098xx
    #endif

#endif /* defined(STM32F098VC) */


#endif /* defined(STM32F0XX_DEVICES_XML____INC_STM32F0XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00) */

