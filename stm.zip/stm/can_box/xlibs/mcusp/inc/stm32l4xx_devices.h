#pragma once

// Automatically umba-mm-pdsc generated file
// Universal definitions file for STM32/derived devices - C language

// input  : stm32l4xx_devices.xml
// output : ..\inc\stm32l4xx_devices.h

#if !defined(STM32L4XX_DEVICES_XML____INC_STM32L4XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00)
#define STM32L4XX_DEVICES_XML____INC_STM32L4XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00

// name     : STM32L431CC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L431
#if defined(STM32L431CC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L431CC"
            #else
                #pragma message("Note: Selected MCU - STM32L431CC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L431)
        #define STM32L431
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L431)
        #define STM32L431
    #endif

#endif /* defined(STM32L431CC) */


// name     : STM32L431KC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L431
#if defined(STM32L431KC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L431KC"
            #else
                #pragma message("Note: Selected MCU - STM32L431KC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L431)
        #define STM32L431
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L431)
        #define STM32L431
    #endif

#endif /* defined(STM32L431KC) */


// name     : STM32L431RC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L431
#if defined(STM32L431RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L431RC"
            #else
                #pragma message("Note: Selected MCU - STM32L431RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L431)
        #define STM32L431
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L431)
        #define STM32L431
    #endif

#endif /* defined(STM32L431RC) */


// name     : STM32L431VC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L431
#if defined(STM32L431VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L431VC"
            #else
                #pragma message("Note: Selected MCU - STM32L431VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L431)
        #define STM32L431
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L431)
        #define STM32L431
    #endif

#endif /* defined(STM32L431VC) */


// name     : STM32L431CB
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L431
#if defined(STM32L431CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L431CB"
            #else
                #pragma message("Note: Selected MCU - STM32L431CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L431)
        #define STM32L431
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L431)
        #define STM32L431
    #endif

#endif /* defined(STM32L431CB) */


// name     : STM32L431KB
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L431
#if defined(STM32L431KB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L431KB"
            #else
                #pragma message("Note: Selected MCU - STM32L431KB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L431)
        #define STM32L431
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L431)
        #define STM32L431
    #endif

#endif /* defined(STM32L431KB) */


// name     : STM32L431RB
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L431
#if defined(STM32L431RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L431RB"
            #else
                #pragma message("Note: Selected MCU - STM32L431RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L431)
        #define STM32L431
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L431)
        #define STM32L431
    #endif

#endif /* defined(STM32L431RB) */


// name     : STM32L432KC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L432
#if defined(STM32L432KC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L432KC"
            #else
                #pragma message("Note: Selected MCU - STM32L432KC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L432)
        #define STM32L432
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L432)
        #define STM32L432
    #endif

#endif /* defined(STM32L432KC) */


// name     : STM32L432KB
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L432
#if defined(STM32L432KB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L432KB"
            #else
                #pragma message("Note: Selected MCU - STM32L432KB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L432)
        #define STM32L432
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L432)
        #define STM32L432
    #endif

#endif /* defined(STM32L432KB) */


// name     : STM32L433CC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L433
#if defined(STM32L433CC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L433CC"
            #else
                #pragma message("Note: Selected MCU - STM32L433CC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L433)
        #define STM32L433
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L433)
        #define STM32L433
    #endif

#endif /* defined(STM32L433CC) */


// name     : STM32L433RC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L433
#if defined(STM32L433RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L433RC"
            #else
                #pragma message("Note: Selected MCU - STM32L433RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L433)
        #define STM32L433
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L433)
        #define STM32L433
    #endif

#endif /* defined(STM32L433RC) */


// name     : STM32L433VC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L433
#if defined(STM32L433VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L433VC"
            #else
                #pragma message("Note: Selected MCU - STM32L433VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L433)
        #define STM32L433
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L433)
        #define STM32L433
    #endif

#endif /* defined(STM32L433VC) */


// name     : STM32L433CB
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L433
#if defined(STM32L433CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L433CB"
            #else
                #pragma message("Note: Selected MCU - STM32L433CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L433)
        #define STM32L433
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L433)
        #define STM32L433
    #endif

#endif /* defined(STM32L433CB) */


// name     : STM32L433RB
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L433
#if defined(STM32L433RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L433RB"
            #else
                #pragma message("Note: Selected MCU - STM32L433RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L433)
        #define STM32L433
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L433)
        #define STM32L433
    #endif

#endif /* defined(STM32L433RB) */


// name     : STM32L442KC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L442
#if defined(STM32L442KC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L442KC"
            #else
                #pragma message("Note: Selected MCU - STM32L442KC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L442)
        #define STM32L442
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L442)
        #define STM32L442
    #endif

#endif /* defined(STM32L442KC) */


// name     : STM32L443CC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L443
#if defined(STM32L443CC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L443CC"
            #else
                #pragma message("Note: Selected MCU - STM32L443CC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L443)
        #define STM32L443
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L443)
        #define STM32L443
    #endif

#endif /* defined(STM32L443CC) */


// name     : STM32L443RC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L443
#if defined(STM32L443RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L443RC"
            #else
                #pragma message("Note: Selected MCU - STM32L443RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L443)
        #define STM32L443
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L443)
        #define STM32L443
    #endif

#endif /* defined(STM32L443RC) */


// name     : STM32L443VC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L443
#if defined(STM32L443VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L443VC"
            #else
                #pragma message("Note: Selected MCU - STM32L443VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L443)
        #define STM32L443
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L443)
        #define STM32L443
    #endif

#endif /* defined(STM32L443VC) */


// name     : STM32L471RC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L471
#if defined(STM32L471RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L471RC"
            #else
                #pragma message("Note: Selected MCU - STM32L471RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

#endif /* defined(STM32L471RC) */


// name     : STM32L471VC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L471
#if defined(STM32L471VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L471VC"
            #else
                #pragma message("Note: Selected MCU - STM32L471VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

#endif /* defined(STM32L471VC) */


// name     : STM32L471RE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L471
#if defined(STM32L471RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L471RE"
            #else
                #pragma message("Note: Selected MCU - STM32L471RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

#endif /* defined(STM32L471RE) */


// name     : STM32L471JE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L471
#if defined(STM32L471JE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L471JE"
            #else
                #pragma message("Note: Selected MCU - STM32L471JE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

#endif /* defined(STM32L471JE) */


// name     : STM32L471VE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L471
#if defined(STM32L471VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L471VE"
            #else
                #pragma message("Note: Selected MCU - STM32L471VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

#endif /* defined(STM32L471VE) */


// name     : STM32L471QE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L471
#if defined(STM32L471QE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L471QE"
            #else
                #pragma message("Note: Selected MCU - STM32L471QE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

#endif /* defined(STM32L471QE) */


// name     : STM32L471ZE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L471
#if defined(STM32L471ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L471ZE"
            #else
                #pragma message("Note: Selected MCU - STM32L471ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

#endif /* defined(STM32L471ZE) */


// name     : STM32L471RG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L471
#if defined(STM32L471RG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L471RG"
            #else
                #pragma message("Note: Selected MCU - STM32L471RG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

#endif /* defined(STM32L471RG) */


// name     : STM32L471JG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L471
#if defined(STM32L471JG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L471JG"
            #else
                #pragma message("Note: Selected MCU - STM32L471JG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

#endif /* defined(STM32L471JG) */


// name     : STM32L471VG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L471
#if defined(STM32L471VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L471VG"
            #else
                #pragma message("Note: Selected MCU - STM32L471VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

#endif /* defined(STM32L471VG) */


// name     : STM32L471QG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L471
#if defined(STM32L471QG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L471QG"
            #else
                #pragma message("Note: Selected MCU - STM32L471QG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

#endif /* defined(STM32L471QG) */


// name     : STM32L471ZG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L471
#if defined(STM32L471ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L471ZG"
            #else
                #pragma message("Note: Selected MCU - STM32L471ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L471)
        #define STM32L471
    #endif

#endif /* defined(STM32L471ZG) */


// name     : STM32L475RC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L475
#if defined(STM32L475RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L475RC"
            #else
                #pragma message("Note: Selected MCU - STM32L475RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

#endif /* defined(STM32L475RC) */


// name     : STM32L475VC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L475
#if defined(STM32L475VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L475VC"
            #else
                #pragma message("Note: Selected MCU - STM32L475VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

#endif /* defined(STM32L475VC) */


// name     : STM32L475RE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L475
#if defined(STM32L475RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L475RE"
            #else
                #pragma message("Note: Selected MCU - STM32L475RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

#endif /* defined(STM32L475RE) */


// name     : STM32L475JE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L475
#if defined(STM32L475JE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L475JE"
            #else
                #pragma message("Note: Selected MCU - STM32L475JE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

#endif /* defined(STM32L475JE) */


// name     : STM32L475VE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L475
#if defined(STM32L475VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L475VE"
            #else
                #pragma message("Note: Selected MCU - STM32L475VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

#endif /* defined(STM32L475VE) */


// name     : STM32L475QE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L475
#if defined(STM32L475QE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L475QE"
            #else
                #pragma message("Note: Selected MCU - STM32L475QE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

#endif /* defined(STM32L475QE) */


// name     : STM32L475ZE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L475
#if defined(STM32L475ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L475ZE"
            #else
                #pragma message("Note: Selected MCU - STM32L475ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

#endif /* defined(STM32L475ZE) */


// name     : STM32L475RG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L475
#if defined(STM32L475RG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L475RG"
            #else
                #pragma message("Note: Selected MCU - STM32L475RG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

#endif /* defined(STM32L475RG) */


// name     : STM32L475JG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L475
#if defined(STM32L475JG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L475JG"
            #else
                #pragma message("Note: Selected MCU - STM32L475JG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

#endif /* defined(STM32L475JG) */


// name     : STM32L475VG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L475
#if defined(STM32L475VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L475VG"
            #else
                #pragma message("Note: Selected MCU - STM32L475VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

#endif /* defined(STM32L475VG) */


// name     : STM32L475QG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L475
#if defined(STM32L475QG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L475QG"
            #else
                #pragma message("Note: Selected MCU - STM32L475QG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

#endif /* defined(STM32L475QG) */


// name     : STM32L475ZG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L475
#if defined(STM32L475ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L475ZG"
            #else
                #pragma message("Note: Selected MCU - STM32L475ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L475)
        #define STM32L475
    #endif

#endif /* defined(STM32L475ZG) */


// name     : STM32L476RC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L476
#if defined(STM32L476RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L476RC"
            #else
                #pragma message("Note: Selected MCU - STM32L476RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

#endif /* defined(STM32L476RC) */


// name     : STM32L476VC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L476
#if defined(STM32L476VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L476VC"
            #else
                #pragma message("Note: Selected MCU - STM32L476VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

#endif /* defined(STM32L476VC) */


// name     : STM32L476RE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L476
#if defined(STM32L476RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L476RE"
            #else
                #pragma message("Note: Selected MCU - STM32L476RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

#endif /* defined(STM32L476RE) */


// name     : STM32L476JE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L476
#if defined(STM32L476JE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L476JE"
            #else
                #pragma message("Note: Selected MCU - STM32L476JE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

#endif /* defined(STM32L476JE) */


// name     : STM32L476ME
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L476
#if defined(STM32L476ME)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L476ME"
            #else
                #pragma message("Note: Selected MCU - STM32L476ME")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

#endif /* defined(STM32L476ME) */


// name     : STM32L476VE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L476
#if defined(STM32L476VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L476VE"
            #else
                #pragma message("Note: Selected MCU - STM32L476VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

#endif /* defined(STM32L476VE) */


// name     : STM32L476QE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L476
#if defined(STM32L476QE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L476QE"
            #else
                #pragma message("Note: Selected MCU - STM32L476QE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

#endif /* defined(STM32L476QE) */


// name     : STM32L476ZE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L476
#if defined(STM32L476ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L476ZE"
            #else
                #pragma message("Note: Selected MCU - STM32L476ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

#endif /* defined(STM32L476ZE) */


// name     : STM32L476RG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L476
#if defined(STM32L476RG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L476RG"
            #else
                #pragma message("Note: Selected MCU - STM32L476RG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

#endif /* defined(STM32L476RG) */


// name     : STM32L476ZG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L476
#if defined(STM32L476ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L476ZG"
            #else
                #pragma message("Note: Selected MCU - STM32L476ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

#endif /* defined(STM32L476ZG) */


// name     : STM32L476JG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L476
#if defined(STM32L476JG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L476JG"
            #else
                #pragma message("Note: Selected MCU - STM32L476JG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

#endif /* defined(STM32L476JG) */


// name     : STM32L476MG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L476
#if defined(STM32L476MG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L476MG"
            #else
                #pragma message("Note: Selected MCU - STM32L476MG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

#endif /* defined(STM32L476MG) */


// name     : STM32L476VG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L476
#if defined(STM32L476VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L476VG"
            #else
                #pragma message("Note: Selected MCU - STM32L476VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

#endif /* defined(STM32L476VG) */


// name     : STM32L476QG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L476
#if defined(STM32L476QG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L476QG"
            #else
                #pragma message("Note: Selected MCU - STM32L476QG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L476)
        #define STM32L476
    #endif

#endif /* defined(STM32L476QG) */


// name     : STM32L485JG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L485
#if defined(STM32L485JG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L485JG"
            #else
                #pragma message("Note: Selected MCU - STM32L485JG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L485)
        #define STM32L485
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L485)
        #define STM32L485
    #endif

#endif /* defined(STM32L485JG) */


// name     : STM32L486RG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L486
#if defined(STM32L486RG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L486RG"
            #else
                #pragma message("Note: Selected MCU - STM32L486RG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L486)
        #define STM32L486
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L486)
        #define STM32L486
    #endif

#endif /* defined(STM32L486RG) */


// name     : STM32L486JG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L486
#if defined(STM32L486JG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L486JG"
            #else
                #pragma message("Note: Selected MCU - STM32L486JG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L486)
        #define STM32L486
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L486)
        #define STM32L486
    #endif

#endif /* defined(STM32L486JG) */


// name     : STM32L486VG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L486
#if defined(STM32L486VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L486VG"
            #else
                #pragma message("Note: Selected MCU - STM32L486VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L486)
        #define STM32L486
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L486)
        #define STM32L486
    #endif

#endif /* defined(STM32L486VG) */


// name     : STM32L486QG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L486
#if defined(STM32L486QG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L486QG"
            #else
                #pragma message("Note: Selected MCU - STM32L486QG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L486)
        #define STM32L486
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L486)
        #define STM32L486
    #endif

#endif /* defined(STM32L486QG) */


// name     : STM32L486ZG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L486
#if defined(STM32L486ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L486ZG"
            #else
                #pragma message("Note: Selected MCU - STM32L486ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L486)
        #define STM32L486
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L486)
        #define STM32L486
    #endif

#endif /* defined(STM32L486ZG) */


// name     : STM32L451RE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L451
#if defined(STM32L451RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L451RE"
            #else
                #pragma message("Note: Selected MCU - STM32L451RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L451)
        #define STM32L451
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L451)
        #define STM32L451
    #endif

#endif /* defined(STM32L451RE) */


// name     : STM32L451RC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L451
#if defined(STM32L451RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L451RC"
            #else
                #pragma message("Note: Selected MCU - STM32L451RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L451)
        #define STM32L451
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L451)
        #define STM32L451
    #endif

#endif /* defined(STM32L451RC) */


// name     : STM32L451CC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L451
#if defined(STM32L451CC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L451CC"
            #else
                #pragma message("Note: Selected MCU - STM32L451CC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L451)
        #define STM32L451
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L451)
        #define STM32L451
    #endif

#endif /* defined(STM32L451CC) */


// name     : STM32L451CE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L451
#if defined(STM32L451CE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L451CE"
            #else
                #pragma message("Note: Selected MCU - STM32L451CE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L451)
        #define STM32L451
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L451)
        #define STM32L451
    #endif

#endif /* defined(STM32L451CE) */


// name     : STM32L451VC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L451
#if defined(STM32L451VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L451VC"
            #else
                #pragma message("Note: Selected MCU - STM32L451VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L451)
        #define STM32L451
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L451)
        #define STM32L451
    #endif

#endif /* defined(STM32L451VC) */


// name     : STM32L451VE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L451
#if defined(STM32L451VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L451VE"
            #else
                #pragma message("Note: Selected MCU - STM32L451VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L451)
        #define STM32L451
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L451)
        #define STM32L451
    #endif

#endif /* defined(STM32L451VE) */


// name     : STM32L452RE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L452
#if defined(STM32L452RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L452RE"
            #else
                #pragma message("Note: Selected MCU - STM32L452RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L452)
        #define STM32L452
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L452)
        #define STM32L452
    #endif

#endif /* defined(STM32L452RE) */


// name     : STM32L452RC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L452
#if defined(STM32L452RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L452RC"
            #else
                #pragma message("Note: Selected MCU - STM32L452RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L452)
        #define STM32L452
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L452)
        #define STM32L452
    #endif

#endif /* defined(STM32L452RC) */


// name     : STM32L452CC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L452
#if defined(STM32L452CC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L452CC"
            #else
                #pragma message("Note: Selected MCU - STM32L452CC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L452)
        #define STM32L452
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L452)
        #define STM32L452
    #endif

#endif /* defined(STM32L452CC) */


// name     : STM32L452CE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L452
#if defined(STM32L452CE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L452CE"
            #else
                #pragma message("Note: Selected MCU - STM32L452CE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L452)
        #define STM32L452
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L452)
        #define STM32L452
    #endif

#endif /* defined(STM32L452CE) */


// name     : STM32L452VC
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L452
#if defined(STM32L452VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L452VC"
            #else
                #pragma message("Note: Selected MCU - STM32L452VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L452)
        #define STM32L452
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L452)
        #define STM32L452
    #endif

#endif /* defined(STM32L452VC) */


// name     : STM32L452VE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L452
#if defined(STM32L452VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L452VE"
            #else
                #pragma message("Note: Selected MCU - STM32L452VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L452)
        #define STM32L452
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L452)
        #define STM32L452
    #endif

#endif /* defined(STM32L452VE) */


// name     : STM32L462RE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L462
#if defined(STM32L462RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L462RE"
            #else
                #pragma message("Note: Selected MCU - STM32L462RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L462)
        #define STM32L462
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L462)
        #define STM32L462
    #endif

#endif /* defined(STM32L462RE) */


// name     : STM32L462CE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L462
#if defined(STM32L462CE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L462CE"
            #else
                #pragma message("Note: Selected MCU - STM32L462CE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L462)
        #define STM32L462
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L462)
        #define STM32L462
    #endif

#endif /* defined(STM32L462CE) */


// name     : STM32L462VE
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L462
#if defined(STM32L462VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L462VE"
            #else
                #pragma message("Note: Selected MCU - STM32L462VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L462)
        #define STM32L462
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L462)
        #define STM32L462
    #endif

#endif /* defined(STM32L462VE) */


// name     : STM32L496RG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L496
#if defined(STM32L496RG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L496RG"
            #else
                #pragma message("Note: Selected MCU - STM32L496RG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L496)
        #define STM32L496
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L496)
        #define STM32L496
    #endif

#endif /* defined(STM32L496RG) */


// name     : STM32L496VG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L496
#if defined(STM32L496VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L496VG"
            #else
                #pragma message("Note: Selected MCU - STM32L496VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L496)
        #define STM32L496
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L496)
        #define STM32L496
    #endif

#endif /* defined(STM32L496VG) */


// name     : STM32L496QG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L496
#if defined(STM32L496QG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L496QG"
            #else
                #pragma message("Note: Selected MCU - STM32L496QG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L496)
        #define STM32L496
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L496)
        #define STM32L496
    #endif

#endif /* defined(STM32L496QG) */


// name     : STM32L496ZG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L496
#if defined(STM32L496ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L496ZG"
            #else
                #pragma message("Note: Selected MCU - STM32L496ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L496)
        #define STM32L496
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L496)
        #define STM32L496
    #endif

#endif /* defined(STM32L496ZG) */


// name     : STM32L496AG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L496
#if defined(STM32L496AG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L496AG"
            #else
                #pragma message("Note: Selected MCU - STM32L496AG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L496)
        #define STM32L496
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L496)
        #define STM32L496
    #endif

#endif /* defined(STM32L496AG) */


// name     : STM32L4A6RG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4A6
#if defined(STM32L4A6RG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4A6RG"
            #else
                #pragma message("Note: Selected MCU - STM32L4A6RG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4A6)
        #define STM32L4A6
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4A6)
        #define STM32L4A6
    #endif

#endif /* defined(STM32L4A6RG) */


// name     : STM32L4A6VG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4A6
#if defined(STM32L4A6VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4A6VG"
            #else
                #pragma message("Note: Selected MCU - STM32L4A6VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4A6)
        #define STM32L4A6
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4A6)
        #define STM32L4A6
    #endif

#endif /* defined(STM32L4A6VG) */


// name     : STM32L4A6QG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4A6
#if defined(STM32L4A6QG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4A6QG"
            #else
                #pragma message("Note: Selected MCU - STM32L4A6QG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4A6)
        #define STM32L4A6
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4A6)
        #define STM32L4A6
    #endif

#endif /* defined(STM32L4A6QG) */


// name     : STM32L4A6ZG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4A6
#if defined(STM32L4A6ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4A6ZG"
            #else
                #pragma message("Note: Selected MCU - STM32L4A6ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4A6)
        #define STM32L4A6
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4A6)
        #define STM32L4A6
    #endif

#endif /* defined(STM32L4A6ZG) */


// name     : STM32L4A6AG
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4A6
#if defined(STM32L4A6AG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4A6AG"
            #else
                #pragma message("Note: Selected MCU - STM32L4A6AG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4A6)
        #define STM32L4A6
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4A6)
        #define STM32L4A6
    #endif

#endif /* defined(STM32L4A6AG) */


// name     : STM32L4R5VI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4R5
#if defined(STM32L4R5VI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4R5VI"
            #else
                #pragma message("Note: Selected MCU - STM32L4R5VI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4R5)
        #define STM32L4R5
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4R5)
        #define STM32L4R5
    #endif

#endif /* defined(STM32L4R5VI) */


// name     : STM32L4R5QI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4R5
#if defined(STM32L4R5QI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4R5QI"
            #else
                #pragma message("Note: Selected MCU - STM32L4R5QI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4R5)
        #define STM32L4R5
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4R5)
        #define STM32L4R5
    #endif

#endif /* defined(STM32L4R5QI) */


// name     : STM32L4R5ZI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4R5
#if defined(STM32L4R5ZI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4R5ZI"
            #else
                #pragma message("Note: Selected MCU - STM32L4R5ZI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4R5)
        #define STM32L4R5
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4R5)
        #define STM32L4R5
    #endif

#endif /* defined(STM32L4R5ZI) */


// name     : STM32L4R5AI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4R5
#if defined(STM32L4R5AI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4R5AI"
            #else
                #pragma message("Note: Selected MCU - STM32L4R5AI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4R5)
        #define STM32L4R5
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4R5)
        #define STM32L4R5
    #endif

#endif /* defined(STM32L4R5AI) */


// name     : STM32L4R7VI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4R7
#if defined(STM32L4R7VI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4R7VI"
            #else
                #pragma message("Note: Selected MCU - STM32L4R7VI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4R7)
        #define STM32L4R7
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4R7)
        #define STM32L4R7
    #endif

#endif /* defined(STM32L4R7VI) */


// name     : STM32L4R7ZI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4R7
#if defined(STM32L4R7ZI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4R7ZI"
            #else
                #pragma message("Note: Selected MCU - STM32L4R7ZI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4R7)
        #define STM32L4R7
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4R7)
        #define STM32L4R7
    #endif

#endif /* defined(STM32L4R7ZI) */


// name     : STM32L4R7AI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4R7
#if defined(STM32L4R7AI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4R7AI"
            #else
                #pragma message("Note: Selected MCU - STM32L4R7AI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4R7)
        #define STM32L4R7
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4R7)
        #define STM32L4R7
    #endif

#endif /* defined(STM32L4R7AI) */


// name     : STM32L4R9VI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4R9
#if defined(STM32L4R9VI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4R9VI"
            #else
                #pragma message("Note: Selected MCU - STM32L4R9VI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4R9)
        #define STM32L4R9
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4R9)
        #define STM32L4R9
    #endif

#endif /* defined(STM32L4R9VI) */


// name     : STM32L4R9ZI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4R9
#if defined(STM32L4R9ZI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4R9ZI"
            #else
                #pragma message("Note: Selected MCU - STM32L4R9ZI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4R9)
        #define STM32L4R9
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4R9)
        #define STM32L4R9
    #endif

#endif /* defined(STM32L4R9ZI) */


// name     : STM32L4R9AI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4R9
#if defined(STM32L4R9AI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4R9AI"
            #else
                #pragma message("Note: Selected MCU - STM32L4R9AI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4R9)
        #define STM32L4R9
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4R9)
        #define STM32L4R9
    #endif

#endif /* defined(STM32L4R9AI) */


// name     : STM32L4S5VI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4S5
#if defined(STM32L4S5VI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4S5VI"
            #else
                #pragma message("Note: Selected MCU - STM32L4S5VI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4S5)
        #define STM32L4S5
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4S5)
        #define STM32L4S5
    #endif

#endif /* defined(STM32L4S5VI) */


// name     : STM32L4S5QI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4S5
#if defined(STM32L4S5QI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4S5QI"
            #else
                #pragma message("Note: Selected MCU - STM32L4S5QI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4S5)
        #define STM32L4S5
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4S5)
        #define STM32L4S5
    #endif

#endif /* defined(STM32L4S5QI) */


// name     : STM32L4S5ZI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4S5
#if defined(STM32L4S5ZI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4S5ZI"
            #else
                #pragma message("Note: Selected MCU - STM32L4S5ZI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4S5)
        #define STM32L4S5
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4S5)
        #define STM32L4S5
    #endif

#endif /* defined(STM32L4S5ZI) */


// name     : STM32L4S5AI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4S5
#if defined(STM32L4S5AI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4S5AI"
            #else
                #pragma message("Note: Selected MCU - STM32L4S5AI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4S5)
        #define STM32L4S5
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4S5)
        #define STM32L4S5
    #endif

#endif /* defined(STM32L4S5AI) */


// name     : STM32L4S7VI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4S7
#if defined(STM32L4S7VI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4S7VI"
            #else
                #pragma message("Note: Selected MCU - STM32L4S7VI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4S7)
        #define STM32L4S7
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4S7)
        #define STM32L4S7
    #endif

#endif /* defined(STM32L4S7VI) */


// name     : STM32L4S7ZI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4S7
#if defined(STM32L4S7ZI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4S7ZI"
            #else
                #pragma message("Note: Selected MCU - STM32L4S7ZI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4S7)
        #define STM32L4S7
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4S7)
        #define STM32L4S7
    #endif

#endif /* defined(STM32L4S7ZI) */


// name     : STM32L4S7AI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4S7
#if defined(STM32L4S7AI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4S7AI"
            #else
                #pragma message("Note: Selected MCU - STM32L4S7AI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4S7)
        #define STM32L4S7
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4S7)
        #define STM32L4S7
    #endif

#endif /* defined(STM32L4S7AI) */


// name     : STM32L4S9VI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4S9
#if defined(STM32L4S9VI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4S9VI"
            #else
                #pragma message("Note: Selected MCU - STM32L4S9VI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4S9)
        #define STM32L4S9
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4S9)
        #define STM32L4S9
    #endif

#endif /* defined(STM32L4S9VI) */


// name     : STM32L4S9ZI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4S9
#if defined(STM32L4S9ZI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4S9ZI"
            #else
                #pragma message("Note: Selected MCU - STM32L4S9ZI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4S9)
        #define STM32L4S9
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4S9)
        #define STM32L4S9
    #endif

#endif /* defined(STM32L4S9ZI) */


// name     : STM32L4S9AI
// core     : Cortex-M4
// family   : STM32L4 Series
// subfamily: STM32L4S9
#if defined(STM32L4S9AI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L4S9AI"
            #else
                #pragma message("Note: Selected MCU - STM32L4S9AI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L4_SERIES)
        #define STM32L4_SERIES
    #endif

    #if !defined(STM32L4S9)
        #define STM32L4S9
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L4S9)
        #define STM32L4S9
    #endif

#endif /* defined(STM32L4S9AI) */


#endif /* defined(STM32L4XX_DEVICES_XML____INC_STM32L4XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00) */

