#pragma once

// Automatically umba-mm-pdsc generated file
// Universal definitions file for STM32/derived devices - C language

// input  : stm32l1xx_devices.xml
// output : ..\inc\stm32l1xx_devices.h

#if !defined(STM32L1XX_DEVICES_XML____INC_STM32L1XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00)
#define STM32L1XX_DEVICES_XML____INC_STM32L1XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00

// name     : STM32L100C6
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L100
#if defined(STM32L100C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L100C6"
            #else
                #pragma message("Note: Selected MCU - STM32L100C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L100)
        #define STM32L100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L100xB)
        #define STM32L100xB
    #endif

#endif /* defined(STM32L100C6) */


// name     : STM32L100R8
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L100
#if defined(STM32L100R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L100R8"
            #else
                #pragma message("Note: Selected MCU - STM32L100R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L100)
        #define STM32L100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    20
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L100xB)
        #define STM32L100xB
    #endif

#endif /* defined(STM32L100R8) */


// name     : STM32L100RB
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L100
#if defined(STM32L100RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L100RB"
            #else
                #pragma message("Note: Selected MCU - STM32L100RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L100)
        #define STM32L100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    20
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L100xB)
        #define STM32L100xB
    #endif

#endif /* defined(STM32L100RB) */


// name     : STM32L100RC
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L100
#if defined(STM32L100RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L100RC"
            #else
                #pragma message("Note: Selected MCU - STM32L100RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L100)
        #define STM32L100
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    8
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L100xC)
        #define STM32L100xC
    #endif

#endif /* defined(STM32L100RC) */


// name     : STM32L151C6
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151C6"
            #else
                #pragma message("Note: Selected MCU - STM32L151C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xB)
        #define STM32L151xB
    #endif

#endif /* defined(STM32L151C6) */


// name     : STM32L151C8
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151C8"
            #else
                #pragma message("Note: Selected MCU - STM32L151C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xB)
        #define STM32L151xB
    #endif

#endif /* defined(STM32L151C8) */


// name     : STM32L151CB
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151CB"
            #else
                #pragma message("Note: Selected MCU - STM32L151CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xB)
        #define STM32L151xB
    #endif

#endif /* defined(STM32L151CB) */


// name     : STM32L151CC
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151CC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151CC"
            #else
                #pragma message("Note: Selected MCU - STM32L151CC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xC)
        #define STM32L151xC
    #endif

#endif /* defined(STM32L151CC) */


// name     : STM32L151QC
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151QC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151QC"
            #else
                #pragma message("Note: Selected MCU - STM32L151QC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    39
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    108
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xCA)
        #define STM32L151xCA
    #endif

    #if !defined(STM32L151xC)
        #define STM32L151xC
    #endif

#endif /* defined(STM32L151QC) */


// name     : STM32L151QD
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151QD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151QD"
            #else
                #pragma message("Note: Selected MCU - STM32L151QD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    39
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    108
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xD)
        #define STM32L151xD
    #endif

#endif /* defined(STM32L151QD) */


// name     : STM32L151R6
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151R6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151R6"
            #else
                #pragma message("Note: Selected MCU - STM32L151R6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    20
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xB)
        #define STM32L151xB
    #endif

#endif /* defined(STM32L151R6) */


// name     : STM32L151R8
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151R8"
            #else
                #pragma message("Note: Selected MCU - STM32L151R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    20
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xB)
        #define STM32L151xB
    #endif

#endif /* defined(STM32L151R8) */


// name     : STM32L151RB
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151RB"
            #else
                #pragma message("Note: Selected MCU - STM32L151RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    20
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xB)
        #define STM32L151xB
    #endif

#endif /* defined(STM32L151RB) */


// name     : STM32L151RC
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151RC"
            #else
                #pragma message("Note: Selected MCU - STM32L151RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xC)
        #define STM32L151xC
    #endif

#endif /* defined(STM32L151RC) */


// name     : STM32L151RD
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151RD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151RD"
            #else
                #pragma message("Note: Selected MCU - STM32L151RD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xD)
        #define STM32L151xD
    #endif

#endif /* defined(STM32L151RD) */


// name     : STM32L151UC
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151UC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151UC"
            #else
                #pragma message("Note: Selected MCU - STM32L151UC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xC)
        #define STM32L151xC
    #endif

#endif /* defined(STM32L151UC) */


// name     : STM32L151V8
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151V8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151V8"
            #else
                #pragma message("Note: Selected MCU - STM32L151V8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xB)
        #define STM32L151xB
    #endif

#endif /* defined(STM32L151V8) */


// name     : STM32L151VB
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151VB"
            #else
                #pragma message("Note: Selected MCU - STM32L151VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xB)
        #define STM32L151xB
    #endif

#endif /* defined(STM32L151VB) */


// name     : STM32L151VC
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151VC"
            #else
                #pragma message("Note: Selected MCU - STM32L151VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    25
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xC)
        #define STM32L151xC
    #endif

#endif /* defined(STM32L151VC) */


// name     : STM32L151VD
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151VD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151VD"
            #else
                #pragma message("Note: Selected MCU - STM32L151VD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    25
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xD)
        #define STM32L151xD
    #endif

#endif /* defined(STM32L151VD) */


// name     : STM32L151ZC
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151ZC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151ZC"
            #else
                #pragma message("Note: Selected MCU - STM32L151ZC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    40
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xCA)
        #define STM32L151xCA
    #endif

    #if !defined(STM32L151xC)
        #define STM32L151xC
    #endif

#endif /* defined(STM32L151ZC) */


// name     : STM32L151ZD
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151ZD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151ZD"
            #else
                #pragma message("Note: Selected MCU - STM32L151ZD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    40
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xD)
        #define STM32L151xD
    #endif

#endif /* defined(STM32L151ZD) */


// name     : STM32L151QE
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151QE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151QE"
            #else
                #pragma message("Note: Selected MCU - STM32L151QE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    40
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    109
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xE)
        #define STM32L151xE
    #endif

#endif /* defined(STM32L151QE) */


// name     : STM32L151RE
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151RE"
            #else
                #pragma message("Note: Selected MCU - STM32L151RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xE)
        #define STM32L151xE
    #endif

#endif /* defined(STM32L151RE) */


// name     : STM32L151VE
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151VE"
            #else
                #pragma message("Note: Selected MCU - STM32L151VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    25
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    83
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xE)
        #define STM32L151xE
    #endif

#endif /* defined(STM32L151VE) */


// name     : STM32L151ZE
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151
#if defined(STM32L151ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151ZE"
            #else
                #pragma message("Note: Selected MCU - STM32L151ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151)
        #define STM32L151
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    40
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    115
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xE)
        #define STM32L151xE
    #endif

#endif /* defined(STM32L151ZE) */


// name     : STM32L152C6
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152C6"
            #else
                #pragma message("Note: Selected MCU - STM32L152C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xB)
        #define STM32L152xB
    #endif

#endif /* defined(STM32L152C6) */


// name     : STM32L152C8
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152C8"
            #else
                #pragma message("Note: Selected MCU - STM32L152C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xB)
        #define STM32L152xB
    #endif

#endif /* defined(STM32L152C8) */


// name     : STM32L152CB
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152CB"
            #else
                #pragma message("Note: Selected MCU - STM32L152CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xB)
        #define STM32L152xB
    #endif

#endif /* defined(STM32L152CB) */


// name     : STM32L152CC
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152CC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152CC"
            #else
                #pragma message("Note: Selected MCU - STM32L152CC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xC)
        #define STM32L152xC
    #endif

#endif /* defined(STM32L152CC) */


// name     : STM32L152QC
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152QC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152QC"
            #else
                #pragma message("Note: Selected MCU - STM32L152QC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    39
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    108
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xCA)
        #define STM32L152xCA
    #endif

    #if !defined(STM32L152xC)
        #define STM32L152xC
    #endif

#endif /* defined(STM32L152QC) */


// name     : STM32L152QD
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152QD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152QD"
            #else
                #pragma message("Note: Selected MCU - STM32L152QD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    39
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    108
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xD)
        #define STM32L152xD
    #endif

#endif /* defined(STM32L152QD) */


// name     : STM32L152R6
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152R6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152R6"
            #else
                #pragma message("Note: Selected MCU - STM32L152R6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    20
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xB)
        #define STM32L152xB
    #endif

#endif /* defined(STM32L152R6) */


// name     : STM32L152R8
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152R8"
            #else
                #pragma message("Note: Selected MCU - STM32L152R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    20
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xB)
        #define STM32L152xB
    #endif

#endif /* defined(STM32L152R8) */


// name     : STM32L152RB
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152RB"
            #else
                #pragma message("Note: Selected MCU - STM32L152RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    20
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xB)
        #define STM32L152xB
    #endif

#endif /* defined(STM32L152RB) */


// name     : STM32L152RC
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152RC"
            #else
                #pragma message("Note: Selected MCU - STM32L152RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xC)
        #define STM32L152xC
    #endif

#endif /* defined(STM32L152RC) */


// name     : STM32L152RD
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152RD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152RD"
            #else
                #pragma message("Note: Selected MCU - STM32L152RD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xD)
        #define STM32L152xD
    #endif

#endif /* defined(STM32L152RD) */


// name     : STM32L152V8
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152V8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152V8"
            #else
                #pragma message("Note: Selected MCU - STM32L152V8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xB)
        #define STM32L152xB
    #endif

#endif /* defined(STM32L152V8) */


// name     : STM32L152VB
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152VB"
            #else
                #pragma message("Note: Selected MCU - STM32L152VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xB)
        #define STM32L152xB
    #endif

#endif /* defined(STM32L152VB) */


// name     : STM32L152VC
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152VC"
            #else
                #pragma message("Note: Selected MCU - STM32L152VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    25
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xC)
        #define STM32L152xC
    #endif

#endif /* defined(STM32L152VC) */


// name     : STM32L152VD
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152VD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152VD"
            #else
                #pragma message("Note: Selected MCU - STM32L152VD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    25
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xD)
        #define STM32L152xD
    #endif

#endif /* defined(STM32L152VD) */


// name     : STM32L152ZC
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152ZC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152ZC"
            #else
                #pragma message("Note: Selected MCU - STM32L152ZC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    40
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xC)
        #define STM32L152xC
    #endif

#endif /* defined(STM32L152ZC) */


// name     : STM32L152ZD
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152ZD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152ZD"
            #else
                #pragma message("Note: Selected MCU - STM32L152ZD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    40
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xD)
        #define STM32L152xD
    #endif

#endif /* defined(STM32L152ZD) */


// name     : STM32L152QE
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152QE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152QE"
            #else
                #pragma message("Note: Selected MCU - STM32L152QE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    40
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    109
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xE)
        #define STM32L152xE
    #endif

#endif /* defined(STM32L152QE) */


// name     : STM32L152RE
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152RE"
            #else
                #pragma message("Note: Selected MCU - STM32L152RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xE)
        #define STM32L152xE
    #endif

#endif /* defined(STM32L152RE) */


// name     : STM32L152VE
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152VE"
            #else
                #pragma message("Note: Selected MCU - STM32L152VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    25
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    83
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xE)
        #define STM32L152xE
    #endif

#endif /* defined(STM32L152VE) */


// name     : STM32L152ZE
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152
#if defined(STM32L152ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152ZE"
            #else
                #pragma message("Note: Selected MCU - STM32L152ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152)
        #define STM32L152
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    40
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    115
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xE)
        #define STM32L152xE
    #endif

#endif /* defined(STM32L152ZE) */


// name     : STM32L162QD
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L162
#if defined(STM32L162QD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L162QD"
            #else
                #pragma message("Note: Selected MCU - STM32L162QD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L162)
        #define STM32L162
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    39
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    108
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L162xD)
        #define STM32L162xD
    #endif

#endif /* defined(STM32L162QD) */


// name     : STM32L162RC
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L162
#if defined(STM32L162RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L162RC"
            #else
                #pragma message("Note: Selected MCU - STM32L162RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L162)
        #define STM32L162
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L162xC)
        #define STM32L162xC
    #endif

#endif /* defined(STM32L162RC) */


// name     : STM32L162RD
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L162
#if defined(STM32L162RD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L162RD"
            #else
                #pragma message("Note: Selected MCU - STM32L162RD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L162)
        #define STM32L162
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L162xD)
        #define STM32L162xD
    #endif

#endif /* defined(STM32L162RD) */


// name     : STM32L162RE
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L162
#if defined(STM32L162RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L162RE"
            #else
                #pragma message("Note: Selected MCU - STM32L162RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L162)
        #define STM32L162
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L162xE)
        #define STM32L162xE
    #endif

#endif /* defined(STM32L162RE) */


// name     : STM32L162VE
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L162
#if defined(STM32L162VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L162VE"
            #else
                #pragma message("Note: Selected MCU - STM32L162VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L162)
        #define STM32L162
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L162xE)
        #define STM32L162xE
    #endif

#endif /* defined(STM32L162VE) */


// name     : STM32L162ZE
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L162
#if defined(STM32L162ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L162ZE"
            #else
                #pragma message("Note: Selected MCU - STM32L162ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L162)
        #define STM32L162
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L162xE)
        #define STM32L162xE
    #endif

#endif /* defined(STM32L162ZE) */


// name     : STM32L162VC
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L162
#if defined(STM32L162VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L162VC"
            #else
                #pragma message("Note: Selected MCU - STM32L162VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L162)
        #define STM32L162
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    25
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    83
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L162xC)
        #define STM32L162xC
    #endif

#endif /* defined(STM32L162VC) */


// name     : STM32L162VD
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L162
#if defined(STM32L162VD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L162VD"
            #else
                #pragma message("Note: Selected MCU - STM32L162VD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L162)
        #define STM32L162
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    25
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L162xD)
        #define STM32L162xD
    #endif

#endif /* defined(STM32L162VD) */


// name     : STM32L162ZD
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L162
#if defined(STM32L162ZD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L162ZD"
            #else
                #pragma message("Note: Selected MCU - STM32L162ZD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L162)
        #define STM32L162
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    40
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L162xD)
        #define STM32L162xD
    #endif

#endif /* defined(STM32L162ZD) */


// name     : STM32L100C6xxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L100xxA
#if defined(STM32L100C6XXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L100C6XXA"
            #else
                #pragma message("Note: Selected MCU - STM32L100C6XXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L100XXA)
        #define STM32L100XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L100xBA)
        #define STM32L100xBA
    #endif

#endif /* defined(STM32L100C6XXA) */


// name     : STM32L100R8xxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L100xxA
#if defined(STM32L100R8XXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L100R8XXA"
            #else
                #pragma message("Note: Selected MCU - STM32L100R8XXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L100XXA)
        #define STM32L100XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    20
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L100xBA)
        #define STM32L100xBA
    #endif

#endif /* defined(STM32L100R8XXA) */


// name     : STM32L100RBxxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L100xxA
#if defined(STM32L100RBXXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L100RBXXA"
            #else
                #pragma message("Note: Selected MCU - STM32L100RBXXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L100XXA)
        #define STM32L100XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    20
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L100xBA)
        #define STM32L100xBA
    #endif

#endif /* defined(STM32L100RBXXA) */


// name     : STM32L151C6xxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151xxA
#if defined(STM32L151C6XXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151C6XXA"
            #else
                #pragma message("Note: Selected MCU - STM32L151C6XXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151XXA)
        #define STM32L151XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xBA)
        #define STM32L151xBA
    #endif

#endif /* defined(STM32L151C6XXA) */


// name     : STM32L151C8xxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151xxA
#if defined(STM32L151C8XXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151C8XXA"
            #else
                #pragma message("Note: Selected MCU - STM32L151C8XXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151XXA)
        #define STM32L151XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xBA)
        #define STM32L151xBA
    #endif

#endif /* defined(STM32L151C8XXA) */


// name     : STM32L151CBxxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151xxA
#if defined(STM32L151CBXXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151CBXXA"
            #else
                #pragma message("Note: Selected MCU - STM32L151CBXXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151XXA)
        #define STM32L151XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xBA)
        #define STM32L151xBA
    #endif

#endif /* defined(STM32L151CBXXA) */


// name     : STM32L151R6xxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151xxA
#if defined(STM32L151R6XXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151R6XXA"
            #else
                #pragma message("Note: Selected MCU - STM32L151R6XXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151XXA)
        #define STM32L151XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    20
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xBA)
        #define STM32L151xBA
    #endif

#endif /* defined(STM32L151R6XXA) */


// name     : STM32L151R8xxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151xxA
#if defined(STM32L151R8XXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151R8XXA"
            #else
                #pragma message("Note: Selected MCU - STM32L151R8XXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151XXA)
        #define STM32L151XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    20
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xBA)
        #define STM32L151xBA
    #endif

#endif /* defined(STM32L151R8XXA) */


// name     : STM32L151RBxxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151xxA
#if defined(STM32L151RBXXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151RBXXA"
            #else
                #pragma message("Note: Selected MCU - STM32L151RBXXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151XXA)
        #define STM32L151XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    20
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xBA)
        #define STM32L151xBA
    #endif

#endif /* defined(STM32L151RBXXA) */


// name     : STM32L151RCxxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151xxA
#if defined(STM32L151RCXXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151RCXXA"
            #else
                #pragma message("Note: Selected MCU - STM32L151RCXXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151XXA)
        #define STM32L151XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xCA)
        #define STM32L151xCA
    #endif

#endif /* defined(STM32L151RCXXA) */


// name     : STM32L151V8xxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151xxA
#if defined(STM32L151V8XXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151V8XXA"
            #else
                #pragma message("Note: Selected MCU - STM32L151V8XXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151XXA)
        #define STM32L151XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    83
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xBA)
        #define STM32L151xBA
    #endif

#endif /* defined(STM32L151V8XXA) */


// name     : STM32L151VBxxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151xxA
#if defined(STM32L151VBXXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151VBXXA"
            #else
                #pragma message("Note: Selected MCU - STM32L151VBXXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151XXA)
        #define STM32L151XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    83
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xBA)
        #define STM32L151xBA
    #endif

#endif /* defined(STM32L151VBXXA) */


// name     : STM32L151VCxxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L151xxA
#if defined(STM32L151VCXXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L151VCXXA"
            #else
                #pragma message("Note: Selected MCU - STM32L151VCXXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L151XXA)
        #define STM32L151XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L151xCA)
        #define STM32L151xCA
    #endif

#endif /* defined(STM32L151VCXXA) */


// name     : STM32L152C6xxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152xxA
#if defined(STM32L152C6XXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152C6XXA"
            #else
                #pragma message("Note: Selected MCU - STM32L152C6XXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152XXA)
        #define STM32L152XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xBA)
        #define STM32L152xBA
    #endif

#endif /* defined(STM32L152C6XXA) */


// name     : STM32L152C8xxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152xxA
#if defined(STM32L152C8XXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152C8XXA"
            #else
                #pragma message("Note: Selected MCU - STM32L152C8XXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152XXA)
        #define STM32L152XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xBA)
        #define STM32L152xBA
    #endif

#endif /* defined(STM32L152C8XXA) */


// name     : STM32L152CBxxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152xxA
#if defined(STM32L152CBXXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152CBXXA"
            #else
                #pragma message("Note: Selected MCU - STM32L152CBXXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152XXA)
        #define STM32L152XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xBA)
        #define STM32L152xBA
    #endif

#endif /* defined(STM32L152CBXXA) */


// name     : STM32L152R6xxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152xxA
#if defined(STM32L152R6XXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152R6XXA"
            #else
                #pragma message("Note: Selected MCU - STM32L152R6XXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152XXA)
        #define STM32L152XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    20
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xBA)
        #define STM32L152xBA
    #endif

#endif /* defined(STM32L152R6XXA) */


// name     : STM32L152R8xxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152xxA
#if defined(STM32L152R8XXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152R8XXA"
            #else
                #pragma message("Note: Selected MCU - STM32L152R8XXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152XXA)
        #define STM32L152XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    20
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xBA)
        #define STM32L152xBA
    #endif

#endif /* defined(STM32L152R8XXA) */


// name     : STM32L152RBxxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152xxA
#if defined(STM32L152RBXXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152RBXXA"
            #else
                #pragma message("Note: Selected MCU - STM32L152RBXXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152XXA)
        #define STM32L152XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    20
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xBA)
        #define STM32L152xBA
    #endif

#endif /* defined(STM32L152RBXXA) */


// name     : STM32L152RCxxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152xxA
#if defined(STM32L152RCXXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152RCXXA"
            #else
                #pragma message("Note: Selected MCU - STM32L152RCXXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152XXA)
        #define STM32L152XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xCA)
        #define STM32L152xCA
    #endif

#endif /* defined(STM32L152RCXXA) */


// name     : STM32L152V8xxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152xxA
#if defined(STM32L152V8XXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152V8XXA"
            #else
                #pragma message("Note: Selected MCU - STM32L152V8XXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152XXA)
        #define STM32L152XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    83
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xBA)
        #define STM32L152xBA
    #endif

#endif /* defined(STM32L152V8XXA) */


// name     : STM32L152VBxxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152xxA
#if defined(STM32L152VBXXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152VBXXA"
            #else
                #pragma message("Note: Selected MCU - STM32L152VBXXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152XXA)
        #define STM32L152XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    83
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xBA)
        #define STM32L152xBA
    #endif

#endif /* defined(STM32L152VBXXA) */


// name     : STM32L152VCxxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L152xxA
#if defined(STM32L152VCXXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L152VCXXA"
            #else
                #pragma message("Note: Selected MCU - STM32L152VCXXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L152XXA)
        #define STM32L152XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L152xCA)
        #define STM32L152xCA
    #endif

#endif /* defined(STM32L152VCXXA) */


// name     : STM32L162RCxxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L162xxA
#if defined(STM32L162RCXXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L162RCXXA"
            #else
                #pragma message("Note: Selected MCU - STM32L162RCXXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L162XXA)
        #define STM32L162XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L162xCA)
        #define STM32L162xCA
    #endif

#endif /* defined(STM32L162RCXXA) */


// name     : STM32L162VCxxA
// core     : Cortex-M3
// family   : STM32L1 Series
// subfamily: STM32L162xxA
#if defined(STM32L162VCXXA)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32L162VCXXA"
            #else
                #pragma message("Note: Selected MCU - STM32L162VCXXA")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32L1_SERIES)
        #define STM32L1_SERIES
    #endif

    #if !defined(STM32L162XXA)
        #define STM32L162XXA
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    32000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_LCD)
        #define STM32_FEATURE_NUM_LCD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32L162xCA)
        #define STM32L162xCA
    #endif

#endif /* defined(STM32L162VCXXA) */


#endif /* defined(STM32L1XX_DEVICES_XML____INC_STM32L1XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00) */

