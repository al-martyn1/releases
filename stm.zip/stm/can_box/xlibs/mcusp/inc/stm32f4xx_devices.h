#pragma once

// Automatically umba-mm-pdsc generated file
// Universal definitions file for STM32/derived devices - C language

// input  : stm32f4xx_devices.xml
// output : ..\inc\stm32f4xx_devices.h

#if !defined(STM32F4XX_DEVICES_XML____INC_STM32F4XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00)
#define STM32F4XX_DEVICES_XML____INC_STM32F4XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00

// name     : STM32F401CB
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F401
#if defined(STM32F401CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F401CB"
            #else
                #pragma message("Note: Selected MCU - STM32F401CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F401)
        #define STM32F401
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    84000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F401xC)
        #define STM32F401xC
    #endif

#endif /* defined(STM32F401CB) */


// name     : STM32F401RB
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F401
#if defined(STM32F401RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F401RB"
            #else
                #pragma message("Note: Selected MCU - STM32F401RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F401)
        #define STM32F401
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    84000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    48
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F401xC)
        #define STM32F401xC
    #endif

#endif /* defined(STM32F401RB) */


// name     : STM32F401VB
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F401
#if defined(STM32F401VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F401VB"
            #else
                #pragma message("Note: Selected MCU - STM32F401VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F401)
        #define STM32F401
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    84000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    79
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F401xC)
        #define STM32F401xC
    #endif

#endif /* defined(STM32F401VB) */


// name     : STM32F401CC
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F401
#if defined(STM32F401CC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F401CC"
            #else
                #pragma message("Note: Selected MCU - STM32F401CC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F401)
        #define STM32F401
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    84000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F401xC)
        #define STM32F401xC
    #endif

#endif /* defined(STM32F401CC) */


// name     : STM32F401RC
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F401
#if defined(STM32F401RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F401RC"
            #else
                #pragma message("Note: Selected MCU - STM32F401RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F401)
        #define STM32F401
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    84000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    48
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F401xC)
        #define STM32F401xC
    #endif

#endif /* defined(STM32F401RC) */


// name     : STM32F401VC
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F401
#if defined(STM32F401VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F401VC"
            #else
                #pragma message("Note: Selected MCU - STM32F401VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F401)
        #define STM32F401
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    84000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    79
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F401xC)
        #define STM32F401xC
    #endif

#endif /* defined(STM32F401VC) */


// name     : STM32F401CD
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F401
#if defined(STM32F401CD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F401CD"
            #else
                #pragma message("Note: Selected MCU - STM32F401CD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F401)
        #define STM32F401
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    84000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    79
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F401xE)
        #define STM32F401xE
    #endif

#endif /* defined(STM32F401CD) */


// name     : STM32F401RD
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F401
#if defined(STM32F401RD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F401RD"
            #else
                #pragma message("Note: Selected MCU - STM32F401RD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F401)
        #define STM32F401
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    84000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    79
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F401xE)
        #define STM32F401xE
    #endif

#endif /* defined(STM32F401RD) */


// name     : STM32F401VD
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F401
#if defined(STM32F401VD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F401VD"
            #else
                #pragma message("Note: Selected MCU - STM32F401VD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F401)
        #define STM32F401
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    84000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    79
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F401xE)
        #define STM32F401xE
    #endif

#endif /* defined(STM32F401VD) */


// name     : STM32F401CE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F401
#if defined(STM32F401CE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F401CE"
            #else
                #pragma message("Note: Selected MCU - STM32F401CE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F401)
        #define STM32F401
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    84000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    79
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F401xE)
        #define STM32F401xE
    #endif

#endif /* defined(STM32F401CE) */


// name     : STM32F401RE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F401
#if defined(STM32F401RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F401RE"
            #else
                #pragma message("Note: Selected MCU - STM32F401RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F401)
        #define STM32F401
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    84000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    79
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F401xE)
        #define STM32F401xE
    #endif

#endif /* defined(STM32F401RE) */


// name     : STM32F401VE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F401
#if defined(STM32F401VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F401VE"
            #else
                #pragma message("Note: Selected MCU - STM32F401VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F401)
        #define STM32F401
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    84000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    79
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F401xE)
        #define STM32F401xE
    #endif

#endif /* defined(STM32F401VE) */


// name     : STM32F410CB
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F410
#if defined(STM32F410CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F410CB"
            #else
                #pragma message("Note: Selected MCU - STM32F410CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F410)
        #define STM32F410
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F410Cx)
        #define STM32F410Cx
    #endif

#endif /* defined(STM32F410CB) */


// name     : STM32F410RB
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F410
#if defined(STM32F410RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F410RB"
            #else
                #pragma message("Note: Selected MCU - STM32F410RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F410)
        #define STM32F410
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F410Rx)
        #define STM32F410Rx
    #endif

#endif /* defined(STM32F410RB) */


// name     : STM32F410TB
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F410
#if defined(STM32F410TB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F410TB"
            #else
                #pragma message("Note: Selected MCU - STM32F410TB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F410)
        #define STM32F410
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F410Tx)
        #define STM32F410Tx
    #endif

#endif /* defined(STM32F410TB) */


// name     : STM32F410C8
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F410
#if defined(STM32F410C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F410C8"
            #else
                #pragma message("Note: Selected MCU - STM32F410C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F410)
        #define STM32F410
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F410Cx)
        #define STM32F410Cx
    #endif

#endif /* defined(STM32F410C8) */


// name     : STM32F410R8
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F410
#if defined(STM32F410R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F410R8"
            #else
                #pragma message("Note: Selected MCU - STM32F410R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F410)
        #define STM32F410
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F410Rx)
        #define STM32F410Rx
    #endif

#endif /* defined(STM32F410R8) */


// name     : STM32F410T8
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F410
#if defined(STM32F410T8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F410T8"
            #else
                #pragma message("Note: Selected MCU - STM32F410T8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F410)
        #define STM32F410
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F410Tx)
        #define STM32F410Tx
    #endif

#endif /* defined(STM32F410T8) */


// name     : STM32F411CC
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F411
#if defined(STM32F411CC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F411CC"
            #else
                #pragma message("Note: Selected MCU - STM32F411CC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F411)
        #define STM32F411
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F411CC) */


// name     : STM32F411RC
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F411
#if defined(STM32F411RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F411RC"
            #else
                #pragma message("Note: Selected MCU - STM32F411RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F411)
        #define STM32F411
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F411RC) */


// name     : STM32F411VC
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F411
#if defined(STM32F411VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F411VC"
            #else
                #pragma message("Note: Selected MCU - STM32F411VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F411)
        #define STM32F411
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    81
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

#endif /* defined(STM32F411VC) */


// name     : STM32F411CE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F411
#if defined(STM32F411CE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F411CE"
            #else
                #pragma message("Note: Selected MCU - STM32F411CE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F411)
        #define STM32F411
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    10
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F411xE)
        #define STM32F411xE
    #endif

#endif /* defined(STM32F411CE) */


// name     : STM32F411RE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F411
#if defined(STM32F411RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F411RE"
            #else
                #pragma message("Note: Selected MCU - STM32F411RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F411)
        #define STM32F411
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    50
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F411xE)
        #define STM32F411xE
    #endif

#endif /* defined(STM32F411RE) */


// name     : STM32F411VE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F411
#if defined(STM32F411VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F411VE"
            #else
                #pragma message("Note: Selected MCU - STM32F411VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F411)
        #define STM32F411
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    81
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    6
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F411xE)
        #define STM32F411xE
    #endif

#endif /* defined(STM32F411VE) */


// name     : STM32F412CE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F412
#if defined(STM32F412CE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F412CE"
            #else
                #pragma message("Note: Selected MCU - STM32F412CE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F412)
        #define STM32F412
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F412Cx)
        #define STM32F412Cx
    #endif

#endif /* defined(STM32F412CE) */


// name     : STM32F412CG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F412
#if defined(STM32F412CG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F412CG"
            #else
                #pragma message("Note: Selected MCU - STM32F412CG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F412)
        #define STM32F412
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F412Cx)
        #define STM32F412Cx
    #endif

#endif /* defined(STM32F412CG) */


// name     : STM32F412RE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F412
#if defined(STM32F412RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F412RE"
            #else
                #pragma message("Note: Selected MCU - STM32F412RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F412)
        #define STM32F412
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F412Rx)
        #define STM32F412Rx
    #endif

#endif /* defined(STM32F412RE) */


// name     : STM32F412RG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F412
#if defined(STM32F412RG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F412RG"
            #else
                #pragma message("Note: Selected MCU - STM32F412RG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F412)
        #define STM32F412
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F412Rx)
        #define STM32F412Rx
    #endif

#endif /* defined(STM32F412RG) */


// name     : STM32F412VE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F412
#if defined(STM32F412VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F412VE"
            #else
                #pragma message("Note: Selected MCU - STM32F412VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F412)
        #define STM32F412
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F412Vx)
        #define STM32F412Vx
    #endif

#endif /* defined(STM32F412VE) */


// name     : STM32F412VG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F412
#if defined(STM32F412VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F412VG"
            #else
                #pragma message("Note: Selected MCU - STM32F412VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F412)
        #define STM32F412
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F412Vx)
        #define STM32F412Vx
    #endif

#endif /* defined(STM32F412VG) */


// name     : STM32F412ZE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F412
#if defined(STM32F412ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F412ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F412ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F412)
        #define STM32F412
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F412Zx)
        #define STM32F412Zx
    #endif

#endif /* defined(STM32F412ZE) */


// name     : STM32F412ZG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F412
#if defined(STM32F412ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F412ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F412ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F412)
        #define STM32F412
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F412Zx)
        #define STM32F412Zx
    #endif

#endif /* defined(STM32F412ZG) */


// name     : STM32F413ZH
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F413
#if defined(STM32F413ZH)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F413ZH"
            #else
                #pragma message("Note: Selected MCU - STM32F413ZH")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F413)
        #define STM32F413
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    4
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F413xx)
        #define STM32F413xx
    #endif

#endif /* defined(STM32F413ZH) */


// name     : STM32F413CH
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F413
#if defined(STM32F413CH)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F413CH"
            #else
                #pragma message("Note: Selected MCU - STM32F413CH")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F413)
        #define STM32F413
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    4
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F413xx)
        #define STM32F413xx
    #endif

#endif /* defined(STM32F413CH) */


// name     : STM32F413RH
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F413
#if defined(STM32F413RH)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F413RH"
            #else
                #pragma message("Note: Selected MCU - STM32F413RH")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F413)
        #define STM32F413
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    4
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F413xx)
        #define STM32F413xx
    #endif

#endif /* defined(STM32F413RH) */


// name     : STM32F413VH
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F413
#if defined(STM32F413VH)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F413VH"
            #else
                #pragma message("Note: Selected MCU - STM32F413VH")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F413)
        #define STM32F413
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    4
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F413xx)
        #define STM32F413xx
    #endif

#endif /* defined(STM32F413VH) */


// name     : STM32F413MH
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F413
#if defined(STM32F413MH)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F413MH"
            #else
                #pragma message("Note: Selected MCU - STM32F413MH")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F413)
        #define STM32F413
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    4
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F413xx)
        #define STM32F413xx
    #endif

#endif /* defined(STM32F413MH) */


// name     : STM32F413ZG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F413
#if defined(STM32F413ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F413ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F413ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F413)
        #define STM32F413
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    4
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F413xx)
        #define STM32F413xx
    #endif

#endif /* defined(STM32F413ZG) */


// name     : STM32F413CG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F413
#if defined(STM32F413CG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F413CG"
            #else
                #pragma message("Note: Selected MCU - STM32F413CG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F413)
        #define STM32F413
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    4
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F413xx)
        #define STM32F413xx
    #endif

#endif /* defined(STM32F413CG) */


// name     : STM32F413RG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F413
#if defined(STM32F413RG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F413RG"
            #else
                #pragma message("Note: Selected MCU - STM32F413RG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F413)
        #define STM32F413
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    4
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F413xx)
        #define STM32F413xx
    #endif

#endif /* defined(STM32F413RG) */


// name     : STM32F413VG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F413
#if defined(STM32F413VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F413VG"
            #else
                #pragma message("Note: Selected MCU - STM32F413VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F413)
        #define STM32F413
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    4
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F413xx)
        #define STM32F413xx
    #endif

#endif /* defined(STM32F413VG) */


// name     : STM32F413MG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F413
#if defined(STM32F413MG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F413MG"
            #else
                #pragma message("Note: Selected MCU - STM32F413MG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F413)
        #define STM32F413
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    4
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F413xx)
        #define STM32F413xx
    #endif

#endif /* defined(STM32F413MG) */


// name     : STM32F423ZH
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F423
#if defined(STM32F423ZH)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F423ZH"
            #else
                #pragma message("Note: Selected MCU - STM32F423ZH")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F423)
        #define STM32F423
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    4
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F423xx)
        #define STM32F423xx
    #endif

#endif /* defined(STM32F423ZH) */


// name     : STM32F423CH
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F423
#if defined(STM32F423CH)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F423CH"
            #else
                #pragma message("Note: Selected MCU - STM32F423CH")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F423)
        #define STM32F423
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    4
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F423xx)
        #define STM32F423xx
    #endif

#endif /* defined(STM32F423CH) */


// name     : STM32F423RH
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F423
#if defined(STM32F423RH)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F423RH"
            #else
                #pragma message("Note: Selected MCU - STM32F423RH")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F423)
        #define STM32F423
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    4
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F423xx)
        #define STM32F423xx
    #endif

#endif /* defined(STM32F423RH) */


// name     : STM32F423VH
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F423
#if defined(STM32F423VH)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F423VH"
            #else
                #pragma message("Note: Selected MCU - STM32F423VH")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F423)
        #define STM32F423
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    4
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F423xx)
        #define STM32F423xx
    #endif

#endif /* defined(STM32F423VH) */


// name     : STM32F423MH
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F423
#if defined(STM32F423MH)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F423MH"
            #else
                #pragma message("Note: Selected MCU - STM32F423MH")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F423)
        #define STM32F423
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    100000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    4
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    5
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F423xx)
        #define STM32F423xx
    #endif

#endif /* defined(STM32F423MH) */


// name     : STM32F405RG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F405
#if defined(STM32F405RG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F405RG"
            #else
                #pragma message("Note: Selected MCU - STM32F405RG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F405)
        #define STM32F405
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F405xx)
        #define STM32F405xx
    #endif

#endif /* defined(STM32F405RG) */


// name     : STM32F405VG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F405
#if defined(STM32F405VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F405VG"
            #else
                #pragma message("Note: Selected MCU - STM32F405VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F405)
        #define STM32F405
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F405xx)
        #define STM32F405xx
    #endif

#endif /* defined(STM32F405VG) */


// name     : STM32F405ZG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F405
#if defined(STM32F405ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F405ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F405ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F405)
        #define STM32F405
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F405xx)
        #define STM32F405xx
    #endif

#endif /* defined(STM32F405ZG) */


// name     : STM32F405OG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F405
#if defined(STM32F405OG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F405OG"
            #else
                #pragma message("Note: Selected MCU - STM32F405OG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F405)
        #define STM32F405
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    72
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F405xx)
        #define STM32F405xx
    #endif

#endif /* defined(STM32F405OG) */


// name     : STM32F405OE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F405
#if defined(STM32F405OE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F405OE"
            #else
                #pragma message("Note: Selected MCU - STM32F405OE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F405)
        #define STM32F405
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    72
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F405xx)
        #define STM32F405xx
    #endif

#endif /* defined(STM32F405OE) */


// name     : STM32F407VG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F407
#if defined(STM32F407VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F407VG"
            #else
                #pragma message("Note: Selected MCU - STM32F407VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F407)
        #define STM32F407
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F407xx)
        #define STM32F407xx
    #endif

#endif /* defined(STM32F407VG) */


// name     : STM32F407IG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F407
#if defined(STM32F407IG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F407IG"
            #else
                #pragma message("Note: Selected MCU - STM32F407IG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F407)
        #define STM32F407
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F407xx)
        #define STM32F407xx
    #endif

#endif /* defined(STM32F407IG) */


// name     : STM32F407ZG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F407
#if defined(STM32F407ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F407ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F407ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F407)
        #define STM32F407
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F407xx)
        #define STM32F407xx
    #endif

#endif /* defined(STM32F407ZG) */


// name     : STM32F407VE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F407
#if defined(STM32F407VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F407VE"
            #else
                #pragma message("Note: Selected MCU - STM32F407VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F407)
        #define STM32F407
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F407xx)
        #define STM32F407xx
    #endif

#endif /* defined(STM32F407VE) */


// name     : STM32F407ZE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F407
#if defined(STM32F407ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F407ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F407ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F407)
        #define STM32F407
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F407xx)
        #define STM32F407xx
    #endif

#endif /* defined(STM32F407ZE) */


// name     : STM32F407IE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F407
#if defined(STM32F407IE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F407IE"
            #else
                #pragma message("Note: Selected MCU - STM32F407IE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F407)
        #define STM32F407
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F407xx)
        #define STM32F407xx
    #endif

#endif /* defined(STM32F407IE) */


// name     : STM32F415RG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F415
#if defined(STM32F415RG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F415RG"
            #else
                #pragma message("Note: Selected MCU - STM32F415RG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F415)
        #define STM32F415
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F415xx)
        #define STM32F415xx
    #endif

#endif /* defined(STM32F415RG) */


// name     : STM32F415VG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F415
#if defined(STM32F415VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F415VG"
            #else
                #pragma message("Note: Selected MCU - STM32F415VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F415)
        #define STM32F415
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F415xx)
        #define STM32F415xx
    #endif

#endif /* defined(STM32F415VG) */


// name     : STM32F415ZG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F415
#if defined(STM32F415ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F415ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F415ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F415)
        #define STM32F415
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F415xx)
        #define STM32F415xx
    #endif

#endif /* defined(STM32F415ZG) */


// name     : STM32F415OG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F415
#if defined(STM32F415OG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F415OG"
            #else
                #pragma message("Note: Selected MCU - STM32F415OG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F415)
        #define STM32F415
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    13
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    72
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F415xx)
        #define STM32F415xx
    #endif

#endif /* defined(STM32F415OG) */


// name     : STM32F417VG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F417
#if defined(STM32F417VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F417VG"
            #else
                #pragma message("Note: Selected MCU - STM32F417VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F417)
        #define STM32F417
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F417xx)
        #define STM32F417xx
    #endif

#endif /* defined(STM32F417VG) */


// name     : STM32F417IG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F417
#if defined(STM32F417IG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F417IG"
            #else
                #pragma message("Note: Selected MCU - STM32F417IG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F417)
        #define STM32F417
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F417xx)
        #define STM32F417xx
    #endif

#endif /* defined(STM32F417IG) */


// name     : STM32F417ZG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F417
#if defined(STM32F417ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F417ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F417ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F417)
        #define STM32F417
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F417xx)
        #define STM32F417xx
    #endif

#endif /* defined(STM32F417ZG) */


// name     : STM32F417VE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F417
#if defined(STM32F417VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F417VE"
            #else
                #pragma message("Note: Selected MCU - STM32F417VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F417)
        #define STM32F417
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F417xx)
        #define STM32F417xx
    #endif

#endif /* defined(STM32F417VE) */


// name     : STM32F417ZE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F417
#if defined(STM32F417ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F417ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F417ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F417)
        #define STM32F417
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F417xx)
        #define STM32F417xx
    #endif

#endif /* defined(STM32F417ZE) */


// name     : STM32F417IE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F417
#if defined(STM32F417IE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F417IE"
            #else
                #pragma message("Note: Selected MCU - STM32F417IE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F417)
        #define STM32F417
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    168000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F417xx)
        #define STM32F417xx
    #endif

#endif /* defined(STM32F417IE) */


// name     : STM32F427AG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F427
#if defined(STM32F427AG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F427AG"
            #else
                #pragma message("Note: Selected MCU - STM32F427AG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F427)
        #define STM32F427
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    130
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F427xx)
        #define STM32F427xx
    #endif

#endif /* defined(STM32F427AG) */


// name     : STM32F427VG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F427
#if defined(STM32F427VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F427VG"
            #else
                #pragma message("Note: Selected MCU - STM32F427VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F427)
        #define STM32F427
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F427xx)
        #define STM32F427xx
    #endif

#endif /* defined(STM32F427VG) */


// name     : STM32F427ZG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F427
#if defined(STM32F427ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F427ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F427ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F427)
        #define STM32F427
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F427xx)
        #define STM32F427xx
    #endif

#endif /* defined(STM32F427ZG) */


// name     : STM32F427IG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F427
#if defined(STM32F427IG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F427IG"
            #else
                #pragma message("Note: Selected MCU - STM32F427IG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F427)
        #define STM32F427
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F427xx)
        #define STM32F427xx
    #endif

#endif /* defined(STM32F427IG) */


// name     : STM32F427AI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F427
#if defined(STM32F427AI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F427AI"
            #else
                #pragma message("Note: Selected MCU - STM32F427AI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F427)
        #define STM32F427
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    130
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F427xx)
        #define STM32F427xx
    #endif

#endif /* defined(STM32F427AI) */


// name     : STM32F427VI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F427
#if defined(STM32F427VI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F427VI"
            #else
                #pragma message("Note: Selected MCU - STM32F427VI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F427)
        #define STM32F427
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F427xx)
        #define STM32F427xx
    #endif

#endif /* defined(STM32F427VI) */


// name     : STM32F427ZI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F427
#if defined(STM32F427ZI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F427ZI"
            #else
                #pragma message("Note: Selected MCU - STM32F427ZI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F427)
        #define STM32F427
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F427xx)
        #define STM32F427xx
    #endif

#endif /* defined(STM32F427ZI) */


// name     : STM32F427II
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F427
#if defined(STM32F427II)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F427II"
            #else
                #pragma message("Note: Selected MCU - STM32F427II")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F427)
        #define STM32F427
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F427xx)
        #define STM32F427xx
    #endif

#endif /* defined(STM32F427II) */


// name     : STM32F429AG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F429
#if defined(STM32F429AG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F429AG"
            #else
                #pragma message("Note: Selected MCU - STM32F429AG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F429)
        #define STM32F429
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    130
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F429xx)
        #define STM32F429xx
    #endif

#endif /* defined(STM32F429AG) */


// name     : STM32F429VG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F429
#if defined(STM32F429VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F429VG"
            #else
                #pragma message("Note: Selected MCU - STM32F429VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F429)
        #define STM32F429
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F429xx)
        #define STM32F429xx
    #endif

#endif /* defined(STM32F429VG) */


// name     : STM32F429ZG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F429
#if defined(STM32F429ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F429ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F429ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F429)
        #define STM32F429
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F429xx)
        #define STM32F429xx
    #endif

#endif /* defined(STM32F429ZG) */


// name     : STM32F429IG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F429
#if defined(STM32F429IG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F429IG"
            #else
                #pragma message("Note: Selected MCU - STM32F429IG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F429)
        #define STM32F429
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F429xx)
        #define STM32F429xx
    #endif

#endif /* defined(STM32F429IG) */


// name     : STM32F429AI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F429
#if defined(STM32F429AI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F429AI"
            #else
                #pragma message("Note: Selected MCU - STM32F429AI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F429)
        #define STM32F429
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    130
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F429xx)
        #define STM32F429xx
    #endif

#endif /* defined(STM32F429AI) */


// name     : STM32F429VI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F429
#if defined(STM32F429VI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F429VI"
            #else
                #pragma message("Note: Selected MCU - STM32F429VI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F429)
        #define STM32F429
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F429xx)
        #define STM32F429xx
    #endif

#endif /* defined(STM32F429VI) */


// name     : STM32F429ZI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F429
#if defined(STM32F429ZI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F429ZI"
            #else
                #pragma message("Note: Selected MCU - STM32F429ZI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F429)
        #define STM32F429
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F429xx)
        #define STM32F429xx
    #endif

#endif /* defined(STM32F429ZI) */


// name     : STM32F429II
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F429
#if defined(STM32F429II)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F429II"
            #else
                #pragma message("Note: Selected MCU - STM32F429II")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F429)
        #define STM32F429
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F429xx)
        #define STM32F429xx
    #endif

#endif /* defined(STM32F429II) */


// name     : STM32F429VE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F429
#if defined(STM32F429VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F429VE"
            #else
                #pragma message("Note: Selected MCU - STM32F429VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F429)
        #define STM32F429
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F429xx)
        #define STM32F429xx
    #endif

#endif /* defined(STM32F429VE) */


// name     : STM32F429ZE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F429
#if defined(STM32F429ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F429ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F429ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F429)
        #define STM32F429
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F429xx)
        #define STM32F429xx
    #endif

#endif /* defined(STM32F429ZE) */


// name     : STM32F429IE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F429
#if defined(STM32F429IE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F429IE"
            #else
                #pragma message("Note: Selected MCU - STM32F429IE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F429)
        #define STM32F429
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F429xx)
        #define STM32F429xx
    #endif

#endif /* defined(STM32F429IE) */


// name     : STM32F429BG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F429
#if defined(STM32F429BG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F429BG"
            #else
                #pragma message("Note: Selected MCU - STM32F429BG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F429)
        #define STM32F429
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    168
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F429xx)
        #define STM32F429xx
    #endif

#endif /* defined(STM32F429BG) */


// name     : STM32F429BI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F429
#if defined(STM32F429BI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F429BI"
            #else
                #pragma message("Note: Selected MCU - STM32F429BI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F429)
        #define STM32F429
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    168
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F429xx)
        #define STM32F429xx
    #endif

#endif /* defined(STM32F429BI) */


// name     : STM32F429BE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F429
#if defined(STM32F429BE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F429BE"
            #else
                #pragma message("Note: Selected MCU - STM32F429BE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F429)
        #define STM32F429
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    168
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F429xx)
        #define STM32F429xx
    #endif

#endif /* defined(STM32F429BE) */


// name     : STM32F429NG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F429
#if defined(STM32F429NG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F429NG"
            #else
                #pragma message("Note: Selected MCU - STM32F429NG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F429)
        #define STM32F429
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    168
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F429xx)
        #define STM32F429xx
    #endif

#endif /* defined(STM32F429NG) */


// name     : STM32F429NI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F429
#if defined(STM32F429NI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F429NI"
            #else
                #pragma message("Note: Selected MCU - STM32F429NI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F429)
        #define STM32F429
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    168
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F429xx)
        #define STM32F429xx
    #endif

#endif /* defined(STM32F429NI) */


// name     : STM32F429NE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F429
#if defined(STM32F429NE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F429NE"
            #else
                #pragma message("Note: Selected MCU - STM32F429NE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F429)
        #define STM32F429
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    168
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F429xx)
        #define STM32F429xx
    #endif

#endif /* defined(STM32F429NE) */


// name     : STM32F437VG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F437
#if defined(STM32F437VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F437VG"
            #else
                #pragma message("Note: Selected MCU - STM32F437VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F437)
        #define STM32F437
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F437xx)
        #define STM32F437xx
    #endif

#endif /* defined(STM32F437VG) */


// name     : STM32F437ZG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F437
#if defined(STM32F437ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F437ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F437ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F437)
        #define STM32F437
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F437xx)
        #define STM32F437xx
    #endif

#endif /* defined(STM32F437ZG) */


// name     : STM32F437IG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F437
#if defined(STM32F437IG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F437IG"
            #else
                #pragma message("Note: Selected MCU - STM32F437IG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F437)
        #define STM32F437
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F437xx)
        #define STM32F437xx
    #endif

#endif /* defined(STM32F437IG) */


// name     : STM32F437AI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F437
#if defined(STM32F437AI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F437AI"
            #else
                #pragma message("Note: Selected MCU - STM32F437AI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F437)
        #define STM32F437
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    130
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F437xx)
        #define STM32F437xx
    #endif

#endif /* defined(STM32F437AI) */


// name     : STM32F437VI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F437
#if defined(STM32F437VI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F437VI"
            #else
                #pragma message("Note: Selected MCU - STM32F437VI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F437)
        #define STM32F437
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F437xx)
        #define STM32F437xx
    #endif

#endif /* defined(STM32F437VI) */


// name     : STM32F437ZI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F437
#if defined(STM32F437ZI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F437ZI"
            #else
                #pragma message("Note: Selected MCU - STM32F437ZI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F437)
        #define STM32F437
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F437xx)
        #define STM32F437xx
    #endif

#endif /* defined(STM32F437ZI) */


// name     : STM32F437II
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F437
#if defined(STM32F437II)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F437II"
            #else
                #pragma message("Note: Selected MCU - STM32F437II")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F437)
        #define STM32F437
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F437xx)
        #define STM32F437xx
    #endif

#endif /* defined(STM32F437II) */


// name     : STM32F439VG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F439
#if defined(STM32F439VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F439VG"
            #else
                #pragma message("Note: Selected MCU - STM32F439VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F439)
        #define STM32F439
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F439xx)
        #define STM32F439xx
    #endif

#endif /* defined(STM32F439VG) */


// name     : STM32F439VI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F439
#if defined(STM32F439VI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F439VI"
            #else
                #pragma message("Note: Selected MCU - STM32F439VI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F439)
        #define STM32F439
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F439xx)
        #define STM32F439xx
    #endif

#endif /* defined(STM32F439VI) */


// name     : STM32F439ZG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F439
#if defined(STM32F439ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F439ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F439ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F439)
        #define STM32F439
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F439xx)
        #define STM32F439xx
    #endif

#endif /* defined(STM32F439ZG) */


// name     : STM32F439ZI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F439
#if defined(STM32F439ZI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F439ZI"
            #else
                #pragma message("Note: Selected MCU - STM32F439ZI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F439)
        #define STM32F439
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F439xx)
        #define STM32F439xx
    #endif

#endif /* defined(STM32F439ZI) */


// name     : STM32F439IG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F439
#if defined(STM32F439IG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F439IG"
            #else
                #pragma message("Note: Selected MCU - STM32F439IG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F439)
        #define STM32F439
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F439xx)
        #define STM32F439xx
    #endif

#endif /* defined(STM32F439IG) */


// name     : STM32F439II
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F439
#if defined(STM32F439II)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F439II"
            #else
                #pragma message("Note: Selected MCU - STM32F439II")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F439)
        #define STM32F439
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F439xx)
        #define STM32F439xx
    #endif

#endif /* defined(STM32F439II) */


// name     : STM32F439BG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F439
#if defined(STM32F439BG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F439BG"
            #else
                #pragma message("Note: Selected MCU - STM32F439BG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F439)
        #define STM32F439
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    168
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F439xx)
        #define STM32F439xx
    #endif

#endif /* defined(STM32F439BG) */


// name     : STM32F439BI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F439
#if defined(STM32F439BI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F439BI"
            #else
                #pragma message("Note: Selected MCU - STM32F439BI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F439)
        #define STM32F439
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    168
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F439xx)
        #define STM32F439xx
    #endif

#endif /* defined(STM32F439BI) */


// name     : STM32F439NG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F439
#if defined(STM32F439NG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F439NG"
            #else
                #pragma message("Note: Selected MCU - STM32F439NG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F439)
        #define STM32F439
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    168
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F439xx)
        #define STM32F439xx
    #endif

#endif /* defined(STM32F439NG) */


// name     : STM32F439NI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F439
#if defined(STM32F439NI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F439NI"
            #else
                #pragma message("Note: Selected MCU - STM32F439NI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F439)
        #define STM32F439
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    168
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F439xx)
        #define STM32F439xx
    #endif

#endif /* defined(STM32F439NI) */


// name     : STM32F439AI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F439
#if defined(STM32F439AI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F439AI"
            #else
                #pragma message("Note: Selected MCU - STM32F439AI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F439)
        #define STM32F439
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    130
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F439xx)
        #define STM32F439xx
    #endif

#endif /* defined(STM32F439AI) */


// name     : STM32F446MC
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F446
#if defined(STM32F446MC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F446MC"
            #else
                #pragma message("Note: Selected MCU - STM32F446MC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F446)
        #define STM32F446
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F446xx)
        #define STM32F446xx
    #endif

#endif /* defined(STM32F446MC) */


// name     : STM32F446RC
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F446
#if defined(STM32F446RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F446RC"
            #else
                #pragma message("Note: Selected MCU - STM32F446RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F446)
        #define STM32F446
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F446xx)
        #define STM32F446xx
    #endif

#endif /* defined(STM32F446RC) */


// name     : STM32F446VC
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F446
#if defined(STM32F446VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F446VC"
            #else
                #pragma message("Note: Selected MCU - STM32F446VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F446)
        #define STM32F446
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F446xx)
        #define STM32F446xx
    #endif

#endif /* defined(STM32F446VC) */


// name     : STM32F446ZC
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F446
#if defined(STM32F446ZC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F446ZC"
            #else
                #pragma message("Note: Selected MCU - STM32F446ZC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F446)
        #define STM32F446
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F446xx)
        #define STM32F446xx
    #endif

#endif /* defined(STM32F446ZC) */


// name     : STM32F446ME
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F446
#if defined(STM32F446ME)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F446ME"
            #else
                #pragma message("Note: Selected MCU - STM32F446ME")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F446)
        #define STM32F446
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F446xx)
        #define STM32F446xx
    #endif

#endif /* defined(STM32F446ME) */


// name     : STM32F446RE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F446
#if defined(STM32F446RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F446RE"
            #else
                #pragma message("Note: Selected MCU - STM32F446RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F446)
        #define STM32F446
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F446xx)
        #define STM32F446xx
    #endif

#endif /* defined(STM32F446RE) */


// name     : STM32F446VE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F446
#if defined(STM32F446VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F446VE"
            #else
                #pragma message("Note: Selected MCU - STM32F446VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F446)
        #define STM32F446
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F446xx)
        #define STM32F446xx
    #endif

#endif /* defined(STM32F446VE) */


// name     : STM32F446ZE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F446
#if defined(STM32F446ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F446ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F446ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F446)
        #define STM32F446
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F446xx)
        #define STM32F446xx
    #endif

#endif /* defined(STM32F446ZE) */


// name     : STM32F469AE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469AE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469AE"
            #else
                #pragma message("Note: Selected MCU - STM32F469AE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469AE) */


// name     : STM32F469AG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469AG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469AG"
            #else
                #pragma message("Note: Selected MCU - STM32F469AG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469AG) */


// name     : STM32F469AI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469AI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469AI"
            #else
                #pragma message("Note: Selected MCU - STM32F469AI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469AI) */


// name     : STM32F469IE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469IE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469IE"
            #else
                #pragma message("Note: Selected MCU - STM32F469IE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469IE) */


// name     : STM32F469IG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469IG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469IG"
            #else
                #pragma message("Note: Selected MCU - STM32F469IG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469IG) */


// name     : STM32F469II
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469II)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469II"
            #else
                #pragma message("Note: Selected MCU - STM32F469II")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469II) */


// name     : STM32F469BE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469BE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469BE"
            #else
                #pragma message("Note: Selected MCU - STM32F469BE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469BE) */


// name     : STM32F469BG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469BG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469BG"
            #else
                #pragma message("Note: Selected MCU - STM32F469BG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469BG) */


// name     : STM32F469BI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469BI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469BI"
            #else
                #pragma message("Note: Selected MCU - STM32F469BI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469BI) */


// name     : STM32F469NE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469NE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469NE"
            #else
                #pragma message("Note: Selected MCU - STM32F469NE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469NE) */


// name     : STM32F469NG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469NG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469NG"
            #else
                #pragma message("Note: Selected MCU - STM32F469NG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469NG) */


// name     : STM32F469NI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469NI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469NI"
            #else
                #pragma message("Note: Selected MCU - STM32F469NI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469NI) */


// name     : STM32F469VE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469VE"
            #else
                #pragma message("Note: Selected MCU - STM32F469VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469VE) */


// name     : STM32F469VG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469VG"
            #else
                #pragma message("Note: Selected MCU - STM32F469VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469VG) */


// name     : STM32F469VI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469VI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469VI"
            #else
                #pragma message("Note: Selected MCU - STM32F469VI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469VI) */


// name     : STM32F469ZE
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F469ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469ZE) */


// name     : STM32F469ZG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F469ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469ZG) */


// name     : STM32F469ZI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F469
#if defined(STM32F469ZI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F469ZI"
            #else
                #pragma message("Note: Selected MCU - STM32F469ZI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F469)
        #define STM32F469
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F469xx)
        #define STM32F469xx
    #endif

#endif /* defined(STM32F469ZI) */


// name     : STM32F479AG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F479
#if defined(STM32F479AG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F479AG"
            #else
                #pragma message("Note: Selected MCU - STM32F479AG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F479)
        #define STM32F479
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F479xx)
        #define STM32F479xx
    #endif

#endif /* defined(STM32F479AG) */


// name     : STM32F479AI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F479
#if defined(STM32F479AI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F479AI"
            #else
                #pragma message("Note: Selected MCU - STM32F479AI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F479)
        #define STM32F479
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F479xx)
        #define STM32F479xx
    #endif

#endif /* defined(STM32F479AI) */


// name     : STM32F479IG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F479
#if defined(STM32F479IG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F479IG"
            #else
                #pragma message("Note: Selected MCU - STM32F479IG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F479)
        #define STM32F479
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F479xx)
        #define STM32F479xx
    #endif

#endif /* defined(STM32F479IG) */


// name     : STM32F479II
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F479
#if defined(STM32F479II)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F479II"
            #else
                #pragma message("Note: Selected MCU - STM32F479II")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F479)
        #define STM32F479
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F479xx)
        #define STM32F479xx
    #endif

#endif /* defined(STM32F479II) */


// name     : STM32F479BG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F479
#if defined(STM32F479BG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F479BG"
            #else
                #pragma message("Note: Selected MCU - STM32F479BG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F479)
        #define STM32F479
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F479xx)
        #define STM32F479xx
    #endif

#endif /* defined(STM32F479BG) */


// name     : STM32F479BI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F479
#if defined(STM32F479BI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F479BI"
            #else
                #pragma message("Note: Selected MCU - STM32F479BI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F479)
        #define STM32F479
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F479xx)
        #define STM32F479xx
    #endif

#endif /* defined(STM32F479BI) */


// name     : STM32F479NG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F479
#if defined(STM32F479NG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F479NG"
            #else
                #pragma message("Note: Selected MCU - STM32F479NG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F479)
        #define STM32F479
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F479xx)
        #define STM32F479xx
    #endif

#endif /* defined(STM32F479NG) */


// name     : STM32F479NI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F479
#if defined(STM32F479NI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F479NI"
            #else
                #pragma message("Note: Selected MCU - STM32F479NI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F479)
        #define STM32F479
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F479xx)
        #define STM32F479xx
    #endif

#endif /* defined(STM32F479NI) */


// name     : STM32F479VG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F479
#if defined(STM32F479VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F479VG"
            #else
                #pragma message("Note: Selected MCU - STM32F479VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F479)
        #define STM32F479
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F479xx)
        #define STM32F479xx
    #endif

#endif /* defined(STM32F479VG) */


// name     : STM32F479VI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F479
#if defined(STM32F479VI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F479VI"
            #else
                #pragma message("Note: Selected MCU - STM32F479VI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F479)
        #define STM32F479
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F479xx)
        #define STM32F479xx
    #endif

#endif /* defined(STM32F479VI) */


// name     : STM32F479ZG
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F479
#if defined(STM32F479ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F479ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F479ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F479)
        #define STM32F479
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F479xx)
        #define STM32F479xx
    #endif

#endif /* defined(STM32F479ZG) */


// name     : STM32F479ZI
// core     : Cortex-M4
// family   : STM32F4 Series
// subfamily: STM32F479
#if defined(STM32F479ZI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F479ZI"
            #else
                #pragma message("Note: Selected MCU - STM32F479ZI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F4_SERIES)
        #define STM32F4_SERIES
    #endif

    #if !defined(STM32F479)
        #define STM32F479
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    180000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_COMOTHER)
        #define STM32_FEATURE_NUM_COMOTHER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    6
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    12
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F479xx)
        #define STM32F479xx
    #endif

#endif /* defined(STM32F479ZI) */


#endif /* defined(STM32F4XX_DEVICES_XML____INC_STM32F4XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00) */

