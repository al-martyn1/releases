#pragma once

// Automatically umba-mm-pdsc generated file
// Universal definitions file for STM32/derived devices - C language

// input  : stm32f3xx_devices.xml
// output : ..\inc\stm32f3xx_devices.h

#if !defined(STM32F3XX_DEVICES_XML____INC_STM32F3XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00)
#define STM32F3XX_DEVICES_XML____INC_STM32F3XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00

// name     : STM32F301C6
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F301
#if defined(STM32F301C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F301C6"
            #else
                #pragma message("Note: Selected MCU - STM32F301C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F301)
        #define STM32F301
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F301x8)
        #define STM32F301x8
    #endif

#endif /* defined(STM32F301C6) */


// name     : STM32F301C8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F301
#if defined(STM32F301C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F301C8"
            #else
                #pragma message("Note: Selected MCU - STM32F301C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F301)
        #define STM32F301
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F301x8)
        #define STM32F301x8
    #endif

#endif /* defined(STM32F301C8) */


// name     : STM32F301K6
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F301
#if defined(STM32F301K6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F301K6"
            #else
                #pragma message("Note: Selected MCU - STM32F301K6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F301)
        #define STM32F301
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    24
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F301x8)
        #define STM32F301x8
    #endif

#endif /* defined(STM32F301K6) */


// name     : STM32F301K8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F301
#if defined(STM32F301K8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F301K8"
            #else
                #pragma message("Note: Selected MCU - STM32F301K8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F301)
        #define STM32F301
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    24
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F301x8)
        #define STM32F301x8
    #endif

#endif /* defined(STM32F301K8) */


// name     : STM32F301R6
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F301
#if defined(STM32F301R6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F301R6"
            #else
                #pragma message("Note: Selected MCU - STM32F301R6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F301)
        #define STM32F301
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F301x8)
        #define STM32F301x8
    #endif

#endif /* defined(STM32F301R6) */


// name     : STM32F301R8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F301
#if defined(STM32F301R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F301R8"
            #else
                #pragma message("Note: Selected MCU - STM32F301R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F301)
        #define STM32F301
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F301x8)
        #define STM32F301x8
    #endif

#endif /* defined(STM32F301R8) */


// name     : STM32F302C6
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302C6"
            #else
                #pragma message("Note: Selected MCU - STM32F302C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302x8)
        #define STM32F302x8
    #endif

#endif /* defined(STM32F302C6) */


// name     : STM32F302C8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302C8"
            #else
                #pragma message("Note: Selected MCU - STM32F302C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    15
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302x8)
        #define STM32F302x8
    #endif

#endif /* defined(STM32F302C8) */


// name     : STM32F302CB
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302CB"
            #else
                #pragma message("Note: Selected MCU - STM32F302CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    9
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302xC)
        #define STM32F302xC
    #endif

#endif /* defined(STM32F302CB) */


// name     : STM32F302CC
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302CC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302CC"
            #else
                #pragma message("Note: Selected MCU - STM32F302CC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    9
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302xC)
        #define STM32F302xC
    #endif

#endif /* defined(STM32F302CC) */


// name     : STM32F302K6
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302K6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302K6"
            #else
                #pragma message("Note: Selected MCU - STM32F302K6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    15
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    24
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302x8)
        #define STM32F302x8
    #endif

#endif /* defined(STM32F302K6) */


// name     : STM32F302K8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302K8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302K8"
            #else
                #pragma message("Note: Selected MCU - STM32F302K8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    15
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    24
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302x8)
        #define STM32F302x8
    #endif

#endif /* defined(STM32F302K8) */


// name     : STM32F302R6
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302R6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302R6"
            #else
                #pragma message("Note: Selected MCU - STM32F302R6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    15
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302x8)
        #define STM32F302x8
    #endif

#endif /* defined(STM32F302R6) */


// name     : STM32F302R8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302R8"
            #else
                #pragma message("Note: Selected MCU - STM32F302R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    15
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302x8)
        #define STM32F302x8
    #endif

#endif /* defined(STM32F302R8) */


// name     : STM32F302RB
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302RB"
            #else
                #pragma message("Note: Selected MCU - STM32F302RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    52
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302xC)
        #define STM32F302xC
    #endif

#endif /* defined(STM32F302RB) */


// name     : STM32F302RC
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302RC"
            #else
                #pragma message("Note: Selected MCU - STM32F302RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    52
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302xC)
        #define STM32F302xC
    #endif

#endif /* defined(STM32F302RC) */


// name     : STM32F302RD
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302RD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302RD"
            #else
                #pragma message("Note: Selected MCU - STM32F302RD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302xE)
        #define STM32F302xE
    #endif

#endif /* defined(STM32F302RD) */


// name     : STM32F302RE
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302RE"
            #else
                #pragma message("Note: Selected MCU - STM32F302RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302xE)
        #define STM32F302xE
    #endif

#endif /* defined(STM32F302RE) */


// name     : STM32F302VB
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302VB"
            #else
                #pragma message("Note: Selected MCU - STM32F302VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    17
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    87
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302xC)
        #define STM32F302xC
    #endif

#endif /* defined(STM32F302VB) */


// name     : STM32F302VC
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302VC"
            #else
                #pragma message("Note: Selected MCU - STM32F302VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    17
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    87
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302xC)
        #define STM32F302xC
    #endif

#endif /* defined(STM32F302VC) */


// name     : STM32F302VD
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302VD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302VD"
            #else
                #pragma message("Note: Selected MCU - STM32F302VD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    17
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    86
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302xE)
        #define STM32F302xE
    #endif

#endif /* defined(STM32F302VD) */


// name     : STM32F302VE
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302VE"
            #else
                #pragma message("Note: Selected MCU - STM32F302VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    17
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    86
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302xE)
        #define STM32F302xE
    #endif

#endif /* defined(STM32F302VE) */


// name     : STM32F302ZD
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302ZD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302ZD"
            #else
                #pragma message("Note: Selected MCU - STM32F302ZD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    18
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    115
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302xE)
        #define STM32F302xE
    #endif

#endif /* defined(STM32F302ZD) */


// name     : STM32F302ZE
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F302
#if defined(STM32F302ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F302ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F302ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F302)
        #define STM32F302
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    18
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    115
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F302xE)
        #define STM32F302xE
    #endif

#endif /* defined(STM32F302ZE) */


// name     : STM32F303C6
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303C6"
            #else
                #pragma message("Note: Selected MCU - STM32F303C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303x8)
        #define STM32F303x8
    #endif

#endif /* defined(STM32F303C6) */


// name     : STM32F303C8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303C8"
            #else
                #pragma message("Note: Selected MCU - STM32F303C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    15
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303x8)
        #define STM32F303x8
    #endif

#endif /* defined(STM32F303C8) */


// name     : STM32F303CB
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303CB"
            #else
                #pragma message("Note: Selected MCU - STM32F303CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    15
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303xC)
        #define STM32F303xC
    #endif

#endif /* defined(STM32F303CB) */


// name     : STM32F303CC
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303CC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303CC"
            #else
                #pragma message("Note: Selected MCU - STM32F303CC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    15
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303xC)
        #define STM32F303xC
    #endif

#endif /* defined(STM32F303CC) */


// name     : STM32F303K6
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303K6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303K6"
            #else
                #pragma message("Note: Selected MCU - STM32F303K6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    9
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    25
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303x8)
        #define STM32F303x8
    #endif

#endif /* defined(STM32F303K6) */


// name     : STM32F303K8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303K8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303K8"
            #else
                #pragma message("Note: Selected MCU - STM32F303K8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    9
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    24
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303x8)
        #define STM32F303x8
    #endif

#endif /* defined(STM32F303K8) */


// name     : STM32F303R6
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303R6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303R6"
            #else
                #pragma message("Note: Selected MCU - STM32F303R6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303x8)
        #define STM32F303x8
    #endif

#endif /* defined(STM32F303R6) */


// name     : STM32F303R8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303R8"
            #else
                #pragma message("Note: Selected MCU - STM32F303R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    21
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303x8)
        #define STM32F303x8
    #endif

#endif /* defined(STM32F303R8) */


// name     : STM32F303RB
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303RB"
            #else
                #pragma message("Note: Selected MCU - STM32F303RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    22
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    52
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303xC)
        #define STM32F303xC
    #endif

#endif /* defined(STM32F303RB) */


// name     : STM32F303RC
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303RC"
            #else
                #pragma message("Note: Selected MCU - STM32F303RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    22
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    52
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303xC)
        #define STM32F303xC
    #endif

#endif /* defined(STM32F303RC) */


// name     : STM32F303RD
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303RD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303RD"
            #else
                #pragma message("Note: Selected MCU - STM32F303RD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    22
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    53
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303xE)
        #define STM32F303xE
    #endif

#endif /* defined(STM32F303RD) */


// name     : STM32F303RE
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303RE"
            #else
                #pragma message("Note: Selected MCU - STM32F303RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    22
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    53
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303xE)
        #define STM32F303xE
    #endif

#endif /* defined(STM32F303RE) */


// name     : STM32F303VB
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303VB"
            #else
                #pragma message("Note: Selected MCU - STM32F303VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    39
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    87
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303xC)
        #define STM32F303xC
    #endif

#endif /* defined(STM32F303VB) */


// name     : STM32F303VC
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303VC"
            #else
                #pragma message("Note: Selected MCU - STM32F303VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    39
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    87
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303xC)
        #define STM32F303xC
    #endif

#endif /* defined(STM32F303VC) */


// name     : STM32F303VD
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303VD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303VD"
            #else
                #pragma message("Note: Selected MCU - STM32F303VD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    39
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    86
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303xE)
        #define STM32F303xE
    #endif

#endif /* defined(STM32F303VD) */


// name     : STM32F303VE
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303VE"
            #else
                #pragma message("Note: Selected MCU - STM32F303VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    39
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    86
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303xE)
        #define STM32F303xE
    #endif

#endif /* defined(STM32F303VE) */


// name     : STM32F303ZD
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303ZD)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303ZD"
            #else
                #pragma message("Note: Selected MCU - STM32F303ZD")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    40
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    115
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303xE)
        #define STM32F303xE
    #endif

#endif /* defined(STM32F303ZD) */


// name     : STM32F303ZE
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F303
#if defined(STM32F303ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F303ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F303ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F303)
        #define STM32F303
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    40
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    116
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F303xE)
        #define STM32F303xE
    #endif

#endif /* defined(STM32F303ZE) */


// name     : STM32F373C8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F373
#if defined(STM32F373C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F373C8"
            #else
                #pragma message("Note: Selected MCU - STM32F373C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F373)
        #define STM32F373
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F373xC)
        #define STM32F373xC
    #endif

#endif /* defined(STM32F373C8) */


// name     : STM32F373CB
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F373
#if defined(STM32F373CB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F373CB"
            #else
                #pragma message("Note: Selected MCU - STM32F373CB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F373)
        #define STM32F373
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F373xC)
        #define STM32F373xC
    #endif

#endif /* defined(STM32F373CB) */


// name     : STM32F373CC
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F373
#if defined(STM32F373CC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F373CC"
            #else
                #pragma message("Note: Selected MCU - STM32F373CC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F373)
        #define STM32F373
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F373xC)
        #define STM32F373xC
    #endif

#endif /* defined(STM32F373CC) */


// name     : STM32F373R8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F373
#if defined(STM32F373R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F373R8"
            #else
                #pragma message("Note: Selected MCU - STM32F373R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F373)
        #define STM32F373
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    52
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F373xC)
        #define STM32F373xC
    #endif

#endif /* defined(STM32F373R8) */


// name     : STM32F373RB
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F373
#if defined(STM32F373RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F373RB"
            #else
                #pragma message("Note: Selected MCU - STM32F373RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F373)
        #define STM32F373
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    52
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F373xC)
        #define STM32F373xC
    #endif

#endif /* defined(STM32F373RB) */


// name     : STM32F373RC
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F373
#if defined(STM32F373RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F373RC"
            #else
                #pragma message("Note: Selected MCU - STM32F373RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F373)
        #define STM32F373
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    52
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F373xC)
        #define STM32F373xC
    #endif

#endif /* defined(STM32F373RC) */


// name     : STM32F373V8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F373
#if defined(STM32F373V8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F373V8"
            #else
                #pragma message("Note: Selected MCU - STM32F373V8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F373)
        #define STM32F373
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    84
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F373xC)
        #define STM32F373xC
    #endif

#endif /* defined(STM32F373V8) */


// name     : STM32F373VB
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F373
#if defined(STM32F373VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F373VB"
            #else
                #pragma message("Note: Selected MCU - STM32F373VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F373)
        #define STM32F373
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    84
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F373xC)
        #define STM32F373xC
    #endif

#endif /* defined(STM32F373VB) */


// name     : STM32F373VC
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F373
#if defined(STM32F373VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F373VC"
            #else
                #pragma message("Note: Selected MCU - STM32F373VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F373)
        #define STM32F373
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    84
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F373xC)
        #define STM32F373xC
    #endif

#endif /* defined(STM32F373VC) */


// name     : STM32F334C4
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x4
#if defined(STM32F334C4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F334C4"
            #else
                #pragma message("Note: Selected MCU - STM32F334C4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X4)
        #define STM32F3X4
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F334x8)
        #define STM32F334x8
    #endif

#endif /* defined(STM32F334C4) */


// name     : STM32F334C6
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x4
#if defined(STM32F334C6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F334C6"
            #else
                #pragma message("Note: Selected MCU - STM32F334C6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X4)
        #define STM32F3X4
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    15
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F334x8)
        #define STM32F334x8
    #endif

#endif /* defined(STM32F334C6) */


// name     : STM32F334C8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x4
#if defined(STM32F334C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F334C8"
            #else
                #pragma message("Note: Selected MCU - STM32F334C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X4)
        #define STM32F3X4
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F334x8)
        #define STM32F334x8
    #endif

#endif /* defined(STM32F334C8) */


// name     : STM32F334K4
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x4
#if defined(STM32F334K4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F334K4"
            #else
                #pragma message("Note: Selected MCU - STM32F334K4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X4)
        #define STM32F3X4
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    24
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F334x8)
        #define STM32F334x8
    #endif

#endif /* defined(STM32F334K4) */


// name     : STM32F334K6
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x4
#if defined(STM32F334K6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F334K6"
            #else
                #pragma message("Note: Selected MCU - STM32F334K6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X4)
        #define STM32F3X4
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    25
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F334x8)
        #define STM32F334x8
    #endif

#endif /* defined(STM32F334K6) */


// name     : STM32F334K8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x4
#if defined(STM32F334K8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F334K8"
            #else
                #pragma message("Note: Selected MCU - STM32F334K8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X4)
        #define STM32F3X4
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    25
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F334x8)
        #define STM32F334x8
    #endif

#endif /* defined(STM32F334K8) */


// name     : STM32F334R6
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x4
#if defined(STM32F334R6)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F334R6"
            #else
                #pragma message("Note: Selected MCU - STM32F334R6")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X4)
        #define STM32F3X4
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    4
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F334x8)
        #define STM32F334x8
    #endif

#endif /* defined(STM32F334R6) */


// name     : STM32F334R8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x4
#if defined(STM32F334R8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F334R8"
            #else
                #pragma message("Note: Selected MCU - STM32F334R8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X4)
        #define STM32F3X4
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    4
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F334x8)
        #define STM32F334x8
    #endif

#endif /* defined(STM32F334R8) */


// name     : STM32F318C8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x8
#if defined(STM32F318C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F318C8"
            #else
                #pragma message("Note: Selected MCU - STM32F318C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X8)
        #define STM32F3X8
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F318xx)
        #define STM32F318xx
    #endif

#endif /* defined(STM32F318C8) */


// name     : STM32F318K8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x8
#if defined(STM32F318K8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F318K8"
            #else
                #pragma message("Note: Selected MCU - STM32F318K8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X8)
        #define STM32F3X8
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    24
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    2
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F318xx)
        #define STM32F318xx
    #endif

#endif /* defined(STM32F318K8) */


// name     : STM32F328C8
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x8
#if defined(STM32F328C8)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F328C8"
            #else
                #pragma message("Note: Selected MCU - STM32F328C8")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X8)
        #define STM32F3X8
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    1
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    1
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F328xx)
        #define STM32F328xx
    #endif

#endif /* defined(STM32F328C8) */


// name     : STM32F358CC
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x8
#if defined(STM32F358CC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F358CC"
            #else
                #pragma message("Note: Selected MCU - STM32F358CC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X8)
        #define STM32F3X8
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    4
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    37
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F358xx)
        #define STM32F358xx
    #endif

#endif /* defined(STM32F358CC) */


// name     : STM32F358RC
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x8
#if defined(STM32F358RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F358RC"
            #else
                #pragma message("Note: Selected MCU - STM32F358RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X8)
        #define STM32F3X8
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    4
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    53
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F358xx)
        #define STM32F358xx
    #endif

#endif /* defined(STM32F358RC) */


// name     : STM32F358VC
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x8
#if defined(STM32F358VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F358VC"
            #else
                #pragma message("Note: Selected MCU - STM32F358VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X8)
        #define STM32F3X8
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    4
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    88
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F358xx)
        #define STM32F358xx
    #endif

#endif /* defined(STM32F358VC) */


// name     : STM32F378CC
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x8
#if defined(STM32F378CC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F378CC"
            #else
                #pragma message("Note: Selected MCU - STM32F378CC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X8)
        #define STM32F3X8
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    36
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F378xx)
        #define STM32F378xx
    #endif

#endif /* defined(STM32F378CC) */


// name     : STM32F378RC
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x8
#if defined(STM32F378RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F378RC"
            #else
                #pragma message("Note: Selected MCU - STM32F378RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X8)
        #define STM32F3X8
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    52
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F378xx)
        #define STM32F378xx
    #endif

#endif /* defined(STM32F378RC) */


// name     : STM32F378VC
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x8
#if defined(STM32F378VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F378VC"
            #else
                #pragma message("Note: Selected MCU - STM32F378VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X8)
        #define STM32F3X8
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    1
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    84
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    3
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F378xx)
        #define STM32F378xx
    #endif

#endif /* defined(STM32F378VC) */


// name     : STM32F398VE
// core     : Cortex-M4
// family   : STM32F3 Series
// subfamily: STM32F3x8
#if defined(STM32F398VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F398VE"
            #else
                #pragma message("Note: Selected MCU - STM32F398VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F3_SERIES)
        #define STM32F3_SERIES
    #endif

    #if !defined(STM32F3X8)
        #define STM32F3X8
    #endif

    #if !defined(CORTEX_M4)
        #define CORTEX_M4
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    72000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    39
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    88
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    4
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    5
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_USBD)
        #define STM32_FEATURE_NUM_USBD    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F398xx)
        #define STM32F398xx
    #endif

#endif /* defined(STM32F398VE) */


#endif /* defined(STM32F3XX_DEVICES_XML____INC_STM32F3XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00) */

