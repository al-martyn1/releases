#pragma once

// Automatically umba-mm-pdsc generated file
// Universal definitions file for STM32/derived devices - C language

// input  : mdr1986bexx_devices.xml
// output : ..\inc\mdr1986bexx_devices.h

#if !defined(MDR1986BEXX_DEVICES_XML____INC_MDR1986BEXX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00)
#define MDR1986BEXX_DEVICES_XML____INC_MDR1986BEXX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00

// name     : MDR1986BE91
// core     : Cortex-M3
// family   : Milandr
// subfamily: 
#if defined(MDR1986BE91)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - MDR1986BE91"
            #else
                #pragma message("Note: Selected MCU - MDR1986BE91")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(MILANDR)
        #define MILANDR
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(USE_MDR32F9Q1_Rev1)
        #define USE_MDR32F9Q1_Rev1
    #endif

    #if !defined(MDR1986BE9x)
        #define MDR1986BE9x
    #endif

#endif /* defined(MDR1986BE91) */


// name     : MDR1986BE92
// core     : Cortex-M3
// family   : Milandr
// subfamily: 
#if defined(MDR1986BE92)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - MDR1986BE92"
            #else
                #pragma message("Note: Selected MCU - MDR1986BE92")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(MILANDR)
        #define MILANDR
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(USE_MDR32F9Q2_Rev1)
        #define USE_MDR32F9Q2_Rev1
    #endif

    #if !defined(MDR1986BE9x)
        #define MDR1986BE9x
    #endif

#endif /* defined(MDR1986BE92) */


// name     : MDR1986BE93
// core     : Cortex-M3
// family   : Milandr
// subfamily: 
#if defined(MDR1986BE93)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - MDR1986BE93"
            #else
                #pragma message("Note: Selected MCU - MDR1986BE93")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(MILANDR)
        #define MILANDR
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(USE_MDR32F9Q3_Rev1)
        #define USE_MDR32F9Q3_Rev1
    #endif

    #if !defined(MDR1986BE9x)
        #define MDR1986BE9x
    #endif

#endif /* defined(MDR1986BE93) */


// name     : MDR1986BE1T
// core     : Cortex-M1
// family   : Milandr
// subfamily: 
#if defined(MDR1986BE1T)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - MDR1986BE1T"
            #else
                #pragma message("Note: Selected MCU - MDR1986BE1T")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(MILANDR)
        #define MILANDR
    #endif

    #if !defined(CORTEX_M1)
        #define CORTEX_M1
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    144000000
    #endif

    #if !defined(USE_MDR1986VE1T)
        #define USE_MDR1986VE1T
    #endif

    #if !defined(MDR1986BE1T)
        #define MDR1986BE1T
    #endif

#endif /* defined(MDR1986BE1T) */


// name     : MDR1986BE3T
// core     : Cortex-M1
// family   : Milandr
// subfamily: 
#if defined(MDR1986BE3T)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - MDR1986BE3T"
            #else
                #pragma message("Note: Selected MCU - MDR1986BE3T")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(MILANDR)
        #define MILANDR
    #endif

    #if !defined(CORTEX_M1)
        #define CORTEX_M1
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    80000000
    #endif

    #if !defined(USE_MDR1986VE3)
        #define USE_MDR1986VE3
    #endif

    #if !defined(MDR1986BE3T)
        #define MDR1986BE3T
    #endif

#endif /* defined(MDR1986BE3T) */


// name     : MDR1986BE4
// core     : Cortex-M0
// family   : Milandr
// subfamily: 
#if defined(MDR1986BE4)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - MDR1986BE4"
            #else
                #pragma message("Note: Selected MCU - MDR1986BE4")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(MILANDR)
        #define MILANDR
    #endif

    #if !defined(CORTEX_M0)
        #define CORTEX_M0
    #endif

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    36000000
    #endif

    #if !defined(USE_MDR1986BE4)
        #define USE_MDR1986BE4
    #endif

    #if !defined(MDR1986BE4)
        #define MDR1986BE4
    #endif

#endif /* defined(MDR1986BE4) */


#endif /* defined(MDR1986BEXX_DEVICES_XML____INC_MDR1986BEXX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00) */

