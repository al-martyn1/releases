#pragma once

// Automatically umba-mm-pdsc generated file
// Universal definitions file for STM32/derived devices - C language

// input  : stm32f7xx_devices.xml
// output : ..\inc\stm32f7xx_devices.h

#if !defined(STM32F7XX_DEVICES_XML____INC_STM32F7XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00)
#define STM32F7XX_DEVICES_XML____INC_STM32F7XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00

// name     : STM32F745ZG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F745
#if defined(STM32F745ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F745ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F745ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F745)
        #define STM32F745
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F745)
        #define STM32F745
    #endif

#endif /* defined(STM32F745ZG) */


// name     : STM32F745ZE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F745
#if defined(STM32F745ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F745ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F745ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F745)
        #define STM32F745
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F745)
        #define STM32F745
    #endif

#endif /* defined(STM32F745ZE) */


// name     : STM32F745VG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F745
#if defined(STM32F745VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F745VG"
            #else
                #pragma message("Note: Selected MCU - STM32F745VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F745)
        #define STM32F745
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F745)
        #define STM32F745
    #endif

#endif /* defined(STM32F745VG) */


// name     : STM32F745VE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F745
#if defined(STM32F745VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F745VE"
            #else
                #pragma message("Note: Selected MCU - STM32F745VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F745)
        #define STM32F745
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F745)
        #define STM32F745
    #endif

#endif /* defined(STM32F745VE) */


// name     : STM32F745IG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F745
#if defined(STM32F745IG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F745IG"
            #else
                #pragma message("Note: Selected MCU - STM32F745IG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F745)
        #define STM32F745
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F745)
        #define STM32F745
    #endif

#endif /* defined(STM32F745IG) */


// name     : STM32F745IE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F745
#if defined(STM32F745IE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F745IE"
            #else
                #pragma message("Note: Selected MCU - STM32F745IE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F745)
        #define STM32F745
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F745)
        #define STM32F745
    #endif

#endif /* defined(STM32F745IE) */


// name     : STM32F746ZG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F746
#if defined(STM32F746ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F746ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F746ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

#endif /* defined(STM32F746ZG) */


// name     : STM32F746VG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F746
#if defined(STM32F746VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F746VG"
            #else
                #pragma message("Note: Selected MCU - STM32F746VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

#endif /* defined(STM32F746VG) */


// name     : STM32F746IG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F746
#if defined(STM32F746IG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F746IG"
            #else
                #pragma message("Note: Selected MCU - STM32F746IG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

#endif /* defined(STM32F746IG) */


// name     : STM32F746BG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F746
#if defined(STM32F746BG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F746BG"
            #else
                #pragma message("Note: Selected MCU - STM32F746BG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

#endif /* defined(STM32F746BG) */


// name     : STM32F746NG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F746
#if defined(STM32F746NG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F746NG"
            #else
                #pragma message("Note: Selected MCU - STM32F746NG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

#endif /* defined(STM32F746NG) */


// name     : STM32F746ZE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F746
#if defined(STM32F746ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F746ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F746ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

#endif /* defined(STM32F746ZE) */


// name     : STM32F746VE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F746
#if defined(STM32F746VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F746VE"
            #else
                #pragma message("Note: Selected MCU - STM32F746VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

#endif /* defined(STM32F746VE) */


// name     : STM32F746IE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F746
#if defined(STM32F746IE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F746IE"
            #else
                #pragma message("Note: Selected MCU - STM32F746IE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

#endif /* defined(STM32F746IE) */


// name     : STM32F746BE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F746
#if defined(STM32F746BE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F746BE"
            #else
                #pragma message("Note: Selected MCU - STM32F746BE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

#endif /* defined(STM32F746BE) */


// name     : STM32F746NE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F746
#if defined(STM32F746NE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F746NE"
            #else
                #pragma message("Note: Selected MCU - STM32F746NE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F746)
        #define STM32F746
    #endif

#endif /* defined(STM32F746NE) */


// name     : STM32F756ZG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F756
#if defined(STM32F756ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F756ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F756ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F756)
        #define STM32F756
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F756)
        #define STM32F756
    #endif

#endif /* defined(STM32F756ZG) */


// name     : STM32F756VG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F756
#if defined(STM32F756VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F756VG"
            #else
                #pragma message("Note: Selected MCU - STM32F756VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F756)
        #define STM32F756
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F756)
        #define STM32F756
    #endif

#endif /* defined(STM32F756VG) */


// name     : STM32F756IG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F756
#if defined(STM32F756IG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F756IG"
            #else
                #pragma message("Note: Selected MCU - STM32F756IG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F756)
        #define STM32F756
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F756)
        #define STM32F756
    #endif

#endif /* defined(STM32F756IG) */


// name     : STM32F756BG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F756
#if defined(STM32F756BG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F756BG"
            #else
                #pragma message("Note: Selected MCU - STM32F756BG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F756)
        #define STM32F756
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F756)
        #define STM32F756
    #endif

#endif /* defined(STM32F756BG) */


// name     : STM32F756NG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F756
#if defined(STM32F756NG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F756NG"
            #else
                #pragma message("Note: Selected MCU - STM32F756NG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F756)
        #define STM32F756
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F756)
        #define STM32F756
    #endif

#endif /* defined(STM32F756NG) */


// name     : STM32F765BG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F765
#if defined(STM32F765BG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F765BG"
            #else
                #pragma message("Note: Selected MCU - STM32F765BG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

#endif /* defined(STM32F765BG) */


// name     : STM32F765BI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F765
#if defined(STM32F765BI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F765BI"
            #else
                #pragma message("Note: Selected MCU - STM32F765BI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

#endif /* defined(STM32F765BI) */


// name     : STM32F765IG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F765
#if defined(STM32F765IG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F765IG"
            #else
                #pragma message("Note: Selected MCU - STM32F765IG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

#endif /* defined(STM32F765IG) */


// name     : STM32F765II
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F765
#if defined(STM32F765II)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F765II"
            #else
                #pragma message("Note: Selected MCU - STM32F765II")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

#endif /* defined(STM32F765II) */


// name     : STM32F765NG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F765
#if defined(STM32F765NG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F765NG"
            #else
                #pragma message("Note: Selected MCU - STM32F765NG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

#endif /* defined(STM32F765NG) */


// name     : STM32F765NI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F765
#if defined(STM32F765NI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F765NI"
            #else
                #pragma message("Note: Selected MCU - STM32F765NI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

#endif /* defined(STM32F765NI) */


// name     : STM32F765VG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F765
#if defined(STM32F765VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F765VG"
            #else
                #pragma message("Note: Selected MCU - STM32F765VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

#endif /* defined(STM32F765VG) */


// name     : STM32F765VI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F765
#if defined(STM32F765VI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F765VI"
            #else
                #pragma message("Note: Selected MCU - STM32F765VI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

#endif /* defined(STM32F765VI) */


// name     : STM32F765ZG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F765
#if defined(STM32F765ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F765ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F765ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

#endif /* defined(STM32F765ZG) */


// name     : STM32F765ZI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F765
#if defined(STM32F765ZI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F765ZI"
            #else
                #pragma message("Note: Selected MCU - STM32F765ZI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F765)
        #define STM32F765
    #endif

#endif /* defined(STM32F765ZI) */


// name     : STM32F767BI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F767
#if defined(STM32F767BI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F767BI"
            #else
                #pragma message("Note: Selected MCU - STM32F767BI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

#endif /* defined(STM32F767BI) */


// name     : STM32F767BG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F767
#if defined(STM32F767BG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F767BG"
            #else
                #pragma message("Note: Selected MCU - STM32F767BG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

#endif /* defined(STM32F767BG) */


// name     : STM32F767NI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F767
#if defined(STM32F767NI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F767NI"
            #else
                #pragma message("Note: Selected MCU - STM32F767NI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

#endif /* defined(STM32F767NI) */


// name     : STM32F767NG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F767
#if defined(STM32F767NG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F767NG"
            #else
                #pragma message("Note: Selected MCU - STM32F767NG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

#endif /* defined(STM32F767NG) */


// name     : STM32F767II
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F767
#if defined(STM32F767II)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F767II"
            #else
                #pragma message("Note: Selected MCU - STM32F767II")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

#endif /* defined(STM32F767II) */


// name     : STM32F767IG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F767
#if defined(STM32F767IG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F767IG"
            #else
                #pragma message("Note: Selected MCU - STM32F767IG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

#endif /* defined(STM32F767IG) */


// name     : STM32F767ZI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F767
#if defined(STM32F767ZI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F767ZI"
            #else
                #pragma message("Note: Selected MCU - STM32F767ZI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

#endif /* defined(STM32F767ZI) */


// name     : STM32F767ZG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F767
#if defined(STM32F767ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F767ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F767ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

#endif /* defined(STM32F767ZG) */


// name     : STM32F767VI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F767
#if defined(STM32F767VI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F767VI"
            #else
                #pragma message("Note: Selected MCU - STM32F767VI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

#endif /* defined(STM32F767VI) */


// name     : STM32F767VG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F767
#if defined(STM32F767VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F767VG"
            #else
                #pragma message("Note: Selected MCU - STM32F767VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F767)
        #define STM32F767
    #endif

#endif /* defined(STM32F767VG) */


// name     : STM32F768AI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F768
#if defined(STM32F768AI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F768AI"
            #else
                #pragma message("Note: Selected MCU - STM32F768AI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F768)
        #define STM32F768
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F768)
        #define STM32F768
    #endif

#endif /* defined(STM32F768AI) */


// name     : STM32F769BI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F769
#if defined(STM32F769BI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F769BI"
            #else
                #pragma message("Note: Selected MCU - STM32F769BI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F769)
        #define STM32F769
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F769)
        #define STM32F769
    #endif

#endif /* defined(STM32F769BI) */


// name     : STM32F769BG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F769
#if defined(STM32F769BG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F769BG"
            #else
                #pragma message("Note: Selected MCU - STM32F769BG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F769)
        #define STM32F769
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F769)
        #define STM32F769
    #endif

#endif /* defined(STM32F769BG) */


// name     : STM32F769NI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F769
#if defined(STM32F769NI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F769NI"
            #else
                #pragma message("Note: Selected MCU - STM32F769NI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F769)
        #define STM32F769
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F769)
        #define STM32F769
    #endif

#endif /* defined(STM32F769NI) */


// name     : STM32F769NG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F769
#if defined(STM32F769NG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F769NG"
            #else
                #pragma message("Note: Selected MCU - STM32F769NG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F769)
        #define STM32F769
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F769)
        #define STM32F769
    #endif

#endif /* defined(STM32F769NG) */


// name     : STM32F769II
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F769
#if defined(STM32F769II)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F769II"
            #else
                #pragma message("Note: Selected MCU - STM32F769II")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F769)
        #define STM32F769
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F769)
        #define STM32F769
    #endif

#endif /* defined(STM32F769II) */


// name     : STM32F769IG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F769
#if defined(STM32F769IG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F769IG"
            #else
                #pragma message("Note: Selected MCU - STM32F769IG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F769)
        #define STM32F769
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F769)
        #define STM32F769
    #endif

#endif /* defined(STM32F769IG) */


// name     : STM32F769AI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F769
#if defined(STM32F769AI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F769AI"
            #else
                #pragma message("Note: Selected MCU - STM32F769AI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F769)
        #define STM32F769
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F769)
        #define STM32F769
    #endif

#endif /* defined(STM32F769AI) */


// name     : STM32F769AG
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F769
#if defined(STM32F769AG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F769AG"
            #else
                #pragma message("Note: Selected MCU - STM32F769AG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F769)
        #define STM32F769
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F769)
        #define STM32F769
    #endif

#endif /* defined(STM32F769AG) */


// name     : STM32F777BI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F777
#if defined(STM32F777BI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F777BI"
            #else
                #pragma message("Note: Selected MCU - STM32F777BI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F777)
        #define STM32F777
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F777)
        #define STM32F777
    #endif

#endif /* defined(STM32F777BI) */


// name     : STM32F777NI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F777
#if defined(STM32F777NI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F777NI"
            #else
                #pragma message("Note: Selected MCU - STM32F777NI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F777)
        #define STM32F777
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F777)
        #define STM32F777
    #endif

#endif /* defined(STM32F777NI) */


// name     : STM32F777II
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F777
#if defined(STM32F777II)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F777II"
            #else
                #pragma message("Note: Selected MCU - STM32F777II")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F777)
        #define STM32F777
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F777)
        #define STM32F777
    #endif

#endif /* defined(STM32F777II) */


// name     : STM32F777ZI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F777
#if defined(STM32F777ZI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F777ZI"
            #else
                #pragma message("Note: Selected MCU - STM32F777ZI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F777)
        #define STM32F777
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F777)
        #define STM32F777
    #endif

#endif /* defined(STM32F777ZI) */


// name     : STM32F777VI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F777
#if defined(STM32F777VI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F777VI"
            #else
                #pragma message("Note: Selected MCU - STM32F777VI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F777)
        #define STM32F777
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F777)
        #define STM32F777
    #endif

#endif /* defined(STM32F777VI) */


// name     : STM32F778AI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F778
#if defined(STM32F778AI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F778AI"
            #else
                #pragma message("Note: Selected MCU - STM32F778AI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F778)
        #define STM32F778
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F778)
        #define STM32F778
    #endif

#endif /* defined(STM32F778AI) */


// name     : STM32F779BI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F779
#if defined(STM32F779BI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F779BI"
            #else
                #pragma message("Note: Selected MCU - STM32F779BI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F779)
        #define STM32F779
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F779)
        #define STM32F779
    #endif

#endif /* defined(STM32F779BI) */


// name     : STM32F779NI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F779
#if defined(STM32F779NI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F779NI"
            #else
                #pragma message("Note: Selected MCU - STM32F779NI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F779)
        #define STM32F779
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F779)
        #define STM32F779
    #endif

#endif /* defined(STM32F779NI) */


// name     : STM32F779II
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F779
#if defined(STM32F779II)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F779II"
            #else
                #pragma message("Note: Selected MCU - STM32F779II")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F779)
        #define STM32F779
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F779)
        #define STM32F779
    #endif

#endif /* defined(STM32F779II) */


// name     : STM32F779AI
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F779
#if defined(STM32F779AI)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F779AI"
            #else
                #pragma message("Note: Selected MCU - STM32F779AI")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F779)
        #define STM32F779
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F779)
        #define STM32F779
    #endif

#endif /* defined(STM32F779AI) */


// name     : STM32F732VE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F732
#if defined(STM32F732VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F732VE"
            #else
                #pragma message("Note: Selected MCU - STM32F732VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F732)
        #define STM32F732
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F732)
        #define STM32F732
    #endif

#endif /* defined(STM32F732VE) */


// name     : STM32F732RE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F732
#if defined(STM32F732RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F732RE"
            #else
                #pragma message("Note: Selected MCU - STM32F732RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F732)
        #define STM32F732
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F732)
        #define STM32F732
    #endif

#endif /* defined(STM32F732RE) */


// name     : STM32F732ZE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F732
#if defined(STM32F732ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F732ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F732ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F732)
        #define STM32F732
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F732)
        #define STM32F732
    #endif

#endif /* defined(STM32F732ZE) */


// name     : STM32F732IE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F732
#if defined(STM32F732IE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F732IE"
            #else
                #pragma message("Note: Selected MCU - STM32F732IE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F732)
        #define STM32F732
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F732)
        #define STM32F732
    #endif

#endif /* defined(STM32F732IE) */


// name     : STM32F722VE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F722
#if defined(STM32F722VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F722VE"
            #else
                #pragma message("Note: Selected MCU - STM32F722VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F722)
        #define STM32F722
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F722)
        #define STM32F722
    #endif

#endif /* defined(STM32F722VE) */


// name     : STM32F722RE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F722
#if defined(STM32F722RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F722RE"
            #else
                #pragma message("Note: Selected MCU - STM32F722RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F722)
        #define STM32F722
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F722)
        #define STM32F722
    #endif

#endif /* defined(STM32F722RE) */


// name     : STM32F722ZE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F722
#if defined(STM32F722ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F722ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F722ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F722)
        #define STM32F722
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F722)
        #define STM32F722
    #endif

#endif /* defined(STM32F722ZE) */


// name     : STM32F722IE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F722
#if defined(STM32F722IE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F722IE"
            #else
                #pragma message("Note: Selected MCU - STM32F722IE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F722)
        #define STM32F722
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F722)
        #define STM32F722
    #endif

#endif /* defined(STM32F722IE) */


// name     : STM32F722RC
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F722
#if defined(STM32F722RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F722RC"
            #else
                #pragma message("Note: Selected MCU - STM32F722RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F722)
        #define STM32F722
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F722)
        #define STM32F722
    #endif

#endif /* defined(STM32F722RC) */


// name     : STM32F722VC
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F722
#if defined(STM32F722VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F722VC"
            #else
                #pragma message("Note: Selected MCU - STM32F722VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F722)
        #define STM32F722
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F722)
        #define STM32F722
    #endif

#endif /* defined(STM32F722VC) */


// name     : STM32F722ZC
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F722
#if defined(STM32F722ZC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F722ZC"
            #else
                #pragma message("Note: Selected MCU - STM32F722ZC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F722)
        #define STM32F722
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F722)
        #define STM32F722
    #endif

#endif /* defined(STM32F722ZC) */


// name     : STM32F722IC
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F722
#if defined(STM32F722IC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F722IC"
            #else
                #pragma message("Note: Selected MCU - STM32F722IC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F722)
        #define STM32F722
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F722)
        #define STM32F722
    #endif

#endif /* defined(STM32F722IC) */


// name     : STM32F733VE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F733
#if defined(STM32F733VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F733VE"
            #else
                #pragma message("Note: Selected MCU - STM32F733VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F733)
        #define STM32F733
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F733)
        #define STM32F733
    #endif

#endif /* defined(STM32F733VE) */


// name     : STM32F733ZE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F733
#if defined(STM32F733ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F733ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F733ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F733)
        #define STM32F733
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F733)
        #define STM32F733
    #endif

#endif /* defined(STM32F733ZE) */


// name     : STM32F733IE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F733
#if defined(STM32F733IE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F733IE"
            #else
                #pragma message("Note: Selected MCU - STM32F733IE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F733)
        #define STM32F733
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F733)
        #define STM32F733
    #endif

#endif /* defined(STM32F733IE) */


// name     : STM32F723VE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F723
#if defined(STM32F723VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F723VE"
            #else
                #pragma message("Note: Selected MCU - STM32F723VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F723)
        #define STM32F723
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F723)
        #define STM32F723
    #endif

#endif /* defined(STM32F723VE) */


// name     : STM32F723ZE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F723
#if defined(STM32F723ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F723ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F723ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F723)
        #define STM32F723
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F723)
        #define STM32F723
    #endif

#endif /* defined(STM32F723ZE) */


// name     : STM32F723IE
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F723
#if defined(STM32F723IE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F723IE"
            #else
                #pragma message("Note: Selected MCU - STM32F723IE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F723)
        #define STM32F723
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F723)
        #define STM32F723
    #endif

#endif /* defined(STM32F723IE) */


// name     : STM32F723ZC
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F723
#if defined(STM32F723ZC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F723ZC"
            #else
                #pragma message("Note: Selected MCU - STM32F723ZC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F723)
        #define STM32F723
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F723)
        #define STM32F723
    #endif

#endif /* defined(STM32F723ZC) */


// name     : STM32F723IC
// core     : Cortex-M7
// family   : STM32F7 Series
// subfamily: STM32F723
#if defined(STM32F723IC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F723IC"
            #else
                #pragma message("Note: Selected MCU - STM32F723IC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F7_SERIES)
        #define STM32F7_SERIES
    #endif

    #if !defined(STM32F723)
        #define STM32F723
    #endif

    #if !defined(CORTEX_M7)
        #define CORTEX_M7
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__FPU_PRESENT)
        #define __FPU_PRESENT
    #endif

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    216000000
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F723)
        #define STM32F723
    #endif

#endif /* defined(STM32F723IC) */


#endif /* defined(STM32F7XX_DEVICES_XML____INC_STM32F7XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00) */

