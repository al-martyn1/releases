#pragma once

// Automatically umba-mm-pdsc generated file
// Universal definitions file for STM32/derived devices - C language

// input  : stm32f2xx_devices.xml
// output : ..\inc\stm32f2xx_devices.h

#if !defined(STM32F2XX_DEVICES_XML____INC_STM32F2XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00)
#define STM32F2XX_DEVICES_XML____INC_STM32F2XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00

// name     : STM32F205RB
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F205
#if defined(STM32F205RB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F205RB"
            #else
                #pragma message("Note: Selected MCU - STM32F205RB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F205)
        #define STM32F205
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F205xx)
        #define STM32F205xx
    #endif

#endif /* defined(STM32F205RB) */


// name     : STM32F205RC
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F205
#if defined(STM32F205RC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F205RC"
            #else
                #pragma message("Note: Selected MCU - STM32F205RC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F205)
        #define STM32F205
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F205xx)
        #define STM32F205xx
    #endif

#endif /* defined(STM32F205RC) */


// name     : STM32F205RE
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F205
#if defined(STM32F205RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F205RE"
            #else
                #pragma message("Note: Selected MCU - STM32F205RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F205)
        #define STM32F205
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F205xx)
        #define STM32F205xx
    #endif

#endif /* defined(STM32F205RE) */


// name     : STM32F205RF
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F205
#if defined(STM32F205RF)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F205RF"
            #else
                #pragma message("Note: Selected MCU - STM32F205RF")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F205)
        #define STM32F205
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F205xx)
        #define STM32F205xx
    #endif

#endif /* defined(STM32F205RF) */


// name     : STM32F205RG
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F205
#if defined(STM32F205RG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F205RG"
            #else
                #pragma message("Note: Selected MCU - STM32F205RG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F205)
        #define STM32F205
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F205xx)
        #define STM32F205xx
    #endif

#endif /* defined(STM32F205RG) */


// name     : STM32F205VB
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F205
#if defined(STM32F205VB)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F205VB"
            #else
                #pragma message("Note: Selected MCU - STM32F205VB")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F205)
        #define STM32F205
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F205xx)
        #define STM32F205xx
    #endif

#endif /* defined(STM32F205VB) */


// name     : STM32F205VC
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F205
#if defined(STM32F205VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F205VC"
            #else
                #pragma message("Note: Selected MCU - STM32F205VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F205)
        #define STM32F205
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F205xx)
        #define STM32F205xx
    #endif

#endif /* defined(STM32F205VC) */


// name     : STM32F205VE
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F205
#if defined(STM32F205VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F205VE"
            #else
                #pragma message("Note: Selected MCU - STM32F205VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F205)
        #define STM32F205
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F205xx)
        #define STM32F205xx
    #endif

#endif /* defined(STM32F205VE) */


// name     : STM32F205VF
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F205
#if defined(STM32F205VF)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F205VF"
            #else
                #pragma message("Note: Selected MCU - STM32F205VF")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F205)
        #define STM32F205
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F205xx)
        #define STM32F205xx
    #endif

#endif /* defined(STM32F205VF) */


// name     : STM32F205VG
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F205
#if defined(STM32F205VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F205VG"
            #else
                #pragma message("Note: Selected MCU - STM32F205VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F205)
        #define STM32F205
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F205xx)
        #define STM32F205xx
    #endif

#endif /* defined(STM32F205VG) */


// name     : STM32F205ZC
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F205
#if defined(STM32F205ZC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F205ZC"
            #else
                #pragma message("Note: Selected MCU - STM32F205ZC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F205)
        #define STM32F205
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F205xx)
        #define STM32F205xx
    #endif

#endif /* defined(STM32F205ZC) */


// name     : STM32F205ZE
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F205
#if defined(STM32F205ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F205ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F205ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F205)
        #define STM32F205
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F205xx)
        #define STM32F205xx
    #endif

#endif /* defined(STM32F205ZE) */


// name     : STM32F205ZF
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F205
#if defined(STM32F205ZF)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F205ZF"
            #else
                #pragma message("Note: Selected MCU - STM32F205ZF")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F205)
        #define STM32F205
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F205xx)
        #define STM32F205xx
    #endif

#endif /* defined(STM32F205ZF) */


// name     : STM32F205ZG
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F205
#if defined(STM32F205ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F205ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F205ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F205)
        #define STM32F205
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F205xx)
        #define STM32F205xx
    #endif

#endif /* defined(STM32F205ZG) */


// name     : STM32F207VC
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F207
#if defined(STM32F207VC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F207VC"
            #else
                #pragma message("Note: Selected MCU - STM32F207VC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F207)
        #define STM32F207
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F207xx)
        #define STM32F207xx
    #endif

#endif /* defined(STM32F207VC) */


// name     : STM32F207VE
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F207
#if defined(STM32F207VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F207VE"
            #else
                #pragma message("Note: Selected MCU - STM32F207VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F207)
        #define STM32F207
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F207xx)
        #define STM32F207xx
    #endif

#endif /* defined(STM32F207VE) */


// name     : STM32F207VF
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F207
#if defined(STM32F207VF)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F207VF"
            #else
                #pragma message("Note: Selected MCU - STM32F207VF")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F207)
        #define STM32F207
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F207xx)
        #define STM32F207xx
    #endif

#endif /* defined(STM32F207VF) */


// name     : STM32F207VG
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F207
#if defined(STM32F207VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F207VG"
            #else
                #pragma message("Note: Selected MCU - STM32F207VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F207)
        #define STM32F207
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F207xx)
        #define STM32F207xx
    #endif

#endif /* defined(STM32F207VG) */


// name     : STM32F207ZC
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F207
#if defined(STM32F207ZC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F207ZC"
            #else
                #pragma message("Note: Selected MCU - STM32F207ZC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F207)
        #define STM32F207
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F207xx)
        #define STM32F207xx
    #endif

#endif /* defined(STM32F207ZC) */


// name     : STM32F207ZE
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F207
#if defined(STM32F207ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F207ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F207ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F207)
        #define STM32F207
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F207xx)
        #define STM32F207xx
    #endif

#endif /* defined(STM32F207ZE) */


// name     : STM32F207ZF
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F207
#if defined(STM32F207ZF)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F207ZF"
            #else
                #pragma message("Note: Selected MCU - STM32F207ZF")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F207)
        #define STM32F207
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F207xx)
        #define STM32F207xx
    #endif

#endif /* defined(STM32F207ZF) */


// name     : STM32F207ZG
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F207
#if defined(STM32F207ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F207ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F207ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F207)
        #define STM32F207
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F207xx)
        #define STM32F207xx
    #endif

#endif /* defined(STM32F207ZG) */


// name     : STM32F207IC
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F207
#if defined(STM32F207IC)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F207IC"
            #else
                #pragma message("Note: Selected MCU - STM32F207IC")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F207)
        #define STM32F207
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F207xx)
        #define STM32F207xx
    #endif

#endif /* defined(STM32F207IC) */


// name     : STM32F207IE
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F207
#if defined(STM32F207IE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F207IE"
            #else
                #pragma message("Note: Selected MCU - STM32F207IE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F207)
        #define STM32F207
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F207xx)
        #define STM32F207xx
    #endif

#endif /* defined(STM32F207IE) */


// name     : STM32F207IF
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F207
#if defined(STM32F207IF)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F207IF"
            #else
                #pragma message("Note: Selected MCU - STM32F207IF")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F207)
        #define STM32F207
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F207xx)
        #define STM32F207xx
    #endif

#endif /* defined(STM32F207IF) */


// name     : STM32F207IG
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F207
#if defined(STM32F207IG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F207IG"
            #else
                #pragma message("Note: Selected MCU - STM32F207IG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F207)
        #define STM32F207
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F207xx)
        #define STM32F207xx
    #endif

#endif /* defined(STM32F207IG) */


// name     : STM32F215RE
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F215
#if defined(STM32F215RE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F215RE"
            #else
                #pragma message("Note: Selected MCU - STM32F215RE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F215)
        #define STM32F215
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F215xx)
        #define STM32F215xx
    #endif

#endif /* defined(STM32F215RE) */


// name     : STM32F215RG
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F215
#if defined(STM32F215RG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F215RG"
            #else
                #pragma message("Note: Selected MCU - STM32F215RG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F215)
        #define STM32F215
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    51
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F215xx)
        #define STM32F215xx
    #endif

#endif /* defined(STM32F215RG) */


// name     : STM32F215VE
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F215
#if defined(STM32F215VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F215VE"
            #else
                #pragma message("Note: Selected MCU - STM32F215VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F215)
        #define STM32F215
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F215xx)
        #define STM32F215xx
    #endif

#endif /* defined(STM32F215VE) */


// name     : STM32F215VG
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F215
#if defined(STM32F215VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F215VG"
            #else
                #pragma message("Note: Selected MCU - STM32F215VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F215)
        #define STM32F215
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F215xx)
        #define STM32F215xx
    #endif

#endif /* defined(STM32F215VG) */


// name     : STM32F215ZE
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F215
#if defined(STM32F215ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F215ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F215ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F215)
        #define STM32F215
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F215xx)
        #define STM32F215xx
    #endif

#endif /* defined(STM32F215ZE) */


// name     : STM32F215ZG
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F215
#if defined(STM32F215ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F215ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F215ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F215)
        #define STM32F215
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F215xx)
        #define STM32F215xx
    #endif

#endif /* defined(STM32F215ZG) */


// name     : STM32F217VE
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F217
#if defined(STM32F217VE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F217VE"
            #else
                #pragma message("Note: Selected MCU - STM32F217VE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F217)
        #define STM32F217
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F217xx)
        #define STM32F217xx
    #endif

#endif /* defined(STM32F217VE) */


// name     : STM32F217VG
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F217
#if defined(STM32F217VG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F217VG"
            #else
                #pragma message("Note: Selected MCU - STM32F217VG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F217)
        #define STM32F217
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    16
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    82
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F217xx)
        #define STM32F217xx
    #endif

#endif /* defined(STM32F217VG) */


// name     : STM32F217ZE
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F217
#if defined(STM32F217ZE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F217ZE"
            #else
                #pragma message("Note: Selected MCU - STM32F217ZE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F217)
        #define STM32F217
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F217xx)
        #define STM32F217xx
    #endif

#endif /* defined(STM32F217ZE) */


// name     : STM32F217ZG
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F217
#if defined(STM32F217ZG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F217ZG"
            #else
                #pragma message("Note: Selected MCU - STM32F217ZG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F217)
        #define STM32F217
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    114
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F217xx)
        #define STM32F217xx
    #endif

#endif /* defined(STM32F217ZG) */


// name     : STM32F217IE
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F217
#if defined(STM32F217IE)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F217IE"
            #else
                #pragma message("Note: Selected MCU - STM32F217IE")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F217)
        #define STM32F217
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F217xx)
        #define STM32F217xx
    #endif

#endif /* defined(STM32F217IE) */


// name     : STM32F217IG
// core     : Cortex-M3
// family   : STM32F2 Series
// subfamily: STM32F217
#if defined(STM32F217IG)

    #if defined(MCU_DETECTION_MESSAGE)
            #if defined(__CC_ARM)
                #warning "Note: Selected MCU - STM32F217IG"
            #else
                #pragma message("Note: Selected MCU - STM32F217IG")
            #endif
    #endif /* defined(MCU_DETECTION_MESSAGE) */

    #if !defined(STM32F2_SERIES)
        #define STM32F2_SERIES
    #endif

    #if !defined(STM32F217)
        #define STM32F217
    #endif

    #if !defined(CORTEX_M3)
        #define CORTEX_M3
    #endif


    #if defined(DEFINE_FPU_MPU)

    #if !defined(__MPU_PRESENT)
        #define __MPU_PRESENT
    #endif

    #endif /* defined(DEFINE_FPU_MPU) */

    #if !defined(LITTLE_ENDIAN)
        #define LITTLE_ENDIAN
    #endif

    #if !defined(STM32_FEATURE_NUM_FREQ)
        #define STM32_FEATURE_NUM_FREQ    120000000
    #endif

    #if !defined(STM32_FEATURE_NUM_ADC)
        #define STM32_FEATURE_NUM_ADC    24
    #endif

    #if !defined(STM32_FEATURE_NUM_CAN)
        #define STM32_FEATURE_NUM_CAN    2
    #endif

    #if !defined(STM32_FEATURE_NUM_CAMERA)
        #define STM32_FEATURE_NUM_CAMERA    14
    #endif

    #if !defined(STM32_FEATURE_NUM_CRYPTO)
        #define STM32_FEATURE_NUM_CRYPTO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_DAC)
        #define STM32_FEATURE_NUM_DAC    2
    #endif

    #if !defined(STM32_FEATURE_NUM_ETH)
        #define STM32_FEATURE_NUM_ETH    1
    #endif

    #if !defined(STM32_FEATURE_NUM_EXTBUS)
        #define STM32_FEATURE_NUM_EXTBUS    16
    #endif

    #if !defined(STM32_FEATURE_NUM_I2C)
        #define STM32_FEATURE_NUM_I2C    3
    #endif

    #if !defined(STM32_FEATURE_NUM_I2S)
        #define STM32_FEATURE_NUM_I2S    2
    #endif

    #if !defined(STM32_FEATURE_NUM_IOS)
        #define STM32_FEATURE_NUM_IOS    140
    #endif

    #if !defined(STM32_FEATURE_NUM_RNG)
        #define STM32_FEATURE_NUM_RNG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_RTC)
        #define STM32_FEATURE_NUM_RTC    32768
    #endif

    #if !defined(STM32_FEATURE_NUM_SDIO)
        #define STM32_FEATURE_NUM_SDIO    1
    #endif

    #if !defined(STM32_FEATURE_NUM_SPI)
        #define STM32_FEATURE_NUM_SPI    3
    #endif

    #if !defined(STM32_FEATURE_NUM_TIMER)
        #define STM32_FEATURE_NUM_TIMER    2
    #endif

    #if !defined(STM32_FEATURE_NUM_UART)
        #define STM32_FEATURE_NUM_UART    2
    #endif

    #if !defined(STM32_FEATURE_NUM_USART)
        #define STM32_FEATURE_NUM_USART    4
    #endif

    #if !defined(STM32_FEATURE_NUM_USBOTG)
        #define STM32_FEATURE_NUM_USBOTG    1
    #endif

    #if !defined(STM32_FEATURE_NUM_WDT)
        #define STM32_FEATURE_NUM_WDT    2
    #endif

    #if !defined(STM32F217xx)
        #define STM32F217xx
    #endif

#endif /* defined(STM32F217IG) */


#endif /* defined(STM32F2XX_DEVICES_XML____INC_STM32F2XX_DEVICES_H_172A6F52_575B_4E32_ADA7_C9D530FD8A00) */

