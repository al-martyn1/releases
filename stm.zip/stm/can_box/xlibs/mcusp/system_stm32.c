
#include "mcu.h"

#if defined(STM32F1_SERIES)
    #include "stm32f1xx/system_stm32f10x.c"
#elif defined(STM32F3_SERIES)
    #include "stm32f3xx/system_stm32f30x.c"
#elif defined(STM32F4_SERIES)
    #include "stm32f4xx/system_stm32f4xx.c"
#elif defined(STM32L1_SERIES)
    #include "stm32l1xx/system_stm32l1xx.c"
#endif



