#pragma once

#include "i_reg_table_for_ui.h"

namespace regs
{


template< typename StreamType >
inline
void printRegs( StreamType &s, regs::IRegTableForUi *pRegTable, bool printValues = false, const std::string &indent = "" )
{
    size_t numRegs = pRegTable->getNumOfRegs();
    for( size_t i = 0; i!=numRegs; ++i)
    {
        std::string name;
        auto str = pRegTable->regGetName(i);
        if (str)
            name = str;

        std::string description;
        str = pRegTable->regGetDescription(i);
        if (str)
            description = str;

        if (name.empty())
            name = std::string("#") + std::to_string(i);

        if (description.empty())
            s<<indent<<name; //<<": "<<valueHex<<"\n";
        else
            s<<indent<<name<<" - "<<description; //<<": "<<valueHex<<"\n";

        if (printValues)
        {
            char dumpBuf[64];
            pRegTable->regGetHexDumpStr( i, &dumpBuf[0], 64 );
            std::string dumpStr = &dumpBuf[0];

            char decBuf[64];
            pRegTable->regGetUnderlyingDisplayStr( i, &decBuf[0], 64 );
            std::string decStr = &decBuf[0];

            char hexBuf[64];
            pRegTable->regGetUnderlyingDisplayStr( i, &hexBuf[0], 64, RegisterUnderlyingFormatFlags::hex );
            std::string hexStr = &hexBuf[0];

            s<<": ";

            if (decStr==hexStr)
            {
                s << decStr;
            }
            else
            {
                s<<decStr<<" / "<<hexStr;
            }

            s<<" (dump: "<<dumpStr<<")";
        }

        s<<"\n";

    }
}


template< typename StreamType >
inline
void printRegs( StreamType &s, regs::IRegTableForUiEx *pRegTable, bool printValues = false, const std::string &indent = "" )
{
    size_t numGroups = pRegTable->getNumOfGroups();
    for( size_t groupNumber = 0; groupNumber!=numGroups; ++groupNumber)
    {
        std::string groupName;
        auto str = pRegTable->groupGetName(groupNumber);
        if (str)
            groupName = str;

        if (groupName.empty())
            groupName = std::string("#") + std::to_string(groupNumber);


        std::string groupDescription;
        str = pRegTable->groupGetDescription(groupNumber);
        if (str)
            groupDescription = str;

        if (groupDescription.empty())
            s<<indent<<groupName<<"\n";
        else
            s<<indent<<groupName<<" - "<<groupDescription<<"\n";

        size_t numGroupRegs = pRegTable->groupGetNumOfRegs(groupNumber);

        for(size_t regGroupIndex = 0; regGroupIndex!=numGroupRegs; ++regGroupIndex)
        {
            size_t regNumber = pRegTable->groupGetRegNumber(groupNumber, regGroupIndex);

            std::string regName;
            auto str = pRegTable->regGetName(regNumber);
            if (str)
                regName = str;

            if (regName.empty())
                regName = std::string("#") + std::to_string(regNumber);
           
            std::string regDescription;
            str = pRegTable->regGetDescription(regNumber);
            if (str)
                regDescription = str;
           
            char buf[32];
            pRegTable->regGetHexDumpStr( regNumber, &buf[0], 32 );
           
            std::string valueHex = &buf[0];
           
           
            if (regDescription.empty())
                s<<indent<<"    "<<regName; // <<": "<<valueHex<<"\n";
            else
                s<<indent<<"    "<<regName<<" - "<<regDescription; // <<": "<<valueHex<<"\n";

            if (printValues)
            {
                char dumpBuf[64];
                pRegTable->regGetHexDumpStr(regNumber, &dumpBuf[0], 64 );
                std::string dumpStr = &dumpBuf[0];
               
                char decBuf[64];
                pRegTable->regGetUnderlyingDisplayStr(regNumber, &decBuf[0], 64 );
                std::string decStr = &decBuf[0];
               
                char hexBuf[64];
                pRegTable->regGetUnderlyingDisplayStr(regNumber, &hexBuf[0], 64, RegisterUnderlyingFormatFlags::hex );
                std::string hexStr = &hexBuf[0];
               
                s<<": ";
               
                if (decStr==hexStr)
                {
                    s << decStr;
                }
                else
                {
                    s<<decStr<<" / "<<hexStr;
                }
               
                s<<" (dump: "<<dumpStr<<")";
            }
            //    s<<": "<<valueHex;
           
            s<<"\n";

        
        }
    }

}







} // namespace regs

