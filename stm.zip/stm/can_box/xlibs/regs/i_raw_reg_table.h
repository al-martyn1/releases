#pragma once


#include "i_reg_table_transacted.h"


namespace regs
{


//! Интерфейс сырой таблицы регистров, где многобайтные регистры - это последовательность однобайтных
interface IRawRegTable : inherits IRegTableTransacted
{

    UMBA_DECLARE_INTERFACE_ID(0x8A5CACF1);

    //--------
    virtual
    size_t rawGetNumOfRegs() = 0;

    //! Обновление регистра - возврат false, если регистр не существует
    virtual
    bool rawUpdateSetReg( size_t rawIndex, uint8_t byte ) = 0;


    //--------

    //! Возвращает false, если регистр не существует
    /*! В принципе, нам тут особо не нужно знать размеры регистров - 
        за это отвечает запрашивающая сторона. Если она криво запрашивает,
        то и получит кривые регистры
     */
    virtual 
    bool rawGetReg( size_t rawIndex, uint8_t *pRegByte ) = 0;

    //! Возвращает статус изменения регистра - false, если не менялся
    virtual 
    bool rawGetModifiedState( size_t rawIndex, bool *pModifiedState ) = 0;

    //! Возвращает индекс следующего обновившегося регистра
    /*! На старте - задаем npos
        На выходе - номер регистра, или npos, если ничего не найдено
     */
    virtual 
    size_t rawGetNextChanged( size_t rawIndex ) = 0;

    //! Получаем размер последовательности, которую необходимо передать в одном пакете
    /*! Используется для передачи многобайтных регистров при передаче в режиме обновлений.
        Если переданный номер не является стартовым индексом для последовательности, возвращается 0.
     */
    virtual 
    size_t rawGetSequenceSize( size_t rawIndex ) = 0;



}; // interface IRawRegTable


} // namespace regs


