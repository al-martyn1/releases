#pragma once


#include <stdint.h>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <exception>
#include <stdexcept>
#include <algorithm>


#include "i_generic_reg_table.h"
#include "i_dynamic_reg_table.h"
#include "i_raw_reg_table.h"
#include "i_logic_reg_table.h"
#include "i_reg_table_for_ui.h"
#include "i_reg_table_for_ui_ex.h"

#include "umba/format_utils.h"
#include "umba/simple_formatter.h"


namespace regs
{



struct RegisterEntry
{
    std::string           name;
    size_t                size              = 1;
    std::string           description;
    uint8_t               bytes[16]            ;
    //size_t                deserializedCount = 0; // количество десериализованных в последний раз данных
    uint16_t              modifiedParts     = 0; // битовая маска обновления частей регистра
    uint16_t              validParts        = 0; // битовая маска валидности частей регистра - хоть раз было что-то присвоено
    //bool                  updated           = false; // Признак обновления
    bool                  autoExtended      = false; // Добавлено для заполнения пустот перед автоматически добавляемым регистром
                                             // При чтении будет возвращать сколько затребовано (без ошибок), а при записи - зафиксирует свой размер
                                             // и последующие некорректные обращения будут генерировать ошибку
    size_t                rawStartIndex     = 0;

    size_t                groupId           = 0;

    RegustryDataType      underlyingType    = RegustryDataType::regTypeSigned;

    /*
    uint16_t makeBit( size_t bitNum ) const
    {
        uint16_t bit = 1;
        return bit<<bitNum;
    }
    */

    uint16_t makeByteFlags( size_t nBytes ) const
    {
        if (!nBytes)
            return 0;

        uint16_t res = 1;
        while( nBytes-- > 0 )
            res |= res<<1;

        return res;
    }

    uint16_t makeByteFlags( ) const
    {
        return makeByteFlags( size );
    }

    bool isModified() const
    {
        return modifiedParts != 0;
    }

    bool isPartialModified() const
    {
        return (modifiedParts ^ makeByteFlags()) != 0;
    }

}; // struct RegisterEntry


struct GroupInfo
{
    std::string           name;
    std::string           description;
    std::vector<size_t>   regNumbers;
}; // struct GroupInfo


struct RegisterOffsetV1
{
    size_t regNumber;
    size_t byteNumber;

};



enum EventType
{
    logicIndexOutOfRange,
    rawIndexOutOfRange,
    logicSizeInvalid,
    updated,
    partiallyUpdated,
    total
};





struct DynamicRegTableImplBase : implements IGenericRegTable
                               , implements IDynamicRegTable
                               , implements ILogicRegTable
                               , implements IRegTableForUi
                               , implements IRegTableForUiEx
                               , implements IRawRegTable
{

    UMBA_BEGIN_INTERFACE_MAP_EX( IGenericRegTable )
         UMBA_IMPLEMENT_INTERFACE( IDynamicRegTable )
         UMBA_IMPLEMENT_INTERFACE( ILogicRegTable )
         UMBA_IMPLEMENT_INTERFACE( IRegTableForUi )
         UMBA_IMPLEMENT_INTERFACE( IRegTableForUiEx )
         UMBA_IMPLEMENT_INTERFACE( IRawRegTable )
    UMBA_END_INTERFACE_MAP()


protected:

    //----------------------
    /* Пользовательский (клиентский) прикладной код не должен пользоваться
       транзакциями. Вместо этого он просто устанавливает значения регистров и сразу же
       обрабатывает ошибку.

       Транзакции нужны для того, чтобы объект протокола мог в пакетном режиме
       обновить регистры данными из пришедшего пакета, и по окончании получить результат -
       валидны ли все данные или нет, и если нет - то отослать признак ошибки.
       Таким образом логика реализации протокола упрощается, и ответственность
       за целостность обновления регистров лежит на таблице регистров.

       Транзакции обновления регистров не являются реентрантными - нельзя стартовать
       новую транзакцию, не завершив предыдущую.

       Данная реализация релизует базовые операции для обеспечения транзакционности,
       конкретная реализация должна переопределить следующие методы
     */


    virtual
    void updateTransactionStart()
    {}

    virtual
    void updateTransactionFinalize()
    {}

    virtual
    void updateTransactionCommit()
    {}

    virtual
    void updateTransactionRollback()
    {}

    virtual
    bool updateTransactionHasErrors()
    {
        return m_updateLogicRegsErrorCount > 0;
    }

    //! Возврат true, если при ошибках следует сделать откат, или false - если ошибки допустимы
    virtual
    bool updateTransactionGetRollbackOnErrorsMode()
    {
        return false;
    }

    virtual
    void onEvent( EventType evt
                , size_t regNumber // ignored, logic or raw, depending on event type
                )
    {
    }

    //onEvent( EventType::logicIndexOutOfRange, N );
    //onEvent( EventType::rawIndexOutOfRange, N );
    //onEvent( EventType::logicSizeInvalid, N );
    

public:

    //----------------------
    // IGenericRegTable

    //! Сериализуем данные регистров. 
    /*! Буфера должно быть достаточно.
        Возврат npos при ошибке.
        Возврат количества использованных для сериализации байт.
        Если pBuf равен 0, то сериализация реально не производится.
     */
    virtual
    size_t serializeRegsData( uint8_t *pBuf, size_t bufSize ) override
    {
        return 0; // Пока заглушка
    }

    //! Десериализуем данные регистров.
    virtual
    bool deserializeRegsData( const uint8_t *pBuf, size_t bufSize ) override
    {
        return true; // Пока заглушка
    }

    //! Сериализация метаданных (состояния, и тп) регистров
    virtual
    size_t serializeRegsMeta( uint8_t *pBuf, size_t bufSize ) override
    {
        return 0; // Пока заглушка
    }

    //! Десериализация метаданных (состояния, и тп) регистров
    virtual
    bool deserializeRegsMeta( const uint8_t *pBuf, size_t bufSize ) override
    {
        return true; // Пока заглушка
    }

    //-----
    //! Сериализация раскладки
    virtual
    size_t serializeRegsLayout( uint8_t *pBuf, size_t bufSize ) override
    {
        return 0; // Пока заглушка
    }

    //! Десериализация раскладки
    virtual
    bool deserializeRegsLayout( const uint8_t *pBuf, size_t bufSize ) override
    {
        return true; // Пока заглушка
    }



    //----------------------
    // Вспомогательные методы

    void checkCreateDefaultGroup()
    {
        if (!m_groups.empty())
            return;

        m_groups.push_back( GroupInfo{ makeGroupName( "Default group", 0 ), makeGroupDecription(0,0) } );
    }

    void rebuildGroups()
    {
        checkCreateDefaultGroup();

        for( size_t grp = 0; grp!=m_groups.size(); ++grp)
        {
            m_groups[grp].regNumbers.clear();
        }
        
        for( size_t regNumber = 0; regNumber!=m_regs.size(); ++regNumber)
        {
            auto regGroup = m_regs[regNumber].groupId;
            if (regGroup>=m_groups.size())
                throw std::runtime_error("Invalid group ID");

            m_groups[regGroup].regNumbers.push_back(regNumber);
        }

    }

    //! Таблицы для протокола V1
    void rebuildInternalTables()
    {
        rebuildGroups();

        m_regOffsets.clear();

        size_t offs = 0;

        for( size_t regNumber = 0; regNumber!=m_regs.size(); ++regNumber)
        {
            RegisterEntry &reg = m_regs[regNumber];
            reg.rawStartIndex = offs;

            RegisterOffsetV1 rov1;
            rov1.regNumber = regNumber;

            size_t regByteNum = 0;
            for( ; regByteNum!=reg.size; ++regByteNum, offs++)
            {
                rov1.byteNumber = regByteNum;
                m_regOffsets.push_back(rov1);
            }
        }
    }

    //----------------------

    // IDynamicRegTable helpers

    size_t findGroupByName( const std::string &name )
    {
        for( size_t i = 0; i!=m_groups.size(); ++i)
        {
            if (m_groups[i].name == name)
                return i;
        }

        return npos;
    }

    size_t findRegByName( const std::string &name )
    {
        for( size_t i = 0; i!=m_regs.size(); ++i)
        {
            if (m_regs[i].name == name)
                return i;
        }

        return npos;
    }

    std::string makeGroupName( const char* name, size_t id )
    {
        std::string n;
        if (name)
            n = name;

        if (n.empty())
        {
            n = std::string("Group ") + std::to_string(id);
            while( findGroupByName(n)!=npos )
            {
                ++id;
                n = std::string("Group ") + std::to_string(id);
            }
        }

        return n;
    }

    std::string makeGroupDecription( const char* name, size_t id )
    {
        std::string n;
        if (name)
            n = name;

        return n;
    }

    std::string makeRegName( const char* name, size_t id )
    {
        std::string n;
        if (name)
            n = name;

        if (n.empty())
        {
            n = std::string("Register ") + std::to_string(id);
            while( findRegByName(n)!=npos )
            {
                ++id;
                n = std::string("Register ") + std::to_string(id);
            }
        }

        return n;
    }

    std::string makeRegDecription( const char* name, size_t id )
    {
        std::string n;
        if (name)
            n = name;

        return n;
    }


    //----------------------
    virtual
    void clear( ) override
    {
        while( getNumOfRegs() != 0 )
        {
            regRemove(0);
        }
       
        while( getNumOfGroups() != 0 )
        {
            groupRemove(0);
        }
    }

    // IDynamicRegTable

    //! Добавляет группу. grpName может быть равен 0
    virtual
    size_t groupAdd( const char* grpName ) override
    {
        size_t newGrpId = m_groups.size();
        m_groups.push_back( GroupInfo{ makeGroupName(grpName, newGrpId) } );
        return newGrpId;
    }

    //! Вставляет новую группу перед заданной. grpName может быть равен 0
    virtual
    size_t groupInsert( size_t insertBefore, const char* grpName ) override
    {
        if (insertBefore >= m_groups.size())
            return groupAdd(grpName);

        size_t newGrpId = insertBefore; // m_groups.size();

        for (auto & reg : m_regs )
        {
            if (reg.groupId > newGrpId)
                reg.groupId++;
        }

        m_groups.insert( m_groups.begin() + insertBefore, GroupInfo{ makeGroupName(grpName,newGrpId) } );

        rebuildInternalTables();

        return insertBefore;
    }

    //! Удаляет группу
    virtual
    bool groupRemove( size_t grpId ) override
    {
        if (grpId >= m_groups.size())
            return false;

        for (auto & reg : m_regs )
        {
            if (reg.groupId == grpId)
                return false;
        }

        for (auto & reg : m_regs )
        {
            if (reg.groupId > grpId)
                reg.groupId--;
        }

        m_groups.erase( m_groups.begin() + grpId );

        rebuildInternalTables();

        return true;
    
    }

    //! Устанавливает название группы
    virtual
    bool groupSetName( size_t grpId, const char* grpName ) override
    {
        if (grpId >= m_groups.size())
            return false;

        if (!grpName)
            m_groups[grpId].name.clear();
        else
            m_groups[grpId].name = grpName;

        return true;
    }

    //! Устанавливает описание группы
    virtual
    bool groupSetDescripton( size_t grpId, const char* grpDescr ) override
    {
        if (grpId >= m_groups.size())
            return false;

        if (!grpDescr)
            m_groups[grpId].description.clear();
        else
            m_groups[grpId].description = grpDescr;

        return true;
    }


    //----------
    // Операции с регистрами

    //! Добавляет регистр. regName может быть равен 0
    virtual
    size_t regAdd( const char* regName, size_t regSize ) override
    {
        if ( !(regSize==1 || regSize==2 || regSize==4 || regSize==8 || regSize==16) )
            return npos;

        size_t newId = m_regs.size();
        RegisterEntry reg;
        size_t fillSize = sizeof(reg.bytes);
        std::memset( (void*)&reg.bytes[0], 0, fillSize );
        reg.name        = makeRegDecription( regName, newId );
        reg.description = std::string();
        reg.size        = regSize;
        reg.groupId     = 0;

        m_regs.push_back( reg );

        rebuildInternalTables();

        return newId;
    }

    //! Вставляет новый регистр перед заданным. regName может быть равен 0
    virtual
    size_t regInsert( size_t insertBefore, const char* regName, size_t regSize ) override
    {
        if (insertBefore>=m_regs.size())
            return regAdd( regName, regSize );

        if ( !(regSize==1 || regSize==2 || regSize==4 || regSize==8 || regSize==16) )
            return npos;

        size_t newId = insertBefore;
        RegisterEntry reg;
        size_t fillSize = sizeof(reg.bytes);
        std::memset( (void*)&reg.bytes[0], 0, fillSize );
        reg.name        = makeRegDecription( regName, newId );
        reg.description = std::string();
        reg.size        = regSize;
        reg.groupId     = 0;

        m_regs.insert( m_regs.begin() + newId, reg );

        rebuildInternalTables();

        return newId;
    }

    //! Удаляет регистр
    virtual
    bool regRemove( size_t regId ) override
    {
        if (regId>=m_regs.size())
            return false;

        m_regs.erase( m_regs.begin()+regId );

        rebuildInternalTables();

        return true;
    }

    //! Устанавливает название регистра
    virtual
    bool regSetName( size_t regId, const char* regName ) override
    {
        if (regId>=m_regs.size())
            return false;

        if (!regName)
            m_regs[regId].name.clear();
        else
            m_regs[regId].name = regName;

        return true;
    }

    //! Устанавливает описание регистра
    virtual
    bool regSetDescripton( size_t regId, const char* regDescr ) override
    {
        if (regId>=m_regs.size())
            return false;

        if (!regDescr)
            m_regs[regId].description.clear();
        else
            m_regs[regId].description = regDescr;

        return true;
    }

    //! Устанавливает размер регистра
    virtual
    bool regSetSize( size_t regId, size_t size ) override
    {
        if (regId>=m_regs.size())
            return false;

        RegisterEntry &reg = m_regs[regId];
        if ( !(size==1 || size==2 || size==4 || size==8 || size==16) )
            return false;

        reg.size = size;

        rebuildInternalTables();

        return true;
    }

    //! Устанавливает принадлежность регистра группе
    virtual
    bool regSetGroup( size_t regId, size_t groupId ) override
    {
        if (regId>=m_regs.size())
            return false;

        m_regs[regId].groupId = groupId;

        rebuildInternalTables();

        return true;
    }

    virtual
    bool regSetUnderlyingType( size_t regId, RegustryDataType t) override
    {
        if (regId>=m_regs.size())
            return false;

        m_regs[regId].underlyingType = t;
        return true;
    }


    //---------------------------
    // ILogicRegTable

    virtual
    size_t getNumOfRegs() override
    {
        return m_regs.size();
    }

    //! Возвращает размер регистра, или npos при ошибке
    virtual
    size_t regGetSize( size_t regNumber ) override
    {
        if (regNumber>=m_regs.size())
            return npos;

        return m_regs[regNumber].size;
    }


    //! Возвращает false если задан невалидный индекс. pModifiedState - опциональный параметр и может быть равным нулю
    virtual
    bool regGetModifiedState( size_t regNumber, bool *pModifiedState ) override
    {
        if (regNumber>=m_regs.size())
            return false;

        return m_regs[regNumber].modifiedParts != 0;
    }

    //! Сбрасывает признак модификации
    virtual
    bool regClearModifiedState( size_t regNumber ) override
    {
        if (regNumber>=m_regs.size())
            return false;

        m_regs[regNumber].modifiedParts = 0;

        return true;
    }

    //! Доступ к нетипизированному содержимому на чтение.
    /*! Для использования в клинском коде - из C#, например.
        Возвращает npos, если номер регистра невалидный или bufSize не равено размеру регистра.
     */
    virtual
    size_t regGetBits( size_t regNumber, uint8_t *pBuf, size_t bufSize ) override
    {
        if (regNumber>=m_regs.size())
            return npos;

        if (m_regs[regNumber].size!=bufSize)
            return npos;

        std::memcpy( (void*)pBuf, (const void*)&m_regs[regNumber].bytes[0], bufSize );

        return bufSize;
    }

    //! Доступ к нетипизированному содержимому на запись.
    /*! Для использования в клинском коде - из C#, например.
        Возвращает false, если дамп имеет ошибочный размер
     */
    virtual
    bool regSetBits( size_t regNumber, const uint8_t *pBuf, size_t bufSize ) override
    {
        if (regNumber>=m_regs.size())
        {
            onEvent( EventType::logicIndexOutOfRange, regNumber );
            ++m_updateLogicRegsErrorCount;
            return false;
        }

        if (m_regs[regNumber].size!=bufSize)
        {
            onEvent( EventType::logicSizeInvalid, regNumber );
            ++m_updateLogicRegsErrorCount;
            return false;
        }

        std::memcpy( (void*)&m_regs[regNumber].bytes[0], (const void*)pBuf, bufSize );

        m_regs[regNumber].modifiedParts = m_regs[regNumber].makeByteFlags(bufSize);
        m_regs[regNumber].validParts    = m_regs[regNumber].makeByteFlags(bufSize);

        return true;
    }


    //! Запуск транзакции обновления регистров
    virtual
    bool regsUpdateBegin() override
    {
        if (m_transactionMode)
            throw std::runtime_error("Transactions are not reentrant");

        m_transactionMode = true;
        
        m_updateLogicRegsErrorCount = 0;

        updateTransactionStart();

        return true;
    }

    //! Применение изменений
    /*! Может вернуть ошибку - false, при этом все изменения откатываются.
        На самом деле, это зависит от реализации. Реализация для компа может
        сохранять ошибки обновления
     */
    virtual
    bool regsUpdateEnd() override
    {
        updateTransactionFinalize();
        bool hasErrors = updateTransactionHasErrors();

        if (!hasErrors || !updateTransactionGetRollbackOnErrorsMode())
        {
            // нет ошибок или ошибки допустимы
            updateTransactionCommit();
            return true;
        }
        else
        {
            updateTransactionRollback();
            return false;
        }
    }

    //---------------------------
    // ILogicRegTable

    //! Возвращает имя регистра
    virtual
    const char* regGetName( size_t regNumber ) override
    {
        if (regNumber>=m_regs.size())
            return 0;

        return m_regs[regNumber].name.c_str();
    }

    //! Возвращает описание регистра
    virtual
    const char* regGetDescription( size_t regNumber ) override
    {
        if (regNumber>=m_regs.size())
            return 0;

        return m_regs[regNumber].description.c_str();
    }

    //! Format as hex dump, AsciiZ
    virtual
    size_t regGetHexDumpStr( size_t regNumber, char *pBuf, size_t bufSize ) override
    {
        if (regNumber>=m_regs.size())
            return 0;

        const auto& reg = m_regs[regNumber];

        size_t requiredSpace = reg.size*2 + reg.size-1 +     1;
                             // digits       spaces    terminating zero
        if (!pBuf)
            return requiredSpace;

        if (bufSize<requiredSpace)
            return 0;

        char *pBufTmp = pBuf;
        
        for(size_t i = 0; i!=reg.size; ++i)
        {
            if (i)
               *pBuf++ = ' ';
            *pBuf++ = umba::format_utils::digitToChar( (unsigned)((reg.bytes[i]>>4)&0x0F), umba::format_utils::CaseParam::upper );
            *pBuf++ = umba::format_utils::digitToChar( (unsigned)((reg.bytes[i]   )&0x0F), umba::format_utils::CaseParam::upper );
        }

        *pBuf++ = 0;

        return pBuf-pBufTmp;
    }

    template< typename T >
    std::string formatUnderlyingImpl( const RegisterEntry &reg, T formatAs, RegisterUnderlyingFormatFlags formatFlags, int dotNumDigits )
    {
        // Можно было бы нашаблонить, чтобы float/не-float само детектилось, но лень

        // используем переданный шаблонный параметр
        std::memcpy( (void*)&formatAs, (const void*)&reg.bytes[0], reg.size );

        umba::StringCharWriter charWritter;
        umba::SimpleFormatter  ss(&charWritter);

        using namespace umba::omanip;

        if (!!(formatFlags & RegisterUnderlyingFormatFlags::floatMode))
        {
            ss<<precision( dotNumDigits )<<fixed<<showpoint<<formatAs;
        }
        else if (!!(formatFlags & RegisterUnderlyingFormatFlags::hex))
        {
            if (!!(formatFlags & RegisterUnderlyingFormatFlags::showhex))
                //ss<<showbase;
                ss.setf( umba::SimpleFormatter :: showbase );
            else
                //ss<<noshowbase;
                ss.unsetf( umba::SimpleFormatter :: showbase );

            ss<<groupsize(4)<<groupsep(' ')<<hex;
            ss<<formatAs;
        }
        else
        {
            ss<<decgroupsize(3)<<decgroupsep(' ')<<formatAs;
        }

        return charWritter.str();
    }

    virtual
    size_t regGetUnderlyingDisplayStr( size_t regNumber, char *pBuf, size_t bufSize
                                     , RegisterUnderlyingFormatFlags formatFlags = RegisterUnderlyingFormatFlags::defaultValue
                                     , RegisterDataType overrideDataType = RegisterDataType::regTypeNoOverride // only signed/unsigned overriding allowed int<->float override not supported
                                     , int dotNumDigits = 2
                                     ) override
    {
        if (regNumber>=m_regs.size())
            return npos;

        if (pBuf && !bufSize)
            return npos;

        formatFlags &= ~RegisterUnderlyingFormatFlags::floatMode;

        RegisterDataType regType = overrideDataType;

        if (regType!=RegisterDataType::regTypeSigned && regType!=RegisterDataType::regTypeUnsigned)
            regType = RegisterDataType::regTypeNoOverride;

        if (dotNumDigits<0)
            dotNumDigits = -dotNumDigits;


        const auto& reg = m_regs[regNumber];

        if (reg.underlyingType==RegisterDataType::regTypeFloat)
        {
            regType = RegisterDataType::regTypeNoOverride;
            formatFlags |= RegisterUnderlyingFormatFlags::floatMode;
        }

        if (regType == RegisterDataType::regTypeNoOverride)
            regType = reg.underlyingType;

        std::string strRes;

        switch(regType)
        {
            case RegisterDataType::regTypeSigned:
                 switch(reg.size)
                 {
                     case 1: strRes = formatUnderlyingImpl( reg, (int8_t  )0, formatFlags, dotNumDigits );
                             break;
                     case 2: strRes = formatUnderlyingImpl( reg, (int16_t )0, formatFlags, dotNumDigits );
                             break;
                     case 4: strRes = formatUnderlyingImpl( reg, (int32_t )0, formatFlags, dotNumDigits );
                             break;
                     case 8: strRes = formatUnderlyingImpl( reg, (int64_t )0, formatFlags, dotNumDigits );
                             break;
                 }
                 break;

            case RegisterDataType::regTypeUnsigned:
                 switch(reg.size)
                 {
                     case 1: strRes = formatUnderlyingImpl( reg, (uint8_t )0, formatFlags, dotNumDigits );
                             break;
                     case 2: strRes = formatUnderlyingImpl( reg, (uint16_t)0, formatFlags, dotNumDigits );
                             break;
                     case 4: strRes = formatUnderlyingImpl( reg, (uint32_t)0, formatFlags, dotNumDigits );
                             break;
                     case 8: strRes = formatUnderlyingImpl( reg, (uint64_t)0, formatFlags, dotNumDigits );
                             break;
                 }
                 break;

            case RegisterDataType::regTypeFloat:
                 switch(reg.size)
                 {
                     case 4: strRes = formatUnderlyingImpl( reg, (float)0.0f, formatFlags, dotNumDigits );
                             break;
                     case 8: strRes = formatUnderlyingImpl( reg, (double)0.0, formatFlags, dotNumDigits );
                             break;
                 }
                 break;
        };

        if (strRes.empty())
           throw std::runtime_error("Unexpected error");

        if (!pBuf)
        {
            return strRes.size()+1;
        }

        size_t nCopied = strRes.copy( pBuf, strRes.size(), 0 );
        pBuf[nCopied] = 0;
        return nCopied+1;
    }
/*


struct RegisterEntry
{
    std::string           name;
    size_t                size              = 1;
    std::string           description;
    uint8_t               bytes[16]            ;
    //size_t                deserializedCount = 0; // количество десериализованных в последний раз данных
    uint16_t              modifiedParts     = 0; // битовая маска обновления частей регистра
    uint16_t              validParts        = 0; // битовая маска валидности частей регистра - хоть раз было что-то присвоено
    //bool                  updated           = false; // Признак обновления
    bool                  autoExtended      = false; // Добавлено для заполнения пустот перед автоматически добавляемым регистром
                                             // При чтении будет возвращать сколько затребовано (без ошибок), а при записи - зафиксирует свой размер
                                             // и последующие некорректные обращения будут генерировать ошибку
    size_t                rawStartIndex     = 0;

    size_t                groupId           = 0;

    RegustryDataType      underlyingType    = RegustryDataType::regTypeSigned;

*/

    //! Информация о группах регистрав
    virtual
    size_t getNumOfGroups() override
    {
        return m_groups.size();
    }

    //! Получение имени группы
    virtual
    const char* groupGetName( size_t groupNum ) override
    {
        if (groupNum>=m_groups.size())
            return 0;
    
        return m_groups[groupNum].name.c_str();
    }

    //! Получение описания группы
    virtual
    const char* groupGetDescription( size_t groupNum ) override
    {
        if (groupNum>=m_groups.size())
            return 0;
    
        return m_groups[groupNum].description.c_str();
    }

    //! 
    virtual
    size_t groupGetNumOfRegs( size_t groupNum ) override
    {
        if (groupNum>=m_groups.size())
            return npos;
    
        return m_groups[groupNum].regNumbers.size();
    
    }

    //! Получение номера регистра по номеру группы и номеру регистра в группе
    /*! Мы знаем число регистров в группе (см. предыдущий метод)
        Надо получить номер регистра по его порядковому номеру в группе
        делаем цикл по regOrder = { 0, NumberOfGroupRegisters }
     */
    virtual
    size_t groupGetRegNumber( size_t groupNum, size_t regInGroupOrder ) override
    {
        if (groupNum>=m_groups.size())
            return npos;

        const auto &grp = m_groups[groupNum];

        if (regInGroupOrder>=grp.regNumbers.size())
            return npos;

        return grp.regNumbers[regInGroupOrder];
    }


    //---------------------------
    // IRawRegTable

    //--------
    virtual
    size_t rawGetNumOfRegs() override
    {
        /*
        if (m_regs.empty())
            return 0;

        const auto & reg = m_regs.back();
        return reg.rawStartIndex + reg.size;
        */

        return m_regOffsets.size();
    }

    //! Обновление регистра - возврат false, если регистр не существует
    virtual
    bool rawUpdateSetReg( size_t rawIndex, uint8_t byte ) override
    {
        if (rawIndex>=m_regOffsets.size())
        {
            onEvent( EventType::rawIndexOutOfRange, rawIndex );
            ++m_updateLogicRegsErrorCount;
            return false;
        }

        const auto &offsetInfo = m_regOffsets[rawIndex];

        if (offsetInfo.regNumber>=m_regs.size())
        {
            //onEvent( EventType::rawIndexOutOfRange, rawIndex );
            //++m_updateLogicRegsErrorCount;
            //return false;

            // Ваще-то такого не должно быть никогда. А если произошло, 
            // то это значит, что таблица смещений расчитана неправильно
            throw std::runtime_error("Unexpected condition: offsetInfo.regNumber>=m_regs.size()"); 
        }

        auto & reg = m_regs[offsetInfo.regNumber];

        if (offsetInfo.byteNumber>=reg.size)
        {
            // Ваще-то такого не должно быть никогда. А если произошло, 
            // то это значит, что таблица смещений расчитана неправильно
            throw std::runtime_error("Unexpected condition: offsetInfo.byteNumber>=reg.size");
            //onEvent( EventType::rawIndexOutOfRange, rawIndex );
            //++m_updateLogicRegsErrorCount;
            //return false;
        }

        reg.bytes[ offsetInfo.byteNumber ] = byte;

        reg.modifiedParts |= 1<<offsetInfo.byteNumber;
        reg.validParts    |= 1<<offsetInfo.byteNumber;

        return true;
    }

/*
struct RegisterOffsetV1
{
    size_t regNumber;
    size_t byteNumber;

};

*/
    //--------

    //! Возвращает false, если регистр не существует
    /*! В принципе, нам тут особо не нужно знать размеры регистров - 
        за это отвечает запрашивающая сторона. Если она криво запрашивает,
        то и получит кривые регистры
     */
    virtual 
    bool rawGetReg( size_t rawIndex, uint8_t *pRegByte ) override
    {
        if (rawIndex>=m_regOffsets.size())
        {
            return false;
        }

        const auto &offsetInfo = m_regOffsets[rawIndex];

        if (offsetInfo.regNumber>=m_regs.size())
        {
            return false;
        }

        const auto & reg = m_regs[offsetInfo.regNumber];

        if (offsetInfo.byteNumber>=reg.size)
        {
            return false;
        }

        if (pRegByte)
            *pRegByte = reg.bytes[ offsetInfo.byteNumber ];

        return true;
    }

    //! Возвращает статус изменения регистра - false, если не менялся
    virtual 
    bool rawGetModifiedState( size_t rawIndex, bool *pModifiedState ) override
    {
        if (rawIndex>=m_regOffsets.size())
        {
            return false;
        }

        const auto &offsetInfo = m_regOffsets[rawIndex];

        if (offsetInfo.regNumber>=m_regs.size())
        {
            return false;
        }

        const auto & reg = m_regs[offsetInfo.regNumber];

        if (offsetInfo.byteNumber>=reg.size)
        {
            return false;
        }

        if (pModifiedState)
            *pModifiedState = (reg.modifiedParts & (1<<offsetInfo.byteNumber)) ? true : false;

        return true;
    }

    //! Возвращает индекс следующего обновившегося регистра
    /*! На старте - задаем npos
        На выходе - номер регистра, или npos, если ничего не найдено
     */
    virtual 
    size_t rawGetNextChanged( size_t rawIndex ) override
    {
        if (m_regOffsets.empty())
        {
            return npos;
        }

        if (rawIndex==npos)
        {
            rawIndex = m_regOffsets.size() - 1;
        }

        if (rawIndex>=m_regOffsets.size())
        {
            return npos;
        }

        const auto &offsetInfo = m_regOffsets[rawIndex];

        if (offsetInfo.regNumber>=m_regs.size())
        {
            return npos;
        }

        size_t regNumber = offsetInfo.regNumber + 1;

        size_t stopRegNumber = offsetInfo.regNumber;

        for( ; regNumber!=stopRegNumber; regNumber = (regNumber+1)%m_regs.size() )
        {
            if (m_regs[regNumber].modifiedParts!=0)
                return m_regs[regNumber].rawStartIndex;
        }

        return npos;
    
    }


    //! Получаем размер последовательности, которую необходимо передать в одном пакете
    /*! Используется для передачи многобайтных регистров при передаче в режиме обновлений.
        Если переданный номер не является стартовым индексом для последовательности, возвращается 0.
     */
    virtual 
    size_t rawGetSequenceSize( size_t rawIndex ) override
    {

        if (rawIndex>=m_regOffsets.size())
        {
            return false;
        }

        const auto &offsetInfo = m_regOffsets[rawIndex];

        if (offsetInfo.regNumber>=m_regs.size())
        {
            return false;
        }

        const auto & reg = m_regs[offsetInfo.regNumber];

        return reg.size;
    
    }








    std::vector<GroupInfo>         m_groups;
    std::vector<RegisterEntry>     m_regs;
    std::vector<RegisterOffsetV1>  m_regOffsets; // мапим сырой индекс в номер регистра/номер байта
    size_t                         m_transactionMode  = false;
    size_t                         m_updateLogicRegsErrorCount ;




}; // struct DynamicRegTableImplBase




} // namespace regs



