#pragma once


#include "i_generic_reg_table.h"


namespace regs
{


//! Интерфейс транзакционной таблицы регистров
interface IRegTableTransacted : inherits umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0xB555582B);

    //--------
    //! Запуск транзакции обновления регистров
    virtual
    bool regsUpdateBegin() = 0;

    //! Применение изменений
    /*! Может вернуть ошибку - false, при этом все изменения откатываются.
        На самом деле, это зависит от реализации. Реализация для компа может
        сохранять ошибки обновления
     */
    virtual
    bool regsUpdateEnd() = 0;


}; // interface IRegTableTransact


} // namespace regs


