#pragma once

#include "dynamic_reg_table_impl_base.h"
#include <cstring>

namespace regs
{


struct TransactionLogEntry
{
    static const size_t   npos = (size_t)-1;

    EventType             eventType;
    size_t                regIndex; // logic or raw 
    uint16_t              modifiedParts     = 0; // битовая маска обновления частей регистра
    uint16_t              validParts        = 0; // битовая маска валидности частей регистра - хоть раз было что-то присвоено

    size_t                rawIndex = npos;
    size_t                rawsize  = 0;


};

/*

*/


struct DynamicRegTable : public DynamicRegTableImplBase
{

    DynamicRegTable(bool rollbackOnErrors = true) : DynamicRegTableImplBase()
    , m_rollbackOnErrors(rollbackOnErrors)
    {
    }


protected:

    virtual
    void updateTransactionStart() override
    {
        m_transactionLog.clear();
        m_hasErrors = false;

        m_backupRegisters = m_regs;

        for( auto &reg : m_regs)
        {
            reg.modifiedParts = 0;
        }
    }

    virtual
    void updateTransactionFinalize()
    {
        for (size_t regNum = 0; regNum!=m_regs.size(); ++regNum)
        {
            const auto &reg = m_regs[regNum];

            if (reg.isModified())
            {
                if (reg.isPartialModified())
                    m_hasErrors = true;
                m_transactionLog.push_back( TransactionLogEntry{ reg.isPartialModified() ? EventType::partiallyUpdated : EventType::updated
                                                               , regNum, reg.modifiedParts , reg.validParts 
                                                               }
                                          );
            }
        }
    }

    virtual
    void updateTransactionCommit() override
    {
        for (size_t regNum = 0; regNum!=m_backupRegisters.size(); ++regNum)
        {
                  auto &reg       = m_regs[regNum];
            const auto &backupReg = m_backupRegisters[regNum];
            // мержим изменения
            // данные - переносим целиков
            std::memcpy( (void*)&reg.bytes, (void*)&backupReg.bytes, backupReg.size );

            // Флаги - объединяем
            reg.modifiedParts |= backupReg.modifiedParts;
            reg.validParts    |= backupReg.validParts   ;

            // Остальное - не трогаем
        }
    }

    virtual
    void updateTransactionRollback() override
    {
        m_regs = m_backupRegisters;
    }

    virtual
    bool updateTransactionHasErrors() override
    {
        return (m_updateLogicRegsErrorCount > 0) || m_hasErrors;
    }

    //! Возврат true, если при ошибках следует сделать откат, или false - если ошибки допустимы
    virtual
    bool updateTransactionGetRollbackOnErrorsMode() override
    {
        return m_rollbackOnErrors;
    }

    virtual
    void onEvent( EventType evt
                , size_t regNumber // ignored, logic or raw, depending on event type
                ) override
    {
        m_transactionLog.push_back( TransactionLogEntry{ evt, regNumber, 0, 0 } );
    }

    std::vector<TransactionLogEntry>
    getTransactionLog() const
    {
        return m_transactionLog;
    }


protected:

    bool                                m_rollbackOnErrors = true;
    bool                                m_hasErrors = false;

    std::vector<RegisterEntry>          m_backupRegisters;
    std::vector<TransactionLogEntry>    m_transactionLog;

}; // struct DynamicRegTable


} // namespace regs


