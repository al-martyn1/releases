#pragma once

#include "i_raw_reg_table.h"

namespace regs
{
namespace helpers
{


//! Разбор ганжубусного рэнджа.
/*! Возврат: 0 - если ок
             1 - ошибка размера пакета. в просмотрщике нужно отдельно рапортовать об этой ошибке
            -1 - ошибка целостности регистров. Детали ошибок целостности регистров обрабатывает таблица регистров
 */ 
inline
int ganjubusParseRangeV1( uint8_t *pData, size_t size, IRawRegTable *pRegTable  )
{
    if (size<2)
        return 1; // ошибка размера пакета

    size -= 2;

    size_t regBegin = (size_t)*pData++;
    size_t regEnd   = (1 + (size_t)*pData++);

    size_t totalRegs = regEnd - regBegin;
    if (totalRegs!=size)
        return 1; // ошибка размера пакета


    if (!pRegTable->regsUpdateBegin())
        return -1; // Какая-то ошибка с регистрами

    for(; regBegin!=regEnd; ++regBegin )
    {
        // сбрасываем старший бит, превращаем номер регистра в индекс в его пространстве имен
        pRegTable->rawUpdateSetReg( ((size_t)regBegin)&0x7Fu, *pData++ ) = 0;
        // ошибки тут игнорим 
    }

    if (!pRegTable->regsUpdateEnd())
        return -1; // Какая-то ошибка с регистрами

    return 0;
}


//! Разбор ганжубусной серии.
/*! Возврат: 0 - если ок
             1 - ошибка размера пакета. в просмотрщике нужно отдельно рапортовать об этой ошибке
            -1 - ошибка целостности регистров. Детали ошибок целостности регистров обрабатывает таблица регистров
 */ 
inline
int ganjubusParseSeriesV1( uint8_t *pData, size_t size, IRawRegTable *pRegTable  )
{
    if (size&1)
        return 1; // ошибка размера пакета - должен быть кратен двум - пары адрес/значение

    size_t totalRegs = size/2;

    if (!pRegTable->regsUpdateBegin())
        return -1; // Какая-то ошибка с регистрами

    for( size_t i = 0; i!=totalRegs; ++i )
    {
        // сбрасываем старший бит, превращаем номер регистра в индекс в его пространстве имен
        //size_t regNum = ((size_t)*pData++)&0x7Fu
        
        pRegTable->rawUpdateSetReg( ((size_t)*pData++)&0x7Fu, *pData++ ) = 0;
        // ошибки тут игнорим 
    }

    if (!pRegTable->regsUpdateEnd())
        return -1; // Какая-то ошибка с регистрами

    return 0;


}





} // namespace helpers
} // namespace regs


