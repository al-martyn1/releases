#pragma once


#include "i_reg_table_for_ui.h"


namespace regs
{


//! Расширеный интерфейс таблицы регистров для UI 
interface IRegTableForUiEx : inherits IRegTableForUi
{

    UMBA_DECLARE_INTERFACE_ID(0x1303992A);


    //! Информация о группах регистрав
    virtual
    size_t getNumOfGroups() = 0;

    //! Получение имени группы
    virtual
    const char* groupGetName( size_t groupNum ) = 0;

    //! Получение описания группы
    virtual
    const char* groupGetDescription( size_t groupNum ) = 0;

    //! 
    virtual
    size_t groupGetNumOfRegs( size_t groupNum ) = 0;

    //! Получение номера регистра по номеру группы и номеру регистра в группе
    /*! Мы знаем число регистров в группе (см. предыдущий метод)
        Надо получить номер регистра по его порядковому номеру в группе
        делаем цикл по regOrder = { 0, NumberOfGroupRegisters }
     */
    virtual
    size_t groupGetRegNumber( size_t groupNum, size_t regInGroupOrder ) = 0;


}; // interface IRegTableForUiEx


} // namespace regs


