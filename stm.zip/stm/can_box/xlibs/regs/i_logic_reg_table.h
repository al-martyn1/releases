#pragma once


#include "i_reg_table_transacted.h"


namespace regs
{


//! Интерфейс логической таблицы регистров
interface ILogicRegTable : inherits IRegTableTransacted
{

    UMBA_DECLARE_INTERFACE_ID(0x8B88E521);

    virtual
    size_t getNumOfRegs() = 0;


    //! Возвращает размер регистра, или npos при ошибке
    virtual
    size_t regGetSize( size_t regNumber ) = 0;

    //! Возвращает false если задан невалидный индекс. pModifiedState - опциональный параметр и может быть равным нулю
    virtual
    bool regGetModifiedState( size_t regNumber, bool *pModifiedState ) = 0;

    //! Сбрасывает признак модификации
    virtual
    bool regClearModifiedState( size_t regNumber ) = 0;

    //! Доступ к нетипизированному содержимому на чтение.
    /*! Для использования в клинском коде - из C#, например.
        Возвращает npos, если номер регистра невалидный или bufSize не равено размеру регистра.
     */
    virtual
    size_t regGetBits( size_t regNumber, uint8_t *pBuf, size_t bufSize ) = 0;

    //! Доступ к нетипизированному содержимому на запись.
    /*! Для использования в клинском коде - из C#, например.
        Возвращает false, если дамп имеет ошибочный размер
     */
    virtual
    bool regSetBits( size_t regNumber, const uint8_t *pBuf, size_t bufSize ) = 0;


}; // interface ILogicRegTable


} // namespace regs


