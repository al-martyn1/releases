#pragma once


#include <stddef.h>
#include <stdint.h>

#include "umba/interface.h"
#include "i_reg_table_for_ui_ex.h"

namespace regs
{


//! Интерфейс для манипуляции раскладкой регистров
interface IDynamicRegTable : inherits IRegTableForUiEx // umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0x7DBFB5F4);

    virtual
    void clear() = 0;

    //----------
    // Операции с группами

    //! Добавляет группу. grpName может быть равен 0
    virtual
    size_t groupAdd( const char* grpName ) = 0;

    //! Вставляет новую группу перед заданной. grpName может быть равен 0
    virtual
    size_t groupInsert( size_t insertBefore, const char* grpName ) = 0;

    //! Удаляет группу
    virtual
    bool groupRemove( size_t grpId ) = 0;

    //! Устанавливает название группы
    virtual
    bool groupSetName( size_t grpId, const char* grpName ) = 0;

    //! Устанавливает описание группы
    virtual
    bool groupSetDescripton( size_t grpId, const char* grpDescr ) = 0;

    //----------
    // Операции с регистрами

    //! Добавляет регистр. regName может быть равен 0
    virtual
    size_t regAdd( const char* regName, size_t regSize ) = 0;

    //! Вставляет новый регистр перед заданным. regName может быть равен 0
    virtual
    size_t regInsert( size_t insertBefore, const char* regName, size_t regSize ) = 0;

    //! Удаляет регистр
    virtual
    bool regRemove( size_t regId ) = 0;

    //! Устанавливает название регистра
    virtual
    bool regSetName( size_t regId, const char* rgName ) = 0;

    //! Устанавливает описание регистра
    virtual
    bool regSetDescripton( size_t regId, const char* regDescr ) = 0;

    //! Устанавливает размер регистра
    virtual
    bool regSetSize( size_t regId, size_t size ) = 0;

    //! Устанавливает принадлежность регистра группе
    virtual
    bool regSetGroup( size_t regId, size_t grpId ) = 0;

    virtual
    bool regSetUnderlyingType( size_t regId, RegustryDataType t ) = 0;




    //---------------------------
    // Common with ILogicRegTable
#if 0
    virtual
    size_t getNumOfRegs() = 0;

    //! Возвращает размер регистра, или npos при ошибке
    virtual
    size_t regGetSize( size_t regNumber ) = 0;

    //! Возвращает имя регистра
    virtual
    const char* regGetName( size_t regNumber ) = 0;

    //! Возвращает имя регистра
    virtual
    const char* regGetDescription( size_t regNumber ) = 0;


    //! Возвращает false если задан невалидный индекс. pModifiedState - опциональный параметр и может быть равным нулю
    virtual
    bool regGetModifiedState( size_t regNumber, bool *pModifiedState ) = 0;

    //! Сбрасывает признак модификации
    virtual
    bool regClearModifiedState( size_t regNumber ) = 0;

    //! Доступ к нетипизированному содержимому на чтение.
    /*! Для использования в клинском коде - из C#, например.
        Возвращает npos, если номер регистра невалидный или bufSize не равено размеру регистра.
     */
    virtual
    size_t regGetBits( size_t regNumber, uint8_t *pBuf, size_t bufSize ) = 0;

    //! Доступ к нетипизированному содержимому на запись.
    /*! Для использования в клинском коде - из C#, например.
        Возвращает false, если дамп имеет ошибочный размер
     */
    virtual
    bool regSetBits( size_t regNumber, const uint8_t *pBuf, size_t bufSize ) = 0;


    //! Format as hex dump, AsciiZ
    virtual
    size_t regGetHexDumpStr( char *pBuf, size_t bufSize ) = 0;

#endif


}; // interface IDynamicRegTable



} // namespace regs