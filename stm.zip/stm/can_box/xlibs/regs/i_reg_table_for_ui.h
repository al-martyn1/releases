#pragma once


#include "i_logic_reg_table.h"

#include "umba/enum_helpers.h"


namespace regs
{

enum class RegisterDataType
{
    defaultValue        = 0,
    regTypeUnknown      = 0,
    regTypeNoOverride   = 0,
    regTypeSigned,
    regTypeUnsigned,
    regTypeFloat
};

typedef RegisterDataType   RegustryDataType; //UNDONE: for compatibility, need refactoring !!!



enum class RegisterUnderlyingFormatFlags
{
    defaultValue = 0x00,
    hex          = 0x01,   // format as hex
    showhex      = 0x02,   // show hex prefix (0x)
    groups       = 0x04,   // use groups. Group separator is ' ' (space) both for dec and hex. Group size for dec is 3, for hex is 4


    floatMode    = 0x80    // for internal usage
};


UMBA_ENUM_CLASS_IMPLEMENT_FLAG_OPERATORS(RegisterUnderlyingFormatFlags)



//! Интерфейс таблицы регистров для UI
interface IRegTableForUi : inherits ILogicRegTable
{

    UMBA_DECLARE_INTERFACE_ID(0xDC22C1D2);

    //! Возвращает имя регистра
    virtual
    const char* regGetName( size_t regNumber ) = 0;

    //! Возвращает описание регистра
    virtual
    const char* regGetDescription( size_t regNumber ) = 0;

    //! Format as hex dump, AsciiZ
    virtual
    size_t regGetHexDumpStr( size_t regNumber, char *pBuf, size_t bufSize ) = 0;

    //! Возвращает строковое значение регистра
    /*! Форматирует значение регистра в строку, в зависимости от базового типа.
        Не обрабатывает флаги и перечисления.
        В большинстве случаев данного форматирования должно быть достаточно.
        Для чисел с плавающей точкой флаг formatHex не используется.
        dotNumDigits - для чисел с плавающей точкой - число знаков после запятой, 
        для целых не имеет значения.
     */
    virtual
    size_t regGetUnderlyingDisplayStr( size_t regNumber, char *pBuf, size_t bufSize
                                     , RegisterUnderlyingFormatFlags formatFlags = RegisterUnderlyingFormatFlags::defaultValue
                                     , RegisterDataType overrideDataType = RegisterDataType::regTypeNoOverride // only signed/unsigned overriding allowed int<->float override not supported
                                     , int dotNumDigits = 2
                                     ) = 0;


}; // interface IRegTableForUi


} // namespace regs


