#pragma once

#include "i_generic_reg_table.h"
#include "i_dynamic_reg_table.h"

#include "i_logic_reg_table.h"

#include "i_reg_table_for_ui.h"
#include "i_reg_table_for_ui_ex.h"

#include "umba/string_plus.h"

#include <iostream>
#include <string>
#include <vector>
#include <algorithm> 
#include <cctype>
#include <locale>
#include <iomanip>
#include <fstream>
#include <sstream>

namespace regs
{

namespace import
{

/*

stoi
stol
stoll  (C++11)
(C++11)
(C++11) 
преобразует строку в знаковое целое число
(функция)
stoul
stoull  (C++11)
(C++11) 
преобразует строку в беззнаковое целое число
(функция)
stof
stod
stold  (C++11)
(C++11)

to_string

isblank
isspace
ispunct

<cctype>
https://ru.cppreference.com/w/cpp/string/byte/isspace

https://ru.cppreference.com/w/cpp/header/cctype
tolower/toupper


https://stackoverflow.com/questions/216823/whats-the-best-way-to-trim-stdstring
https://stackoverflow.com/questions/44973435/stdptr-fun-replacement-for-c17/44973498#44973498

 */


//using namespace umba::string_plus;


static inline 
std::string make_name_copy( const std::string &str )
{
    auto res = umba::string_plus::tolower_copy(str);
    if (!res.empty())
        res[0] = (char)std::toupper((char)res[0]);
    return res;
}

static inline 
std::vector<std::string> make_name_copy( const std::vector<std::string> &strs )
{
    auto res = strs;
    for( auto &w : res )
        w = make_name_copy(w);
    return res;
}



template< typename RegTable >
inline
void clearTable( RegTable &tbl )
{
    while( tbl.getNumOfRegs() != 0 )
    {
        tbl.regRemove(0);
    }

    while( tbl.getNumOfGroups() != 0 )
    {
        tbl.groupRemove(0);
    }
}






template< typename RegTable >
inline
bool cheaderSimple( const std::vector< std::string > &lines, RegTable &rwTable, RegTable &roTable )
{
    static std::map<std::string, RegustryDataType> regTypes =
        { { "U8"  , RegustryDataType::regTypeUnsigned }
        , { "S8"  , RegustryDataType::regTypeSigned }
        , { "U16" , RegustryDataType::regTypeUnsigned }
        , { "S16" , RegustryDataType::regTypeSigned }
        , { "U32" , RegustryDataType::regTypeUnsigned }
        , { "S32" , RegustryDataType::regTypeSigned }
        , { "U64" , RegustryDataType::regTypeUnsigned }
        , { "S64" , RegustryDataType::regTypeSigned }
        , { "F32" , RegustryDataType::regTypeFloat }
        , { "F64" , RegustryDataType::regTypeFloat }
        };



    /*
    const int nsNone = 0;
    const int nsRo   = 1;
    const int nsRw   = 2;

    int nsState = nsNone;
    */

    clearTable(rwTable);
    clearTable(roTable);

    RegTable *pTable = 0;

    size_t groupId = 0;
    std::string prevRegName;
    unsigned    prevRegIdxSuffix = 0;

    for( auto line : lines )
    {
        umba::string_plus::trim( line );

        if (pTable == 0)
        {
            if ( line == "//$ROBEGIN" )
            {
                pTable = &roTable;
                groupId = 0;
                prevRegName.clear();
                prevRegIdxSuffix = 0;
            }
            else if ( line == "//$RWBEGIN" )
            {
                pTable = &rwTable;
                groupId = 0;
                prevRegName.clear();
                prevRegIdxSuffix = 0;
            }
            continue;
        }
        else // currently we are parsing NS
        {
            if ( pTable == &roTable && line == "//$ROEND" )
            {
                pTable = 0;
                continue;
            }
            else if ( pTable == &rwTable && line == "//$RWEND" )
            {
                pTable = 0;
                continue;
            }
            else if ( umba::string_plus::start_with_and_strip(line, "//$GROUP") )
            {
                umba::string_plus::trim(line);

                /* 1) Группа - перед всеми регистрами - надо добавить
                
                 */

                //getNumOfRegs()

                groupId = pTable->groupAdd( line.c_str() );
            }
            else if ( umba::string_plus::start_with_and_strip(line, "#define ") )
            {
                umba::string_plus::trim(line);

                char delim = ' ';

                std::string name, addrStr, description;

                std::vector<std::string> tokens = umba::string_plus::split( line, ' ', true  /* skipEmpty */ );
                
                if (tokens.size()<2)
                    continue;

                name    = tokens[0]; tokens.erase(tokens.begin());
                addrStr = tokens[0]; tokens.erase(tokens.begin());
                
                if (!tokens.empty() && tokens[0]=="//")
                    tokens.erase(tokens.begin());

                description = umba::string_plus::merge(tokens, ' ');
                /*
                line = textCompress( line, " " );

                std::istringstream tokenStream(line);

                std::vector<std::string> tokens;

                if ( !std::getline( tokenStream, name, delim ) )
                    continue; // bad line

                if ( !std::getline( tokenStream, addr, delim ) )
                    continue; // bad line
                
                std::getline( tokenStream, description );
                */

                
                umba::string_plus::trim(name);
                umba::string_plus::trim(addrStr);
                unsigned addr = (unsigned)-1;
                try
                {
                    addr = (unsigned)std::stoul(addrStr, 0, 0);
                }
                catch(...)
                {
                }

                if (addr>255)
                    continue;

                if (addr>=128)
                    addr -= 128;

                 if (pTable->rawGetNumOfRegs()>addr)
                     continue;

                tokens = umba::string_plus::split( name, '_', true  /* skipEmpty */ );
                if (tokens.size()>1 && (umba::string_plus::tolower_copy(tokens[0])=="ro" || umba::string_plus::tolower_copy(tokens[0])=="rw"))
                    tokens.erase(tokens.begin());

                RegustryDataType regType = RegustryDataType::regTypeUnknown;

                unsigned suffixNumber = (unsigned)-1;
                if (!tokens.empty())
                {
                    try
                    {
                        size_t numCharsParsed = 0;
                        suffixNumber = std::stoul(tokens.back(), &numCharsParsed, 0);
                        if (numCharsParsed>0)
                            tokens.erase(tokens.end()-1);
                    }
                    catch(...)
                    {}
                }

                if (!tokens.empty())
                {
                    std::string back = umba::string_plus::toupper_copy(tokens.back());
                    auto iter = regTypes.find(back);
                    if (iter!=regTypes.end())
                    {
                        tokens.erase(tokens.end()-1);
                        regType = iter->second;
                    }
                }


                tokens = make_name_copy(tokens);
                name   = umba::string_plus::merge(tokens, ' ');

                if (prevRegName==name && (prevRegIdxSuffix+1)==suffixNumber && pTable->getNumOfRegs()>0)
                {
                    // bool regSetSize( size_t regId, size_t size ) = 0;
                    auto regIdx = pTable->getNumOfRegs()-1;

                    if (suffixNumber==1)
                       pTable->regSetSize( regIdx, 2 );
                    else if (suffixNumber==3)
                       pTable->regSetSize( regIdx, 4 );

                    prevRegIdxSuffix = suffixNumber;
                }
                else
                {
                    size_t numRawRegs = pTable->rawGetNumOfRegs();
                    while( numRawRegs<addr )
                    {
                        pTable->regAdd( "Dummy", 1 );
                    }

                    auto regIdx = pTable->regAdd( name.c_str(), 1 );

                    if (!description.empty())
                        pTable->regSetDescripton(regIdx, description.c_str());

                    pTable->regSetGroup(regIdx, groupId);

                    if (regType != RegustryDataType::regTypeUnknown)
                        pTable->regSetUnderlyingType( regIdx, regType );

                    prevRegName = name;

                    //if (suffixNumber == (unsigned)-1)
                    prevRegIdxSuffix = suffixNumber;
                }

                //prevRegName.clear();
                //prevRegIdxSuffix = 0;


                //if (!tokens.empty())
                //    tokens[0] = make_name( tokens[0] )


                /*
                #define ro_sucker_pid_scale_differential_current_f32_0 0x0E // Кд
                #define ro_sucker_pid_scale_differential_current_f32_1 0x0F
                #define ro_sucker_pid_scale_differential_current_f32_2 0x10
                #define ro_sucker_pid_scale_differential_current_f32_3 0x11

                std::stringstream stream;
                stream << std::hex << your_int;
                std::string result( stream.str() );

                to_string

                */
            }


        }

    } // for( auto line : lines )

    return true;

}


template< typename RegTable >
inline
bool cheaderSimple( std::istream &in, RegTable &rwTable, RegTable &roTable )
{
    std::vector< std::string > lines;
    std::string str;
    while( std::getline( in, str ) )
    {
        lines.push_back(str);
    }

    return cheaderSimple( lines, rwTable, roTable );

}


template< typename RegTable >
inline
bool cheaderSimple( const std::string &fileName, RegTable &rwTable, RegTable &roTable )
{
    std::ifstream in(fileName.c_str());
    if (!in)
        return false;

    return cheaderSimple( in, rwTable, roTable );
}


} // namespace import


} // namespace regs


