#pragma once

#include <stddef.h>
#include <stdint.h>

#include "umba/interface.h"


namespace regs
{


const size_t npos = (size_t)-1;

//! Интерфейс какой-то таблицы регистров
interface IGenericRegTable : inherits umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0x230034CE);

    //----
    // Методы для создания/восстановления из снапшотов
    //----


    //! Сериализуем данные регистров. 
    /*! Буфера должно быть достаточно.
        Возврат npos при ошибке.
        Возврат количества использованных для сериализации байт.
        Если pBuf равен 0, то сериализация реально не производится.
     */
    virtual
    size_t serializeRegsData( uint8_t *pBuf, size_t bufSize ) = 0;

    //! Десериализуем данные регистров.
    virtual
    bool deserializeRegsData( const uint8_t *pBuf, size_t bufSize ) = 0;

    //! Сериализация метаданных (состояния, и тп) регистров
    virtual
    size_t serializeRegsMeta( uint8_t *pBuf, size_t bufSize ) = 0;

    //! Десериализация метаданных (состояния, и тп) регистров
    virtual
    bool deserializeRegsMeta( const uint8_t *pBuf, size_t bufSize ) = 0;

    //-----
    //! Сериализация раскладки
    virtual
    size_t serializeRegsLayout( uint8_t *pBuf, size_t bufSize ) = 0;

    //! Десериализация раскладки
    virtual
    bool deserializeRegsLayout( const uint8_t *pBuf, size_t bufSize ) = 0;




}; // interface IGenericRegTable



} // namespace regs

