#pragma once

#include <stdint.h>
#include <umba/umba.h>

/*! 
    \file
    \brief Работа с CRC
 */

//TODO: Вынести в отдельный большой файл заголовки групп
//! \addtogroup UMBA_LIBS_TUNING_MACROS Макросы настройки UMBA-библиотек
//! \addtogroup SCRYPTO Scrypto (Simple Crypto) - Библиотека криптографии, хэшей, CRC и тп


//! Криптография, хэши, CRC и тп
namespace scrypto
{

/*! 
 *  \addtogroup SCRYPTO
 *  @{
 */


// Разные матеръялсы на тему
// https://ru.wikipedia.org/wiki/%D0%A6%D0%B8%D0%BA%D0%BB%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B8%D0%B9_%D0%B8%D0%B7%D0%B1%D1%8B%D1%82%D0%BE%D1%87%D0%BD%D1%8B%D0%B9_%D0%BA%D0%BE%D0%B4
// https://en.wikipedia.org/wiki/Computation_of_cyclic_redundancy_checks
// https://en.wikipedia.org/wiki/Adler-32
// https://stackoverflow.com/questions/21001659/crc32-algorithm-implementation-in-c-without-a-look-up-table-and-with-a-public-li
// https://create.stephan-brumme.com/crc32/Crc32.cpp
// https://barrgroup.com/Embedded-Systems/How-To/CRC-Calculation-C-Code

// https://en.wikipedia.org/wiki/Mathematics_of_cyclic_redundancy_checks#Reciprocal_polynomials
// https://en.wikipedia.org/wiki/Mathematics_of_cyclic_redundancy_checks#Reversed_representations_and_reciprocal_polynomials


// Тестируем так (см. содержимое каталога tests/src):
// Собираем crc_test.cpp         - отладочная сборка с использованием функций CRC (определен макрос SCRYPTO_CRC_DEBUG)
// Собираем crc_test_release.cpp - релизная сборка с использованием класса CRC
// Запускаем и прогоняем через дифф (например, windiff) - смотрим глазами
// Можно использовать run_and_cmp_crc_tests.bat
// Можно смотреть не глазами, а как-то автоматом сравнить выхлоп обоих вариантов.

// Если что-то пошло не так, то собираем отладочную сборку с печатью деталей - макросы SCRYPTO_CRC_DEBUG и SCRYPTO_CRC_DEBUG_PRINT
// В отладочной сборке оставляем только проблемный CRC - коментим таблицу с тестами
// Проблемный CRC прописываем в crc_py.bat
// Запускаем тест, запускаем питоновскую версию. Смотрим, где начались расхождения


// Хелперы, надо потом перенести в umba/bits.h, если их там еще нет
// Для начала просто сделано вообще без внешних зависимостей

/*! 
    \ingroup SCRYPTO
    \addtogroup SCRYPTO_BIT_HELPERS Хелперы для работы с битами
    @{
 */


//----------------------------------------------------------------------------
//! Создаёт полную битовую маску заданного типа
/*! 
    \tparam BitsType Тип маски

    \return Полная битовая маска (все биты равны 1) для заданного типа
 */
template< typename BitsType
        >
inline
BitsType makeMask( )
{
    return ~(BitsType)0;
}


//----------------------------------------------------------------------------
//! Создаёт битовую маску заданного типа, устанавливая младших nBits бит в 1
/*! 
    \tparam BitsType Тип маски

    \return Битовая маска для заданного типа
 */
template< typename BitsType
        >
inline
BitsType makeMask( size_t nBits // Задаёт количество единичных бит
                 )
{
    if (nBits)
       --nBits;

    BitsType res = 1;
    for (size_t n=0; n!=nBits; ++n)
        res |= (res<<1);
    return res;
}


//----------------------------------------------------------------------------
//! Возвращает значение типа BitsType с установленным старшим битом
/*! 
    \tparam BitsType Тип маски

    \return Значение типа BitsType с установленным старшим битом
 */
template<typename BitsType>
inline
BitsType makeMostSignificantBit( )
{
    const BitsType mask = makeMask<BitsType>();
    return mask - (mask>>1); //MSBit;
}


//----------------------------------------------------------------------------
//! Возвращает значение типа BitsType с установленным старшим битом для разрядности, заданной параметром функции nBits.
/*! 
    Тип BitsType используется для хранения значения, параметр nBits используется для задания фактически требуемой разрядности

    \tparam BitsType Тип маски

    \return Значение типа BitsType с установленным старшим битом
 */
template<typename BitsType>
inline
BitsType makeMostSignificantBit( size_t nBits )
{
    const BitsType mask = makeMask<BitsType>( nBits );
    return mask - (mask>>1); //MSBit;
}


//----------------------------------------------------------------------------
//! Производит реверс бит (используются только младшие четыре бита параметра)
/*! 
    При реверсе бит используются только младшие 4 бита

    \return Возвращает число, биты в котором расположены в обратном порядке относительно исходного. 
    В возвращаемом значении старшие биты всегда нулевые.
 */
inline
uint8_t revertBits4( uint8_t u //!< Значение, в котором требуется перевернуть младшие 4е бита
                  )
{
    switch( u & 0x0F)
    {
        case 0x00: return 0x00;
        case 0x01: return 0x08;
        case 0x02: return 0x04;
        case 0x03: return 0x0C;
        case 0x04: return 0x02;
        case 0x05: return 0x0A;
        case 0x06: return 0x06;
        case 0x07: return 0x0E;
        case 0x08: return 0x01;
        case 0x09: return 0x09;
        case 0x0A: return 0x05;
        case 0x0B: return 0x0D;
        case 0x0C: return 0x03;
        case 0x0D: return 0x0B;
        case 0x0E: return 0x07;
        case 0x0F: return 0x0F;
        default  : return 0   ;  // Никогда не произойдёт
    }
}


//----------------------------------------------------------------------------
//! Производит реверс бит
/*! 
    \return Возвращает число, биты в котором расположены в обратном порядке относительно исходного
 */
inline
uint8_t revertBits( uint8_t u //!< Значение, в котором требуется перевернуть биты
                  )
{
    // 0x00 (0000)  -> 0x00 (0000)
    // 0x01 (0001)  -> 0x08 (1000)
    // 0x02 (0010)  -> 0x04 (0100)
    // 0x03 (0011)  -> 0x0C (1100)
    // 0x04 (0100)  -> 0x02 (0010)
    // 0x05 (0101)  -> 0x0A (1010)
    // 0x06 (0110)  -> 0x06 (0110)
    // 0x07 (0111)  -> 0x0E (1110)
    // 0x08 (1000)  -> 0x01 (0001)
    // 0x09 (1001)  -> 0x09 (1001)
    // 0x0A (1010)  -> 0x05 (0101)
    // 0x0B (1011)  -> 0x0D (1101)
    // 0x0C (1100)  -> 0x03 (0011)
    // 0x0D (1101)  -> 0x0B (1011)
    // 0x0E (1110)  -> 0x07 (0111)
    // 0x0F (1111)  -> 0x0F (1111)
    /*
    static uint8_t revertTable[16] = { 0x00, 0x08, 0x04, 0x0C
                                     , 0x02, 0x0A, 0x06, 0x0E
                                     , 0x01, 0x09, 0x05, 0x0D
                                     , 0x03, 0x0B, 0x07, 0x0F
                                     };
    return  revertTable[ (u&0xF0)>>4 ]
         | (revertTable[ (u&0x0F) ] << 4)
         ;
    */

    // Табличная реализация имхо медленнее - инит гард будет мешать постоянно
    // Возможно, если завести cpp-шечку и там объявить массив, из которого брать значения, толькобудет быстрее, и, 
    // возможно, компактнее. Но мы стронк хидер-онли

    return (revertBits4(u>>4) | (revertBits4( u ) << 4) );
}


//----------------------------------------------------------------------------
//! Производит реверс бит
/*! 
    \return Возвращает число, биты в котором расположены в обратном порядке относительно исходного
 */
inline
uint16_t revertBits( uint16_t u //!< Значение, в котором требуется перевернуть биты
                   )
{
    return  (uint16_t)revertBits( (uint8_t)(u>>8  ) )
         | ((uint16_t)revertBits( (uint8_t)(u&0xFFu) )<<8)
         ;
}


//----------------------------------------------------------------------------
//! Производит реверс бит
/*! 
    \return Возвращает число, биты в котором расположены в обратном порядке относительно исходного
 */
inline
uint32_t revertBits( uint32_t u //!< Значение, в котором требуется перевернуть биты
                   )
{
    return  (uint32_t)revertBits( (uint16_t)(u>>16  ) )
         | ((uint32_t)revertBits( (uint16_t)(u&0xFFFFu) )<<16)
         ;
}


//----------------------------------------------------------------------------
//! Производит реверс бит
/*! 
    \return Возвращает число, биты в котором расположены в обратном порядке относительно исходного
 */
inline
uint64_t revertBits( uint64_t u //!< Значение, в котором требуется перевернуть биты
                   )
{
    return  (uint64_t)revertBits( (uint32_t)(u>>32  ) )
         | ((uint64_t)revertBits( (uint32_t)(u&0xFFFFFFFFu) )<<32)
         ;
}


//----------------------------------------------------------------------------
//! Возвращает значение типа BitsType с исходным или перевёрнутым порядком бит, в зависимости от параметра revert
/*! 
    \tparam BitsType Тип, используемый для хранения бит

    \return Значение типа BitsType с опционально перевёрнытыми битами
 */

template<typename BitsType>
inline
BitsType revertBits( BitsType bits //!< Значение, в котором требуется перевернуть биты
                   , bool revert   //!< Флаг, задающий, требуется переворачивание битам, или нет
                   )
{
    return revert ? revertBits(bits) : bits;
}


//----------------------------------------------------------------------------
// End of group SCRYPTO_BIT_HELPERS
/*! @}*/



//----------------------------------------------------------------------------
/*! \def SCRYPTO_CRC_DEBUG
    \ingroup UMBA_LIBS_TUNING_MACROS
    \brief Включает режим отладки алгоритмов CRC.

    Никак не определяется в исходниках, при необходимости должен быть задан средствами среды разработки/сборочного инструмента
 */

/*! \def SCRYPTO_CRC_DEBUG_PRINT
    \ingroup UMBA_LIBS_TUNING_MACROS
    \brief Включает режим печати деталей при отладке алгоритмов CRC.

    Никак не определяется в исходниках, при необходимости должен быть задан средствами среды разработки/сборочного инструмента
 */

// Нужно, чтобы это попало в Doxygen документацию (и не попало в код проекта)
#ifdef DOXYGEN_SUNDAY_NEVER_COMES
    #define SCRYPTO_CRC_DEBUG
    #define SCRYPTO_CRC_DEBUG_PRINT
#endif

//----------------------------------------------------------------------------
//! Класс для посчета CRC
/*! 
    Класс "накапливает" CRC для тех данных, которые в него пихают разные пацаны в разное время. Не является потокобезопасным.

    \tparam CrcType Тип, хранящий значение CRC. 
    Размер данного типа должен быть больше или равен битности CRC - проверок и сравнений с битностью CRC не производится. 
    Сам себе буратины могут пытаться считать CRC16, используя uit8_t, и по рукам им никто не даст/

    Данный класс можно использовать сам по себе, и он используется в функциях подсчёта CRC в релизной версии, 
    когда не определён макрос SCRYPTO_CRC_DEBUG
 */
template <typename CrcType>
class Crc
{

public:

    //! Инициализация CRC-тора
    Crc( size_t nBits      //!< Размер CRC
       , CrcType poly      //!< Исходный полином для вычисления CRC
       , bool reversePoly  //!< Какой-то флаг про реверс полинома
       , bool reverseCalc  //!< Какой-то флаг реверса подсчёта
       , bool reverseOut   //!< Какой-то флаг реверса результата
       , CrcType initVal   //!< Начальное значение
       , CrcType resXor    //!< Xor'ит результат
       )
    : m_nBits  ( nBits )
    , m_mask   ( makeMask<CrcType>(nBits) )
    , m_msbMask( makeMostSignificantBit<CrcType>(nBits) )
    , m_poly   ( crcInitPoly( poly, reversePoly ) )
    , m_initVal( calcCrcInit(initVal) )
    , m_reverseCalc(reverseCalc)
    , m_reverseOut(reverseOut)
    , m_resXor ( resXor )
    , m_crc    ( m_initVal )
    {
        // now we ready to calc, reset not required
    }

    //! Конструктор копирования
    Crc( const Crc &c )
    : m_nBits      ( m_nBits       )
    , m_mask       ( m_mask        )
    , m_msbMask    ( m_msbMask     )
    , m_poly       ( m_poly        )
    , m_initVal    ( m_initVal     )
    , m_reverseCalc( m_reverseCalc )
    , m_reverseOut ( m_reverseOut  )
    , m_resXor     ( m_resXor      )
    , m_crc        ( m_crc         )
    {
        // now we ready to calc, reset not required
    }

    //! Сброс (переинициализация)
    /*! После сброса можно считать CRC для новой последовательности */
    void reset()
    {
        m_crc = m_initVal;
    }

    //! Финализирует вычисление CRC и возвращает конечный результат (CRC последовательности байт)
    CrcType getValue() const
    {
        return crcFinalizeCalc( m_crc ); // but we also can continue - members not modified
    }

    //! Кладёт байтик в копилку текущего цикла вычисления CRC
    void calc( uint8_t byte )
    {
        m_crc = calcStepImpl( m_crc, byte );
    }

    //! Кладёт последовательность байтиков в копилку текущего цикла вычисления CRC
    void calc( const uint8_t *pBuf, size_t len )
    {
        while(len--)
        {
            calc( *pBuf++ );
        }
    }

    //! Кладёт байтик в копилку текущего цикла вычисления CRC. То же самое, что и calc, типа пригодится для функциональщины
    void operator()( uint8_t byte )
    {
        m_crc = calcStepImpl( m_crc, byte );
    }

    //! Преобразование к базовому типу, типа пригодится для функциональщины. То же, что и getValue
    operator CrcType()
    {
        return crcFinalizeCalc( m_crc );
    }

protected:

    //! Запрет копирования. Хз, зачем, наверное просто лень было
    Crc& operator=( const Crc &c );

    const size_t m_crcTypeNumBits = 8*sizeof(CrcType); //!< Количество бит в типе, по которому считаем CRC

    const size_t  m_nBits      ; //!< Битность CRC
    const CrcType m_mask       ; //!< Маска бит CRC
    const CrcType m_msbMask    ; //!< Старший бит (маска)
    const CrcType m_poly       ; //!< Полином CRC
    const CrcType m_initVal    ; //!< Стартовое значение CRC
    const bool    m_reverseCalc; //!< Какой-то флаг реверса подсчёта
    const bool    m_reverseOut ; //!< Какой-то флаг реверса результата
    const CrcType m_resXor     ; //!< Xor'ит результат

    CrcType       m_crc        ; //!< Текущее значение  CRC


    //! Вычисление начального полинома
    CrcType crcInitPoly( CrcType poly     //!< Начальный полином
                       , bool reversePoly //!< Нужно ли реверснуть
                       ) const
    {
        if (reversePoly)
        {
            poly = revertBits( poly );
            size_t revShift = m_crcTypeNumBits-m_nBits;
            if (revShift)
                poly >>= revShift;
        }

        return poly;
    }

    //! Инициализация расчета
    CrcType calcCrcInit( CrcType initVal //!< Начальное значение
                       ) const
    {
        CrcType crc = initVal;
       
        for( size_t i = 0; i!=m_nBits; ++i )
        {
            auto lsb = crc & 1;
            if (lsb)
                crc ^= m_poly;
            crc >>= 1;
            if (lsb)
                crc |= m_msbMask;
        }

        return crc;
    }

    //! Финализация расчета
    CrcType crcFinalizeCalc( CrcType crc //!<  Вычисленная CRC
                           ) const
    {
        for( size_t i = 0; i!=m_nBits; ++i )
        {
            auto msb = crc & m_msbMask;
            crc = (crc<<1) & m_mask;
            if (msb)
                crc ^= m_poly;
        }
      
        if (m_reverseOut)
        {
            crc = revertBits( crc );
            size_t revShift = m_crcTypeNumBits-m_nBits;
            if (revShift)
                crc >>= revShift;
        }
      
        crc ^= m_resXor;
        crc &= m_mask;
      
        return crc;

    }

    //! Шаг вычислений
    CrcType calcStepImpl( CrcType crc    //!< Текущая CRC
                        , uint8_t byte   //!< Кладомый байтик
                        ) const
    {
        if (m_reverseCalc)
        {
            byte = revertBits( byte );
        }
       
        for ( auto i = 0u; i != 8u; ++i)
        {
            CrcType msb = crc & m_msbMask;
            crc = ((crc << 1) & m_mask) | ((byte >> (7 - i)) & 0x01);
            if (msb)
                crc ^= m_poly;
        }

        return crc;

    }


}; // class Crc

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
/*! 
    \ingroup SCRYPTO
    \addtogroup SCRYPTO_DEBUG_HELPERS Отладочные версии
    @{
 */
//-----------------------------------------------------------------------------

// Хелперы для реализации подсчета CRC на функциях (для отладочной версии)

//! Хелпер для для отладочной версии. return initialized poly
template< typename CrcType >
CrcType crcInitPoly( size_t nBits, CrcType poly, bool reversePoly )
{
    const size_t  crcTypeNumBits = 8*sizeof(CrcType);

    if (reversePoly)
    {
        poly = revertBits( poly );
        size_t revShift = crcTypeNumBits-nBits;
        if (revShift)
            poly >>= revShift;
    }

    return poly;
}


//----------------------------------------------------------------------------
//! Хелпер для для отладочной версии. Шаг вычислений
/*! \tparam CrcType Тип, хранящий CRC
 */
template< typename CrcType >
inline
CrcType crcStepImpl( CrcType crc, uint8_t byte, size_t nBits, CrcType poly, bool reverseCalc, size_t nShift, const CrcType mask, const CrcType msbMask )
{
    #if defined(SCRYPTO_CRC_DEBUG_PRINT)
    std::printf("Byte (1) = 0x%02X\n", (unsigned)byte );
    #endif

    if (reverseCalc)
    {
        byte = revertBits( byte );
        #if defined(SCRYPTO_CRC_DEBUG_PRINT)
        std::printf("Byte (2) = 0x%02X\n", (unsigned)byte );
        #endif
    }

    #if defined(SCRYPTO_CRC_DEBUG_PRINT)
    size_t nBytes = nBits/8;
    if (nBits%8)
        ++nBytes;
    #endif
 
    for ( auto i = 0u; i != 8u; ++i)
    {
        CrcType msb = crc & msbMask;
        crc = ((crc << 1) & mask) | ((byte >> (7 - i)) & 0x01);
        if (msb)
            crc ^= poly;

        /*
        if (reverseCalc)
        {
            crc = crc & 1 ? (crc >> 1) ^ poly : crc >> 1; // reverce
        }
        else
        {
            crc = crc & msbMask ? (crc << 1) ^ poly : crc << 1; // no reverce
        }
        crc &= mask;
        */
        
        #if defined(SCRYPTO_CRC_DEBUG_PRINT)
        std::printf("  CRC: 0x%0*llX\n", 2*nBytes, (uint64_t)crc );
        #endif
    }

    return crc;
}


//----------------------------------------------------------------------------
//! Хелпер для для отладочной версии. Финализация расчета
/*! \tparam CrcType Тип, хранящий CRC
 */
template< typename CrcType >
CrcType crcFinalizeCalc( CrcType crc, size_t nBits, CrcType poly, bool reverseOut, CrcType resXor )
{
    const CrcType mask    = makeMask<CrcType>(nBits);
    const CrcType msbMask = makeMostSignificantBit<CrcType>(nBits);
    const size_t  crcTypeNumBits = 8*sizeof(CrcType);

    for( size_t i = 0; i!=nBits; ++i )
    {
        auto msb = crc & msbMask;
        crc = (crc<<1) & mask;
        if (msb)
            crc ^= poly;

        #if defined(SCRYPTO_CRC_DEBUG_PRINT)
        std::printf("  CRC: 0x%0*llX\n", 2*nBytes, (uint64_t)crc );
        #endif
    }

    if (reverseOut)
    {
        crc = revertBits( crc );
        size_t revShift = crcTypeNumBits-nBits;
        if (revShift)
            crc >>= revShift;
    }

    crc ^= resXor;
    crc &= mask;


    return crc;

}


//----------------------------------------------------------------------------
//! Хелпер для для отладочной версии. Обработка бцфера
/*! \tparam CrcType Тип, хранящий CRC
 */
template< typename CrcType >
CrcType crcImpl( const uint8_t *pBuf, size_t len, size_t nBits, CrcType poly, bool reversePoly, bool reverseCalc, bool reverseOut, CrcType initVal, CrcType resXor )
{
    #ifndef SCRYPTO_CRC_DEBUG

        Crc<CrcType> crc( nBits, poly, reversePoly, reverseCalc, reverseOut, initVal, resXor );
        while(len--)
        {
            crc(*pBuf++);
        }

        return crc; // .getValue();

    #else

        const size_t nShift = nBits>16
                             ? 0
                             : nBits>8 ? nBits-8 : 0
                             ;
        //(CrcType)(nBits>16 ? 0 : nBits - 8); //NBits - 8; //NShift;
        const CrcType mask    = makeMask<CrcType>(nBits);
        const CrcType msbMask = makeMostSignificantBit<CrcType>(nBits);
        //const size_t  crcTypeNumBits = 8*sizeof(CrcType);
       
        /*
        if (reversePoly)
        {
            poly = revertBits( poly );
            size_t revShift = crcTypeNumBits-nBits;
            if (revShift)
                poly >>= revShift;
        }
        */
       
        poly = crcInitPoly<CrcType>( nBits, poly, reversePoly );
       
        #if defined(SCRYPTO_CRC_DEBUG_PRINT)
        size_t nBytes = nBits/8;
        if (nBits%8)
            ++nBytes;
       
        std::printf("CRC Impl, poly: 0x%0*llX   "
                   , 2*nBytes, (uint64_t)poly
                   );
        std::printf("rp: %s  rc: %s   "
                   , reversePoly?"true ":"false"
                   , reverseCalc?"true ":"false"
                   );
        std::printf("init: 0x%0*llX   xor out: 0x%0*llX\n"
                   , 2*nBytes, (uint64_t)initVal
                   , 2*nBytes, (uint64_t)resXor
                   );
        #endif
       
        CrcType crc = initVal;
       
        for( size_t i = 0; i!=nBits; ++i )
        {
            auto lsb = crc & 1;
            if (lsb)
                crc ^= poly;
            crc >>= 1;
            if (lsb)
                crc |= msbMask;
        }
       
        /*
        crc = init
        for dummy_i in range(self.width):
            bit = crc & 0x01
            if bit:
                crc ^= self.poly
            crc >>= 1
            if bit:
                crc |= self.msb_mask
        return crc & self.mask
        */
       
       
        #if defined(SCRYPTO_CRC_DEBUG_PRINT)
        std::printf("Initial CRC: 0x%0*llX\n", 2*nBytes, (uint64_t)crc );
        #endif
       
        while(len--)
        {
            crc = crcStepImpl< CrcType >( crc, *pBuf++, nBits, poly, reverseCalc, nShift, mask, msbMask );
            // CrcType crcStepImpl( CrcType crc, uint8_t byte, size_t nBits, CrcType poly )
        }
       
        /*
            for i in range(self.width):
                topbit = reg & self.msb_mask
                reg = ((reg << 1) & self.mask)
                if topbit:
                    reg ^= self.poly
        */
        #if defined(SCRYPTO_CRC_DEBUG_PRINT)
        std::printf("---\n" );
        #endif
       
        /*
        for( size_t i = 0; i!=nBits; ++i )
        {
            auto msb = crc & msbMask;
            crc = (crc<<1) & mask;
            if (msb)
                crc ^= poly;
       
            #if defined(SCRYPTO_CRC_DEBUG_PRINT)
            std::printf("  CRC: 0x%0*llX\n", 2*nBytes, (uint64_t)crc );
            #endif
        }
       
        if (reverseOut)
        {
            crc = revertBits( crc );
            size_t revShift = crcTypeNumBits-nBits;
            if (revShift)
                crc >>= revShift;
        }
       
        crc ^= resXor;
        crc &= mask;
       
       
        return crc;
        */
       
        return crcFinalizeCalc( crc, nBits, poly, reverseOut, resXor );

    #endif

}

//-----------------------------------------------------------------------------
// End of SCRYPTO_DEBUG_HELPERS
/*! @}*/
//-----------------------------------------------------------------------------



//-----------------------------------------------------------------------------
// Для упрощения подсчета CRC делаем функции.
// По дефолту ставим параметры наиболее часто используемые у нас

//----------------------------------------------------------------------------
//! Расчет CRC8 на буфере данных
inline
uint8_t crc8( const uint8_t *pBuf, size_t len, uint8_t poly = 0x31u, bool reversePoly = false, bool reverseCalc = false, bool reverseOut = false, uint8_t initVal = 0xFFu, uint8_t resXor = 0x00u )
{
    return crcImpl< uint8_t >( pBuf, len, 8, poly, reversePoly, reverseCalc, reverseOut, initVal, resXor );
}

//----------------------------------------------------------------------------
//! Расчет CRC16 на буфере данных
inline
uint16_t crc16( const uint8_t *pBuf, size_t len, uint16_t poly = 0x1021u, bool reversePoly = false, bool reverseCalc = false, bool reverseOut = false, uint16_t initVal = 0xFFFFu, uint16_t resXor = 0x0000u )
{
    return crcImpl< uint16_t >( pBuf, len, 16u, poly, reversePoly, reverseCalc, reverseOut, initVal, resXor );
}

//----------------------------------------------------------------------------
//! Расчет CRC32 на буфере данных
inline
uint32_t crc32( const uint8_t *pBuf, size_t len, uint32_t poly = 0x04C11DB7, bool reversePoly = false, bool reverseCalc = false, bool reverseOut = false, uint32_t initVal = 0xFFFFFFFFu, uint32_t resXor = 0xFFFFFFFFu )
{
    return crcImpl< uint32_t >( pBuf, len, 32u, poly, reversePoly, reverseCalc, reverseOut, initVal, resXor );
}

//-----------------------------------------------------------------------------
// Универсальные функции, размер CRC в битах задается в рантайме
// Суффикс Vs - Variable Size, затем максимальное допустимое число бит

//----------------------------------------------------------------------------
//! Расчет CRC на буфере данных, размер CRC в битах задается в рантайме, Vs - Variable Size, затем максимальное допустимое число бит
inline
uint8_t  crcVs8 ( const uint8_t *pBuf, size_t len, size_t nBits, uint8_t poly ,bool reversePoly, bool reverseCalc, bool reverseOut, uint8_t initVal, uint8_t resXor )
{
    return crcImpl< uint8_t >( pBuf, len, nBits, poly, reversePoly, reverseCalc, reverseOut, initVal, resXor );
}

//----------------------------------------------------------------------------
//! Расчет CRC на буфере данных, размер CRC в битах задается в рантайме, Vs - Variable Size, затем максимальное допустимое число бит
inline
uint16_t crcVs16( const uint8_t *pBuf, size_t len, size_t nBits, uint16_t poly ,bool reversePoly, bool reverseCalc, bool reverseOut, uint16_t initVal, uint16_t resXor )
{
    return crcImpl< uint16_t >( pBuf, len, nBits, poly, reversePoly, reverseCalc, reverseOut, initVal, resXor );
}

//----------------------------------------------------------------------------
//! Расчет CRC на буфере данных, размер CRC в битах задается в рантайме, Vs - Variable Size, затем максимальное допустимое число бит
inline
uint32_t crcVs32( const uint8_t *pBuf, size_t len, size_t nBits, uint32_t poly ,bool reversePoly, bool reverseCalc, bool reverseOut, uint32_t initVal, uint32_t resXor )
{
    return crcImpl< uint32_t >( pBuf, len, nBits, poly, reversePoly, reverseCalc, reverseOut, initVal, resXor );
}

//----------------------------------------------------------------------------
//! Расчет CRC на буфере данных, размер CRC в битах задается в рантайме, Vs - Variable Size, затем максимальное допустимое число бит
inline
uint64_t crcVs64( const uint8_t *pBuf, size_t len, size_t nBits, uint64_t poly, bool reversePoly, bool reverseCalc, bool reverseOut, uint64_t initVal, uint64_t resXor )
{
    return crcImpl< uint64_t >( pBuf, len, nBits, poly, reversePoly, reverseCalc, reverseOut, initVal, resXor );
}

/*! @}*/


} // namespace scrypto


