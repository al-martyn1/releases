
#include "umba/memory_pools_impl.h"
#include "umba/assert.h"

#include "umba/bits.h"


//-----------------------------------------------------------------------------
namespace umba
{
namespace memory
{



//-----------------------------------------------------------------------------
GrowingMemoryPool::GrowingMemoryPool(RawMemPtr pMemChunk, size_t memChunkSize)
    : m_pOrgMemChunk   ( (ByteMemPtr)memory_pool_impl::align_addr( (void*)pMemChunk, memory_pool_impl::default_alignment ) )
    , m_orgMemChunkSize(             memory_pool_impl::align_size( memChunkSize    , memory_pool_impl::default_alignment ) )
    , m_pMemChunk      ( (ByteMemPtr)memory_pool_impl::align_addr( (void*)pMemChunk, memory_pool_impl::default_alignment ) )
    , m_memChunkSize   (             memory_pool_impl::align_size( memChunkSize    , memory_pool_impl::default_alignment ) )
{
    UMBA_ASSERT(m_pMemChunk!=0);
    UMBA_ASSERT(m_memChunkSize!=0);
}

//-----------------------------------------------------------------------------
size_t GrowingMemoryPool::queryOptimalAllocationSize( size_t requestFor, size_t alignment )
{
    return memory_pool_impl::calcNiceBlockSize( m_pMemChunk, requestFor, alignment);
}

//-----------------------------------------------------------------------------
RawMemPtr GrowingMemoryPool::allocateMemoryBlock(size_t numBytes, size_t alignment)
{
    alignment = memory_pool_impl::adjustAlignment(alignment);

    if (!numBytes)
        numBytes = 1;

    numBytes = memory_pool_impl::align_size( numBytes, memory_pool_impl::min_alignment );

    //size_t recomendedNumBytes;
    //ByteMemPtr nextHead = memory_pool_impl::calcNextHead( m_pMemChunk, numBytes, alignment, 0 /*&numBytes*/ );

    size_t infoSize = getChunkInfoSize();

    size_t nbTotalAllocate = numBytes + infoSize;

    if ( m_memChunkSize < nbTotalAllocate )
        return 0;

    GrowingMemoryPoolChunkInfo chunkInfo;
    chunkInfo.chunkPrevHead = (RawMemPtr)m_pMemChunk;
    chunkInfo.chunkSize = numBytes;
    //= { (RawMemPtr)m_pMemChunk, numBytes }; // put only payload size

    //GrowingMemoryPoolChunkInfo *pChunkInfo = (GrowingMemoryPoolChunkInfo*)(m_pMemChunk);
    //*pChunkInfo = chunkInfo;

    //RawMemPtr resPtr = (RawMemPtr)(m_pMemChunk + infoSize);

    RawMemPtr  resPtr = memory_pool_impl::align_addr( m_pMemChunk + infoSize, alignment );
    ByteMemPtr nextHeadPtr = ((ByteMemPtr)resPtr) + numBytes;
    size_t actualAllocatedBytes = nextHeadPtr - m_pMemChunk;
    if ( m_memChunkSize < actualAllocatedBytes )
        return 0;

    GrowingMemoryPoolChunkInfo *pChunkInfo = (GrowingMemoryPoolChunkInfo*)(resPtr);
    --pChunkInfo;
    *pChunkInfo = chunkInfo;

    m_memChunkSize -= actualAllocatedBytes;
    m_pMemChunk     = nextHeadPtr;
    
    return resPtr;
}

//-----------------------------------------------------------------------------
bool GrowingMemoryPool::canDeallocate( ByteMemPtr pChunk, GrowingMemoryPoolChunkInfo *pChunkInfo ) const
{
    //UMBA_ASSERT( (ByteMemPtr)pChunkInfo->chunkPrevHead == (ByteMemPtr)pChunkInfo);

    #if !defined(UMBA_MPOOL_NDEBUG)
        #if !defined(_WIN64) /*sizeof(uintptr_t)<8*/
            UMBA_ASSERT( pChunkInfo->fill == UMBA_MEMORY_POOL_CHUNKINFO_FILLING_VAL );
        #else
            UMBA_ASSERT( pChunkInfo->fill[0] == UMBA_MEMORY_POOL_CHUNKINFO_FILLING_VAL );
            UMBA_ASSERT( pChunkInfo->fill[0] == UMBA_MEMORY_POOL_CHUNKINFO_FILLING_VAL );
        #endif
    #endif

    ByteMemPtr pHead = pChunk + pChunkInfo->chunkSize;

    return pHead == m_pMemChunk;

}

//-----------------------------------------------------------------------------
void GrowingMemoryPool::restoreHead( ByteMemPtr pChunk, GrowingMemoryPoolChunkInfo *pChunkInfo )
{
    size_t infoSize = getChunkInfoSize();

    m_memChunkSize += ((ByteMemPtr)pChunkInfo->chunkPrevHead - m_pMemChunk);// pChunkInfo->chunkSize + infoSize;
    m_pMemChunk    = (ByteMemPtr)pChunkInfo->chunkPrevHead; // (ByteMemPtr)pChunkInfo;
}

//-----------------------------------------------------------------------------
// Память возвращается только в порядке, противоположном порядку выделения
bool GrowingMemoryPool::deallocateMemoryBlock(RawMemPtr memPtr)
{
    UMBA_ASSERT( checkMemoryBlockOnwnership(memPtr) );

    size_t infoSize = getChunkInfoSize();
    ByteMemPtr pChunk = (ByteMemPtr)memPtr;
    GrowingMemoryPoolChunkInfo *pChunkInfo = (GrowingMemoryPoolChunkInfo*)(pChunk - infoSize);

    if (!canDeallocate( pChunk, pChunkInfo ))
    {
        return false;
    }

    restoreHead( pChunk, pChunkInfo );

    fillDebugSignature( m_pMemChunk, pChunkInfo->chunkSize + infoSize );

    return true;
}

//-----------------------------------------------------------------------------
bool GrowingMemoryPool::expandMemoryBlock(RawMemPtr memPtr, size_t numBytesNew)
{
    UMBA_ASSERT( checkMemoryBlockOnwnership(memPtr) );

    size_t infoSize = getChunkInfoSize();
    ByteMemPtr pChunk = (ByteMemPtr)memPtr;
    GrowingMemoryPoolChunkInfo *pChunkInfo = (GrowingMemoryPoolChunkInfo*)(pChunk - infoSize);

    numBytesNew = memory_pool_impl::align_size( numBytesNew, memory_pool_impl::default_alignment );
    if (numBytesNew <= pChunkInfo->chunkSize)
       return true; // Nothing to do for success

    if (!canDeallocate( pChunk, pChunkInfo ))
    {
        return false;
    }

    size_t numBytesExpand = numBytesNew - pChunkInfo->chunkSize;
    if (m_memChunkSize < numBytesExpand)
        return false; // No room for chunk expansion

    m_pMemChunk    += numBytesExpand; // simply move pointer
    m_memChunkSize -= numBytesExpand; // simply reduce available space

    pChunkInfo->chunkSize = numBytesNew;

    return true;
}

//-----------------------------------------------------------------------------
bool GrowingMemoryPool::checkMemoryBlockOnwnership(RawMemPtr memPtr)
{
    const RawMemPtr b = (RawMemPtr)m_pOrgMemChunk;
    const RawMemPtr e = (RawMemPtr)(m_pOrgMemChunk+m_orgMemChunkSize);
    return (memPtr >= b) && (memPtr < e);
}

//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------
#if defined(UMBA_MCU_USED)
    #define UMBA_FIXED_SIZE_MEMORY_POOL_ELEMENT_NUMBER_INVALID  (65535)
    #define UMBA_FIXED_SIZE_MEMORY_POOL_ELEMENT_NUMBER_MAX      (65535-1)
#else
    #define UMBA_FIXED_SIZE_MEMORY_POOL_ELEMENT_NUMBER_INVALID  (SIZE_MAX)
    #define UMBA_FIXED_SIZE_MEMORY_POOL_ELEMENT_NUMBER_MAX      (SIZE_MAX-1)
#endif


//-----------------------------------------------------------------------------
FixedSizeMemoryPool::FixedSizeMemoryPool(RawMemPtr pMemChunk, size_t memChunkSize, size_t elementSize )
    : m_pMemChunk( (ByteMemPtr)pMemChunk )
    , m_memChunkSize( memChunkSize )
    , m_elementSize( elementSize )
    , m_firstAvail( 0 )
    , m_availCount( (ElementNumber)(memChunkSize/elementSize) )
    , m_maxNumUsed( 0 )
    , m_pNextPool(0)
{
    UMBA_ASSERT(m_pMemChunk!=0);
    UMBA_ASSERT(m_memChunkSize!=0);
    UMBA_ASSERT(m_availCount!=0);    
    UMBA_ASSERT(elementSize!=0);    

    size_t totalElements = memChunkSize/elementSize;
    UMBA_ASSERT( totalElements <= UMBA_FIXED_SIZE_MEMORY_POOL_ELEMENT_NUMBER_MAX );

    // Первоначальная разметка списка блоков
    size_t i = 0;
    for(; i != (totalElements-1); ++i)
    {
        ElementNumber* pElement = getItemPtr( (ElementNumber)i );
        *pElement = i+1;
    }

    ElementNumber* pElement = getItemPtr( (ElementNumber)i );
    *pElement = UMBA_FIXED_SIZE_MEMORY_POOL_ELEMENT_NUMBER_INVALID;
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
size_t FixedSizeMemoryPool::queryOptimalAllocationSize( size_t requestFor, size_t alignment )
{
    return requestFor;
}

//-----------------------------------------------------------------------------
RawMemPtr FixedSizeMemoryPool::allocateMemoryBlock(size_t numBytes, size_t alignment)
{
    if (!numBytes)
        numBytes = 1;

    if (numBytes>m_elementSize)
        return 0;

    if (!m_availCount)
        return 0;

    RawMemPtr res = getItemRawPtr( m_firstAvail );

    ElementNumber* pCapturedElement = getItemPtr( (ElementNumber)m_firstAvail);
    m_firstAvail = *pCapturedElement;

    m_availCount--;

    ElementNumber totalElementsNum = (ElementNumber)(m_memChunkSize/m_elementSize);
    ElementNumber totalUsedNum     = totalElementsNum - m_availCount;

    if (m_maxNumUsed<totalUsedNum)
        m_maxNumUsed = totalUsedNum;

    return res;
}

//-----------------------------------------------------------------------------
bool FixedSizeMemoryPool::deallocateMemoryBlock(RawMemPtr memPtr)
{
    UMBA_ASSERT(checkMemoryBlockOnwnership(memPtr));

    ElementNumber itemNoFreed = getItemIndex( memPtr );

    ElementNumber* pElementFreed = getItemPtr(itemNoFreed);
    *pElementFreed = m_firstAvail;
    m_firstAvail = itemNoFreed;
    m_availCount++;

    return true;
}

//-----------------------------------------------------------------------------
bool FixedSizeMemoryPool::expandMemoryBlock(RawMemPtr memPtr, size_t numBytesNew)
{
    if (numBytesNew>m_elementSize)
        return false;
    return true;
}

//-----------------------------------------------------------------------------
bool FixedSizeMemoryPool::checkMemoryBlockOnwnership(RawMemPtr memPtr)
{
    ByteMemPtr byteMemPtr = (ByteMemPtr)memPtr;
    if (byteMemPtr < m_pMemChunk)
        return false;

    size_t diff = (size_t)(byteMemPtr-m_pMemChunk);
    if (diff>=m_memChunkSize)
        return false;

    return true;
}

//-----------------------------------------------------------------------------
RawMemPtr FixedSizeMemoryPool::getItemRawPtr( ElementNumber itemNo )
{
    return (RawMemPtr)(m_pMemChunk + m_elementSize*itemNo);
}

//-----------------------------------------------------------------------------
FixedSizeMemoryPool::ElementNumber* FixedSizeMemoryPool::getItemPtr( ElementNumber itemNo )
{
     return (ElementNumber*)(m_pMemChunk + m_elementSize*itemNo);
}

//-----------------------------------------------------------------------------
FixedSizeMemoryPool::ElementNumber  FixedSizeMemoryPool::getItemIndex( RawMemPtr memPtr )
{
    ByteMemPtr byteMemPtr = (ByteMemPtr)memPtr;
    if (byteMemPtr < m_pMemChunk)
        return 0;

    size_t diff = (size_t)(byteMemPtr-m_pMemChunk);
    if (diff>=m_memChunkSize)
        return 0;

    return (ElementNumber)diff / m_elementSize;
}

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
static size_t fixedPoolSizes[16] = {
   64,  64,  64,  64, //   8  16  24  32
   32,  32,  32,  32, //  40  48  56  64
   16,  16,  16,  16, //  80  96 112 128
    8,   8,   8,   8  // 160 192 224 256
                      // 320 384 448 512 
}; // 64*8+64*16+64*24+64*32+32*40+32*48+32*56+32*64+16*80+16*96+16*112+16*128+8*160+8*192+8*224+8*256 = 25088

//-----------------------------------------------------------------------------
void DynamicMemoryPool::initPoolSizes() const
{
    #if defined( UMBA_MEMORY_POOL_LOW_MEM_EXTRIMELY)
    fixedPoolSizes[0] = 16;
    fixedPoolSizes[1] =  8;
    fixedPoolSizes[2] =  8;
    #elif defined(UMBA_MEMORY_POOL_LOW_MEM)
    for(size_t i=0; i!=numberOfPools; ++i)
    {
        fixedPoolSizes[i] /= 4;
    }
    #elif defined(_WIN32)
    for(size_t i=0; i!=numberOfPools; ++i)
    {
        fixedPoolSizes[i] *= 4;
    }
    #endif

}

//-----------------------------------------------------------------------------
DynamicMemoryPool::DynamicMemoryPool( )
   : freeBlocksListItemsPool(0)
   , m_pHeadFreeBlocks(0)
   , m_pTailFreeBlocks(0)
{
    for( size_t i=0; i!=DynamicMemoryPool::numberOfPools; ++i)
    {
        m_fixedPools[i] = 0;
    }

    initPoolSizes();
}

//-----------------------------------------------------------------------------
size_t DynamicMemoryPool::queryOptimalAllocationSize( size_t requestFor, size_t alignment )
{
    freeBlockList();

    size_t blockSize = 0;
    size_t poolIdx = calulatePoolIndex( requestFor, &blockSize );
    if (poolIdx < numberOfPools)
        return blockSize;

    BlocksListItem *pItem = m_pHeadFreeBlocks;
    while(pItem)
    {
        GrowingMemoryPoolChunkInfo *pChunkInfo = (GrowingMemoryPoolChunkInfo*) pItem->pBlock;
        --pChunkInfo;
        if (pChunkInfo->chunkSize >= requestFor)
        {
           ByteMemPtr alignedPtr = (ByteMemPtr)umba::memory::memory_pool_impl::align_addr( (void*)pItem->pBlock, alignment );
           if (alignedPtr==pItem->pBlock)
               return pChunkInfo->chunkSize; // подошло по запрошенному выравниванию
        }
        pItem = pItem->pNextItem;
    }

    return globalStaticMemoryPool->queryOptimalAllocationSize( requestFor, alignment );
}

//-----------------------------------------------------------------------------
RawMemPtr DynamicMemoryPool::allocateBlockFromList( size_t numBytes, size_t alignment )
{
    BlocksListItem *pPrevItem = 0;
    BlocksListItem *pItem = m_pHeadFreeBlocks;
    while(pItem)
    {
        GrowingMemoryPoolChunkInfo *pChunkInfo = (GrowingMemoryPoolChunkInfo*) pItem->pBlock;
        --pChunkInfo;
        if (pChunkInfo->chunkSize >= numBytes)
        {
           ByteMemPtr alignedPtr = (ByteMemPtr)umba::memory::memory_pool_impl::align_addr( (void*)pItem->pBlock, alignment );
           if (alignedPtr==pItem->pBlock)
           {
               if (!pPrevItem)
               {
                   // found at head
                   m_pHeadFreeBlocks = 0;
                   //m_pTailFreeBlocks = 0;
               }
               else
               {
                   // remove from chain
                   pPrevItem->pNextItem = pItem->pNextItem;
               }

               RawMemPtr res = (RawMemPtr)pItem->pBlock;
               deallocateBlocksListItem( pItem );
               return res;
           }
        }

        pPrevItem = pItem;
        pItem = pItem->pNextItem;
    }

    return 0;
}

//-----------------------------------------------------------------------------
RawMemPtr DynamicMemoryPool::allocateBlock( size_t numBytes, size_t alignment )
{
    RawMemPtr res = allocateBlockFromList( numBytes, alignment );
    if (res)
        return res;

    return globalStaticMemoryPool->allocateMemoryBlock( numBytes, alignment );
}

//-----------------------------------------------------------------------------
bool DynamicMemoryPool::deallocateBlock( RawMemPtr pBlock )
{
    // Try to return to global pool
    if (globalStaticMemoryPool->deallocateMemoryBlock(pBlock))
        return true;

    // Try to put to free blocks list
    BlocksListItem* pNewItem = allocateBlocksListItem();
    if (!pNewItem)
        return false; //NOTE: memory leak

    pNewItem->pBlock = (ByteMemPtr)pBlock;

    // find block with address less size then currently deallocated
    BlocksListItem *pPrevItem = 0;
    BlocksListItem *pItem = m_pHeadFreeBlocks;
    while(pItem)
    {
        //GrowingMemoryPoolChunkInfo *pChunkInfo = (GrowingMemoryPoolChunkInfo*) pItem->pBlock;
        //--pChunkInfo;
        if (pItem->pBlock < (ByteMemPtr)pBlock)
        {
            // pItem points to block with less addr
            // make it next
            pNewItem->pNextItem = pItem;
            if (pPrevItem)
                pPrevItem->pNextItem = pNewItem;
            else
                m_pHeadFreeBlocks = pNewItem;

            return true;
        }
        pItem = pItem->pNextItem;
    }

    // Все адреса в списке больше
    pNewItem->pNextItem = 0; // Добавляем конец
    if (!pPrevItem)
        m_pHeadFreeBlocks = pNewItem;
    else
        pPrevItem->pNextItem = pNewItem;

    return true;
}

//-----------------------------------------------------------------------------
bool DynamicMemoryPool::freeBlockList()
{
    while(m_pHeadFreeBlocks)
    {
        if (!globalStaticMemoryPool->deallocateMemoryBlock(m_pHeadFreeBlocks->pBlock))
           return false;
        BlocksListItem *pNextItem = m_pHeadFreeBlocks->pNextItem;
        deallocateBlocksListItem( m_pHeadFreeBlocks );
        m_pHeadFreeBlocks = pNextItem;
    }
    return true;
}

//-----------------------------------------------------------------------------
FixedSizeMemoryPool* DynamicMemoryPool::allocatePool( size_t numBytes, size_t blockSize )
{
    RawMemPtr pRaw = allocateBlock( sizeof(FixedSizeMemoryPool), memory_pool_impl::default_alignment );
    if (!pRaw)
        return 0;

    size_t chunkAlignment = blockSize > memory_pool_impl::default_alignment ? memory_pool_impl::default_alignment : blockSize;
    RawMemPtr pChunk = allocateBlock( numBytes, chunkAlignment );
    if (!pChunk)
    {
        deallocateBlock( pRaw );
        return 0;
    }

    return new(pRaw) FixedSizeMemoryPool( pChunk, numBytes, blockSize );
}

//-----------------------------------------------------------------------------
void DynamicMemoryPool::deallocatePool( FixedSizeMemoryPool* pPool )
{
    deallocateBlock( (RawMemPtr)pPool->m_pMemChunk );
    pPool->~FixedSizeMemoryPool();
    deallocateBlock( (RawMemPtr)pPool );
}

//-----------------------------------------------------------------------------
RawMemPtr DynamicMemoryPool::allocateFromPool( size_t poolIdx, size_t blockSize, FixedSizeMemoryPool* pPool, size_t numBytes, FixedSizeMemoryPool ** ppNewPool)
{
    FixedSizeMemoryPool* pPrevPool = 0;

    // find pool with free cells
    while(pPool)
    {
        if (pPool->m_availCount > 0)
            break;

        pPrevPool = pPool;
        pPool = pPool->m_pNextPool;
    }

    if (!pPool)
    {
        size_t poolNumBytes = numberOfLargeBlocks*blockSize;
        if (poolIdx!=(size_t)-1)
           poolNumBytes = fixedPoolSizes[poolIdx] * blockSize;

        pPool = allocatePool( poolNumBytes, blockSize );
        if (ppNewPool)
            *ppNewPool = pPool;
        if (pPrevPool)
            pPrevPool->m_pNextPool = pPool;
    }

    if (!pPool)
        return (RawMemPtr)0;

    return pPool->allocateMemoryBlock( numBytes, 0 );

}

//-----------------------------------------------------------------------------
DynamicMemoryPool::BlocksListItem* DynamicMemoryPool::allocateBlocksListItem( )
{
    size_t blockSize = 0;
    calulatePoolIndex( sizeof(BlocksListItem), &blockSize );

    FixedSizeMemoryPool ** ppNewPool = 0;
    if (!freeBlocksListItemsPool)
        ppNewPool = &freeBlocksListItemsPool;

    return (BlocksListItem*)allocateFromPool( (size_t)-1, blockSize, freeBlocksListItemsPool, sizeof(BlocksListItem), ppNewPool );
}

//-----------------------------------------------------------------------------
void DynamicMemoryPool::deallocateBlocksListItem(DynamicMemoryPool::BlocksListItem* pItem )
{
    FixedSizeMemoryPool* pPrevPool = 0;
    FixedSizeMemoryPool* pPool = freeBlocksListItemsPool;

    while(pPool)
    {
        if (pPool->checkMemoryBlockOnwnership((RawMemPtr)pItem))
            break;
        pPrevPool = pPool;
        pPool = pPool->m_pNextPool;
    }

    if (pPool)
    {
        pPool->deallocateMemoryBlock((RawMemPtr)pItem);
        if (pPool->isEmpty())
        {
            // deallocate
            if (pPrevPool)
                pPrevPool->m_pNextPool = pPool->m_pNextPool;
            else
                freeBlocksListItemsPool = pPool->m_pNextPool;

            deallocatePool( pPool );
        }
    }
}

//-----------------------------------------------------------------------------
RawMemPtr DynamicMemoryPool::allocateMemoryBlock(size_t numBytes, size_t alignment)
{
    freeBlockList();

    if (!numBytes)
        numBytes = 1;

    size_t blockSize = 0;
    size_t poolIdx = calulatePoolIndex( numBytes, &blockSize );

    if (poolIdx<numberOfPools)
    {
        // get block from fixed pool
        FixedSizeMemoryPool ** ppNewPool = 0;
        if (!m_fixedPools[poolIdx])
            ppNewPool = &m_fixedPools[poolIdx];
        return allocateFromPool( poolIdx, blockSize, m_fixedPools[poolIdx], numBytes, ppNewPool);
    }
    else
    {
        // get block from large list or global mem
        return allocateBlock( numBytes, alignment );
    
    }
}

//-----------------------------------------------------------------------------
bool DynamicMemoryPool::deallocateMemoryBlock(RawMemPtr memPtr)
{
    if (!memPtr)
        return true;

    size_t poolIdx = 0;
    for(; poolIdx!=numberOfPools; ++poolIdx)
    {
        FixedSizeMemoryPool* pPrevPool = 0;
        FixedSizeMemoryPool* pPool = m_fixedPools[poolIdx];

        while(pPool)
        {
            if (pPool->checkMemoryBlockOnwnership(memPtr))
                break;
            pPrevPool = pPool;
            pPool = pPool->m_pNextPool;
        }

        if (pPool)
        {
            pPool->deallocateMemoryBlock(memPtr);
            if (pPool->isEmpty())
            {
                // deallocate
                if (pPrevPool)
                    pPrevPool->m_pNextPool = pPool->m_pNextPool;
                else
                    m_fixedPools[poolIdx] = pPool->m_pNextPool;

                deallocatePool( pPool );
            }
            return true;
        }
    } // for(; poolIdx!=numberOfPools; ++poolIdx)

    return deallocateBlock( memPtr );
}

//-----------------------------------------------------------------------------
bool DynamicMemoryPool::expandMemoryBlock(RawMemPtr memPtr, size_t numBytesNew)
{
    //UNDONE:
    return false;
}

//-----------------------------------------------------------------------------
bool DynamicMemoryPool::checkMemoryBlockOnwnership(RawMemPtr memPtr)
{
    if (!memPtr)
        return false;

    size_t poolIdx = 0;
    for(; poolIdx!=numberOfPools; ++poolIdx)
    {
        FixedSizeMemoryPool* pPrevPool = 0;
        FixedSizeMemoryPool* pPool = m_fixedPools[poolIdx];

        while(pPool)
        {
            if (pPool->checkMemoryBlockOnwnership(memPtr))
                return true;
            pPrevPool = pPool;
            pPool = pPool->m_pNextPool;
        }

    } // for(; poolIdx!=numberOfPools; ++poolIdx)

    return globalStaticMemoryPool->checkMemoryBlockOnwnership(memPtr);

}

//-----------------------------------------------------------------------------




/*
 use chunk sizes
         4,    8,   16,   32, 
        64,  128,  256,  512,
      1024, 2048,

0x0004            2
0x0008            3
0x0010            4
0x0020            5
0x0040            6

0x0080            7
0x0100 - 256      8
0x0200 - 512      9
0x0400 - 1024    10
0x0800 - 2048    11

2-11 => 0-9

*/



}; // namespace memory
}; // namespace umba

