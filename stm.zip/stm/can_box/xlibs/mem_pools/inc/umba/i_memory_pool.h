/*! \file
\brief Интерфейс пула памяти

*/

#pragma once

#include "umba/interface.h"


namespace umba
{
namespace memory
{

typedef void*    RawMemPtr;


//! Интерфейс IMemoryPool предоставляет API для выделения, освобождения, и расширения блоков памяти
UMBA_INTERFACE IMemoryPool : UMBA_INHERITS IUnknown
{
    UMBA_DECLARE_INTERFACE_ID(0x6DC035BF);

    typedef uint8_t* ByteMemPtr;

    virtual
    size_t queryOptimalAllocationSize( size_t requestFor, size_t alignment ) = 0;

    //! Выделяет память в пуле и возвращает указатель на выделенный блок
    virtual
    RawMemPtr allocateMemoryBlock(size_t numBytes, size_t alignment) = 0;

    //! Освобождает ранее выделенный блок памяти для повторного использования
    virtual
    bool deallocateMemoryBlock(RawMemPtr memPtr) = 0;

    //! Расширяет блок памяти до нового размера без перемещения. Если это невозможно, возвращается false
    virtual
    bool expandMemoryBlock(RawMemPtr memPtr, size_t numBytesNew) = 0;

    //! Проверяет принадлежность блока памяти данному пулу
    virtual
    bool checkMemoryBlockOnwnership(RawMemPtr memPtr) = 0;


}; // interface IMemoryPool

}; // namespace memory


extern memory::IMemoryPool* globalStaticMemoryPool;
extern memory::IMemoryPool* globalHeapMemoryPool;



}; // namespace umba

