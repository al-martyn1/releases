#pragma once

#include <cstddef>

#include "i_memory_pool.h"
#include "umba/assert.h"



namespace umba
{


template <class _TypeT> struct allocator;


template<>
struct allocator<void>
{

    typedef void*       pointer;
    typedef const void* const_pointer;
    typedef void        value_type;
   
    template <class _TypeU> 
    struct rebind {
        typedef allocator<_TypeU> other;
    };
    
};





template< class T >
struct allocator
{

    typedef T              value_type;
    typedef T*             pointer;
    typedef const T*       const_pointer;
    typedef T&             reference;
    typedef const T&       const_reference;
    typedef std::size_t    size_type;
    typedef std::ptrdiff_t difference_type;


    allocator () { }

    allocator (const allocator &) { }

    template <class _TypeU> 
    struct rebind
    {
        typedef allocator<_TypeU> other;
    };

    template <class _TypeU>
    allocator (const allocator<_TypeU>&) { }

    template <class _TypeU>
    allocator&
    operator= (const allocator<_TypeU>&)
    { 
        return *this; 
    }

    pointer address (reference __x) const
    { 
        return &__x; 
    }

    const_pointer address (const_reference __x) const
    { 
        return &__x;
    }

    size_t calc_alignemnt( )
    {
        size_t sz = sizeof(value_type);
        if (sz < 2)
            return 1;
        else if (sz < 4)
            return 2;
        else if (sz < 8)
            return 4;
        else if (sz < 16)
            return 8;
        return 16;
    }

    pointer allocate (size_type n, allocator<void>::const_pointer hint = 0)
    {
        pointer p = (pointer)globalHeapMemoryPool->allocateMemoryBlock( n * sizeof (value_type), calc_alignemnt() );
        UMBA_ASSERT(p!=0);
        return p;
    }

    void deallocate (pointer p, size_type n)
    {
        globalHeapMemoryPool->deallocateMemoryBlock( (umba::memory::RawMemPtr)p );
    }

    // 20.4.1.1, p11 - the largest N for which allocate (N) might succeed
    size_type max_size () const
    { 
        if (size_type (~0) / sizeof (value_type))
            return size_type (size_type (~0) / sizeof (value_type));
        else 
            return size_type (1);
    }

    void construct (pointer p, const_reference val)
    {
        ::new (p) value_type (val);
    }
    
    void destroy (pointer p)
    {
        (*p).~value_type();
    }

}; // struct allocator






template< class T >
struct static_allocator
{

    typedef T              value_type;
    typedef T*             pointer;
    typedef const T*       const_pointer;
    typedef T&             reference;
    typedef const T&       const_reference;
    typedef std::size_t    size_type;
    typedef std::ptrdiff_t difference_type;


    static_allocator () { }

    static_allocator (const static_allocator &) { }

    template <class _TypeU> 
    struct rebind
    {
        typedef static_allocator<_TypeU> other;
    };

    template <class _TypeU>
    static_allocator (const static_allocator<_TypeU>&) { }

    template <class _TypeU>
    static_allocator&
    operator= (const static_allocator<_TypeU>&)
    { 
        return *this; 
    }

    pointer address (reference __x) const
    { 
        return &__x; 
    }

    const_pointer address (const_reference __x) const
    { 
        return &__x;
    }

    size_t calc_alignemnt( )
    {
        size_t sz = sizeof(value_type);
        if (sz < 2)
            return 1;
        else if (sz < 4)
            return 2;
        else if (sz < 8)
            return 4;
        else if (sz < 16)
            return 8;
        return 16;
    }

    pointer allocate (size_type n, allocator<void>::const_pointer hint = 0)
    {
        pointer p = (pointer)globalStaticMemoryPool->allocateMemoryBlock( n * sizeof (value_type), calc_alignemnt() );
        UMBA_ASSERT(p!=0);
        return p;
    }

    void deallocate (pointer p, size_type n)
    {
        // deallocation not allowed (container capacity can not be modified)
        //UMBA_ASSERT_FAIL();
        globalStaticMemoryPool->deallocateMemoryBlock( (umba::memory::RawMemPtr)p );
    }

    // 20.4.1.1, p11 - the largest N for which allocate (N) might succeed
    size_type max_size () const 
    { 
        if (size_type (~0) / sizeof (value_type))
            return size_type (size_type (~0) / sizeof (value_type));
        else 
            return size_type (1);
    }

    void construct (pointer p, const_reference val)
    {
        ::new (p) value_type (val);
    }
    
    void destroy (pointer p)
    {
        (*p).~value_type();
    }

}; // struct static_allocator


} // namespace umba



