/*! \file
\brief Определения классов - пулов памяти для работы с динамической памятью

*/

#pragma once

#include "umba/i_memory_pool.h"
#include "umba/bits.h"
#include "containers/static_list.h"


//#define UMBA_MEMORY_POOL_LOW_MEM_EXTRIMELY


#if !defined(UMBA_MPOOL_NDEBUG)

    #if defined(NDEBUG)
        #define UMBA_MPOOL_NDEBUG
    #endif

    #if defined(UMBA_MEMORY_POOL_LOW_MEM_EXTRIMELY) || defined(UMBA_MEMORY_POOL_LOW_MEM)
        #define UMBA_MPOOL_NDEBUG
    #endif

#endif



// 0xDEFEC8ED 0xBADC0C0A
#define UMBA_MEMORY_POOL_CHUNKINFO_FILLING_VAL 0x0A0CDCBAEDC8FEDEull 
//#define UMBA_MEMORY_POOL_MEM_FILL_SIGNATURE    0xBAADF00Dul // seen as 0DF0ADBA
#define UMBA_MEMORY_POOL_MEM_FILL_SIGNATURE    0x0DF0ADBA     // seen as BAADF00Dul
//#define UMBA_MEMORY_POOL_MEM_FILL_SIGNATURE    0xBDBDBDBDul




namespace umba
{
namespace memory
{


#include "umba/pushpack1.h"
struct GrowingMemoryPoolChunkInfo
{
    RawMemPtr       chunkPrevHead; // 4\8
    size_t          chunkSize;     // 4\8

    #if defined(_WIN64)
        constexpr static size_t alignment = 8;
    #else
        constexpr static size_t alignment = 4;
    #endif

    // 8\16

    #if !defined(UMBA_MPOOL_NDEBUG)

        #if !defined(_WIN64) /*sizeof(uintptr_t)<8*/
            uint64_t    fill    = UMBA_MEMORY_POOL_CHUNKINFO_FILLING_VAL; // 8
        #else
            uint64_t    fill[2] = { UMBA_MEMORY_POOL_CHUNKINFO_FILLING_VAL, UMBA_MEMORY_POOL_CHUNKINFO_FILLING_VAL }; // 16
        #endif

    #endif

    // 16\32

};
#include "umba/packpop.h"



namespace memory_pool_impl
{


    #if defined(_WIN64)
        constexpr static size_t min_alignment          =  8;
        constexpr static size_t default_alignment      = 16;
    #else
        constexpr static size_t min_alignment          =  8;
        constexpr static size_t default_alignment      =  8;
    #endif

    #if defined( UMBA_MEMORY_POOL_LOW_MEM_EXTRIMELY)
        constexpr static size_t nice_block_alignment   =  8;
    #elif defined(UMBA_MEMORY_POOL_LOW_MEM)
        constexpr static const size_t nice_block_alignment =  64;
    #else
        constexpr static size_t nice_block_alignment   = 256;
    #endif

    constexpr static size_t max_alignment              = 256;

    inline
    uintptr_t align_impl( uintptr_t val, size_t alignment = default_alignment )
    {
        const uintptr_t alignMask  = (uintptr_t)(alignment - 1);
        uintptr_t valAligned       = val & (uintptr_t)~alignMask;

        if (valAligned!=val)
        {
            valAligned += (uintptr_t)alignment;
        }

        return valAligned;
    }

    inline
    void* align_addr( void* pAddr, size_t alignment = default_alignment )
    {
        return (void*)align_impl( (uintptr_t)pAddr, alignment );
    }

    inline
    size_t align_size( size_t sz, size_t alignment = default_alignment )
    {
        return (size_t)align_impl( (size_t)sz, alignment );
    }

    inline
    size_t adjustAlignment( size_t alignment )
    {
        if (!alignment)
            alignment = default_alignment;

        if (alignment<min_alignment)
            alignment = min_alignment;

        if (alignment > max_alignment)
            alignment = max_alignment;

        UMBA_ASSERT( umba::bits::getSetCount( alignment ) == 1 );

        return alignment;
    }

    inline
    size_t calcNiceBlockSize( IMemoryPool::ByteMemPtr curHead, size_t requestFor, size_t alignment )
    {
        alignment = adjustAlignment(alignment);
       
        const size_t chunkInfoSize = align_size( sizeof(GrowingMemoryPoolChunkInfo), GrowingMemoryPoolChunkInfo::alignment );
        //getChunkInfoSize();
        const IMemoryPool::ByteMemPtr returnPtrCandidate     = curHead + chunkInfoSize;
        const IMemoryPool::ByteMemPtr returnPtr              = (IMemoryPool::ByteMemPtr)align_addr( (void*)returnPtrCandidate, alignment );
        const IMemoryPool::ByteMemPtr nextReturnCandidatePtr = returnPtr + requestFor + chunkInfoSize; // add next chunk info size
        const IMemoryPool::ByteMemPtr nextReturnPtr          = (IMemoryPool::ByteMemPtr)align_addr( (void*)nextReturnCandidatePtr, nice_block_alignment );
        
        return nextReturnPtr - returnPtr - chunkInfoSize;
    }

    #ifdef _MSC_VER
    #pragma warning( push  )  
    //#pragma warning( disable : 4334 )  
    #endif
    inline
    size_t calulatePoolIndex( size_t nBytes, size_t *pBlockSize, size_t intervalNumChunks = 4, size_t chunkStartSize = 8 )
    {
        size_t X = nBytes;

        const size_t one = 1;
        size_t pwrNumChunks = umba::bits::getLog2(intervalNumChunks);
        size_t numChunks = one << pwrNumChunks;

        size_t pwrChunkStartSize = umba::bits::getLog2(chunkStartSize);
        chunkStartSize = one << pwrChunkStartSize;

        size_t pwrOffset = pwrNumChunks + pwrChunkStartSize;
        size_t pwrX = umba::bits::getLog2(X);
        size_t valueOffset = one << pwrOffset;

        if (X <= valueOffset)
        {
            size_t idx = (X-one) >> pwrChunkStartSize;
            if (pBlockSize)
                *pBlockSize = (idx+one)*chunkStartSize;
            return idx;
            //lout << "X: " << X << ", pwrX: " << pwrX << ", pwrOffset: " << pwrOffset << ", valueOffset: " << valueOffset << ", idx: " << idx << ", chunkSize: " << (idx+1)*chunkStartSize << endl;
        }
        else
        {
            const size_t pwrXm1 = pwrX - one;
            const size_t chunkSizeStep = one << (pwrX - pwrNumChunks - one);
            const size_t lowPartX = one << pwrXm1;
            const size_t Xmod = X - lowPartX;
            const size_t pwrChunkSizeStep = umba::bits::getLog2(chunkSizeStep);
            const size_t idx = (Xmod - one ) >> pwrChunkSizeStep;
            if (pBlockSize)
                *pBlockSize = (one << pwrXm1) + (idx+one)*chunkSizeStep;
            return idx + (pwrX - pwrOffset)*numChunks;
        }
    
    }
    #ifdef _MSC_VER
    #pragma warning( pop )  
    #endif
    

} // namespace memory_pool_impl




// 0xBAADF00D
// DEFECA7E или же DEFEC8 0xDEFEC8ED 0xBADC0C0A
// 0xBAADF00D BeefEater waiting on 0xdeadbeef BEEF EA7E EA7 DEAD BEAF ABADBABE 

 
//-----------------------------------------------------------------------------
//! Растущий пул - умеет только откусывать память от управляемого им куска, никогда не освобождая её (количество выделенной в пуле памяти растет)
class GrowingMemoryPool : UMBA_IMPLEMENTS IMemoryPool
{

public:

    //UMBA_BEGIN_INTERFACE_MAP_EX(IMemoryPool)
    UMBA_BEGIN_INTERFACE_MAP()
        UMBA_IMPLEMENT_INTERFACE(IMemoryPool)
    UMBA_END_INTERFACE_MAP()

    GrowingMemoryPool(RawMemPtr pMemChunk, size_t memChunkSize);


    virtual
    size_t queryOptimalAllocationSize( size_t requestFor, size_t alignment ) override;

    virtual
    RawMemPtr allocateMemoryBlock(size_t numBytes, size_t alignment) override;

    virtual
    bool deallocateMemoryBlock(RawMemPtr memPtr) override;

    virtual
    bool expandMemoryBlock(RawMemPtr memPtr, size_t numBytesNew) override;

    virtual
    bool checkMemoryBlockOnwnership(RawMemPtr memPtr) override;

private:

    bool canDeallocate( ByteMemPtr pChunk, GrowingMemoryPoolChunkInfo *pChunkInfo ) const;
    void restoreHead( ByteMemPtr pChunk, GrowingMemoryPoolChunkInfo *pChunkInfo );
    void fillDebugSignature( ByteMemPtr pMem, size_t memSize) const
    {
        #if !defined(UMBA_MPOOL_NDEBUG)
        uint32_t *pDW = (uint32_t*)pMem;
        size_t nFills = memSize / sizeof(uint32_t);
        for(size_t i=0; i!=nFills; ++i, ++pDW)
            *pDW = UMBA_MEMORY_POOL_MEM_FILL_SIGNATURE;
        #endif
    }

    size_t getChunkInfoSize() const
    {
        return memory_pool_impl::align_size( sizeof(GrowingMemoryPoolChunkInfo), GrowingMemoryPoolChunkInfo::alignment );
    }

    ByteMemPtr     m_pOrgMemChunk;
    size_t         m_orgMemChunkSize;
    ByteMemPtr     m_pMemChunk;
    size_t         m_memChunkSize;

}; // class GrowingMemoryPool


class DynamicMemoryPool;

//-----------------------------------------------------------------------------
//! Выделение памяти кусками фиксированного размера
class FixedSizeMemoryPool : UMBA_IMPLEMENTS IMemoryPool
{

public:

    friend class DynamicMemoryPool;

    #if defined(UMBA_MCU_USED)
        typedef uint16_t  ElementNumber;
    #else
        typedef size_t    ElementNumber;
    #endif


    UMBA_BEGIN_INTERFACE_MAP()
        UMBA_IMPLEMENT_INTERFACE(IMemoryPool)
    UMBA_END_INTERFACE_MAP()

    FixedSizeMemoryPool(RawMemPtr pMemChunk, size_t memChunkSize, size_t elementSize );

    virtual
    size_t queryOptimalAllocationSize( size_t requestFor, size_t alignment ) override;

    virtual
    RawMemPtr allocateMemoryBlock(size_t numBytes, size_t alignment) override;

    virtual
    bool deallocateMemoryBlock(RawMemPtr memPtr) override;

    virtual
    bool expandMemoryBlock(RawMemPtr memPtr, size_t numBytesNew) override;

    virtual
    bool checkMemoryBlockOnwnership(RawMemPtr memPtr) override;

private:

    RawMemPtr      getItemRawPtr( ElementNumber itemNo );
    ElementNumber* getItemPtr( ElementNumber itemNo );

    ElementNumber  getItemIndex( RawMemPtr );


    ByteMemPtr     m_pMemChunk;
    size_t         m_memChunkSize;
    size_t         m_elementSize;

    ElementNumber  m_firstAvail;
    ElementNumber  m_availCount;
    ElementNumber  m_maxNumUsed   ; // collect usage stat

    FixedSizeMemoryPool* m_pNextPool;

    bool isEmpty() const
    {
        return m_availCount == ( (ElementNumber)(m_memChunkSize/m_elementSize) );
    }

}; // class FixedSizeMemoryPool



//-----------------------------------------------------------------------------
//! Пул динамической памяти
class DynamicMemoryPool : UMBA_IMPLEMENTS IMemoryPool
{

public:

    UMBA_BEGIN_INTERFACE_MAP()
        UMBA_IMPLEMENT_INTERFACE(IMemoryPool)
    UMBA_END_INTERFACE_MAP()

    DynamicMemoryPool();

    virtual
    size_t queryOptimalAllocationSize( size_t requestFor, size_t alignment );

    virtual
    RawMemPtr allocateMemoryBlock(size_t numBytes, size_t alignment) override;

    virtual
    bool deallocateMemoryBlock(RawMemPtr memPtr) override;

    virtual
    bool expandMemoryBlock(RawMemPtr memPtr, size_t numBytesNew) override;

    virtual
    bool checkMemoryBlockOnwnership(RawMemPtr memPtr) override;

private:

    void initPoolSizes() const;

    constexpr static size_t intervalNumberOfChunksInLevel =  4;

    #if defined( UMBA_MEMORY_POOL_LOW_MEM_EXTRIMELY)
        constexpr static size_t numberOfPools                =   3;
        constexpr static size_t chunkBasicSize               =  16;
        constexpr static size_t numberOfLargeBlocks          =   8;
    #elif defined(UMBA_MEMORY_POOL_LOW_MEM)             
        constexpr static size_t numberOfPools                =   8;
        constexpr static size_t chunkBasicSize               =   8;
        constexpr static size_t numberOfLargeBlocks          =  16;
    #else                                               
        #if defined(_WIN32)
            constexpr static size_t numberOfPools            =  16;
            constexpr static size_t chunkBasicSize           =   8;
            constexpr static size_t numberOfLargeBlocks      =  32;
        #else
            constexpr static size_t numberOfPools            =  16;
            constexpr static size_t chunkBasicSize           =   8;
            constexpr static size_t numberOfLargeBlocks      =  32;
        #endif
    #endif

    size_t calulatePoolIndex( size_t nBytes, size_t *pBlockSize )
    {
        return umba::memory::memory_pool_impl::calulatePoolIndex( nBytes, pBlockSize, intervalNumberOfChunksInLevel, chunkBasicSize );
    }

    FixedSizeMemoryPool* allocatePool( size_t numBytes, size_t blockSize );
    void deallocatePool( FixedSizeMemoryPool* pPool );
    RawMemPtr allocateFromPool( size_t poolIdx, size_t blockSize, FixedSizeMemoryPool* pPool, size_t numBytes, FixedSizeMemoryPool ** ppNewPool );
    RawMemPtr allocateBlockFromList( size_t numBytes, size_t alignment );
    RawMemPtr allocateBlock( size_t numBytes, size_t alignment );
    bool deallocateBlock( RawMemPtr pBlock );
    bool freeBlockList();


    struct BlocksListItem
    {
       BlocksListItem   *pNextItem;
       ByteMemPtr       pBlock;

    }; // struct BlocksListItem

    BlocksListItem* allocateBlocksListItem();
    void deallocateBlocksListItem( BlocksListItem* pItem );


    //typedef umba::static_list< ByteMemPtr, uint16_t > FreeLargeBlocksList;
    //typedef umba::static_list< uintptr_t, uint16_t > FreeLargeBlocksList;

    //FreeLargeBlocksList   m_freeLargeBlocks;
    FixedSizeMemoryPool*      m_fixedPools[numberOfPools]; 
    FixedSizeMemoryPool*      freeBlocksListItemsPool;

    // Храним по уменьшению адресов - 
    // при помещении в список находим подходящуу позицию, 
    // при освобождении начинаем особождать с головы
    BlocksListItem       *m_pHeadFreeBlocks;
    BlocksListItem       *m_pTailFreeBlocks;



}; // class DynamicMemoryPool




namespace memory_pool_impl
{

    inline
    size_t calcGrowingPoolServicePayload()
    {
        return align_size( sizeof(GrowingMemoryPoolChunkInfo), GrowingMemoryPoolChunkInfo::alignment );
    }

    inline
    size_t calcFixedPoolObjectSizePayload()
    {
        return align_size( sizeof(FixedSizeMemoryPool), default_alignment );
    }

    // Память организована следующим образом
    // есть массив указателей на FixedSizeMemoryPool - 
    // пулы, которые выделяют блоки фиксированного размера.
    // Это на самом деле списки пулов - когда все пулы заданного размера заняты,
    // происходит следующее: 1) выделяется память и в ней создается еще один объект пула;
    // 2) выделяется память, которой будет управлять пул
    // На выделение в глобальном пуле тратится место на служебную информацию, а также память, 
    // которая идет под объект пула, тоже является служебной.
    // Подсчет размера служебной информации нужен для того, чтобы рациональнее расходовать память - 
    // если выделяем пулы для нескольких небольших элементов, то служебные расходы могут превышать 
    // объем полезной памяти, что не есть хорошо
    // Итого служебных расходов - 2 выделения в глобальном пуле и размер объекта пула
    
    inline
    size_t calcSingleFixedPoolServicePayload()
    {
        return 2 * calcGrowingPoolServicePayload()
                 + calcFixedPoolObjectSizePayload();
    }





} // namespace memory_pool_impl
}; // namespace memory
}; // namespace umba



#define UMBA_MEM_POOL_FIXED_POOL_ALLOC_SIZE_CALCULATOR( itemSize, numItemsToAlloc )  \
                      (                                                              \
                        (((itemSize) * (numItemsToAlloc) % sizeof(uint64_t)) != 0)   \
                      ? (((itemSize) * (numItemsToAlloc) / sizeof(uint64_t)) + 1)    \
                      : ( (itemSize) * (numItemsToAlloc) / sizeof(uint64_t))         \
                      )

#define UMBA_MEM_POOL_FIXED_POOL_ALLOCATE_STATIC_RAW_MEM(rawBufName, itemSize, numItemsToAlloc) \
                      static uint64_t rawBufName[ UMBA_MEM_POOL_FIXED_POOL_ALLOC_SIZE_CALCULATOR(itemSize, numItemsToAlloc) ]

#define UMBA_MEM_POOL_FIXED_POOL_ALLOCATE_STATIC_RAW_MEM_SIMPLE(rawBufName, sizeInBytes)        \
                      static uint64_t rawBufName[ UMBA_MEM_POOL_FIXED_POOL_ALLOC_SIZE_CALCULATOR( 1, sizeInBytes) ]


