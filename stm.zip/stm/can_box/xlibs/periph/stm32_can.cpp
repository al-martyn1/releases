#include "umba/umba.h"
#include "mcu.h"
#include "stm32_traits.h"


//UMBA_IRQ_HANDLER( EXTI2_IRQHandler );

//umba::periph::traits

#if !defined(NO_CAN_IRQ_HANDLERS)

    #if defined(STM32F1_SERIES)
    
        #if defined(CAN1) && defined(USE_CAN1)
    
            #if !defined(STM32F10X_CL)
                UMBA_IRQ_HANDLER(USB_HP_CAN1_TX_IRQHandler) // F3 - USB_HP_CAN_TX_IRQHandler
            #else
                UMBA_IRQ_HANDLER(CAN1_TX_IRQHandler)
            #endif
            {
                if (umba::periph::traits::handleCanTxInterrupt( CAN1, umba::periph::traits::canGetIrqHandler(CAN1) ) )
                    return;
            }
           
            #if !defined(STM32F10X_CL)
                UMBA_IRQ_HANDLER(USB_LP_CAN1_RX0_IRQHandler) // F3 USB_LP_CAN_RX0_IRQHandler
            #else
                UMBA_IRQ_HANDLER(CAN1_RX0_IRQHandler)
            #endif
            {
                if (umba::periph::traits::handleCanFifoInterrupt( CAN1, CAN1->RF0R, 0, umba::periph::traits::canGetIrqHandler(CAN1) ) )
                    return;
            }
           
            UMBA_IRQ_HANDLER(CAN1_RX1_IRQHandler)
            {
                if (umba::periph::traits::handleCanFifoInterrupt( CAN1, CAN1->RF1R, 1, umba::periph::traits::canGetIrqHandler(CAN1) ) )
                    return;
            }
           
            UMBA_IRQ_HANDLER(CAN1_SCE_IRQHandler)
            {
                if (umba::periph::traits::handleCanErrorInterrupt( CAN1, umba::periph::traits::canGetIrqHandler(CAN1) ) )
                    return;
            }
    
        #endif   
    
        #if defined(CAN2) && defined(USE_CAN2)
    
            UMBA_IRQ_HANDLER(CAN2_TX_IRQHandler)
            {
                if (umba::periph::traits::handleCanTxInterrupt( CAN2, umba::periph::traits::canGetIrqHandler(CAN2) ) )
                    return;
            }
           
            UMBA_IRQ_HANDLER(CAN2_RX0_IRQHandler)
            {
                if (umba::periph::traits::handleCanFifoInterrupt( CAN2, CAN2->RF0R, 0, umba::periph::traits::canGetIrqHandler(CAN2) ) )
                    return;
            }
           
            UMBA_IRQ_HANDLER(CAN2_RX1_IRQHandler)
            {
                if (umba::periph::traits::handleCanFifoInterrupt( CAN2, CAN2->RF1R, 1, umba::periph::traits::canGetIrqHandler(CAN2) ) )
                    return;
            }
           
            UMBA_IRQ_HANDLER(CAN2_SCE_IRQHandler)
            {
                if (umba::periph::traits::handleCanErrorInterrupt( CAN2, umba::periph::traits::canGetIrqHandler(CAN2) ) )
                    return;
            }
    
        #endif
    
    #elif defined(STM32F3_SERIES)
    
        #if defined(CAN1) && defined(USE_CAN1)
    
            UMBA_IRQ_HANDLER(USB_HP_CAN_TX_IRQHandler )
            {
                if (umba::periph::traits::handleCanTxInterrupt( CAN1, umba::periph::traits::canGetIrqHandler(CAN1) ) )
                    return;
            }
           
            UMBA_IRQ_HANDLER(USB_LP_CAN_RX0_IRQHandler)
            {
                if (umba::periph::traits::handleCanFifoInterrupt( CAN1, CAN1->RF0R, 0, umba::periph::traits::canGetIrqHandler(CAN1) ) )
                    return;
            }
           
            UMBA_IRQ_HANDLER(CAN_RX1_IRQHandler       )
            {
                if (umba::periph::traits::handleCanFifoInterrupt( CAN1, CAN1->RF1R, 1, umba::periph::traits::canGetIrqHandler(CAN1) ) )
                    return;
            }
           
            UMBA_IRQ_HANDLER(CAN_SCE_IRQHandler       )
            {
                if (umba::periph::traits::handleCanErrorInterrupt( CAN1, umba::periph::traits::canGetIrqHandler(CAN1) ) )
                    return;
            }
    
        #endif
    
        //UMBA_IRQ_HANDLER()
     
    #elif defined(STM32F4_SERIES)
     
        #if defined(CAN1) && defined(USE_CAN1)
     
            UMBA_IRQ_HANDLER(CAN1_TX_IRQHandler )
            {
                if (umba::periph::traits::handleCanTxInterrupt( CAN1, umba::periph::traits::canGetIrqHandler(CAN1) ) )
                    return;
            }
           
            UMBA_IRQ_HANDLER(CAN1_RX0_IRQHandler)
            {
                if (umba::periph::traits::handleCanFifoInterrupt( CAN1, CAN1->RF0R, 0, umba::periph::traits::canGetIrqHandler(CAN1) ) )
                    return;
            }
           
            UMBA_IRQ_HANDLER(CAN1_RX1_IRQHandler)
            {
                if (umba::periph::traits::handleCanFifoInterrupt( CAN1, CAN1->RF1R, 1, umba::periph::traits::canGetIrqHandler(CAN1) ) )
                    return;
            }
           
            UMBA_IRQ_HANDLER(CAN1_SCE_IRQHandler)
            {
                if (umba::periph::traits::handleCanErrorInterrupt( CAN1, umba::periph::traits::canGetIrqHandler(CAN1) ) )
                    return;
            }
           
        #endif
     
        #if defined(CAN2) && defined(USE_CAN2)
            
            UMBA_IRQ_HANDLER(CAN2_TX_IRQHandler )
            {
                if (umba::periph::traits::handleCanTxInterrupt( CAN2, umba::periph::traits::canGetIrqHandler(CAN2) ) )
                    return;
            }
           
            UMBA_IRQ_HANDLER(CAN2_RX0_IRQHandler)
            {
                if (umba::periph::traits::handleCanFifoInterrupt( CAN2, CAN2->RF0R, 0, umba::periph::traits::canGetIrqHandler(CAN2) ) )
                    return;
            }
           
            UMBA_IRQ_HANDLER(CAN2_RX1_IRQHandler)
            {
                if (umba::periph::traits::handleCanFifoInterrupt( CAN2, CAN2->RF1R, 1, umba::periph::traits::canGetIrqHandler(CAN2) ) )
                    return;
            }
           
            UMBA_IRQ_HANDLER(CAN2_SCE_IRQHandler)
            {
                if (umba::periph::traits::handleCanErrorInterrupt( CAN1, umba::periph::traits::canGetIrqHandler(CAN1) ) )
                    return;
            }
     
        #endif
     
    #else

    #endif

#endif // NO_CAN_IRQ_HANDLERS




namespace umba
{
namespace periph
{
namespace traits
{



} // namespace traits
} // namespace periph
} // namespace umba

