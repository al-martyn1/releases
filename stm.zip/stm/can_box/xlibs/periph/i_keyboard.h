#pragma once

#include "umba/umba.h"
#include "umba/interface.h"
#include "umba/time_service.h"
#include "vgpio/i_virtual_gpio.h"

#include <stdint.h>


namespace umba
{

namespace periph
{


enum class KeyState
{
	released  = 0,
	pressing  = 1,
	releasing = 2,
	pressed   = 3
};



using TimeTick = umba::time_service::TimeTick;


struct KeyPressState
{
	KeyState    keyState;
	TimeTick    keyTick;
	size_t      repeatCount;
};


struct KeyboardTimeouts
{
	TimeTick     antiBounceTimeout       =  10;
	TimeTick     firstRepetitionTimeout  =  300;
	TimeTick     repetitionTimeout       =  150;

};


UMBA_INTERFACE IKeyboardHandler
{
    virtual
    void onKeyPress( unsigned vkc, bool fPressed, size_t repeatCout ) = 0;

}; // interface IKeyboardHandler



UMBA_INTERFACE IKeyboard
{
    virtual
    void setHandler( IKeyboardHandler *pHandler ) = 0;

    virtual
    IKeyboardHandler* getHandler( ) = 0;

	virtual 
    void scanKeyboard() = 0;

	virtual 
    bool getKeyState( unsigned vkc ) = 0;

}; // interface IKeyboard





UMBA_INTERFACE IGpioKeyboard : public IKeyboard
{

    virtual 
    void setRowOutputPort( umba::virtual_gpio::IOutputPort* pRowOutputPort ) = 0;

    virtual 
    umba::virtual_gpio::IOutputPort* getRowOutputPort( ) = 0;


    virtual 
    void setColInputPort( umba::virtual_gpio::IInputPort* pColInputPort ) = 0;

    virtual 
    umba::virtual_gpio::IInputPort* getColInputPort( ) = 0;


	virtual 
    void setTimeouts( const KeyboardTimeouts &keyboardTimeouts) = 0;

	virtual 
    void setTimeouts( uint32_t antiBounceTimeout, uint32_t firstRepetitionTimeout, uint32_t repetitionTimeout ) = 0;

	virtual 
    KeyboardTimeouts getTimeouts( ) = 0;


}; // interface IKeyboard



template< typename TLambda >
class GenericKeyboardHandler : public IKeyboardHandler
{

public:

    GenericKeyboardHandler( TLambda l ) : IKeyboardHandler(), m_lambda(l) {}
    GenericKeyboardHandler( const GenericKeyboardHandler &h ) : IKeyboardHandler(), m_lambda(h.m_lambda) {}

    virtual
    void onKeyPress( unsigned vkc, bool fPressed, size_t repeatCout ) override
    {
        m_lambda( vkc, fPressed, repeatCout );
    }

protected:

    TLambda m_lambda;

}; // GenericKeyboardHandler



template< typename TLambda >
GenericKeyboardHandler< TLambda > makeKeyboardHandler( TLambda l )
{
    return GenericKeyboardHandler< TLambda >(l);
}



} // namespace periph


} // namespace umba

