#pragma once


// Подключаем ручками после включения заголовочных файлов MCU

// http://we.easyelectronics.ru/STM32/stm32---bit-banding.html
// http://we.easyelectronics.ru/STM32/atomarnyy-dostup-k-bitam-registrov-bit-band-cherez-makros.html
// http://infocenter.arm.com/help/index.jsp?topic=/com.arm.doc.faqs/ka4203.html

// wordType - тип слова, для STM - uint32_t
#define UMBA_BITBANG_IMPL( addr, bitNo, addrBase, bbBase, wordType )     (volatile wordType *)(((bbBase) + (((wordType)addr)-(addrBase))*(sizeof(wordType)*8) + (bitNo)*sizeof(wordType)))


#ifdef SRAM_BB_ASE

    #define  UMBA_BB_SRAM( sramAddr, bitNo )        UMBA_BITBANG_IMPL( sramAddr, bitNo, SRAM_BASE, SRAM_BB_BASE, uint32_t )

#endif


#ifdef PERIPH_BASE

    #define  UMBA_BB_PERIPH( periphAddr, bitNo )    UMBA_BITBANG_IMPL( periphAddr, bitNo, PERIPH_BASE, PERIPH_BB_BASE, uint32_t )

#endif

