/**************************************************************************************************
**************************************************************************************************/
#include "soft_i2c.h"
//#include "mcu_configuration.h"
#include "umba/time_service.h"

// umba::periph::soft::

namespace umba
{
namespace periph
{
namespace soft
{


bool SoftI2c::start( void )
{
    sda_set();

    I2C_delay();

    if (!scl_set())
        return false;
        
    I2C_delay();

    if ( !m_sda.getInput() )
        return false;

    sda_reset();
    I2C_delay();
    if ( m_sda.getInput() )
        return false;

    //sda_reset(); // ??? - ���� ��� � ����, ����� ���?
    scl_reset();   // clock - � 0, ��� ��� ������ - �� ������ clock'�

    // I2C_delay();

    return true;
}


void SoftI2c::stop( void )
{
    scl_reset();
    I2C_delay();

    sda_reset();
    I2C_delay();

    scl_set();
    I2C_delay();

    sda_set();
    I2C_delay();

}

void SoftI2c::ack( void )
{
    scl_reset();
    I2C_delay();

    sda_reset();
    I2C_delay();

    scl_set();
    I2C_delay();

    scl_reset();
    I2C_delay();
}

void SoftI2c::nack( void )
{
    scl_reset();
    I2C_delay();

    sda_set();
    I2C_delay();

    scl_set();
    I2C_delay();

    scl_reset();
    I2C_delay();
}

bool SoftI2c::waitAck( void )
{
    scl_reset();
    I2C_delay();

    sda_set();
    I2C_delay();

    scl_set();
    I2C_delay();

    if(m_sda.getInput())
    {
        scl_reset();
        return false;
    }

    scl_reset();

    return true;
}


bool SoftI2c::writeBit(bool bit)
{
    if (bit)
    {
        sda_set();
    }
    else
    {
        sda_reset();
    }

    // SDA change propagation delay
    I2C_delay();

    // Set SCL high to indicate a new valid SDA value is available
    //scl_set();
    m_scl.set();

    // Wait for SDA value to be read by slave, minimum of 4us for standard mode
    I2C_delay();

    if (!scl_wait_for( true ))
        return false;

    // SCL is high, now data is valid
    // If SDA is high, check that nobody else is driving SDA
    if (bit && m_sda.getInput()==false)
        return false;

    // Clear the SCL to low in preparation for next change
    scl_reset();
    return true;
}

bool SoftI2c::sendByte( uint8_t byte )
{
    uint8_t i = 8;

    while(i--)
    {
        if (!writeBit( (byte & 0x80) ? true : false ) )
            return false;

        byte <<= 1;

        /*
        scl_reset();
        I2C_delay();

        if( byte & 0x80 )
        {
            sda_set();
        }
        else
        {
            sda_reset();
        }

        byte <<= 1;
        I2C_delay();

        scl_set();
        I2C_delay();
        */
    }

    //scl_reset();
    return true;
}

uint8_t SoftI2c::receiveByte( void )
{
    uint8_t i = 8;
    uint8_t byte = 0;

    sda_set();
    while ( i-- )
    {
        byte <<= 1;
        scl_reset();
        I2C_delay();

        scl_set();
        I2C_delay();

        if( m_sda.getInput() )
        {
            byte|=0x01;
        }
    }

    scl_reset();

    return byte;
}

bool SoftI2c::sendByte_pause_waitAck( uint8_t byte, uint32_t delay )
{
    sendByte( byte );

    for( volatile uint32_t i=0; i<delay; i++) {}

    auto r = waitAck();
    
    pause( 30*m_half_bit_timeout );

    return r;
}

bool SoftI2c::sendByteWaitAck( uint8_t byte )
{
    sendByte( byte );
    //I2C_delay();
    return waitAck();
}

void SoftI2c::pause( uint32_t bogoticks )
{
    for( volatile uint32_t i=0; i<bogoticks; i++)
    {
        ;
    }
}

void SoftI2c::I2C_delay( void )
{
    volatile unsigned int i = m_half_bit_timeout;

    while ( i )
    {
        i--;
    }
}

bool SoftI2c::readFrom( uint8_t addr, uint8_t *pData, size_t numBytes )
{
    auto r = start();
    
    if( r == false )
    {
        stop();
        return false;
    }

    // dev addr
    sendByte( (addr<<1) | 1 );
    r = waitAck();
    
    if( r == false )
    {
        stop();
        return false;
    }

    while (numBytes-- > 1)
    {
      *(pData) = receiveByte();
      pData++;
      ack();
    }
    
    *(pData) = receiveByte();
    nack();

    stop();

    return true;
}

bool SoftI2c::writeTo( uint8_t addr, const uint8_t *pData, size_t numBytes )
{
    auto r = start();
    
    if( r == false )
    {
        stop();
        return false;
    }

    // dev addr
    //sendByte( (addr<<1) /*| 1*/ );
    //r = waitAck();
    r = sendByteWaitAck( (addr<<1) /*| 1*/ );

    if( r == false )
    {
        stop();
        return false;
    }

    for( size_t i = 0; i!= numBytes; ++i, ++pData)
    {
        //I2C_delay();
        if (!sendByteWaitAck( *pData ))
        {
            stop();
            return false;
        }
    }

    stop();

    return true;
}



} // namespace soft
} // namespace periph
} // namespace umba


