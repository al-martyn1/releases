#pragma once

#include "umba/umba.h"
//#include "umba_gpio_pin.h"
//#include "soft_timer.h"
#include "periph/gpio.h"


// umba::periph::soft::

namespace umba
{
namespace periph
{
namespace soft
{


class SoftI2c
{

public:

    //using GpioPin = umba::GpioPin;



/*
enum class PinMode
{
    analog_in,         //<! 0x00 Аналоговый вход
    gpio_in_floating,  //<! 0x01 Вход без подтяжки, болтающийся (англ. float) в воздухе
    gpio_in_pulldown,  //<! 0x02 Вход с подтяжкой к земле (англ. Pull-down)
    gpio_in_pullup,    //<! 0x03 Вход с подтяжкой к питанию (англ. Pull-up)
    gpio_out_od,       //<! 0x04 Выход с открытым стоком (англ. Open Drain)
    gpio_out_pp,       //<! 0x05 Выход двумя состояниями (англ. Push-Pull — туда-сюда)
    alt_mode_od,       //<! 0x06 Выход для альтернативных функций с открытым стоком
    alt_mode_pp        //<! 0x07 Выход для альтернативных функций с двумя состояниями
};

*/

    //SoftI2c( const GpioPin & sda, const GpioPin & scl, uint32_t half_bit_timeout = 15 ) :
    SoftI2c( const umba::periph::GpioPinAddr & sdaPinAddr
           , const umba::periph::GpioPinAddr & sclPinAddr
           , uint32_t half_bit_timeout = 15 )
      : m_sda( sdaPinAddr, umba::periph:: /* traits:: */ PinMode::gpio_out_od )
      , m_scl( sclPinAddr, umba::periph:: /* traits:: */ PinMode::gpio_out_od )
      , m_half_bit_timeout( half_bit_timeout )
    {
    }

    SoftI2c( uint32_t half_bit_timeout )
      : m_sda( )
      , m_scl( )
      , m_half_bit_timeout( half_bit_timeout )
    {
    }

    SoftI2c( )
      : m_sda( )
      , m_scl( )
      , m_half_bit_timeout( 15 )
    {
    }

    void setHalfBitTimeout(uint32_t half_bit_timeout)
    {
        m_half_bit_timeout = half_bit_timeout;
    }

    void setAddrs( const umba::periph::GpioPinAddr & sdaPinAddr
                 , const umba::periph::GpioPinAddr & sclPinAddr )
    {
        if (m_sda.isConnected())
            m_sda.shutdown( );
        if (m_scl.isConnected())
            m_scl.shutdown( );

        m_sda.assignAddrAndMode( sdaPinAddr, umba::periph::PinMode::gpio_out_od /* , PinSpeed pinSpeed = PinSpeed::high */  );
        m_scl.assignAddrAndMode( sclPinAddr, umba::periph::PinMode::gpio_out_od /* , PinSpeed pinSpeed = PinSpeed::high */  );
    }

    void init()
    {
        m_scl.connect();
        m_sda.connect();

        m_scl.set();
        m_sda.set();
    }

    bool start();
    void stop();
    void ack();
    void nack();
    bool waitAck();
    bool sendByte( uint8_t byte );
    uint8_t receiveByte();

    void pause( uint32_t bogoticks = 2000 );

    // тщательно подобранная пауза для bq40z50
    bool sendByte_pause_waitAck( uint8_t byte, uint32_t delay = 3000 );

    bool sendByteWaitAck( uint8_t byte );

    bool readFrom( uint8_t addr, uint8_t *pData, size_t numBytes );

    bool writeTo( uint8_t addr, const uint8_t *pData, size_t numBytes );



private:

    void I2C_delay();

    void sda_set()   { m_sda.set(); }
    void sda_reset() { m_sda.reset(); }

    bool scl_wait_for( bool waitFor ) const
    {
        unsigned int i = 100*m_half_bit_timeout;
        while( m_scl.getInput() != waitFor && i) { --i; }
        
        return i ? true : false;
    }

    bool scl_set()
    {
        m_scl.set();

        // ждем, пока нога действительно поднимется
        // потому что может быть clock-stretch
        // while( m_scl.getInput() == false ) {}  // BUG: possible unconditionally lock
     
        
        unsigned int i = 100*m_half_bit_timeout;
        while( m_scl.getInput() == false && i) { --i; }
        
        return i ? true : false;
        

        //return scl_wait_for( true );
    }

    void scl_reset() { m_scl.reset(); }

    bool writeBit(bool bit);


    umba::periph::GpioPin m_sda;
    umba::periph::GpioPin m_scl;

    uint32_t m_half_bit_timeout;
};






} // namespace soft
} // namespace periph
} // namespace umba


