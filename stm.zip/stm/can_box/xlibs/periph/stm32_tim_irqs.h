#pragma once

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif

#include <cstring>

namespace umba
{
namespace periph
{
namespace traits
{

//inline
//void
//TIM_ClearITPendingBit(TIM2, TIM_IT_Update);

// In most cases it is global IRQ
inline
IRQn timerGetIRQn( TIM_TypeDef *pt )
{
    #if defined(STM32F1_SERIES)
        #ifdef TIM1
            if (pt==TIM1) return (IRQn)25; // TIM1_UP_IRQn
        #endif

        #ifdef TIM2
            if (pt==TIM2) return (IRQn)28; // TIM2_IRQn
        #endif

        #ifdef TIM3
            if (pt==TIM3) return (IRQn)29; // TIM3_IRQn
        #endif

        #ifdef TIM4
            if (pt==TIM4) return (IRQn)30; // TIM4_IRQn
        #endif

        #ifdef TIM5
            if (pt==TIM5) return (IRQn)50; // TIM5_IRQn
        #endif

        #ifdef TIM6
            if (pt==TIM6) return (IRQn)54; // TIM6_IRQn / TIM6_DAC_IRQn
        #endif

        #ifdef TIM7
            if (pt==TIM7) return (IRQn)55; // TIM7_IRQn
        #endif

        #ifdef TIM8
            if (pt==TIM8) return (IRQn)44; // TIM8_UP_IRQn // TIM8_UP_TIM13_IRQn
        #endif

        #ifdef TIM12
            if (pt==TIM12) return (IRQn)43; // TIM12_IRQn
        #endif

        #ifdef TIM13
            if (pt==TIM13) return (IRQn)44; // TIM13_IRQn - shared with TIM8
        #endif

        #ifdef TIM14
            if (pt==TIM14) return (IRQn)46; // TIM14_IRQn
        #endif

    #elif defined(STM32F3_SERIES)
    #elif defined(STM32F4_SERIES)
    #endif

    UMBA_ASSERT_FAIL();

    return (IRQn)0;

}

inline
IRQn periphGetIRQn( TIM_TypeDef * tim )
{
    return timerGetIRQn(tim);
}





} // namespace traits
} // namespace periph
} // namespace umba
