

namespace umba{
namespace periph{
namespace traits{



inline
void periphSoftReset( CAN_TypeDef * CANx )
{
    //NOTE what happens with CAN2 when CAN1 going to reset?
    CANx->MCR |= bcCAN_MCR_RESET_SET_MASK;
}


//----------------------------------------------------------------------------
template < > inline
uint32_t periphResetGetFlag<CAN_TypeDef>( CAN_TypeDef * CANx )
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

        #if defined(STM32F3_SERIES) && ( defined(CAN) && (defined(USE_CAN) || defined(USE_CAN1)) )
            if (CANx==CAN)
                return RCC_APB1Periph_CAN1;
        #endif

        #if (defined(CAN1) && defined(USE_CAN1))
            if (CANx==CAN1)
                return RCC_APB1Periph_CAN1;
        #endif

        #if defined(CAN2) && defined(USE_CAN2)
            if (CANx==CAN2)
                return RCC_APB1Periph_CAN2;
        #endif

    #endif

    UMBA_ASSERT_FAIL();

    return 0;
}


#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
    template <>
    inline
    ClockBus periphClockGetBus<CAN_TypeDef>( CAN_TypeDef * pt )
    {
        return ClockBus::APB1;
    }
#endif


#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

    template <>
    inline
    PerifClockFunctionPtr periphClockGetFunction<CAN_TypeDef>( CAN_TypeDef * pt )
    {
        return RCC_APB1PeriphClockCmd;
    }

    template <>
    inline
    uint32_t periphClockGetFlag<CAN_TypeDef>( CAN_TypeDef * pt )
    {
        // USE_CAN1
        #if defined(STM32F3_SERIES) && ( defined(CAN) && (defined(USE_CAN) || defined(USE_CAN1)) )
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( CAN, RCC_APB1Periph_CAN1 );
        #endif

        #if defined(CAN1) && defined(USE_CAN1)
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( CAN1, RCC_APB1Periph_CAN1 );
        #endif

        #if defined(CAN2) && defined(USE_CAN2)
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( CAN2, RCC_APB1Periph_CAN1|RCC_APB1Periph_CAN2 );
        #endif
        //#if defined(CAN3
        //    UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( CAN3, RCC_APB1Periph_CAN3 );
        //#endif

        UMBA_ASSERT_FAIL();

        return 0;
    }

#endif


} // namespace traits
} // namespace periph
} // namespace umba


