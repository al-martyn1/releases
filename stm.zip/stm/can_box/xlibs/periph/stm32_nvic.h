#pragma once

// http://easyelectronics.ru/arm-uchebnyj-kurs-preryvaniya-i-nvic-prioritetnyj-kontroller-preryvanij.html


// NVIC_InitTypeDef NVIC_InitStruct;

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif


namespace umba
{
namespace periph
{
namespace traits
{

inline
void initNvicChannel( IRQn n, unsigned prio, unsigned subPrio, bool enable = true )
{
    NVIC_InitTypeDef  NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = n;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = prio;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = subPrio; // 0x1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = enable ? ENABLE : DISABLE;
    NVIC_Init(&NVIC_InitStructure);
}


// #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)


} // namespace traits
} // namespace periph
} // namespace umba
