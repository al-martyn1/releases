#pragma once

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif

/*
    http://easyelectronics.ru/arm-uchebnyj-kurs-vneshnie-preryvaniya.html
    http://www.count-zero.ru/2016/stm32_gpio/
    https://stm32f4-discovery.net/2014/08/stm32f4-external-interrupts-tutorial/
*/

/*
#define EXTI0_IRQ_HANDLER_NAME         EXTI0_IRQHandler
#define EXTI1_IRQ_HANDLER_NAME         EXTI1_IRQHandler
#define EXTI2_IRQ_HANDLER_NAME         EXTI2_IRQHandler
#define EXTI3_IRQ_HANDLER_NAME         EXTI3_IRQHandler
#define EXTI4_IRQ_HANDLER_NAME         EXTI4_IRQHandler
//#define EXTI9_5_IRQ_HANDLER_NAME       EXTI9_5_IRQHandler
//#define EXTI15_10_IRQ_HANDLER_NAME     EXTI15_10_IRQHandler
#define EXTI5_IRQ_HANDLER_NAME         EXTI5_IRQHandler
#define EXTI6_IRQ_HANDLER_NAME         EXTI6_IRQHandler
#define EXTI7_IRQ_HANDLER_NAME         EXTI7_IRQHandler
#define EXTI8_IRQ_HANDLER_NAME         EXTI8_IRQHandler
#define EXTI9_IRQ_HANDLER_NAME         EXTI9_IRQHandler
#define EXTI10_IRQ_HANDLER_NAME        EXTI10_IRQHandler
#define EXTI11_IRQ_HANDLER_NAME        EXTI11_IRQHandler
#define EXTI12_IRQ_HANDLER_NAME        EXTI12_IRQHandler
#define EXTI13_IRQ_HANDLER_NAME        EXTI13_IRQHandler
#define EXTI14_IRQ_HANDLER_NAME        EXTI14_IRQHandler
#define EXTI15_IRQ_HANDLER_NAME        EXTI15_IRQHandler
*/

// Декларируем обработчики прерываний, и теперь их можно писать без extern "C"
/*
UMBA_IRQ_HANDLER( EXTI0_IRQ_HANDLER_NAME     );
UMBA_IRQ_HANDLER( EXTI1_IRQ_HANDLER_NAME     );
UMBA_IRQ_HANDLER( EXTI2_IRQ_HANDLER_NAME     );
UMBA_IRQ_HANDLER( EXTI3_IRQ_HANDLER_NAME     );
UMBA_IRQ_HANDLER( EXTI4_IRQ_HANDLER_NAME     );
UMBA_IRQ_HANDLER( EXTI5_IRQ_HANDLER_NAME     );
UMBA_IRQ_HANDLER( EXTI6_IRQ_HANDLER_NAME     );
UMBA_IRQ_HANDLER( EXTI7_IRQ_HANDLER_NAME     );
UMBA_IRQ_HANDLER( EXTI8_IRQ_HANDLER_NAME     );
UMBA_IRQ_HANDLER( EXTI9_IRQ_HANDLER_NAME     );
UMBA_IRQ_HANDLER( EXTI10_IRQ_HANDLER_NAME     );
UMBA_IRQ_HANDLER( EXTI11_IRQ_HANDLER_NAME     );
UMBA_IRQ_HANDLER( EXTI12_IRQ_HANDLER_NAME     );
UMBA_IRQ_HANDLER( EXTI13_IRQ_HANDLER_NAME     );
UMBA_IRQ_HANDLER( EXTI14_IRQ_HANDLER_NAME     );
UMBA_IRQ_HANDLER( EXTI15_IRQ_HANDLER_NAME     );
*/

/*

#define UMBA_EXTI_IRQ_HANDLER_BEGIN_IMPL( pinNo )                       \
    extern "C" void EXTI##pinNo##_IRQHandler()                          \
    {                                                                   \
        if (umba::periph::traits::gpioTestPendingEXTI((uint16_t)pinNo)) \
        {

#define UMBA_EXTI_IRQ_HANDLER_END( pinNo )                              \
            umba::periph::traits::gpioClearPendingEXTI((uint16_t)pinNo);\
        }                                                               \
    }

#define UMBA_EXTI_IRQ_HANDLER_BEGIN( pinNo )    UMBA_EXTI_IRQ_HANDLER_BEGIN_IMPL( pinNo )

*/

namespace umba
{
namespace periph
{
namespace traits
{


//---------------------------------------------------------
enum ExtiTrigger
{
    extiTriggerNone     = 0,
    extiTriggerRising   = 1,
    extiTriggerFalling  = 2,
    extiTriggerChange   = 3,
    extiTriggerBoth     = extiTriggerChange

};



#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

    // F1  0x40010400 - 0x400107FF        EXTI Section 10.3.7 on page 214
    // F3  0x40010400 - 0x400107FF   1K   EXTI     Section 14.3.13 on page 303
    // F4  0x40013C00 - 0x40013FFF        EXTI Section 12.3.7: EXTI register map on page 387    

    /*
    typedef struct
    {
      __IO uint32_t IMR;
      __IO uint32_t EMR;
      __IO uint32_t RTSR;
      __IO uint32_t FTSR;
      __IO uint32_t SWIER;
      __IO uint32_t PR;
    } EXTI_Channel_TypeDef;

    typedef EXTI_TypeDef
    {
        #if defined(STM32F1_SERIES) || defined(STM32F4_SERIES)
            EXTI_Channel_TypeDef   exti[1];
        #else
            EXTI_Channel_TypeDef   exti[2];
        #endif
    } EXTI_TypeDef;

    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES)
        const EXTI_TypeDef* EXTI = (EXTI_TypeDef*)(0x40010400);
    #else // F4
        const EXTI_TypeDef* EXTI = (EXTI_TypeDef*)(0x40010400);
    #endif
    */
    
#endif

/*
gpioGetExtiIrqN            extiGpioGetIRQn
gpioInitEXTI               extiGpioInit
gpioGenerateSoftwareEXTI   extiGpioGenerateSoftware
gpioTestPendingEXTI        extiGpioTestPending
gpioClearPendingEXTI       extiGpioClearPending

*/

//---------------------------------------------------------
#ifdef STM32F303xC 
    #define EXTI2_IRQn EXTI2_TS_IRQn
#endif



inline
IRQn gpioGetExtiIrqN( uint16_t pinNo )
{
    UMBA_ASSERT(isValidPinNo(pinNo));
    switch(pinNo)
       {
        case 0:  return EXTI0_IRQn    ;
        case 1:  return EXTI1_IRQn    ;
        //case 2:  return EXTI2_IRQn    ;
        case 3:  return EXTI3_IRQn    ;
        case 4:  return EXTI4_IRQn    ;
        case 5: 
        case 6: 
        case 7: 
        case 8: 
        case 9: 
                 return EXTI9_5_IRQn  ;
        default: return EXTI15_10_IRQn;
       }
}

// 
inline
IRQn periphGetIRQn( GPIO_TypeDef *pGpioDummy, uint16_t pinNo )
{
    return gpioGetExtiIrqN( pinNo );
}


//---------------------------------------------------------
// periphInitIrq
// periphDisableIrq
// periphInstallIrqHandler
// periphUninstallIrqHandler
// periphTestPendingIrq
// periphClearPendingIrq
// periphGenerateSoftwareIrq
//---------------------------------------------------------


//inline
//ExtiHandlerProcT 
//void gpioInitEXTI( GPIO_TypeDef *gpioPort, uint16_t pinNo, ExtiTrigger extiTrigger, PinMode pinMode = PinMode::gpio_in_pullup )

inline
void periphInitIrq( GPIO_TypeDef *gpioPort, uint16_t pinNo, ExtiTrigger extiTrigger, PinMode pinMode = PinMode::gpio_in_pullup )
{
    UMBA_ASSERT( pinMode==PinMode::gpio_in_floating || pinMode==PinMode::gpio_in_pulldown || pinMode==PinMode::gpio_in_pullup );
    UMBA_ASSERT(isValidPinPort(gpioPort));
    UMBA_ASSERT(isValidPinNo(pinNo));

    UMBA_ASSERT( (((uint16_t)extiTrigger) & ((uint16_t)extiTriggerRising)) || (((uint16_t)extiTrigger) & ((uint16_t)extiTriggerFalling)) );

    uint16_t pinMask = 1 << pinNo;

    
    initPeriphClock( SYSCFG, ENABLE );

    gpioInit( gpioPort, PinSpeed::high, pinMode, pinMask ); // GPIO_Pin_X


    // EXTI# == pinNo

    // pinNo: 0x00 - 0x0F
    //        0000 - 1111
    uint16_t regNo  = (pinNo >> 2) & 0x03;
    uint16_t extiNo = (pinNo     ) & 0x03; //    0, 1, 2,  3
                                         // x4 0, 4, 8, 12

    uint16_t extiShift = 4*extiNo;
    // ~(0x0F << extiShift)

    uint16_t portNo = gpioGetPortNo( gpioPort );

    SYSCFG->EXTICR[regNo] &= ~(0x0F   << extiShift);
    SYSCFG->EXTICR[regNo] |=  (portNo << extiShift);

    // Rising trigger selection
    if (((uint16_t)extiTrigger) & ((uint16_t)extiTriggerRising))
        EXTI->RTSR |=  pinMask;
    else
        EXTI->RTSR &= ~pinMask;

    // Falling trigger selection
    if (((uint16_t)extiTrigger) & ((uint16_t)extiTriggerFalling))
        EXTI->FTSR |=  pinMask;
    else
        EXTI->FTSR &= ~pinMask;

    // SWIER
    // PR

    NVIC_EnableIRQ ( gpioGetExtiIrqN(pinNo) ); // NVIC_DisableIRQ

    // Разрешаем прерывания в периферии
    EXTI->IMR |= pinMask; // (EXTI_IMR_MR1 | EXTI_IMR_MR2);

}

inline
void periphInitIrq( const GpioPinAddr &pinAddr, ExtiTrigger extiTrigger, PinMode pinMode = PinMode::gpio_in_pullup )
{
    periphInitIrq( pinAddr.port, pinAddr.pinNo, extiTrigger, pinMode);
}

inline
void periphInitIrq( const GpioPin &pin, ExtiTrigger extiTrigger, PinMode pinMode = PinMode::gpio_in_pullup )
{
    periphInitIrq( pin.getPinAddr(), extiTrigger, pinMode);
}

//---------------------------------------------------------




//---------------------------------------------------------
inline
void periphDisableIrq( GPIO_TypeDef *gpioPort, uint16_t pinNo )
{
    UMBA_ASSERT(isValidPinPort(gpioPort));
    UMBA_ASSERT(isValidPinNo(pinNo));

    uint16_t pinMask = 1 << pinNo;
    //NVIC_DisableIRQ( gpioGetExtiIrqN(pinNo) ); // NVIC_DisableIRQ
    periphEnableIRQ( gpioGetExtiIrqN(pinNo), false );
    EXTI->IMR &= ~pinMask;
}

inline
void periphDisableIrq( const GpioPinAddr &pinAddr )
{
    periphDisableIrq( pinAddr.port, pinAddr.pinNo );
}

inline
void periphDisableIrq( const GpioPin &pin )
{
    periphDisableIrq( pin.getPinAddr() );
}

//---------------------------------------------------------






//---------------------------------------------------------
inline 
void gpioExtiGenerateSoftwareIrq( uint16_t pinNo )
{
    UMBA_ASSERT(isValidPinNo(pinNo));
    uint16_t pinMask = 1 << pinNo;
    EXTI->SWIER |= pinMask;
}

inline 
void gpioExtiGenerateSoftwareIrq( GPIO_TypeDef *gpioPort, uint16_t pinNo )
{
    UMBA_ASSERT(isValidPinPort(gpioPort));
    gpioExtiGenerateSoftwareIrq( pinNo );
}

inline 
void gpioExtiGenerateSoftwareIrq( const GpioPinAddr &pinAddr )
{
    gpioExtiGenerateSoftwareIrq( pinAddr.pinNo );
}

inline 
void gpioExtiGenerateSoftwareIrq( const GpioPin &pin )
{
    gpioExtiGenerateSoftwareIrq( pin.getPinAddr() );
}

//---------------------------------------------------------




//---------------------------------------------------------
inline 
bool gpioExtiTestPendingIrq( uint16_t pinNo )
{
    UMBA_ASSERT(isValidPinNo(pinNo));
    uint16_t pinMask = 1 << pinNo;
    return (EXTI->PR & pinMask) ? true : false;
}

inline 
bool gpioExtiTestPendingIrq( GPIO_TypeDef *gpioPort, uint16_t pinNo )
{
    UMBA_ASSERT(isValidPinPort(gpioPort));
    return gpioExtiTestPendingIrq( pinNo );
}

inline 
bool gpioExtiTestPendingIrq( const GpioPinAddr &pinAddr )
{
    return gpioExtiTestPendingIrq( pinAddr.pinNo );
}

inline 
bool gpioExtiTestPendingIrq( const GpioPin &pin )
{
    return gpioExtiTestPendingIrq( pin.getPinAddr() );
}



//---------------------------------------------------------
inline 
void gpioExtiClearPendingIrq( uint16_t pinNo )
{
    UMBA_ASSERT(isValidPinNo(pinNo));
    uint16_t pinMask = 1 << pinNo;
    EXTI->PR |= pinMask; // writting clears bit
}

inline 
void gpioExtiClearPendingIrq( GPIO_TypeDef *gpioPort, uint16_t pinNo )
{
    UMBA_ASSERT(isValidPinPort(gpioPort));
    gpioExtiClearPendingIrq( pinNo );
}

inline 
void gpioExtiClearPendingIrq( const GpioPinAddr &pinAddr )
{
    gpioExtiClearPendingIrq( pinAddr.pinNo );
}

inline 
void gpioExtiClearPendingIrq( const GpioPin &pin )
{
    gpioExtiClearPendingIrq( pin.getPinAddr() );
}

#define UMBA_PERIPH_DECLARE_GPIO_EXTI_HANDLER_PROC( name )   void name( void *pParam, const umba::periph::traits::GpioPinAddr &pinAddr )


typedef void (*ExtiHandlerProcT)( void *pParam, const GpioPinAddr &);

struct ExtiHandlerVectorEntry
{
    GpioPinAddr        pinAddr;
    ExtiHandlerProcT   extiHandlerProc;
    void*              pParam;
};


bool periphInstallIrqHandler  ( const GpioPinAddr &pinAddr, ExtiHandlerProcT proc, void *pParam = 0 );
bool periphUninstallIrqHandler( const GpioPinAddr &pinAddr );

inline
bool periphInstallIrqHandler  ( GPIO_TypeDef *gpioPort, uint16_t pinNo, ExtiHandlerProcT proc, void *pParam = 0 )
{
    return periphInstallIrqHandler( { gpioPort, pinNo }, proc, pParam );
}

inline 
bool periphInstallIrqHandler( const GpioPin &pin, ExtiHandlerProcT proc, void *pParam = 0 )
{
    return periphInstallIrqHandler( pin.getPinAddr(), proc, pParam );
}

inline
bool periphUninstallIrqHandler  ( GPIO_TypeDef *gpioPort, uint16_t pinNo )
{
    return periphUninstallIrqHandler( { gpioPort, pinNo } );
}

inline 
bool periphUninstallIrqHandler( const GpioPin &pin )
{
    return periphUninstallIrqHandler( pin.getPinAddr() );
}


} // namespace traits
} // namespace periph
} // namespace umba


