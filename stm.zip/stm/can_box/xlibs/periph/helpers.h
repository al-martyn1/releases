#pragma once


// umba::periph::helpers::

namespace umba
{
namespace periph
{
namespace helpers
{

#if 0
//inline 
UMBA_FORCE_INLINE( void setResetHelper( volatile uint16_t *pReg, uint16_t mask, bool bv ) )
{
    /*
    if (bv)
       *pReg |= mask;
    else
       *pReg &= ~mask;
    */
}

//inline
UMBA_FORCE_INLINE( void setResetHelper( volatile uint32_t *pReg, uint32_t mask, bool bv ) )
{
    /*
    if (bv)
       *pReg |= mask;
    else
       *pReg &= ~mask;
    */
}
#endif

//----------------------------------------------------------------------------
inline
void regBitSetResetHelper( volatile uint32_t &reg, uint32_t mask, bool bv )
{
    if (bv)
       reg |= mask;
    else
       reg &= ~mask;
}

//----------------------------------------------------------------------------
inline
void regBitSetResetHelper( volatile uint32_t *pReg, uint32_t mask, bool bv )
{
    if (bv)
       *pReg |= mask;
    else
       *pReg &= ~mask;
}

//----------------------------------------------------------------------------
constexpr uint32_t makeBit( const unsigned nBit )
{
    return 1u<<nBit;
}

//----------------------------------------------------------------------------
constexpr uint32_t makeMask( const unsigned nMaskBits )
{
    return ((1u<<nMaskBits)-1);
}

//----------------------------------------------------------------------------
inline
void regMaskedSet( volatile uint32_t &reg, unsigned valMaskNumBits, unsigned lowBitNo, uint32_t val )
{
    reg &= ~(makeMask(valMaskNumBits) << lowBitNo); // clear reg field
    reg |= ((val<<lowBitNo) & makeMask(valMaskNumBits)); // set reg field

}

//----------------------------------------------------------------------------
inline
uint32_t regMaskedGet( const volatile uint32_t &reg, unsigned valMaskNumBits, unsigned lowBitNo )
{
    return (reg & makeMask(valMaskNumBits))>>lowBitNo;
}

/*
//----------------------------------------------------------------------------
inline
uint32_t regMaskedMakeMask( unsigned numBits )
{
    uint32_t res = 1;
    for(unsigned i=0; i!=numBits; ++i, res <<= 1)
        res |= res<<1;
    return res;
}

inline
void regMaskedSetHelper( volatile uint32_t *pReg, unsigned valSizeNumBits, unsigned lowBitNo, uint32_t val )
{
    uint32_t mask = regMaskedMakeMask( valSizeNumBits ) << lowBitNo;
    val           = (val<<lowBitNo) & mask;
    mask = 
    //setResetHelper( pReg, (uint32_t)mask, bv );
    if (bv)
       *pReg |= mask;
    else
       *pReg &= ~mask;
}
*/




/*
inline void setResetHelper( uint32_t *pReg, unsigned mask, bool bv )
{
    setResetHelper( pReg, (uint32_t)mask, bv );
}
*/





/*
//inline
UMBA_FORCE_INLINE( void setResetHelper( volatile uint16_t *pReg, int mask, bool bv ) )
{
    setResetHelper( pReg, (uint16_t)mask, bv );
}

//inline 
UMBA_FORCE_INLINE( void setResetHelper( volatile uint16_t *pReg, unsigned mask, bool bv ) )
{
    setResetHelper( pReg, (uint16_t)mask, bv );
}
*/

} // namespace helpers
} // namespace periph
} // namespace umba

#define UMBA_PERIPH_BIT_SET_RESET_HELPER( reg, bitMask, flag )    \
            umba::periph::helpers::regBitSetResetHelper( &(reg), bitMask, flag!=0 )


