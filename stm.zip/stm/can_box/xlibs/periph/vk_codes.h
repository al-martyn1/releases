#pragma once

// umba::periph::
namespace umba
{
namespace periph
{

// umba::periph::VirtualKeyCode
namespace VirtualKeyCode
{
    const unsigned virtualCodeFlag     = 0x80000000;
                                                
    const unsigned enter               = 0x8000000D;
    const unsigned tab                 = 0x80000009;
    const unsigned pause               = 0x8000001A;
    const unsigned escape              = 0x8000001B;
                                                
    const unsigned f1                  = 0x80000020;
    const unsigned f2                  = 0x80000021;
    const unsigned f3                  = 0x80000022;
    const unsigned f4                  = 0x80000023;
    const unsigned f5                  = 0x80000024;
    const unsigned f6                  = 0x80000025;
    const unsigned f7                  = 0x80000026;
    const unsigned f8                  = 0x80000027;
    const unsigned f9                  = 0x80000028;
    const unsigned f10                 = 0x80000029;
    const unsigned f11                 = 0x8000002A;
    const unsigned f12                 = 0x8000002B;
    const unsigned f13                 = 0x8000002C;
    const unsigned f14                 = 0x8000002D;
    const unsigned f15                 = 0x8000002E;
    const unsigned f16                 = 0x8000002F;
    const unsigned f17                 = 0x80000030;
    const unsigned f18                 = 0x80000031;
    const unsigned f19                 = 0x80000032;
    const unsigned f20                 = 0x80000033;
    const unsigned f21                 = 0x80000034;
    const unsigned f22                 = 0x80000035;
    const unsigned f23                 = 0x80000036;
    const unsigned f24                 = 0x80000037;
    const unsigned f25                 = 0x80000038;
    const unsigned f26                 = 0x80000039;
    const unsigned f27                 = 0x8000003A;
    const unsigned f28                 = 0x8000003B;
    const unsigned f29                 = 0x8000003C;
    const unsigned f30                 = 0x8000003D;
    const unsigned f31                 = 0x8000003E;
    const unsigned f32                 = 0x8000003F;
                                                
    const unsigned up                  = 0x80000041;
    const unsigned down                = 0x80000042;
    const unsigned right               = 0x80000043;
    const unsigned left                = 0x80000044;

    const unsigned home                = 0x80000051;
    const unsigned ins                 = 0x80000052;
    const unsigned del                 = 0x80000053;
    const unsigned end                 = 0x80000054;
    const unsigned pageUp              = 0x80000055;
    const unsigned pageDown            = 0x80000056;

    const unsigned menu                = 0x80000060;
    const unsigned telemetry           = 0x80000061;
    const unsigned volumeUp            = 0x80000062;
    const unsigned volumeDown          = 0x80000063;

                                                
    const unsigned backspace           = 0x8000007F;
    //const unsigned unknown             = 0x80000100;
    const unsigned unknown             = 0xFFFFFFFF;


inline
const char* getKeyCodeName( unsigned vkc )
{
    using namespace umba::periph::VirtualKeyCode;
    switch(vkc)
    {
     case f1       : return "F1";
     case f2       : return "F2";
     case f3       : return "F3";
     case f4       : return "F4";
     case f5       : return "F5";
     case f6       : return "F6";
     case f7       : return "F7";
     case f8       : return "F8";
     case f9       : return "F9";
     case f10      : return "F10";
     case f11      : return "F11";
     case f12      : return "F12";
     case f13      : return "F13";
     case f14      : return "F14";
     case f15      : return "F15";
     case f16      : return "F16";
     case f17      : return "F17";
     case f18      : return "F18";
     case f19      : return "F19";
     case f20      : return "F20";
     case f21      : return "F21";
     case f22      : return "F22";
     case f23      : return "F23";
     case f24      : return "F24";
     case f25      : return "F25";
     case f26      : return "F26";
     case f27      : return "F27";
     case f28      : return "F28";
     case f29      : return "F29";
     case f30      : return "F30";
     case f31      : return "F31";
     case f32      : return "F32";
     case enter    : return "Enter";
     case tab      : return "Tab";
     case escape   : return "Escape";
     case backspace: return "Backspace";
     case pause    : return "Pause";
     case ins      : return "Ins";
     case del      : return "Del";
     case home     : return "Home";
     case end      : return "End";
     case pageUp   : return "Page Up";
     case pageDown : return "Page Down";
     case left     : return "Left";
     case right    : return "Right";
     case up       : return "Up";
     case down     : return "Down";
     case menu       : return "Menu";
     case telemetry  : return "Telemetry";
     case volumeUp   : return "VolumeUp";
     case volumeDown : return "VolumeDown";
     default       : return "<Unknown>";
    }

} // namespace VirtualKeyCode



}





} // namespace periph
} // namespace umba

