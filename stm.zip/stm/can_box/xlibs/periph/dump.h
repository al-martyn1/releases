#pragma once


#include "umba/dump.h"
//#iclude "umba/exception.h"
#include <stddef.h>
#include <cstring>
#include <algorithm> 


namespace umba
{
namespace periph
{

namespace utils
{

template< typename StreamType >
inline
void configureStreamHex( StreamType & ss, bool setHex )
{
    // Bjarne, 740
    //ss.setf( setHex ? std::ios_base::hex : std::ios_base::dec, std::ios_base::basefield );
}

//----------------------------------------------------------------------------
#ifdef UMBA_SIMPLE_FORMATTER_H
template< >
inline
void configureStreamHex< ::umba::SimpleFormatter >( ::umba::SimpleFormatter & ss, bool setHex )
{
    ss.base( setHex ? 16 : 10 );
    ss.groupsize(8);
    //ss.noshowbase();
}
#endif

} // namespace utils




template <typename StreamType> inline
void dumpLine( StreamType &s
             , const uint8_t *pBase
             , const uint8_t *pCur
             , size_t sz
             , bool longOffset
             , bool alsoBin
             )
{
   using namespace umba::omanip;
   utils::configureStreamHex( s, true );
   size_t delta = (size_t)(pCur - pBase);

   char buf[64];
   if (sz>4) sz = 4;

   char dataBuf[4];
   std::memcpy( dataBuf, pCur, sz ); // lock the volatile data

   #if defined(UMBA_ARCH_LITTLE_ENDIAN)
       // In dwords, low bytes goes first
       std::reverse( &dataBuf[0], &dataBuf[sz] );
   #endif

   s<<noshowbase<<(size_t)(pBase)<<" + ";

   if (longOffset)
       s<<noshowbase<<width(8)<<(uint32_t)delta;
   else
       s<<noshowbase<<width(4)<<(uint16_t)delta;

   s<<width(0)<<": "<<umba::dump( &buf[0], (const uint8_t*)&dataBuf[0], sz );

   if(alsoBin)
   {
       s<<" - "<<umba::dumpBin( &buf[0], (const uint8_t*)&dataBuf[0], sz );
   }

   s<<"\n";
}

template <typename StreamType, typename PeriphType> inline
void dump( StreamType &s, PeriphType *pPeriph, const char *pPeriphName, bool alsoBin = true )
{
    size_t i=0, size = sizeof(PeriphType) / 4;
    size_t rest = sizeof(PeriphType) - size*4;

    bool longOffset = sizeof(PeriphType) > 65535;

    const uint8_t *pBase = (const uint8_t*)pPeriph;
    const uint8_t *pCur  = pBase;

    using namespace umba::omanip;
    utils::configureStreamHex( s, true );
    s<<(size_t)pBase<<" - "<<pPeriphName;

    utils::configureStreamHex( s, false );
    s<<", size: "<< sizeof(PeriphType)<<"\n";
    utils::configureStreamHex( s, true );

    for(; i!=size; ++i, pCur += 4)
    {
        dumpLine( s, pBase, pCur, 4, longOffset, alsoBin );
    }

    if(rest>=2)
    {
       dumpLine( s, pBase, pCur, 2, longOffset, alsoBin );
       rest-=2;
    }

    if(rest)
       dumpLine( s, pBase, pCur, rest, longOffset, alsoBin );

    utils::configureStreamHex( s, false );
}




} // namespace periph
} // namespace umba


