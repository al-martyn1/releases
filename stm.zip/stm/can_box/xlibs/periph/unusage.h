/*
 Reduce prorgam size by using explicitly defined periphery
 
 Use Keil option 
   --preinclude=periph/unusage.h

  Small project, used: ADC2, TIM1, DAC1

  Before defining PERIPH_EXPLICIT_USAGE:
    Program Size: Code=19904 RO-data=3780 RW-data=172 ZI-data=3796  

  After defining PERIPH_EXPLICIT_USAGE:
    Program Size: Code=17716 RO-data=3476 RW-data=172 ZI-data=3796  

 */


#ifndef USE_TIM1
     #ifdef TIM1
     #undef TIM1
     #endif
#endif

#ifndef USE_TIM2
     #ifdef TIM2
     #undef TIM2
     #endif
#endif

#ifndef USE_TIM3
     #ifdef TIM3
     #undef TIM3
     #endif
#endif

#ifndef USE_TIM4
     #ifdef TIM4
     #undef TIM4
     #endif
#endif

#ifndef USE_TIM5
     #ifdef TIM5
     #undef TIM5
     #endif
#endif

#ifndef USE_TIM6
     #ifdef TIM6
     #undef TIM6
     #endif
#endif

#ifndef USE_TIM7
     #ifdef TIM7
     #undef TIM7
     #endif
#endif

#ifndef USE_TIM8
     #ifdef TIM8
     #undef TIM8
     #endif
#endif

#ifndef USE_TIM9
     #ifdef TIM9
     #undef TIM9
     #endif
#endif

#ifndef USE_TIM10
     #ifdef TIM10
     #undef TIM10
     #endif
#endif

#ifndef USE_TIM11
     #ifdef TIM11
     #undef TIM11
     #endif
#endif

#ifndef USE_TIM12
     #ifdef TIM12
     #undef TIM12
     #endif
#endif

#ifndef USE_TIM13
     #ifdef TIM13
     #undef TIM13
     #endif
#endif

#ifndef USE_TIM14
     #ifdef TIM14
     #undef TIM14
     #endif
#endif

#ifndef USE_TIM15
     #ifdef TIM15
     #undef TIM15
     #endif
#endif

#ifndef USE_TIM16
     #ifdef TIM16
     #undef TIM16
     #endif
#endif

#ifndef USE_TIM17
     #ifdef TIM17
     #undef TIM17
     #endif
#endif

#ifndef USE_TIM18
     #ifdef TIM18
     #undef TIM18
     #endif
#endif

#ifndef USE_TIM19
     #ifdef TIM19
     #undef TIM19
     #endif
#endif

#ifndef USE_TIM20
     #ifdef TIM20
     #undef TIM20
     #endif
#endif

#ifndef USE_ADC1
     #ifdef ADC1
     #undef ADC1
     #endif
#endif

#ifndef USE_ADC2
     #ifdef ADC2
     #undef ADC2
     #endif
#endif

#ifndef USE_ADC3
     #ifdef ADC3
     #undef ADC3
     #endif
#endif

#ifndef USE_ADC4
     #ifdef ADC4
     #undef ADC4
     #endif
#endif

#ifdef USE_DAC1
    #ifndef USE_DAC
        #define USE_DAC
    #endif
#endif

#ifdef USE_DAC
    #ifndef USE_DAC1
        #define USE_DAC1
    #endif
#endif

#ifndef USE_DAC
     #ifdef DAC
     #undef DAC
     #endif
#endif

#ifndef USE_DAC1
     #ifdef DAC1
     #undef DAC1
     #endif
#endif

#ifndef USE_DAC2
     #ifdef DAC2
     #undef DAC2
     #endif
#endif

#ifndef USE_SPI1
     #ifdef SPI1
     #undef SPI1
     #endif
#endif

#ifndef USE_SPI2
     #ifdef SPI2
     #undef SPI2
     #endif
#endif

#ifndef USE_SPI3
     #ifdef SPI3
     #undef SPI3
     #endif
#endif

#ifndef USE_SPI4
     #ifdef SPI4
     #undef SPI4
     #endif
#endif

#ifndef USE_I2C1
     #ifdef I2C1
     #undef I2C1
     #endif
#endif

#ifndef USE_I2C2
     #ifdef I2C2
     #undef I2C2
     #endif
#endif

#ifndef USE_I2C3
     #ifdef I2C3
     #undef I2C3
     #endif
#endif

#ifndef USE_CAN1
     #ifdef CAN1
     #undef CAN1
     #endif
#endif

#ifndef USE_CAN2
     #ifdef CAN2
     #undef CAN2
     #endif
#endif

#ifndef USE_CAN3
     #ifdef CAN3
     #undef CAN3
     #endif
#endif



