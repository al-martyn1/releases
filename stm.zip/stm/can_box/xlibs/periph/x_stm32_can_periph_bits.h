
namespace umba{
namespace periph{
namespace traits{


// Bit constants - bs* prefix is used to exclude conflicts with old macros

// Do not include this file directly

#if defined(STM32F1_SERIES)

   // Transmit MailBoxes base and shift (to next MailBox)

   constexpr uint32_t bcCAN_TSR_MB_BASE_OFFSET  = 0u;
   constexpr uint32_t bcCAN_TSR_MB_SHIFT        = 8u;

   // Index (offset) in single MailBox, not in all TSR register
   constexpr uint32_t bcCAN_TSR_MB_RQCP_BITN    = 0u; // Bit 0 RQCP0: Request completed mailbox
   constexpr uint32_t bcCAN_TSR_MB_TXOK_BITN    = 1u; // Bit 1 TXOK0: Transmission OK of mailbox
   constexpr uint32_t bcCAN_TSR_MB_ALST_BITN    = 2u; // Bit 2 ALST0: Arbitration lost for mailbox
   constexpr uint32_t bcCAN_TSR_MB_TERR_BITN    = 3u; // Bit 3 TERR0: Transmission error of mailbox
   constexpr uint32_t bcCAN_TSR_MB_ABRQ_BITN    = 7u; // Bit 7 ABRQ0: Abort request for mailbox

   constexpr uint32_t bcCAN_TSR_RQCP0           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 0u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_RQCP_BITN);
   constexpr uint32_t bcCAN_TSR_RQCP1           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 1u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_RQCP_BITN);
   constexpr uint32_t bcCAN_TSR_RQCP2           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 2u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_RQCP_BITN);
                                              
   constexpr uint32_t bcCAN_TSR_TXOK0           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 0u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_TXOK_BITN);
   constexpr uint32_t bcCAN_TSR_TXOK1           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 1u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_TXOK_BITN);
   constexpr uint32_t bcCAN_TSR_TXOK2           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 2u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_TXOK_BITN);
                                              
   constexpr uint32_t bcCAN_TSR_ALST0           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 0u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_ALST_BITN);
   constexpr uint32_t bcCAN_TSR_ALST1           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 1u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_ALST_BITN);
   constexpr uint32_t bcCAN_TSR_ALST2           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 2u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_ALST_BITN);
                                              
   constexpr uint32_t bcCAN_TSR_TERR0           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 0u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_TERR_BITN);
   constexpr uint32_t bcCAN_TSR_TERR1           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 1u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_TERR_BITN);
   constexpr uint32_t bcCAN_TSR_TERR2           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 2u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_TERR_BITN);

   constexpr uint32_t bcCAN_TSR_MB_STATUS_BYTE_CHK_MASK = ( (1u<<bcCAN_TSR_MB_RQCP_BITN) | (1u<<bcCAN_TSR_MB_TXOK_BITN) | (1u<<bcCAN_TSR_MB_ALST_BITN) | (1u<<bcCAN_TSR_MB_TERR_BITN) );


   constexpr uint32_t bcCAN_TSR_MB_TME_BASE_OFFSET = 26u;
   constexpr uint32_t bcCAN_TSR_TME0            =  1u<<(bcCAN_TSR_MB_TME_BASE_OFFSET + 0 /* 0*bcCAN_TSR_MB_SHIFT */ );
   constexpr uint32_t bcCAN_TSR_TME1            =  1u<<(bcCAN_TSR_MB_TME_BASE_OFFSET + 1 /* 1*bcCAN_TSR_MB_SHIFT */ );
   constexpr uint32_t bcCAN_TSR_TME2            =  1u<<(bcCAN_TSR_MB_TME_BASE_OFFSET + 2 /* 2*bcCAN_TSR_MB_SHIFT */ );

   constexpr uint32_t bcCAN_TSR_TME_CHK_MASK    =  bcCAN_TSR_TME0 | bcCAN_TSR_TME1 | bcCAN_TSR_TME2;


   // RX FIFO MailBoxes/Registers
   constexpr uint32_t bcCAN_RFR_RFOM_BITN       =  5u; // Bit 5 RFOM0: Release FIFO output mailbox
   constexpr uint32_t bcCAN_RFR_FOVR_BITN       =  4u; // Bit 4 FOVR0: FIFO overrun
   constexpr uint32_t bcCAN_RFR_FULL_BITN       =  3u; // Bit 3 FULL0: FIFO full
   constexpr uint32_t bcCAN_RFR_FMP_BITN        =  0u; // Bits 1:0 FMP0[1:0]: FIFO message pending

   constexpr uint32_t bcCAN_RFR_FMP_MASK        =  3u<<bcCAN_RFR_FMP_BITN;    // Bits 1:0 FMP0[1:0]: FIFO message pending
   constexpr uint32_t bcCAN_RFR_FMP_CHK_MASK    =  bcCAN_RFR_FMP_MASK;
   constexpr uint32_t bcCAN_RFR_FMP_SET_MASK    =  bcCAN_RFR_FMP_CHK_MASK;
   constexpr uint32_t bcCAN_RFR_FMP_CLR_MASK    = ~bcCAN_RFR_FMP_CHK_MASK;

   constexpr uint32_t bcCAN_RFR_FULL_FOVR_BITN  = 3u;
   constexpr uint32_t bcCAN_RFR_FULL_FOVR_SHIFT = bcCAN_RFR_FULL_FOVR_BITN;
   constexpr uint32_t bcCAN_RFR_FULL_FOVR_CHK_MASK  = 3u<<bcCAN_RFR_FULL_FOVR_BITN;
   constexpr uint32_t bcCAN_RFR_FULL_FOVR_SET_MASK  = bcCAN_RFR_FULL_FOVR_CHK_MASK;
   constexpr uint32_t bcCAN_RFR_FULL_FOVR_CLR_MASK  = ~bcCAN_RFR_FULL_FOVR_SET_MASK;

   constexpr uint32_t bcCAN_RFR_RFOM_CHK_MASK   =  1u<<bcCAN_RFR_RFOM_BITN ;
   constexpr uint32_t bcCAN_RFR_RFOM_SET_MASK   =  bcCAN_RFR_RFOM_CHK_MASK ;
   constexpr uint32_t bcCAN_RFR_RFOM_CLR_MASK   = ~bcCAN_RFR_RFOM_SET_MASK ;


   // MSR - Master Status Register
   constexpr uint32_t bcCAN_MSR_RX_BITN         = 11u;  // Bit 11 RX: CAN Rx signal. Monitors the actual value of the CAN_RX Pin.
   constexpr uint32_t bcCAN_MSR_SAMP_BITN       = 10u;  // Bit 10 SAMP: Last sample point. The value of RX on the last sample point (current received bit value).
   constexpr uint32_t bcCAN_MSR_RXM_BITN        =  9u;  // Bit 9 RXM: Receive mode. The CAN hardware is currently receiver.
   constexpr uint32_t bcCAN_MSR_TXM_BITN        =  8u;  // Bit 8 TXM: Transmit mode. The CAN hardware is currently transmitter.
   constexpr uint32_t bcCAN_MSR_SLAKI_BITN      =  4u;  // Bit 4 SLAKI: Sleep acknowledge interrupt
   constexpr uint32_t bcCAN_MSR_WKUI_BITN       =  3u;  // Bit 3 WKUI: Wakeup interrupt
   constexpr uint32_t bcCAN_MSR_ERRI_BITN       =  2u;  // Bit 2 ERRI: Error interrupt
   constexpr uint32_t bcCAN_MSR_SLAK_BITN       =  1u;  // Bit 1 SLAK: Sleep acknowledge
   constexpr uint32_t bcCAN_MSR_INAK_BITN       =  0u;  // Bit 0 INAK: Initialization acknowledge

   constexpr uint32_t bcCAN_MSR_RX_CHK_MASK     = 1<<bcCAN_MSR_RX_BITN   ;
   constexpr uint32_t bcCAN_MSR_SAMP_CHK_MASK   = 1<<bcCAN_MSR_SAMP_BITN ;
   constexpr uint32_t bcCAN_MSR_RXM_CHK_MASK    = 1<<bcCAN_MSR_RXM_BITN  ;
   constexpr uint32_t bcCAN_MSR_TXM_CHK_MASK    = 1<<bcCAN_MSR_TXM_BITN  ;
   constexpr uint32_t bcCAN_MSR_SLAKI_CHK_MASK  = 1<<bcCAN_MSR_SLAKI_BITN;
   constexpr uint32_t bcCAN_MSR_WKUI_CHK_MASK   = 1<<bcCAN_MSR_WKUI_BITN ;
   constexpr uint32_t bcCAN_MSR_ERRI_CHK_MASK   = 1<<bcCAN_MSR_ERRI_BITN ;
   constexpr uint32_t bcCAN_MSR_SLAK_CHK_MASK   = 1<<bcCAN_MSR_SLAK_BITN ;
   constexpr uint32_t bcCAN_MSR_INAK_CHK_MASK   = 1<<bcCAN_MSR_INAK_BITN ;
                                               
   constexpr uint32_t bcCAN_MSR_RX_SET_MASK     =  bcCAN_MSR_RX_CHK_MASK   ;
   constexpr uint32_t bcCAN_MSR_SAMP_SET_MASK   =  bcCAN_MSR_SAMP_CHK_MASK ;
   constexpr uint32_t bcCAN_MSR_RXM_SET_MASK    =  bcCAN_MSR_RXM_CHK_MASK  ;
   constexpr uint32_t bcCAN_MSR_TXM_SET_MASK    =  bcCAN_MSR_TXM_CHK_MASK  ;
   constexpr uint32_t bcCAN_MSR_SLAKI_SET_MASK  =  bcCAN_MSR_SLAKI_CHK_MASK;
   constexpr uint32_t bcCAN_MSR_WKUI_SET_MASK   =  bcCAN_MSR_WKUI_CHK_MASK ;
   constexpr uint32_t bcCAN_MSR_ERRI_SET_MASK   =  bcCAN_MSR_ERRI_CHK_MASK ;
   constexpr uint32_t bcCAN_MSR_SLAK_SET_MASK   =  bcCAN_MSR_SLAK_CHK_MASK ;
   constexpr uint32_t bcCAN_MSR_INAK_SET_MASK   =  bcCAN_MSR_INAK_CHK_MASK ;
                                               
   constexpr uint32_t bcCAN_MSR_RX_CLR_MASK     = ~bcCAN_MSR_RX_SET_MASK   ;
   constexpr uint32_t bcCAN_MSR_SAMP_CLR_MASK   = ~bcCAN_MSR_SAMP_SET_MASK ;
   constexpr uint32_t bcCAN_MSR_RXM_CLR_MASK    = ~bcCAN_MSR_RXM_SET_MASK  ;
   constexpr uint32_t bcCAN_MSR_TXM_CLR_MASK    = ~bcCAN_MSR_TXM_SET_MASK  ;
   constexpr uint32_t bcCAN_MSR_SLAKI_CLR_MASK  = ~bcCAN_MSR_SLAKI_SET_MASK;
   constexpr uint32_t bcCAN_MSR_WKUI_CLR_MASK   = ~bcCAN_MSR_WKUI_SET_MASK ;
   constexpr uint32_t bcCAN_MSR_ERRI_CLR_MASK   = ~bcCAN_MSR_ERRI_SET_MASK ;
   constexpr uint32_t bcCAN_MSR_SLAK_CLR_MASK   = ~bcCAN_MSR_SLAK_SET_MASK ;
   constexpr uint32_t bcCAN_MSR_INAK_CLR_MASK   = ~bcCAN_MSR_INAK_SET_MASK ;


   constexpr uint32_t bcCAN_ESR_REC_BITN        = 24 ;
   constexpr uint32_t bcCAN_ESR_TEC_BITN        = 16 ;
   constexpr uint32_t bcCAN_ESR_LEC_BITN        =  4 ;
   constexpr uint32_t bcCAN_ESR_BOFF_BITN       =  2 ;
   constexpr uint32_t bcCAN_ESR_EPVF_BITN       =  1 ;
   constexpr uint32_t bcCAN_ESR_EWGF_BITN       =  0 ;

   constexpr uint32_t bcCAN_ESR_REC_CHK_MASK    = 0xFFu << bcCAN_ESR_REC_BITN;
   constexpr uint32_t bcCAN_ESR_TEC_CHK_MASK    = 0xFFu << bcCAN_ESR_TEC_BITN;
   constexpr uint32_t bcCAN_ESR_LEC_CHK_MASK    = 0x07u << bcCAN_ESR_LEC_BITN;
   constexpr uint32_t bcCAN_ESR_BOFF_CHK_MASK   = 1u    << bcCAN_ESR_BOFF_BITN ;
   constexpr uint32_t bcCAN_ESR_EPVF_CHK_MASK   = 1u    << bcCAN_ESR_EPVF_BITN ;
   constexpr uint32_t bcCAN_ESR_EWGF_CHK_MASK   = 1u    << bcCAN_ESR_EWGF_BITN ;


   constexpr uint32_t bcCAN_MCR_DBF_BITN        = 16u; // Bit 16 DBF: Debug freeze
   constexpr uint32_t bcCAN_MCR_RESET_BITN      = 15u; // Bit 15 RESET: bxCAN software master reset
   constexpr uint32_t bcCAN_MCR_TTCM_BITN       =  7u; // Bit 7 TTCM: Time triggered communication mode
   constexpr uint32_t bcCAN_MCR_ABOM_BITN       =  6u; // Bit 6 ABOM: Automatic bus-off management
   constexpr uint32_t bcCAN_MCR_AWUM_BITN       =  5u; // Bit 5 AWUM: Automatic wakeup mode
   constexpr uint32_t bcCAN_MCR_NART_BITN       =  4u; // Bit 4 NART: No automatic retransmission
   constexpr uint32_t bcCAN_MCR_RFLM_BITN       =  3u; // Bit 3 RFLM: Receive FIFO locked mode
   constexpr uint32_t bcCAN_MCR_TXFP_BITN       =  2u; // Bit 2 TXFP: Transmit FIFO priority, 0: Priority ID-driven, 1: Order diven
   constexpr uint32_t bcCAN_MCR_SLEEP_BITN      =  1u; // Bit 1 SLEEP: Sleep mode request
   constexpr uint32_t bcCAN_MCR_INRQ_BITN       =  0u; // Bit 0 INRQ: Initialization request

   constexpr uint32_t bcCAN_MCR_DBF_CHK_MASK    = 1u<<bcCAN_MCR_DBF_BITN  ;
   constexpr uint32_t bcCAN_MCR_RESET_CHK_MASK  = 1u<<bcCAN_MCR_RESET_BITN;
   constexpr uint32_t bcCAN_MCR_TTCM_CHK_MASK   = 1u<<bcCAN_MCR_TTCM_BITN ;
   constexpr uint32_t bcCAN_MCR_ABOM_CHK_MASK   = 1u<<bcCAN_MCR_ABOM_BITN ;
   constexpr uint32_t bcCAN_MCR_AWUM_CHK_MASK   = 1u<<bcCAN_MCR_AWUM_BITN ;
   constexpr uint32_t bcCAN_MCR_NART_CHK_MASK   = 1u<<bcCAN_MCR_NART_BITN ;
   constexpr uint32_t bcCAN_MCR_RFLM_CHK_MASK   = 1u<<bcCAN_MCR_RFLM_BITN ;
   constexpr uint32_t bcCAN_MCR_TXFP_CHK_MASK   = 1u<<bcCAN_MCR_TXFP_BITN ;
   constexpr uint32_t bcCAN_MCR_SLEEP_CHK_MASK  = 1u<<bcCAN_MCR_SLEEP_BITN;
   constexpr uint32_t bcCAN_MCR_INRQ_CHK_MASK   = 1u<<bcCAN_MCR_INRQ_BITN ;
                                                
   constexpr uint32_t bcCAN_MCR_DBF_SET_MASK    =  bcCAN_MCR_DBF_CHK_MASK  ;
   constexpr uint32_t bcCAN_MCR_RESET_SET_MASK  =  bcCAN_MCR_RESET_CHK_MASK;
   constexpr uint32_t bcCAN_MCR_TTCM_SET_MASK   =  bcCAN_MCR_TTCM_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_ABOM_SET_MASK   =  bcCAN_MCR_ABOM_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_AWUM_SET_MASK   =  bcCAN_MCR_AWUM_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_NART_SET_MASK   =  bcCAN_MCR_NART_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_RFLM_SET_MASK   =  bcCAN_MCR_RFLM_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_TXFP_SET_MASK   =  bcCAN_MCR_TXFP_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_SLEEP_SET_MASK  =  bcCAN_MCR_SLEEP_CHK_MASK;
   constexpr uint32_t bcCAN_MCR_INRQ_SET_MASK   =  bcCAN_MCR_INRQ_CHK_MASK ;
                                                
   constexpr uint32_t bcCAN_MCR_DBF_CLR_MASK    = ~bcCAN_MCR_DBF_CHK_MASK  ;
   constexpr uint32_t bcCAN_MCR_RESET_CLR_MASK  = ~bcCAN_MCR_RESET_CHK_MASK;
   constexpr uint32_t bcCAN_MCR_TTCM_CLR_MASK   = ~bcCAN_MCR_TTCM_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_ABOM_CLR_MASK   = ~bcCAN_MCR_ABOM_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_AWUM_CLR_MASK   = ~bcCAN_MCR_AWUM_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_NART_CLR_MASK   = ~bcCAN_MCR_NART_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_RFLM_CLR_MASK   = ~bcCAN_MCR_RFLM_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_TXFP_CLR_MASK   = ~bcCAN_MCR_TXFP_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_SLEEP_CLR_MASK  = ~bcCAN_MCR_SLEEP_CHK_MASK;
   constexpr uint32_t bcCAN_MCR_INRQ_CLR_MASK   = ~bcCAN_MCR_INRQ_CHK_MASK ;


   constexpr uint32_t bcCAN_BTR_SILM_BITN       = 31u; // Bit 31 SILM: Silent mode (debug)
   constexpr uint32_t bcCAN_BTR_LBKM_BITN       = 30u; // Bit 30 LBKM: Loop back mode (debug)
   constexpr uint32_t bcCAN_BTR_SJW_BITN        = 24u; // Bits 25:24 SJW[1:0]: Resynchronization jump width
   constexpr uint32_t bcCAN_BTR_TS2_BITN        = 20u; // Bits 22:20 TS2[2:0]: Time segment 2
   constexpr uint32_t bcCAN_BTR_TS1_BITN        = 16u; // Bits 19:16 TS1[3:0]: Time segment 1
   constexpr uint32_t bcCAN_BTR_BRP_BITN        =  0u; // Bits 9:0 BRP[9:0]: Baud rate prescaler
                                               
   constexpr uint32_t bcCAN_BTR_SILM_CHK_MASK   = 1u    <<bcCAN_BTR_SILM_BITN;
   constexpr uint32_t bcCAN_BTR_LBKM_CHK_MASK   = 1u    <<bcCAN_BTR_LBKM_BITN;
   constexpr uint32_t bcCAN_BTR_SJW_CHK_MASK    = 0x003u<<bcCAN_BTR_SJW_BITN ;
   constexpr uint32_t bcCAN_BTR_TS2_CHK_MASK    = 0x007u<<bcCAN_BTR_TS2_BITN ;
   constexpr uint32_t bcCAN_BTR_TS1_CHK_MASK    = 0x00Fu<<bcCAN_BTR_TS1_BITN ;
   constexpr uint32_t bcCAN_BTR_BRP_CHK_MASK    = 0x3FFu<<bcCAN_BTR_BRP_BITN ;
                                               
   constexpr uint32_t bcCAN_BTR_SILM_SET_MASK   =  bcCAN_BTR_SILM_CHK_MASK;
   constexpr uint32_t bcCAN_BTR_LBKM_SET_MASK   =  bcCAN_BTR_LBKM_CHK_MASK;
   constexpr uint32_t bcCAN_BTR_SJW_SET_MASK    =  bcCAN_BTR_SJW_CHK_MASK ;
   constexpr uint32_t bcCAN_BTR_TS2_SET_MASK    =  bcCAN_BTR_TS2_CHK_MASK ;
   constexpr uint32_t bcCAN_BTR_TS1_SET_MASK    =  bcCAN_BTR_TS1_CHK_MASK ;
   constexpr uint32_t bcCAN_BTR_BRP_SET_MASK    =  bcCAN_BTR_BRP_CHK_MASK ;
                                               
   constexpr uint32_t bcCAN_BTR_SILM_CLR_MASK   = ~bcCAN_BTR_SILM_SET_MASK;
   constexpr uint32_t bcCAN_BTR_LBKM_CLR_MASK   = ~bcCAN_BTR_LBKM_SET_MASK;
   constexpr uint32_t bcCAN_BTR_SJW_CLR_MASK    = ~bcCAN_BTR_SJW_SET_MASK ;
   constexpr uint32_t bcCAN_BTR_TS2_CLR_MASK    = ~bcCAN_BTR_TS2_SET_MASK ;
   constexpr uint32_t bcCAN_BTR_TS1_CLR_MASK    = ~bcCAN_BTR_TS1_SET_MASK ;
   constexpr uint32_t bcCAN_BTR_BRP_CLR_MASK    = ~bcCAN_BTR_BRP_SET_MASK ;


   constexpr uint32_t bcCAN_FMR_CAN2SB_BITN     =  8u; // Bits 13:8 CAN2SB[5:0]: CAN2 start bank
   constexpr uint32_t bcCAN_FMR_FINIT_BITN      =  0u; // Bit 0 FINIT: Filter init mode

   constexpr uint32_t bcCAN_FMR_CAN2SB_CHK_MASK = 0x3Fu  <<bcCAN_FMR_CAN2SB_BITN;
   constexpr uint32_t bcCAN_FMR_FINIT_CHK_MASK  = 1u     <<bcCAN_FMR_FINIT_BITN ;

   constexpr uint32_t bcCAN_FMR_CAN2SB_SET_MASK =  bcCAN_FMR_CAN2SB_CHK_MASK;
   constexpr uint32_t bcCAN_FMR_FINIT_SET_MASK  =  bcCAN_FMR_FINIT_CHK_MASK ;

   constexpr uint32_t bcCAN_FMR_CAN2SB_CLR_MASK = ~bcCAN_FMR_CAN2SB_SET_MASK;
   constexpr uint32_t bcCAN_FMR_FINIT_CLR_MASK  = ~bcCAN_FMR_FINIT_SET_MASK ;


   constexpr uint32_t bcCAN_TIR_TXRQ_BITN       =   0u; // Bit 0 TXRQ: Transmit mailbox request
   constexpr uint32_t bcCAN_TIR_RTR_BITN        =   1u; // Bit 1 RTR: Remote transmission request
   constexpr uint32_t bcCAN_TIR_IDE_BITN        =   2u; // Bit 2 IDE: Identifier extension
   constexpr uint32_t bcCAN_TIR_EXID_BITN       =   3u; // Bits 20:3 EXID[17:0]: Extended identifier
   constexpr uint32_t bcCAN_TIR_STD_BITN        =  21u; // Bits 31:21 STID[10:0]/EXID[28:18]: Standard identifier or extended identifier

   constexpr uint32_t bcCAN_TIR_TXRQ_CHK_MASK   =         1u<<bcCAN_TIR_TXRQ_BITN ;
   constexpr uint32_t bcCAN_TIR_RTR_CHK_MASK    =         1u<<bcCAN_TIR_RTR_BITN  ;
   constexpr uint32_t bcCAN_TIR_IDE_CHK_MASK    =         1u<<bcCAN_TIR_IDE_BITN  ;
   constexpr uint32_t bcCAN_TIR_EXID_CHK_MASK   =   0x3FFFFu<<bcCAN_TIR_EXID_BITN ;
   constexpr uint32_t bcCAN_TIR_STD_CHK_MASK    =     0x7FFu<<bcCAN_TIR_STD_BITN  ;

   constexpr uint32_t bcCAN_TIR_TXRQ_SET_MASK   =  bcCAN_TIR_TXRQ_CHK_MASK ;
   constexpr uint32_t bcCAN_TIR_RTR_SET_MASK    =  bcCAN_TIR_RTR_CHK_MASK  ;
   constexpr uint32_t bcCAN_TIR_IDE_SET_MASK    =  bcCAN_TIR_IDE_CHK_MASK  ;
   constexpr uint32_t bcCAN_TIR_EXID_SET_MASK   =  bcCAN_TIR_EXID_CHK_MASK ;
   constexpr uint32_t bcCAN_TIR_STD_SET_MASK    =  bcCAN_TIR_STD_CHK_MASK  ;

   constexpr uint32_t bcCAN_TIR_TXRQ_CLR_MASK   = ~bcCAN_TIR_TXRQ_SET_MASK ;
   constexpr uint32_t bcCAN_TIR_RTR_CLR_MASK    = ~bcCAN_TIR_RTR_SET_MASK  ;
   constexpr uint32_t bcCAN_TIR_IDE_CLR_MASK    = ~bcCAN_TIR_IDE_SET_MASK  ;
   constexpr uint32_t bcCAN_TIR_EXID_CLR_MASK   = ~bcCAN_TIR_EXID_SET_MASK ;
   constexpr uint32_t bcCAN_TIR_STD_CLR_MASK    = ~bcCAN_TIR_STD_SET_MASK  ;


   constexpr uint32_t bcCAN_TDTR_DLC_BITN       =   0u; // Bits 3:0 DLC[3:0]: Data length code
   constexpr uint32_t bcCAN_TDTR_TGT_BITN       =   8u; // Bit 8 TGT: Transmit global time
   constexpr uint32_t bcCAN_TDTR_TIME_BITN      =  16u; // Bits 31:16 TIME[15:0]: Message time stamp

   constexpr uint32_t bcCAN_TDTR_DLC_CHK_MASK   =   0x0Fu<<bcCAN_TDTR_DLC_BITN  ;
   constexpr uint32_t bcCAN_TDTR_TGT_CHK_MASK   =      1u<<bcCAN_TDTR_TGT_BITN  ;
   constexpr uint32_t bcCAN_TDTR_TIME_CHK_MASK  = 0xFFFFu<<bcCAN_TDTR_TIME_BITN ;

   constexpr uint32_t bcCAN_TDTR_DLC_SET_MASK   =  bcCAN_TDTR_DLC_CHK_MASK  ;
   constexpr uint32_t bcCAN_TDTR_TGT_SET_MASK   =  bcCAN_TDTR_TGT_CHK_MASK  ;
   constexpr uint32_t bcCAN_TDTR_TIME_SET_MASK  =  bcCAN_TDTR_TIME_CHK_MASK ;

   constexpr uint32_t bcCAN_TDTR_DLC_CLR_MASK   = ~bcCAN_TDTR_DLC_SET_MASK  ;
   constexpr uint32_t bcCAN_TDTR_TGT_CLR_MASK   = ~bcCAN_TDTR_TGT_SET_MASK  ;
   constexpr uint32_t bcCAN_TDTR_TIME_CLR_MASK  = ~bcCAN_TDTR_TIME_SET_MASK ;


   // CAN receive FIFO mailbox identifier register (CAN_RIxR) (x=0..1)
   constexpr uint32_t bcCAN_RIR_RTR_BITN        =   1u; // Bit 1 RTR: Remote transmission request
   constexpr uint32_t bcCAN_RIR_IDE_BITN        =   2u; // 
   constexpr uint32_t bcCAN_RIR_EXID_BITN       =   3u; // 
   constexpr uint32_t bcCAN_RIR_STID_BITN       =  21u; // 

   constexpr uint32_t bcCAN_RIR_RTR_CHK_MASK    =         1u<<bcCAN_RIR_RTR_BITN  ;
   constexpr uint32_t bcCAN_RIR_IDE_CHK_MASK    =         1u<<bcCAN_RIR_IDE_BITN  ;
   constexpr uint32_t bcCAN_RIR_EXID_CHK_MASK   =   0x3FFFFu<<bcCAN_RIR_EXID_BITN ;
   constexpr uint32_t bcCAN_RIR_STID_CHK_MASK   =     0x7FFu<<bcCAN_RIR_STID_BITN ;

   constexpr uint32_t bcCAN_RIR_RTR_SET_MASK    =  bcCAN_RIR_RTR_CHK_MASK  ;
   constexpr uint32_t bcCAN_RIR_IDE_SET_MASK    =  bcCAN_RIR_IDE_CHK_MASK  ;
   constexpr uint32_t bcCAN_RIR_EXID_SET_MASK   =  bcCAN_RIR_EXID_CHK_MASK ;
   constexpr uint32_t bcCAN_RIR_STID_SET_MASK   =  bcCAN_RIR_STID_CHK_MASK ;

   constexpr uint32_t bcCAN_RIR_RTR_CLR_MASK    = ~bcCAN_RIR_RTR_SET_MASK  ;
   constexpr uint32_t bcCAN_RIR_IDE_CLR_MASK    = ~bcCAN_RIR_IDE_SET_MASK  ;
   constexpr uint32_t bcCAN_RIR_EXID_CLR_MASK   = ~bcCAN_RIR_EXID_SET_MASK ;
   constexpr uint32_t bcCAN_RIR_STID_CLR_MASK   = ~bcCAN_RIR_STID_SET_MASK ;


   constexpr uint32_t bcCAN_RDTR_DLC_BITN       =   0u; // Bits 3:0 DLC[3:0]: Data length code
   constexpr uint32_t bcCAN_RDTR_DLC_CHK_MASK   =   0x0Fu<<bcCAN_RDTR_DLC_BITN ;
   constexpr uint32_t bcCAN_RDTR_DLC_SET_MASK   =  bcCAN_RDTR_DLC_CHK_MASK     ;
   constexpr uint32_t bcCAN_RDTR_DLC_CLR_MASK   = ~bcCAN_RDTR_DLC_SET_MASK     ;


#else

    #if defined(USE_CAN) || defined(USE_CAN1) || defined(USE_CAN2)
        #error "Not implemented for this family"
    #endif


   // Transmit MailBoxes base and shift (to next MailBox)

   constexpr uint32_t bcCAN_TSR_MB_BASE_OFFSET  = 0u;
   constexpr uint32_t bcCAN_TSR_MB_SHIFT        = 8u;

   // Index (offset) in single MailBox, not in all TSR register
   constexpr uint32_t bcCAN_TSR_MB_RQCP_BITN    = 0u; // Bit 0 RQCP0: Request completed mailbox
   constexpr uint32_t bcCAN_TSR_MB_TXOK_BITN    = 1u; // Bit 1 TXOK0: Transmission OK of mailbox
   constexpr uint32_t bcCAN_TSR_MB_ALST_BITN    = 2u; // Bit 2 ALST0: Arbitration lost for mailbox
   constexpr uint32_t bcCAN_TSR_MB_TERR_BITN    = 3u; // Bit 3 TERR0: Transmission error of mailbox
   constexpr uint32_t bcCAN_TSR_MB_ABRQ_BITN    = 7u; // Bit 7 ABRQ0: Abort request for mailbox

   constexpr uint32_t bcCAN_TSR_RQCP0           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 0u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_RQCP_BITN);
   constexpr uint32_t bcCAN_TSR_RQCP1           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 1u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_RQCP_BITN);
   constexpr uint32_t bcCAN_TSR_RQCP2           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 2u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_RQCP_BITN);
                                              
   constexpr uint32_t bcCAN_TSR_TXOK0           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 0u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_TXOK_BITN);
   constexpr uint32_t bcCAN_TSR_TXOK1           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 1u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_TXOK_BITN);
   constexpr uint32_t bcCAN_TSR_TXOK2           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 2u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_TXOK_BITN);
                                              
   constexpr uint32_t bcCAN_TSR_ALST0           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 0u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_ALST_BITN);
   constexpr uint32_t bcCAN_TSR_ALST1           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 1u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_ALST_BITN);
   constexpr uint32_t bcCAN_TSR_ALST2           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 2u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_ALST_BITN);
                                              
   constexpr uint32_t bcCAN_TSR_TERR0           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 0u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_TERR_BITN);
   constexpr uint32_t bcCAN_TSR_TERR1           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 1u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_TERR_BITN);
   constexpr uint32_t bcCAN_TSR_TERR2           = 1u<<(bcCAN_TSR_MB_BASE_OFFSET + 2u*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_TERR_BITN);

   constexpr uint32_t bcCAN_TSR_MB_STATUS_BYTE_CHK_MASK = ( (1u<<bcCAN_TSR_MB_RQCP_BITN) | (1u<<bcCAN_TSR_MB_TXOK_BITN) | (1u<<bcCAN_TSR_MB_ALST_BITN) | (1u<<bcCAN_TSR_MB_TERR_BITN) );


   constexpr uint32_t bcCAN_TSR_MB_TME_BASE_OFFSET = 26u;
   constexpr uint32_t bcCAN_TSR_TME0            =  1u<<(bcCAN_TSR_MB_TME_BASE_OFFSET + 0 /* 0*bcCAN_TSR_MB_SHIFT */ );
   constexpr uint32_t bcCAN_TSR_TME1            =  1u<<(bcCAN_TSR_MB_TME_BASE_OFFSET + 1 /* 1*bcCAN_TSR_MB_SHIFT */ );
   constexpr uint32_t bcCAN_TSR_TME2            =  1u<<(bcCAN_TSR_MB_TME_BASE_OFFSET + 2 /* 2*bcCAN_TSR_MB_SHIFT */ );

   constexpr uint32_t bcCAN_TSR_TME_CHK_MASK    =  bcCAN_TSR_TME0 | bcCAN_TSR_TME1 | bcCAN_TSR_TME2;


   // RX FIFO MailBoxes/Registers
   constexpr uint32_t bcCAN_RFR_RFOM_BITN       =  5u; // Bit 5 RFOM0: Release FIFO output mailbox
   constexpr uint32_t bcCAN_RFR_FOVR_BITN       =  4u; // Bit 4 FOVR0: FIFO overrun
   constexpr uint32_t bcCAN_RFR_FULL_BITN       =  3u; // Bit 3 FULL0: FIFO full
   constexpr uint32_t bcCAN_RFR_FMP_BITN        =  0u; // Bits 1:0 FMP0[1:0]: FIFO message pending

   constexpr uint32_t bcCAN_RFR_FMP_MASK        =  3u<<bcCAN_RFR_FMP_BITN;    // Bits 1:0 FMP0[1:0]: FIFO message pending
   constexpr uint32_t bcCAN_RFR_FMP_CHK_MASK    =  bcCAN_RFR_FMP_MASK;
   constexpr uint32_t bcCAN_RFR_FMP_SET_MASK    =  bcCAN_RFR_FMP_CHK_MASK;
   constexpr uint32_t bcCAN_RFR_FMP_CLR_MASK    = ~bcCAN_RFR_FMP_CHK_MASK;

   constexpr uint32_t bcCAN_RFR_FULL_FOVR_BITN  = 3u;
   constexpr uint32_t bcCAN_RFR_FULL_FOVR_SHIFT = bcCAN_RFR_FULL_FOVR_BITN;
   constexpr uint32_t bcCAN_RFR_FULL_FOVR_CHK_MASK  = 3u<<bcCAN_RFR_FULL_FOVR_BITN;
   constexpr uint32_t bcCAN_RFR_FULL_FOVR_SET_MASK  = bcCAN_RFR_FULL_FOVR_CHK_MASK;
   constexpr uint32_t bcCAN_RFR_FULL_FOVR_CLR_MASK  = ~bcCAN_RFR_FULL_FOVR_SET_MASK;

   constexpr uint32_t bcCAN_RFR_RFOM_CHK_MASK   =  1u<<bcCAN_RFR_RFOM_BITN ;
   constexpr uint32_t bcCAN_RFR_RFOM_SET_MASK   =  bcCAN_RFR_RFOM_CHK_MASK ;
   constexpr uint32_t bcCAN_RFR_RFOM_CLR_MASK   = ~bcCAN_RFR_RFOM_SET_MASK ;


   // MSR - Master Status Register
   constexpr uint32_t bcCAN_MSR_RX_BITN         = 11u;  // Bit 11 RX: CAN Rx signal. Monitors the actual value of the CAN_RX Pin.
   constexpr uint32_t bcCAN_MSR_SAMP_BITN       = 10u;  // Bit 10 SAMP: Last sample point. The value of RX on the last sample point (current received bit value).
   constexpr uint32_t bcCAN_MSR_RXM_BITN        =  9u;  // Bit 9 RXM: Receive mode. The CAN hardware is currently receiver.
   constexpr uint32_t bcCAN_MSR_TXM_BITN        =  8u;  // Bit 8 TXM: Transmit mode. The CAN hardware is currently transmitter.
   constexpr uint32_t bcCAN_MSR_SLAKI_BITN      =  4u;  // Bit 4 SLAKI: Sleep acknowledge interrupt
   constexpr uint32_t bcCAN_MSR_WKUI_BITN       =  3u;  // Bit 3 WKUI: Wakeup interrupt
   constexpr uint32_t bcCAN_MSR_ERRI_BITN       =  2u;  // Bit 2 ERRI: Error interrupt
   constexpr uint32_t bcCAN_MSR_SLAK_BITN       =  1u;  // Bit 1 SLAK: Sleep acknowledge
   constexpr uint32_t bcCAN_MSR_INAK_BITN       =  0u;  // Bit 0 INAK: Initialization acknowledge

   constexpr uint32_t bcCAN_MSR_RX_CHK_MASK     = 1<<bcCAN_MSR_RX_BITN   ;
   constexpr uint32_t bcCAN_MSR_SAMP_CHK_MASK   = 1<<bcCAN_MSR_SAMP_BITN ;
   constexpr uint32_t bcCAN_MSR_RXM_CHK_MASK    = 1<<bcCAN_MSR_RXM_BITN  ;
   constexpr uint32_t bcCAN_MSR_TXM_CHK_MASK    = 1<<bcCAN_MSR_TXM_BITN  ;
   constexpr uint32_t bcCAN_MSR_SLAKI_CHK_MASK  = 1<<bcCAN_MSR_SLAKI_BITN;
   constexpr uint32_t bcCAN_MSR_WKUI_CHK_MASK   = 1<<bcCAN_MSR_WKUI_BITN ;
   constexpr uint32_t bcCAN_MSR_ERRI_CHK_MASK   = 1<<bcCAN_MSR_ERRI_BITN ;
   constexpr uint32_t bcCAN_MSR_SLAK_CHK_MASK   = 1<<bcCAN_MSR_SLAK_BITN ;
   constexpr uint32_t bcCAN_MSR_INAK_CHK_MASK   = 1<<bcCAN_MSR_INAK_BITN ;
                                               
   constexpr uint32_t bcCAN_MSR_RX_SET_MASK     =  bcCAN_MSR_RX_CHK_MASK   ;
   constexpr uint32_t bcCAN_MSR_SAMP_SET_MASK   =  bcCAN_MSR_SAMP_CHK_MASK ;
   constexpr uint32_t bcCAN_MSR_RXM_SET_MASK    =  bcCAN_MSR_RXM_CHK_MASK  ;
   constexpr uint32_t bcCAN_MSR_TXM_SET_MASK    =  bcCAN_MSR_TXM_CHK_MASK  ;
   constexpr uint32_t bcCAN_MSR_SLAKI_SET_MASK  =  bcCAN_MSR_SLAKI_CHK_MASK;
   constexpr uint32_t bcCAN_MSR_WKUI_SET_MASK   =  bcCAN_MSR_WKUI_CHK_MASK ;
   constexpr uint32_t bcCAN_MSR_ERRI_SET_MASK   =  bcCAN_MSR_ERRI_CHK_MASK ;
   constexpr uint32_t bcCAN_MSR_SLAK_SET_MASK   =  bcCAN_MSR_SLAK_CHK_MASK ;
   constexpr uint32_t bcCAN_MSR_INAK_SET_MASK   =  bcCAN_MSR_INAK_CHK_MASK ;
                                               
   constexpr uint32_t bcCAN_MSR_RX_CLR_MASK     = ~bcCAN_MSR_RX_SET_MASK   ;
   constexpr uint32_t bcCAN_MSR_SAMP_CLR_MASK   = ~bcCAN_MSR_SAMP_SET_MASK ;
   constexpr uint32_t bcCAN_MSR_RXM_CLR_MASK    = ~bcCAN_MSR_RXM_SET_MASK  ;
   constexpr uint32_t bcCAN_MSR_TXM_CLR_MASK    = ~bcCAN_MSR_TXM_SET_MASK  ;
   constexpr uint32_t bcCAN_MSR_SLAKI_CLR_MASK  = ~bcCAN_MSR_SLAKI_SET_MASK;
   constexpr uint32_t bcCAN_MSR_WKUI_CLR_MASK   = ~bcCAN_MSR_WKUI_SET_MASK ;
   constexpr uint32_t bcCAN_MSR_ERRI_CLR_MASK   = ~bcCAN_MSR_ERRI_SET_MASK ;
   constexpr uint32_t bcCAN_MSR_SLAK_CLR_MASK   = ~bcCAN_MSR_SLAK_SET_MASK ;
   constexpr uint32_t bcCAN_MSR_INAK_CLR_MASK   = ~bcCAN_MSR_INAK_SET_MASK ;


   constexpr uint32_t bcCAN_ESR_REC_BITN        = 24 ;
   constexpr uint32_t bcCAN_ESR_TEC_BITN        = 16 ;
   constexpr uint32_t bcCAN_ESR_LEC_BITN        =  4 ;
   constexpr uint32_t bcCAN_ESR_BOFF_BITN       =  2 ;
   constexpr uint32_t bcCAN_ESR_EPVF_BITN       =  1 ;
   constexpr uint32_t bcCAN_ESR_EWGF_BITN       =  0 ;

   constexpr uint32_t bcCAN_ESR_REC_CHK_MASK    = 0xFFu << bcCAN_ESR_REC_BITN;
   constexpr uint32_t bcCAN_ESR_TEC_CHK_MASK    = 0xFFu << bcCAN_ESR_TEC_BITN;
   constexpr uint32_t bcCAN_ESR_LEC_CHK_MASK    = 0x07u << bcCAN_ESR_LEC_BITN;
   constexpr uint32_t bcCAN_ESR_BOFF_CHK_MASK   = 1u    << bcCAN_ESR_BOFF_BITN ;
   constexpr uint32_t bcCAN_ESR_EPVF_CHK_MASK   = 1u    << bcCAN_ESR_EPVF_BITN ;
   constexpr uint32_t bcCAN_ESR_EWGF_CHK_MASK   = 1u    << bcCAN_ESR_EWGF_BITN ;


   constexpr uint32_t bcCAN_MCR_DBF_BITN        = 16u; // Bit 16 DBF: Debug freeze
   constexpr uint32_t bcCAN_MCR_RESET_BITN      = 15u; // Bit 15 RESET: bxCAN software master reset
   constexpr uint32_t bcCAN_MCR_TTCM_BITN       =  7u; // Bit 7 TTCM: Time triggered communication mode
   constexpr uint32_t bcCAN_MCR_ABOM_BITN       =  6u; // Bit 6 ABOM: Automatic bus-off management
   constexpr uint32_t bcCAN_MCR_AWUM_BITN       =  5u; // Bit 5 AWUM: Automatic wakeup mode
   constexpr uint32_t bcCAN_MCR_NART_BITN       =  4u; // Bit 4 NART: No automatic retransmission
   constexpr uint32_t bcCAN_MCR_RFLM_BITN       =  3u; // Bit 3 RFLM: Receive FIFO locked mode
   constexpr uint32_t bcCAN_MCR_TXFP_BITN       =  2u; // Bit 2 TXFP: Transmit FIFO priority, 0: Priority ID-driven, 1: Order diven
   constexpr uint32_t bcCAN_MCR_SLEEP_BITN      =  1u; // Bit 1 SLEEP: Sleep mode request
   constexpr uint32_t bcCAN_MCR_INRQ_BITN       =  0u; // Bit 0 INRQ: Initialization request

   constexpr uint32_t bcCAN_MCR_DBF_CHK_MASK    = 1u<<bcCAN_MCR_DBF_BITN  ;
   constexpr uint32_t bcCAN_MCR_RESET_CHK_MASK  = 1u<<bcCAN_MCR_RESET_BITN;
   constexpr uint32_t bcCAN_MCR_TTCM_CHK_MASK   = 1u<<bcCAN_MCR_TTCM_BITN ;
   constexpr uint32_t bcCAN_MCR_ABOM_CHK_MASK   = 1u<<bcCAN_MCR_ABOM_BITN ;
   constexpr uint32_t bcCAN_MCR_AWUM_CHK_MASK   = 1u<<bcCAN_MCR_AWUM_BITN ;
   constexpr uint32_t bcCAN_MCR_NART_CHK_MASK   = 1u<<bcCAN_MCR_NART_BITN ;
   constexpr uint32_t bcCAN_MCR_RFLM_CHK_MASK   = 1u<<bcCAN_MCR_RFLM_BITN ;
   constexpr uint32_t bcCAN_MCR_TXFP_CHK_MASK   = 1u<<bcCAN_MCR_TXFP_BITN ;
   constexpr uint32_t bcCAN_MCR_SLEEP_CHK_MASK  = 1u<<bcCAN_MCR_SLEEP_BITN;
   constexpr uint32_t bcCAN_MCR_INRQ_CHK_MASK   = 1u<<bcCAN_MCR_INRQ_BITN ;
                                                
   constexpr uint32_t bcCAN_MCR_DBF_SET_MASK    =  bcCAN_MCR_DBF_CHK_MASK  ;
   constexpr uint32_t bcCAN_MCR_RESET_SET_MASK  =  bcCAN_MCR_RESET_CHK_MASK;
   constexpr uint32_t bcCAN_MCR_TTCM_SET_MASK   =  bcCAN_MCR_TTCM_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_ABOM_SET_MASK   =  bcCAN_MCR_ABOM_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_AWUM_SET_MASK   =  bcCAN_MCR_AWUM_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_NART_SET_MASK   =  bcCAN_MCR_NART_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_RFLM_SET_MASK   =  bcCAN_MCR_RFLM_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_TXFP_SET_MASK   =  bcCAN_MCR_TXFP_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_SLEEP_SET_MASK  =  bcCAN_MCR_SLEEP_CHK_MASK;
   constexpr uint32_t bcCAN_MCR_INRQ_SET_MASK   =  bcCAN_MCR_INRQ_CHK_MASK ;
                                                
   constexpr uint32_t bcCAN_MCR_DBF_CLR_MASK    = ~bcCAN_MCR_DBF_CHK_MASK  ;
   constexpr uint32_t bcCAN_MCR_RESET_CLR_MASK  = ~bcCAN_MCR_RESET_CHK_MASK;
   constexpr uint32_t bcCAN_MCR_TTCM_CLR_MASK   = ~bcCAN_MCR_TTCM_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_ABOM_CLR_MASK   = ~bcCAN_MCR_ABOM_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_AWUM_CLR_MASK   = ~bcCAN_MCR_AWUM_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_NART_CLR_MASK   = ~bcCAN_MCR_NART_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_RFLM_CLR_MASK   = ~bcCAN_MCR_RFLM_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_TXFP_CLR_MASK   = ~bcCAN_MCR_TXFP_CHK_MASK ;
   constexpr uint32_t bcCAN_MCR_SLEEP_CLR_MASK  = ~bcCAN_MCR_SLEEP_CHK_MASK;
   constexpr uint32_t bcCAN_MCR_INRQ_CLR_MASK   = ~bcCAN_MCR_INRQ_CHK_MASK ;


   constexpr uint32_t bcCAN_BTR_SILM_BITN       = 31u; // Bit 31 SILM: Silent mode (debug)
   constexpr uint32_t bcCAN_BTR_LBKM_BITN       = 30u; // Bit 30 LBKM: Loop back mode (debug)
   constexpr uint32_t bcCAN_BTR_SJW_BITN        = 24u; // Bits 25:24 SJW[1:0]: Resynchronization jump width
   constexpr uint32_t bcCAN_BTR_TS2_BITN        = 20u; // Bits 22:20 TS2[2:0]: Time segment 2
   constexpr uint32_t bcCAN_BTR_TS1_BITN        = 16u; // Bits 19:16 TS1[3:0]: Time segment 1
   constexpr uint32_t bcCAN_BTR_BRP_BITN        =  0u; // Bits 9:0 BRP[9:0]: Baud rate prescaler
                                               
   constexpr uint32_t bcCAN_BTR_SILM_CHK_MASK   = 1u    <<bcCAN_BTR_SILM_BITN;
   constexpr uint32_t bcCAN_BTR_LBKM_CHK_MASK   = 1u    <<bcCAN_BTR_LBKM_BITN;
   constexpr uint32_t bcCAN_BTR_SJW_CHK_MASK    = 0x003u<<bcCAN_BTR_SJW_BITN ;
   constexpr uint32_t bcCAN_BTR_TS2_CHK_MASK    = 0x007u<<bcCAN_BTR_TS2_BITN ;
   constexpr uint32_t bcCAN_BTR_TS1_CHK_MASK    = 0x00Fu<<bcCAN_BTR_TS1_BITN ;
   constexpr uint32_t bcCAN_BTR_BRP_CHK_MASK    = 0x3FFu<<bcCAN_BTR_BRP_BITN ;
                                               
   constexpr uint32_t bcCAN_BTR_SILM_SET_MASK   =  bcCAN_BTR_SILM_CHK_MASK;
   constexpr uint32_t bcCAN_BTR_LBKM_SET_MASK   =  bcCAN_BTR_LBKM_CHK_MASK;
   constexpr uint32_t bcCAN_BTR_SJW_SET_MASK    =  bcCAN_BTR_SJW_CHK_MASK ;
   constexpr uint32_t bcCAN_BTR_TS2_SET_MASK    =  bcCAN_BTR_TS2_CHK_MASK ;
   constexpr uint32_t bcCAN_BTR_TS1_SET_MASK    =  bcCAN_BTR_TS1_CHK_MASK ;
   constexpr uint32_t bcCAN_BTR_BRP_SET_MASK    =  bcCAN_BTR_BRP_CHK_MASK ;
                                               
   constexpr uint32_t bcCAN_BTR_SILM_CLR_MASK   = ~bcCAN_BTR_SILM_SET_MASK;
   constexpr uint32_t bcCAN_BTR_LBKM_CLR_MASK   = ~bcCAN_BTR_LBKM_SET_MASK;
   constexpr uint32_t bcCAN_BTR_SJW_CLR_MASK    = ~bcCAN_BTR_SJW_SET_MASK ;
   constexpr uint32_t bcCAN_BTR_TS2_CLR_MASK    = ~bcCAN_BTR_TS2_SET_MASK ;
   constexpr uint32_t bcCAN_BTR_TS1_CLR_MASK    = ~bcCAN_BTR_TS1_SET_MASK ;
   constexpr uint32_t bcCAN_BTR_BRP_CLR_MASK    = ~bcCAN_BTR_BRP_SET_MASK ;


   constexpr uint32_t bcCAN_FMR_CAN2SB_BITN     =  8u; // Bits 13:8 CAN2SB[5:0]: CAN2 start bank
   constexpr uint32_t bcCAN_FMR_FINIT_BITN      =  0u; // Bit 0 FINIT: Filter init mode

   constexpr uint32_t bcCAN_FMR_CAN2SB_CHK_MASK = 0x3Fu  <<bcCAN_FMR_CAN2SB_BITN;
   constexpr uint32_t bcCAN_FMR_FINIT_CHK_MASK  = 1u     <<bcCAN_FMR_FINIT_BITN ;

   constexpr uint32_t bcCAN_FMR_CAN2SB_SET_MASK =  bcCAN_FMR_CAN2SB_CHK_MASK;
   constexpr uint32_t bcCAN_FMR_FINIT_SET_MASK  =  bcCAN_FMR_FINIT_CHK_MASK ;

   constexpr uint32_t bcCAN_FMR_CAN2SB_CLR_MASK = ~bcCAN_FMR_CAN2SB_SET_MASK;
   constexpr uint32_t bcCAN_FMR_FINIT_CLR_MASK  = ~bcCAN_FMR_FINIT_SET_MASK ;


   constexpr uint32_t bcCAN_TIR_TXRQ_BITN       =   0u; // Bit 0 TXRQ: Transmit mailbox request
   constexpr uint32_t bcCAN_TIR_RTR_BITN        =   1u; // Bit 1 RTR: Remote transmission request
   constexpr uint32_t bcCAN_TIR_IDE_BITN        =   2u; // Bit 2 IDE: Identifier extension
   constexpr uint32_t bcCAN_TIR_EXID_BITN       =   3u; // Bits 20:3 EXID[17:0]: Extended identifier
   constexpr uint32_t bcCAN_TIR_STD_BITN        =  21u; // Bits 31:21 STID[10:0]/EXID[28:18]: Standard identifier or extended identifier

   constexpr uint32_t bcCAN_TIR_TXRQ_CHK_MASK   =         1u<<bcCAN_TIR_TXRQ_BITN ;
   constexpr uint32_t bcCAN_TIR_RTR_CHK_MASK    =         1u<<bcCAN_TIR_RTR_BITN  ;
   constexpr uint32_t bcCAN_TIR_IDE_CHK_MASK    =         1u<<bcCAN_TIR_IDE_BITN  ;
   constexpr uint32_t bcCAN_TIR_EXID_CHK_MASK   =   0x3FFFFu<<bcCAN_TIR_EXID_BITN ;
   constexpr uint32_t bcCAN_TIR_STD_CHK_MASK    =     0x7FFu<<bcCAN_TIR_STD_BITN  ;

   constexpr uint32_t bcCAN_TIR_TXRQ_SET_MASK   =  bcCAN_TIR_TXRQ_CHK_MASK ;
   constexpr uint32_t bcCAN_TIR_RTR_SET_MASK    =  bcCAN_TIR_RTR_CHK_MASK  ;
   constexpr uint32_t bcCAN_TIR_IDE_SET_MASK    =  bcCAN_TIR_IDE_CHK_MASK  ;
   constexpr uint32_t bcCAN_TIR_EXID_SET_MASK   =  bcCAN_TIR_EXID_CHK_MASK ;
   constexpr uint32_t bcCAN_TIR_STD_SET_MASK    =  bcCAN_TIR_STD_CHK_MASK  ;

   constexpr uint32_t bcCAN_TIR_TXRQ_CLR_MASK   = ~bcCAN_TIR_TXRQ_SET_MASK ;
   constexpr uint32_t bcCAN_TIR_RTR_CLR_MASK    = ~bcCAN_TIR_RTR_SET_MASK  ;
   constexpr uint32_t bcCAN_TIR_IDE_CLR_MASK    = ~bcCAN_TIR_IDE_SET_MASK  ;
   constexpr uint32_t bcCAN_TIR_EXID_CLR_MASK   = ~bcCAN_TIR_EXID_SET_MASK ;
   constexpr uint32_t bcCAN_TIR_STD_CLR_MASK    = ~bcCAN_TIR_STD_SET_MASK  ;


   constexpr uint32_t bcCAN_TDTR_DLC_BITN       =   0u; // Bits 3:0 DLC[3:0]: Data length code
   constexpr uint32_t bcCAN_TDTR_TGT_BITN       =   8u; // Bit 8 TGT: Transmit global time
   constexpr uint32_t bcCAN_TDTR_TIME_BITN      =  16u; // Bits 31:16 TIME[15:0]: Message time stamp

   constexpr uint32_t bcCAN_TDTR_DLC_CHK_MASK   =   0x0Fu<<bcCAN_TDTR_DLC_BITN  ;
   constexpr uint32_t bcCAN_TDTR_TGT_CHK_MASK   =      1u<<bcCAN_TDTR_TGT_BITN  ;
   constexpr uint32_t bcCAN_TDTR_TIME_CHK_MASK  = 0xFFFFu<<bcCAN_TDTR_TIME_BITN ;

   constexpr uint32_t bcCAN_TDTR_DLC_SET_MASK   =  bcCAN_TDTR_DLC_CHK_MASK  ;
   constexpr uint32_t bcCAN_TDTR_TGT_SET_MASK   =  bcCAN_TDTR_TGT_CHK_MASK  ;
   constexpr uint32_t bcCAN_TDTR_TIME_SET_MASK  =  bcCAN_TDTR_TIME_CHK_MASK ;

   constexpr uint32_t bcCAN_TDTR_DLC_CLR_MASK   = ~bcCAN_TDTR_DLC_SET_MASK  ;
   constexpr uint32_t bcCAN_TDTR_TGT_CLR_MASK   = ~bcCAN_TDTR_TGT_SET_MASK  ;
   constexpr uint32_t bcCAN_TDTR_TIME_CLR_MASK  = ~bcCAN_TDTR_TIME_SET_MASK ;


   // CAN receive FIFO mailbox identifier register (CAN_RIxR) (x=0..1)
   constexpr uint32_t bcCAN_RIR_RTR_BITN        =   1u; // Bit 1 RTR: Remote transmission request
   constexpr uint32_t bcCAN_RIR_IDE_BITN        =   2u; // 
   constexpr uint32_t bcCAN_RIR_EXID_BITN       =   3u; // 
   constexpr uint32_t bcCAN_RIR_STID_BITN       =  21u; // 

   constexpr uint32_t bcCAN_RIR_RTR_CHK_MASK    =         1u<<bcCAN_RIR_RTR_BITN  ;
   constexpr uint32_t bcCAN_RIR_IDE_CHK_MASK    =         1u<<bcCAN_RIR_IDE_BITN  ;
   constexpr uint32_t bcCAN_RIR_EXID_CHK_MASK   =   0x3FFFFu<<bcCAN_RIR_EXID_BITN ;
   constexpr uint32_t bcCAN_RIR_STID_CHK_MASK   =     0x7FFu<<bcCAN_RIR_STID_BITN ;

   constexpr uint32_t bcCAN_RIR_RTR_SET_MASK    =  bcCAN_RIR_RTR_CHK_MASK  ;
   constexpr uint32_t bcCAN_RIR_IDE_SET_MASK    =  bcCAN_RIR_IDE_CHK_MASK  ;
   constexpr uint32_t bcCAN_RIR_EXID_SET_MASK   =  bcCAN_RIR_EXID_CHK_MASK ;
   constexpr uint32_t bcCAN_RIR_STID_SET_MASK   =  bcCAN_RIR_STID_CHK_MASK ;

   constexpr uint32_t bcCAN_RIR_RTR_CLR_MASK    = ~bcCAN_RIR_RTR_SET_MASK  ;
   constexpr uint32_t bcCAN_RIR_IDE_CLR_MASK    = ~bcCAN_RIR_IDE_SET_MASK  ;
   constexpr uint32_t bcCAN_RIR_EXID_CLR_MASK   = ~bcCAN_RIR_EXID_SET_MASK ;
   constexpr uint32_t bcCAN_RIR_STID_CLR_MASK   = ~bcCAN_RIR_STID_SET_MASK ;


   constexpr uint32_t bcCAN_RDTR_DLC_BITN       =   0u; // Bits 3:0 DLC[3:0]: Data length code
   constexpr uint32_t bcCAN_RDTR_DLC_CHK_MASK   =   0x0Fu<<bcCAN_RDTR_DLC_BITN ;
   constexpr uint32_t bcCAN_RDTR_DLC_SET_MASK   =  bcCAN_RDTR_DLC_CHK_MASK     ;
   constexpr uint32_t bcCAN_RDTR_DLC_CLR_MASK   = ~bcCAN_RDTR_DLC_SET_MASK     ;


#endif


} // namespace traits
} // namespace periph
} // namespace umba



