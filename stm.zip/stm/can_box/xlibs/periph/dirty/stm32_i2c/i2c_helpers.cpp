#include "mcu.h"
#include "periph/stm32_traits.h"
#include "i2c_helpers.h"

namespace umba
{
namespace periph
{
namespace dirty
{



void init_I2C2( I2C_TypeDef* I2Cx
              , uint32_t i2cSpeed
              , uint8_t  i2cSelfAddr
              , GPIO_TypeDef *portScl, uint16_t sclPinNo
              , GPIO_TypeDef *portSda, uint16_t sdaPinNo
              )
{
    I2C_InitTypeDef i2cInitStruct;

    I2C_StructInit( &i2cInitStruct );

    #if defined(STM32F4_SERIES)

    i2cInitStruct.I2C_ClockSpeed = i2cSpeed; 
    i2cInitStruct.I2C_Mode = I2C_Mode_I2C;
    i2cInitStruct.I2C_DutyCycle = I2C_DutyCycle_2;
    
    i2cInitStruct.I2C_OwnAddress1 = i2cSelfAddr;
    i2cInitStruct.I2C_Ack = I2C_Ack_Enable; // I2C_Ack_Disable; // I2C_Ack_Enable; // I2C_Ack_Disable; //
    i2cInitStruct.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;

    #else

        #if defined(__CC_ARM)
            #warning Undone - current family not supported
        #else
            #pragma message("Undone - current family not supported")
        #endif

    #endif
    
    using namespace umba::periph::traits;

    periphInit( I2Cx, i2cInitStruct, portScl, sclPinNo, portSda, sdaPinNo );
}



} // namespace dirty
} // namespace periph
} // namespace umba

// http://altor1.narod.ru/Articles/I2C_RP.pdf



//-----------------------------------------------------------------------------
void I2C_StartTransmission(I2C_TypeDef* I2Cx, uint8_t transmissionDirection,  uint8_t slaveAddress)
{
    // На всякий слуыай ждем, пока шина осовободится
    while(I2C_GetFlagStatus(I2Cx, I2C_FLAG_BUSY));
 
    // Генерируем старт - тут все понятно )
    I2C_GenerateSTART(I2Cx, ENABLE);
    #if 0
	      if (NewState != DISABLE)
	      {
	        /* Generate a START condition */
	        I2Cx->CR1 |= I2C_CR1_START;
	      }
	      else
	      {
	        /* Disable the START condition generation */
	        I2Cx->CR1 &= (uint16_t)~((uint16_t)I2C_CR1_START);
	      }
    #endif
 
    // Ждем пока взлетит нужный флаг
    #if defined(STM32F4_SERIES)
    while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_MODE_SELECT));
    #else
        #if defined(__CC_ARM)
            #warning Undone - current family not supported
        #else
            #pragma message("Undone - current family not supported")
        #endif
    #endif
 
    // Посылаем адрес подчиненному
    #if defined(STM32F4_SERIES)
    I2C_Send7bitAddress(I2Cx, slaveAddress, transmissionDirection);
    #else
        #if defined(__CC_ARM)
            #warning Undone - current family not supported
        #else
            #pragma message("Undone - current family not supported")
        #endif
    #endif
 
    // А теперь у нас два варианта развития событий - в зависимости от выбранного направления обмена данными
    if(transmissionDirection== I2C_Direction_Transmitter)
    {
        #if defined(STM32F4_SERIES)
        while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED));
        #else
            #if defined(__CC_ARM)
                #warning Undone - current family not supported
            #else
                #pragma message("Undone - current family not supported")
            #endif
        #endif
    }
 
    if(transmissionDirection== I2C_Direction_Receiver)
    {
        #if defined(STM32F4_SERIES)
	    while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED));
        #else
            #if defined(__CC_ARM)
                #warning Undone - current family not supported
            #else
                #pragma message("Undone - current family not supported")
            #endif
        #endif
    }
}

//-----------------------------------------------------------------------------
bool I2C_IsBusy( I2C_TypeDef* I2Cx )
{
    return I2C_GetFlagStatus(I2Cx, I2C_FLAG_BUSY) ? true : false;
}

//-----------------------------------------------------------------------------
bool I2C_IsEventMasterNodeSelect(I2C_TypeDef* I2Cx)
{
    #if defined(STM32F4_SERIES)
    return I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_MODE_SELECT);
    #else
    return false;
        #if defined(__CC_ARM)
            #warning Undone - current family not supported
        #else
            #pragma message("Undone - current family not supported")
        #endif
    #endif
}

//-----------------------------------------------------------------------------
bool I2C_IsEventMasterTransmitterModeSelected(I2C_TypeDef* I2Cx)
{
    #if defined(STM32F4_SERIES)
    return I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED) ? true : false;
    #else
    return false;
        #if defined(__CC_ARM)
            #warning Undone - current family not supported
        #else
            #pragma message("Undone - current family not supported")
        #endif
    #endif
}

//-----------------------------------------------------------------------------
bool I2C_IsEventMasterReceiverModeSelected(I2C_TypeDef* I2Cx)
{
    #if defined(STM32F4_SERIES)
    return I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED) ? true : false;
    #else
    return false;
        #if defined(__CC_ARM)
            #warning Undone - current family not supported
        #else
            #pragma message("Undone - current family not supported")
        #endif
    #endif
}

//-----------------------------------------------------------------------------
bool I2C_IsMasterByteTransmitted(I2C_TypeDef* I2Cx)
{
    #if defined(STM32F4_SERIES)
    return I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED) ? true : false;
    #else
    return false;
        #if defined(__CC_ARM)
            #warning Undone - current family not supported
        #else
            #pragma message("Undone - current family not supported")
        #endif
    #endif
}

//-----------------------------------------------------------------------------
bool I2C_IsMasterByteReceived(I2C_TypeDef* I2Cx)
{
    #if defined(STM32F4_SERIES)
    return I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED) ? true : false;
    #else
    return false;
        #if defined(__CC_ARM)
            #warning Undone - current family not supported
        #else
            #pragma message("Undone - current family not supported")
        #endif
    #endif
}

//-----------------------------------------------------------------------------
unsigned I2C_StartTransmission(I2C_TypeDef* I2Cx, uint8_t transmissionDirection,  uint8_t slaveAddress, const ISoftTimer &asyncDelay)
{
    // На всякий слуыай ждем, пока шина осовободится
    while(!asyncDelay.isTimedOut() && I2C_GetFlagStatus(I2Cx, I2C_FLAG_BUSY));
    if (asyncDelay.isTimedOut())
       return 1;
 
    // Генерируем старт - тут все понятно )
    I2C_GenerateSTART(I2Cx, ENABLE);
 
    // Ждем пока взлетит нужный флаг
    /* Test on EV5 and clear it */
    //while (!I2C_CheckEvent(CODEC_I2C, I2C_EVENT_MASTER_MODE_SELECT))

    #if defined(STM32F4_SERIES)
    while(!asyncDelay.isTimedOut() && !I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_MODE_SELECT));
    #else
        #if defined(__CC_ARM)
            #warning Undone - current family not supported
        #else
            #pragma message("Undone - current family not supported")
        #endif
    #endif
    if (asyncDelay.isTimedOut())
       return 2;
 
    // Посылаем адрес подчиненному
    #if defined(STM32F4_SERIES)
    I2C_Send7bitAddress(I2Cx, slaveAddress, transmissionDirection);
    #else
        #if defined(__CC_ARM)
            #warning Undone - current family not supported
        #else
            #pragma message("Undone - current family not supported")
        #endif
    #endif
 
    // А теперь у нас два варианта развития событий - в зависимости от выбранного направления обмена данными
    if(transmissionDirection== I2C_Direction_Transmitter)
    {
        #if defined(STM32F4_SERIES)
    	while(!asyncDelay.isTimedOut() && !I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED));
        if (asyncDelay.isTimedOut())
           return 3;
        #else
            #if defined(__CC_ARM)
                #warning Undone - current family not supported
            #else
                #pragma message("Undone - current family not supported")
            #endif
        #endif
    }
 
    if(transmissionDirection== I2C_Direction_Receiver)
    {
        #if defined(STM32F4_SERIES)
        while(!asyncDelay.isTimedOut() && !I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED));
        if (asyncDelay.isTimedOut())
           return 3;
        #else
            #if defined(__CC_ARM)
                #warning Undone - current family not supported
            #else
                #pragma message("Undone - current family not supported")
            #endif
        #endif
    }
    
    return 0;
}
 
//-----------------------------------------------------------------------------
void I2C_WriteData(I2C_TypeDef* I2Cx, uint8_t data)
{
    // Просто вызываем готоваую функцию из SPL и ждем, пока данные улетят
    I2C_SendData(I2Cx, data);
    while(!I2C_IsMasterByteTransmitted(I2Cx));
}
 
//-----------------------------------------------------------------------------
uint8_t I2C_ReadData(I2C_TypeDef* I2Cx)
{
    uint8_t data;
    // Тут картина похожа, как только данные пришли быстренько считываем их и возвращаем
    while( !I2C_IsMasterByteReceived(I2Cx) );
    data = I2C_ReceiveData(I2Cx);
    return data;
}

//-----------------------------------------------------------------------------
/*
bool I2C_IsMasterByteTransmitted(I2C_TypeDef* I2Cx)
{
    return I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED) ? true : false;
}

//-----------------------------------------------------------------------------
bool I2C_IsMasterByteReceived(I2C_TypeDef* I2Cx)
{
    return I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED) ? true : false;
}
*/
//-----------------------------------------------------------------------------
bool I2C_TryWriteData(I2C_TypeDef* I2Cx, uint8_t data, const ISoftTimer &asyncDelay)
{
    // Просто вызываем готоваую функцию из SPL и ждем, пока данные улетят
    I2C_SendData(I2Cx, data);

    while(!asyncDelay.isTimedOut() && !I2C_IsMasterByteTransmitted(I2Cx) ) {}

    // Если сработал таймаут, то проверка состояния не производится, и биты состояния,
    // которые могла сбросить проверка, будут ждать следующей попытки их прочитать
    if (asyncDelay.isTimedOut())
       return false;

    return true;
}

//-----------------------------------------------------------------------------
bool I2C_TryWriteData(I2C_TypeDef* I2Cx, uint8_t data, umba::time_service::TimeTick timeout)
{
    SoftTimerMillisec asyncDelay(timeout);
    return I2C_TryWriteData(I2Cx, data, asyncDelay);
} 
 
//-----------------------------------------------------------------------------
bool I2C_TryReadData(I2C_TypeDef* I2Cx, uint8_t &data, const ISoftTimer &asyncDelay )
{
    // Тут картина похожа, как только данные пришли быстренько считываем их и возвращаем
    while(!asyncDelay.isTimedOut() &&  !I2C_IsMasterByteReceived(I2Cx)) {}
    if (asyncDelay.isTimedOut())
       return false;

    data = I2C_ReceiveData(I2Cx);
    return true;
}

//-----------------------------------------------------------------------------
bool I2C_TryReadData(I2C_TypeDef* I2Cx, uint8_t &data, umba::time_service::TimeTick timeout)
{
    SoftTimerMillisec asyncDelay(timeout);
    return I2C_TryReadData(I2Cx, data, asyncDelay);
}
