#pragma once

#include "umba.h"

#include <stdint.h>
#include <stddef.h>

//#include "global_macros/global_macros.h"
#include "soft_timer.h"

#include "umba/simple_formatter.h"

extern umba::SimpleFormatter  lout;


#include <stdio.h>
#include <string.h>
#include <stdarg.h>

//#define USE_DEBUG_PRINT
//#define DEBUG_I2C


#ifdef USE_DEBUG_PRINT

    //#define DEBUG_PRINT(...) printf(__VA_ARGS__)
    #define UMBA_DEBUG_PRINT(...)          umba_debug_printf(__VA_ARGS__)
    #define UMBA_DEBUG_PRINT_WAIT_FOR()    ubma_debug_printf_wait_for()
    #define UMBA_DEBUG_WAIT_PRINT(...)     do{ ubma_debug_printf_wait_for(); umba_debug_printf(__VA_ARGS__); } while(0)

    #define UMBA_DEBUG_PUTS(s)             umba_debug_puts(s)
    #define UMBA_DEBUG_WAIT_PUTS(s)        do{ ubma_debug_printf_wait_for(); umba_debug_puts(s); } while(0)

#else

    #define UMBA_DEBUG_PRINT(...)          do{} while(0)
    #define UMBA_DEBUG_PRINT_WAIT_FOR()    do{} while(0)
    #define UMBA_DEBUG_WAIT_PRINT(...)     do{} while(0)

    #define UMBA_DEBUG_PUTS(s)             do{} while(0)
    #define UMBA_DEBUG_WAIT_PUTS(s)        do{} while(0)

#endif


#if defined(UMBA_GCC_COMPILER_USED)
    int umba_debug_printf( const char *format, ... ) __attribute__((format(printf, 1, 2)));
#else
    int umba_debug_printf( const char *format, ... );
#endif


inline
void ubma_debug_printf_wait_for()
{}

inline
void umba_debug_puts( const char *s )
{
    lout<<s;
}

inline
int umba_debug_printf( const char *format, ... )
{
    //static char buf[512];

    //if (!uart::uart1.isTransmitComplete())
    //    return 0;

/*
    char crlfExpandedFormat[500];
    size_t i = 0, expFmtBufSize = sizeof(crlfExpandedFormat);
    bool prevCr = false;
    for(; i<(expFmtBufSize-2) && *format; ++i, ++format)
    {
        if (*format=='\n')
        {
            if (!prevCr)
                crlfExpandedFormat[i++] = '\r';
            crlfExpandedFormat[i] = *format;
            prevCr = false;
        }
        else if (*format=='\r')
        {
            crlfExpandedFormat[i] = *format;
            prevCr = true;
        }
        else
        {
            crlfExpandedFormat[i] = *format;
            prevCr = false;
        }
    }

    crlfExpandedFormat[i] = 0;
*/
    char bufTmp[512];

    va_list args;
    va_start (args, format);
    int numCharsPrinted = vsnprintf(bufTmp,sizeof(bufTmp)-1, format, args );
    va_end (args);

    bufTmp[sizeof(bufTmp)-1] = 0;

    //UMBA_CRITICAL_SECTION_EX(umba::CriticalSection, umba::globalCriticalSection);
    //if (!uart::uart1.isTransmitComplete())
    //    return 0;

    //memcpy ( (void*)buf, (void*)bufTmp, sizeof(bufTmp) );
    //uart::uart1.sendLocalArray((const uint8_t*)buf, numCharsPrinted );
    lout<<bufTmp;
    return numCharsPrinted;
}



#ifdef DEBUG_I2C

    #define I2C_NONBLOCKING_PRINT(...)    UMBA_DEBUG_PRINT(__VA_ARGS__)
    #define I2C_BLOCKING_PRINT(...)       UMBA_DEBUG_WAIT_PRINT(__VA_ARGS__)
    #define I2C_BLOCKING_PUTS(s)          UMBA_DEBUG_WAIT_PUTS(s)

#else

    #define I2C_NONBLOCKING_PRINT(...)    do {} while(0) /*(void)*/
    #define I2C_BLOCKING_PRINT(...)       do {} while(0) /*(void)*/
    #define I2C_BLOCKING_PUTS(s)          do {} while(0) /*(void)*/

#endif

//#include "debug_print.h"


//-----------------------------------------------------------------------------
struct II2cInitializer
{
    virtual void initialize( ) = 0;
    virtual void reset( ) = 0;

};
//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
class I2cPort
{

public:

    //STRONG_ENUM( 
    enum class State {
    State, FAIL = -1    //! batch is completed with fail condition
                       , DONE = 0     //! batch is done
                       , SUCCESS = 0
                       , INPROGRESS   //! batch in progess
                       , READY        //! ready to start
    };

    //STRONG_ENUM( 
    
    enum class Operation { START, WRITE, READ };

    I2cPort( I2C_TypeDef *I2Cx = 0, II2cInitializer *pInitializer = 0, ISoftTimer *pTimer = 0
           , ISoftTimer::TimeTick busTimeout = 0
           , ISoftTimer::TimeTick opTimeout = 0
           );

    void setInitializer( II2cInitializer *pInitializer );
    void setTimer( ISoftTimer *pTimer );
    void setTimeout( ISoftTimer::TimeTick busTimeout, ISoftTimer::TimeTick opTimeout );
    void setHwInterface( I2C_TypeDef *I2Cx );

    ISoftTimer::TimeTick getTimerTimeout() const ;
    ISoftTimer::TimeTick getTimerElapsed() const;
    ISoftTimer::TimeTick getTimerStartTick() const;
    ISoftTimer::TimeTick getTimerTimedoutTick() const;
    ISoftTimer::TimeTick getTimerTimedoutElapsed() const;

    // can return only FAIL or SUCCESS
    State addReadBatch ( uint8_t *pReadBuf , size_t readNumBytes  );
    State addWriteBatch( uint8_t *pWriteBuf, size_t writeNumBytes );

    uint8_t* getReadBuf ( );
    uint8_t* getWriteBuf( );
    size_t   getNumBytesReaded( ) const;
    size_t   getNumBytesWritten( ) const;

    void init();
    void init( I2C_TypeDef *I2Cx, II2cInitializer *pInitializer, ISoftTimer *pTimer = 0
             , ISoftTimer::TimeTick busTimeout = 0
             , ISoftTimer::TimeTick opTimeout = 0
             );
    void reset();


    void resetBatch();
    void setBatchPeerAddr(uint8_t peerAddr);
    uint8_t getBatchPeerAddr();
    State startBatch();
    State performBatchStep();

    State getState() const;

    bool isReadyToStartState(State state) const;
    bool isReadyToStartState() const;

    bool isFinalState(State state) const;
    bool isFinalState() const;

    bool isFailState(State state) const;
    bool isFailState() const;

    Operation getOperation() const;

protected:

    //STRONG_ENUM( 
    enum class AutomataState{
                 WAIT_BEGIN_BATCH
               , WAIT_UNTIL_BUS_BUSY
               , WAIT_MASTER_MODE_SELECT
               , WAIT_MASTER_TRANSMITTER_MODE_SELECTED
               , WAIT_MASTER_RECEIVER_MODE_SELECTED
               , TRANSMIT_BYTES
               , RECEIVE_BYTES
               , DONE
               , FAIL
    };

    // return it's argument, but can modify it
    // Usage: m_automataState = onTransition(newState);
    AutomataState onTransition( AutomataState nextState );
    bool isTimedOut() const;
    void restartTimer() const;
    void sendStop();

    I2C_TypeDef     *m_I2Cx;
    uint8_t          m_peerAddr;

    II2cInitializer *m_pInitializer;
    ISoftTimer      *m_pTimer;
    ISoftTimer::TimeTick m_opTimeout;
    ISoftTimer::TimeTick m_busTimeout;

    AutomataState      m_automataState;
    Operation  m_curOperation;

    uint8_t         *m_pWriteBuf;
    size_t           m_writeNumBytes;
    size_t           m_numBytesWritten;

    uint8_t         *m_pReadBuf;
    size_t           m_readNumBytes;
    size_t           m_numBytesReaded;

    size_t           m_triesCount;
    size_t           m_triesCountMax;

};


//-----------------------------------------------------------------------------
inline
void blockingWrite( I2cPort &i2c, uint8_t addr, uint8_t *pData, size_t dataSize)
{
    if (i2c.getState()!=I2cPort::State::READY)
       i2c.reset();

    i2c.setBatchPeerAddr(addr);
    i2c.addWriteBatch( pData, dataSize );

    while(true)
    {
        I2cPort::State status = i2c.startBatch();
        if (status==I2cPort::State::FAIL)
        {
            i2c.reset();
            continue;
        }

        while(status==I2cPort::State::INPROGRESS)
        {
            status = i2c.performBatchStep();
        }

        if (status==I2cPort::State::FAIL)
        {
            i2c.reset();
            continue;
        }

        i2c.reset();
        return;
    }
}
//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
#ifdef UMBA_CXX_HAS_STD11
// i2c must be configured for batch
// CompletionHandler must be in form
// void handler(bool fFail, I2cPort &i2c)
template< typename CompletionHandler >
struct I2cSingleBatchWorker
{

    I2cSingleBatchWorker( I2cPort &i2c, CompletionHandler handler )
    : m_i2c(i2c)
    , m_handler(handler)
    {
    }

    // return true if started
    bool startBatch()
    {
        I2C_BLOCKING_PUTS("S: SB\n");
        if (!m_i2c.isReadyToStartState())
        {    
            I2C_BLOCKING_PUTS("S: ret false\n");
            return false;
        }
        I2C_BLOCKING_PUTS("S: SB Ok\n");
        m_i2c.startBatch();
        return true;
    }

    // return true if step performed
    bool performBatchStep()
    {
        I2C_BLOCKING_PUTS("S: STP\n");
        //i2c.performBatchStep();
        I2cPort::State i2cState = m_i2c.getState();
        if (m_i2c.isReadyToStartState(i2cState))
        {
           I2C_BLOCKING_PUTS("S: ret false\n");
           return false; // step not performed, need to call startBatch first
        }

        I2C_BLOCKING_PUTS("S: SB\n");
        if (m_i2c.isFinalState(i2cState))
        {
            I2C_BLOCKING_PUTS("S: FIN\n");
            m_handler(m_i2c.isFailState(), m_i2c);
            m_i2c.reset();
            return false;
        }

        I2C_BLOCKING_PUTS("S: DO STP\n");
        m_i2c.performBatchStep();
        return true;
    }

    bool isDone() const
    {
        I2C_BLOCKING_PUTS("S: DN\n");
        if (m_i2c.isFinalState())
        {
            I2C_BLOCKING_PUTS("S: DN done\n");
            return true;
        }

        I2C_BLOCKING_PUTS("S: !DN\n");
        return false;
    }


protected:

    I2cPort            &m_i2c;
    CompletionHandler  m_handler;

}; // struct I2cSingleBatchWorker



template< typename CompletionHandler >
I2cSingleBatchWorker<CompletionHandler> makeI2cSingleBatchWorker( I2cPort &i2c, CompletionHandler handler )
{
    return I2cSingleBatchWorker<CompletionHandler>( i2c, handler );
}

#endif /* UMBA_CXX_HAS_STD11 */
//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
struct II2cCompletionHandler{

    // return true to continue batch list processing on fail condition
    // return false to try again current failed entry
    // no mean on success events
    virtual bool onI2cCompletion( bool fFail, I2cPort &i2c ) = 0;

}; // struct II2cCompletionHandler
//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
struct I2cBatchListEntry
{
    enum EntryType  { LISTEND       = 0x00  //! Marks final (and not used) entry
                    , WRITE         = 0x01  //! Write entry
                    , READ          = 0x02  //! Read entry
                    , SKIP          = 0x10  //! Skip entry/bit
                    , ONESHOT       = 0x20  //! single time action flag
                    , ONESHOT_WRITE = 0x20 | 0x01
                    , ONESHOT_READ  = 0x20 | 0x02
                    , FLAGS_MASK    = 0x20 | 0x10
                    };

    enum ComplexType{ SIMPLE      = 0  //! Single entry
                    , CONDITIONAL = 1  //! if prev op was failed, all next CONDITIONAL entries are failed
                    };

    EntryType                entryType;
    ComplexType              complexType;
    uint8_t                  deviceBusAddr; // ignored in the first entry in complex write-read batch
    uint8_t                 *pData;
    size_t                   numBytes;   // can be 0, in that case entry simple skipped
    II2cCompletionHandler   *pCompletionHandler; // can be 0, ignored in the first entry in complex write-read batch

    bool isEnd() const;
    bool isRead() const;
    bool isWrite() const;
    bool isOneShot() const;
    bool isSkip() const;

    void makeSkipped();
    void makeUnskipped();
    void makeOneShot();
    void makeRegularShot();
}; // struct I2cBatchListEntry
//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------
struct I2cBatchListWorker
{
    I2cBatchListWorker( I2cPort &i2c, I2cBatchListEntry *pBatchList );

    void setBatchList( I2cBatchListEntry *pBatchList ); // reuse Worker with plural Batch Lists

    bool startBatch();
    bool performBatchStep();
    bool isDone() const;

    size_t getCondSkippedCount() const;
    size_t getExecutedCount() const;
    bool   isBatchListCompleted() const;

protected:

    bool isLastIndex(size_t idx) const;

    I2cPort               &m_i2c;
    I2cBatchListEntry     *m_pBatchList;
    size_t                 m_curEntry;
    bool                   m_fDone;
    size_t                 m_executedJobsCount;
    size_t                 m_condSkippedJobsCount;
}; // struct I2cBatchListWorker
//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
template< typename HandlerFunctor >
struct I2cCompletionHandlerGeneric : public II2cCompletionHandler{

    I2cCompletionHandlerGeneric( HandlerFunctor handlerFunctor)
    : m_handlerFunctor(handlerFunctor)
    {}

    virtual bool onI2cCompletion( bool fFail, I2cPort &i2c )
    {
        m_handlerFunctor(fFail, i2c);
        return true;
    }

protected:

    HandlerFunctor m_handlerFunctor;

}; // struct I2cCompletionHandlerGeneric


template < typename HandlerFunctor >
I2cCompletionHandlerGeneric<HandlerFunctor>
makeI2cCompletionHandlerGeneric( HandlerFunctor handlerFunctor )
{
    return I2cCompletionHandlerGeneric<HandlerFunctor>(handlerFunctor);
}
//-----------------------------------------------------------------------------



