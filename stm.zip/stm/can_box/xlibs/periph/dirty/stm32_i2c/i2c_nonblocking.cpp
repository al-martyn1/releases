#include "i2c_nonblocking.h"
#include "i2c_helpers.h"

#include <stdio.h>

//#include "debug_print.h"


// https://embedjournal.com/two-wire-interface-i2c-protocol-in-a-nut-shell/
// http://altor1.narod.ru/Articles/I2C_RP.pdf
// http://catethysis.ru/stm32_i2c/

//class I2cPort

//STRONG_ENUM( State, FAIL = -1, SUCCESS, INPROGRESS_START, INPROGRESS_READ, INPROGRESS_WRITE, );

//-----------------------------------------------------------------------------
I2cPort::I2cPort( I2C_TypeDef *I2Cx
                , II2cInitializer *pInitializer
                , ISoftTimer *pTimer
                , ISoftTimer::TimeTick busTimeout
                , ISoftTimer::TimeTick opTimeout
                )
: m_I2Cx(I2Cx)
, m_peerAddr(0)
, m_pInitializer(pInitializer)
, m_pTimer(pTimer)
, m_opTimeout(opTimeout ? opTimeout : busTimeout)
, m_busTimeout(busTimeout)
, m_automataState(I2cPort::AutomataState::WAIT_BEGIN_BATCH)
, m_curOperation(I2cPort::Operation::START)
, m_pWriteBuf(0)
, m_writeNumBytes(0)
, m_numBytesWritten(0)
, m_pReadBuf(0)
, m_readNumBytes(0)
, m_numBytesReaded(0)
, m_triesCount(0)
, m_triesCountMax(3)
{
}

//-----------------------------------------------------------------------------
void I2cPort::setInitializer( II2cInitializer *pInitializer )
{
    m_pInitializer = pInitializer;
}

//-----------------------------------------------------------------------------
void I2cPort::setTimer( ISoftTimer *pTimer )
{
    m_pTimer = pTimer;
}

//-----------------------------------------------------------------------------
void I2cPort::setTimeout( ISoftTimer::TimeTick busTimeout, ISoftTimer::TimeTick opTimeout )
{
    m_opTimeout = opTimeout;
    m_busTimeout = busTimeout;
}

//-----------------------------------------------------------------------------
void I2cPort::setHwInterface( I2C_TypeDef *I2Cx )
{
    m_I2Cx = I2Cx;
}

//-----------------------------------------------------------------------------
void I2cPort::resetBatch()
{
    m_pWriteBuf = 0;
    m_writeNumBytes = 0;
    m_pReadBuf = 0;
    m_readNumBytes = 0;
    m_peerAddr = 0;
    m_triesCount = 0;
}

//-----------------------------------------------------------------------------
uint8_t* I2cPort::getReadBuf ( )
{
    return m_pReadBuf;
}

//-----------------------------------------------------------------------------
uint8_t* I2cPort::getWriteBuf( )
{
    return m_pWriteBuf;
}

//-----------------------------------------------------------------------------
size_t   I2cPort::getNumBytesReaded( ) const
{
    return m_numBytesReaded;
}

//-----------------------------------------------------------------------------
size_t   I2cPort::getNumBytesWritten( ) const
{
    return m_numBytesWritten;
}

//-----------------------------------------------------------------------------
void I2cPort::setBatchPeerAddr(uint8_t peerAddr)
{
    m_peerAddr = peerAddr;
}

//-----------------------------------------------------------------------------
uint8_t I2cPort::getBatchPeerAddr()
{
    return m_peerAddr;
}

//-----------------------------------------------------------------------------
// can return only FAIL or SUCCESS
I2cPort::State I2cPort::addReadBatch ( uint8_t *pReadBuf , size_t readNumBytes  )
{
    State curStatus = getState();
    if (curStatus==State::INPROGRESS)
       return State::FAIL; // can't change data buf when operations are in progress

    m_pReadBuf       = pReadBuf;
    m_readNumBytes   = readNumBytes;
    m_numBytesReaded = 0;

    return State::SUCCESS;
}

//-----------------------------------------------------------------------------
// can return only FAIL or SUCCESS
I2cPort::State I2cPort::addWriteBatch( uint8_t *pWriteBuf, size_t writeNumBytes )
{
    State curStatus = getState();
    if (curStatus==State::INPROGRESS)
       return State::FAIL; // can't change data buf when operations are in progress

    m_pWriteBuf       = pWriteBuf;
    m_writeNumBytes   = writeNumBytes;
    m_numBytesWritten = 0;

    return State::SUCCESS;
}

//-----------------------------------------------------------------------------
bool I2cPort::isTimedOut() const
{
    if (!m_pTimer) // no timer taken, timed out event never occurs
       return false;
    return m_pTimer->isTimedOut();
}

//-----------------------------------------------------------------------------
void I2cPort::restartTimer() const
{
    if (m_pTimer)
       m_pTimer->reset( m_opTimeout );
}

//-----------------------------------------------------------------------------
ISoftTimer::TimeTick I2cPort::getTimerTimeout() const 
{
    if (!m_pTimer)
       return 0;
    return m_pTimer->getTimeout();
}

//-----------------------------------------------------------------------------
ISoftTimer::TimeTick I2cPort::getTimerElapsed() const
{
    if (!m_pTimer)
       return 0;
    return m_pTimer->getElapsedTicks();
}

//-----------------------------------------------------------------------------
ISoftTimer::TimeTick I2cPort::getTimerStartTick() const
{
    if (!m_pTimer)
       return 0;
    return m_pTimer->getStartTick();
}

//-----------------------------------------------------------------------------
ISoftTimer::TimeTick I2cPort::getTimerTimedoutElapsed() const
{
    if (!m_pTimer)
       return 0;
    return m_pTimer->getTimedoutElapsed();
}

//-----------------------------------------------------------------------------
ISoftTimer::TimeTick I2cPort::getTimerTimedoutTick() const
{
    if (!m_pTimer)
       return 0;
    return m_pTimer->getTimedoutTick();
}

//-----------------------------------------------------------------------------
I2cPort::AutomataState I2cPort::onTransition( AutomataState nextState  )
{
    if (m_automataState!=AutomataState::FAIL)
       restartTimer();
    return nextState;
}

//-----------------------------------------------------------------------------
bool I2cPort::isReadyToStartState(State state) const
{
    return state==State::READY;
}

//-----------------------------------------------------------------------------
bool I2cPort::isReadyToStartState() const
{
    return isReadyToStartState(getState());
}

//-----------------------------------------------------------------------------
bool I2cPort::isFinalState(State state) const
{
    return state==State::DONE || state==State::FAIL;
}

//-----------------------------------------------------------------------------
bool I2cPort::isFinalState() const
{
    return isFinalState(getState());
}

//-----------------------------------------------------------------------------
bool I2cPort::isFailState(State state) const
{
    return state==State::FAIL;
}

//-----------------------------------------------------------------------------
bool I2cPort::isFailState() const
{
    return isFailState(getState());
}

//-----------------------------------------------------------------------------
I2cPort::State I2cPort::getState() const
{
    switch(m_automataState)
    {
        case AutomataState::WAIT_BEGIN_BATCH :
             return State::READY;

        case AutomataState::DONE :
             return State::DONE;

        case AutomataState::FAIL :
             return State::FAIL;

        default:            
             return State::INPROGRESS;
    }
}

//-----------------------------------------------------------------------------
void I2cPort::init()
{
    UMBA_ASSERT(m_I2Cx);
    UMBA_ASSERT(m_pInitializer);
    m_pInitializer->initialize();
}

//-----------------------------------------------------------------------------
void I2cPort::init( I2C_TypeDef *I2Cx, II2cInitializer *pInitializer, ISoftTimer *pTimer
                  , ISoftTimer::TimeTick busTimeout
                  , ISoftTimer::TimeTick opTimeout
                  )
{
    setHwInterface( I2Cx );
    setInitializer( pInitializer );
    setTimer( pTimer );
    setTimeout( busTimeout, opTimeout ? opTimeout : busTimeout );
    init();
}

//-----------------------------------------------------------------------------
void I2cPort::reset()
{
    if (m_automataState!=AutomataState::DONE && m_automataState!=AutomataState::WAIT_BEGIN_BATCH)
       {
        I2C_BLOCKING_PUTS("A:RST\n");
        UMBA_ASSERT(m_pInitializer);
        m_pInitializer->reset();
       }

    m_automataState = AutomataState::WAIT_BEGIN_BATCH;
}

//-----------------------------------------------------------------------------
void I2cPort::sendStop()
{
    I2C_GenerateSTOP(m_I2Cx, ENABLE);
    m_pInitializer->reset();
}

//-----------------------------------------------------------------------------
I2cPort::State I2cPort::startBatch()
{
    UMBA_ASSERT(m_I2Cx);
    UMBA_ASSERT(m_pInitializer);

    UMBA_ASSERT(( m_pWriteBuf && m_writeNumBytes) || (m_pReadBuf && m_readNumBytes) );

    UMBA_ASSERT(m_automataState==AutomataState::WAIT_BEGIN_BATCH);

    m_triesCount = 0;

    m_numBytesWritten = 0;
    m_numBytesReaded  = 0;

    m_automataState = onTransition( AutomataState::WAIT_UNTIL_BUS_BUSY );

    //restartTimer();
    if (m_pTimer)
       m_pTimer->reset( m_busTimeout );

    m_curOperation = Operation::START;
    //Operation, START, WRITE, READ

    return performBatchStep();
}

//-----------------------------------------------------------------------------
I2cPort::State I2cPort::performBatchStep()
{
    switch(m_automataState)
    {
        case AutomataState::WAIT_UNTIL_BUS_BUSY :
        {
             I2C_BLOCKING_PUTS("A:WT_BUS\n");
             if (!I2C_IsBusy(m_I2Cx))
             {
                 I2C_BLOCKING_PUTS("A:WT_BUS: !busy\n");
                 I2C_GenerateSTART(m_I2Cx, ENABLE);                 
                 m_automataState = onTransition( AutomataState::WAIT_MASTER_MODE_SELECT );
                 I2C_BLOCKING_PUTS("A:WT_BUS: BR\n");
                 break;
             }

             #ifdef DEBUG_I2C
             ISoftTimer::TimeTick to = getTimerTimeout();
             ISoftTimer::TimeTick el = getTimerElapsed();
             #endif
             //I2C_BLOCKING_PUTS("A:WT_BUS: busy\n");
             I2C_BLOCKING_PRINT("A:WT_BUS: busy, timeout: %d, elapsed: %d\n", to, el );
             if (isTimedOut())
             {
                 #ifdef DEBUG_I2C
                 ISoftTimer::TimeTick stTick = getTimerStartTick();
                 ISoftTimer::TimeTick tdTick = getTimerTimedoutTick();
                 ISoftTimer::TimeTick tdEl   = getTimerTimedoutElapsed();
                 #endif

                 I2C_BLOCKING_PRINT("A:WT_BUS: TO, timeout: %d, elapsed: %d, started: %d, timedout at: %d, from start to timeout: %d\n", to, el, stTick, tdTick, tdEl );
                 #ifdef DEBUG_I2C
                 if (el<to)
                    I2C_BLOCKING_PRINT("A:WT_BUS: TO, wow\n" );
                 #endif

                 if (m_triesCount >= m_triesCountMax)
                 {   
                     m_automataState = onTransition( AutomataState::FAIL );
                     I2C_BLOCKING_PUTS("A:WT_BUS: INIT COUNT EXCEEDS\n");
                     m_triesCount = 0;
                 }
                 else
                 {
                     m_pInitializer->reset();
                     if (m_pTimer)
                        m_pTimer->reset( m_busTimeout );
                     m_triesCount++;
                     I2C_BLOCKING_PUTS("A:WT_BUS: TRY INIT NEXT TIME\n");
                 }
             }
             I2C_BLOCKING_PUTS("A:WT_BUS: BR\n");
             break;
        }

        case AutomataState::WAIT_MASTER_MODE_SELECT :
        {
             I2C_BLOCKING_PUTS("A:WT_MS_MSEL\n");
             if (I2C_IsEventMasterNodeSelect(m_I2Cx))
             {
                 I2C_BLOCKING_PUTS("A:WT_MS_MSEL: Ok\n");
                 bool writeFirst = m_pWriteBuf ? true : false;
                 #if defined(STM32F4_SERIES)
                 I2C_Send7bitAddress(m_I2Cx, m_peerAddr<<1, writeFirst ? I2C_Direction_Transmitter : I2C_Direction_Receiver );
                 #else
                     #if defined(__CC_ARM)
                         #warning Undone - current family not supported
                     #else
                         #pragma message("Undone - current family not supported")
                     #endif
                 #endif


                 m_automataState = onTransition( writeFirst ? AutomataState::WAIT_MASTER_TRANSMITTER_MODE_SELECTED : AutomataState::WAIT_MASTER_RECEIVER_MODE_SELECTED );
                 I2C_BLOCKING_PUTS("A:WT_MS_MSEL: BR\n");
                 break;
             }
             I2C_BLOCKING_PUTS("A:WT_MS_MSEL: notrdy\n");
             if (isTimedOut())
             {
                 //I2C_BLOCKING_PUTS("A:WT_MS_MSEL: TO\n");
                 #ifdef DEBUG_I2C
                 ISoftTimer::TimeTick to = getTimerTimeout();
                 ISoftTimer::TimeTick el = getTimerElapsed();
                 ISoftTimer::TimeTick stTick = getTimerStartTick();
                 ISoftTimer::TimeTick tdTick = getTimerTimedoutTick();
                 ISoftTimer::TimeTick tdEl   = getTimerTimedoutElapsed();
                 #endif
                 I2C_BLOCKING_PRINT("A:WT_MS_MSEL: TO, timeout: %d, elapsed: %d, started: %d, timedout at: %d, from start to timeout: %d\n", to, el, stTick, tdTick, tdEl );
                 m_automataState = onTransition( AutomataState::FAIL );
             }
             I2C_BLOCKING_PUTS("A:WT_MS_MSEL: BR\n");
             break;
        }

        case AutomataState::WAIT_MASTER_TRANSMITTER_MODE_SELECTED :
        {
             I2C_BLOCKING_PUTS("A:WT_MS_TRSEL\n");
             if (I2C_IsEventMasterTransmitterModeSelected(m_I2Cx))
             {
                 I2C_BLOCKING_PUTS("A:WT_MS_TRSEL: Ok\n");
                 // write byte
                 I2C_SendData(m_I2Cx, m_pWriteBuf[m_numBytesWritten++]);
                 m_curOperation = Operation::WRITE;
                 m_automataState = onTransition(AutomataState::TRANSMIT_BYTES);
                 I2C_BLOCKING_PUTS("A:WT_MS_TRSEL: BR\n");
                 break;
             }
             I2C_BLOCKING_PUTS("A:WT_MS_TRSEL: notrdy\n");
             if (isTimedOut())
             {
                 //I2C_BLOCKING_PUTS("A:WT_MS_TRSEL: TO\n");
                 #ifdef DEBUG_I2C
                 ISoftTimer::TimeTick to = getTimerTimeout();
                 ISoftTimer::TimeTick el = getTimerElapsed();
                 ISoftTimer::TimeTick stTick = getTimerStartTick();
                 ISoftTimer::TimeTick tdTick = getTimerTimedoutTick();
                 ISoftTimer::TimeTick tdEl   = getTimerTimedoutElapsed();
                 #endif
                 I2C_BLOCKING_PRINT("A:WT_MS_TRSEL: TO, timeout: %d, elapsed: %d, started: %d, timedout at: %d, from start to timeout: %d\n", to, el, stTick, tdTick, tdEl );
                 m_automataState = onTransition( AutomataState::FAIL );
             }
             I2C_BLOCKING_PUTS("A:WT_MS_TRSEL: BR\n");
             break;
        }

        case AutomataState::WAIT_MASTER_RECEIVER_MODE_SELECTED :
        {
             I2C_BLOCKING_PUTS("A:WT_MS_RCVSEL\n");
             if (I2C_IsEventMasterReceiverModeSelected(m_I2Cx))
             {
                 I2C_BLOCKING_PUTS("A:WT_MS_RCVSEL: OK\n");
                 m_curOperation = Operation::READ;
                 m_automataState = onTransition(AutomataState::RECEIVE_BYTES);
                 I2C_BLOCKING_PUTS("A:WT_MS_RCVSEL: BR\n");
                 if (m_readNumBytes<2)
                     I2C_AcknowledgeConfig(m_I2Cx, DISABLE);
                 else
                     I2C_AcknowledgeConfig(m_I2Cx, ENABLE);
                 break;
             }
             I2C_BLOCKING_PUTS("A:WT_MS_RCVSEL: notrdy\n");
             if (isTimedOut())
             {
                 //I2C_BLOCKING_PUTS("A:WT_MS_RCVSEL: TO\n");
                 #ifdef DEBUG_I2C
                 ISoftTimer::TimeTick to = getTimerTimeout();
                 ISoftTimer::TimeTick el = getTimerElapsed();
                 ISoftTimer::TimeTick stTick = getTimerStartTick();
                 ISoftTimer::TimeTick tdTick = getTimerTimedoutTick();
                 ISoftTimer::TimeTick tdEl   = getTimerTimedoutElapsed();
                 #endif
                 I2C_BLOCKING_PRINT("A:WT_MS_RCVSEL: TO, timeout: %d, elapsed: %d, started: %d, timedout at: %d, from start to timeout: %d\n", to, el, stTick, tdTick, tdEl );
                 m_automataState = onTransition( AutomataState::FAIL );
             }
             I2C_BLOCKING_PUTS("A:WT_MS_RCVSEL: BR\n");
             break;
        }

        case AutomataState::TRANSMIT_BYTES :
        {
             I2C_BLOCKING_PUTS("A:TR_BTS\n");
             if (I2C_IsMasterByteTransmitted(m_I2Cx))
             {
                 I2C_BLOCKING_PUTS("A:TR_BTS: OK\n");
                 if (m_numBytesWritten>=m_writeNumBytes)
                 {
                     I2C_BLOCKING_PUTS("A:TR_BTS: ALL, STOP\n");
                     //I2C_GenerateSTOP(m_I2Cx, ENABLE);
                     sendStop();
                     m_automataState = onTransition(AutomataState::DONE);
                     I2C_BLOCKING_PUTS("A:TR_BTS: BR\n");
                     break;
                 }
                I2C_BLOCKING_PUTS("A:TR_BTS: SND NXT\n");
                // Send next byte
                I2C_SendData(m_I2Cx, m_pWriteBuf[m_numBytesWritten++]);
                I2C_BLOCKING_PUTS("A:TR_BTS: TIM RST\n");
                I2C_BLOCKING_PUTS("A:TR_BTS: BR\n");
                restartTimer();
                break;
             }
             I2C_BLOCKING_PUTS("A:TR_BTS: notrdy\n");

             if (isTimedOut())
             {
                 I2C_BLOCKING_PUTS("A:TR_BTS: TO\n");
                 if (m_triesCount >= m_triesCountMax)
                 {   
                     m_automataState = onTransition( AutomataState::FAIL );
                     I2C_BLOCKING_PUTS("A:TR_BTS: TRY COUNT EXCEEDS\n");
                     m_triesCount = 0;
                 }
                 else
                 {
                     m_triesCount++;
                     I2C_BLOCKING_PUTS("A:TR_BTS: TRY NEXT TIME\n");
                     restartTimer();
                 }
             }

             I2C_BLOCKING_PUTS("A:TR_BTS: BR\n");
             break;
        }

        // перед приемом первого байта необходимо выполнить I2C_AcknowledgeConfig(I2C2, ENABLE) и перед приемом последнего I2C_AcknowledgeConfig(I2C2, DISABLE)
        case AutomataState::RECEIVE_BYTES :
        {
             I2C_BLOCKING_PUTS("A:RCV_BTS\n");
             if (I2C_IsMasterByteReceived(m_I2Cx))
             {
                 I2C_BLOCKING_PUTS("A:RCV_BTS: OK\n");
                 m_pReadBuf[m_numBytesReaded++] = I2C_ReceiveData(m_I2Cx);
                 if (m_numBytesReaded>=m_readNumBytes)
                 {
                     I2C_BLOCKING_PUTS("A:RCV_BTS: ALL, STOP\n");
                     //I2C_GenerateSTOP(m_I2Cx, ENABLE);
                     sendStop();
                     //m_pInitializer->reset();
                     m_automataState = onTransition(AutomataState::DONE);
                     I2C_BLOCKING_PUTS("A:RCV_BTS: BR\n");
                     break;
                 }

                 if ((m_numBytesReaded+1)==m_readNumBytes)
                 {
                     I2C_BLOCKING_PUTS("A:RCV_BTS: NACK\n");
                     I2C_AcknowledgeConfig(m_I2Cx, DISABLE);
                 }

                 I2C_BLOCKING_PUTS("A:RCV_BTS: RCV NXT\n");
                 I2C_BLOCKING_PUTS("A:RCV_BTS: TIM RST\n");
                 restartTimer();
                 I2C_BLOCKING_PUTS("A:RCV_BTS: BR\n");
                 break;
             }

             I2C_BLOCKING_PUTS("A:RCV_BTS: notrdy\n");

             if (isTimedOut())
             {
                 I2C_BLOCKING_PUTS("A:RCV_BTS: TO\n");
                 if (m_triesCount >= m_triesCountMax)
                 {   
                     m_automataState = onTransition( AutomataState::FAIL );
                     I2C_BLOCKING_PUTS("A:RCV_BTS: TRY COUNT EXCEEDS\n");
                     m_triesCount = 0;
                 }
                 else
                 {
                     m_triesCount++;
                     I2C_BLOCKING_PUTS("A:RCV_BTS: TRY NEXT TIME\n");
                     restartTimer();
                 }
             }

             I2C_BLOCKING_PUTS("A:RCV_BTS: BR\n");
             break;
        }

        case AutomataState::WAIT_BEGIN_BATCH :
             I2C_BLOCKING_PUTS("A:WT_BB: BR\n");
             break;

        case AutomataState::DONE :
             I2C_BLOCKING_PUTS("A:DONE: BR\n");
             break;

        case AutomataState::FAIL :
             I2C_BLOCKING_PUTS("A:FAIL: BR\n");
             break;

        default:
             // WAIT_BEGIN_BATCH, DONE, FAIL
             // Do nothing
             // if state is WAIT_BEGIN_BATCH user must call startBatch()
             // if state is DONE or FAIL, user must call reset and then startBatch()
             return getState();
    };

    return getState();
}

//-----------------------------------------------------------------------------







//-----------------------------------------------------------------------------
bool I2cBatchListEntry::isEnd() const
{
    return entryType==LISTEND;
}

//-----------------------------------------------------------------------------
bool I2cBatchListEntry::isRead() const
{
    return (((unsigned)entryType) & (~(unsigned)FLAGS_MASK)) == (unsigned)READ;
}

//-----------------------------------------------------------------------------
bool I2cBatchListEntry::isWrite() const
{
    return (((unsigned)entryType) & (~(unsigned)FLAGS_MASK)) == (unsigned)WRITE;
}

//-----------------------------------------------------------------------------
bool I2cBatchListEntry::isOneShot() const
{
    return (((unsigned)entryType) & (unsigned)ONESHOT) ? true : false;
}

//-----------------------------------------------------------------------------
bool I2cBatchListEntry::isSkip() const
{
    return (((unsigned)entryType) & (unsigned)SKIP) ? true : false;
}

//-----------------------------------------------------------------------------
void I2cBatchListEntry::makeSkipped()
{
    entryType = (EntryType)(((unsigned)entryType) | ((unsigned)SKIP));
}

//-----------------------------------------------------------------------------
void I2cBatchListEntry::makeUnskipped()
{
    entryType = (EntryType)(((unsigned)entryType) & ~((unsigned)SKIP));
}

//-----------------------------------------------------------------------------
void I2cBatchListEntry::makeOneShot()
{
    entryType = (EntryType)(((unsigned)entryType) | ((unsigned)ONESHOT));
}

//-----------------------------------------------------------------------------
void I2cBatchListEntry::makeRegularShot()
{
    entryType = (EntryType)(((unsigned)entryType) & ~((unsigned)ONESHOT));
}

//-----------------------------------------------------------------------------







//-----------------------------------------------------------------------------
I2cBatchListWorker::I2cBatchListWorker( I2cPort &i2c, I2cBatchListEntry *pBatchList )
: m_i2c(i2c)
, m_pBatchList(pBatchList)
, m_curEntry(0)
, m_fDone(true)
, m_executedJobsCount(0)
, m_condSkippedJobsCount(0)
{
    UMBA_ASSERT(pBatchList);
}

//-----------------------------------------------------------------------------
void I2cBatchListWorker::setBatchList( I2cBatchListEntry *pBatchList ) // reuse Worker with plural Batch Lists
{
    UMBA_ASSERT(m_fDone);
    UMBA_ASSERT(pBatchList);
    m_pBatchList = pBatchList;
}

//-----------------------------------------------------------------------------
bool I2cBatchListWorker::isDone() const
{
    return m_fDone;
}

//-----------------------------------------------------------------------------
size_t I2cBatchListWorker::getCondSkippedCount() const
{
    return m_condSkippedJobsCount;
}

//-----------------------------------------------------------------------------
size_t I2cBatchListWorker::getExecutedCount() const
{
    return m_executedJobsCount;
}

//-----------------------------------------------------------------------------
bool I2cBatchListWorker::isBatchListCompleted() const
{
    if (!isDone())              return false;
    if (m_condSkippedJobsCount) return false;
    if (m_executedJobsCount)    return false;
    return true;
}

//-----------------------------------------------------------------------------
bool I2cBatchListWorker::startBatch()
{
    if (!m_fDone)
        return false; // already in progress

    m_curEntry = 0;
    m_fDone = false;

    m_executedJobsCount = 0;
    m_condSkippedJobsCount   = 0;

    return performBatchStep();
}

//-----------------------------------------------------------------------------
bool I2cBatchListWorker::isLastIndex(size_t idx) const
{
    return m_pBatchList[idx].isEnd();
}

//-----------------------------------------------------------------------------
bool I2cBatchListWorker::performBatchStep()
{
    if (m_fDone)
    {
        //I2C_BLOCKING_PUTS("W: m_fDone\n");
        return false;
    }

    if (isLastIndex(m_curEntry))
    {
        I2C_BLOCKING_PUTS("W: LastI\n");
        m_fDone = true;
        return true;
    }


    I2cPort::State i2cState = m_i2c.getState();

    if (m_i2c.isReadyToStartState(i2cState))
    {

        I2C_BLOCKING_PUTS("W: Ready\n");

        if (m_pBatchList[m_curEntry].isSkip()) // entryType==I2cBatchListEntry::SKIP
        {
            I2C_BLOCKING_PUTS("W: Step ET==SKIP\n");
            m_curEntry++;
            return true;
        }

        I2C_BLOCKING_PUTS("W: rstB\n");
        m_i2c.resetBatch();

        m_executedJobsCount++;

        if (m_pBatchList[m_curEntry].isWrite()) // entryType==I2cBatchListEntry::WRITE
        {
            I2C_BLOCKING_PUTS("W: ET==WRITE\n");
            UMBA_ASSERT(m_pBatchList[m_curEntry].pData);
            UMBA_ASSERT(m_pBatchList[m_curEntry].numBytes);

            m_i2c.setBatchPeerAddr(m_pBatchList[m_curEntry].deviceBusAddr);
            m_i2c.addWriteBatch( m_pBatchList[m_curEntry].pData, m_pBatchList[m_curEntry].numBytes );

            I2C_BLOCKING_PRINT("W: StartB, addr: 0x%02X\n", m_pBatchList[m_curEntry].deviceBusAddr);
            m_i2c.startBatch();

            return true;
        }

        // else - READ
        UMBA_ASSERT(m_pBatchList[m_curEntry].pData);
        UMBA_ASSERT(m_pBatchList[m_curEntry].numBytes);

        I2C_BLOCKING_PUTS("W: ET==READ\n");

        m_i2c.setBatchPeerAddr(m_pBatchList[m_curEntry].deviceBusAddr); // overwrite device addr
        m_i2c.addReadBatch( m_pBatchList[m_curEntry].pData, m_pBatchList[m_curEntry].numBytes );

        I2C_BLOCKING_PRINT("W: StartB, addr: 0x%02X\n", m_pBatchList[m_curEntry].deviceBusAddr);
        m_i2c.startBatch();
        return true;
    }

    //m_executedJobsCount = 0;
    //m_activeJobsCount   = 0;


    if (m_i2c.isFinalState(i2cState))
    {
        bool isFail = m_i2c.isFailState(i2cState);
        I2C_BLOCKING_PUTS("W: FinSt\n");
        if (m_pBatchList[m_curEntry].pCompletionHandler)
        {
            I2C_BLOCKING_PUTS("W: CallHdlr\n");
            m_pBatchList[m_curEntry].pCompletionHandler->onI2cCompletion( isFail, m_i2c );
        }

        if (!isFail)
        {
            I2C_BLOCKING_PUTS("W: !isFail\n");
            if (m_pBatchList[m_curEntry].isOneShot())
            {
                I2C_BLOCKING_PUTS("W: OS - makeSkipped\n");
                m_pBatchList[m_curEntry].makeSkipped();
            }
        }

        m_i2c.reset();
        m_curEntry++;
        while(isFail && !isLastIndex(m_curEntry) && m_pBatchList[m_curEntry].complexType==I2cBatchListEntry::CONDITIONAL)
        {
            m_condSkippedJobsCount++;
            I2C_BLOCKING_PUTS("W: skip CONDs on fail\n");
            m_curEntry++;
        }

        return true;
    }

    I2C_BLOCKING_PUTS("W: CallStp\n");

    m_i2c.performBatchStep();
    return true;
}

//-----------------------------------------------------------------------------

