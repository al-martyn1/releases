#pragma once

/*
#ifndef UMBA_DECLARE_WEAK_FUNCTION

    #if defined(UMBA_KEIL_ARMCC_COMPILER_USED)

        #define UMBA_DECLARE_WEAK_FUNCTION( funcFullSignature )   __weak funcFullSignature

    #elif defined(UMBA_GCC_COMPILER_USED) || defined(UMBA_KEIL_CLANG_COMPILER_USED)

        #define UMBA_DECLARE_WEAK_FUNCTION( funcFullSignature )   funcFullSignature __attribute__ ((weakref))

    #endif

#endif

#ifndef UMBA_DECLARE_WEAK_IRQ_HANDLER
    #define UMBA_DECLARE_WEAK_IRQ_HANDLER( funcName )     extern "C" UMBA_DECLARE_WEAK_FUNCTION( void funcName() )
#endif

#ifndef UMBA_WEAK_IRQ_HANDLER
    #define UMBA_WEAK_IRQ_HANDLER( funcName )             UMBA_DECLARE_WEAK_IRQ_HANDLER(funcName)
#endif
*/

/*
#ifndef UMBA_FORCE_INLINE

    #if defined(UMBA_KEIL_ARMCC_COMPILER_USED)

        #define UMBA_FORCE_INLINE( funcFullSignature )   __forceinline funcFullSignature

    #elif defined(UMBA_GCC_COMPILER_USED) || defined(UMBA_KEIL_CLANG_COMPILER_USED)

        #define UMBA_FORCE_INLINE( funcFullSignature )   inline __attribute__ ((always_inline)) funcFullSignature 

    #else

        #define UMBA_FORCE_INLINE( funcFullSignature )   inline funcFullSignature

    #endif

#endif
*/

#ifdef USE_PERIPH_EXPLICITLY
    #include "unusage.h"
#endif

#include "stm32_traits_base.h"

#define UMBA_PERIPH_STM32_TRAITS_INCLUDED


#if defined(STM32F1_SERIES)
    #if defined(STM32F3_SERIES)
        #error "STM32F1_SERIES and STM32F3_SERIES defined at the same time"
    #endif
    #if defined(STM32F4_SERIES)
        #error "STM32F1_SERIES and STM32F4_SERIES defined at the same time"
    #endif
#endif

#if defined(STM32F3_SERIES)
    #if defined(STM32F4_SERIES)
        #error "STM32F3_SERIES and STM32F4_SERIES defined at the same time"
    #endif
#endif



// Желательно определить для конкретного проекта точно, в соответствии с использованым чипом
// Если не задано, задаем значения по умолчанию

#ifndef STM32_PACKAGE_PIN_NUMBER

    #if defined(STM32F1_SERIES)

        #define STM32_PACKAGE_PIN_NUMBER      48

    #elif defined(STM32F3_SERIES)

        #define STM32_PACKAGE_PIN_NUMBER      64

    #elif defined(STM32F4_SERIES)

        #define STM32_PACKAGE_PIN_NUMBER     100

    #else

        #define STM32_PACKAGE_PIN_NUMBER      64

    #endif

#endif /* STM32_PACKAGE_PIN_NUMBER */


#define UMBA_PERIPH_GENERATE_FUNC_ALIAS_INLINE( orgName, aliasName, paramsDecl, params ) \
inline                                                                                   \
void aliasName paramsDecl                                                                \
{                                                                                        \
    orgName params;                                                                      \
}

#define UMBA_PERIPH_GENERATE_FUNC_RET_ALIAS_INLINE( retType, orgName, aliasName, paramsDecl, params ) \
inline                                                                                   \
retType aliasName paramsDecl                                                                \
{                                                                                        \
    return orgName params;                                                                      \
}




#include "stm32_spi_base.h"
#include "stm32_dma_base.h"





// umba::periph::traits

namespace umba
{
namespace periph
{
namespace traits
{


enum class ClockBus
{
    BUSUNK,  // unknown bus

    OSCCLK,
    CORECLK,
    SYSCLK,
    AHB1,
    AHB = AHB1,
    AHB2,
    AHB3,
    APB1, 
    APB = APB1,
    APB2,

    BUSEND // last bus id  +1

};


inline
const char* getClockBusName( ClockBus clockBus )
{
    if ( ((unsigned)clockBus) >= ((unsigned)ClockBus::BUSEND) )
        clockBus = ClockBus::BUSUNK;

    static const char* busNames[] = { "BUS UNKNOWN"
                                    , "OSC Clock"
                                    , "Core Clock"
                                    , "Sys Clock"
                                    , "AHB1"
                                    , "AHB2"
                                    , "AHB3"
                                    , "APB1"
                                    , "APB2"
                                    };

    return busNames[(unsigned)clockBus];
}



// return periph base freq in MHz
inline
unsigned clockGetFreq( ClockBus ebus )
{

    switch(ebus)
    {
        case ClockBus::OSCCLK:  return HSE_VALUE;
        case ClockBus::CORECLK: return SystemCoreClock;
    };

    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

        RCC_ClocksTypeDef clocks;
        RCC_GetClocksFreq(&clocks);

        switch(ebus)
        {
            case ClockBus::SYSCLK:  return clocks.SYSCLK_Frequency ;
            case ClockBus::AHB:     return clocks.HCLK_Frequency   ; // AHB1 for F4
            case ClockBus::APB1:    return clocks.PCLK1_Frequency  ;
            case ClockBus::APB2:    return clocks.PCLK2_Frequency  ;
        };

    #endif

    UMBA_ASSERT_FAIL();
    return 0;
}





template < typename TPeriph >
inline
ClockBus periphClockGetBus( TPeriph * pt )
{
    UMBA_ASSERT_FAIL();
    return ClockBus::SYSCLK;
}


//-----------------------------------------------------------------------------
typedef void(*PerifClockFunctionPtr)( uint32_t RCC_AHBPeriph, FunctionalState NewState );
typedef void(*PerifResetFunctionPtr)( uint32_t flags        , FunctionalState NewState );




// GPIO, TIM, I2C, SPI, UART/USART, ADC, DAC, DMA

// GPIO_TypeDef
// TIM_TypeDef
// I2C_TypeDef
// SPI_TypeDef
// USART_TypeDef
// ADC_TypeDef
// DAC_TypeDef
// DMA_TypeDef



template < typename T >
inline
PerifClockFunctionPtr periphClockGetFunction( T * pt )
{
    //static_assert( pt!=pt, "Must be specialized for specific peripherals" );
    UMBA_ASSERT_FAIL();
    return 0;
}

template < typename T >
inline
uint32_t periphClockGetFlag( T * pt )
{
    //static_assert( pt!=pt, "Must be specialized for specific peripherals" );
    UMBA_ASSERT_FAIL();
    return 0;
}

template < typename T >
inline
uint32_t periphResetGetFlag( T * pt )
{
    //static_assert( pt!=pt, "Must be specialized for specific peripherals" );
    UMBA_ASSERT_FAIL();
    return 0;
}

template < typename T >
inline
PerifResetFunctionPtr periphResetGetFunction( T * pt )
{
    ClockBus bus = periphClockGetBus( pt );

    switch(bus)
    {
        case ClockBus::AHB1: 
                             #if defined(STM32F1_SERIES)
                                 #ifdef STM32F10X_CL
                                     return RCC_AHBPeriphResetCmd; // AHB
                                 #else
                                     UMBA_ASSERT_FAIL(); return 0;
                                 #endif
                             #else
                                 return RCC_AHBPeriphResetCmd; // AHB
                             #endif
        case ClockBus::AHB2: UMBA_ASSERT_FAIL(); return 0;
        case ClockBus::AHB3: UMBA_ASSERT_FAIL(); return 0;
        case ClockBus::APB1: return RCC_APB1PeriphResetCmd; // APB
        case ClockBus::APB2: return RCC_APB2PeriphResetCmd;
        default: UMBA_ASSERT_FAIL();
    };
    return 0;
}

template < typename T >
inline
void periphReset( T * pt )
{
    PerifResetFunctionPtr pfn = periphResetGetFunction( pt );
    //UMBA_ASSERT(pfn!=0);
    if (pfn==0)
        return;

    uint32_t flag = periphResetGetFlag( pt );

    pfn( flag, ENABLE );
    pfn( flag, DISABLE );
}





/*
#if defined(STM32F1_SERIES) // || defined(STM32F4_SERIES)
    template <>
    inline
    ClockBus periphClockGetBus<TPeriph>( TPeriph * pt )
    {
        return ClockBus::; //!!!
    }
#elif defined(STM32F3_SERIES)
    template <>
    inline
    ClockBus periphClockGetBus<TPeriph>( TPeriph * pt )
    {
        return ClockBus::; //!!!
    }
#elif defined(STM32F4_SERIES)
    template <>
    inline
    ClockBus periphClockGetBus<TPeriph>( TPeriph * pt )
    {
        return ClockBus::; //!!!
    }
#endif
*/



// return periph base freq in MHz
template < typename TPeriph >
inline
unsigned periphClockGetFreq( TPeriph * pt )
{
    return clockGetFreq( periphClockGetBus( pt ) );
}

/*
#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

    template <>
    inline
    PerifClockFunctionPtr periphClockGetFunction<SPI_TypeDef>( SPI_TypeDef * pt )
    {
        #ifdef SPI1
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( SPI1, RCC_APB2PeriphClockCmd );
        #endif
        #ifdef SPI2
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( SPI2, RCC_APB1PeriphClockCmd );
        #endif
        #ifdef SPI3
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( SPI3, RCC_APB1PeriphClockCmd );
        #endif
        #ifdef SPI4
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( SPI4, RCC_APB2PeriphClockCmd );
        #endif
        #ifdef SPI5
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( SPI5, RCC_APB2PeriphClockCmd );
        #endif
        #ifdef SPI6
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( SPI6, RCC_APB2PeriphClockCmd );
        #endif


*/

//-----------------------------------------------------------------------------
template< typename T >
inline
void initPeriphClock( T * pt, FunctionalState newState, uint32_t extraFlags = 0 ) // FunctionalState newState DISABLE/ENABLE (from SPL directly)
{
    auto clockFn = periphClockGetFunction(pt);
    if (clockFn)
        clockFn( periphClockGetFlag(pt) | extraFlags, newState );
}

//-----------------------------------------------------------------------------
template< typename TPeriph, typename TOnOff >
inline
void periphEnable( TPeriph * pt, TOnOff onOff )
{
    //static_assert( pt!=pt, "Must be specialized for specific peripherals" );
    UMBA_ASSERT_FAIL();
}

template< typename TPeriph >
inline
bool periphIsEnabled( TPeriph * pt )
{
    //static_assert( pt!=pt, "Must be specialized for specific peripherals" );
    UMBA_ASSERT_FAIL();
    return false;
}

template< typename TPeriph >
inline
void periphWaitDisabled( TPeriph * pt )
{
    //static_assert( pt!=pt, "Must be specialized for specific peripherals" );
    UMBA_ASSERT_FAIL();
}

//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------
enum class PinFunctionUart
{
    rx, tx
};

enum class PinFunctionCan
{
    rx, tx
};

enum class PinFunctionI2c
{
    scl, sda
};

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
template < typename TPeriph, typename TPinFunction >
inline
uint32_t periphAltFunctionGetFlags( TPeriph *pPeriph, TPinFunction pinFn, GPIO_TypeDef* pGpioPort, unsigned pinNo )
{
    UMBA_ASSERT_FAIL();
    return 0;
}

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
template< typename TPinFunction >
struct PinAltFunctionInfo
{
    TPinFunction     pinFunction;
    GPIO_TypeDef    *pGpioPort;
    unsigned         pinNo;

    PinAltFunctionInfo() : pinFunction(), pGpioPort(0), pinNo(0) {}
    PinAltFunctionInfo(TPinFunction pinFn, GPIO_TypeDef *pgp, unsigned pn)
    : pinFunction(pinFn), pGpioPort(pgp), pinNo(pn)
    {}

};


template < typename TPinFunction >
inline
PinAltFunctionInfo<TPinFunction> makePinAltFunctionInfo( TPinFunction pinFn, GPIO_TypeDef* pGpioPort, unsigned pinNo )
{
    return PinAltFunctionInfo<TPinFunction>( pinFn, pGpioPort, pinNo );
}
//-----------------------------------------------------------------------------

template < typename TPinFunction >
inline
PinAltFunctionInfo<TPinFunction> makePinAltFunctionInfo( TPinFunction pinFn, const GpioPinAddr &pinAddr)
{
    return PinAltFunctionInfo<TPinFunction>( pinFn, pinAddr.port, pinAddr.pinNo );
}

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------

// Variadic template test - https://ideone.com/fKViyk
//                          https://ideone.com/UyvVmZ

//-----------------------------------------------------------------------------
// Variadic tpl helpers
template<std::size_t N, typename T, typename... types>
struct get_Nth_type
{
    using type = typename get_Nth_type<N - 1, types...>::type;
};

template<typename T, typename... types>
struct get_Nth_type<0, T, types...>
{
    using type = T;
};

template<std::size_t N, typename... Args>
using getVariadicArgsType = typename get_Nth_type<N, Args...>::type;
//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------
template< size_t arrayBufSize, size_t itemNo, typename ArrayItemType >
inline
size_t buildSomeStructuredTypeArrayImpl(ArrayItemType *pArrayBuf)
{
    return itemNo;
}


template< size_t arrayBufSize, size_t itemNo, typename ArrayItemType, typename SomeStructuredType >
inline
size_t buildSomeStructuredTypeArrayImpl(ArrayItemType *pArrayBuf
    , const SomeStructuredType &s)
{
    if (itemNo >= arrayBufSize)
    {
        static_assert(itemNo < arrayBufSize, "Error");
        return itemNo;
    }

    pArrayBuf[itemNo] = s;
    return itemNo + 1;
}


template< size_t arrayBufSize, size_t itemNo
        , typename ArrayItemType, typename SomeStructuredType
        , typename... SomeStructuredTypeListItems
        >
inline
size_t buildSomeStructuredTypeArrayImpl( ArrayItemType *pArrayBuf
                                       , const SomeStructuredType &s
                                       , SomeStructuredTypeListItems... structs)
{
    if (itemNo >= arrayBufSize)
    {
        static_assert(itemNo < arrayBufSize, "Error");
        return itemNo;
    }
    else
    {
        buildSomeStructuredTypeArrayImpl<arrayBufSize, itemNo >(pArrayBuf, s);
        return buildSomeStructuredTypeArrayImpl<arrayBufSize, itemNo + 1 >(pArrayBuf, structs...);
    }
}

template< size_t arrayBufSize, typename ArrayItemType, typename... SomeStructuredTypeListItems >
inline
size_t buildSomeStructuredTypeArray( ArrayItemType *pArrayBuf
                                   , SomeStructuredTypeListItems... structs)
{
    return buildSomeStructuredTypeArrayImpl< arrayBufSize, 0 >(pArrayBuf, structs...);
}



#if defined(STM32F1_SERIES)

template< typename TPeriph, typename TArrayItem >
inline
void periphAltFunctionConfigure( TPeriph *pPeriph, TArrayItem *pBuf, size_t bufSize )
{
    uint32_t remapFlags = 0;

    for (size_t i = 0; i != bufSize; ++i)
    {
        if (!isValidPinPort(pBuf[i].pGpioPort))
            continue; // simple skip this pin

        //cout << buf[i].val << "\n";
        uint32_t curFlags = periphAltFunctionGetFlags( pPeriph, pBuf[i].pinFunction, pBuf[i].pGpioPort, pBuf[i].pinNo );
        if (!i)
        {
            remapFlags = curFlags;
        }
        else
        {
            if (remapFlags != curFlags)
            {
                UMBA_ASSERT_FAIL();
            }
        }
    }

    if (remapFlags)
        GPIO_PinRemapConfig( remapFlags, ENABLE);
}


#elif defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

template< typename TPeriph, typename TArrayItem >
inline
void periphAltFunctionConfigure( TPeriph *pPeriph, TArrayItem *pBuf, size_t bufSize )
{
    for (size_t i = 0; i != bufSize; ++i)
    {
        //cout << buf[i].val << "\n";
        if (!isValidPinPort(pBuf[i].pGpioPort))
            continue; // simple skip this pin

        uint32_t curFlags = periphAltFunctionGetFlags( pPeriph, pBuf[i].pinFunction, pBuf[i].pGpioPort, pBuf[i].pinNo );
        if (!curFlags)
        {
            UMBA_ASSERT_FAIL();
        }

        GPIO_PinAFConfig( pBuf[i].pGpioPort, pBuf[i].pinNo, (uint8_t)curFlags );
    }
}

#endif


template< typename TPeriph, typename... SomeStructuredTypeListItems >
inline
void periphAltFunctionConfigure( TPeriph *pPeriph, SomeStructuredTypeListItems... structs)
{
    getVariadicArgsType< 0, SomeStructuredTypeListItems... > buf[sizeof...(structs)];

    size_t sz = buildSomeStructuredTypeArray< sizeof...(structs) > (buf, structs...);

    periphAltFunctionConfigure( pPeriph, buf, sz );
}

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
#include "umba/optimize_speed.h"
UMBA_FORCE_INLINE( void periphEnableIRQ( IRQn n, bool bEnable = true ) )
{
    if (bEnable) NVIC_EnableIRQ ( n );
    else         NVIC_DisableIRQ( n );
}
#include "umba/optimize_pop.h"



//-----------------------------------------------------------------------------



} // namespace traits
} // namespace periph
} // namespace umba

//UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION(periphNo, periphClockFunc)
//UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( periphNo, periphFlag )

#define UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( periphNo, periphClockFunc )  \
                                 if (pt==periphNo) return periphClockFunc

#define UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( periphNo, Bus )  \
                                 if (pt==periphNo) return ClockBus::Bus

#define UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( periphNo, periphFlag )           \
                                 if (pt==periphNo) return periphFlag

#define UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( port, pin, res ) \
                          if (pGpioPort==port && pinNo==pin)     \
                               return res


#include "stm32_syscfg.h"
#include "stm32_nvic.h"
#include "stm32_gpio.h"
#include "stm32_i2c.h"
#include "stm32_tim.h"
#include "stm32_tim_irqs.h"
#include "stm32_spi.h"
#include "stm32_adc.h"
#include "stm32_dac.h"
#include "stm32_can.h"
#include "stm32_exti.h"
#include "stm32_mco.h"
#include "stm32_dma.h"
#include "stm32_uart.h"
#include "stm32_flash.h"



