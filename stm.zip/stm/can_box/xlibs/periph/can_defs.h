#pragma once

#ifdef LINUX
    #include <linix/can.h>
#endif


// https://www.kernel.org/doc/Documentation/networking/can.txt
// https://www.can-cia.org/fileadmin/resources/documents/proceedings/2012_kleine-budde.pdf
// https://github.com/torvalds/linux/blob/master/include/uapi/linux/can.h


// linux/can.h compatible macros


/* special address description flags for the CAN_ID */

// EFF - Extended Frame Format
// SFF - Standard Frame Format

#ifndef CAN_EFF_FLAG
    #define CAN_EFF_FLAG 0x80000000U /* EFF/SFF is set in the MSB */
#endif

#ifndef CAN_RTR_FLAG
    #define CAN_RTR_FLAG 0x40000000U /* remote transmission request */
#endif

#ifndef CAN_ERR_FLAG
    #define CAN_ERR_FLAG 0x20000000U /* error message frame */
#endif


/* valid bits in CAN ID for frame formats */

#ifndef CAN_SFF_MASK
    #define CAN_SFF_MASK 0x000007FFU /* standard frame format (SFF) */
#endif

#ifndef CAN_EFF_MASK
    #define CAN_EFF_MASK 0x1FFFFFFFU /* extended frame format (EFF) */
#endif

#ifndef CAN_ERR_MASK
    #define CAN_ERR_MASK 0x1FFFFFFFU /* omit EFF, RTR, ERR flags */
#endif

#ifndef CAN_MAX_DLC
    #define CAN_MAX_DLC 8
#endif

#ifndef CAN_MAX_DLEN
    #define CAN_MAX_DLEN 8
#endif


// Non-standart macros

#ifndef CAN_FILTER_MASK_SFF_ID
    #define CAN_FILTER_MASK_SFF_ID   (CAN_RTR_FLAG) | (CAN_SFF_MASK)
#endif

#ifndef CAN_FILTER_MASK_EFF_ID
    #define CAN_FILTER_MASK_EFF_ID   (CAN_RTR_FLAG) | (CAN_EFF_MASK) | (CAN_EFF_FLAG)
#endif


// Filter ID/Mask format

//                  31 30  29      11 10       0
// Standartd frame: 0  RTR ZERO[19:0] STID[10:0]

//                  31 30  29 28      18 17       0
// Extended frame : 1  RTR 0  STID[10:0] EXID[17:0]


// В случае расширенного идентификатора CAN STD ID часть является старшей частью полного адреса,
// EXT ID - младшей
// Одним фильтром можно ловить как стандартные идентификаторы, так и расширенные (совпадение 
// только по стандартной части, значение расширенной части игнорируется таким фильтром)


// umba::periph::

namespace umba
{
namespace periph
{

enum class CanFrameFlags : uint32_t
{
    standard                    =            0,
    standardFrameFormat         =            0,
    standardRtr                 = CAN_RTR_FLAG,

    extended                    = CAN_EFF_FLAG, // Standart Frame Format used if extended flag is not set
    extendedFrameFormat         = CAN_EFF_FLAG,
    extendedRtr                 = CAN_EFF_FLAG | CAN_RTR_FLAG,

    remoteTransmissionRequest   = CAN_RTR_FLAG,
    rtr                         = CAN_RTR_FLAG,

    errorMessageFrame           = CAN_ERR_FLAG
};

// Same as CanFrameFlags, but no errorMessageFrame entry
enum class CanFilterFlags : uint32_t
{
    standard                    =            0,
    standardFrameFormat         =            0,
    standardRtr                 = CAN_RTR_FLAG,

    extended                    = CAN_EFF_FLAG, // Standart Frame Format used if extended flag is not set
    extendedFrameFormat         = CAN_EFF_FLAG,
    extendedRtr                 = CAN_EFF_FLAG | CAN_RTR_FLAG,

    remoteTransmissionRequest   = CAN_RTR_FLAG,
    rtr                         = CAN_RTR_FLAG,

    standardIdMask              = CAN_FILTER_MASK_SFF_ID,
    extendedIdMask              = CAN_FILTER_MASK_EFF_ID

};





// Compatible (by names) with socketCAN struct can_frame
struct CanFrame
{
    uint32_t     can_id;    /* 32 bit CAN_ID + EFF/RTR/ERR flags / CanFrameFlags */
    //uint8_t      can_dlc;   /* frame payload length in bytes (0 .. 8) */
    std::size_t  can_dlc;
    uint8_t      data[8];   /* frame payload */
};

// Compatible with socketCAN struct can_filter
// A filter matches, when  <received_can_id> & mask == can_id & mask

// А как задать фильтр по точному идентификатору, без использования маски?
// Маска задает, какие биты важны
// Для точного совпадения по ID важны все биты ID
// Нет возможности указать, что мы ищем совпадение по идентификатору.
// Но это можно определить - если маска покрывает все биты идентификатора,
// то это фильтр по точному ID. Но тут есть нюанс - как быть с RTR битом?
// Его нельзя игнорировать, только точное значение. Поэтому RTR бит должен
// быть задан в маске, а ожидаемое значение - в ID. Таким образом, если нам
// надо ловить RTR бит и так и эдак - то надо задавать два ID с RTR и без,
// что, собственно, по размеру равно ID+Mask.
// (По крайней мере я именно так понимаю.)

// На самом деле по RTR нет аппаратной фильтрации, так что он мимо.

//#ifndef CAN_EFF_MASK
//    #define CAN_EFF_MASK 0x1FFFFFFFU /* extended frame format (EFF) */
//#endif

//! Info about received frame
struct CanFrameInfo
{
    uint32_t     timeStamp; //! in millisecs
    uint32_t     seqNumber; //! monotonic counter of input frames
    uint8_t      flags    ;

    static const uint8_t flagTimeStamp = 1;
    static const uint8_t flagSeqNumber = 2;
    static const uint8_t flagAllGood   = 3;
};



struct CanFilter
{
    uint32_t can_id; // canid_t
    uint32_t can_mask; // canid_t
};


enum class CanFilterClass // For internal usage
{
      id16     = 0, // 16ти-битный ID
      idMask16 = 1, // 16ти-битный ID/MASK
      id32     = 2, // 32х-битный ID
      idMask32 = 3  // 32х-битный ID/MASK
};


inline
CanFilterClass getCanFilterClass( const CanFilter &filter )
{
    if (filter.can_mask==(uint32_t)CanFilterFlags::standardIdMask)
        return CanFilterClass::id16;
    else if (filter.can_mask==(uint32_t)CanFilterFlags::extendedIdMask)
        return CanFilterClass::id32;
    else if ((filter.can_mask&(uint32_t)CanFilterFlags::extendedFrameFormat) == 0)
        return CanFilterClass::idMask16;
    else if ((filter.can_mask & 0x7FFF)==0) // ex id - 18 bit, 17-15 are used in 16 bit mode, and 14-0 are ignored
        return CanFilterClass::idMask16;
    else
        return CanFilterClass::idMask32;
}







//struct

#include "umba/pushpack1.h"
union CanId
{
    uint32_t    id;
    struct u
    {
        uint32_t   unused:3;
        uint32_t   std_id:11;
        uint32_t   extended_id:18;
    };
};
#include "umba/packpop.h"







} // namespace periph
} // namespace umba


