#pragma once

//----------------------------------------------------------------------------
#ifdef USE_UART1
    #ifndef UART_N1_ENABLE
        #define UART_N1_ENABLE
    #endif
#endif

#ifdef USE_UART2
    #ifndef UART_N2_ENABLE
        #define UART_N2_ENABLE
    #endif
#endif

#ifdef USE_UART2
    #ifndef UART_N2_ENABLE
        #define UART_N2_ENABLE
    #endif
#endif

#ifdef USE_UART3
    #ifndef UART_N3_ENABLE
        #define UART_N3_ENABLE
    #endif
#endif

#ifdef USE_UART4
    #ifndef UART_N4_ENABLE
        #define UART_N4_ENABLE
    #endif
#endif

#ifdef USE_UART5
    #ifndef UART_N5_ENABLE
        #define UART_N5_ENABLE
    #endif
#endif

#ifdef USE_UART6
    #ifndef UART_N6_ENABLE
        #define UART_N6_ENABLE
    #endif
#endif

#ifdef USE_UART7
    #ifndef UART_N7_ENABLE
        #define UART_N7_ENABLE
    #endif
#endif

#ifdef USE_UART8
    #ifndef UART_N8_ENABLE
        #define UART_N8_ENABLE
    #endif
#endif

#ifdef USE_UART9
    #ifndef UART_N9_ENABLE
        #define UART_N9_ENABLE
    #endif
#endif

#ifdef USE_UART10
    #ifndef UART_N10_ENABLE
        #define UART_N10_ENABLE
    #endif
#endif

//----------------------------------------------------------------------------

#ifdef USE_CAN
    #ifndef USE_CAN1
        #define USE_CAN1
    #endif
#endif

//------------------------------

#ifdef USE_CAN1
    #ifndef CAN1_ENABLE
        #define CAN1_ENABLE
    #endif
#endif

#ifdef USE_CAN2
    #ifndef CAN2_ENABLE
        #define CAN2_ENABLE
    #endif
#endif



