#pragma once

#include "umba/umba.h"
#include "umba/time_service.h"
#include "gpio.h"

// umba::periph
namespace umba
{
namespace periph
{

inline
void initPowerPins( umba::time_service::TimeTick msIntervalBetween
                  , GpioPin** powerPins
                  , size_t    powerPinsCount
                  , bool      powerOnCmd = true
                  )
{
    UMBA_ASSERT(powerPins!=0);

    for( size_t i = 0; i!=powerPinsCount; ++i, ++powerPins )
    {
        umba::time_service::delayMs(msIntervalBetween);
        GpioPin* pPowerPin = *powerPins;

        //UMBA_ASSERT(pPowerPin!=0);
        // "Начальству" сверху виднее, что оно делает
        if (!pPowerPin)
            continue;
        
        if (!pPowerPin->isConnected())
            pPowerPin->connect();
        *pPowerPin = powerOnCmd;
    }
    
}





} // namespace periph
} // namespace umba
