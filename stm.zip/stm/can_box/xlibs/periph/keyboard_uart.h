#pragma once

#include "i_keyboard.h"
#include "periph/vk_codes.h"

#include "umba/assert.h"
#include "umba/time_service.h"


#include "uart/uart_handle.h"


// umba::periph::legacy


namespace umba
{

namespace periph
{

namespace legacy
{


struct UartTerminalKeyboard : public IKeyboard
{

    UartTerminalKeyboard( IKeyboardHandler *pHandler = 0, uart::Handle *pUart = 0) : m_pHandler(pHandler), m_pUart(pUart)
    {
        size_t size = sizeof(keyStates) / sizeof(keyStates[0]);
        for( size_t i = 0; i!= size; ++i)
        {
            keyStates[i].vkc = 0;
            keyStates[i].lastPressInterval = 0;
            keyStates[i].lastPressTime     = 0;
            keyStates[i].repeatCout        = 0;      
        }
    }

    virtual
    void setHandler( IKeyboardHandler *pHandler ) override;


    virtual
    IKeyboardHandler* getHandler( );

    void setUart( uart::Handle *pUart );

    uart::Handle* getUart();

	virtual 
    void scanKeyboard() override;

	virtual 
    bool getKeyState( unsigned vkc ) override;


protected:

    struct KeyState
    {
        unsigned                      vkc;
        umba::time_service::TimeTick  lastPressTime;
        umba::time_service::TimeTick  lastPressInterval;
        size_t                        repeatCout;
    };


    void uartReadByte( uint8_t *pByte );

    bool uartWaitReadByte( umba::time_service::TimeTick waitPeriod, uint8_t *pByte );

    void internalHandleKey( unsigned vkc );

    KeyState* findKeyState( unsigned vkc );

    void callKeyPressHandler( unsigned vkc, bool bPressed, size_t repeatCount );

    void checkReleasedKeys();

    void scanKeyboardImpl();


    IKeyboardHandler                 *m_pHandler;
    uart::Handle                     *m_pUart;

    KeyState   keyStates[32];


}; // interface UartTerminalKeyboard






} // namespace legacy

} // namespace periph

} // namespace umba

