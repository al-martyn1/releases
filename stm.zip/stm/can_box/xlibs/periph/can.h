#pragma once

#if defined(STM32F0_SERIES) || defined(STM32F1_SERIES) || defined(STM32F2_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES) || defined(STM32F7_SERIES)\
                             || defined(STM32L0_SERIES) || defined(STM32L1_SERIES) || defined(STM32L4_SERIES) \
                             || defined(MILANDR)

    #include "stm32_traits.h"
    
#endif

#include "gpio.h"




//----------------------------------------------------------------------------

// umba::periph::
namespace umba{
namespace periph{

//----------------------------------------------------------------------------




//----------------------------------------------------------------------------
typedef traits::CanInterruptFlags  CanInterruptFlags;
typedef traits::CanError           CanError;
typedef traits::ICanEventHandler   ICanEventHandler;


constexpr bool canTxPriorityId       = false;
constexpr bool canTxPriorityOrder    = true;

constexpr bool canSilenceNonsilent   = false;
constexpr bool canSilenceSilent      = true;

constexpr bool canNoLoopback         = false;
constexpr bool canLoopback           = true;

//----------------------------------------------------------------------------




//----------------------------------------------------------------------------
inline
bool periphInstallIrqHandler( CAN_TypeDef* CANx, ICanEventHandler *pHandler )
{
    return traits::periphInstallIrqHandler( CANx, pHandler );
}

inline
bool periphUninstallIrqHandler( CAN_TypeDef* CANx )
{
    return traits::periphUninstallIrqHandler( CANx );
}

void periphInitIrq( CAN_TypeDef* CANx, unsigned prio, unsigned subPrio )
{
    traits::periphInitIrq( CANx, prio, subPrio );
}

inline
void periphDisableIrq( CAN_TypeDef* CANx )
{
    traits::periphDisableIrq( CANx );
}

inline
void periphSoftReset( CAN_TypeDef * CANx )
{
    traits::periphSoftReset( CANx );
}

inline
void canDefaultInitFilters( CAN_TypeDef * CANx )
{
    umba::periph::traits::canSetFilter( CANx, 0 // fltNo
                , false  // mask, not list
                , true   // filterModeSingle32
                , 0      // fifoNo // 0/1
                , 0, 0
                );
}

inline
CanBusStatus canGetBusStatus( CAN_TypeDef *pCan )
{
    return umba::periph::traits::canGetBusStatus( pCan );
}

//----------------------------------------------------------------------------





//----------------------------------------------------------------------------
inline
bool serialTransmit( CAN_TypeDef * CANx, uint32_t canId, std::size_t dalaLen, const uint8_t *pData )
{
    return umba::periph::traits::canTransmit( CANx, canId, dalaLen, pData );
}

inline
bool serialTransmit( CAN_TypeDef * CANx, const CanFrame &canFrame )
{
    return serialTransmit( CANx, canFrame.can_id, canFrame.can_dlc, &canFrame.data[0] );
}

inline
bool serialIsReadyToTransmit( CAN_TypeDef * CANx )
{
    return umba::periph::traits::canCanTransmit( CANx );
}

inline
bool serialAreAllTransmitsComplete(CAN_TypeDef * CANx)
{
    return umba::periph::traits::canGetEmptyTxMailboxCount( CANx )==umba::periph::traits::canGetEmptyTxMailboxTotal( CANx );
}

//----------------------------------------------------------------------------




//----------------------------------------------------------------------------
inline
std::size_t serialGetPendingCount( CAN_TypeDef * CANx, std::size_t inputQueueNo )
{
    return umba::periph::traits::canFifoGetMessagesPendingCount( CANx, inputQueueNo );
}

inline
std::size_t serialGetPendingCount( CAN_TypeDef * CANx )
{
    return umba::periph::traits::canFifoGetMessagesPendingCount( CANx );
}

inline
bool serialReceive( CAN_TypeDef* CANx, uint32_t &canId, std::size_t &receivedLen, uint8_t *pBuf, std::size_t bufSize, std::size_t inputQueueNo )
{
    UMBA_ASSERT( bufSize>=8 );
    return umba::periph::traits::canFifoGetData( CANx, canId, receivedLen, pBuf, inputQueueNo );
}

inline
bool serialReceive( CAN_TypeDef* CANx, uint32_t &canId, std::size_t &receivedLen, uint8_t *pBuf, std::size_t bufSize )
{
    UMBA_ASSERT( bufSize>=8 );
    return umba::periph::traits::canFifoGetData( CANx, canId, receivedLen, pBuf );
}
 
inline
bool serialReceive( CAN_TypeDef* CANx, CanFrame &canFrame, std::size_t inputQueueNo )
{
    return umba::periph::traits::canFifoGetData( CANx, canFrame.can_id, canFrame.can_dlc, &canFrame.data[0], inputQueueNo );
}

inline
bool serialReceive( CAN_TypeDef* CANx, CanFrame &canFrame )
{
    return umba::periph::traits::canFifoGetData( CANx, canFrame.can_id, canFrame.can_dlc, &canFrame.data[0] );
}
 





//----------------------------------------------------------------------------






//----------------------------------------------------------------------------
inline
void periphInit( CAN_TypeDef  *CANx
               , GPIO_TypeDef *portRx
               , uint16_t      rxPinNo
               , GPIO_TypeDef *portTx
               , uint16_t      txPinNo
               , CanInterruptFlags canInterruptFlags    // CanInterruptFlags::maskAllFlags
               , uint64_t      baudRate
               , bool          silentMode   = false
               , bool          loopbackMode = false
               , bool          priorityOrder = true
               , unsigned      takenPermille = 875 // 700
               )
{
    traits::periphInit( CANx
               , portRx, rxPinNo
               , portTx, txPinNo
               , canInterruptFlags    // CanInterruptFlags::maskAllFlags
               , baudRate
               , silentMode
               , loopbackMode
               , priorityOrder
               , takenPermille
               );
}

//typedef traits::GpioPinAddr       GpioPinAddr    ;
inline
void periphInit( CAN_TypeDef *CANx
               , GpioPinAddr  rxGpioPinAddr
               , GpioPinAddr  txGpioPinAddr
               , CanInterruptFlags canInterruptFlags    // CanInterruptFlags::maskAllFlags
               , uint64_t     baudRate
               , bool         silentMode   = false
               , bool         loopbackMode = false
               , bool         priorityOrder = true
               , unsigned     takenPermille = 875 // 700
               )
{
    //m_pinConfig.rxPinAddr.port, m_pinConfig.rxPinAddr.pinNo
    traits::periphInit( CANx
               , rxGpioPinAddr.port, rxGpioPinAddr.pinNo
               , txGpioPinAddr.port, txGpioPinAddr.pinNo
               , canInterruptFlags    // CanInterruptFlags::maskAllFlags
               , baudRate
               , silentMode
               , loopbackMode
               , priorityOrder
               , takenPermille
               );
}





} // namespace periph
} // namespace umba
