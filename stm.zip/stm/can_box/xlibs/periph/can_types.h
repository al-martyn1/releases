#pragma once


namespace umba{
namespace periph{

enum class CanDirection
{
    rx,
    tx
};

enum class CanBusStatus
{
    normal,
    warning,
    passive,
    busOff
};

struct CanTxStatus
{
    typedef unsigned value_type;

    static const unsigned ok               = 1;
    static const unsigned arbitrationLost  = 2;
    static const unsigned txError          = 4;

    unsigned value;
};

struct CanRxStatus
{
    typedef unsigned value_type;

    static const unsigned ok               = 0;
    static const unsigned full             = 1;
    static const unsigned overrun          = 2;

    unsigned value;
};


} // namespace periph
} // namespace umba


