#pragma once

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif

//#include "stm32_syscfg.h"


namespace umba
{
namespace periph
{
namespace traits
{


//-----------------------------------------------------------------------------
enum class DmaChannelPriorityLevel
{
    dmaChannelPriorityLow      = 0, 
    dmaChannelPriorityMedium   = 1, 
    dmaChannelPriorityHigh     = 2, 
    dmaChannelPriorityVeryHigh = 3 
};

//-----------------------------------------------------------------------------



//-----------------------------------------------------------------------------
enum class DmaSize
{
    dmaSizeInvalid = -1,

    dmaBits8        = 0,
    dmaBytes1       = 0,
    dmaSizeBits8    = 0,
    dmaSizeBytes1   = 0,
                   
    dmaBits16       = 1,
    dmaBytes2       = 1,
    dmaSizeBits16   = 1,
    dmaSizeBytes2   = 1,
                   
    dmaBits32       = 2,
    dmaBytes4       = 2,
    dmaSizeBits32   = 2,
    dmaSizeBytes4   = 2,

    dmaSizeReserved = 3,

};

inline
DmaSize sizeofToDmaSize( size_t sz )
{
    switch( sz )
    {
        case 1: return DmaSize::dmaBytes1;
        case 2: return DmaSize::dmaBytes2;
        case 4: return DmaSize::dmaBytes4;
        default: return DmaSize::dmaSizeInvalid;
    }
}

inline
bool isValidDmaSize( DmaSize sz )
{
    return sz==DmaSize::dmaBytes1 || sz==DmaSize::dmaBytes2 || sz==DmaSize::dmaBytes4;
}

//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
enum class DmaIncMode
{
    dmaIncOff     = 0,
    dmaIncOn      = 1,
    dmaIncMem     = 1,
    dmaIncPeriph  = 1
};

//-----------------------------------------------------------------------------
enum class DmaCircMode
{
    dmaCircOff    = 0,
    dmaCircOn     = 1
};

//-----------------------------------------------------------------------------
enum class DmaOnOff
{
    dmaOff = 0,
    dmaOn  = 1
};

//-----------------------------------------------------------------------------
enum class DmaDirection
{
    dmaRx            = 0, // from periph to mem
    dmaPeriphToMem   = 0,

    dmaTx            = 1,  // from mem to periph
    dmaMemToPeriph   = 1,

    dmaMemMemMode    = 2,
    dmaM2Mode        = 2
};

//-----------------------------------------------------------------------------
enum class DmaChannel
{
    dmaChannel0     = 0x00,
    dmaChannel1     = 0x01,
    dmaChannel2     = 0x02,
    dmaChannel3     = 0x03,
    dmaChannel4     = 0x04,
    dmaChannel5     = 0x05,
    dmaChannel6     = 0x06,
    dmaChannel7     = 0x07,

    dmaChannelEnd   = 0x08
};

inline
DmaChannel dmaEnumerateGetNextChannel( DmaChannel ch )
{
    if (ch!=DmaChannel::dmaChannelEnd)
    {
        ch = (DmaChannel)(((unsigned)ch) + 1);
    }

    return ch;
}

inline
DmaChannel dmaEnumerateGetPrevChannel( DmaChannel ch )
{
    if (ch==DmaChannel::dmaChannel0)
        return DmaChannel::dmaChannelEnd;

    ch = (DmaChannel)(((unsigned)ch) - 1);

    return ch;
}


//-----------------------------------------------------------------------------
enum class DmaController
{
    dma1            = 0x00,
    dma2            = 0x01,

    #if defined(DMA2)
        dmaControllerEnd = 0x02,
    #else
        dmaControllerEnd = 0x01,
    #endif

    dmaControllerInvalid = -1
};

inline
DmaController dmaEnumerateGetNextController( DmaController dma )
{
    if (dma!=DmaController::dmaControllerEnd)
    {
        dma = (DmaController)(((unsigned)dma) + 1);
    }

    return dma;
}

inline
DmaController dmaEnumerateGetPrevController( DmaController dma )
{
    if (dma==DmaController::dma1)
        return DmaController::dmaControllerEnd;

    dma = (DmaController)(((unsigned)dma) - 1);

    return dma;
}

inline
bool dmaIsMemMemCompatible( DmaController dma, DmaChannel )
{
    #if defined(STM32F4_SERIES)
        #if defined(DMA2)
            if (dma==DmaController::dma2)
                return true;
        #endif
        return false;
    #else
        return true;
    #endif
}

//-----------------------------------------------------------------------------




//---------------------------------------------------------

//#define UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( ctrl, ch )         (((uint16_t)(ctrl))<<8) | ((uint16_t)(ch))
//#define UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CTRL( ctrlCh )    ((DmaController)((((uint16_t)ctrlCh)>>8)&0xFF))
//#define UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CH( ctrlCh )      ((DmaChannel)((((uint16_t)ctrlCh))&0xFF))

// Пакуем в младшую часть байта - 1-7 каналы - 3 бита, номер контроллера-1 - 1 бит


//#define UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( ctrl, ch )         (((uint8_t)((((uint8_t)ctrl)-1)&1))<<3) | ((uint8_t)(ch&7))
//#define UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CTRL( ctrlCh )    ((DmaController)((((uint8_t)ctrlCh)>>3)&0x1 + 1))
//#define UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CH( ctrlCh )      ((DmaChannel)((((uint16_t)ctrlCh))&0x7))

#define UMBA_PERIPH_STM32_TRAITS_DMA2INTEGRAL( val )  ((unsigned) (val))

#define UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( ctrl, ch )         ( (uint8_t)( (((UMBA_PERIPH_STM32_TRAITS_DMA2INTEGRAL( ctrl ) /* - 1 */ ) & 1) << 3) \
                                                                                   | (UMBA_PERIPH_STM32_TRAITS_DMA2INTEGRAL( ch ) & 7 )             \
                                                                                 )                                                                  \
                                                                      )

#define UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CTRL( ctrlCh )    ((DmaController)((((uint8_t)ctrlCh)>>3)&0x1 /* + 1 */ ))
#define UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CH( ctrlCh )      ((DmaChannel)((((uint16_t)ctrlCh))&0x7))

#define UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( ctrlN, chN )  dma##ctrlN##_Channel##chN = \
                                          UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( DmaController::dma##ctrlN, DmaChannel::dmaChannel##chN )

enum class DmaControllerChannel : uint8_t
{
    // define values dmaX_ChannelY

    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES)

        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 1 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 2 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 3 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 4 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 5 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 6 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 7 ),

        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 1 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 2 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 3 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 4 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 5 ),

    #elif defined(STM32F4_SERIES)

        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 0 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 1 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 2 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 3 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 4 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 5 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 6 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 7 ),

        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 0 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 1 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 2 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 3 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 4 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 5 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 6 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 7 ),

    #endif

    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
    invalidControlerChannel = 16
    #endif



}; // enum DmaControllerChannel

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
template< typename TPeriph >
inline
void periphDmaEnable( TPeriph * pt, DmaDirection dmaDir, DmaOnOff onOff )
{
    //static_assert( pt!=pt, "Must be specialized for specific peripherals" );
    UMBA_ASSERT_FAIL();
}

template< typename TPeriph >
inline
bool periphDmaIsEnabled( TPeriph * pt, DmaDirection dmaDir )
{
    //static_assert( pt!=pt, "Must be specialized for specific peripherals" );
    UMBA_ASSERT_FAIL();
    return false;
}

template< typename TPeriph >
inline
void periphDmaWaitDisabled( TPeriph * pt, DmaDirection dmaDir )
{
    //static_assert( pt!=pt, "Must be specialized for specific peripherals" );
    UMBA_ASSERT_FAIL();
}



template< typename TPeriph >
inline
bool periphDmaTestCompatible( TPeriph *pp, DmaControllerChannel ctrlCh, uint32_t *pHwChannelRes )
{
    UMBA_ASSERT_FAIL();
    return false;
}

template< typename TPeriph >
inline
bool periphDmaTestCompatible( TPeriph *pp, DmaControllerChannel ctrlCh, uint32_t *pHwChannelRes, DmaDirection dir )
{
    UMBA_ASSERT_FAIL();
    return false;
}

template< typename TPeriph >
inline
bool periphDmaTestCompatible( TPeriph *pp, DmaControllerChannel ctrlCh, uint32_t *pHwChannelRes, DmaDirection dir, int periphChannel )
{
    UMBA_ASSERT_FAIL();
    return false;
}

// Must be called before other Periph/DMA configuring
template< typename TPeriph >
inline
bool periphDmaRemap( TPeriph *pp, DmaControllerChannel ctrlCh )
{
    return true;
}

template< typename TPeriph >
inline
bool periphDmaRemap( TPeriph *pp, DmaControllerChannel ctrlCh, DmaDirection dir )
{
    return true;
}

// Must be called before other Periph/DMA configuring
template< typename TPeriph >
inline
bool periphDmaRemap( TPeriph *pp, DmaControllerChannel ctrlCh, DmaDirection dir, int periphChannel )
{
    return true;
}







//DmaControllerChannel

namespace priv
{

inline
volatile uint32_t& getDmaChannelsBusyFlagsStorage()
{
    static volatile uint32_t _ = 0; return _;
}

inline
void dmaSetControllerChannelBusy( DmaControllerChannel cch, bool val = true )
{
    unsigned ucch = (unsigned)cch;

    UMBA_ASSERT( ucch < (unsigned)DmaControllerChannel::invalidControlerChannel );

    UMBA_CRITICAL_SECTION(umba::globalCriticalSection);

    volatile uint32_t& flags = priv::getDmaChannelsBusyFlagsStorage();
    const uint32_t mask = 1<<ucch;

    if (val)
       flags |= mask;
    else
       flags &= mask;
}

constexpr size_t dmaRemapFlagsStorageSize = 4;

inline
volatile uint32_t* getDmaRemapFlagsStorage()
{
    static volatile uint32_t _[dmaRemapFlagsStorageSize] = { 0 }; return &_[0];
}



} // namespace priv


inline
bool dmaControllerChannelIsBusy( DmaControllerChannel cch )
{
    unsigned ucch = (unsigned)cch;

    UMBA_ASSERT( ucch < (unsigned)DmaControllerChannel::invalidControlerChannel );

    UMBA_CRITICAL_SECTION(umba::globalCriticalSection);
    volatile uint32_t& flags = priv::getDmaChannelsBusyFlagsStorage();
    return (flags & (1<<ucch)) ? true : false;
}


inline
bool dmaControllerChannelUsageAcquire( DmaControllerChannel cch )
{
    unsigned ucch = (unsigned)cch;

    UMBA_ASSERT( ucch < (unsigned)DmaControllerChannel::invalidControlerChannel );

    UMBA_CRITICAL_SECTION(umba::globalCriticalSection);
    volatile uint32_t& flags = priv::getDmaChannelsBusyFlagsStorage();
    uint32_t mask = 1<<ucch;

    if (flags&mask)
        return false;

    flags |= mask;
    return true;
}

inline
bool dmaControllerChannelUsageFree( DmaControllerChannel cch )
{
    unsigned ucch = (unsigned)cch;

    UMBA_ASSERT( ucch < (unsigned)DmaControllerChannel::invalidControlerChannel );

    UMBA_CRITICAL_SECTION(umba::globalCriticalSection);
    volatile uint32_t& flags = priv::getDmaChannelsBusyFlagsStorage();
    uint32_t mask = 1<<ucch;

    if ((flags&mask)==0)
        return false;

    flags &= ~mask;
    return true;
}

inline
bool dmaIsControllerChannelIsRemapUsed( size_t remapRegNo, uint32_t remapBit )
{
    UMBA_ASSERT( remapRegNo < priv::dmaRemapFlagsStorageSize );

    UMBA_CRITICAL_SECTION(umba::globalCriticalSection);
    volatile uint32_t* flags = priv::getDmaRemapFlagsStorage();
    return flags[remapRegNo]&remapBit ? true : false;
}

inline
bool dmaControllerChannelRemapAcquire( size_t remapRegNo, uint32_t remapBit )
{
    UMBA_ASSERT( remapRegNo < priv::dmaRemapFlagsStorageSize );

    UMBA_CRITICAL_SECTION(umba::globalCriticalSection);
    volatile uint32_t* flags = priv::getDmaRemapFlagsStorage();

    if (flags[remapRegNo]&remapBit)
        return false;

    flags[remapRegNo] |= remapBit;
    return true;
}

inline
bool dmaControllerChannelRemapFree( size_t remapRegNo, uint32_t remapBit )
{
    UMBA_ASSERT( remapRegNo < priv::dmaRemapFlagsStorageSize );

    UMBA_CRITICAL_SECTION(umba::globalCriticalSection);
    volatile uint32_t* flags = priv::getDmaRemapFlagsStorage();

    if ((flags[remapRegNo]&remapBit)==0)
        return false;

    flags[remapRegNo] &= ~remapBit;
    return true;
}









//-----------------------------------------------------------------------------


} // namespace traits
} // namespace periph
} // namespace umba
