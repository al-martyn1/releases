
namespace umba{
namespace periph{
namespace traits{


inline IRQn canGetIRQn( unsigned /* uint16_t */ canNo, CanIrq canIrq )
{
    // F1 - Refman 10.1
    // F3 - Refman 14.1
    // F4 - Refman 10.1

    switch(canNo)
    {
        #if (defined(CAN1) || defined(CAN)) && defined(USE_CAN1)
            case 1u:
                switch(canIrq)
                {
                    case CanIrq::tx : return (IRQn)19; // Shared with USB Device High Priority
                    case CanIrq::rx0: return (IRQn)20; // Shared with USB Device Low Priority 
                    case CanIrq::rx1: return (IRQn)21;
                    case CanIrq::esr: return (IRQn)22;
                    default:    UMBA_ASSERT_FAIL();
                }
                break;
        #endif
        #if defined(CAN2) && defined(USE_CAN2)
            case 2u:
                switch(canIrq)
                {
                    case CanIrq::tx : return (IRQn)63;
                    case CanIrq::rx0: return (IRQn)64;
                    case CanIrq::rx1: return (IRQn)65;
                    case CanIrq::esr: return (IRQn)66;
                    default:    UMBA_ASSERT_FAIL();
                }
                break;
        #endif

        default:    UMBA_ASSERT_FAIL();
    }

    return (IRQn)0;

}

//inline
UMBA_FORCE_INLINE( IRQn canGetIRQn( CAN_TypeDef *pt, CanIrq canIrq ) )
{
    return canGetIRQn( canGetNo( pt ), canIrq );
}

//inline 
UMBA_FORCE_INLINE( IRQn periphGetIRQn( CAN_TypeDef *pt, CanIrq canIrq ) )
{
    return canGetIRQn(pt, canIrq);
}

//----------------------------------------------------------------------------



//----------------------------------------------------------------------------
inline
ICanEventHandler** canGetEventHandlersTable( )
{
    static ICanEventHandler* _[] = { 0, 0 };
    return &_[0];
}

//----------------------------------------------------------------------------
inline
bool canSetIrqHandlerImpl( unsigned /* uint16_t */ CANn, ICanEventHandler *pHandler )
{
    unsigned /* uint16_t */ tblIdx = CANn - 1;
    UMBA_ASSERT(tblIdx<2);

    ICanEventHandler** pTable = canGetEventHandlersTable( );

    UMBA_MEMORY_BARRIER();
    UMBA_DISABLE_IRQ();
    pTable[tblIdx] = pHandler;
    UMBA_ENABLE_IRQ();

    return true;
}

//----------------------------------------------------------------------------
inline
ICanEventHandler* canGetIrqHandlerImpl( unsigned /* uint16_t */ CANn )
{
    unsigned /* uint16_t */ tblIdx = CANn - 1;
    UMBA_ASSERT(tblIdx<2);

    ICanEventHandler** pTable = canGetEventHandlersTable( );

    UMBA_MEMORY_BARRIER();
    UMBA_DISABLE_IRQ();
    ICanEventHandler* pRes = pTable[tblIdx];
    UMBA_ENABLE_IRQ();

    return pRes;
}

//----------------------------------------------------------------------------
inline
bool canInstallIrqHandler( unsigned /* uint16_t */ CANn, ICanEventHandler *pHandler )
{
    UMBA_ASSERT(pHandler);
    return canSetIrqHandlerImpl( CANn, pHandler );
}

inline
bool canInstallIrqHandler( CAN_TypeDef* CANx, ICanEventHandler *pHandler )
{
    UMBA_ASSERT(pHandler);
    return canSetIrqHandlerImpl( canGetNo(CANx), pHandler );
}

inline
bool periphInstallIrqHandler( CAN_TypeDef* CANx, ICanEventHandler *pHandler )
{
    UMBA_ASSERT(pHandler);
    return canSetIrqHandlerImpl( canGetNo(CANx), pHandler );
}

//----------------------------------------------------------------------------
//inline
UMBA_FORCE_INLINE( bool canUninstallIrqHandler( unsigned /* uint16_t */ CANn ) )
{
    return canSetIrqHandlerImpl( CANn, 0 );
}

//inline
UMBA_FORCE_INLINE( bool canUninstallIrqHandler( CAN_TypeDef* CANx ) )
{
    return canSetIrqHandlerImpl( canGetNo(CANx), 0 );
}

//inline
UMBA_FORCE_INLINE( bool periphUninstallIrqHandler( CAN_TypeDef* CANx ) )
{
    return canSetIrqHandlerImpl( canGetNo(CANx), 0 );
}

//----------------------------------------------------------------------------
//inline
UMBA_FORCE_INLINE( ICanEventHandler* canGetIrqHandler( unsigned /* uint16_t */ CANn ) )
{
    return canGetIrqHandlerImpl( CANn );
}

// inline
UMBA_FORCE_INLINE( ICanEventHandler* canGetIrqHandler( CAN_TypeDef* CANx ) )
{
    return canGetIrqHandlerImpl( canGetNo(CANx) );
}

//----------------------------------------------------------------------------

} // namespace traits
} // namespace periph
} // namespace umba


