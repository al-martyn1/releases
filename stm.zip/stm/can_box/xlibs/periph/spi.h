#pragma once

#if defined(STM32F0_SERIES) || defined(STM32F1_SERIES) || defined(STM32F2_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES) || defined(STM32F7_SERIES)\
                             || defined(STM32L0_SERIES) || defined(STM32L1_SERIES) || defined(STM32L4_SERIES) \
                             || defined(MILANDR)

    #include "stm32_traits.h"
    
#endif

// umba::periph
namespace umba
{
namespace periph
{

typedef traits::PinFunctionSpi       PinFunctionSpi;
typedef traits::BitsDirection        BitsDirection;
typedef traits::SpiMode              SpiMode;

typedef traits::SpiDataBits          SpiDataBits;
typedef traits::SpiPrescaler         SpiPrescaler;
typedef traits::SpiWaitNotBusy       SpiWaitNotBusy;
typedef traits::SpiModeMasterSlave   SpiModeMasterSlave;

typedef traits::SpiEventType         SpiEventType;

typedef traits::SpiOnOff             SpiOnOff;
//typedef traits::SpiWaitNotBusy       SpiWaitNotBusy


inline uint16_t spiGetNo( SPI_TypeDef *pt )      { return traits::spiGetNo(pt); }
inline uint16_t periphGetNo( SPI_TypeDef * pt )  { return traits::periphGetNo(pt); }
inline SPI_TypeDef* spiGetSpi( uint16_t spiNo )  { return traits::spiGetSpi( spiNo ); }
inline IRQn spiGetIRQn( SPI_TypeDef *pt )        { return traits::spiGetIRQn( pt ); }
inline IRQn periphGetIRQn( SPI_TypeDef *pt )     { return traits::periphGetIRQn( pt ); }


inline
void periphInit( SPI_TypeDef* SPIx
               , GPIO_TypeDef *sckPort , uint16_t sckPinNo
               , GPIO_TypeDef *misoPort, uint16_t misoPinNo
               , GPIO_TypeDef *mosiPort, uint16_t mosiPinNo
               , SpiDataBits dataSize
               , BitsDirection bitsDirection
               , SpiMode spiMode
               , SpiPrescaler baudRatePrescalerPwr
               , PinSpeed pinSpeed  = PinSpeed::high
               , SpiModeMasterSlave spiModeMasterSlave = SpiModeMasterSlave::spiModeMaster
               , SpiOnOff  spiOnOff = SpiOnOff::spiOn
               )
{
    traits::periphInit( SPIx
               , sckPort , sckPinNo
               , misoPort, misoPinNo
               , mosiPort, mosiPinNo
               , dataSize
               , bitsDirection
               , spiMode
               , baudRatePrescalerPwr
               , pinSpeed
               , spiModeMasterSlave
               , spiOnOff
               );
}

inline
void periphInit( SPI_TypeDef* SPIx
               , const GpioPinAddr sckPinAddr
               , const GpioPinAddr misoPinAddr
               , const GpioPinAddr mosiPinAddr
               , SpiDataBits dataSize
               , BitsDirection bitsDirection
               , SpiMode spiMode
               , SpiPrescaler baudRatePrescalerPwr // uint16_t baudRatePrescalerPwr = 7 // power of two
               , PinSpeed pinSpeed = PinSpeed::high
               , SpiModeMasterSlave spiModeMasterSlave = SpiModeMasterSlave::spiModeMaster
               , SpiOnOff  spiOnOff = SpiOnOff::spiOn
               )
{
    traits::periphInit( SPIx
               , sckPinAddr
               , misoPinAddr
               , mosiPinAddr
               , dataSize
               , bitsDirection
               , spiMode
               , baudRatePrescalerPwr // uint16_t baudRatePrescalerPwr = 7 // power of two
               , pinSpeed
               , spiModeMasterSlave
               , spiOnOff
               );
}

inline unsigned spiGetFreq( SPI_TypeDef* SPIx )                                       { return traits::spiGetFreq( SPIx ); }
inline SpiPrescaler spiCalcPrescaler( SPI_TypeDef* SPIx, int requestedFreq )          { return traits::spiCalcPrescaler( SPIx, requestedFreq ); }
inline uint16_t spiGetDataSize( SPI_TypeDef* SPIx )                                   { return traits::spiGetDataSize(SPIx); }

template< typename THandler >
inline void spiWaitCanTransmit( SPI_TypeDef* SPIx, const THandler &waitHandler )      { traits::spiWaitCanTransmit( SPIx, waitHandler ); }
inline void spiWaitCanTransmit( SPI_TypeDef* SPIx )                                   { traits::spiWaitCanTransmit( SPIx ); }

template< typename THandler >
inline void spiWaitTransmitComplete( SPI_TypeDef* SPIx, const THandler &waitHandler ) { traits::spiWaitTransmitComplete( SPIx, waitHandler ); }
inline void spiWaitTransmitComplete( SPI_TypeDef* SPIx )                              { traits::spiWaitTransmitComplete( SPIx ); }

template< typename THandler >
inline void spiWaitReceiveComplete( SPI_TypeDef* SPIx, const THandler &waitHandler )  { traits::spiWaitReceiveComplete( SPIx, waitHandler ); }
inline void spiWaitReceiveComplete( SPI_TypeDef* SPIx )                               { traits::spiWaitReceiveComplete( SPIx ); }

template< typename THandler >
inline void spiWaitNotBusy( SPI_TypeDef* SPIx, const THandler &waitHandler )          { traits::spiWaitNotBusy( SPIx, waitHandler ); }
inline void spiWaitNotBusy( SPI_TypeDef* SPIx )                                       { traits::spiWaitNotBusy( SPIx ); }

template< typename THandler >
inline void spiWaitNotBusy( SPI_TypeDef* SPIx, SpiWaitNotBusy waitNotBusy, const THandler &waitHandler ) { traits::spiWaitNotBusy( SPIx, waitNotBusy, waitHandler ); }
inline void spiWaitNotBusy( SPI_TypeDef* SPIx, SpiWaitNotBusy waitNotBusy )                              { traits::spiWaitNotBusy( SPIx, waitNotBusy  ); }             

inline uint16_t spiReadGetValue( SPI_TypeDef* SPIx, SpiDataBits dataSize ) { return traits::spiReadGetValue( SPIx, dataSize ); }
inline uint16_t spiReadGetValue( SPI_TypeDef* SPIx )                       { return traits::spiReadGetValue( SPIx ); }

inline void spiWriteSetValue( SPI_TypeDef* SPIx, SpiDataBits dataSize, uint16_t data ) { traits::spiWriteSetValue( SPIx, dataSize, data ); }
inline void spiWriteSetValue( SPI_TypeDef* SPIx, uint16_t data )                       { traits::spiWriteSetValue( SPIx, data ); }

inline void spiStartPrepare( SPI_TypeDef* SPIx ) { traits::spiStartPrepare( SPIx ); }

inline void spiWriteStart( SPI_TypeDef* SPIx, uint16_t data, GpioPin *pCsPin = 0, umba::hr_counter::NanosecInterval csAfterPause = 0) { traits::spiWriteStart( SPIx, data, pCsPin, csAfterPause ); }

template< typename THandler >
inline void spiWrite( SPI_TypeDef* SPIx, uint16_t data, GpioPin &csPin, umba::hr_counter::NanosecInterval csAfterPause, SpiWaitNotBusy waitNotBusy, const THandler &waitHandler ) { traits::spiWrite( SPIx, data, csPin, csAfterPause, waitNotBusy, waitHandler ); }

inline void spiWrite( SPI_TypeDef* SPIx, uint16_t data, GpioPin &csPin, umba::hr_counter::NanosecInterval csAfterPause, SpiWaitNotBusy waitNotBusy ) { traits::spiWrite( SPIx, data, csPin, csAfterPause, waitNotBusy ); }

template< typename THandler >
inline void spiWrite( SPI_TypeDef* SPIx, uint16_t data, SpiWaitNotBusy waitNotBusy, const THandler &waitHandler ) { traits::spiWrite( SPIx, data, waitNotBusy, waitHandler ); }

inline void spiWrite( SPI_TypeDef* SPIx, uint16_t data, SpiWaitNotBusy waitNotBusy ) { traits::spiWrite( SPIx, data, waitNotBusy ); }


inline void spiReadStart( SPI_TypeDef* SPIx, uint16_t dummyData, GpioPin *pCsPin = 0, umba::hr_counter::NanosecInterval csAfterPause = 0 ) { return traits::spiReadStart( SPIx, dummyData, pCsPin, csAfterPause ); }

template< typename THandler >
inline uint16_t spiRead( SPI_TypeDef* SPIx, uint16_t dummyData, SpiWaitNotBusy waitNotBusy, const THandler &waitHandler ) { return traits::spiRead( SPIx, dummyData, waitNotBusy, waitHandler ); }

inline uint16_t spiRead( SPI_TypeDef* SPIx, uint16_t dummyData, SpiWaitNotBusy waitNotBusy ) { return traits::spiRead( SPIx, dummyData, waitNotBusy ); }

template< typename THandler >
inline uint16_t spiRead( SPI_TypeDef* SPIx, uint16_t dummyData, GpioPin &csPin, umba::hr_counter::NanosecInterval csAfterPause, SpiWaitNotBusy waitNotBusy, const THandler &waitHandler ) { return traits::spiRead( SPIx, dummyData, csPin, csAfterPause, waitNotBusy, waitHandler ); }

inline uint16_t spiRead( SPI_TypeDef* SPIx, uint16_t dummyData, GpioPin &csPin, umba::hr_counter::NanosecInterval csAfterPause, SpiWaitNotBusy waitNotBusy ) { return traits::spiRead( SPIx, dummyData, csPin, csAfterPause, waitNotBusy ); }

inline size_t spiGetTxFifoLevel( SPI_TypeDef* SPIx ) { return traits::spiGetTxFifoLevel( SPIx ); }
inline size_t spiGetRxFifoLevel( SPI_TypeDef* SPIx ) { return traits::spiGetRxFifoLevel( SPIx ); }
inline void   spiClearRxFifo( SPI_TypeDef* SPIx )      { traits::spiClearRxFifo( SPIx ); }


} // namespace periph
} // namespace umba

