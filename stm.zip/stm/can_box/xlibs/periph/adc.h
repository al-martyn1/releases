#pragma once

#if defined(STM32F0_SERIES) || defined(STM32F1_SERIES) || defined(STM32F2_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES) || defined(STM32F7_SERIES)\
                             || defined(STM32L0_SERIES) || defined(STM32L1_SERIES) || defined(STM32L4_SERIES) \
                             || defined(MILANDR)

    #include "stm32_traits.h"
    
#endif

// umba::periph
namespace umba
{
namespace periph
{

using AdcSamplingSpeed = umba::periph::traits::AdcSamplingSpeed;
using AdcInjected      = umba::periph::traits::AdcInjected;
using AdcInitHwOption  = umba::periph::traits::AdcInitHwOption;
//using umba::periph::traits::

//using adcInitInject    = umba::periph::traits::adcInitInject;

template< typename... SomeStructuredTypeListItems >
inline
AdcInjected adcInitInject( ADC_TypeDef* ADCx, AdcSamplingSpeed samplingSpeed
                         , AdcInitHwOption doInitAdc // set to true to add injected channels over regular
                         , SomeStructuredTypeListItems... structs)
{
    return traits::adcInitInject( ADCx, samplingSpeed, doInitAdc, structs... );
}



} // namespace periph
} // namespace umba

