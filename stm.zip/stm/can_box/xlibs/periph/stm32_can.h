#pragma once

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif

#include "can_defs.h"
#include "can_types.h"

#include "helpers.h"


namespace umba{
namespace periph{
namespace traits{

// Неплохое описание фильтров CAN
// RM0008
// Reference manual
// STM32F101xx, STM32F102xx, STM32F103xx, STM32F105xx and STM32F107xx advanced Arm®-based 32-bit MCUs
//
// 24.7.4 Identifier filtering
//    Filter bank scale and mode configuration
// Figure 230. Filter bank scale configuration - register organization. Page 665

// Примечание: модуль CAN практически идентичен (если не идентичен полностью) для семейств F1/F3/F4,
// так что можно использовать любой из мануалов по этим семействам. В мануале от сотки расписано лучше,
// чем в мануале от четверки, как минимум.


// Identifier extension bit (IDE)	1	Must be dominant (0) for base frame format with 11-bit identifiers


//           STID[10:3]       STID[2:0] EXID[17:13]     EXID[12:5]      EXID[4:0]  IDE RTR  0

// One 32-Bit Filter - Identifier Mask
// ID      CAN_FxR1[31:24]       CAN_FxR1[23:16]      CAN_FxR1[15:8]      CAN_FxR1[7:0]
// Mask    CAN_FxR2[31:24]       CAN_FxR2[23:16]      CAN_FxR2[15:8]      CAN_FxR2[7:0]

// Two 32-Bit Filters - Identifier List
// ID      CAN_FxR1[31:24]       CAN_FxR1[23:16]      CAN_FxR1[15:8]      CAN_FxR1[7:0]
// ID      CAN_FxR2[31:24]       CAN_FxR2[23:16]      CAN_FxR2[15:8]      CAN_FxR2[7:0]



// Two 16-Bit Filters - Identifier Mask

//          STID[10:3]      STID[2:0] RTR IDE EXID[17:15]
// ID      CAN_FxR1[15:8]         CAN_FxR1[7:0]
// Mask    CAN_FxR1[31:24]        CAN_FxR1[23:16]
                                 
// ID      CAN_FxR2[15:8]         CAN_FxR2[7:0]
// Mask    CAN_FxR2[31:24]        CAN_FxR2[23:16]

// Four 16-Bit Filters - Identifier List

// ID      CAN_FxR1[15:8]         CAN_FxR1[7:0]
// ID      CAN_FxR1[31:24]        CAN_FxR1[23:16]
                                 
// ID      CAN_FxR2[15:8]         CAN_FxR2[7:0]
// ID      CAN_FxR2[31:24]        CAN_FxR2[23:16]


// Для задания фильтров используем массив структур umba::periph::CanFrame (can_defs.h)
// CAN_ERR_FLAG не используется для задания фильтров, поэтому мы можем использовать
// его значение для внутренних целей - промаркировать фильтр, как влезающий в 16 бит.

//#define CAN_FILTER_INTERNAL_SIZE_16    CAN_ERR_FLAG


// Filter ID/Mask format

//                  31 30  29      11 10       0
// Standartd frame: EF RTR ZERO[19:0] STID[10:0]

//                  31 30  29 28      18 17       0
// Extended frame : 1  RTR 0  STID[10:0] EXID[17:0]


// В случае расширенного идентификатора CAN STD ID часть является старшей частью полного адреса,
// EXT ID - младшей
// Одним фильтром можно ловить как стандартные идентификаторы, так и расширенные (совпадение 
// только по стандартной части, значение расширенной части игнорируется таким фильтром)

                                                                                             
// В STM32 CAN фильтр может быть как 32ух-битным, так и 16ти-битным.
// В обоих случаях в фильтре
// может быть использован как 
// #define CAN_FILTER_INTERNAL_COMPAT16_MASK



/*
 1) В струтуре CanFilter

      struct CanFilter
      {
          uint32_t can_id; // canid_t
          uint32_t can_mask; // canid_t
      };

    нет возможности указать, что мы ищем совпадение по идентификатору.
    Но это можно определить - если маска покрывает все биты идентификатора,
    то это фильтр по точному ID. Но тут есть нюанс - как быть с RTR битом?
    Его нельзя игнорировать, только точное значение. Поэтому RTR бит должен
    быть задан в маске, а ожидаемое значение - в ID. Таким образом, если нам
    надо ловить RTR бит и так и эдак - то надо задавать два ID с RTR и без,
    что, собственно, по размеру равно ID+Mask.
    (По крайней мере я именно так понимаю.)

 2) Для того, чтобы поплотнее упаковать фильтры, нам надо уметь:
    а) фильтры ID группировать вместе по 4;
    б) фильтры ID/MASK16 группировать вместе по 2;
    в) фильтры ID32 группировать вместе по 2;
    г) фильтры ID/MASK32 не требуют группировки, так как занимают максимальный размер.

 3) Куда можно поместить отсортированную последовательность?
    а) сортировать во входном массиве - но тогда не передать константный массив
    б) сортировать во временном массиве, при этом:
       I  выделять его где-то самому
       II вызывающий код предоставляет буфер необходимого размера
    в) сортировать индексы, при этом можно сделать предвычесление характеристик фильтра:
       0 - 16ти-битный ID
       1 - 16ти-битный ID/MASK
       2 - 32х-битный ID
       3 - 32х-битный ID/MASK


 16ти-битные фильтры
    группировать вместе
 */




enum class CanHardwareMode
{
    inactive,
    rx,
    tx
};

enum class CanTransmitMailboxStatus
{
    statusIncomplete,
    transmissionSuccessful,
    arbitrationError,
    transmissionError
};

enum class CanError : unsigned
{
    noError           = 0,  // 000: No Error
    stuffError        = 1,  // 001: Stuff Error
    formError         = 2,  // 010: Form Error
    ackError          = 3,  // 011: Acknowledgment Error
    recessiveBitError = 4,  // 100: Bit recessive Error
    dominantBitError  = 5,  // 101: Bit dominant Error
    crcError          = 6,  // 110: CRC Error
    softError         = 7   // 111: Set by software
};




enum class CanIrq
{
    tx ,
    rx0,
    rx1,
    esr
};

struct CanInterruptFlags
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

        // CANx->IER (CAN_IER)

        static const uint32_t sleepInterrupt                 = 1<<17; // CAN_IER_SLKIE: Sleep interrupt enable
        static const uint32_t wakeupInterrupt                = 1<<16; // CAN_IER_WKUIE: Wakeup interrupt enable
       
        // All interrupts below refers to CAN_ESR ERRI
        static const uint32_t errorInterrupt                 = 1<<15; // CAN_IER_ERRIE: Error interrupt enable
        static const uint32_t lastErrCodeInterrupt           = 1<<11; // CAN_IER_LECIE: Last error code interrupt enable
        static const uint32_t busOffInterrupt                = 1<<10; // CAN_IER_BOFIE: Bus-off interrupt enable
        static const uint32_t errorPassiveInterrupt          = 1<< 9; // CAN_IER_EPVIE: Error passive interrupt enable
        static const uint32_t errorWarningInterrupt          = 1<< 8; // CAN_IER_EWGIE: Error warning interrupt enable
        // End of CAN_ESR ERRI
       
        static const uint32_t fifo1_overrunInterrupt         = 1<< 6; // CAN_IER_FOVIE1: FIFO overrun interrupt enable
        static const uint32_t fifo1_fullInterrupt            = 1<< 5; // CAN_IER_FFIE1 : FIFO full interrupt enable
        static const uint32_t fifo1_messagePendingInterrupt  = 1<< 4; // CAN_IER_FMPIE1: FIFO message pending interrupt enable
       
        static const uint32_t fifo0_overrunInterrupt         = 1<< 3; // CAN_IER_FOVIE0: FIFO overrun interrupt enable
        static const uint32_t fifo0_fullInterrupt            = 1<< 2; // CAN_IER_FFIE0 : FIFO full interrupt enable
        static const uint32_t fifo0_messagePendingInterrupt  = 1<< 1; // CAN_IER_FMPIE0: FIFO message pending interrupt enable
       
        // for usage for generic fifo (with shift 0/3)
        static const uint32_t fifoOverrunInterrupt           = 1<< 3; // CAN_IER_
        static const uint32_t fifoFullInterrupt              = 1<< 2; // CAN_IER_
        static const uint32_t fifoMessagePendingInterrupt    = 1<< 1; // CAN_IER_
       
        static const uint32_t txEmptyInterrupt               = 1<< 0; // CAN_IER_TMEIE: Transmit mailbox empty interrupt enable
       
       
        static const uint32_t maskAllErrors                  = 1<<15  // CAN_IER_ERRIE
                                                             | 1<<11  // CAN_IER_LECIE
                                                             | 1<<10  // CAN_IER_BOFIE
                                                             | 1<< 9  // CAN_IER_EPVIE
                                                             | 1<< 8  // CAN_IER_EWGIE
                                                             ;
       
        static const uint32_t maskAllFlags                   = 1<<17  // CAN_IER_SLKIE
                                                             | 1<<16  // CAN_IER_WKUIE
                                                             | 1<<15  // CAN_IER_ERRIE
                                                             | 1<<11  // CAN_IER_LECIE
                                                             | 1<<10  // CAN_IER_BOFIE
                                                             | 1<< 9  // CAN_IER_EPVIE
                                                             | 1<< 8  // CAN_IER_EWGIE
                                                                    
                                                             | 1<< 6  // CAN_IER_FOVIE1
                                                             | 1<< 5  // CAN_IER_FFIE1 
                                                             | 1<< 4  // CAN_IER_FMPIE1
                                                                    
                                                             | 1<< 3  // CAN_IER_FOVIE0
                                                             | 1<< 2  // CAN_IER_FFIE0 
                                                             | 1<< 1  // CAN_IER_FMPIE0
                                                                    
                                                             | 1<< 0  // CAN_IER_TMEIE
                                                             ;
    #else

        #error "Not implemented for this family"

    #endif

    uint32_t value;

}; // struct CanInterruptFlags


} // namespace traits
} // namespace periph
} // namespace umba

//----------------------------------------------------------------------------




//----------------------------------------------------------------------------
#include "x_stm32_can_periph_bits.h"
#include "x_stm32_can_number.h"
#include "x_stm32_can_irq_handlers_impl.h"
#include "x_stm32_can_irq_handlers.h"
#include "x_stm32_can_clocking.h"
#include "x_stm32_can_gpio_mapping.h"

//----------------------------------------------------------------------------




//----------------------------------------------------------------------------
namespace umba{
namespace periph{
namespace traits{

//----------------------------------------------------------------------------
#include "umba/optimize_speed.h"
UMBA_FORCE_INLINE( void periphClearIrqEventFlags( CAN_TypeDef *CANx ) )
{
    CANx->IER &= ~ CanInterruptFlags::maskAllFlags;
}

UMBA_FORCE_INLINE( void periphSetIrqEventFlags( CAN_TypeDef *CANx, CanInterruptFlags canInterruptFlags ) )
{
    periphClearIrqEventFlags(CANx);
    CANx->IER |= canInterruptFlags.value;
}

UMBA_FORCE_INLINE( CanInterruptFlags periphGetIrqEventFlags( CAN_TypeDef *CANx ) )
{
    CanInterruptFlags canInterruptFlags;
    canInterruptFlags.value = CANx->IER & CanInterruptFlags::maskAllFlags;
    return canInterruptFlags;
}
#include "umba/optimize_pop.h"
//----------------------------------------------------------------------------






//-----------------------------------------------------------------------------
/* inline */  UMBA_FORCE_INLINE( void canSetDebugFreezeMode( CAN_TypeDef *pCan, bool df = true ) ) { UMBA_PERIPH_BIT_SET_RESET_HELPER( pCan->MCR, (1u<<16), df   );  /* setResetHelper( &pCan->MCR, (1u<<16), df   ); */  } // Bit 16 DBF: Debug freeze
/* inline */  UMBA_FORCE_INLINE( void canReset( CAN_TypeDef *pCan )                              ) { UMBA_PERIPH_BIT_SET_RESET_HELPER( pCan->MCR, (1u<<15), true );  /* setResetHelper( &pCan->MCR, (1u<<15), true ); */  } // Set RESET bit (bit 15) of MCR

inline CanHardwareMode canGetHardwareMode( CAN_TypeDef *pCan )
{
    if (pCan->MSR & (1<<9))      // Bit 9 RXM: Receive mode
        return CanHardwareMode::rx;
    else if (pCan->MSR & (1<<8)) // Bit 8 TXM: Transmit mode
        return CanHardwareMode::tx;
    else
        return CanHardwareMode::inactive;
}


// Get or clear CAN interrupt status flags 
#if 0
/* inline */  
UMBA_FORCE_INLINE( bool canFlagGetSleepAckInterrupt( CAN_TypeDef *pCan )   )  {  return (pCan->MSR & (1<<4)) ? true : false; } // Bit 4 SLAKI: Sleep acknowledge interrupt
/* inline */  
UMBA_FORCE_INLINE( void canFlagClearSleepAckInterrupt( CAN_TypeDef *pCan ) )  {  pCan->MSR &= ~(1<<4); }                       // Bit 4 SLAKI: Sleep acknowledge interrupt

/* inline */  
UMBA_FORCE_INLINE( bool canFlagGetWakeupInterrupt( CAN_TypeDef *pCan )     )  { return (pCan->MSR & (1<<3))  ? true : false; } // Bit 3 WKUI: Wakeup interrupt
/* inline */  
UMBA_FORCE_INLINE( void canFlagClearWakeupInterrupt( CAN_TypeDef *pCan )   )  { pCan->MSR &= ~(1<<3); }                        // Bit 3 WKUI: Wakeup interrupt

/* inline */  
UMBA_FORCE_INLINE( bool canFlagGetErrorInterrupt( CAN_TypeDef *pCan )      )  {  return (pCan->MSR & (1<<2)) ? true : false; } // Bit 2 ERRI: Error interrupt
/* inline */  
UMBA_FORCE_INLINE( void canFlagClearErrorInterrupt( CAN_TypeDef *pCan )    )  { pCan->MSR &= ~(1<<2); }                        // Bit 2 ERRI: Error interrupt

/* inline */  
/* inline */  
#endif

UMBA_FORCE_INLINE( bool getFlagInitAck( CAN_TypeDef *pCan )                )  { return (pCan->MSR & bcCAN_MSR_INAK_CHK_MASK) ? true : false; }  // Bit 0 INAK: Initialization acknowledge
UMBA_FORCE_INLINE( bool getFlagSleepAck( CAN_TypeDef *pCan )               )  { return (pCan->MSR & bcCAN_MSR_SLAK_CHK_MASK) ? true : false; }  // Bit 1 SLAK: Sleep acknowledge


inline void canEnterInitMode( CAN_TypeDef *pCan )     { pCan->MCR |= bcCAN_MCR_INRQ_SET_MASK;              }
inline void canWaitEnterInitMode( CAN_TypeDef *pCan ) { while(!getFlagInitAck(pCan)) {} } // //while((pCan->MSR & 0x01)==0) {} // Test INAK bit (bit 0) of MSR while it is not 1

inline void canLeaveInitMode( CAN_TypeDef *pCan )     { pCan->MCR &= bcCAN_MCR_INRQ_CLR_MASK; } // Set INRQ bit (bit 0) of MCR
inline void canWaitLeaveInitMode( CAN_TypeDef *pCan ) { while(getFlagInitAck(pCan)) {} } //while((pCan->MSR & 0x01)==1) {} // Test INAK bit (bit 0) of MSR while it is not 0


/* inline */  UMBA_FORCE_INLINE( void canSetTimeTriggeredMode( CAN_TypeDef *pCan, bool ttm = true )           ) { UMBA_PERIPH_BIT_SET_RESET_HELPER( pCan->MCR, bcCAN_MCR_TTCM_SET_MASK, ttm       );  }
/* inline */  UMBA_FORCE_INLINE( void canSetAutomaticBusOffMode( CAN_TypeDef *pCan, bool abom = true )        ) { UMBA_PERIPH_BIT_SET_RESET_HELPER( pCan->MCR, bcCAN_MCR_ABOM_SET_MASK, abom      );  }
/* inline */  UMBA_FORCE_INLINE( void canSetAutomaticWakeupMode( CAN_TypeDef *pCan, bool aw = true )          ) { UMBA_PERIPH_BIT_SET_RESET_HELPER( pCan->MCR, bcCAN_MCR_AWUM_SET_MASK, aw        );  }
/* inline */  UMBA_FORCE_INLINE( void canSetAutomaticRetransmissionMode( CAN_TypeDef *pCan, bool rtr = true ) ) { UMBA_PERIPH_BIT_SET_RESET_HELPER( pCan->MCR, bcCAN_MCR_NART_SET_MASK, !rtr      );  }
/* inline */  UMBA_FORCE_INLINE( void canSetReceiveFifoLockedMode( CAN_TypeDef *pCan, bool lck = true )       ) { UMBA_PERIPH_BIT_SET_RESET_HELPER( pCan->MCR, bcCAN_MCR_RFLM_SET_MASK, lck       );  }
/* inline */  UMBA_FORCE_INLINE( void canSetTransmitFifoPriority( CAN_TypeDef *pCan, bool prioChrono = true ) ) { UMBA_PERIPH_BIT_SET_RESET_HELPER( pCan->MCR, bcCAN_MCR_TXFP_SET_MASK, prioChrono);  }
/* inline */  UMBA_FORCE_INLINE( void canSetSleepMode( CAN_TypeDef *pCan, bool slp = true )                   ) { UMBA_PERIPH_BIT_SET_RESET_HELPER( pCan->MCR, bcCAN_MCR_SLEEP_SET_MASK, slp      );  }
/* inline */  UMBA_FORCE_INLINE( void canWaitSleepMode( CAN_TypeDef *pCan, bool sleepMode = true )            ) { while(getFlagSleepAck(pCan)!=sleepMode) {} }

/* inline */  UMBA_FORCE_INLINE( void canSetFilterInitMode( CAN_TypeDef *pCan, bool fltInit = true )          ) { UMBA_PERIPH_BIT_SET_RESET_HELPER( CAN1->FMR, 1u, fltInit ); }
/* inline */  UMBA_FORCE_INLINE( unsigned canGetTransmitMailboxEmptyFlags( CAN_TypeDef *pCan )                ) // 0 0 0 0...0 2 1 0
{
    return ((pCan->TSR&bcCAN_TSR_TME_CHK_MASK)>>bcCAN_TSR_MB_TME_BASE_OFFSET);
}


inline unsigned canGetTransmissionMailboxStatusLowBitNumber( CAN_TypeDef *pCan, unsigned mailBoxNo ) 
{
    switch(mailBoxNo)
    {
        case 0 : return 0;
        case 1 : return 8;
        case 2 : return 16;
        default: UMBA_ASSERT_FAIL();
    }
    return 0;
}

inline /* uint8_t */ unsigned canGetTransmissionMailboxStatusByte( CAN_TypeDef *pCan, unsigned mailBoxNo )
{
    //return (pCan->TSR >> canGetTransmissionMailboxStatusLowBitNumber( pCan, mailBoxNo ));
    return (pCan->TSR >> (bcCAN_TSR_MB_BASE_OFFSET + mailBoxNo*bcCAN_TSR_MB_SHIFT)) & bcCAN_TSR_MB_STATUS_BYTE_CHK_MASK;
}

inline void canAbortTransmit( CAN_TypeDef *pCan, unsigned mailBoxNo )
{
    pCan->TSR |= 1<<(bcCAN_TSR_MB_BASE_OFFSET + mailBoxNo*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_ABRQ_BITN);
}

inline 
bool canGetTransmissionComplete( CAN_TypeDef *pCan, unsigned mailBoxNo )
{
     return pCan->TSR & (1<<(bcCAN_TSR_MB_BASE_OFFSET + mailBoxNo*bcCAN_TSR_MB_SHIFT + bcCAN_TSR_MB_RQCP_BITN));
}

/*
XZ?
inline
void canClearTransmissionStatus( CAN_TypeDef *pCan, unsigned mailBoxNo )
{
    uint32_t bitMask = canGetTransmissionMailboxStatusLowBitNumber( pCan, mailBoxNo );
    pCan->TSR &= ~bitMask;
}
*/

inline CanTransmitMailboxStatus canGetTransmissionMailboxStatus( CAN_TypeDef *pCan, unsigned mailBoxNo )
{
    unsigned /* uint8_t */ statusByte = canGetTransmissionMailboxStatusByte( pCan, mailBoxNo );
    if (statusByte&(1<<1))
        return CanTransmitMailboxStatus::transmissionSuccessful;
    if (statusByte&(1<<2))
        return CanTransmitMailboxStatus::arbitrationError;
    if (statusByte&(1<<3))
        return CanTransmitMailboxStatus::transmissionError;

    return CanTransmitMailboxStatus::statusIncomplete;
}

//inline
UMBA_FORCE_INLINE( unsigned canGetReceiveErrorCounter( CAN_TypeDef *pCan ) )
{
    return (pCan->ESR & bcCAN_ESR_REC_CHK_MASK ) >> bcCAN_ESR_REC_BITN;
}

//inline
UMBA_FORCE_INLINE( unsigned canGetTransmitErrorCounter( CAN_TypeDef *pCan ) )
{
    return (pCan->ESR & bcCAN_ESR_TEC_CHK_MASK ) >> bcCAN_ESR_TEC_BITN;
}

//inline
UMBA_FORCE_INLINE( CanError canGetLastErrorCode( CAN_TypeDef *pCan ) )
{
    return (CanError)( (pCan->ESR & bcCAN_ESR_LEC_CHK_MASK ) >> bcCAN_ESR_LEC_BITN );
}

inline
CanBusStatus canGetBusStatus( CAN_TypeDef *pCan )
{
    if (pCan->ESR & bcCAN_ESR_EWGF_CHK_MASK)
        return CanBusStatus::warning;
    if (pCan->ESR & bcCAN_ESR_EPVF_CHK_MASK)
        return CanBusStatus::passive;
    if (pCan->ESR & bcCAN_ESR_BOFF_CHK_MASK)
        return CanBusStatus::busOff;
    return CanBusStatus::normal;
}

inline
bool canGetSilentMode( CAN_TypeDef *pCan )
{
    return (pCan->BTR & bcCAN_BTR_SILM_CHK_MASK) ? true : false;
}

inline
void canSetSilentMode( CAN_TypeDef *pCan, bool silm = true )
{
    if (silm)
        pCan->BTR |= bcCAN_BTR_SILM_SET_MASK;
    else
        pCan->BTR &= bcCAN_BTR_SILM_CLR_MASK;
}

inline
bool canGetLoopbackMode( CAN_TypeDef *pCan )
{
    return (pCan->BTR & bcCAN_BTR_LBKM_CHK_MASK) ? true : false;
}

inline
void canSetLoopbackMode( CAN_TypeDef *pCan, bool lbkm = true )
{
    if (lbkm)
        pCan->BTR |= bcCAN_BTR_LBKM_SET_MASK;
    else
        pCan->BTR &= bcCAN_BTR_LBKM_CLR_MASK;
}

//inline
UMBA_FORCE_INLINE( void canSetTimings( CAN_TypeDef *pCan, unsigned /* uint16_t */ presc, unsigned /* uint16_t */ bs1, unsigned /* uint16_t */ bs2, unsigned /* uint16_t */ sjw = 0 ) )
{
    // Bits 9:0 BRP[9:0]: Baud rate prescaler
    pCan->BTR &=                               bcCAN_BTR_BRP_CLR_MASK;
    pCan->BTR |= (presc<<bcCAN_BTR_BRP_BITN) & bcCAN_BTR_BRP_SET_MASK;

    pCan->BTR &=                               bcCAN_BTR_TS1_CLR_MASK;
    pCan->BTR |= (bs1  <<bcCAN_BTR_TS1_BITN) & bcCAN_BTR_TS1_SET_MASK;
    //umba::periph::helpers::regMaskedSet( pCan->BTR, 4, 16, bs1 );

    // Bits 22:20 TS2[2:0]: Time segment 2
    pCan->BTR &=                               bcCAN_BTR_TS2_CLR_MASK;
    pCan->BTR |= (bs2  <<bcCAN_BTR_TS2_BITN) & bcCAN_BTR_TS2_SET_MASK;

    // Bits 25:24 SJW[1:0]: Resynchronization jump width
    pCan->BTR &=                               bcCAN_BTR_SJW_CLR_MASK;
    pCan->BTR |= (sjw  <<bcCAN_BTR_SJW_BITN) & bcCAN_BTR_SJW_SET_MASK;

}

//-----------------------------------------------------------------------------
//inline
UMBA_FORCE_INLINE( uint64_t calcCanSamplePointFit( uint64_t v1, uint64_t v2 ) )
{
    int64_t i = (int64_t)v1 - (int64_t)v2;

    return (i<0) ? -i : i;
}

//-----------------------------------------------------------------------------
inline
bool calcCanTimings( uint64_t freq, uint64_t baudRate, unsigned takenPermille, unsigned /* uint16_t */ &prescaler, unsigned /* uint16_t */ &bs1, unsigned /* uint16_t */ &bs2)
{
    // SJW assumed that is 1
    constexpr unsigned /* uint16_t */  maxBs1   = 16; // PHASE_SEG1
    constexpr unsigned /* uint16_t */  maxBs2   = 8;  // PHASE_SEG2

    bool bestFound           = false;
    unsigned /* uint16_t */  bestPrescaler   = 0;
    unsigned /* uint16_t */  bestBs1         = 0;
    unsigned /* uint16_t */  bestBs2         = 0;
    unsigned bestPermilleErr = 0;

    // /* const */ uint64_t sfreq = 0;
    // /* const */ uint64_t nTQ   = 0;

    uint64_t checkFreq    = 0;
    uint64_t diffPermille = 0;

    int delta = 0;

    unsigned /* int16_t */  curPrescaler = 1;

    for(; true; ++curPrescaler)
    {
        const uint64_t sfreq = freq / curPrescaler;
        const uint64_t nTQ   = sfreq / baudRate;

        if (curPrescaler > 1024)
            break;

        if ( nTQ > (uint64_t)(1 + maxBs1 + maxBs2) )
           continue;

        if ( nTQ <= 3 )
            break;

        /* uint64_t */ checkFreq    = nTQ*baudRate;
        /* uint64_t */ diffPermille = 1000*checkFreq / sfreq;
        /* int */ delta = 1000 - (int)diffPermille;
        if (delta<0)
            delta = -delta;

        //if (nTQ*baudRate != sfreq)
        if (delta>5) //NOTE: !!! allowed speed tolerance 0.5% or less
           continue;

        for ( unsigned /* uint16_t */ bs1 = maxBs1; bs1 > 1 ; --bs1)
        {
            for(unsigned /* uint16_t */ bs2 = maxBs2; bs2 > 0 ; --bs2)
            {
                if ((1+bs1+bs2)!=nTQ)
                    continue;

                unsigned curPermille = 1000*(1+bs1) / (1+bs1+bs2);
                unsigned curPermilleErr = (unsigned)calcCanSamplePointFit( curPermille, takenPermille );
                if (!bestFound)
                {
                    bestFound        = true;
                    bestPrescaler    = curPrescaler;
                    bestBs1          = bs1;
                    bestBs2          = bs2;
                    bestPermilleErr  = curPermilleErr;
                }
                else
                {
                    if (bestPermilleErr > curPermilleErr)
                    {
                        bestPrescaler    = curPrescaler;
                        bestBs1          = bs1;
                        bestBs2          = bs2;
                        bestPermilleErr  = curPermilleErr;
                    }
                }
            }
        }
    }

    if (!bestFound)
        return bestFound;

    prescaler =  /* (uint16_t) */ (bestPrescaler - 1);
    bs1       =  /* (uint16_t) */ (bestBs1 - 1);
    bs2       =  /* (uint16_t) */ (bestBs2 - 1);
    return true;

}


/*
inline
bool canGetSleepInterruptEnable( CAN_TypeDef *pCan )
{
    return (pCan->IER & 1<<17) ? true : false;
}

inline
void canSetSleepInterruptEnable( CAN_TypeDef *pCan, bool interruptEnable = true )
{
    if (interruptEnable)
        pCan->IER |=   1<<17;
    else
        pCan->IER &= ~(1<<17);
}
*/

//-----------------------------------------------------------------------------
#define UMBA_PERIPH_TRAITS_DECL_IMPL_IE_FUNCTION( interruptName, bitNo )                \
inline                                                                                   \
bool canGet##interruptName##Enable( CAN_TypeDef *pCan )                                  \
{                                                                                        \
    return (pCan->IER & 1u<<(bitNo)) ? true : false;                                      \
}                                                                                        \
                                                                                         \
inline                                                                                   \
void canSet##interruptName##Enable( CAN_TypeDef *pCan, bool interruptEnable = true )     \
{                                                                                        \
    if (interruptEnable)                                                                 \
        pCan->IER |=   1u<<(bitNo);                                                       \
    else                                                                                 \
        pCan->IER &= ~(1u<<(bitNo));                                                      \
}

//-----------------------------------------------------------------------------
UMBA_PERIPH_TRAITS_DECL_IMPL_IE_FUNCTION( SleepInterrupt               , 17 )  // SLAKI bit
UMBA_PERIPH_TRAITS_DECL_IMPL_IE_FUNCTION( WakeupInterrupt              , 16 )  // WKUI bit
UMBA_PERIPH_TRAITS_DECL_IMPL_IE_FUNCTION( ErrorInterrupt               , 15 )  // will be generation when an error condition is pending in the CAN_ESR ???

UMBA_PERIPH_TRAITS_DECL_IMPL_IE_FUNCTION( LastErrorCodeInterrupt       , 11 )  // ERRI bit
UMBA_PERIPH_TRAITS_DECL_IMPL_IE_FUNCTION( BusOffInterrupt              , 10 )  // ERRI bit
UMBA_PERIPH_TRAITS_DECL_IMPL_IE_FUNCTION( ErrorPassiveInterrupt        ,  9 )  // ERRI bit
UMBA_PERIPH_TRAITS_DECL_IMPL_IE_FUNCTION( ErrorWarningInterrupt        ,  8 )  // ERRI bit

UMBA_PERIPH_TRAITS_DECL_IMPL_IE_FUNCTION( Fifo1_OverrunInterrupt       ,  6 )  // FOVIE1: FIFO overrun interrupt enable - FOVR bit
UMBA_PERIPH_TRAITS_DECL_IMPL_IE_FUNCTION( Fifo1_FullInterrupt          ,  5 )  // FFIE1: FIFO full interrupt enable - FULL bit
UMBA_PERIPH_TRAITS_DECL_IMPL_IE_FUNCTION( Fifo1_MessagePendingInterrupt,  4 )  // FMPIE1: FIFO message pending interrupt enable - FMP[1:0] bits are not 00b

UMBA_PERIPH_TRAITS_DECL_IMPL_IE_FUNCTION( Fifo0_OverrunInterrupt       ,  3 )  // FOVIE0: FIFO overrun interrupt enable - FOVR bit
UMBA_PERIPH_TRAITS_DECL_IMPL_IE_FUNCTION( Fifo0_FullInterrupt          ,  2 )  // FFIE0: FIFO full interrupt enable - FULL bit
UMBA_PERIPH_TRAITS_DECL_IMPL_IE_FUNCTION( Fifo0_MessagePendingInterrupt,  1 )  // FMPIE0: FIFO message pending interrupt enable - FMP[1:0] bits are not 00b

UMBA_PERIPH_TRAITS_DECL_IMPL_IE_FUNCTION( TransmitMailboxEmptyInterrupt,  0 )  // Transmit mailbox empty interrupt enable - RQCPx bit

//-----------------------------------------------------------------------------








//-----------------------------------------------------------------------------
inline
void canConfigureSpeedAndMode( CAN_TypeDef* CANx
                             , uint64_t baudRate
                             , bool silentMode   = false
                             , bool loopbackMode = false
                             , unsigned takenPermille = 875 // 700
                             )
{
    bool needLeaveInitMode = false;
    //CanInterruptFlags canInterruptFlags;

    if (!getFlagInitAck(CANx)) // init mode is inactive?
    {
        needLeaveInitMode = true;
        canEnterInitMode(CANx);
        canWaitEnterInitMode(CANx);
        //canInterruptFlags = periphGetIrqEventFlags(CANx);
    }

    canSetSilentMode  ( CANx, silentMode );
    canSetLoopbackMode( CANx, loopbackMode );

    ClockBus busCan = periphClockGetBus(CANx);
    //static 
    unsigned freqBusCan = clockGetFreq(busCan);

    unsigned /* uint16_t */  prescaler = 0;
    unsigned /* uint16_t */  bs1       = 0;
    unsigned /* uint16_t */  bs2       = 0;

    bool tmRes = calcCanTimings( freqBusCan, baudRate, takenPermille, prescaler, bs1, bs2 );

    UMBA_ASSERT( tmRes==true );

    canSetTimings( CANx, prescaler, bs1, bs2, 0 /* sjw */  );

    if (needLeaveInitMode)
    {
        //periphSetIrqEventFlags(CANx, canInterruptFlags);
        canLeaveInitMode(CANx);
        canWaitLeaveInitMode(CANx);
    }

}

//-----------------------------------------------------------------------------
inline
void periphInit( CAN_TypeDef* CANx
               , GPIO_TypeDef *portRx, uint16_t rxPinNo
               , GPIO_TypeDef *portTx, uint16_t txPinNo
               , CanInterruptFlags canInterruptFlags    // CanInterruptFlags::maskAllFlags
               , uint64_t baudRate
               , bool silentMode   = false
               , bool loopbackMode = false
               , bool priorityOrder = true
               , unsigned takenPermille = 875 // 700
               )
{
    //using namespace umba::periph::traits;
    initPeriphClock( portRx, ENABLE, getPeriphClockGpioAltFunctionFlag(portRx) );
    initPeriphClock( portTx, ENABLE, getPeriphClockGpioAltFunctionFlag(portTx) );

    initPeriphClock( CANx, ENABLE );

    canSetSleepMode( CANx, false );
    canWaitSleepMode( CANx, false );


    gpioInit( portRx, PinSpeed::high, PinMode::gpio_in_pulldown /* gpio_in_pullup */   /* alt_mode_input_floatinggpio_in_pullup */ , 1 << rxPinNo ); // GPIO_Pin_X
    gpioInit( portTx, PinSpeed::high, PinMode::alt_mode_pp            , 1 << txPinNo ); // GPIO_Pin_X

    periphAltFunctionConfigure( CANx
                              , makePinAltFunctionInfo( PinFunctionCan::rx, portRx, rxPinNo )
                              , makePinAltFunctionInfo( PinFunctionCan::tx, portTx, txPinNo )
                              );

    canEnterInitMode( CANx );
    canWaitEnterInitMode( CANx );

    CANx->MCR &= bcCAN_MCR_DBF_CLR_MASK 
              &  bcCAN_MCR_TTCM_CLR_MASK
              &  bcCAN_MCR_ABOM_CLR_MASK
              &  bcCAN_MCR_AWUM_CLR_MASK
              &  bcCAN_MCR_NART_CLR_MASK
              &  bcCAN_MCR_RFLM_CLR_MASK
              &  bcCAN_MCR_TXFP_CLR_MASK
              &  bcCAN_MCR_SLEEP_CLR_MASK;

    CANx->MCR |=   bcCAN_MCR_DBF_SET_MASK;
    // TTCM - Time Triggered Communication mode disabled
    CANx->MCR |=   bcCAN_MCR_ABOM_SET_MASK | bcCAN_MCR_AWUM_SET_MASK /*| bcCAN_MCR_NART_SET_MASK | bcCAN_MCR_RFLM_SET_MASK */ ;

    if (priorityOrder)
        CANx->MCR |= bcCAN_MCR_TXFP_SET_MASK;

    // CANx->MCR |=   bcCAN_MCR_TXFP_SET_MASK;

    canConfigureSpeedAndMode( CANx, baudRate, silentMode, loopbackMode, takenPermille );

    periphSetIrqEventFlags( CANx, canInterruptFlags );

    canLeaveInitMode(CANx);
    canWaitLeaveInitMode(CANx);

}

//-----------------------------------------------------------------------------

// 1) disable irq
// 2) init NVIC channel(enable) - void initNvicChannel( IRQn n, unsigned prio, unsigned subPrio, bool enable = true )
// 3) enable irq

//-----------------------------------------------------------------------------
// For single CAN IRQs

inline
void periphInitIrq( CAN_TypeDef* CANx, CanIrq canIrq, unsigned prio, unsigned subPrio )
{
    IRQn irqN = canGetIRQn(CANx, canIrq);
    initNvicChannel( irqN, prio, subPrio, false );
    periphEnableIRQ( irqN, true );
    initNvicChannel( irqN, prio, subPrio, true /* enable */ );
}

inline
void canInitIrq( unsigned /* uint16_t */ canNo, CanIrq canIrq, unsigned prio, unsigned subPrio )
{
    periphInitIrq( canGetCan(canNo), canIrq, prio, subPrio );
}

//-----------------------------------------------------------------------------
// 1) disable irq
// 2) init NVIC channel(disable)

inline
void periphDisableIrq( CAN_TypeDef* CANx, CanIrq canIrq )
{
    IRQn irqN = canGetIRQn(CANx, canIrq);
    initNvicChannel( irqN, 0, 0, false );
    periphEnableIRQ( irqN, false );
}

inline
void canDisableIrq( unsigned /* uint16_t */ canNo, CanIrq canIrq )
{
    periphDisableIrq( canGetCan(canNo), canIrq );
}

//-----------------------------------------------------------------------------
// For all CAN IRQs initNvicChannel in one time

inline
void periphInitIrq( CAN_TypeDef* CANx, unsigned prio, unsigned subPrio )
{
    periphInitIrq( CANx, CanIrq::tx , prio, subPrio );
    periphInitIrq( CANx, CanIrq::rx0, prio, subPrio );
    periphInitIrq( CANx, CanIrq::rx1, prio, subPrio );
    periphInitIrq( CANx, CanIrq::esr, prio, subPrio );
}

inline
void canInitIrq( unsigned /* uint16_t */ canNo, unsigned prio, unsigned subPrio )
{
    periphInitIrq( canGetCan(canNo), prio, subPrio );
}

inline
void periphDisableIrq( CAN_TypeDef* CANx )
{
    periphDisableIrq( CANx, CanIrq::tx  );
    periphDisableIrq( CANx, CanIrq::rx0 );
    periphDisableIrq( CANx, CanIrq::rx1 );
    periphDisableIrq( CANx, CanIrq::esr );
}

inline
void canDisableIrq( unsigned /* uint16_t */ canNo )
{
    periphDisableIrq( canGetCan(canNo) );
}


//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
inline
void canSetFilter( CAN_TypeDef* CANx
                 , unsigned fltNo
                 , bool listMode // mask Mode if false
                 , bool filterModeSingle32
                 , unsigned fifoNo // 0/1
                 , uint32_t flt1 // depending on filter mode
                 , uint32_t flt2
                 )
{
    uint32_t canFltIdx = 0;
    uint32_t can2StartFlt = (CAN1->FMR  & bcCAN_FMR_CAN2SB_CHK_MASK) >> bcCAN_FMR_CAN2SB_BITN;
    if (CANx==CAN1)
    {
        canFltIdx = fltNo;
        UMBA_ASSERT(canFltIdx<can2StartFlt);
    }
    #if defined(CAN2) && defined(USE_CAN2)
    else
    {
        canFltIdx = can2StartFlt+fltNo;
        UMBA_ASSERT(canFltIdx<28);
    }
    #endif

    using namespace umba::periph::traits;

    canSetFilterInitMode(CAN1, true); // or CANx?

    //umba::periph::setResetHelper( &CAN1 /* x */ ->FM1R , 1u<<canFltIdx, listMode           ); // or mask
    //umba::periph::setResetHelper( &CAN1 /* x */ ->FS1R , 1u<<canFltIdx, filterModeSingle32 );
    //umba::periph::setResetHelper( &CAN1 /* x */ ->FFA1R, 1u<<canFltIdx, fifoNo!=0          ); // Filter FIFO assignment
    //umba::periph::setResetHelper( &CAN1 /* x */ ->FA1R , 1u<<canFltIdx, true               ); // Filter activation

    UMBA_PERIPH_BIT_SET_RESET_HELPER( CAN1->FM1R , 1u<<canFltIdx, listMode           );
    UMBA_PERIPH_BIT_SET_RESET_HELPER( CAN1->FS1R , 1u<<canFltIdx, filterModeSingle32 );
    UMBA_PERIPH_BIT_SET_RESET_HELPER( CAN1->FFA1R, 1u<<canFltIdx, fifoNo!=0          );
    UMBA_PERIPH_BIT_SET_RESET_HELPER( CAN1->FA1R , 1u<<canFltIdx, true               );

    CAN1 /* x */ ->sFilterRegister[canFltIdx].FR1 = flt1;
    CAN1 /* x */ ->sFilterRegister[canFltIdx].FR2 = flt2;

    canSetFilterInitMode(CAN1, false); // or CANx?
}

//-----------------------------------------------------------------------------
inline
int canFindEmptyTxMailbox( CAN_TypeDef* CANx )
{
    // Bit 28 TME2: Transmit mailbox 2 empty - This bit is set by hardware when no transmit request is pending for mailbox 2.
    // Bit 27 TME1: Transmit mailbox 1 empty - This bit is set by hardware when no transmit request is pending for mailbox 1.
    // Bit 26 TME0: Transmit mailbox 0 empty - This bit is set by hardware when no transmit request is pending for mailbox 0.

    /*
    constexpr unsigned baseBit = 26;
    if ( CANx->TSR & (1<<(baseBit+0)) )
       return 0;
    if ( CANx->TSR & (1<<(baseBit+1)) )
       return 1;
    if ( CANx->TSR & (1<<(baseBit+2)) )
       return 2;
    */

    for( unsigned nMailBox=0; nMailBox!=3; ++nMailBox)
    {
        unsigned bitNo = bcCAN_TSR_MB_TME_BASE_OFFSET + nMailBox;
        if (CANx->TSR & (1<<bitNo))
            return (int)nMailBox;
    }
    return -1;
}

//-----------------------------------------------------------------------------
inline
unsigned canGetEmptyTxMailboxTotal( CAN_TypeDef* CANx )
{
    return 3;
}

inline
unsigned canGetEmptyTxMailboxCount( CAN_TypeDef* CANx )
{
    unsigned res = 0;
    for( unsigned nMailBox=0; nMailBox!=3; ++nMailBox)
    {
        unsigned bitNo = bcCAN_TSR_MB_TME_BASE_OFFSET + nMailBox;
        if (CANx->TSR & (1<<bitNo))
            ++res;
    }

    return res;
}

//-----------------------------------------------------------------------------
inline
bool canCanTransmit( CAN_TypeDef* CANx )
{
    return canFindEmptyTxMailbox( CANx ) >= 0;
}

//-----------------------------------------------------------------------------
inline
bool canTransmit( CAN_TypeDef* CANx, uint32_t canId, std::size_t dlc, const uint8_t *pData )
{
    int mbNo = canFindEmptyTxMailbox( CANx );

    if (mbNo<0 || mbNo>2)
        return false;

    if (!pData)
        dlc = 0;

    if (dlc>8)
        dlc = 8;

    /*

    CANx->sTxMailBox[mbNo].TIR   // CAN TX mailbox identifier register
    CANx->sTxMailBox[mbNo].TDTR  // CAN mailbox data length control and time stamp register
    CANx->sTxMailBox[mbNo].TDLR  // CAN mailbox data low register
    CANx->sTxMailBox[mbNo].TDHR  // CAN mailbox data high register

    TIR
    Bits 31:21 STID[10:0]/EXID[28:18]: Standard identifier or extended identifier
    Bits 20:3 EXID[17:0]: Extended identifier
    Bit 2 IDE: Identifier extension
    Bit 1 RTR: Remote transmission request
    Bit 0 TXRQ: Transmit mailbox request

    */

    // Set up CAN identifier register

    CANx->sTxMailBox[mbNo].TIR = 0; // Clear all

    if (canId&CAN_RTR_FLAG)
        CANx->sTxMailBox[mbNo].TIR |= bcCAN_TIR_TXRQ_SET_MASK; // Set Remote transmission request mode

    uint32_t canIdStdPart = canId&CAN_SFF_MASK;
    CANx->sTxMailBox[mbNo].TIR |= canIdStdPart<<bcCAN_TIR_STD_BITN;

    if (canId&CAN_EFF_FLAG)
    {
        uint32_t canIdExPart  = (canId&CAN_EFF_MASK)>>11;
        CANx->sTxMailBox[mbNo].TIR |= canIdExPart<<bcCAN_TIR_EXID_BITN;

        CANx->sTxMailBox[mbNo].TIR |= bcCAN_TIR_IDE_SET_MASK; // Set extended ID mode
    }

    CANx->sTxMailBox[mbNo].TDTR &= bcCAN_TDTR_TGT_CLR_MASK & bcCAN_TDTR_DLC_CLR_MASK;
    CANx->sTxMailBox[mbNo].TDTR |= ((uint32_t)(dlc))<<bcCAN_TDTR_DLC_BITN;

    uint64_t data = 0;
    for(std::size_t i=0; i!=dlc; ++i, ++pData)
    {
        data |= ((uint64_t)*pData)<<(8*i);
    }

    CANx->sTxMailBox[mbNo].TDLR = data; //&0xFFFFFFFFu; // маска не нужна
    CANx->sTxMailBox[mbNo].TDHR = (data>>32);//&0xFFFFFFFFu;

    CANx->sTxMailBox[mbNo].TIR |= bcCAN_TIR_TXRQ_SET_MASK; // Set TXRQ: Transmit mailbox request

    return true;
}

//-----------------------------------------------------------------------------
inline
std::size_t canFifoGetMessagesPendingCount( CAN_TypeDef* CANx, std::size_t fifoNo )
{
    if (fifoNo==0)
        return (CANx->RF0R&bcCAN_RFR_FMP_CHK_MASK)>>bcCAN_RFR_FMP_BITN;

    return (CANx->RF1R&bcCAN_RFR_FMP_CHK_MASK)>>bcCAN_RFR_FMP_BITN;
}

//-----------------------------------------------------------------------------
inline
std::size_t canFifoGetMessagesPendingCount( CAN_TypeDef* CANx )
{
    std::size_t res = 0;

    for(std::size_t fifoNo=0; fifoNo!=2; ++fifoNo)
    {
        res += canFifoGetMessagesPendingCount( CANx, fifoNo );
    }

    return res;
}

//-----------------------------------------------------------------------------
inline
void canFifoRelease( CAN_TypeDef* CANx, std::size_t fifoNo )
{
    if (fifoNo==0)
        CANx->RF0R |= bcCAN_RFR_RFOM_SET_MASK;
    else
        CANx->RF1R |= bcCAN_RFR_RFOM_SET_MASK;
}

//-----------------------------------------------------------------------------
inline
bool canFifoGetDataUnchecked( CAN_TypeDef* CANx
                          , uint32_t &canId, uint8_t &dlc, uint8_t *pBuf /* must be enough space */
                          , std::size_t fifoNo
                          )
{
    canId = 0;
    dlc   = 0;

    //canId = (CANx->sFIFOMailBox[fifoNo].RIR >>21) & CAN_SFF_MASK;
    canId = ((CANx->sFIFOMailBox[fifoNo].RIR & bcCAN_RIR_STID_CHK_MASK) >> bcCAN_RIR_STID_BITN);

    if ((CANx->sFIFOMailBox[fifoNo].RIR & bcCAN_RIR_IDE_CHK_MASK))
    {
        canId |= CAN_EFF_FLAG;
        canId |= ((CANx->sFIFOMailBox[fifoNo].RIR & bcCAN_RIR_EXID_CHK_MASK)>>bcCAN_RIR_EXID_BITN) << 11;
    }

    if (CANx->sFIFOMailBox[fifoNo].RIR & bcCAN_RIR_RTR_CHK_MASK)
        canId |= CAN_RTR_FLAG;

    dlc = (CANx->sFIFOMailBox[fifoNo].RDTR & bcCAN_RDTR_DLC_CHK_MASK)>>bcCAN_RDTR_DLC_BITN;
    if (dlc>8)
        dlc = 8;

    uint64_t data = (((uint64_t)CANx->sFIFOMailBox[fifoNo].RDHR)<<32) | ((uint64_t)CANx->sFIFOMailBox[fifoNo].RDLR);

    for(uint8_t i=0; i!=dlc; ++i, ++pBuf, data>>=8)
    {
        *pBuf = (uint8_t)(data&0xFFu);
    }

    canFifoRelease( CANx, fifoNo );

    return true;
}

//-----------------------------------------------------------------------------
inline
bool canFifoGetDataUnchecked( CAN_TypeDef* CANx
                          , uint32_t &canId, std::size_t &dlc, uint8_t *pBuf /* must be enough space */
                          , std::size_t fifoNo
                          )
{
    uint8_t u8dlc;
    if (canFifoGetDataUnchecked( CANx, canId, u8dlc, pBuf, fifoNo ))
    {
        dlc = u8dlc;
        return true;
    }

    return false;
}

//-----------------------------------------------------------------------------
inline
bool canFifoGetData( CAN_TypeDef* CANx
                   , uint32_t &canId, std::size_t &dlc, uint8_t *pBuf /* must be enough space */
                   , std::size_t fifoNo
                   )
{
    if (fifoNo>1)
        return false;

    if (canFifoGetMessagesPendingCount( CANx, fifoNo )==0)
        return false;

    return canFifoGetDataUnchecked(CANx, canId, dlc, pBuf, fifoNo);
}

inline
bool canFifoGetData( CAN_TypeDef* CANx
                   , uint32_t &canId, std::size_t &dlc, uint8_t *pBuf /* must be enough space */
                   , std::size_t *pFifoNo = 0
                   )
{
    for(std::size_t fifoNo=0; fifoNo!=2; ++fifoNo)
    {
        if (canFifoGetMessagesPendingCount( CANx, fifoNo ))
        {
            if (canFifoGetDataUnchecked( CANx, canId, dlc, pBuf, fifoNo ))
            {
                if (pFifoNo)
                   *pFifoNo = fifoNo;

                return true;
            }
        }
    }

    return false;
}




} // namespace traits
} // namespace periph
} // namespace umba


