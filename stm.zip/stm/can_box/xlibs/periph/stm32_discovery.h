#pragma once

/* Definitions for STM32 Discovery boards

*/

#include "stm32_traits.h"
#include "stm32_pinaddrs.h"


#if !defined(HSE_VALUE)
    #error "External frequency source freq (HSE_VALUE) not defined"
#endif


#ifndef STM32_DISCOVERY_DONT_CHECK_HSE
    #if HSE_VALUE!=8000000
        #error "Invalid external frequency source freq (HSE_VALUE) - must be 8000000"
    #endif
#endif

#if defined(STM32F1_SERIES)

    #if defined(STM32F100)
        #define STM32_DISCOVERY_NAME       "STM32F100"
    #else
        #define STM32_DISCOVERY_NAME       "STM32F103"
    #endif
    #define STM32_DISCOVERY_NUM_LEDS   2

    /*

    B1: Push button B1 labeled USER is connected to the I/O PA0 of STM32F100RBT6B and can be used as WAKE-UP.
    B2: Push button B2 labeled RST is dedicated to the RESET pin of STM32F100RBT6B

    LD1: Red LED LD1 labeled COM indicates communication between PC and ST-Link.
    LD2: Red LED LD2 labeled PWR indicates that the board is powered.
    LD3: Green LED LD3 labeled PC9 is connected to the I/O PC9 of STM32F100RBT6B.
    LD4: Blue  LED LD4 labeled PC8 is connected to the I/O PC8 of STM32F100RBT6B

    */

    // Buttons

    #define STM32_DISCOVERY_B1_GPIO_PIN_NO                                  0
    #define STM32_DISCOVERY_B1_GPIO_PIN_ADDR                                UMBA_PINADDR_PA0
    #define STM32_DISCOVERY_B1_GPIO_PIN_ADDR_DIR                            UMBA_PINADDR_PA0, UMBA_GPIO_DIRECTION_IN
    #define STM32_DISCOVERY_BTN_USER_GPIO_PIN_NO                            STM32_DISCOVERY_B1_GPIO_PIN_NO      
    #define STM32_DISCOVERY_BTN_USER_GPIO_PIN_ADDR                          STM32_DISCOVERY_B1_GPIO_PIN_ADDR    
    #define STM32_DISCOVERY_BTN_USER_GPIO_PIN_ADDR_DIR                      STM32_DISCOVERY_B1_GPIO_PIN_ADDR_DIR
                                                                     
                                                                     
    // LEDs                                                          
                                                                     
    // Green
    #define STM32_DISCOVERY_LD3_GPIO_PIN_ADDR                               UMBA_PINADDR_PC9
    #define STM32_DISCOVERY_LD3_GPIO_PIN_ADDR_DIR                           UMBA_PINADDR_PC9, UMBA_GPIO_DIRECTION_OUT 

    #define STM32_DISCOVERY_LED_GREEN_GPIO_PIN_ADDR                         STM32_DISCOVERY_LD3_GPIO_PIN_ADDR    
    #define STM32_DISCOVERY_LED_GREEN_GPIO_PIN_ADDR_DIR                     STM32_DISCOVERY_LD3_GPIO_PIN_ADDR_DIR

    // Blue                                                                 
    #define STM32_DISCOVERY_LD4_GPIO_PIN_ADDR                               UMBA_PINADDR_PC8
    #define STM32_DISCOVERY_LD4_GPIO_PIN_ADDR_DIR                           UMBA_PINADDR_PC8, UMBA_GPIO_DIRECTION_OUT 

    #define STM32_DISCOVERY_LED_BLUE_GPIO_PIN_ADDR                          STM32_DISCOVERY_LD4_GPIO_PIN_ADDR    
    #define STM32_DISCOVERY_LED_BLUE_GPIO_PIN_ADDR_DIR                      STM32_DISCOVERY_LD4_GPIO_PIN_ADDR_DIR


    // Common single led (all boards compatible definition)
    #define STM32_DISCOVERY_LED_GPIO_PIN_ADDR                               STM32_DISCOVERY_LD3_GPIO_PIN_ADDR    
    #define STM32_DISCOVERY_LED_GPIO_PIN_ADDR_DIR                           STM32_DISCOVERY_LD3_GPIO_PIN_ADDR_DIR

    // UART

    #define STM32_DISCOVERY_UART                                            UART1
    #define STM32_DISCOVERY_LEGACY_UART                                     uart::uart1
                                                                      
    #define STM32_DISCOVERY_UART_TX_GPIO                                    GPIOA
    #define STM32_DISCOVERY_UART_TX_GPIO_PIN_NO                             9
    #define STM32_DISCOVERY_UART_TX_GPIO_PIN_ADDR                           UMBA_PINADDR_PA9
    #define STM32_DISCOVERY_UART_TX_GPIO_PIN_SOURCE                         GPIO_PinSource9
    #define STM32_DISCOVERY_UART_TX_GPIO_PIN_DIRECTION                      UMBA_GPIO_DIRECTION_OUT
                                                                      
    #define STM32_DISCOVERY_UART_RX_GPIO                                    GPIOA
    #define STM32_DISCOVERY_UART_RX_GPIO_PIN_NO                             10
    #define STM32_DISCOVERY_UART_RX_GPIO_PIN_ADDR                           UMBA_PINADDR_PA10
    #define STM32_DISCOVERY_UART_RX_GPIO_PIN_SOURCE                         GPIO_PinSource10
    #define STM32_DISCOVERY_UART_RX_GPIO_PIN_DIRECTION                      UMBA_GPIO_DIRECTION_IN


#elif defined(STM32F3_SERIES)

    #define STM32_DISCOVERY_NAME       "STM32F303"
    #define STM32_DISCOVERY_NUM_LEDS   8

    /*

    B1 USER: user and wake-up button connected to the I/O PA0 of the STM32F303VCT6.
    B2 RESET: push-button connected to NRST is used to RESET the STM32F303VCT6
    
    LD1 PWR: red LED indicates that the board is powered.
    LD2 COM: LD2 default status is red. LD2 turns to green to indicate that communications are in progress between the PC and the ST-LINK/V2.
    User LD3: red LED    is a user LED connected to the I/O PE9  of the STM32F303VCT6.
    User LD4: blue LED   is a user LED connected to the I/O PE8  of the STM32F303VCT6.
    User LD5: orange LED is a user LED connected to the I/O PE10 of the STM32F303VCT6.
    User LD6: green LED  is a user LED connected to the I/O PE15 of the STM32F303VCT6.
    User LD7: green LED  is a user LED connected to the I/O PE11 of the STM32F303VCT6.
    User LD8: orange LED is a user LED connected to the I/O PE14 of the STM32F303VCT6.
    User LD9: blue LED   is a user LED connected to the I/O PE12 of the STM32F303VCT6.
    User LD10: red LED   is a user LED connected to the I/O PE13 of the STM32F303VCT6.

    */

    // Buttons

    #define STM32_DISCOVERY_B1_GPIO_PIN_NO                                  0
    #define STM32_DISCOVERY_B1_GPIO_PIN_ADDR                                UMBA_PINADDR_PA0
    #define STM32_DISCOVERY_B1_GPIO_PIN_ADDR_DIR                            UMBA_PINADDR_PA0, UMBA_GPIO_DIRECTION_IN
    #define STM32_DISCOVERY_BTN_USER_GPIO_PIN_NO                            STM32_DISCOVERY_B1_GPIO_PIN_NO      
    #define STM32_DISCOVERY_BTN_USER_GPIO_PIN_ADDR                          STM32_DISCOVERY_B1_GPIO_PIN_ADDR    
    #define STM32_DISCOVERY_BTN_USER_GPIO_PIN_ADDR_DIR                      STM32_DISCOVERY_B1_GPIO_PIN_ADDR_DIR
                                                                     
                                                                     
    // LEDs                                                          
                                                                     
    #define STM32_DISCOVERY_LD3_GPIO_PIN_ADDR                               UMBA_PINADDR_PE9
    #define STM32_DISCOVERY_LD3_GPIO_PIN_ADDR_DIR                           UMBA_PINADDR_PE9, UMBA_GPIO_DIRECTION_OUT 
                                                                     
    #define STM32_DISCOVERY_LD4_GPIO_PIN_ADDR                               UMBA_PINADDR_PE8
    #define STM32_DISCOVERY_LD4_GPIO_PIN_ADDR_DIR                           UMBA_PINADDR_PE8, UMBA_GPIO_DIRECTION_OUT 
                                                                     
    #define STM32_DISCOVERY_LD5_GPIO_PIN_ADDR                               UMBA_PINADDR_PE10
    #define STM32_DISCOVERY_LD5_GPIO_PIN_ADDR_DIR                           UMBA_PINADDR_PE10, UMBA_GPIO_DIRECTION_OUT 
                                                                     
    #define STM32_DISCOVERY_LD6_GPIO_PIN_ADDR                               UMBA_PINADDR_PE15
    #define STM32_DISCOVERY_LD6_GPIO_PIN_ADDR_DIR                           UMBA_PINADDR_PE15, UMBA_GPIO_DIRECTION_OUT 
                                                                     
    #define STM32_DISCOVERY_LD7_GPIO_PIN_ADDR                               UMBA_PINADDR_PE11
    #define STM32_DISCOVERY_LD7_GPIO_PIN_ADDR_DIR                           UMBA_PINADDR_PE11, UMBA_GPIO_DIRECTION_OUT 
                                                                     
    #define STM32_DISCOVERY_LD8_GPIO_PIN_ADDR                               UMBA_PINADDR_PE14
    #define STM32_DISCOVERY_LD8_GPIO_PIN_ADDR_DIR                           UMBA_PINADDR_PE14, UMBA_GPIO_DIRECTION_OUT 
                                                                     
    #define STM32_DISCOVERY_LD9_GPIO_PIN_ADDR                               UMBA_PINADDR_PE12
    #define STM32_DISCOVERY_LD9_GPIO_PIN_ADDR_DIR                           UMBA_PINADDR_PE12, UMBA_GPIO_DIRECTION_OUT 
                                                                     
    #define STM32_DISCOVERY_LD10_GPIO_PIN_ADDR                              UMBA_PINADDR_PE13
    #define STM32_DISCOVERY_LD10_GPIO_PIN_ADDR_DIR                          UMBA_PINADDR_PE13, UMBA_GPIO_DIRECTION_OUT 

    // Common single led (all boards compatible definition)
    #define STM32_DISCOVERY_LED_GPIO_PIN_ADDR                               STM32_DISCOVERY_LD3_GPIO_PIN_ADDR    
    #define STM32_DISCOVERY_LED_GPIO_PIN_ADDR_DIR                           STM32_DISCOVERY_LD3_GPIO_PIN_ADDR_DIR


    // UART

    #define STM32_DISCOVERY_VCP_UART                                        UART1
    #define STM32_DISCOVERY_VCP_LEGACY_UART                                 uart::uart1
                                                                      
    #define STM32_DISCOVERY_VCP_UART_TX_GPIO                                GPIOC
    #define STM32_DISCOVERY_VCP_UART_TX_GPIO_PIN_NO                         4
    #define STM32_DISCOVERY_VCP_UART_TX_GPIO_PIN_ADDR                       UMBA_PINADDR_PC4
    #define STM32_DISCOVERY_VCP_UART_TX_GPIO_PIN_SOURCE                     GPIO_PinSource4
    #define STM32_DISCOVERY_VCP_UART_TX_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT
                                                                      
    #define STM32_DISCOVERY_VCP_UART_RX_GPIO                                GPIOC
    #define STM32_DISCOVERY_VCP_UART_RX_GPIO_PIN_NO                         5
    #define STM32_DISCOVERY_VCP_UART_RX_GPIO_PIN_ADDR                       UMBA_PINADDR_PC5
    #define STM32_DISCOVERY_VCP_UART_RX_GPIO_PIN_SOURCE                     GPIO_PinSource5
    #define STM32_DISCOVERY_VCP_UART_RX_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_IN
                                                                      
                                                                      
    #define STM32_DISCOVERY_UART                                            STM32_DISCOVERY_VCP_UART                      
    #define STM32_DISCOVERY_LEGACY_UART                                     STM32_DISCOVERY_VCP_LEGACY_UART               
                                                                                                              
    #define STM32_DISCOVERY_UART_TX_GPIO                                    STM32_DISCOVERY_VCP_UART_TX_GPIO              
    #define STM32_DISCOVERY_UART_TX_GPIO_PIN_NO                             STM32_DISCOVERY_VCP_UART_TX_GPIO_PIN_NO       
    #define STM32_DISCOVERY_UART_TX_GPIO_PIN_ADDR                           STM32_DISCOVERY_VCP_UART_TX_GPIO_PIN_ADDR     
    #define STM32_DISCOVERY_UART_TX_GPIO_PIN_SOURCE                         STM32_DISCOVERY_VCP_UART_TX_GPIO_PIN_SOURCE   
    #define STM32_DISCOVERY_UART_TX_GPIO_PIN_DIRECTION                      STM32_DISCOVERY_VCP_UART_TX_GPIO_PIN_DIRECTION
                                                                                                              
    #define STM32_DISCOVERY_UART_RX_GPIO                                    STM32_DISCOVERY_VCP_UART_RX_GPIO              
    #define STM32_DISCOVERY_UART_RX_GPIO_PIN_NO                             STM32_DISCOVERY_VCP_UART_RX_GPIO_PIN_NO       
    #define STM32_DISCOVERY_UART_RX_GPIO_PIN_ADDR                           STM32_DISCOVERY_VCP_UART_RX_GPIO_PIN_ADDR     
    #define STM32_DISCOVERY_UART_RX_GPIO_PIN_SOURCE                         STM32_DISCOVERY_VCP_UART_RX_GPIO_PIN_SOURCE   
    #define STM32_DISCOVERY_UART_RX_GPIO_PIN_DIRECTION                      STM32_DISCOVERY_VCP_UART_RX_GPIO_PIN_DIRECTION


    // ST MEMS Gyroscope (ST MEMS L3GD20)

    #define STM32_DISCOVERY_L3GD20_SPI                                      SPI1
    #define STM32_DISCOVERY_L3GD20_SPI_SCK_GPIO                             GPIOA
    #define STM32_DISCOVERY_L3GD20_SPI_SCK_GPIO_PIN_NO                      5
    #define STM32_DISCOVERY_L3GD20_SPI_SCK_GPIO_PIN_ADDR                    UMBA_PINADDR_PA5
    #define STM32_DISCOVERY_L3GD20_SPI_SCK_GPIO_PIN_ADDR_DIR                UMBA_PINADDR_PA5, UMBA_GPIO_DIRECTION_OUT
    #define STM32_DISCOVERY_L3GD20_SPI_SCK_GPIO_PIN_SOURCE                  GPIO_PinSource5
    #define STM32_DISCOVERY_L3GD20_SPI_SCK_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_OUT
    
    #define STM32_DISCOVERY_L3GD20_SPI_MOSI_GPIO                            GPIOA
    #define STM32_DISCOVERY_L3GD20_SPI_MOSI_GPIO_PIN_NO                     7
    #define STM32_DISCOVERY_L3GD20_SPI_MOSI_GPIO_PIN_ADDR                   UMBA_PINADDR_PA7
    #define STM32_DISCOVERY_L3GD20_SPI_MOSI_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PA7, UMBA_GPIO_DIRECTION_OUT
    #define STM32_DISCOVERY_L3GD20_SPI_MOSI_GPIO_PIN_SOURCE                 GPIO_PinSource7
    #define STM32_DISCOVERY_L3GD20_SPI_MOSI_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_OUT
    
    #define STM32_DISCOVERY_L3GD20_SPI_MISO_GPIO                            GPIOA
    #define STM32_DISCOVERY_L3GD20_SPI_MISO_GPIO_PIN_NO                     6
    #define STM32_DISCOVERY_L3GD20_SPI_MISO_GPIO_PIN_ADDR                   UMBA_PINADDR_PA6
    #define STM32_DISCOVERY_L3GD20_SPI_MISO_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PA6, UMBA_GPIO_DIRECTION_IN
    #define STM32_DISCOVERY_L3GD20_SPI_MISO_GPIO_PIN_SOURCE                 GPIO_PinSource6
    #define STM32_DISCOVERY_L3GD20_SPI_MISO_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_IN
    
    #define STM32_DISCOVERY_L3GD20_INT1_GPIO                                GPIOE
    #define STM32_DISCOVERY_L3GD20_INT1_GPIO_PIN_NO                         0
    #define STM32_DISCOVERY_L3GD20_INT1_GPIO_PIN_ADDR                       UMBA_PINADDR_PE0
    #define STM32_DISCOVERY_L3GD20_INT1_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PE0, UMBA_GPIO_DIRECTION_IN
    #define STM32_DISCOVERY_L3GD20_INT1_GPIO_PIN_SOURCE                     GPIO_PinSource0
    #define STM32_DISCOVERY_L3GD20_INT1_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_IN
    
    #define STM32_DISCOVERY_L3GD20_INT2_GPIO                                GPIOE
    #define STM32_DISCOVERY_L3GD20_INT2_GPIO_PIN_NO                         1
    #define STM32_DISCOVERY_L3GD20_INT2_GPIO_PIN_ADDR                       UMBA_PINADDR_PE1
    #define STM32_DISCOVERY_L3GD20_INT2_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PE1, UMBA_GPIO_DIRECTION_IN
    #define STM32_DISCOVERY_L3GD20_INT2_GPIO_PIN_SOURCE                     GPIO_PinSource1
    #define STM32_DISCOVERY_L3GD20_INT2_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_IN
    
    #define STM32_DISCOVERY_L3GD20_CS_GPIO                                  GPIOE
    #define STM32_DISCOVERY_L3GD20_CS_GPIO_PIN_NO                           3
    #define STM32_DISCOVERY_L3GD20_CS_GPIO_PIN_ADDR                         UMBA_PINADDR_PE3
    #define STM32_DISCOVERY_L3GD20_CS_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PE3, UMBA_GPIO_DIRECTION_IN
    #define STM32_DISCOVERY_L3GD20_CS_GPIO_PIN_SOURCE                       GPIO_PinSource3
    #define STM32_DISCOVERY_L3GD20_CS_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_IN
    
    
    // ST MEMS E-compass (ST MEMS LSM303DLHC)
    
    #define STM32_DISCOVERY_L3GD20_I2C                                      I2C1
    #define STM32_DISCOVERY_LSM303DLHC_I2C_SCL_GPIO                         GPIOB
    #define STM32_DISCOVERY_LSM303DLHC_I2C_SCL_GPIO_PIN_NO                  6
    #define STM32_DISCOVERY_LSM303DLHC_I2C_SCL_GPIO_PIN_ADDR                UMBA_PINADDR_PB6
    #define STM32_DISCOVERY_LSM303DLHC_I2C_SCL_GPIO_PIN_ADDR_DIR            UMBA_PINADDR_PB6, UMBA_GPIO_DIRECTION_OUT
    #define STM32_DISCOVERY_LSM303DLHC_I2C_SCL_GPIO_PIN_SOURCE              GPIO_PinSource6
    #define STM32_DISCOVERY_LSM303DLHC_I2C_SCL_GPIO_PIN_DIRECTION           UMBA_GPIO_DIRECTION_OUT
    
    #define STM32_DISCOVERY_LSM303DLHC_I2C_SDA_GPIO                         GPIOB
    #define STM32_DISCOVERY_LSM303DLHC_I2C_SDA_GPIO_PIN_NO                  7
    #define STM32_DISCOVERY_LSM303DLHC_I2C_SDA_GPIO_PIN_ADDR                UMBA_PINADDR_PB7
    #define STM32_DISCOVERY_LSM303DLHC_I2C_SDA_GPIO_PIN_ADDR_DIR            UMBA_PINADDR_PB7, UMBA_GPIO_DIRECTION_OUT
    #define STM32_DISCOVERY_LSM303DLHC_I2C_SDA_GPIO_PIN_SOURCE              GPIO_PinSource7
    #define STM32_DISCOVERY_LSM303DLHC_I2C_SDA_GPIO_PIN_DIRECTION           UMBA_GPIO_DIRECTION_OUT
    
    
    #define STM32_DISCOVERY_LSM303DLHC_DRDY_GPIO                            GPIOE
    #define STM32_DISCOVERY_LSM303DLHC_DRDY_GPIO_PIN_NO                     2
    #define STM32_DISCOVERY_LSM303DLHC_DRDY_GPIO_PIN_ADDR                   UMBA_PINADDR_PE2
    #define STM32_DISCOVERY_LSM303DLHC_DRDY_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PE2, UMBA_GPIO_DIRECTION_IN
    #define STM32_DISCOVERY_LSM303DLHC_DRDY_GPIO_PIN_SOURCE                 GPIO_PinSource2
    #define STM32_DISCOVERY_LSM303DLHC_DRDY_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_IN
    
    #define STM32_DISCOVERY_LSM303DLHC_INT1_GPIO                            GPIOE
    #define STM32_DISCOVERY_LSM303DLHC_INT1_GPIO_PIN_NO                     4
    #define STM32_DISCOVERY_LSM303DLHC_INT1_GPIO_PIN_ADDR                   UMBA_PINADDR_PE4
    #define STM32_DISCOVERY_LSM303DLHC_INT1_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PE4, UMBA_GPIO_DIRECTION_IN
    #define STM32_DISCOVERY_LSM303DLHC_INT1_GPIO_PIN_SOURCE                 GPIO_PinSource4
    #define STM32_DISCOVERY_LSM303DLHC_INT1_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_IN
    
    #define STM32_DISCOVERY_LSM303DLHC_INT2_GPIO                            GPIOE
    #define STM32_DISCOVERY_LSM303DLHC_INT2_GPIO_PIN_NO                     5
    #define STM32_DISCOVERY_LSM303DLHC_INT2_GPIO_PIN_ADDR                   UMBA_PINADDR_PE5
    #define STM32_DISCOVERY_LSM303DLHC_INT2_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PE5, UMBA_GPIO_DIRECTION_IN
    #define STM32_DISCOVERY_LSM303DLHC_INT2_GPIO_PIN_SOURCE                 GPIO_PinSource5
    #define STM32_DISCOVERY_LSM303DLHC_INT2_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_IN


#elif defined(STM32F4_SERIES)

    #define STM32_DISCOVERY_NAME       "STM32F407"
    #define STM32_DISCOVERY_NUM_LEDS   4

    /*

    B1 USER: User and Wake-Up buttons are connected to the I/O PA0 of the STM32F407VG.
    B2 RESET: Push button connected to NRST is used to RESET the STM32F407VG.

    LD1 COM: LD1 default status is red. LD1 turns to green to indicate that communications are in progress between the PC and the ST-LINK/V2.
    LD2 PWR: red LED indicates that the board is powered.
    User LD3: orange LED is a user LED connected to the I/O PD13 of the STM32F407VGT6.
    User LD4: green  LED is a user LED connected to the I/O PD12 of the STM32F407VGT6.
    User LD5: red    LED is a user LED connected to the I/O PD14 of the STM32F407VGT6. 
    User LD6: blue   LED is a user LED connected to the I/O PD15 of the STM32F407VGT6.
    USB LD7: green   LED indicates when VBUS is present on CN5 and is connected to PA9 of the STM32F407VGT6.
    USB LD8: red     LED indicates an overcurrent from VBUS of CN5 and is connected to the I/O PD5 of the STM32F407VGT6.

    */

    // Buttons

    #define STM32_DISCOVERY_B1_GPIO_PIN_NO                                  0
    #define STM32_DISCOVERY_B1_GPIO_PIN_ADDR                                UMBA_PINADDR_PA0
    #define STM32_DISCOVERY_B1_GPIO_PIN_ADDR_DIR                            UMBA_PINADDR_PA0, UMBA_GPIO_DIRECTION_IN
    #define STM32_DISCOVERY_BTN_USER_GPIO_PIN_NO                            STM32_DISCOVERY_B1_GPIO_PIN_NO
    #define STM32_DISCOVERY_BTN_USER_GPIO_PIN_ADDR                          STM32_DISCOVERY_B1_GPIO_PIN_ADDR    
    #define STM32_DISCOVERY_BTN_USER_GPIO_PIN_ADDR_DIR                      STM32_DISCOVERY_B1_GPIO_PIN_ADDR_DIR
                                                                     
                                                                     
    // LEDs                                                          
                                                                     
    #define STM32_DISCOVERY_LD3_GPIO_PIN_ADDR                               UMBA_PINADDR_PD13
    #define STM32_DISCOVERY_LD3_GPIO_PIN_ADDR_DIR                           UMBA_PINADDR_PD13, UMBA_GPIO_DIRECTION_OUT 
                                                                     
    #define STM32_DISCOVERY_LD4_GPIO_PIN_ADDR                               UMBA_PINADDR_PD12
    #define STM32_DISCOVERY_LD4_GPIO_PIN_ADDR_DIR                           UMBA_PINADDR_PD12, UMBA_GPIO_DIRECTION_OUT 
                                                                     
    #define STM32_DISCOVERY_LD5_GPIO_PIN_ADDR                               UMBA_PINADDR_PD14
    #define STM32_DISCOVERY_LD5_GPIO_PIN_ADDR_DIR                           UMBA_PINADDR_PD14, UMBA_GPIO_DIRECTION_OUT 
                                                                     
    #define STM32_DISCOVERY_LD6_GPIO_PIN_ADDR                               UMBA_PINADDR_PD15
    #define STM32_DISCOVERY_LD6_GPIO_PIN_ADDR_DIR                           UMBA_PINADDR_PD15, UMBA_GPIO_DIRECTION_OUT 

    // Common single led (all boards compatible definition)
    #define STM32_DISCOVERY_LED_GPIO_PIN_ADDR                               STM32_DISCOVERY_LD3_GPIO_PIN_ADDR    
    #define STM32_DISCOVERY_LED_GPIO_PIN_ADDR_DIR                           STM32_DISCOVERY_LD3_GPIO_PIN_ADDR_DIR

    // UART

    #define STM32_DISCOVERY_UART                                            UART1
    #define STM32_DISCOVERY_LEGACY_UART                                     uart::uart1
                                                                      
    #define STM32_DISCOVERY_UART_TX_GPIO                                    GPIOB
    #define STM32_DISCOVERY_UART_TX_GPIO_PIN_NO                             6
    #define STM32_DISCOVERY_UART_TX_GPIO_PIN_ADDR                           UMBA_PINADDR_PB6
    #define STM32_DISCOVERY_UART_TX_GPIO_PIN_SOURCE                         GPIO_PinSource6
    #define STM32_DISCOVERY_UART_TX_GPIO_PIN_DIRECTION                      UMBA_GPIO_DIRECTION_OUT
                                                                      
    #define STM32_DISCOVERY_UART_RX_GPIO                                    GPIOB
    #define STM32_DISCOVERY_UART_RX_GPIO_PIN_NO                             7
    #define STM32_DISCOVERY_UART_RX_GPIO_PIN_ADDR                           UMBA_PINADDR_PB7
    #define STM32_DISCOVERY_UART_RX_GPIO_PIN_SOURCE                         GPIO_PinSource7
    #define STM32_DISCOVERY_UART_RX_GPIO_PIN_DIRECTION                      UMBA_GPIO_DIRECTION_IN

                                                                     

    // CS43L22
    // - Using I2S protocol
    // – Using DAC to analog input AIN1x of the CS43L22
    // – Using the microphone output directly via a low-pass filter to analog input AIN4x of the CS43L22
    
    // LRCK/AIN1x  PA4
    // SCL         PB6
    // SDA         PB9
    // MCLK        PC7
    // SCLK        PC10
    // SDIN        PC12
    // RESET       PD4



    // The MP45DT02 is a compact, low-power, topport, omnidirectional, digital MEMS microphone.
    // The MP45DT02 is built with a sensing element and an IC interface with stereo capability

    // CLK         PB10
    // DOUT/AIN4x  PC3



    // Motion sensor (ST-MEMS LIS302DL or LIS3DSH)
    // Two different versions of motion sensors (U5 in schematic) are available on the board depending on the PCB version.
    // The LIS302DL and LIS3DSH are both ultra-compact low-power three-axis linear accelerometers.

    // The motion sensor includes a sensing element and an IC interface able to provide the measured acceleration to the external world through the I2C/SPI serial interfaces.

    #define STM32_DISCOVERY_LIS3DSH_SPI                                     SPI1
    #define STM32_DISCOVERY_LIS3DSH_SPI_SCK_GPIO                            GPIOA
    #define STM32_DISCOVERY_LIS3DSH_SPI_SCK_GPIO_PIN_NO                     5
    #define STM32_DISCOVERY_LIS3DSH_SPI_SCK_GPIO_PIN_ADDR                   UMBA_PINADDR_PA5
    #define STM32_DISCOVERY_LIS3DSH_SPI_SCK_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PA5, UMBA_GPIO_DIRECTION_OUT
    #define STM32_DISCOVERY_LIS3DSH_SPI_SCK_GPIO_PIN_SOURCE                 GPIO_PinSource5
    #define STM32_DISCOVERY_LIS3DSH_SPI_SCK_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_OUT
    
    #define STM32_DISCOVERY_LIS3DSH_SPI_MOSI_GPIO                           GPIOA
    #define STM32_DISCOVERY_LIS3DSH_SPI_MOSI_GPIO_PIN_NO                    7
    #define STM32_DISCOVERY_LIS3DSH_SPI_MOSI_GPIO_PIN_ADDR                  UMBA_PINADDR_PA7
    #define STM32_DISCOVERY_LIS3DSH_SPI_MOSI_GPIO_PIN_ADDR_DIR              UMBA_PINADDR_PA7, UMBA_GPIO_DIRECTION_OUT
    #define STM32_DISCOVERY_LIS3DSH_SPI_MOSI_GPIO_PIN_SOURCE                GPIO_PinSource7
    #define STM32_DISCOVERY_LIS3DSH_SPI_MOSI_GPIO_PIN_DIRECTION             UMBA_GPIO_DIRECTION_OUT
    
    #define STM32_DISCOVERY_LIS3DSH_SPI_MISO_GPIO                           GPIOA
    #define STM32_DISCOVERY_LIS3DSH_SPI_MISO_GPIO_PIN_NO                    6
    #define STM32_DISCOVERY_LIS3DSH_SPI_MISO_GPIO_PIN_ADDR                  UMBA_PINADDR_PA6
    #define STM32_DISCOVERY_LIS3DSH_SPI_MISO_GPIO_PIN_ADDR_DIR              UMBA_PINADDR_PA6, UMBA_GPIO_DIRECTION_IN
    #define STM32_DISCOVERY_LIS3DSH_SPI_MISO_GPIO_PIN_SOURCE                GPIO_PinSource6
    #define STM32_DISCOVERY_LIS3DSH_SPI_MISO_GPIO_PIN_DIRECTION             UMBA_GPIO_DIRECTION_IN
    
    #define STM32_DISCOVERY_LIS3DSH_INT1_GPIO                               GPIOE
    #define STM32_DISCOVERY_LIS3DSH_INT1_GPIO_PIN_NO                        0
    #define STM32_DISCOVERY_LIS3DSH_INT1_GPIO_PIN_ADDR                      UMBA_PINADDR_PE0
    #define STM32_DISCOVERY_LIS3DSH_INT1_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PE0, UMBA_GPIO_DIRECTION_IN
    #define STM32_DISCOVERY_LIS3DSH_INT1_GPIO_PIN_SOURCE                    GPIO_PinSource0
    #define STM32_DISCOVERY_LIS3DSH_INT1_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_IN
    
    #define STM32_DISCOVERY_LIS3DSH_INT2_GPIO                               GPIOE
    #define STM32_DISCOVERY_LIS3DSH_INT2_GPIO_PIN_NO                        1
    #define STM32_DISCOVERY_LIS3DSH_INT2_GPIO_PIN_ADDR                      UMBA_PINADDR_PE1
    #define STM32_DISCOVERY_LIS3DSH_INT2_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PE1, UMBA_GPIO_DIRECTION_IN
    #define STM32_DISCOVERY_LIS3DSH_INT2_GPIO_PIN_SOURCE                    GPIO_PinSource1
    #define STM32_DISCOVERY_LIS3DSH_INT2_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_IN
    
    #define STM32_DISCOVERY_LIS3DSH_CS_GPIO                                 GPIOE
    #define STM32_DISCOVERY_LIS3DSH_CS_GPIO_PIN_NO                          3
    #define STM32_DISCOVERY_LIS3DSH_CS_GPIO_PIN_ADDR                        UMBA_PINADDR_PE3
    #define STM32_DISCOVERY_LIS3DSH_CS_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PE3, UMBA_GPIO_DIRECTION_IN
    #define STM32_DISCOVERY_LIS3DSH_CS_GPIO_PIN_SOURCE                      GPIO_PinSource3
    #define STM32_DISCOVERY_LIS3DSH_CS_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_IN



#endif




