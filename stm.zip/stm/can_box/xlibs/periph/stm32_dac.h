#pragma once

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif

#include "stm32_pinaddrs.h"


namespace umba
{
namespace periph
{
namespace traits
{


#if 0

// http://easystm32.ru/for-beginners/37-dac-stm32/


// F1

typedef struct
{
  uint32_t DAC_Trigger;                      /*!< Specifies the external trigger for the selected DAC channel.
                                                  This parameter can be a value of @ref DAC_trigger_selection */

  uint32_t DAC_WaveGeneration;               /*!< Specifies whether DAC channel noise waves or triangle waves
                                                  are generated, or whether no wave is generated.
                                                  This parameter can be a value of @ref DAC_wave_generation */

  uint32_t DAC_LFSRUnmask_TriangleAmplitude; /*!< Specifies the LFSR mask for noise wave generation or
                                                  the maximum amplitude triangle generation for the DAC channel. 
                                                  This parameter can be a value of @ref DAC_lfsrunmask_triangleamplitude */

  uint32_t DAC_OutputBuffer;                 /*!< Specifies whether the DAC channel output buffer is enabled or disabled.
                                                  This parameter can be a value of @ref DAC_output_buffer */
}DAC_InitTypeDef;




// F3
typedef struct
{
  uint32_t DAC_Trigger;                      /*!< Specifies the external trigger for the selected DAC channel.
                                                  This parameter can be a value of @ref DAC_trigger_selection */

  uint32_t DAC_WaveGeneration;               /*!< Specifies whether DAC channel noise waves or triangle waves
                                                  are generated, or whether no wave is generated.
                                                  This parameter can be a value of @ref DAC_wave_generation */

  uint32_t DAC_LFSRUnmask_TriangleAmplitude; /*!< Specifies the LFSR mask for noise wave generation or
                                                  the maximum amplitude triangle generation for the DAC channel. 
                                                  This parameter can be a value of @ref DAC_lfsrunmask_triangleamplitude */

  uint32_t DAC_Buffer_Switch;                /*!< Specifies whether the DAC channel output buffer is enabled or disabled or 
                                                  the DAC channel output switch is enabled or disabled.
                                                  This parameter can be a value of @ref DAC_buffer_switch */
}DAC_InitTypeDef;



// F4

typedef struct
{
  uint32_t DAC_Trigger;                      /*!< Specifies the external trigger for the selected DAC channel.
                                                  This parameter can be a value of @ref DAC_trigger_selection */

  uint32_t DAC_WaveGeneration;               /*!< Specifies whether DAC channel noise waves or triangle waves
                                                  are generated, or whether no wave is generated.
                                                  This parameter can be a value of @ref DAC_wave_generation */

  uint32_t DAC_LFSRUnmask_TriangleAmplitude; /*!< Specifies the LFSR mask for noise wave generation or
                                                  the maximum amplitude triangle generation for the DAC channel. 
                                                  This parameter can be a value of @ref DAC_lfsrunmask_triangleamplitude */

  uint32_t DAC_OutputBuffer;                 /*!< Specifies whether the DAC channel output buffer is enabled or disabled.
                                                  This parameter can be a value of @ref DAC_output_buffer */
}DAC_InitTypeDef;


void DAC_Init(DAC_TypeDef* DACx, uint32_t DAC_Channel, DAC_InitTypeDef* DAC_InitStruct);
void DAC_StructInit(DAC_InitTypeDef* DAC_InitStruct);
void DAC_Cmd(DAC_TypeDef* DACx, uint32_t DAC_Channel, FunctionalState NewState);
void DAC_SoftwareTriggerCmd(DAC_TypeDef* DACx, uint32_t DAC_Channel, FunctionalState NewState);
void DAC_DualSoftwareTriggerCmd(DAC_TypeDef* DACx, FunctionalState NewState);
void DAC_WaveGenerationCmd(DAC_TypeDef* DACx, uint32_t DAC_Channel, uint32_t DAC_Wave, FunctionalState NewState);
void DAC_SetChannel1Data(DAC_TypeDef* DACx, uint32_t DAC_Align, uint16_t Data);
void DAC_SetChannel2Data(DAC_TypeDef* DACx, uint32_t DAC_Align, uint16_t Data);


#endif


#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
    template <>
    inline
    ClockBus periphClockGetBus<DAC_TypeDef>( DAC_TypeDef * pt )
    {
        return ClockBus::APB1;
    }
#endif


#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)


    template <>
    inline
    PerifClockFunctionPtr periphClockGetFunction<DAC_TypeDef>( DAC_TypeDef * pt )
    {
        return RCC_APB1PeriphClockCmd;
    }

    template <>
    inline
    uint32_t periphClockGetFlag<DAC_TypeDef>( DAC_TypeDef * pt )
    {
        #ifdef DAC
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( DAC, RCC_APB1Periph_DAC );
        #endif
        #ifdef DAC1
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( DAC1, RCC_APB1Periph_DAC1 );
        #endif
        #ifdef DAC2
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( DAC2, RCC_APB1Periph_DAC2 );
        #endif

        UMBA_ASSERT_FAIL();

        return 0;
    }

#endif


enum class DacBits
{
    bits_8  = 8,
    bits_12 = 12
};

enum DacChannel
{
    channel_1 = 1,
    channel_2 = 2,
};


class DacSimple
{

public:

    DacSimple()                               = delete;
    DacSimple( const DacSimple &)             = delete;
    DacSimple( DacSimple &&)                  = default;

    DacSimple( unsigned channel, DacBits dacBits = DacBits::bits_8)
      : m_pinAddr( channel==1 ? GpioPinAddr( UMBA_PINADDR_PA4 ) : GpioPinAddr( UMBA_PINADDR_PA5 ) )
      , m_channel(channel)
      , m_dacBitsMode(dacBits)
      , m_val(0)
      , m_connected(false)
    {
        UMBA_ASSERT( m_channel == 1 || m_channel == 2 );
        UMBA_ASSERT( m_dacBitsMode == DacBits::bits_8 || m_dacBitsMode == DacBits::bits_12 );
    }

    DacSimple( DacChannel channel, DacBits dacBits = DacBits::bits_8)
      : m_pinAddr( channel==DacChannel::channel_1 ? GpioPinAddr( UMBA_PINADDR_PA4 ) : GpioPinAddr( UMBA_PINADDR_PA5 ) )
      , m_channel(channel)
      , m_dacBitsMode(dacBits)
      , m_val(0)
      , m_connected(false)
    {
        UMBA_ASSERT( m_channel == DacChannel::channel_1 || m_channel == DacChannel::channel_1 );
        UMBA_ASSERT( m_dacBitsMode == DacBits::bits_8 || m_dacBitsMode == DacBits::bits_12 );
    }

    // channel==dacChannel1 ? GpioPinAddr( UMBA_PINADDR_PA4 ) : GpioPinAddr( UMBA_PINADDR_PA5 )
    DacSimple( const GpioPinAddr &pinAddr, DacBits dacBits = DacBits::bits_8)
      : m_pinAddr( pinAddr )
      , m_channel( pinAddr == UMBA_PINADDR_PA4 )
      , m_dacBitsMode(dacBits)
      , m_val(0)
      , m_connected(false)
    {
        UMBA_ASSERT( m_pinAddr == UMBA_PINADDR_PA4 || m_pinAddr == UMBA_PINADDR_PA5 );
        UMBA_ASSERT( m_dacBitsMode == DacBits::bits_8 || m_dacBitsMode == DacBits::bits_12 );
    }

    GpioPinAddr getPinAddr()
    {
        return m_channel==DacChannel::channel_1 ? GpioPinAddr( UMBA_PINADDR_PA4 ) : GpioPinAddr( UMBA_PINADDR_PA5 );
    }

    // Result of this function can be casted to unsigned
    DacBits getNumberOfBits() const
    {
        return m_dacBitsMode;
    }

    void connect()
    {
        UMBA_ASSERT( m_connected == false );

        initPeriphClock( m_pinAddr.port, ENABLE );

        initPeriphClock( DAC, ENABLE );
        incRefCounter();

        // http://homepage.cem.itesm.mx/carbajal/Microcontrollers/SLIDES/STM32F3%20DAC.pdf
        gpioInit( m_pinAddr.port, PinSpeed::high, PinMode::analog_in, 1<<m_pinAddr.pinNo );
        //gpioInit( m_pinAddr.port, PinSpeed::high, PinMode::gpio_in_floating, 1<<m_pinAddr.pinNo );
 
        DAC_InitTypeDef dacInitStructure;

        #if defined(STM32F1_SERIES) || defined(STM32F4_SERIES)
            dacInitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Enable;
        #elif defined(STM32F3_SERIES)
            dacInitStructure.DAC_Buffer_Switch = DAC_BufferSwitch_Enable;
        #else
            #error "Family not supported yet"
        #endif
        dacInitStructure.DAC_Trigger = DAC_Trigger_None;
        dacInitStructure.DAC_WaveGeneration = DAC_WaveGeneration_None;
        dacInitStructure.DAC_LFSRUnmask_TriangleAmplitude = DAC_LFSRUnmask_Bit0;
 
        #if defined(STM32F1_SERIES) || defined(STM32F4_SERIES)
        DAC_Init( m_channel == 1 ? DAC_Channel_1 : DAC_Channel_2, &dacInitStructure ); 
        DAC_Cmd ( m_channel == 1 ? DAC_Channel_1 : DAC_Channel_2, ENABLE );
        #elif defined(STM32F3_SERIES)
        DAC_Init( DAC, m_channel == 1 ? DAC_Channel_1 : DAC_Channel_2, &dacInitStructure ); 
        DAC_Cmd ( DAC, m_channel == 1 ? DAC_Channel_1 : DAC_Channel_2, ENABLE );
        #endif

        m_connected = true;
    }

    void shutdown()
    {
        UMBA_ASSERT( m_connected != false );

        #if defined(STM32F1_SERIES) || defined(STM32F4_SERIES)
        DAC_Cmd ( m_channel == 1 ? DAC_Channel_1 : DAC_Channel_2, DISABLE );
        #elif defined(STM32F3_SERIES)
        DAC_Cmd ( DAC, m_channel == 1 ? DAC_Channel_1 : DAC_Channel_2, DISABLE );
        #endif

        if (decRefCounter()==0)
        {
            #if defined(STM32F1_SERIES) || defined(STM32F4_SERIES)
            DAC_DeInit( ); 
            #elif defined(STM32F3_SERIES)
            DAC_DeInit( DAC );
            #endif

            initPeriphClock( DAC, DISABLE );
        }

        m_connected = false;
    }

    bool isConnected() const
    {
        return m_connected;
    }

    DacSimple& operator=( const DacSimple &)  = delete;

    void operator=( unsigned val )
    {
        write( val );
    }

    void write( unsigned val )
    {
        m_val = val;
        if (m_dacBitsMode == DacBits::bits_8)
            m_val &=  0xFF;
        else
            m_val &= 0xFFF;

        #ifdef STM32F3_SERIES
        if (m_channel == 1)
            DAC_SetChannel1Data( DAC, m_dacBitsMode == DacBits::bits_8 ? DAC_Align_8b_R : DAC_Align_12b_R, m_val );
        else
            DAC_SetChannel2Data( DAC, m_dacBitsMode == DacBits::bits_8 ? DAC_Align_8b_R : DAC_Align_12b_R, m_val );
        #else
        if (m_channel == 1)
            DAC_SetChannel1Data( m_dacBitsMode == DacBits::bits_8 ? DAC_Align_8b_R : DAC_Align_12b_R, m_val );
        else
            DAC_SetChannel2Data( m_dacBitsMode == DacBits::bits_8 ? DAC_Align_8b_R : DAC_Align_12b_R, m_val );
        #endif
    }

protected:


    unsigned& getRefCounter()
    {
        static unsigned clockUsageCount = 0;
        return clockUsageCount;
    }

    unsigned incRefCounter()
    {
        unsigned &cnt = getRefCounter();
        ++cnt;
        return cnt;
    }

    unsigned decRefCounter()
    {
        unsigned &cnt = getRefCounter();
        ++cnt;
        return cnt;
    }

    GpioPinAddr         m_pinAddr;
    unsigned            m_channel;
    DacBits             m_dacBitsMode;
    unsigned            m_val;
    bool                m_connected;


}; // class DacSimple


// void initPeriphClock( T * pt, FunctionalState newState, uint32_t extraFlags = 0 ) // FunctionalState newState DISABLE/ENABLE (from SPL directly)
// void DAC_Init(uint32_t DAC_Channel, DAC_InitTypeDef* DAC_InitStruct)



} // namespace traits
} // namespace periph
} // namespace umba


