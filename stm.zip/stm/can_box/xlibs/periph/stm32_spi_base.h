#pragma once

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif


namespace umba
{
namespace periph
{
namespace traits
{

enum class PinFunctionSpi
{
    sclk, 
    clk  = sclk,
    spc  = sclk,
    sck  = sclk,
    mosi,
    miso,
    nss
};

enum class BitsDirection // basically for SPI
{
    msb, lsb // first bit is
};

enum class SpiMode
{
    mode00, // CPOL = 0, CPHA = 0 // normal polarity for both
    mode01, // CPOL = 0, CPHA = 1
    mode10, // CPOL = 1, CPHA = 0
    mode11, // CPOL = 1, CPHA = 1 // inverse polarity for both

    // https://ideone.com/eVWRl3
    
    nCPOL_nCPHA = mode00,
    nCPOL_CPHA  = mode01,
    CPOL_nCPHA  = mode10,
    CPOL_CPHA   = mode11,

    CPOL0_CPHA0 = nCPOL_nCPHA,
    CPOL0_CPHA1 = nCPOL_CPHA ,
    CPOL1_CPHA0 = CPOL_nCPHA ,
    CPOL1_CPHA1 = CPOL_CPHA  ,

    mode0 = mode00,
    mode1 = mode01,
    mode2 = mode10,
    mode3 = mode11
};




} // namespace traits
} // namespace periph
} // namespace umba

