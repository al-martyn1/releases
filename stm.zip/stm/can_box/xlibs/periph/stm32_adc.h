#pragma once

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif

#include "mcu.h"
#include "stm32_dma.h"

//#include "stm32f1xx/inc/stm32f10x.h"

// https://embedds.com/introducing-to-stm32-adc-programming-part1/
// https://ralimtek.com/stm32_double_pwm/


// http://www.avislab.com/blog/stm32-adc_ru/

namespace umba
{
namespace periph
{
namespace traits
{


class AdcInjectedChannel;

#if defined(UMBA_SIMPLE_FORMATTER_H)
    umba::SimpleFormatter& operator<<( umba::SimpleFormatter &fmt, const AdcInjectedChannel &pin );
#endif


//----------------
class AdcInjected;

class AdcInjectedChannel
{

public:

    friend class AdcInjected;
    #if defined(UMBA_SIMPLE_FORMATTER_H)
        friend
        umba::SimpleFormatter& operator<<( umba::SimpleFormatter &fmt, const AdcInjectedChannel &pin );
    #endif


    AdcInjectedChannel() = delete;

    operator unsigned () const
    {
        
        #if defined(STM32F1_SERIES)
            return ADC_GetInjectedConversionValue( m_ADCx, 0x10 + ((m_injectNo+1)<<2) );
        #elif defined(STM32F3_SERIES)
            return ADC_GetInjectedConversionValue( m_ADCx, m_injectNo );
        //UNDONE:!!!
        #elif defined(STM32F4_SERIES)
        //UNDONE:!!!
        return 0;
        #endif
    }

//protected:

    AdcInjectedChannel( ADC_TypeDef* ADCx, unsigned injectNo )
      : m_ADCx(ADCx)
      , m_injectNo(injectNo)
      {
      }

    AdcInjectedChannel( const AdcInjectedChannel &adcCh )
      : m_ADCx(adcCh.m_ADCx)
      , m_injectNo(adcCh.m_injectNo)
      {
      }

    ADC_TypeDef*   m_ADCx;
    unsigned       m_injectNo;
}; // class AdcInjectedChannel


//----------------
class AdcInjected
{

public:

    AdcInjected() = delete;

    AdcInjected( ADC_TypeDef* ADCx
               , unsigned numChannels
               #if defined(STM32F3_SERIES)
               //, int *pChannels = 0
               #endif
               )
      : m_ADCx(ADCx)
      , m_numInjectedChannels(numChannels)
    {
        /*
        #if defined(STM32F3_SERIES)
        UMBA_ASSERT(pChannels!=0);
        for(unsigned i = 0; i!=m_numInjectedChannels; ++i)
        {
            m_channels[i] = pChannels[i];
        }
        #endif
        */
    }

    AdcInjected( const AdcInjected &aj )
      : m_ADCx(aj.m_ADCx)
      , m_numInjectedChannels(aj.m_numInjectedChannels)
    {
        /*
        #if defined(STM32F3_SERIES)
        for(unsigned i = 0; i!=m_numInjectedChannels; ++i)
        {
            m_channels[i] = aj.m_channels[i];
        }
        #endif
        */
    }

    AdcInjectedChannel operator[](unsigned n)
    {
        //UMBA_ASSERT( n!=0 );
        UMBA_ASSERT( n < m_numInjectedChannels);
        #if defined(STM32F3_SERIES)        
        return AdcInjectedChannel(m_ADCx,n+1);
        #else
        return AdcInjectedChannel(m_ADCx,n);
        #endif
    }

    void connect()
    {
    }

    void shutdown()
    {
    }

    bool isConnected() const
    {
        return true;
    }

protected:

    ADC_TypeDef*   m_ADCx;
    unsigned       m_numInjectedChannels;

    #if defined(STM32F3_SERIES)
    //    int        m_channels[4];
    #endif

}; // class AdcInjected



#if defined(UMBA_SIMPLE_FORMATTER_H)

    inline
    umba::SimpleFormatter& operator<<( umba::SimpleFormatter &fmt, const AdcInjectedChannel &pin )
    {
        fmt << unsigned(pin);
        return fmt;
    }

#endif




#define UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( pa, chan )  if ( pinAddr == GpioPinAddr(pa) ) return chan


#if defined(STM32F1_SERIES) || defined(STM32F4_SERIES)
    template <>
    inline
    ClockBus periphClockGetBus<ADC_TypeDef>( ADC_TypeDef * pt )
    {
        return ClockBus::APB2;
    }
#elif defined(STM32F3_SERIES)
    template <>
    inline
    ClockBus periphClockGetBus<ADC_TypeDef>( ADC_TypeDef * pt )
    {
        return ClockBus::AHB;
    }
#endif


//-----------------------
// Clocks & AF mnapping
//-----------------------

#if defined(STM32F1_SERIES) || defined(STM32F4_SERIES)


    template <>
    inline
    PerifClockFunctionPtr periphClockGetFunction<ADC_TypeDef>( ADC_TypeDef * pt )
    {
        return RCC_APB2PeriphClockCmd;
    }

    template <>
    inline
    uint32_t periphClockGetFlag<ADC_TypeDef>( ADC_TypeDef * pt )
    {
        #ifdef ADC1
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( ADC1, RCC_APB2Periph_ADC1 );
        #endif
        #ifdef ADC2
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( ADC2, RCC_APB2Periph_ADC2 );
        #endif
        #ifdef ADC3
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( ADC3, RCC_APB2Periph_ADC3 );
        #endif

        UMBA_ASSERT_FAIL();

        return 0;
    }


#elif defined(STM32F3_SERIES)


    template <>
    inline
    PerifClockFunctionPtr periphClockGetFunction<ADC_TypeDef>( ADC_TypeDef * pt )
    {
        return RCC_AHBPeriphClockCmd;
    }

    template <>
    inline
    uint32_t periphClockGetFlag<ADC_TypeDef>( ADC_TypeDef * pt )
    {
        #ifdef ADC1
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( ADC1, RCC_AHBPeriph_ADC12 );
        #endif
        #ifdef ADC2
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( ADC2, RCC_AHBPeriph_ADC12 );
        #endif
        #ifdef ADC3
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( ADC3, RCC_AHBPeriph_ADC34 );
        #endif
        #ifdef ADC4
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( ADC4, RCC_AHBPeriph_ADC34 );
        #endif

        UMBA_ASSERT_FAIL();

        return 0;
    }

#endif


#if defined(STM32F1_SERIES)

    inline
    unsigned getPinAddrAdcChannelNo( ADC_TypeDef* ADCx, const GpioPinAddr &pinAddr )
    {
        #ifdef ADC1
        if (ADCx==ADC1)
        {
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA0,  0 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA1,  1 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA2,  2 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA3,  3 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA4,  4 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA5,  5 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA6,  6 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA7,  7 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB0,  8 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB1,  9 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC0, 10 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC1, 11 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC2, 12 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC3, 13 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC4, 14 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC5, 15 );
        }
        #endif

        #ifdef ADC2
        if (ADCx==ADC2)
        {
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA0,  0 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA1,  1 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA2,  2 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA3,  3 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA4,  4 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA5,  5 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA6,  6 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA7,  7 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB0,  8 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB1,  9 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC0, 10 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC1, 11 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC2, 12 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC3, 13 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC4, 14 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC5, 15 );
        }
        #endif

        UMBA_ASSERT_FAIL();
        return 0;
    }

    inline
    bool adcCalibrate( ADC_TypeDef* ADCx )
    {
        #if defined(STM32F1_SERIES)
            //  ADC calibration (optional, but recommended at power on)
            ADC_ResetCalibration(ADCx); // Reset previous calibration
            while(ADC_GetResetCalibrationStatus(ADCx)) {}
            ADC_StartCalibration(ADCx); // Start new calibration (ADC must be off at that time)
            while(ADC_GetCalibrationStatus(ADCx));

            // ADC_Cmd (ADC1,ENABLE);  // enable ADC1 only after calibration?
        #endif

        return true; // On F4 ADCs are auto-calibrated
    }

    inline
    void adcCommonInitSimple( ADC_TypeDef* ADCx )
    {
        //ADC_CommonInitTypeDef commonInitTypeDef;
        //commonInitTypeDef.ADC_Prescaler = ADC_Prescaler_Div1;
        //ADC_CommonInit( ADCx, &commonInitTypeDef );    
    }



#elif defined(STM32F3_SERIES)

    inline
    unsigned getPinAddrAdcChannelNo( ADC_TypeDef* ADCx, const GpioPinAddr &pinAddr )
    {
        #if defined(STM32F303x8) // STM32F303C6/STM32F303C8/STM32F303K6/STM32F303K8/STM32F303R6/STM32F303R8/
        // https://www.st.com/resource/en/datasheet/stm32f303k8.pdf

            #ifdef ADC1
            if (ADCx==ADC1)
            {
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA0 ,  1 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA1 ,  2 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA2 ,  3 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA3 ,  4 );

                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB0 , 11 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB1 , 12 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB13, 13 );

                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC0 ,  6 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC1 ,  7 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC2 ,  8 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC3 ,  9 );
        
            }
            #endif
        
            #ifdef ADC2
            if (ADCx==ADC2)
            {
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA4 ,  1 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA5 ,  2 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA6 ,  3 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA7 ,  4 );

                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB2 , 12 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB12, 13 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB14, 14 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB15, 15 );

                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC0 ,  6 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC1 ,  7 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC2 ,  8 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC3 ,  9 );

                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC4 ,  5 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC5 , 11 );

            }
            #endif
        

        #elif defined(STM32F303xC) || defined(STM32F303xE)

            #ifdef ADC1
            if (ADCx==ADC1)
            {
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA0,  1 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA1,  2 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA2,  3 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA3,  4 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PF4,  5 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC0,  6 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC1,  7 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC2,  8 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC3,  9 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PF2, 10 );
        
            }
            #endif
        
            #ifdef ADC2
            if (ADCx==ADC2)
            {
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA4,  1 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA5,  2 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA6,  3 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA7,  4 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC4,  5 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC0,  6 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC1,  7 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC2,  8 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC3,  9 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PF2, 10 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC5, 11 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB2, 12 );
            }
            #endif
        
            #ifdef ADC3
            if (ADCx==ADC3)
            {
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB1 ,  1 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PE9 ,  2 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PE13,  3 );
        
                // No ch 4
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB13,  5 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PE8 ,  6 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PD10,  7 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PD11,  8 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PD12,  9 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PD13, 10 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PD14, 11 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB0 , 12 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PE7 , 13 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PE10, 14 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PE11, 15 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PE12, 16 );
            }
            #endif
        
            #ifdef ADC4
            if (ADCx==ADC4)
            {
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PE14,  1 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PE15,  2 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB12,  3 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB14,  4 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB15,  5 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PE8 ,  6 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PD10,  7 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PD11,  8 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PD12,  9 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PD13, 10 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PD14, 11 );
        
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PD8 , 12 );
                UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PD9 , 13 );
        
            }
            #endif

        #endif // STM32F303x8 vs STM32F303xC || STM32F303xE


        UMBA_ASSERT_FAIL();
        return 0;
    }

    inline
    void adcCommonInitSimple( ADC_TypeDef* ADCx )
    {
    
        ADC_CommonInitTypeDef commonInitStructure;
        commonInitStructure.ADC_Mode = ADC_Mode_Independent;
        commonInitStructure.ADC_Clock = ADC_Clock_SynClkModeDiv1;
        commonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
        commonInitStructure.ADC_DMAMode = ADC_DMAMode_Circular;
        commonInitStructure.ADC_TwoSamplingDelay = 0x0;//минимум, здесь дефайнов нет(
        ADC_CommonInit( ADCx, &commonInitStructure );
    
    }

    // https://microtechnics.ru/stm32f3-rabota-s-adc-i-dma/
    inline
    bool adcCalibrate( ADC_TypeDef* ADCx )
    {
        //ADC_ResetCalibration(ADCx); //???
        ADC_VoltageRegulatorCmd( ADCx, ENABLE );
        ADC_StartCalibration( ADCx );
        while( ADC_GetCalibrationStatus( ADCx ) != RESET ) {}
        return true;
    }


#elif defined(STM32F4_SERIES)

    inline
    unsigned getPinAddrAdcChannelNo( ADC_TypeDef* ADCx, const GpioPinAddr &pinAddr )
    {
        #ifdef ADC1
        if (ADCx==ADC1)
        {
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA0 ,  0 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA1 ,  1 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA2 ,  2 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA3 ,  3 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA4 ,  4 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA5 ,  5 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA6 ,  6 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA7 ,  7 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB0 ,  8 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB1 ,  9 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC0 , 10 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC1 , 11 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC2 , 12 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC3 , 13 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC4 , 14 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC5 , 15 );
        }
        #endif

        #ifdef ADC2
        if (ADCx==ADC2)
        {
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA0 ,  0 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA1 ,  1 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA2 ,  2 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA3 ,  3 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA4 ,  4 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA5 ,  5 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA6 ,  6 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA7 ,  7 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB0 ,  8 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PB1 ,  9 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC0 , 10 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC1 , 11 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC2 , 12 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC3 , 13 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC4 , 14 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC5 , 15 );
        }
        #endif

        #ifdef ADC3
        if (ADCx==ADC3)
        {
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA0 ,  0 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA1 ,  1 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA2 ,  2 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PA3 ,  3 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PF6 ,  4 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PF7 ,  5 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PF8 ,  6 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PF9 ,  7 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PF10,  8 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PF3 ,  9 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC0 , 10 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC1 , 11 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC2 , 12 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PC3 , 13 );

            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PF4 , 14 );
            UMBA_PERIPH_STM32_TRAITS_PINADDR_CHECK_ADC_CHANNEL( UMBA_PINADDR_PF5 , 15 );


        }
        #endif

        UMBA_ASSERT_FAIL();
        return 0;
    }

    inline
    void adcCommonInitSimple( ADC_TypeDef* ADCx )
    {
        ADC_CommonInitTypeDef commonInitStruct;
        commonInitStruct.ADC_Mode = ADC_Mode_Independent;
        commonInitStruct.ADC_Prescaler = ADC_Prescaler_Div2;                            // максимальная скорость
        //commonInitStruct.ADC_DMAAccessMode = ADC_DMAAccessMode_1;
        commonInitStruct.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
        commonInitStruct.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;           // минимальная задержка
        ADC_CommonInit( &commonInitStruct );
    }

    inline
    bool adcCalibrate( ADC_TypeDef* ADCx )
    {
        return true; // On F4 ADCs are auto-calibrated
    }


#endif

// https://www.compel.ru/lib/ne/2011/2/7-atsp-v-mikrokontrollerah-stm32-periferiya-reshaet-mnogoe
// http://www.avislab.com/blog/stm32-adc_ru/
// http://mycontroller.ru/old_site/stm32-adc-primeryi-ispolzovaniya-inzhektirovannyie-kanalyi/default.htm
// http://www.avislab.com/blog/stm32-list_ru/
// ? https://sites.google.com/site/cybnod/home/primerinicializaciiacpustm32stm32adcinitializationexample
// doxy - http://www.disca.upv.es/aperles/arm_cortex_m3/curset/STM32F4xx_DSP_StdPeriph_Lib_V1.0.1/html/group___a_d_c___group6.html


enum class AdcSamplingSpeed
{
    very_low, low, medium, fast, high,
    very_high // too noisy
};

/*
// F1
#define ADC_SampleTime_1Cycles5                    ((uint8_t)0x00)   // very_high
#define ADC_SampleTime_7Cycles5                    ((uint8_t)0x01)   // high
#define ADC_SampleTime_13Cycles5                   ((uint8_t)0x02)   // fast
#define ADC_SampleTime_28Cycles5                   ((uint8_t)0x03)   
#define ADC_SampleTime_41Cycles5                   ((uint8_t)0x04)   // medium
#define ADC_SampleTime_55Cycles5                   ((uint8_t)0x05)   
#define ADC_SampleTime_71Cycles5                   ((uint8_t)0x06)   // low
#define ADC_SampleTime_239Cycles5                  ((uint8_t)0x07)   // very_low

// F3
#define ADC_SampleTime_1Cycles5                    ((uint8_t)0x00)   // very_high
#define ADC_SampleTime_2Cycles5                    ((uint8_t)0x01)   
#define ADC_SampleTime_4Cycles5                    ((uint8_t)0x02)   
#define ADC_SampleTime_7Cycles5                    ((uint8_t)0x03)   // high
#define ADC_SampleTime_19Cycles5                   ((uint8_t)0x04)   // fast
#define ADC_SampleTime_61Cycles5                   ((uint8_t)0x05)   // medium
#define ADC_SampleTime_181Cycles5                  ((uint8_t)0x06)   // low
#define ADC_SampleTime_601Cycles5                  ((uint8_t)0x07)   // very_low

// F4
#define ADC_SampleTime_3Cycles                    ((uint8_t)0x00)    // very_high
#define ADC_SampleTime_15Cycles                   ((uint8_t)0x01)    // high
#define ADC_SampleTime_28Cycles                   ((uint8_t)0x02)    // fast
#define ADC_SampleTime_56Cycles                   ((uint8_t)0x03)
#define ADC_SampleTime_84Cycles                   ((uint8_t)0x04)    // medium
#define ADC_SampleTime_112Cycles                  ((uint8_t)0x05)
#define ADC_SampleTime_144Cycles                  ((uint8_t)0x06)    // low
#define ADC_SampleTime_480Cycles                  ((uint8_t)0x07)    // very_low
*/

inline
unsigned adcSamplingSpeedConvertToRaw( AdcSamplingSpeed chsp )
{
    switch(chsp)
    {
        case AdcSamplingSpeed::very_high:
             #if defined(STM32F1_SERIES)
                 return ADC_SampleTime_1Cycles5;
             #elif defined(STM32F3_SERIES)
                 return ADC_SampleTime_1Cycles5;
             #elif defined(STM32F4_SERIES)
                 return ADC_SampleTime_3Cycles;
             #else
                 break;
             #endif

        case AdcSamplingSpeed::high:
             #if defined(STM32F1_SERIES)
                 return ADC_SampleTime_7Cycles5;
             #elif defined(STM32F3_SERIES)
                 return ADC_SampleTime_7Cycles5;
             #elif defined(STM32F4_SERIES)
                 return ADC_SampleTime_15Cycles;
             #else
                 break;
             #endif

        case AdcSamplingSpeed::fast:
             #if defined(STM32F1_SERIES)
                 return ADC_SampleTime_13Cycles5;
             #elif defined(STM32F3_SERIES)
                 return ADC_SampleTime_19Cycles5;
             #elif defined(STM32F4_SERIES)
                 return ADC_SampleTime_28Cycles;
             #else
                 break;
             #endif

        case AdcSamplingSpeed::medium:
             #if defined(STM32F1_SERIES)
                 return ADC_SampleTime_41Cycles5;
             #elif defined(STM32F3_SERIES)
                 return ADC_SampleTime_61Cycles5;
             #elif defined(STM32F4_SERIES)
                 return ADC_SampleTime_84Cycles;
             #else
                 break;
             #endif

        case AdcSamplingSpeed::low: 
             #if defined(STM32F1_SERIES)
                 return ADC_SampleTime_71Cycles5;
             #elif defined(STM32F3_SERIES)
                 return ADC_SampleTime_181Cycles5;
             #elif defined(STM32F4_SERIES)
                 return ADC_SampleTime_144Cycles;
             #else
                 break;
             #endif

        case AdcSamplingSpeed::very_low: 
             #if defined(STM32F1_SERIES)
                 return ADC_SampleTime_239Cycles5;
             #elif defined(STM32F3_SERIES)
                 return ADC_SampleTime_601Cycles5;
             #elif defined(STM32F4_SERIES)
                 return ADC_SampleTime_480Cycles;
             #else
                 break;
             #endif

        default:
             UMBA_ASSERT_FAIL(); // Invalid sampling speed value
    };

    UMBA_ASSERT_FAIL(); // Invalid sampling speed value

    #if defined(STM32F1_SERIES)
        return ADC_SampleTime_239Cycles5;
    #elif defined(STM32F3_SERIES)
        return ADC_SampleTime_601Cycles5;
    #elif defined(STM32F4_SERIES)
        return ADC_SampleTime_480Cycles;
    #endif

}


#define UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dmaCtrlCh ) \
             if ( ctrlCh==DmaControllerChannel :: dmaCtrlCh ) return true

#define UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA_EX( dmaCtrlCh, hwChan ) \
             if ( ctrlCh==DmaControllerChannel :: dmaCtrlCh )         \
                 do                                                   \
                 {                                                    \
                     if (pHwChannelRes)                               \
                        *pHwChannelRes = hwChan;                      \
                     return true;                                     \
                 } while(0)
                 


template<>
inline
bool periphDmaTestCompatible<ADC_TypeDef>( ADC_TypeDef *pp, DmaControllerChannel ctrlCh, uint32_t *pHwChannelRes )
{
    if (pHwChannelRes)
        pHwChannelRes = 0;

    #if defined(STM32F1_SERIES)

        #ifdef ADC1
        if (pp==ADC1)
            UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dma1_Channel1 );
        #endif

        // ADC2 has no DMA connection, it's pins complettely mapped to ADC1 pins

        #ifdef ADC3
        if (pp==ADC3)
        {
            // ADC3, SDIO and TIM8 DMA requests are available only in high-density and XL-density devices.
            #if defined(STM32F10X_XL) || defined(STM32F10X_HD) || defined(STM32F10X_HD_VL)
                #if defined(DMA2)
                    UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dma2_Channel5 );
                #endif
            #endif
        }
        #endif

    #elif defined(STM32F3_SERIES)

        /*
          1) Для 301/318 отдельный рефман, там раздел 10.3.7 DMA request mapping


          Для прочих трехсоток смотрим раздел RefMan'а - 13.4.7 DMA request mapping
             Там бардак и перепутано

          2) Эта - хз, похоже, таблицы нет
             Figure 47. STM32F302xB/C/D/E and STM32F302x6/8 DMA1 request mapping


          3) Для STM32F303x6/8 and STM32F328x8 - и фигура, и таблица
             Figure 48. STM32F303x6/8 and STM32F328x8            DMA1 request mapping
             Table 79.  STM32F303x6/8 and STM32F328x8 summary of DMA1 requests for each channel

          4) Для DMA1 только таблица
             Table 78.  STM32F303xB/C/D/E, STM32F358xC and STM32F398xE summary of DMA1 requests for each channel
             Для DMA2 - и фигура, и таблица
             Figure 49. STM32F303xB/C/D/E, STM32F358xC and STM32F398xE            DMA2 request mapping
             Table 80.  STM32F303xB/C/D/E, STM32F358xC and STM32F398xE summary of DMA2 requests for each channel

          5) STM32F334x4/x6/x8 - 11.3.7 DMA request mapping


          6) STM32F373Cx/Rx/Vx and STM32F378Cx/Rx/Vx - 10.3.2 DMA request mapping


        */

        // 1
        #if defined(STM32F301x8) || defined(STM32F318xx)

            #ifdef ADC1
            if (pp==ADC1)
                UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dma1_Channel1 );
            #endif

        // 2
        #elif  defined(STM32F302xBxC) || defined(STM32F302xDxE) || defined(STM32F302x6x8)

            #ifdef ADC1
            if (pp==ADC1)
                UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dma1_Channel1 );
            #endif
           
        //3
        #elif defined(STM32F303x6x8) || defined(STM32F328x6x8)

            #ifdef ADC1
            if (pp==ADC1)
                UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dma1_Channel1 );
            #endif
           
            #ifdef ADC2
            if (pp==ADC2)
            {
                UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dma1_Channel2 );
                // UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dma1_Channel4 ); // remap
            }
            #endif
           
        //4
        #elif defined(STM32F303xBxC) || defined(STM32F303xDxE) || defined(STM32F358xBxC) || defined(STM32F398xDxE)

            #ifdef ADC1
            if (pp==ADC1)
                UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dma1_Channel1 );
            #endif
           
            #ifdef ADC2
            if (pp==ADC2)
            {
               UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dma2_Channel1 );
               // UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dma2_Channel3 ); // remap
            }
            #endif
           
            #ifdef ADC3
            if (pp==ADC3)
               UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dma2_Channel5 );
            #endif

            #ifdef ADC4
            if (pp==ADC4)
            {
               UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dma2_Channel2 );
               // UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dma2_Channel4 ); // remap
            }
            #endif

        // 5
        #elif defined(STM32F334x6x8)

            #ifdef ADC1
            if (pp==ADC1)
                UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dma1_Channel1 );
            #endif
           
            #ifdef ADC2
            if (pp==ADC2)
            {
                UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dma1_Channel2 );
                // UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dma1_Channel4 ); // remap
            }
            #endif
           
        // 6
        #elif defined(STM32F373xC) || defined(STM32F378xx)

            #ifdef ADC1
            if (pp==ADC1)
            {
                UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA( dma1_Channel1 );
            }
            #endif

            /* DMA2
            Peripheral Channel 1 Channel 2 Channel 3 Channel 4 Channel 5
            SDADC - -                       SDADC1    SDADC2    SDADC3            
            */

        #endif


    #elif defined(STM32F4_SERIES)

        // 10.3.3 Channel selection

        #ifdef ADC1
        if (pp==ADC1)
        {
            UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA_EX( dma2_Channel0, 0 ); // hw channel 0
            UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA_EX( dma2_Channel4, 0 ); // hw channel 0
        }
        #endif

        #ifdef ADC2
        if (pp==ADC2)
        {
            UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA_EX( dma2_Channel2, 1 ); // hw channel 1
            UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA_EX( dma2_Channel3, 1 ); // hw channel 1
        }
        #endif

        #ifdef ADC3
        if (pp==ADC3)
        {
            UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA_EX( dma2_Channel0, 2 ); // hw channel 2
            UMBA_PERIPH_STM32_TRAITS_ADC_TEST_DMA_EX( dma2_Channel1, 2 ); // hw channel 2
        }
        #endif

    #endif

    // UMBA_ASSERT_FAIL(); - нахуй тут assert, функция тестирует, переданное, а не возвращает что-то на запрос.
    // Я этот assert тут оставлю, чтобы, блядь, сцука, потом не появилось желание опять его сюда вставить

    return false;
}

template<>
inline
bool periphDmaRemap<ADC_TypeDef>( ADC_TypeDef *pp, DmaControllerChannel ctrlCh )
{
    #if defined(STM32F3_SERIES)

        // see SYSCFG_DMAChannelRemapConfig
        // SYSCFG_DMARemap_ADC2ADC4           SYSCFG_CFGR1_ADC24_DMA_RMP
        // #define SYSCFG_CFGR1_ADC24_DMA_RMP          ((uint32_t)0x00000100) /*!< ADC2 and ADC4 DMA remap */
        // #define SYSCFG_CFGR3_ADC2_DMA_RMP              ((uint32_t)0x00000300) /*!< ADC2 DMA remap */
        // #define SYSCFG_CFGR3_ADC2_DMA_RMP_0            ((uint32_t)0x00000100) /*!< ADC2 DMA remap bit 0 */
        // #define SYSCFG_CFGR3_ADC2_DMA_RMP_1            ((uint32_t)0x00000200) /*!< ADC2 DMA remap bit 1 */

        return true; // UNDONE: need to implement remapping

        #ifdef ADC1
        if (pp==ADC1)
        {
        }
        #endif

        #ifdef ADC2
        if (pp==ADC2)
        {
        }
        #endif

        #ifdef ADC3
        if (pp==ADC3)
        {
        }
        #endif

        #ifdef ADC4
        if (pp==ADC4)
        {
        }
        #endif

    #else

        return true;

    #endif
}

template<> inline bool periphDmaTestCompatible<ADC_TypeDef>( ADC_TypeDef *pp, DmaControllerChannel ctrlCh, uint32_t *pHwChannelRes, DmaDirection dir )
{
    return periphDmaTestCompatible<ADC_TypeDef>( pp, ctrlCh, pHwChannelRes );
}

template<> inline bool periphDmaRemap<ADC_TypeDef>( ADC_TypeDef *pp, DmaControllerChannel ctrlCh, DmaDirection dir )
{
    return periphDmaRemap<ADC_TypeDef>( pp, ctrlCh );
}

template<> inline bool periphDmaTestCompatible<ADC_TypeDef>( ADC_TypeDef *pp, DmaControllerChannel ctrlCh, uint32_t *pHwChannelRes, DmaDirection dir, int channel )
{
    return periphDmaTestCompatible<ADC_TypeDef>( pp, ctrlCh, pHwChannelRes );
}

template<> inline bool periphDmaRemap<ADC_TypeDef>( ADC_TypeDef *pp, DmaControllerChannel ctrlCh, DmaDirection dir, int channel )
{
    return periphDmaRemap<ADC_TypeDef>( pp, ctrlCh );
}





// http://we.easyelectronics.ru/STM32/rukovodstvo-k-bystromu-startu-po-rabote-s-periferiey-stm32f10x.html

enum class AdcInitHwOption
{
    dont_init = 0,
    init      = 1
};


inline
AdcInjected adcInitInject( ADC_TypeDef* ADCx, AdcSamplingSpeed samplingSpeed, AdcInitHwOption doInitAdc // set true to add injected channels over regular
                         , GpioPinAddr* gpioPinAddrs, size_t pinAddrsCount
                         )
{
    UMBA_ASSERT( pinAddrsCount < 4 );
    UMBA_ASSERT( gpioPinAddrs != 0 );

    initPeriphClock( ADCx, ENABLE );

    if (doInitAdc!=AdcInitHwOption::dont_init)
    {
        //ADC_DeInit(ADCx);
       
        adcCommonInitSimple( ADCx );
       
        ADC_InitTypeDef ADC_InitStructure;
        ADC_StructInit( &ADC_InitStructure );
       
        #if defined(STM32F1_SERIES)
       
            ADC_InitStructure.ADC_ContinuousConvMode = ENABLE; // ADC_ContinuousConvMode_Enable;
            ADC_InitStructure.ADC_DataAlign          = ADC_DataAlign_Right;
            ADC_InitStructure.ADC_ExternalTrigConv   = ADC_ExternalTrigConv_None;
            ADC_InitStructure.ADC_Mode               = ADC_Mode_Independent; // ADC_Mode_InjecSimult; // ADC_Mode_Independent;
            ADC_InitStructure.ADC_NbrOfChannel       = 0; // pinAddrsCount; // 1;
            ADC_InitStructure.ADC_ScanConvMode       = ENABLE;

        #elif defined(STM32F3_SERIES)

            ADC_InitStructure.ADC_AutoInjMode = ADC_AutoInjec_Enable;
            ADC_InitStructure.ADC_ContinuousConvMode = ADC_ContinuousConvMode_Enable;
            ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
            ADC_InitStructure.ADC_ExternalTrigConvEvent = ADC_ExternalTrigConvEvent_0;
            ADC_InitStructure.ADC_ExternalTrigEventEdge = ADC_ExternalTrigEventEdge_None;
            ADC_InitStructure.ADC_NbrOfRegChannel = 1;
            ADC_InitStructure.ADC_OverrunMode = ADC_OverrunMode_Disable;
            ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;

        #else

            ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
            ADC_InitStructure.ADC_ScanConvMode = ENABLE; // DISABLE;
            ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
            ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
            ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;
            ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
            ADC_InitStructure.ADC_NbrOfConversion = 1;
            ADC_Init(ADCx, &ADC_InitStructure);

        #endif
       
        ADC_Init(ADCx, &ADC_InitStructure);
    }

    #if defined(STM32F1_SERIES)

        ADC_InjectedSequencerLengthConfig(ADC1, pinAddrsCount);

    #elif defined(STM32F3_SERIES)

        ADC_InjectedInitTypeDef injectedInitStructure;
        ADC_InjectedStructInit( &injectedInitStructure);

        injectedInitStructure.ADC_ExternalTrigInjecConvEvent = ADC_ExternalTrigInjecConvEvent_0;
        injectedInitStructure.ADC_ExternalTrigInjecEventEdge = ADC_ExternalTrigInjecEventEdge_None;

        injectedInitStructure.ADC_NbrOfInjecChannel = pinAddrsCount;

        /* injectedInitStructure.ADC_InjecSequence1 = adc.channels[0];
         * injectedInitStructure.ADC_InjecSequence2 = adc.channels[1];
         * injectedInitStructure.ADC_InjecSequence3 = adc.channels[2];
         * injectedInitStructure.ADC_InjecSequence4 = adc.channels[3];
         */

        int channels[4]; //  = { -1, -1, -1, -1 };
        
    #elif defined(STM32F4_SERIES)

        ADC_InjectedSequencerLengthConfig(ADC1, pinAddrsCount);
        //ADC_InjectedChannelConfig( ADC1, uint8_t ADC_Channel, uint8_t Rank, uint8_t ADC_SampleTime);

        
        //#error "Not implemented"


    #endif

    unsigned injectedChannelIdx = 0;

    GpioPinAddr* ppa = gpioPinAddrs;
    for(size_t p=0; p!=pinAddrsCount; ++p, ++injectedChannelIdx)
    {
        UMBA_ASSERT(ppa[p].port!=0);
        initPeriphClock( ppa[p].port, ENABLE );
        gpioInit( ppa[p].port, PinSpeed::high, PinMode::analog_in, 1<<ppa[p].pinNo );

        #if defined(STM32F1_SERIES)

            ADC_InjectedChannelConfig( ADCx
                                     , getPinAddrAdcChannelNo( ADCx, ppa[p] ) // ADC_Channel_X
                                     ,  injectedChannelIdx + 1
                                     , (uint8_t)adcSamplingSpeedConvertToRaw( samplingSpeed )
                                     );
            

        #elif defined(STM32F3_SERIES)

            unsigned chNo = getPinAddrAdcChannelNo( ADCx, ppa[p] );
            channels[p] = (int)chNo;
            *((&injectedInitStructure.ADC_InjecSequence1) + injectedChannelIdx) = chNo;
            // void ADC_InjectedChannelSampleTimeConfig(ADC_TypeDef* ADCx, uint8_t ADC_InjectedChannel, uint8_t ADC_SampleTime);
            //#error "Not implemented"
            
        #elif defined(STM32F4_SERIES)
            
            //unsigned chNo = getPinAddrAdcChannelNo( ADCx, ppa[p] );
            ADC_InjectedChannelConfig( ADCx
                                     , getPinAddrAdcChannelNo( ADCx, ppa[p] ) // ADC_Channel_X
                                     ,  injectedChannelIdx + 1
                                     , (uint8_t)adcSamplingSpeedConvertToRaw( samplingSpeed )
                                     );

        #endif
    }

    #if defined(STM32F1_SERIES)

        ADC_ExternalTrigInjectedConvConfig( ADCx, ADC_ExternalTrigInjecConv_None );    
        ADC_AutoInjectedConvCmd( ADCx, ENABLE );
        while(!(ADCx->CR1 & 0x00000400)); // #define CR1_JAUTO_Set               ((uint32_t)0x00000400)

        ADC_Cmd ( ADCx , ENABLE );
        while(!(ADCx->CR2 & 0x00000001)); // #define CR2_ADON_Set                ((uint32_t)0x00000001)

        ADC_SoftwareStartInjectedConvCmd ( ADCx , ENABLE );

        return AdcInjected( ADCx, injectedChannelIdx );

    #elif defined(STM32F3_SERIES)

        ADC_InjectedInit( ADCx, &injectedInitStructure );
        ppa = gpioPinAddrs;
        for(size_t p=0; p!=pinAddrsCount; ++p)
        {
            ADC_InjectedChannelSampleTimeConfig( ADCx, getPinAddrAdcChannelNo( ADCx, ppa[p] )
                                               , (uint8_t)adcSamplingSpeedConvertToRaw( samplingSpeed ) );
        }

        ADC_AutoInjectedConvCmd(ADCx, ENABLE);
        while(!(ADCx->CFGR & ADC_CFGR_JAUTO));
        
        ADC_Cmd( ADCx, ENABLE );
        while(!(ADCx->CR & ADC_CR_ADEN));
        
        ADC_StartConversion(ADCx);
        //while(!(ADCx->CR & ADC_CR_ADSTART));
        
        //return AdcInjected( ADCx, injectedChannelIdx, &channels[0] );
        return AdcInjected( ADCx, injectedChannelIdx );

    #elif defined(STM32F4_SERIES)
        
        ADC_ExternalTrigInjectedConvEdgeConfig( ADCx, ADC_ExternalTrigInjecConvEdge_None );
        ADC_AutoInjectedConvCmd( ADCx, ENABLE );
        while(!(ADCx->CR1 & ADC_CR1_JAUTO));

        ADC_Cmd ( ADCx , ENABLE );
        while(!(ADCx->CR2 & ADC_CR2_ADON));

        //ADC_SoftwareStartInjectedConvCmd ( ADCx , ENABLE );
        ADC_SoftwareStartInjectedConv( ADCx );
        //while(!(ADCx->CR2 & ADC_CR2_JSWSTART));

        return AdcInjected( ADCx, injectedChannelIdx );

    #else

        UMBA_ASSERT_FAIL();
        return AdcInjected( (ADC_TypeDef*)0, 0 );

    #endif

    
            
}




template< typename... SomeStructuredTypeListItems >
inline
AdcInjected adcInitInject( ADC_TypeDef* ADCx, AdcSamplingSpeed samplingSpeed
                         , AdcInitHwOption doInitAdc // set to true to add injected channels over regular
                         , SomeStructuredTypeListItems... structs)
{
    getVariadicArgsType< 0, SomeStructuredTypeListItems... > buf[sizeof...(structs)];

    size_t sz = buildSomeStructuredTypeArray< sizeof...(structs) > (buf, structs...);

    return adcInitInject( ADCx, samplingSpeed, doInitAdc, buf, sz );
}


// На скорую руку одноканальный регулярный ацп

#if defined(STM32F3_SERIES)

// DMA https://microtechnics.ru/stm32f3-rabota-s-adc-i-dma/
// http://easystm32.ru/for-beginners/20-adc-in-stm32-part-2/

// https://hubstub.ru/stm32/66-stm32-acp.html

// Injected - http://easystm32.ru/for-beginners/18-adc-in-stm32-part-1/
//            http://easystm32.ru/for-beginners/20-adc-in-stm32-part-2/

// bare metall http://eleceng.dit.ie/frank/arm/BareMetalSTM32F303Nucleo/

class AdcSingleChannel
{

public:

    AdcSingleChannel( ADC_TypeDef *ADCx, GpioPinAddr gpioPinAddr, AdcSamplingSpeed samplingSpeed )
    : m_ADCx(ADCx)
    {
        //ADC_InitTypeDef  ADC_InitStructure;
        //RCC_ADCCLKConfig(RCC_PCLK2_Div6);
        RCC_ADCCLKConfig(RCC_ADC12PLLCLK_Div6);
        //RCC_ADCCLKConfig( params.adcPllDivider );

        initPeriphClock( m_ADCx, ENABLE );

        initPeriphClock( gpioPinAddr.port, ENABLE );
        gpioInit( gpioPinAddr.port, PinSpeed::high, PinMode::analog_in, 1<<gpioPinAddr.pinNo );

        //RCC_AHBPeriphClockCmd( params.rccAdc, ENABLE);

        // без этого калибровка не завершалась
        // не очень понятно почему TODO: понять
        RCC_ADCCLKConfig( RCC_ADC12PLLCLK_Div256 );

        /* Calibration procedure */
        ADC_VoltageRegulatorCmd( m_ADCx, ENABLE);

        /* Insert delay equal to 10 µs */
        for( volatile uint32_t i=0; i<SystemCoreClock/100000; i++ )
        {
            __NOP();
        }

        ADC_SelectCalibrationMode( m_ADCx, ADC_CalibrationMode_Single );
        ADC_StartCalibration( m_ADCx );

        while( ADC_GetCalibrationStatus( m_ADCx ) != RESET );

        // ацп - настройка

        ADC_InitTypeDef ADC_InitStructure;
        ADC_StructInit( &ADC_InitStructure );

        // общая
        ADC_CommonInitTypeDef ADC_CommonInitStructure;

        ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
        ADC_CommonInitStructure.ADC_Clock = ADC_Clock_AsynClkMode;
        ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_1;
        ADC_CommonInitStructure.ADC_DMAMode = ADC_DMAAccessMode_Disabled; // //ADC_DMAMode_Circular;
        ADC_CommonInitStructure.ADC_TwoSamplingDelay = 0;

        ADC_CommonInit( m_ADCx, &ADC_CommonInitStructure );

        /* adc configuration ------------------------------------------------------*/
        ADC_InitStructure.ADC_ContinuousConvMode = ADC_ContinuousConvMode_Enable;
        ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
        ADC_InitStructure.ADC_ExternalTrigConvEvent = ADC_ExternalTrigConvEvent_0;
        ADC_InitStructure.ADC_ExternalTrigEventEdge = ADC_ExternalTrigEventEdge_None;
        ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
        ADC_InitStructure.ADC_OverrunMode = ADC_OverrunMode_Disable;
        ADC_InitStructure.ADC_AutoInjMode = ADC_AutoInjec_Disable;

        ADC_InitStructure.ADC_NbrOfRegChannel = 1; // sizeof...(channels);
        ADC_Init( m_ADCx, &ADC_InitStructure );

        //uint8_t chan[] = { channels... };

        // настройка каналов - в каком порядке они будут конвертиться
        //for( uint8_t i = 0; i<NUM_ELEM(chan); i++ )
        //{
        //    ADC_RegularChannelConfig( params.adc, chan[i], i+1, ADC_SampleTime_601Cycles5 );
        //}

        //ADC_RegularChannelConfig( m_ADCx, getPinAddrAdcChannelNo( m_ADCx, gpioPinAddr ) /* chan[i] */ , 1 /* i+1 */ , ADC_SampleTime_601Cycles5 );
        ADC_RegularChannelConfig( m_ADCx, getPinAddrAdcChannelNo( m_ADCx, gpioPinAddr ) /* chan[i] */ , 1 /* i+1 */ , adcSamplingSpeedConvertToRaw(samplingSpeed) );

        ADC_Cmd( m_ADCx, ENABLE );

        /* wait for adc ADRDY */
        while( !ADC_GetFlagStatus( m_ADCx, ADC_FLAG_RDY ) ) 
        {
            ADC_Cmd( m_ADCx, ENABLE );
        }

        /* Enable the DMA channel */
        //DMA_Cmd( params.dmaChannel, ENABLE );

        /* Start adc Software Conversion */
        ADC_StartConversion( m_ADCx );



/*
    ADC1_2->CCR |= 1<<17;
    //ADC12_CCR |= 1<<17; // BIT17;
	// disable the ADC
	m_ADCx->CR &= ~(1<<0);// ADC2_CR &= ~(1<<0);	//BIT0
	// enable the ADC voltage regulator
	m_ADCx->CR &= ~(1<<29); //ADC2_CR &= ~(1<<29); // BIT29
	m_ADCx->CR |= 1<<28; // ADC2_CR |= 1<<28; //BIT28
	// start ADC calibration cycle
	m_ADCx->CR |= 1<<31; //BIT31
	// wait for calibration to complete
	while (m_ADCx->CR & (1<<31)); //BIT31
	
	// enable the ADC
	m_ADCx->CR |= 1<<0; // BIT0
	
	// Select ADC Channel 1
	m_ADCx->SQR1 = (3 << 6);

*/

        /*

        initPeriphClock( m_ADCx, ENABLE );

        initPeriphClock( gpioPinAddr.port, ENABLE );
        gpioInit( gpioPinAddr.port, PinSpeed::high, PinMode::analog_in, 1<<gpioPinAddr.pinNo );

        m_ADCx->CR &= ~(3<<28); //ADC voltage regulator clr
        m_ADCx->CR |= (1<<28); //ADC voltage regulator clr
        for( volatile uint32_t i=0; i<SystemCoreClock/100000; i++ )
        {
            __NOP();
        }

        m_ADCx->CR &= ~(1<<30); // clr ADCALDIF
        m_ADCx->CR |= 1<<31; // calib

        for( volatile uint32_t i=0; i<SystemCoreClock/100000; i++ )
        {
            __NOP();
        }

        m_ADCx->CR |= 1; // ADEN

        //for(size_t i=0; i!=10000; ++i) {}

        m_ADCx->CFGR &= ~(1<<5); // ALIGN - right
        m_ADCx->CFGR &= ~(3<<3); // RES 12 bit

        unsigned spd = adcSamplingSpeedConvertToRaw( samplingSpeed );        

        m_ADCx->SMPR1 |= (spd&7)<<3; // samplking speed
        
        m_ADCx->SQR1 &= ~0x0F; // L=0 - 1 channel in sequence

        unsigned chan = getPinAddrAdcChannelNo( m_ADCx, gpioPinAddr );
        m_ADCx->SQR1 &= ~(0x1F<<6);
        m_ADCx->SQR1 |= chan<<6;

        while( !ADC_GetFlagStatus( m_ADCx, ADC_FLAG_RDY ) ) {;}


        
        //while( m_ADCx->CR & (1<<31)) 
        {
        } // wait for
        */

    }

    AdcSingleChannel( const AdcSingleChannel &adcSingleChannel)
    : m_ADCx(adcSingleChannel.m_ADCx)
    {
    }

    operator unsigned () const
    {
        /*
        //m_ADCx->CR |= 1<<2; // ADSTART
        m_ADCx->CR |= ADC_CR_ADSTART;
        //while( (m_ADCx->ISR & (1<<2))==0 )
        while( (m_ADCx->CR & ADC_CR_ADSTART) !=0 )
        {
        }
        */
        //m_ADCx->CR |= 1<<2; // BIT2; // start conversion
        //while (m_ADCx->CR & (1<<2)); // BIT2 wait for end of conversion
        return m_ADCx->DR;

        //return m_ADCx->DR;
    }

protected:

    ADC_TypeDef *m_ADCx;

}; // AdcSingleChannel





template< size_t BufSize >
class AdcSingleChannelDma
{

public:

    AdcSingleChannelDma( ADC_TypeDef *ADCx, GpioPinAddr gpioPinAddr, AdcSamplingSpeed samplingSpeed, DmaControllerChannel dmaX_ChannelY )
    : m_ADCx(ADCx)
    {
        dmaInitBase( dmaX_ChannelY
                   , (void*)&m_buf[0]
                   , (void*)&m_ADCx->DR
                   , DmaChannelPriorityLevel::dmaChannelPriorityVeryHigh
                   , (uint32_t)1 // hwChannel mean only for F4
                   //, sizeof(m_buf[0])
                   , DmaSize::dmaSizeBits16
                   , sizeof( m_buf ) / sizeof(m_buf[0])
                   , DmaDirection::dmaPeriphToMem
                   , DmaIncMode::dmaIncMem   
                   , DmaIncMode::dmaIncOff
                   , DmaCircMode::dmaCircOn
                );

        //ADC_InitTypeDef  ADC_InitStructure;
        //RCC_ADCCLKConfig(RCC_PCLK2_Div6);
        RCC_ADCCLKConfig(RCC_ADC12PLLCLK_Div6);
        //RCC_ADCCLKConfig( params.adcPllDivider );

        initPeriphClock( m_ADCx, ENABLE );

        initPeriphClock( gpioPinAddr.port, ENABLE );
        gpioInit( gpioPinAddr.port, PinSpeed::high, PinMode::analog_in, 1<<gpioPinAddr.pinNo );

        //RCC_AHBPeriphClockCmd( params.rccAdc, ENABLE);

        // без этого калибровка не завершалась
        // не очень понятно почему TODO: понять
        RCC_ADCCLKConfig( RCC_ADC12PLLCLK_Div256 );

        /* Calibration procedure */
        ADC_VoltageRegulatorCmd( m_ADCx, ENABLE);

        /* Insert delay equal to 10 µs */
        for( volatile uint32_t i=0; i<SystemCoreClock/100000; i++ )
        {
            __NOP();
        }

        ADC_SelectCalibrationMode( m_ADCx, ADC_CalibrationMode_Single );
        ADC_StartCalibration( m_ADCx );

        while( ADC_GetCalibrationStatus( m_ADCx ) != RESET );

        // ацп - настройка

        ADC_InitTypeDef ADC_InitStructure;
        ADC_StructInit( &ADC_InitStructure );

        // общая
        ADC_CommonInitTypeDef ADC_CommonInitStructure;

        ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
        ADC_CommonInitStructure.ADC_Clock = ADC_Clock_AsynClkMode;
        ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_1; // DMA mode enabled for 12 and 10-bit resolution (6 bit)
        ADC_CommonInitStructure.ADC_DMAMode = ADC_DMAMode_Circular; // ADC_DMAAccessMode_Disabled; // //ADC_DMAMode_Circular;
        ADC_CommonInitStructure.ADC_TwoSamplingDelay = 0;

        ADC_CommonInit( m_ADCx, &ADC_CommonInitStructure );

        /* adc configuration ------------------------------------------------------*/
        ADC_InitStructure.ADC_ContinuousConvMode = ADC_ContinuousConvMode_Enable;
        ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
        ADC_InitStructure.ADC_ExternalTrigConvEvent = ADC_ExternalTrigConvEvent_0;
        ADC_InitStructure.ADC_ExternalTrigEventEdge = ADC_ExternalTrigEventEdge_None;
        ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
        ADC_InitStructure.ADC_OverrunMode = ADC_OverrunMode_Disable;
        ADC_InitStructure.ADC_AutoInjMode = ADC_AutoInjec_Disable;

        ADC_InitStructure.ADC_NbrOfRegChannel = 1; // sizeof...(channels);
        ADC_Init( m_ADCx, &ADC_InitStructure );

        //uint8_t chan[] = { channels... };

        // настройка каналов - в каком порядке они будут конвертиться
        //for( uint8_t i = 0; i<NUM_ELEM(chan); i++ )
        //{
        //    ADC_RegularChannelConfig( params.adc, chan[i], i+1, ADC_SampleTime_601Cycles5 );
        //}

        //ADC_RegularChannelConfig( m_ADCx, getPinAddrAdcChannelNo( m_ADCx, gpioPinAddr ) /* chan[i] */ , 1 /* i+1 */ , ADC_SampleTime_601Cycles5 );
        ADC_RegularChannelConfig( m_ADCx, getPinAddrAdcChannelNo( m_ADCx, gpioPinAddr ) /* chan[i] */ , 1 /* i+1 */ , adcSamplingSpeedConvertToRaw(samplingSpeed) );

        ADC_Cmd( m_ADCx, ENABLE );

        /* wait for adc ADRDY */
        while( !ADC_GetFlagStatus( m_ADCx, ADC_FLAG_RDY ) ) 
        {
            ADC_Cmd( m_ADCx, ENABLE );
        }

        /* Configures the ADC DMA */
        ADC_DMAConfig( m_ADCx, ADC_DMAMode_Circular );
        /* Enable the ADC DMA */
        ADC_DMACmd( m_ADCx, ENABLE );

        /* Enable the DMA channel */
        //DMA_Cmd( params.dmaChannel, ENABLE );
        //DMA_Channel_TypeDef
        periphEnable( dmaGetChannelAddr( dmaX_ChannelY ), DmaOnOff::dmaOn );
        //periphEnable( dmaGetChannelAddr( DMA2, dmaChannel1 ), dmaOn );
        //void ADC_DMACmd(ADC_TypeDef* ADCx, FunctionalState NewState); 


        /* Start adc Software Conversion */
        ADC_StartConversion( m_ADCx );



/*
    ADC1_2->CCR |= 1<<17;
    //ADC12_CCR |= 1<<17; // BIT17;
	// disable the ADC
	m_ADCx->CR &= ~(1<<0);// ADC2_CR &= ~(1<<0);	//BIT0
	// enable the ADC voltage regulator
	m_ADCx->CR &= ~(1<<29); //ADC2_CR &= ~(1<<29); // BIT29
	m_ADCx->CR |= 1<<28; // ADC2_CR |= 1<<28; //BIT28
	// start ADC calibration cycle
	m_ADCx->CR |= 1<<31; //BIT31
	// wait for calibration to complete
	while (m_ADCx->CR & (1<<31)); //BIT31
	
	// enable the ADC
	m_ADCx->CR |= 1<<0; // BIT0
	
	// Select ADC Channel 1
	m_ADCx->SQR1 = (3 << 6);

*/

        /*

        initPeriphClock( m_ADCx, ENABLE );

        initPeriphClock( gpioPinAddr.port, ENABLE );
        gpioInit( gpioPinAddr.port, PinSpeed::high, PinMode::analog_in, 1<<gpioPinAddr.pinNo );

        m_ADCx->CR &= ~(3<<28); //ADC voltage regulator clr
        m_ADCx->CR |= (1<<28); //ADC voltage regulator clr
        for( volatile uint32_t i=0; i<SystemCoreClock/100000; i++ )
        {
            __NOP();
        }

        m_ADCx->CR &= ~(1<<30); // clr ADCALDIF
        m_ADCx->CR |= 1<<31; // calib

        for( volatile uint32_t i=0; i<SystemCoreClock/100000; i++ )
        {
            __NOP();
        }

        m_ADCx->CR |= 1; // ADEN

        //for(size_t i=0; i!=10000; ++i) {}

        m_ADCx->CFGR &= ~(1<<5); // ALIGN - right
        m_ADCx->CFGR &= ~(3<<3); // RES 12 bit

        unsigned spd = adcSamplingSpeedConvertToRaw( samplingSpeed );        

        m_ADCx->SMPR1 |= (spd&7)<<3; // samplking speed
        
        m_ADCx->SQR1 &= ~0x0F; // L=0 - 1 channel in sequence

        unsigned chan = getPinAddrAdcChannelNo( m_ADCx, gpioPinAddr );
        m_ADCx->SQR1 &= ~(0x1F<<6);
        m_ADCx->SQR1 |= chan<<6;

        while( !ADC_GetFlagStatus( m_ADCx, ADC_FLAG_RDY ) ) {;}


        
        //while( m_ADCx->CR & (1<<31)) 
        {
        } // wait for
        */

    }

    AdcSingleChannelDma( const AdcSingleChannelDma &adcSingleChannel)
    : m_ADCx(adcSingleChannel.m_ADCx)
    {
    }

    operator unsigned () const
    {
        unsigned res = 0;
        for(size_t i=0; i!=BufSize; ++i)
        {
            res += m_buf[i];
        }

        return res / BufSize;

        /*
        //m_ADCx->CR |= 1<<2; // ADSTART
        m_ADCx->CR |= ADC_CR_ADSTART;
        //while( (m_ADCx->ISR & (1<<2))==0 )
        while( (m_ADCx->CR & ADC_CR_ADSTART) !=0 )
        {
        }
        */
        //m_ADCx->CR |= 1<<2; // BIT2; // start conversion
        //while (m_ADCx->CR & (1<<2)); // BIT2 wait for end of conversion
        //return m_ADCx->DR;

        //return m_ADCx->DR;

        return 0;
    }

protected:

    ADC_TypeDef *m_ADCx;

    uint16_t     m_buf[BufSize];


}; // AdcSingleChannelDma



    // ADC_TypeDef* ADCx
    // unsigned adcSamplingSpeedConvertToRaw( AdcSamplingSpeed chsp )
    // unsigned getPinAddrAdcChannelNo( ADC_TypeDef* ADCx, const GpioPinAddr &pinAddr )

/*

ADCx_ISR - EOC
ADRDY ?

ADCx_CR
ADCAL: ADC calibration - It is cleared by hardware after calibration is complete. 0: Calibration complete
ADSTART: ADC start of regular conversion
ADEN: ADC enable control


CFGR - CONT
ALIGN: Data alignment
This bit is set and cleared by software to select right or left alignment. Refer to Figure : Data register,
data alignment and offset (ADCx_DR, OFFSETy, OFFSETy_CH, ALIGN)
0: Right alignment
1: Left alignment
Note: Software is allowed to write this bit only when ADSTART=0 and JADSTART=0 (which ensures
that no conversion is ongoing).

RES[1:0]: Data resolution
These bits are written by software to select the resolution of the conversion

0: Right alignment



Single conversion mode (CONT=0)
In Single conversion mode, the ADC performs once all the conversions of the channels.
This mode is started with the CONT bit at 0 by either:
• Setting the ADSTART bit in the ADCx_CR register (for a regular channel)
• Setting the JADSTART bit in the ADCx_CR register (for an injected channel)
• External hardware trigger event (for a regular or injected channel)
Inside the regular sequence, after each conversion is complete:
• The converted data are stored into the 16-bit ADCx_DR register
• The EOC (end of regular conversion) flag is set
• An interrupt is generated if the EOCIE bit is set
Inside the injected sequence, after each conversion is complete:
• The converted data are stored into one of the four 16-bit ADCx_JDRy registers
• The JEOC (end of injected conversion) flag is set
• An interrupt is generated if the JEOCIE bit is set
After the regular sequence is complete:
• The EOS (end of regular sequence) flag is set
• An interrupt is generated if the EOSIE bit is set
After the injected sequence is complete:
• The JEOS (end of injected sequence) flag is set
• An interrupt is generated if the JEOSIE bit is set
Then the ADC stops until a new external regular or injected trigger occurs or until bit
ADSTART or JADSTART is set again

Note: To convert a single channel, program a sequence with a length of 1.


Starting conversions (ADSTART, JADSTART)
Software starts ADC regular conversions by setting ADSTART=1.
When ADSTART is set, the conversion starts:
• Immediately: if EXTEN = 0x0 (software trigger)
• At the next active edge of the selected regular hardware trigger: if EXTEN /= 0x0


*/

#endif


} // namespace traits
} // namespace periph
} // namespace umba




