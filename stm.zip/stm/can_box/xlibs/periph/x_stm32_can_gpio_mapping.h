
namespace umba{
namespace periph{
namespace traits{

//-----------------------------------------------------------------------------

#if defined(STM32F1_SERIES)

    #if 0
    #define GPIO_Remap1_CAN1            ((uint32_t)0x001D4000)  /*!< CAN1 Alternate Function mapping */
    #define GPIO_Remap2_CAN1            ((uint32_t)0x001D6000)  /*!< CAN1 Alternate Function mapping */
    #define GPIO_Remap_CAN2             ((uint32_t)0x00200040)  /*!< CAN2 remapping (only for Connectivity line devices) */
    #endif

    /*
      103 C/D/E
      PA11 CAN_RX  CAN1? Main
      PA12 CAN_TX  CAN1? Main

      PB8 CAN_RX  CAN1?  Alter
      PB9 CAN_TX  CAN1?  Alter

      PD0 CAN_RX  CAN1?  Alter
      PD1 CAN_TX  CAN1?  Alter

      // F105RC
      PB12 CAN2_RX MAIN
      PB13 CAN2_TX MAIN

      PB5 CAN2_RX Alter
      PB6 CAN2_TX Alter

            A11_A12 - no remap
            
            case CanPins::D0_D1:
                GPIO_PinRemapConfig( GPIO_Remap2_CAN1, ENABLE);

            case CanPins::B8_B9:
                GPIO_PinRemapConfig( GPIO_Remap1_CAN1, ENABLE);
    */

    template < >
    inline
    uint32_t periphAltFunctionGetFlags< CAN_TypeDef, PinFunctionCan >( CAN_TypeDef *pt, PinFunctionCan pinFn, GPIO_TypeDef* pGpioPort, unsigned pinNo )
    {
        #if defined(CAN1) && defined(USE_CAN1)
            if (pt==CAN1)
            {
                if (pinFn==PinFunctionCan::rx)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOA, 11, 0 ); // PA11
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB, 8 , GPIO_Remap1_CAN1 ); // PB8

                    #if defined(GPIOD)
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOD, 0 , GPIO_Remap2_CAN1 ); // PD0
                    #endif
                }
                else if (pinFn==PinFunctionCan::tx)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOA, 12, 0 ); // PA12
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB, 9 , GPIO_Remap1_CAN1 ); // PB9

                    #if defined(GPIOD)
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOD, 1 , GPIO_Remap2_CAN1 ); // PD1
                    #endif
                }
            }
        #endif

        #if defined(CAN2) && defined(USE_CAN2)
            if (pt==CAN2)
            {
                if (pinFn==PinFunctionCan::rx)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB,  5, GPIO_Remap_CAN2 ); // PB5
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB, 12, 0 ); // PB12
                }
                else if (pinFn==PinFunctionCan::tx)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB,  6, GPIO_Remap_CAN2 ); // PB6
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB, 13, 0 ); // PB13
                }
            }
        #endif

        UMBA_ASSERT_FAIL();
        return 0;
    }

#elif defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

    template < >
    inline
    uint32_t periphAltFunctionGetFlags< CAN_TypeDef, PinFunctionCan >( CAN_TypeDef *pt, PinFunctionCan pinFn, GPIO_TypeDef* pGpioPort, unsigned pinNo )
    {
        #if (defined(CAN1) && defined(USE_CAN1)) || (defined(CAN) && (defined(USE_CAN)||defined(USE_CAN1)))

            #if defined(CAN1)
            if (pt==CAN1)
            #else
            if (pt==CAN)
            #endif
            {
                if (pinFn==PinFunctionCan::rx)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOA, 11, GPIO_AF_9 ); // PA11   F3/F4
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB, 8 , GPIO_AF_9 ); // PB8    F3/F4

                    #if defined(GPIOD)
                        #if defined(STM32F3_SERIES)
                            UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOD, 0 , GPIO_AF_7 ); // PD0
                        #else
                            UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOD, 0 , GPIO_AF_9 ); // PD0
                        #endif
                    #endif

                    #if defined(GPIOI)
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOI, 9 , GPIO_AF_9 ); // PI9
                    #endif

                }
                else if (pinFn==PinFunctionCan::tx)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOA, 12, GPIO_AF_9 ); // PA12   F3/F4
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB, 9 , GPIO_AF_9 ); // PB9    F3/F4

                    #if defined(GPIOD)
                        #if defined(STM32F3_SERIES)
                            UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOD, 1 , GPIO_AF_7 ); // PD1
                        #else
                            UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOD, 1 , GPIO_AF_7 ); // PD1
                        #endif
                    #endif

                    #if defined(GPIOH)
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOH, 13, GPIO_AF_9 ); // PH13
                    #endif

                }
            }
        #endif

        #if defined(CAN2) && defined(USE_CAN2)
            if (pt==CAN2)
            {
                if (pinFn==PinFunctionCan::rx)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB,  5, GPIO_AF_9 ); // PB5
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB, 12, GPIO_AF_9 ); // PB12
                }
                else if (pinFn==PinFunctionCan::tx)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB,  6, GPIO_AF_9 ); // PB6
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB, 13, GPIO_AF_9 ); // PB13
                }
            }
        #endif

        UMBA_ASSERT_FAIL();
        return 0;
    }
#endif // STM32F4_SERIES


} // namespace traits
} // namespace periph
} // namespace umba


