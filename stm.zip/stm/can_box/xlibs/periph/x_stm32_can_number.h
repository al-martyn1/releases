
namespace umba{
namespace periph{
namespace traits{

//----------------------------------------------------------------------------
//inline
UMBA_FORCE_INLINE( unsigned /* uint16_t */ canGetNo( CAN_TypeDef *pt ) )
{
    #if defined(CAN1) && defined(USE_CAN1)
        if (pt==CAN1) return 1u;
    #endif
    #if defined(CAN2) && defined(USE_CAN2)
        if (pt==CAN2) return 2u;
    #endif
    #if defined(CAN3) && defined(USE_CAN3)
        if (pt==CAN) return 3u;
    #endif

    UMBA_ASSERT_FAIL();

    return 0;
}

//inline
UMBA_FORCE_INLINE( unsigned /* uint16_t */ periphGetNo( CAN_TypeDef * pt ) )
{
    return canGetNo(pt);
}

//inline
UMBA_FORCE_INLINE( CAN_TypeDef* canGetCan( unsigned /* uint16_t */ canNo ) )
{
    switch(canNo)
    {
        case 1u:
             #if defined(CAN1) && defined(USE_CAN1)
             return CAN1;
             #else
             break;
             #endif
        case 2u:
             #if defined(CAN2) && defined(USE_CAN2)
             return CAN2;
             #else
             break;
             #endif
        case 3u:
             #if defined(CAN3) && defined(USE_CAN3)
             return CAN3;
             #else
             break;
             #endif
    }

    UMBA_ASSERT_FAIL();
    
    return 0;

}


} // namespace traits
} // namespace periph
} // namespace umba

