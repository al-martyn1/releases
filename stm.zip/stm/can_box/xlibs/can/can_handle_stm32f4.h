#pragma once

#if defined(STM32F4XX)       || defined(STM32F40_41xxx) || defined(STM32F427_437xx) || \
    defined(STM32F429_439xx) || defined(STM32F401xx)    || defined(STM32F410xx)     || \
    defined(STM32F411xE)     || defined(STM32F412xG)    || defined(STM32F413_423xx) || \
    defined(STM32F446xx)     || defined(STM32F469_479xx)


#include "circular_buffer/blocking_circular_buffer.h"
#include "i_can.h"
#include "can_config.h"



namespace can
{       
    const uint32_t max_baud_rate = 500000;      // бит в сек - предельный бодрейт can
    
    const uint32_t min_baud_rate = 3000;        // бит в сек - предельный бодрейт can

    const uint8_t num_of_rx_fifo = 2;           // кол-во фифо приемных

    const uint8_t max_num_of_rx_filters = 14;   // предельное кол-во фильтров при использовании 32 бит    


    
    // выбор GPIO
    STRONG_ENUM( CanTxPins ,
        CAN1_A12,
        #if defined(STM32F412xG) || defined(STM32F413_423xx)
            CAN1_B9 ,
        #endif
        CAN1_D1 ,
        CAN2_B6 ,
        CAN2_B13,
        CAN2_G12,
        #if defined(STM32F413_423xx)
            CAN3_A15,
            CAN3_B4
        #endif
    );
    
    STRONG_ENUM( CanRxPins,
        CAN1_A11,
        #if defined(STM32F412xG) || defined(STM32F413_423xx)
            CAN1_B8 ,
        #endif
        CAN1_D0 ,
        CAN2_B5 ,
        CAN2_B12,
        CAN2_G11,
        #if defined(STM32F413_423xx)
            CAN3_A8 ,
            CAN3_B3
        #endif
    );   
                
    
    
    enum CanNumbers
    {
    #ifdef CAN1_ENABLE 
        CAN_N1,
    #endif
    #ifdef CAN2_ENABLE 
        CAN_N2,
    #endif
    #ifdef CAN3_ENABLE 
        CAN_N3,
    #endif
        CAN_NUMBER
    };
    
    
    
    // структурищще для инициализации can
    struct CanInitStruct
    {
        uint32_t            baudRate = 0;               // бодрейт бит в сек 125000...500000
        CanTxPins           pinTx = CanTxPins::CAN1_A12;
        CanRxPins           pinRx = CanRxPins::CAN1_A11;
        CanMode             canMode = CanMode::NORMAL;    // режим CAN
        uint8_t             irqPriority = 0;            // приоритет прерываний 0-15
        uint8_t             sjw = 0;                    // коррекция длины бита 0-3
        FunctionalState     ttcim = DISABLE;            // вкл - 2 байта сообщения отражают время отправки
        FunctionalState     abom = DISABLE;             // вкл - автовыход из bus-off
        FunctionalState     awum = DISABLE;             // вкл - автовыход из sleep
        FunctionalState     nart = DISABLE;             // выкл - отправлять сообщение, пока не примется успешно 
        FunctionalState     rflm = DISABLE;             // вкл - перезапись сообщения при заполненных ФИФО приема. выкл - пропуск
        FunctionalState     txfp = DISABLE;             // приоритет отправки. вкл - по ID, выкл - по времени
    };
    
    

    class Handle : public ICan
    {
        public:
            
            // коньструктор
            Handle( CAN_TypeDef * hardwareCan ):
                m_rxBuffer( ),
                m_canPointer( hardwareCan )
            {
                m_rxBuffer.reset();
                
                if( ++counter() > CAN_NUMBER )
                {
                    // капец, слишком много хэндлов
                    UMBA_ASSERT_FAIL();
                }
            }


            virtual ~Handle() override
            {
                UMBA_ASSERT_FAIL();
            }


            // деактивация
            virtual void deInit(void) override;
            
            // инициализация простая
            ReturnState init( uint32_t baudRate, CanTxPins pinTx, CanRxPins pinRx,
                    can::FrameFormat frameFormat = can::FrameFormat::STANDART );
            
            // инициализация полная (вся структура в деле)
            ReturnState initExtended( CanInitStruct & initStruct,
                    can::FrameFormat frameFormat = can::FrameFormat::STANDART );
            
            // параметры фильров
            virtual void addFilter( const CanFilter & filterParams, const uint32_t num ) override;
            virtual uint32_t getFilterCapacity() const override
            {
                return max_num_of_rx_filters;
            }
            
            // передача
            virtual ReturnState transmitMessage( const CanMessage & msg ) override;
            
            // прием            
            virtual bool tryToReceive( CanMessage & msg ) override;
            
            // проверка инициализации
            virtual bool isInited(void) override;
        
            // обработчик прерываний - прием в фифо
            void canRxIrq( uint8_t canFifo, uint32_t canItFf, uint32_t canItFov, uint32_t canItFmp );
            
            // обработчик прерываний - передача свершилась
            void canTxIrq( void );
            
            // обработчик прерываний - какая-то ошибка
            void canErrIrq( void );
            
            // проверка на ошибку - не упало ли все
            virtual CanErr getErrorState( void ) override
            {
                return m_errState;
            }
          
            virtual void clearError( void ) override
            {
                m_errState = CanErr::NO_ERROR;
                m_lastErrCode = 0;
                
            }
            
            // раньше и этого не было, так что смысла большого нет
            virtual uint32_t getPlatformSpecificError( void ) override
            { 
                return m_lastErrCode;
            }
            
            virtual bool isReadyToTransmit( void ) override;
            virtual bool areAllTransmitsComplete( void ) override;
            
            // мьютекс
            virtual bool isLocked( void ) override;            
            virtual void lock( void ) override;
            virtual void unLock( void ) override;
               
        private:
            // константы, типы 
            
            // методы

            // копировать нельзя
            Handle(const Handle & that) = delete;

            // присваивать тоже нельзя
            Handle & operator=( Handle & that) = delete;
                  
            // отдельно вынесенный инит пинов
            void initGpio( CanTxPins pinTx, CanRxPins pinRx );
        
            // отдельно вынесенный инит прерываний
            ReturnState initIrq( uint8_t priority );
            
            // служебная функция для пересыпания данных из spl-структуры в единую для всех-всех-всех
            void copyMsg( CanMessage & destMsg, CanRxMsg & srcMsg );
            
            // для подсчета кол-ва экземпляров
            static uint8_t & counter(void)
            {
                static uint8_t count = 0; 
                return count; 
            }
            
            //  члены класса 
            
            // буфер рх
            BlockingCircularBuffer< CanMessage, rx_buffer_size > m_rxBuffer;
        
            // указатель на сам интерфейс
            CAN_TypeDef * m_canPointer;
        
            // вспомогательные шняги
            bool m_isInitDone = false; 

            // текущий бодрейт
            uint32_t m_baudRate = 0;
            
            // код последней ошибки для внутреннего пользования (соответствует кодам из spl) :
            //  CAN_ErrorCode_NoErr            /*!< No Error */ 
            //  CAN_ErrorCode_StuffErr         /*!< Stuff Error */ 
            //  CAN_ErrorCode_FormErr          /*!< Form Error */ 
            //  CAN_ErrorCode_ACKErr           /*!< Acknowledgment Error */ 
            //  CAN_ErrorCode_BitRecessiveErr  /*!< Bit Recessive Error */ 
            //  CAN_ErrorCode_BitDominantErr  /*!< Bit Dominant Error */ 
            //  CAN_ErrorCode_CRCErr           /*!< CRC Error  */ 
            //  CAN_ErrorCode_SoftwareSetErr   /*!< Software Set Error */
            uint8_t m_lastErrCode = 0;// CAN_ErrorCode_NoErr;
        
            // наличие ошибки
            CanErr m_errState = CanErr::NO_ERROR;
        
            // для потокобезопасности типа
            bool m_isLocked = false;

            uint32_t m_emptyBufferNum = max_num_of_rx_filters;
            can::FrameFormat m_frameFormat = can::FrameFormat::STANDART;
            
            // коды альтернативных функций в соответствии с пинами
            static constexpr auto codes_size = 
            5
#if defined(STM32F412xG) || defined(STM32F413_423xx)
            + 1 
#endif
#if defined(STM32F413_423xx)
            + 2
#endif
            ;
            
            
            uint8_t af_codes[ codes_size ] = 
            {
                GPIO_AF_CAN1,  
        #if defined(STM32F412xG) || defined(STM32F413_423xx)
                GPIO_AF8_CAN1, 
        #endif
                GPIO_AF_CAN1,  
                GPIO_AF_CAN2,
                GPIO_AF_CAN2,
                GPIO_AF_CAN2,
        #if defined(STM32F413_423xx)
                GPIO_AF11_CAN3,
                GPIO_AF11_CAN3
        #endif
            };
            
    };


    #ifdef CAN1_ENABLE
        extern Handle can1;
    #endif
    
    #ifdef CAN2_ENABLE
        extern Handle can2;
    #endif
    
    #ifdef CAN3_ENABLE
        extern Handle can3;
    #endif
    
}

#endif
