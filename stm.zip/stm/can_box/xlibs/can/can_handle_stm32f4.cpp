/***************************************************************************************************
    Файл классом can

    инициализируется, деинициализируется, отправляет, принимает
    
    для инициализации использовать функции init или initExtended, предварительно заполнив 
    структуру типа CanInitStruct (чуть-чуть для функции init и полностью для initExtended)
    после - настроить фильтрацию функциями setFilterMask, setFilterTwoIds или setFilterExtended
    
    для приема сообщений периодически вызывать tryToReceive
    
    для отправки использовать функцию transmitMessage
    
    если нужно все это пользовать в разных потоках - использовать isLocked, lock и unLock
    
    для сброса всего can использовать deInit
***************************************************************************************************/

#include "can_handle_stm32f4.h"

#ifdef UMBA_UNLOCK_CAN_CPP 

#if defined(STM32F4XX)       || defined(STM32F40_41xxx) || defined(STM32F427_437xx) || \
    defined(STM32F429_439xx) || defined(STM32F401xx)    || defined(STM32F410xx)     || \
    defined(STM32F411xE)     || defined(STM32F412xG)    || defined(STM32F413_423xx) || \
    defined(STM32F446xx)     || defined(STM32F469_479xx)


// ведро местных констант для битоебства с фильтрами
const uint32_t id_extended_mask_a = 0x00001FFF; // где в filterId лежит часть A
const uint32_t id_extended_mask_b = 0x1FFFE000; // где в filterId лежит часть B
const uint32_t id_extended_mask_a_filter = 0x0000FFF8;  // где в spl-структуре лежит часть A
const uint32_t id_extended_mask_b_filter = 0x0000FFFF;  // где в spl-структуре лежит часть B
const uint32_t id_extended_a_filter_shift = 3;  // сдвиг spl-структуры относительно filterId
const uint32_t id_extended_b_filter_shift = 13; // сдвиг spl-структуры относительно filterId

const uint32_t id_standard_mask = 0x07FF;   // где в filterId лежит ID
const uint32_t id_standard_mask_filter = 0xFFE0;    // где в spl-структуре лежит ID
const uint32_t id_standard_filter_shift = 5;    // сдвиг spl-структуры относительно filterId

//const uint32_t can_bus_speed = 36000000;    // скорость APB1 для правильного пересчета бодрейта
static uint32_t canBusSpeed = 0;

namespace can
{
    // железный can-1
    #ifdef CAN1_ENABLE
        Handle can1( CAN1 );
    #endif
    #ifdef CAN2_ENABLE
        Handle can2( CAN2 );
    #endif
    #ifdef CAN3_ENABLE
        Handle can3( CAN3 );
    #endif


// ведро методов
 

/***************************************************************************************************
    инициализация простая
    Аргументы:  baudRate - бодрейт бит в сек ...125000...500000...
                pinCan - выводы для CAN_RX
    Возврат:    OK - все хорошо
                ERROR - не хорошо
    Замечания:  если частота APB1 Fpclk1 не 36 MHz, поменять can_bus_speed
***************************************************************************************************/
    ReturnState Handle::init( uint32_t baudRate,  CanTxPins pinTx, CanRxPins pinRx , can::FrameFormat frameFormat )
    {
        // проверка входных данных
        if( ( baudRate > max_baud_rate ) ||
            ( baudRate < min_baud_rate ) )
        {
            m_isInitDone = false;
            return ReturnState::ERROR;
        }

        UMBA_ASSERT( m_canPointer != NULL );
        
        CanInitStruct initStruct;
        initStruct.baudRate = baudRate;
        initStruct.pinTx = pinTx;
        initStruct.pinRx = pinRx;
        initStruct.irqPriority = IRQ_PRIORITY_LEVEL_NORMAL;
        initStruct.canMode = CanMode::NORMAL;
        initStruct.sjw = CAN_SJW_1tq;
        initStruct.ttcim = DISABLE;
        initStruct.abom = ENABLE;
        initStruct.awum = DISABLE;
        initStruct.nart = DISABLE;
        initStruct.rflm = ENABLE;
        initStruct.txfp = ENABLE;
        
        return ( initExtended( initStruct, frameFormat ));
    }



/***************************************************************************************************
    инициализация полная
    Аргументы:  структура для инициализации.
                    initStruct.baudRate - бодрейт бит в сек 125000...500000
                    initStruct.pinTx, Rx - выводы для CAN
                    initStruct.irqPriority - приоритет прерываний 0-15
                    initStruct.canMode - режим CAN:
                        NORM - обычный
                        LOOPBACK - все, что отправляется, идет и на прием
                        SILENT - передача в линию не идет
                        SILENT_LOOPBACK - передача только самому себе
                    initStruct.sjw - коррекция длины бита. 0-3. Фактическая коррекция = sjw+1
                    initStruct.ttcim - ENABLE или DISABLE. вкл - последние 2 байта сообщения - время
                    initStruct.abom - ENABLE или DISABLE. вкл - автовыход из состояния bus-off
                    initStruct.awum - ENABLE или DISABLE. вкл - автовыход из состояния sleep
                    initStruct.nart - ENABLE или DISABLE. отключает автоповтор передачи при ошибке
                    initStruct.rflm - ENABLE или DISABLE. вкл - перезапись сообщения при 
                                        переполненном фифо приема. выкл - пропуск нового сообщения
                    initStruct.txfp - ENABLE или DISABLE. приоритет отправки. вкл - ID, выкл - время 
    Возврат:    OK - все хорошо
                ERROR - не хорошо
    Замечания:  если частота APB1 Fpclk1 не 36 MHz, вернет ERROR
***************************************************************************************************/
    ReturnState Handle::initExtended( CanInitStruct & initStruct, can::FrameFormat frameFormat )
    {
        // проверка входных данных
        if( ( initStruct.baudRate > max_baud_rate ) ||
            ( initStruct.baudRate < min_baud_rate ) ||
            ( initStruct.irqPriority > IRQ_PRIORITY_LEVEL_LOWEST ) ||
            ( initStruct.sjw > 3 ) )
        {
            m_isInitDone = false;
            return ReturnState::ERROR;
        }

        UMBA_ASSERT( m_canPointer != NULL );
        
        // проверить частоту тактирования
        RCC_ClocksTypeDef clocks;
        RCC_GetClocksFreq( & clocks );
        
        canBusSpeed = clocks.PCLK1_Frequency;

        // сбросить инициализацию старого кана
        CAN_DeInit( m_canPointer );
        m_isInitDone = false;
        m_baudRate = 0;
        
        // can - магия с разбирательством, где он на шине и какого номера
        if( m_canPointer == CAN1 )
        {
            RCC_APB1PeriphClockCmd( RCC_APB1Periph_CAN1, ENABLE ); 
        }
        else if( m_canPointer == CAN2 )
        {
            RCC_APB1PeriphClockCmd( RCC_APB1Periph_CAN1, ENABLE ); 
            RCC_APB1PeriphClockCmd( RCC_APB1Periph_CAN2, ENABLE );
        }
#if defined(STM32F413_423xx)
        else if( m_canPointer == CAN3 )
        {
            RCC_APB1PeriphClockCmd( RCC_APB1Periph_CAN3, ENABLE );
        }
#endif
        else
        {
            UMBA_ASSERT_FAIL();
            // дичь
        }
        
        // настройка выводов
        initGpio( initStruct.pinTx, initStruct.pinRx );       
        
        // can структура
        CAN_InitTypeDef CAN_InitStruct;
        
        if( initStruct.canMode == CanMode::NORMAL )
        {
            CAN_InitStruct.CAN_Mode = CAN_Mode_Normal;
        }
        else if( initStruct.canMode == CanMode::LOOPBACK )
        {
            CAN_InitStruct.CAN_Mode = CAN_Mode_LoopBack;
        }
        else if( initStruct.canMode == CanMode::SILENT )
        {
            CAN_InitStruct.CAN_Mode = CAN_Mode_Silent;
        }
        else if( initStruct.canMode == CanMode::SILENT_LOOPBACK )
        {
            CAN_InitStruct.CAN_Mode = CAN_Mode_Silent_LoopBack;
        }
        
        CAN_InitStruct.CAN_SJW = initStruct.sjw;
        CAN_InitStruct.CAN_TTCM = initStruct.ttcim;        
        CAN_InitStruct.CAN_ABOM = initStruct.abom;       
        CAN_InitStruct.CAN_AWUM = initStruct.awum;        
        CAN_InitStruct.CAN_NART = initStruct.nart;        
        CAN_InitStruct.CAN_RFLM = initStruct.rflm;        
        CAN_InitStruct.CAN_TXFP = initStruct.txfp;        
        
        // бодрейт
        // CAN_InitStruct->CAN_Prescaler = (0..1023) - длина кванта Tquant = (CAN_Prescaler + 1) * Tpclk
        // реально используемый бодрейт 125-500 кбит
        // длина бита 12 квантов ( BS1+BS2+1 )
        // CAN_BS1_xtq на 1 меньше, чем x, потому в пересчете надо добавлять еще по 1 за BS1 и BS2
        CAN_InitStruct.CAN_BS1 = CAN_BS1_8tq; // сколько квантов до взятия значения и после
        CAN_InitStruct.CAN_BS2 = CAN_BS2_3tq; // рекомендуется иметь BS1 больше BS2 раза в 2-3
        // presc = canBusSpeed / ( baudRate * ( BS1+BS2+1 ) )
        CAN_InitStruct.CAN_Prescaler = canBusSpeed / ( initStruct.baudRate * (CAN_InitStruct.CAN_BS1+CAN_InitStruct.CAN_BS2+3) );
        m_baudRate = initStruct.baudRate;

        if( CAN_Init( m_canPointer, &CAN_InitStruct) == CAN_InitStatus_Failed )
        {
            // случилась какая-то хуйня и настройки не залились
            m_canPointer = NULL;
            m_isInitDone = false;
            m_baudRate = 0;
            return ReturnState::ERROR;
        }
     
        // настройка прерывания
        initIrq( initStruct.irqPriority );
        
        m_rxBuffer.reset();   // сброс буфера приема
        
        m_frameFormat = frameFormat;
 
        m_isInitDone = true;
        return ReturnState::OK;
    }
    
    
    void Handle::addFilter( const CanFilter & filterParams, const uint32_t num )
    {
        UMBA_ASSERT( isInited() );
        UMBA_ASSERT( num < max_num_of_rx_filters );
        
        
        CAN_FilterInitTypeDef filterStruct;
        filterStruct.CAN_FilterActivation = ENABLE;
        filterStruct.CAN_FilterFIFOAssignment = CAN_FIFO0;
        filterStruct.CAN_FilterNumber = num;
        filterStruct.CAN_FilterMode = CAN_FilterMode_IdMask;
        filterStruct.CAN_FilterScale = CAN_FilterScale_32bit;
                
        if( m_frameFormat == can::FrameFormat::STANDART )
        {
            // IDE и RTR не проверяем
            filterStruct.CAN_FilterIdHigh = ( (filterParams.filter & id_standard_mask) << id_standard_filter_shift) & id_standard_mask_filter;
            filterStruct.CAN_FilterIdLow = 0;
            filterStruct.CAN_FilterMaskIdHigh = ( (filterParams.mask & id_standard_mask) << id_standard_filter_shift) & id_standard_mask_filter;
            filterStruct.CAN_FilterMaskIdLow = 0;
        }
        else
        {
            // IDE и RTR не проверяем
            filterStruct.CAN_FilterIdHigh = ( (filterParams.filter & id_extended_mask_b) >> id_extended_b_filter_shift ) & id_extended_mask_b_filter;
            filterStruct.CAN_FilterIdLow = ( (filterParams.filter & id_extended_mask_a) << id_extended_a_filter_shift ) & id_extended_mask_a_filter;
            filterStruct.CAN_FilterMaskIdHigh = ( (filterParams.mask & id_extended_mask_b) >> id_extended_b_filter_shift ) & id_extended_mask_b_filter;
            filterStruct.CAN_FilterMaskIdLow = ( (filterParams.mask & id_extended_mask_a) << id_extended_a_filter_shift ) & id_extended_mask_a_filter;
        }

        auto initFilter = []( CAN_TypeDef * CANx, CAN_FilterInitTypeDef * CAN_FilterInitStruct ) -> void
        {
            #if defined(STM32F413_423xx)
                CAN_FilterInit( CANx, CAN_FilterInitStruct );
            #else
                (void)CANx;
                CAN_FilterInit( CAN_FilterInitStruct );
            #endif
        };

        #ifdef ENABLE_CAN2
        // второй кан на stm32f4 делит фильтры с первым, поэтому требуется задавать фильтры 1 кану
        if( m_canPointer == CAN2 )
        {
            static constexpr auto can2_filter_shift = 14;
            filterStruct.CAN_FilterNumber = num + can2_filter_shift;

            initFilter( CAN1, & filterStruct );
            return;
        }
        #endif
        initFilter( m_canPointer, & filterStruct );

        
    }    

/***************************************************************************************************
    прерывание, обрабатывает события приема в фифо
    Аргументы:  canFifo - CAN_FIFO0 или CAN_FIFO1
                canItFf - CAN_IT_FF0 или CAN_IT_FF1 
                canItFov - CAN_IT_FOV0 или CAN_IT_FOV1
                canItFmp - CAN_IT_FMP0 или CAN_IT_FMP1
    Возврат: -
    Замечания: если буфер приема забился, то поднимается m_errState = CanErr::RX_OVERFLOW и
               сообщение тогда потеряется
               если попали сюда без инициализации can, то все останавливается
***************************************************************************************************/    
    void Handle::canRxIrq( uint8_t canFifo, uint32_t canItFf, uint32_t canItFov, uint32_t canItFmp )
    {  
         // прерывание приема
        
        if( isInited() == false )
        {
            // если не инициализировано, то какого хрена вообще произошло?
            UMBA_ASSERT_FAIL();
        }
                
        // сначала проверить на заполнение фифо до краев       
        if( ( CAN_GetITStatus( m_canPointer, canItFf )  == SET ) ||   // FIFO полон?
            ( CAN_GetITStatus( m_canPointer, canItFov ) == SET ) )    // FIFO переполнен?
        {
            // фифо-0 полон
            // или даже переполнен
            // разгрести все
            
            // взять кол-во сообщений в фифо-0
            uint8_t messagesPending = CAN_MessagePending( m_canPointer, canFifo);     
            CanMessage currentMessage;
            CanRxMsg RxMessage;            
            
            for(int i = 0; i < messagesPending; i++ )
            {               
                if( m_rxBuffer.isFull() == false )  // есть ли место в буфере для приема?
                {
                    CAN_Receive( m_canPointer, canFifo, &RxMessage ); // принять сообщение, отпустить мэйлбокс 
                                                                        // заодно скидывает прерывание приема 
                    copyMsg( currentMessage, RxMessage );               // копировать
                    m_rxBuffer.writeHead( currentMessage );             // погрузить в кольцевой буфер
                }
                else
                {
                    // охренеть, забился весь кольцевой буфер!
                    m_errState = CanErr::RX_OVERFLOW;
                    break;
                }
            }
            
            CAN_ClearITPendingBit( m_canPointer, canItFf ); // скинуть прерывания переполнения и заполнения
            CAN_ClearITPendingBit( m_canPointer, canItFov );
        }
        
        // если не полон до краев, то проверить на наличие там хоть чего
        if( CAN_GetITStatus( m_canPointer, canItFmp ) == SET )   // FIFO не пустой?
        {
            // чот принялось в фифо
            CanRxMsg RxMessage;
            CAN_Receive( m_canPointer, canFifo, &RxMessage ); // принять сообщение, заодно скидывает прерывание приема
                
            if( m_rxBuffer.isFull() == false )  // есть ли место в буфере для приема?
            {
                CanMessage currentMessage;
                copyMsg( currentMessage, RxMessage );
                m_rxBuffer.writeHead( currentMessage ); // погрузить в кольцевой буфер
            }
            else
            {
                // охренеть, забился весь кольцевой буфер!
                m_errState = CanErr::RX_OVERFLOW;
            }

        }
    }
    
    
    
/***************************************************************************************************
    прерывание, обрабатывает события окончания передачи
    Аргументы: -
    Возврат: -
    Замечания: если попали сюда без инициализации can, то все останавливается
***************************************************************************************************/    
    void Handle::canTxIrq( void )
    {  
        if( isInited() == false )
        {
            // если не инициализировано, то какого хрена вообще произошло?
            UMBA_ASSERT_FAIL();
        }
        
        m_canPointer->TSR = CAN_TSR_RQCP0 | CAN_TSR_RQCP1 | CAN_TSR_RQCP2; // сбросить флаг прерывания
    }
    
    
    
/***************************************************************************************************
    прерывание, обрабатывает события ошибок
    Аргументы: -
    Возврат: -
    Замечания: если попали сюда без инициализации can, то все останавливается
***************************************************************************************************/    
    void Handle::canErrIrq( void )
    {  
        if( isInited() == false )
        {
            // если не инициализировано, то какого хрена вообще произошло?
            UMBA_ASSERT_FAIL();
        }
        
        // посмотреть, что произошло, и отреагировать        
        if( (m_canPointer->MSR & CAN_MSR_ERRI) != 0 )
        {
            // прерывание  - какая-то ошибка, считать код и подумать
            m_lastErrCode = CAN_GetLastErrorCode( m_canPointer );
            
            if( (m_canPointer->ESR & CAN_ESR_BOFF) != 0 ) 
            {
                // все сильно упало
                // ошибки бодрейта
                m_errState = CanErr::BUS_OFF;
            }
            else if( (m_canPointer->ESR & CAN_ESR_EPVF) != 0 )
            {
                // ошибок еще не достаточно для полного провала
                m_errState = CanErr::PASSIVE;
            }
            else
            {
                // посмотреть подробнее
                if( ( m_lastErrCode == CAN_ErrorCode_StuffErr ) ||
                    ( m_lastErrCode == CAN_ErrorCode_FormErr ) || 
                    ( m_lastErrCode == CAN_ErrorCode_ACKErr ) )
                {
                    // вероятно, неправильный бодрейт
                    m_canPointer->TSR |= CAN_TSR_ABRQ0 | CAN_TSR_ABRQ1 | CAN_TSR_ABRQ2; // отменить все передачи
                    m_errState = CanErr::BAUDRATE;
                }
 
            }

            // скинуть флаги ошибок
            m_canPointer->ESR = RESET;
            m_canPointer->MSR = CAN_MSR_ERRI;
        }
    }
    
    
    
/***************************************************************************************************
    начать передачу
    Аргументы:  messageID - 11 или 29 бит ID
                frameFormat - STANDART или EXTENDED
                data - до 8 байт данных
                dataLen - длина буфера данных
    Возврат:    OK - отправлено
                TX_BUSY - все буфера для отпарвки заняты, не отправлено
                ERROR - косяк с данными, не отправлено
    Замечания:
***************************************************************************************************/    
    ReturnState Handle::transmitMessage( const CanMessage & msg )
    {
        if( ( isInited() == false ) ||
            ( msg.length > msg_len_max) ||
            ( getErrorState() == CanErr::BUS_OFF ) )
        {
            // не инициализирован can или размер неправильный или шина упала
            return ReturnState::ERROR;
        }
        
        CanTxMsg message;
        if( msg.frameFormat == FrameFormat::STANDART )
        {
            message.IDE = CAN_Id_Standard;
            message.StdId = msg.id & 0x07FF;
        }
        else if( msg.frameFormat == FrameFormat::EXTENDED )
        {
            message.IDE = CAN_Id_Extended;
            message.ExtId = msg.id & 0x1FFFFFFF;
        }
        else
        {
            // какая-то дичь
            return ReturnState::ERROR;
        }
        
        if( msg.type == MsgType::DATA )
        {
            message.RTR = CAN_RTR_Data;
        }
        else if( msg.type == MsgType::REQ )
        {
            message.RTR = CAN_RTR_Remote;
        }
        else
        {
            return ReturnState::ERROR;
        }
        
        message.DLC = msg.length;
        
        std::copy( msg.data, msg.data + message.DLC, message.Data);
        
        if( CAN_Transmit( m_canPointer, &message ) == CAN_TxStatus_NoMailBox )
        {
            // не отправилось
            return ReturnState::TX_BUSY;
        }
        
        return ReturnState::OK;
    }



/***************************************************************************************************
    проверить приемный буфер, если там есть сообщение - получить его в message
    Аргументы:  msg - ссыль на принятое сообщение
    Возврат:    true - принято, лежит в message
                false - не было ничего принято
    Замечания:
***************************************************************************************************/    
    bool Handle::tryToReceive( CanMessage & msg )
    {

        if( ( isInited() == false ) ||
            ( getErrorState() == CanErr::BUS_OFF) )
        {
            return false;
        }
        
        if( m_rxBuffer.isEmpty() == true )
        {
            // буфер пустой
            return false;
        }
        else
        {
            // в буфере чот есть, забрать
            msg = m_rxBuffer.readTail();
            return true;
        }
    }
    
    
    
/***************************************************************************************************
    сброс инициализации can
    Аргументы:  
    Возврат:    
    Замечания: режим выводов не меняет
***************************************************************************************************/    
    void Handle::deInit( void )
    {
        CAN_DeInit( m_canPointer );
        m_isInitDone = false;
    }
    
    

/***************************************************************************************************
    проверка на инициализованность
    Аргументы:  
    Возврат:    true - инициализация была
                false - инициализации не было
    Замечания: если m_canPointer == NULL, то капец, залипнуть
***************************************************************************************************/    
    bool Handle::isInited( void )
    {
        // на случай странных вещей проверять указатель
        UMBA_ASSERT( m_canPointer != NULL );

        return m_isInitDone;
    }
    
    

/***************************************************************************************************
    инициализация пинов для can
    Аргументы: pinCan - enum, выбирающий выводы   
    Возврат:
    Замечания:
***************************************************************************************************/    
    void Handle::initGpio( CanTxPins pinTx, CanRxPins pinRx )
    {
        struct PinInitStruct
        {
            void ( * rccInit )( uint32_t, FunctionalState );
            uint32_t rccNum;
            uint16_t pinNum;
            uint16_t pinSource;
            GPIO_TypeDef * pinPort;
            uint8_t af;
        };
        
        PinInitStruct Tx;
        PinInitStruct Rx;
        
        switch( pinTx )
        {
            case CanTxPins::CAN1_A12:
            {
                Tx.rccInit = RCC_AHB1PeriphClockCmd;
                Tx.rccNum = RCC_AHB1Periph_GPIOA;
                Tx.pinNum = GPIO_Pin_12;
                Tx.pinSource = GPIO_PinSource12;
                Tx.pinPort = GPIOA;
                Tx.af = af_codes[ (uint8_t)(CanTxPins::CAN1_A12) ];
                
                break;
            }            
#if defined(STM32F412xG) || defined(STM32F413_423xx)
            case CanTxPins::CAN1_B9:
            {
                Tx.rccInit = RCC_AHB1PeriphClockCmd;
                Tx.rccNum = RCC_AHB1Periph_GPIOB;
                Tx.pinNum = GPIO_Pin_9;
                Tx.pinSource = GPIO_PinSource9;
                Tx.pinPort = GPIOB;
                Tx.af = af_codes[ (uint8_t)(CanTxPins::CAN1_B9) ];
                
                break;
            }                
#endif
            case CanTxPins::CAN1_D1:
            {
                Tx.rccInit = RCC_AHB1PeriphClockCmd;
                Tx.rccNum = RCC_AHB1Periph_GPIOD;
                Tx.pinNum = GPIO_Pin_1;
                Tx.pinSource = GPIO_PinSource1;
                Tx.pinPort = GPIOD;
                Tx.af = af_codes[ (uint8_t)(CanTxPins::CAN1_D1) ];
                
                break;
            }
            
            case CanTxPins::CAN2_B6:
            {
                Tx.rccInit = RCC_AHB1PeriphClockCmd;
                Tx.rccNum = RCC_AHB1Periph_GPIOB;
                Tx.pinNum = GPIO_Pin_6;
                Tx.pinSource = GPIO_PinSource6;
                Tx.pinPort = GPIOB;
                Tx.af = af_codes[ (uint8_t)(CanTxPins::CAN2_B6) ];

                break;
            }

            case CanTxPins::CAN2_B13:
            {
                Tx.rccInit = RCC_AHB1PeriphClockCmd;
                Tx.rccNum = RCC_AHB1Periph_GPIOB;
                Tx.pinNum = GPIO_Pin_13;
                Tx.pinSource = GPIO_PinSource13;
                Tx.pinPort = GPIOB;
                Tx.af = af_codes[ (uint8_t)(CanTxPins::CAN2_B13) ];
                
                break;
            }
            
            case CanTxPins::CAN2_G12:
            {
                Tx.rccInit = RCC_AHB1PeriphClockCmd;
                Tx.rccNum = RCC_AHB1Periph_GPIOG;
                Tx.pinNum = GPIO_Pin_12;
                Tx.pinSource = GPIO_PinSource12;
                Tx.pinPort = GPIOG;
                Tx.af = af_codes[ (uint8_t)(CanTxPins::CAN2_G12) ];
                
                break;
            }
            
#if defined(STM32F413_423xx)
            case CanTxPins::CAN3_A15:
            {
                Tx.rccInit = RCC_AHB1PeriphClockCmd;
                Tx.rccNum = RCC_AHB1Periph_GPIOA;
                Tx.pinNum = GPIO_Pin_15;
                Tx.pinSource = GPIO_PinSource15;
                Tx.pinPort = GPIOA;
                Tx.af = af_codes[ (uint8_t)(CanTxPins::CAN3_A15) ];
                
                break;
            }
            case CanTxPins::CAN3_B4:
            {
                Tx.rccInit = RCC_AHB1PeriphClockCmd;
                Tx.rccNum = RCC_AHB1Periph_GPIOB;
                Tx.pinNum = GPIO_Pin_4;
                Tx.pinSource = GPIO_PinSource4;
                Tx.pinPort = GPIOB;
                Tx.af = af_codes[ (uint8_t)(CanTxPins::CAN3_B4) ];
                
                break;
            }
#endif
            default:
            {
                // магия?
                UMBA_ASSERT_FAIL();
            }
        }
        
        switch( pinRx )
        {
            case CanRxPins::CAN1_A11:
            {
                Rx.rccInit = RCC_AHB1PeriphClockCmd;
                Rx.rccNum = RCC_AHB1Periph_GPIOA;
                Rx.pinNum = GPIO_Pin_11;
                Rx.pinSource = GPIO_PinSource11;
                Rx.pinPort = GPIOA;
                Rx.af = af_codes[ (uint8_t)(CanRxPins::CAN1_A11) ];
                
                break;
            }            
#if defined(STM32F412xG) || defined(STM32F413_423xx)
            case CanRxPins::CAN1_B8:
            {
                Rx.rccInit = RCC_AHB1PeriphClockCmd;
                Rx.rccNum = RCC_AHB1Periph_GPIOB;
                Rx.pinNum = GPIO_Pin_8;
                Rx.pinSource = GPIO_PinSource8;
                Rx.pinPort = GPIOB;
                Rx.af = af_codes[ (uint8_t)(CanRxPins::CAN1_B8) ];
                
                break;
            }                
#endif
            case CanRxPins::CAN1_D0:
            {
                Rx.rccInit = RCC_AHB1PeriphClockCmd;
                Rx.rccNum = RCC_AHB1Periph_GPIOD;
                Rx.pinNum = GPIO_Pin_0;
                Rx.pinSource = GPIO_PinSource0;
                Rx.pinPort = GPIOD;
                Rx.af = af_codes[ (uint8_t)(CanRxPins::CAN1_D0) ];
                
                break;
            }
            
            case CanRxPins::CAN2_B5:
            {
                Rx.rccInit = RCC_AHB1PeriphClockCmd;
                Rx.rccNum = RCC_AHB1Periph_GPIOB;
                Rx.pinNum = GPIO_Pin_5;
                Rx.pinSource = GPIO_PinSource5;
                Rx.pinPort = GPIOB;
                Rx.af = af_codes[ (uint8_t)(CanRxPins::CAN2_B5) ];

                break;
            }

            case CanRxPins::CAN2_B12:
            {
                Rx.rccInit = RCC_AHB1PeriphClockCmd;
                Rx.rccNum = RCC_AHB1Periph_GPIOB;
                Rx.pinNum = GPIO_Pin_12;
                Rx.pinSource = GPIO_PinSource12;
                Rx.pinPort = GPIOB;
                Rx.af = af_codes[ (uint8_t)(CanRxPins::CAN2_B12) ];
                
                break;
            }
            
            case CanRxPins::CAN2_G11:
            {
                Rx.rccInit = RCC_AHB1PeriphClockCmd;
                Rx.rccNum = RCC_AHB1Periph_GPIOG;
                Rx.pinNum = GPIO_Pin_11;
                Rx.pinSource = GPIO_PinSource11;
                Rx.pinPort = GPIOG;
                Rx.af = af_codes[ (uint8_t)(CanRxPins::CAN2_G11) ];
                
                break;
            }
            
#if defined(STM32F413_423xx)
            case CanRxPins::CAN3_A8:
            {
                Rx.rccInit = RCC_AHB1PeriphClockCmd;
                Rx.rccNum = RCC_AHB1Periph_GPIOA;
                Rx.pinNum = GPIO_Pin_8;
                Rx.pinSource = GPIO_PinSource8;
                Rx.pinPort = GPIOA;
                Rx.af = af_codes[ (uint8_t)(CanRxPins::CAN3_A8) ];
                
                break;
            }
            case CanRxPins::CAN3_B3:
            {
                Rx.rccInit = RCC_AHB1PeriphClockCmd;
                Rx.rccNum = RCC_AHB1Periph_GPIOB;
                Rx.pinNum = GPIO_Pin_3;
                Rx.pinSource = GPIO_PinSource3;
                Rx.pinPort = GPIOB;
                Rx.af = af_codes[ (uint8_t)(CanRxPins::CAN3_B3) ];
                
                break;
            }
#endif
            default:
            {
                // магия?
                UMBA_ASSERT_FAIL();
            }
        }
        
        Tx.rccInit( Tx.rccNum, ENABLE );
    
        GPIO_InitTypeDef GPIO_InitStruct;
        GPIO_InitStruct.GPIO_Pin = Tx.pinNum;
        GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
        GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_UP;

        GPIO_Init( Tx.pinPort, &GPIO_InitStruct );
        GPIO_PinAFConfig( Tx.pinPort, Tx.pinSource, Tx.af );

    
        Rx.rccInit( Rx.rccNum, ENABLE );
    
        GPIO_InitStruct.GPIO_Pin = Rx.pinNum;
        GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
        GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_UP;
        GPIO_Init( Rx.pinPort, &GPIO_InitStruct );

        GPIO_PinAFConfig( Rx.pinPort, Rx.pinSource, Rx.af );

        
    }
    
    

/***************************************************************************************************
    инициализация прерывания для can
    Аргументы: priority - 0-15 приоритетность прерываний   
    Возврат:    OK - все хорошо
                ERROR - не хорошо
    Замечания:
***************************************************************************************************/    
    ReturnState Handle::initIrq( uint8_t priority)
    {
        if( priority > IRQ_PRIORITY_LEVEL_LOWEST )
        {
            return ReturnState::ERROR;
        }
        
        
        CAN_ITConfig( m_canPointer, CAN_IT_TME, ENABLE);  // вкл прерывание "пустой буфер передачи"    
        // фифо-0
        CAN_ITConfig( m_canPointer, CAN_IT_FMP0, ENABLE);  // вкл прерывание "фифо-0 сообщение есть"
        CAN_ITConfig( m_canPointer, CAN_IT_FF0, ENABLE);  // вкл прерывание "фифо-0 полный"        
        CAN_ITConfig( m_canPointer, CAN_IT_FOV0, ENABLE);  // вкл прерывание "фифо-0 переполнение"        
        // фифо-1
        CAN_ITConfig( m_canPointer, CAN_IT_FMP1, ENABLE);  // вкл прерывание "фифо-1 сообщение есть"
        CAN_ITConfig( m_canPointer, CAN_IT_FF1, ENABLE);  // вкл прерывание "фифо-1 полный"
        CAN_ITConfig( m_canPointer, CAN_IT_FOV1, ENABLE);  // вкл прерывание "фифо-1 переполнение"       
        // всяческие ошибки
        CAN_ITConfig( m_canPointer, CAN_IT_EWG, ENABLE);   /*!< Error warning Interrupt*/
        CAN_ITConfig( m_canPointer, CAN_IT_EPV, ENABLE);   /*!< Error passive Interrupt*/
        CAN_ITConfig( m_canPointer, CAN_IT_BOF, ENABLE);   /*!< Bus-off Interrupt*/
        CAN_ITConfig( m_canPointer, CAN_IT_LEC, ENABLE);   /*!< Last error code Interrupt*/
        CAN_ITConfig( m_canPointer, CAN_IT_ERR, ENABLE);   /*!< Error Interrupt*/

        struct CanIrqStruct
        {
            uint8_t txIrq;
            uint8_t rx0Irq;
            uint8_t rx1Irq;
            uint8_t sceIrq;
        };
        CanIrqStruct irq;

        #ifdef ENABLE_CAN1

        if( m_canPointer == CAN1 )
        {
            irq.rx0Irq = CAN1_RX0_IRQn;
            irq.rx1Irq = CAN1_RX1_IRQn;
            irq.txIrq  = CAN1_TX_IRQn;
            irq.sceIrq = CAN1_SCE_IRQn;
        }
        else 
        #endif
        
        #ifdef ENABLE_CAN2
        if( m_canPointer ==  CAN2 )

        {
            irq.rx0Irq = CAN2_RX0_IRQn;
            irq.rx1Irq = CAN2_RX1_IRQn;
            irq.txIrq  = CAN2_TX_IRQn;
            irq.sceIrq = CAN2_SCE_IRQn;
        }
        else 
        #endif
        
        #ifdef ENABLE_CAN3
        if( m_canPointer ==  CAN3 )
        {
            irq.rx0Irq = CAN3_RX0_IRQn;
            irq.rx1Irq = CAN3_RX1_IRQn;
            irq.txIrq  = CAN3_TX_IRQn;
            irq.sceIrq = CAN3_SCE_IRQn;
        }
        else
            
        #endif

        {
            UMBA_ASSERT_FAIL();
        }
    
        
        NVIC_InitTypeDef canNVIC;
        canNVIC.NVIC_IRQChannel = irq.rx0Irq;
        canNVIC.NVIC_IRQChannelPreemptionPriority = priority;  
        canNVIC.NVIC_IRQChannelSubPriority = 0;
        canNVIC.NVIC_IRQChannelCmd = ENABLE;
        NVIC_Init( &canNVIC );
        
        canNVIC.NVIC_IRQChannel = irq.rx1Irq;
        canNVIC.NVIC_IRQChannelPreemptionPriority = priority;  
        canNVIC.NVIC_IRQChannelSubPriority = 0;
        canNVIC.NVIC_IRQChannelCmd = ENABLE;
        NVIC_Init( &canNVIC );
        
        canNVIC.NVIC_IRQChannel = irq.txIrq;
        canNVIC.NVIC_IRQChannelPreemptionPriority = priority;  
        canNVIC.NVIC_IRQChannelSubPriority = 0;
        canNVIC.NVIC_IRQChannelCmd = ENABLE;
        NVIC_Init( &canNVIC );
        
        canNVIC.NVIC_IRQChannel = irq.sceIrq;
        canNVIC.NVIC_IRQChannelPreemptionPriority = priority;  
        canNVIC.NVIC_IRQChannelSubPriority = 0;
        canNVIC.NVIC_IRQChannelCmd = ENABLE;
        NVIC_Init( &canNVIC );
        
        return ReturnState::OK;
    }

    
    // "мьютекс" на владение
    bool Handle::isLocked(void)
    {
        UMBA_ASSERT(m_isInitDone);

        return m_isLocked;
    }

    void Handle::lock(void)
    {
        UMBA_ASSERT(m_isInitDone);

        m_isLocked = true;
    }

    void Handle::unLock(void)
    {
        UMBA_ASSERT(m_isInitDone);

        m_isLocked = false;
    }
    
    
    
/***************************************************************************************************
    копирование сообщения из структуры из spl в другую универсальную
    Аргументы:  destMsg - куда копировать
                srcMsg - откуда копировать
    Возврат: -
    Замечания:
***************************************************************************************************/    
    void Handle::copyMsg( CanMessage &destMsg, CanRxMsg &srcMsg )
    {
        // копировать
        if( srcMsg.IDE == CAN_Id_Standard )
        {
            destMsg.id = srcMsg.StdId;
            destMsg.frameFormat = FrameFormat::STANDART;
        }
        else
        {
            destMsg.id = srcMsg.ExtId;
            destMsg.frameFormat = FrameFormat::EXTENDED;
        }
        
        if( srcMsg.RTR == CAN_RTR_Data )
        {
            destMsg.type = MsgType::DATA;
        }
        else
        {
            destMsg.type = MsgType::REQ;
        }           
         
        destMsg.length = srcMsg.DLC;

        std::copy( srcMsg.Data, srcMsg.Data + destMsg.length, destMsg.data );
    }
    
    
    
/***************************************************************************************************
    проверка на готовность передавать
    Аргументы:  -
    Возврат: true - есть свободные мэйлбоксы на передачу
             false - нет таковых
    Замечания:
***************************************************************************************************/    
    bool Handle::isReadyToTransmit( void )
    {
        if( isInited() == false )
        {
            return false;
        }
        
        if( ( m_canPointer->TSR & CAN_TSR_TME ) != 0 )
        {
            return true;
        }
       
        return false;
    }



/***************************************************************************************************
    проверяет, завершены ли все передачи
    Аргументы:  -
    Возврат: true - ничего не передается
             false - что-то все еще передается
    Замечания:
***************************************************************************************************/
    bool Handle::areAllTransmitsComplete( void )
    {
        if( isInited() == false )
        {
            return false;
        }

        if( ( m_canPointer->TSR & CAN_TSR_TME ) == CAN_TSR_TME )
        {
            return true;
        }

        return false;
    }
}



/***************************************************************************************************
  Перехват обработчиков прерываний
***************************************************************************************************/
                
extern "C"
{
    #ifdef CAN1_ENABLE    
        // захватить все, что связано с CAN1

        void CAN1_RX1_IRQHandler( void )
        {
            can::can1.canRxIrq( CAN_FIFO1, CAN_IT_FF1, CAN_IT_FOV1, CAN_IT_FMP1 );
        }
        
        void CAN1_RX0_IRQHandler( void )
        {   
//            if( ( CAN_GetITStatus( CAN1, CAN_IT_FF0 )  == SET ) || 
//                ( CAN_GetITStatus( CAN1, CAN_IT_FOV0 ) == SET ) ||
//                ( CAN_GetITStatus( CAN1, CAN_IT_FMP0 ) == SET ) )
//            {
                // это таки CAN1
                // здесь он проверяется напрямую, ибо прерывание может происходить только от него или USB
                can::can1.canRxIrq( CAN_FIFO0, CAN_IT_FF0, CAN_IT_FOV0, CAN_IT_FMP0 );
//            }
        }
        
        void CAN1_SCE_IRQHandler( void )
        {
            can::can1.canErrIrq();
        }
        
        void CAN1_TX_IRQHandler( void )
        {
        
            if( CAN_GetITStatus( CAN1, CAN_IT_TME )  == SET )
            {
                // это таки CAN1
                can::can1.canTxIrq();
            }
        }
    #endif

    #ifdef CAN2_ENABLE
        // захватить все, что связано с CAN2
        void CAN2_RX1_IRQHandler( void )
        {
            can::can2.canRxIrq( CAN_FIFO1, CAN_IT_FF1, CAN_IT_FOV1, CAN_IT_FMP1 );
        }

        void CAN2_RX0_IRQHandler( void )
        {
            can::can2.canRxIrq( CAN_FIFO0, CAN_IT_FF0, CAN_IT_FOV0, CAN_IT_FMP0 );
        }

        void CAN2_SCE_IRQHandler( void )
        {
            can::can2.canErrIrq();
        }

        void CAN2_TX_IRQHandler( void )
        {

            if( CAN_GetITStatus( CAN2, CAN_IT_TME )  == SET )
            {
                can::can2.canTxIrq();
            }
        }
    #endif

    #ifdef CAN3_ENABLE

        void CAN3_RX1_IRQHandler( void )
        {
            can::can3.canRxIrq( CAN_FIFO1, CAN_IT_FF1, CAN_IT_FOV1, CAN_IT_FMP1 );
        }

        void CAN3_RX0_IRQHandler( void )
        {
            can::can3.canRxIrq( CAN_FIFO0, CAN_IT_FF0, CAN_IT_FOV0, CAN_IT_FMP0 );
        }

        void CAN3_SCE_IRQHandler( void )
        {
            can::can3.canErrIrq();
        }

        void CAN3_TX_IRQHandler( void )
        {

            if( CAN_GetITStatus( CAN3, CAN_IT_TME )  == SET )
            {
                can::can3.canTxIrq();
            }
        }
    #endif
}

#endif 

#endif
