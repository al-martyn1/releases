#pragma once

#if defined (STM32F303xC) || defined (STM32F334x8) || defined (STM32F302x8) || defined (STM32F303xE)

#include "circular_buffer/blocking_circular_buffer.h"
#include "i_can.h"
#include "can_config.h"




namespace can
{       
    const uint32_t max_baud_rate = 500000;      // бит в сек - предельный бодрейт can
    
    const uint32_t min_baud_rate = 3000;        // бит в сек - предельный бодрейт can

    const uint8_t num_of_rx_fifo = 2;           // кол-во фифо приемных

    const uint8_t max_num_of_rx_filters = 14;   // предельное кол-во фильтров при использовании 32 бит    


    
    // выбор GPIO
    STRONG_ENUM(    CanPins,
                    A11_A12,   // есть у всех STM32F103x8 и STM32F103xB
                    D0_D1,     // есть у qfpn36 lqfp100 tfbga64 ufbg100
                    B8_B9     // все кроме qfn36
                );   
    
    
    
    enum CanNumbers
    {
    #ifdef CAN1_ENABLE 
        CAN_N1,
    #endif
        CAN_NUMBER
    };
    
    
    
    // структурищще для инициализации can
    struct CanInitStruct
    {
        uint32_t            baudRate = 0;               // бодрейт бит в сек 125000...500000
        CanPins             pinCan = CanPins::A11_A12;  // выводы для CAN
        CanMode             canMode = CanMode::NORMAL;    // режим CAN
        uint8_t             irqPriority = 0;            // приоритет прерываний 0-15
        uint8_t             sjw = 0;                    // коррекция длины бита 0-3
        FunctionalState     ttcim = DISABLE;            // вкл - 2 байта сообщения отражают время отправки
        FunctionalState     abom = DISABLE;             // вкл - автовыход из bus-off
        FunctionalState     awum = DISABLE;             // вкл - автовыход из sleep
        FunctionalState     nart = DISABLE;             // выкл - отправлять сообщение, пока не примется успешно 
        FunctionalState     rflm = DISABLE;             // вкл - перезапись сообщения при заполненных ФИФО приема. выкл - пропуск
        FunctionalState     txfp = DISABLE;             // приоритет отправки. вкл - по ID, выкл - по времени
    };
    
    

    class Handle : public ICan
    {
        public:
            
            // коньструктор
            Handle( CAN_TypeDef * hardwareCan ):
                m_rxBuffer( ),
                m_canPointer( hardwareCan )
            {
                m_rxBuffer.reset();
                
                if( ++counter() > CAN_NUMBER )
                {
                    // капец, слишком много хэндлов
                    UMBA_ASSERT_FAIL();
                }
            }


            virtual ~Handle() override
            {
                UMBA_ASSERT_FAIL();
            }


            // деактивация
            virtual void deInit(void) override;
            
            // инициализация простая
            ReturnState init( uint32_t baudRate, CanPins pinCan,
                    can::FrameFormat frameFormat = can::FrameFormat::STANDART );
            
            // инициализация полная (вся структура в деле)
            ReturnState initExtended( CanInitStruct & initStruct,
                    can::FrameFormat frameFormat = can::FrameFormat::STANDART );
            
            // параметры фильров
            virtual void addFilter( const CanFilter & filterParams, const uint32_t num ) override;
            virtual uint32_t getFilterCapacity() const override
            {
                return max_num_of_rx_filters;
            }
            
            // передача
            virtual ReturnState transmitMessage( const CanMessage & msg ) override;
            
            // прием            
            virtual bool tryToReceive( CanMessage & msg ) override;
            
            // проверка инициализации
            virtual bool isInited(void) override;
        
            // обработчик прерываний - прием в фифо
            void canRxIrq( uint8_t canFifo, uint32_t canItFf, uint32_t canItFov, uint32_t canItFmp );
            
            // обработчик прерываний - передача свершилась
            void canTxIrq( void );
            
            // обработчик прерываний - какая-то ошибка
            void canErrIrq( void );
            
            // проверка на ошибку - не упало ли все
            virtual CanErr getErrorState( void ) override
            {
                return m_errState;
            }
          
            virtual void clearError( void ) override
            {
                m_errState = CanErr::NO_ERROR;
                m_lastErrCode = 0;
                
            }
            
            // раньше и этого не было, так что смысла большого нет
            virtual uint32_t getPlatformSpecificError( void ) override
            { 
                return m_lastErrCode;
            }
            
            
            virtual bool isReadyToTransmit( void ) override;
            virtual bool areAllTransmitsComplete( void ) override;
            
            // мьютекс
            virtual bool isLocked( void ) override;            
            virtual void lock( void ) override;
            virtual void unLock( void ) override;
               
        private:
            // константы, типы 
            
            // методы

            // копировать нельзя
            Handle(const Handle & that) = delete;

            // присваивать тоже нельзя
            Handle & operator=( Handle & that) = delete;
                  
            // отдельно вынесенный инит пинов
            void initGpio( CanPins pinCan);
        
            // отдельно вынесенный инит прерываний
            ReturnState initIrq( uint8_t priority );
            
            // служебная функция для пересыпания данных из spl-структуры в единую для всех-всех-всех
            void copyMsg( CanMessage & destMsg, CanRxMsg & srcMsg );
            
            // для подсчета кол-ва экземпляров
            static uint8_t & counter(void)
            {
                static uint8_t count = 0; 
                return count; 
            }
            
            //  члены класса 
            
            // буфер рх
            BlockingCircularBuffer< CanMessage, rx_buffer_size > m_rxBuffer;
        
            // указатель на сам интерфейс
            CAN_TypeDef * m_canPointer;
        
            // вспомогательные шняги
            bool m_isInitDone = false; 

            // текущий бодрейт
            uint32_t m_baudRate = 0;
            
            // код последней ошибки для внутреннего пользования (соответствует кодам из spl) :
            //  CAN_ErrorCode_NoErr            /*!< No Error */ 
            //  CAN_ErrorCode_StuffErr         /*!< Stuff Error */ 
            //  CAN_ErrorCode_FormErr          /*!< Form Error */ 
            //  CAN_ErrorCode_ACKErr           /*!< Acknowledgment Error */ 
            //  CAN_ErrorCode_BitRecessiveErr  /*!< Bit Recessive Error */ 
            //  CAN_ErrorCode_BitDominantErr  /*!< Bit Dominant Error */ 
            //  CAN_ErrorCode_CRCErr           /*!< CRC Error  */ 
            //  CAN_ErrorCode_SoftwareSetErr   /*!< Software Set Error */
            uint8_t m_lastErrCode = CAN_ErrorCode_NoErr;
        
            // наличие ошибки
            CanErr m_errState = CanErr::NO_ERROR;
        
            // для потокобезопасности типа
            bool m_isLocked = false;

            uint32_t m_emptyBufferNum = max_num_of_rx_filters;
            can::FrameFormat m_frameFormat = can::FrameFormat::STANDART;
    };


    #ifdef CAN1_ENABLE
        extern Handle can1;
    #endif
    
    #ifdef CAN2_ENABLE
        extern Handle can2;
    #endif
    
}

#endif
