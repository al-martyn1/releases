#include "can_handle.h"

     
#define UMBA_UNLOCK_CAN_CPP 
    
#ifdef USE_UMBA_MM
     
    #if defined(STM32F1_SERIES)
     
        #include "can_handle_stm32f1.cpp"
     
    #elif defined(STM32F3_SERIES)
     
        #include "can_handle_stm32f3.cpp"
     
    #elif defined(STM32F4_SERIES)
     
        #include "can_handle_stm32f4.cpp"
     
    #elif defined(MILANDR)
     
        #include "can_handle_mdr.cpp"
     
    #endif
    

#else
    
    #if defined (STM32F10X_LD) || defined (STM32F10X_LD_VL) || defined (STM32F10X_MD) ||    \
        defined (STM32F10X_MD_VL) || defined (STM32F10X_HD) || defined (STM32F10X_HD_VL) || \
        defined (STM32F10X_XL) || defined (STM32F10X_CL)
        
        #include "can_handle_stm32f1.cpp"
        
    #elif defined (STM32F303xC) || defined (STM32F334x8) || defined (STM32F302x8) || defined (STM32F303xE)

        #include "can_handle_stm32f3.cpp"
        
    #elif defined(STM32F4XX)       || defined(STM32F40_41xxx) || defined(STM32F427_437xx) || \
          defined(STM32F429_439xx) || defined(STM32F401xx)    || defined(STM32F410xx)     || \
          defined(STM32F411xE)     || defined(STM32F412xG)    || defined(STM32F413_423xx) || \
          defined(STM32F446xx)     || defined(STM32F469_479xx)

        #include "can_handle_stm32f4.cpp"
        
    #elif defined USE_MDR1986VE1T || defined USE_MDR1986VE9x

        #include "can_handle_mdr.cpp"
        
    #else

        #error "not supported yet"
        
    #endif
#endif

#undef UMBA_UNLOCK_CAN_CPP 
