/***************************************************************************************************
    Модуль управления CAN для микроконроллеров 1986ВЕxx
    Реализация класса can::Handle

    Для доступа к отдельным can'ам используйте глабальные объекты can::can1 и can::can2
    
    для инициализации использовать функции init или initExtended, предварительно заполнив 
    структуру типа CanInitStruct (чуть-чуть для функции init и полностью для initExtended)
    после - настроить фильтрацию функциями setFilterMask, setFilterTwoIds или setFilterExtended
    
    для приема сообщений периодически вызывать tryToReceive
    
    для отправки использовать функцию transmitMessage
    
    если нужно все это пользовать в разных потоках - использовать isLocked, lock и unLock
    
    для сброса всего can использовать deInit
***************************************************************************************************/

#include "can_handle_mdr.h"

#ifdef UMBA_UNLOCK_CAN_CPP 

#if defined (USE_MDR1986VE1T) || (defined USE_MDR1986VE9x)

// ради memcpy
#include <string.h>

namespace can
{
    // Глобальные хэндлы канов
    #ifdef CAN1_ENABLE
        Handle can1;
    #endif

    #ifdef CAN2_ENABLE
        Handle can2;
    #endif

    uint8_t Handle::handlesCounter;

    // Маска и фильтр, заведомо исключающие получение сообщения
    const uint32_t rx_mask_null   = 0x00000000;
    const uint32_t rx_filter_null = 0x1FFFFFFF;


    // Проверка распределения буферов: всего 32 буфера, могут быть назначены на прием, передачу или выключены.
    // Приемные буферы должны иметь меньшие номера, чем отправные. Группы не должны пересекаться.
    
    // -V::2007 - allow zero operand in static expression
    UMBA_STATIC_ASSERT_MSG( ( (tx_buf_max - tx_buf_min + 1 + rx_buf_max - rx_buf_min + 1) <= 32 ), should_be_max_32_buffers);
    UMBA_STATIC_ASSERT_MSG( ( (rx_buf_min <= rx_buf_max) && (tx_buf_min <= tx_buf_max) ), max_should_not_be_less_than_min);
    UMBA_STATIC_ASSERT_MSG( ( rx_buf_max < tx_buf_min ), rx_should_be_less_than_tx);

    Handle::Handle()
    {
        handlesCounter++;

        // Нельзя создавать канов больше, чем разрешено с помощью констант CAN_x_ENABLE

        // Этот енум нужен только ради значения CAN_N_MAX - максимального количества канов
        enum CAN_NUMBERS
        {
            #ifdef CAN1_ENABLE
                CAN_N_1,
            #endif

            #ifdef CAN2_ENABLE
                CAN_N_2,
            #endif

                CAN_N_MAX
        };

        UMBA_ASSERT( handlesCounter <= CAN_N_MAX );
    }



    /**************************************************************************************************
    Описание:  Метод инициализации
    Аргументы: Енумы пинов, бодрейт, формат фрейма, приоритет прерывания
    Возврат:   -
    Замечания: -
    **************************************************************************************************/
    
    // -V::801 - allow passing strong enums by value
    void Handle :: init( const RxPins rxPin,
                         const TxPins txPin,
                         const uint32_t baudrate,
                         const FrameFormat format,
                         const uint32_t irqPrio )
    {
        UMBA_ASSERT( m_isInited == false );

        m_baudrate = baudrate;
        m_format = format;

        selectHardware( rxPin, txPin );

        CAN_Cmd( m_mdrCan, DISABLE );

        initPins();
        initMdrCan();
        initBuffers();

        m_isInited = true;

        CAN_Cmd( m_mdrCan, ENABLE );

        // Из параноидальных соображений прерывание включается только когда все остальное уже точно готово
        initIrq( irqPrio );

    }

    /***************************************************************************************************
        сброс инициализации can
        Аргументы:
        Возврат:
        Замечания: режим выводов не меняет
     ***************************************************************************************************/
    void Handle::deInit()
    {
        CAN_DeInit( m_mdrCan );

        m_isInited = false;
    }

    /**************************************************************************************************
    Описание:  Метод настройки фильтра приемного буфера
    Аргументы: Номер буфера, маска, фильтр
    Возврат:   
    Замечания: Входное сообщение с идентификатором ID пройдет фильтр и поступит на обработку, если
               (ID & MASK) == FILTER.
               CAN должен быть уже проинициализирован.
    **************************************************************************************************/
    void Handle :: addFilter( const CanFilter & filterParams, const uint32_t num )
    {
        UMBA_ASSERT( m_isInited );
        UMBA_ASSERT( num <= rx_buf_max );
        UMBA_ASSERT( ( rx_buf_min == 0 )  || ( ( rx_buf_min > 0 ) && (num >= rx_buf_min ) ) );

        CAN_FilterInitTypeDef mdrFilter;

        if( m_format == FrameFormat::EXTENDED )
        {
            mdrFilter.Filter_ID = filterParams.filter;
            mdrFilter.Mask_ID = filterParams.mask;
        }
        else
        {
            mdrFilter.Filter_ID = CAN_STDID_TO_EXTID( filterParams.filter );
            mdrFilter.Mask_ID = CAN_STDID_TO_EXTID( filterParams.mask );
        }

        CAN_FilterInit( m_mdrCan, num, &mdrFilter );
    }

    /**************************************************************************************************
    Описание:  Метод форсированной отправки соощения
    Аргументы: Сообщение
    Возврат:   -
    Замечания: Сообщение будет отправлено с высшим приоритетом. Если свободных буферов нет, будет
               затерто сообщение в буфере с максимальным номером и поднимется флаг переполнения.
               CAN должен быть уже проинициализирован.
    **************************************************************************************************/
    ReturnState Handle::forceSendMsg( const CanMessage & msg )
    {
        UMBA_ASSERT( m_isInited );

        CAN_TxMsgTypeDef txMsg;
        if( m_format == FrameFormat::EXTENDED )
        {
            txMsg.ID = msg.id;
            txMsg.IDE = CAN_ID_EXT;
        }
        else
        {
            txMsg.ID = CAN_STDID_TO_EXTID( msg.id );
            txMsg.IDE = CAN_ID_STD;
        }

        txMsg.PRIOR_0 = DISABLE;
        txMsg.DLC = msg.length;
        memcpy( txMsg.Data, msg.data, msg_len_max );

        ReturnState state = ReturnState::OK;

        ENTER_CRITICAL_SECTION();

            uint32_t bufN = CAN_GetEmptyTransferBuffer( m_mdrCan );
            if( bufN != CAN_BUFFER_NUMBER )
            {
                m_mdrCan->BUF_CON[ bufN ] |= CAN_STATUS_PRIOR_0;
                CAN_Transmit( m_mdrCan, bufN, &txMsg );
                state = ReturnState::OK;
            }
            else
            {
                bufN = tx_buf_max;
                m_mdrCan->BUF_CON[ bufN ] |= CAN_STATUS_PRIOR_0;
                CAN_Transmit( m_mdrCan, bufN, &txMsg );
                state = ReturnState::TX_BUSY;
            }

        LEAVE_CRITICAL_SECTION();

        return state;
    }

    /***************************************************************************************************
        начать передачу
        Аргументы:  messageID - 11 или 29 бит ID
                    frameFormat - STANDART или EXTENDED
                    data - до 8 байт данных
                    dataLen - длина буфера данных
        Возврат:    OK - отправлено
                    TX_BUSY - все буфера для отпарвки заняты, не отправлено
                    ERROR - косяк с данными, не отправлено
        Замечания:
     ***************************************************************************************************/
    ReturnState Handle::transmitMessage( const CanMessage & msg )
    {
        UMBA_ASSERT( m_isInited );

        auto result = ReturnState::ERROR;

        CAN_TxMsgTypeDef txMsg;
        if( m_format == FrameFormat::EXTENDED )
        {
            txMsg.ID = msg.id;
            txMsg.IDE = CAN_ID_EXT;
        }
        else
        {
            txMsg.ID = CAN_STDID_TO_EXTID( msg.id );
            txMsg.IDE = CAN_ID_STD;
        }
        txMsg.PRIOR_0 = DISABLE;
        txMsg.DLC = msg.length;
        memcpy( txMsg.Data, msg.data, msg_len_max );

        ENTER_CRITICAL_SECTION();

            uint32_t bufN = CAN_GetEmptyTransferBuffer( m_mdrCan );
            if( bufN != CAN_BUFFER_NUMBER )
            {
                m_mdrCan->BUF_CON[ bufN ] &= ~CAN_STATUS_PRIOR_0;
                CAN_Transmit( m_mdrCan, bufN, &txMsg );
                result = ReturnState::OK;
            }
            else
            {
                result = ReturnState::TX_BUSY;
            }

        LEAVE_CRITICAL_SECTION();

        return result;
    }

    /***************************************************************************************************
        проверить приемный буфер, если там есть сообщение - получить его в message
        Аргументы:  msg - ссыль на принятое сообщение
        Возврат:    true - принято, лежит в message
                    false - не было ничего принято
        Замечания:
    ***************************************************************************************************/
    bool Handle::tryToReceive( CanMessage & msg )
    {
        if( ( isInited() == false ) ||
            ( getErrorState() == CanErr::BUS_OFF) )
        {
            return false;
        }

        if( m_rxBuffer.isEmpty() == true )
        {
            // буфер пустой
            return false;
        }
        else
        {
            // в буфере чот есть, забрать
            msg = m_rxBuffer.readTail();
            return true;
        }
    }

    /***************************************************************************************************
        получить текущую ошибку
        Аргументы: -
        Возврат:   одну из "стандартных" ошибок can'a
        Замечания: за платформоспецифичными ошибками обращайтесь в getPlatformSpecificError
     ***************************************************************************************************/
    CanErr Handle::getErrorState()
    {
        UMBA_ASSERT( m_isInited );
        // ошибку вытаскиваю из поля, в которое скопирован статус последней ошибки
        
        // Смещение битов состояния линии в регистре STATUS
        const uint32_t status_err_offset = 9;

        uint32_t mdrStatus = ( m_errorCode & CAN_STATUS_ERR_STATUS_Msk ) >> status_err_offset;
        
        CanErr err = CanErr::NO_ERROR;

        // проверяем на условно-универсальные ошибки
        switch ( mdrStatus )
        {
            case CAN_STATUS_ERR_STATUS_ERROR_ACTIVE:
                if( m_errorCode == 0 )
                { 
                    err = CanErr::NO_ERROR;
                }
                else
                {
                    err = CanErr::BUS_OFF;
                }
                break;
                
            case CAN_STATUS_ERR_STATUS_ERROR_PASSIVE:
                err = CanErr::PASSIVE;
                break;
                
            default:
                err = CanErr::BUS_OFF;
                break;
        }

        if( m_isRxQueueOverflow )
            err = CanErr::RX_OVERFLOW;

        return err;
    }

    /***************************************************************************************************
        получить все платформозависимые ошибки
        Аргументы: -
        Возврат:   просто весь регистр статуса
        Замечания: -
     ***************************************************************************************************/
    uint32_t Handle::getPlatformSpecificError()
    {
        UMBA_ASSERT( m_isInited );

        return m_errorCode;
    }

    /***************************************************************************************************
        проверка на готовность передавать
        Аргументы:  -
        Возврат: true - есть свободные мэйлбоксы на передачу
                 false - нет таковых
        Замечания:
     ***************************************************************************************************/
    bool Handle::isReadyToTransmit()
    {
        UMBA_ASSERT( m_isInited );

        auto bufN = CAN_GetEmptyTransferBuffer( m_mdrCan );

        if( bufN != CAN_BUFFER_NUMBER )
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /***************************************************************************************************
        проверка, что все передачи полностью завершены
        Аргументы:  -
        Возврат: true/false
        Замечания:
     ***************************************************************************************************/
    bool Handle::areAllTransmitsComplete()
    {
        UMBA_ASSERT( m_isInited );

        for(uint32_t bufN = tx_buf_min; bufN <= tx_buf_max; bufN++)
        {
            // хотя бы в одном буфере еще что-то есть
            if( m_mdrCan->BUF_CON[bufN] & CAN_STATUS_TX_REQ )
                return false;
        }

        // все буферы пусты
        return true;
    }

    // "мьютекс" на владение
    bool Handle::isLocked()
    {
        UMBA_ASSERT( m_isInited );

        return m_isLocked;
    }

    void Handle::lock()
    {
        UMBA_ASSERT( m_isInited );

        m_isLocked = true;
    }

    void Handle::unLock()
    {
        UMBA_ASSERT( m_isInited );

        m_isLocked = false;
    }



    /**************************************************************************************************
    Описание:  Обработчик прерываний CAN
    Аргументы: -
    Возврат:   -
    Замечания: Обработываются только прерывания приемных буферов
    **************************************************************************************************/
    void Handle::irqHandler()
    {
    
        static constexpr auto errorMask = ( CAN_STATUS_ERROR_OVER | 
                                           CAN_STATUS_BIT_ERR | 
                                           CAN_STATUS_BIT_STUFF_ERR | 
                                           CAN_STATUS_CRC_ERR | 
                                           CAN_STATUS_FRAME_ERR | 
                                           CAN_STATUS_ACK_ERR );                                           
        
        // Флаг ошибки вытаскивается из STATUS, сбрасывается он тоже через этот регистр
        if( m_mdrCan->STATUS & errorMask )
        {
            auto status = CAN_GetStatus( m_mdrCan );
            
            
            m_errorCode = status & errorMask;
                        
            // сбрасываю все флаги
            m_mdrCan->STATUS &= ~errorMask;
            
        }
        
        // Перебор всех буферов
        for( uint32_t bufN = rx_buf_min; bufN <= rx_buf_max; bufN++ )
        {
            // Если для буфера установлен флаг прерывания, обработать
            if( CAN_GetRxITStatus( m_mdrCan, bufN ) != SET )
                continue;

            CAN_RxMsgTypeDef mdrMsg;
            CAN_GetRawReceivedData( m_mdrCan, bufN, &mdrMsg );
            
            // флаг прерывания сбрасываем сразу
            CAN_ITClearRxTxPendingBit( m_mdrCan, bufN, CAN_STATUS_RX_READY );

            CanMessage msg;

            // копируем поле ID
            if( ( m_format == FrameFormat::STANDART ) && ( mdrMsg.Rx_Header.IDE == CAN_ID_STD ) )
            {
                msg.id = CAN_EXTID_TO_STDID( mdrMsg.Rx_Header.ID );
            }
            else if( (m_format == FrameFormat::EXTENDED ) && ( mdrMsg.Rx_Header.IDE == CAN_ID_EXT ) )
            {
                msg.id = mdrMsg.Rx_Header.ID;
            }
            else
            {
                // ошибка - себе сохраняем, в железе сбрасываем
                m_isRxFormatErr = true;
                CAN_ITClearRxTxPendingBit( m_mdrCan, bufN, CAN_STATUS_RX_READY );
                break;
            }

            // копируем длину и данные
            msg.length = mdrMsg.Rx_Header.DLC;
            memcpy( msg.data, mdrMsg.Data, msg_len_max );

            if( m_rxBuffer.isFull() )
            {
                m_isRxQueueOverflow = true;
                break;
            }

            m_rxBuffer.writeHead( msg );

            // Для ускорения работы прерывания после первого же обработанного сообщения производится выход
            // из обработчика. Если в других буферах осталить непринятые сообщения, прерывание сработает
            // снова. Но вероятность этого много меньше вероятности единократного приема одного сообщения.
            break;
        }
    }

     /***************************************************************************************************
                                              Приватные методы
     ***************************************************************************************************/

     /**************************************************************************************************
     Описание:  Выбор железа, с которым предстоит иметь дело
     Аргументы: Енумы пинов
     Возврат:   -
     Замечания: -
     **************************************************************************************************/

    #if defined USE_MDR1986VE1T

         void Handle :: selectHardware( const RxPins rxPin, const TxPins txPin )
         {
             #ifdef CAN1_ENABLE
                 if( this == &can1 )
                 {
                     m_mdrCan = MDR_CAN1;
                     m_irqn = CAN1_IRQn;

                     switch( rxPin )
                     {
                         case RxPins::CAN1_RX_PC9:
                             m_rxMdrPort = MDR_PORTC;
                             m_rxMdrPin = PORT_Pin_9;
                             m_rxMdrPinFunc = PORT_FUNC_OVERRID;
                             break;
                         case RxPins::CAN1_RX_PE11:
                             m_rxMdrPort = MDR_PORTE;
                             m_rxMdrPin = PORT_Pin_11;
                             m_rxMdrPinFunc = PORT_FUNC_MAIN;
                             break;
                         default:
                             UMBA_ASSERT_FAIL();
                     }

                     switch( txPin )
                     {
                         case TxPins::CAN1_TX_PC10:
                             m_txMdrPort = MDR_PORTC;
                             m_txMdrPin = PORT_Pin_10;
                             m_txMdrPinFunc = PORT_FUNC_OVERRID;
                             break;
                         case TxPins::CAN1_TX_PE12:
                             m_txMdrPort = MDR_PORTE;
                             m_txMdrPin = PORT_Pin_12;
                             m_txMdrPinFunc = PORT_FUNC_MAIN;
                             break;
                         default:
                             UMBA_ASSERT_FAIL();
                     }
                 }
             #endif /*CAN1_ENABLE*/

             #ifdef CAN2_ENABLE
                 if( this == &can2 )
                 {
                     m_mdrCan = MDR_CAN2;
                     m_irqn = CAN2_IRQn;

                     switch( rxPin )
                     {
                         case RxPins::CAN2_RX_PC11:
                             m_rxMdrPort = MDR_PORTC;
                             m_rxMdrPin = PORT_Pin_11;
                             m_rxMdrPinFunc = PORT_FUNC_OVERRID;
                             break;
                         case RxPins::CAN2_RX_PE13:
                             m_rxMdrPort = MDR_PORTE;
                             m_rxMdrPin = PORT_Pin_13;
                             m_rxMdrPinFunc = PORT_FUNC_MAIN;
                             break;
                         default:
                             UMBA_ASSERT_FAIL();
                     }

                     switch( txPin )
                     {
                         case TxPins::CAN2_TX_PC12:
                             m_txMdrPort = MDR_PORTC;
                             m_txMdrPin = PORT_Pin_12;
                             m_txMdrPinFunc = PORT_FUNC_OVERRID;
                             break;
                         case TxPins::CAN2_TX_PE14:
                             m_txMdrPort = MDR_PORTE;
                             m_txMdrPin = PORT_Pin_14;
                             m_txMdrPinFunc = PORT_FUNC_MAIN;
                             break;
                         default:
                             UMBA_ASSERT_FAIL();
                     }
                 }
             #endif /*CAN2_ENABLE*/
         }

   #elif defined USE_MDR1986VE9x

        void Handle::selectHardware( const RxPins rxPin, const TxPins txPin )
        {
            #ifdef CAN1_ENABLE

                if( this == &can1 )
                {
                    m_mdrCan = MDR_CAN1;
                    m_irqn = CAN1_IRQn;

                    switch( rxPin )
                    {
                        case RxPins::CAN1_RX_PA7:
                            m_rxMdrPort = MDR_PORTA;
                            m_rxMdrPin = PORT_Pin_7;
                            m_rxMdrPinFunc = PORT_FUNC_ALTER;
                            break;
                        case RxPins::CAN1_RX_PB3:
                            m_rxMdrPort = MDR_PORTB;
                            m_rxMdrPin = PORT_Pin_3;
                            m_rxMdrPinFunc = PORT_FUNC_OVERRID;
                            break;
                        case RxPins::CAN1_RX_PC9:
                            m_rxMdrPort = MDR_PORTC;
                            m_rxMdrPin = PORT_Pin_9;
                            m_rxMdrPinFunc = PORT_FUNC_MAIN;
                            break;
                        case RxPins::CAN1_RX_PD14:
                            m_rxMdrPort = MDR_PORTD;
                            m_rxMdrPin = PORT_Pin_14;
                            m_rxMdrPinFunc = PORT_FUNC_OVERRID;
                            break;
                        case RxPins::CAN1_RX_PE0:
                            m_rxMdrPort = MDR_PORTE;
                            m_rxMdrPin = PORT_Pin_0;
                            m_rxMdrPinFunc = PORT_FUNC_OVERRID;
                            break;
                        default:
                            UMBA_ASSERT_FAIL();
                    }

                    switch( txPin )
                    {
                        case TxPins::CAN1_TX_PA6:
                            m_txMdrPort = MDR_PORTA;
                            m_txMdrPin = PORT_Pin_6;
                            m_txMdrPinFunc = PORT_FUNC_ALTER;
                            break;
                        case TxPins::CAN1_TX_PB2:
                            m_txMdrPort = MDR_PORTB;
                            m_txMdrPin = PORT_Pin_2;
                            m_txMdrPinFunc = PORT_FUNC_OVERRID;
                            break;
                        case TxPins::CAN1_TX_PC8:
                            m_txMdrPort = MDR_PORTC;
                            m_txMdrPin = PORT_Pin_8;
                            m_txMdrPinFunc = PORT_FUNC_MAIN;
                            break;
                        case TxPins::CAN1_TX_PD13:
                            m_txMdrPort = MDR_PORTD;
                            m_txMdrPin = PORT_Pin_13;
                            m_txMdrPinFunc = PORT_FUNC_OVERRID;
                            break;
                        case TxPins::CAN1_TX_PE1:
                            m_txMdrPort = MDR_PORTE;
                            m_txMdrPin = PORT_Pin_1;
                            m_txMdrPinFunc = PORT_FUNC_OVERRID;
                            break;
                        default:
                            UMBA_ASSERT_FAIL();
                    }
                } // if( this == &can1 );

            #endif /* CAN1_ENABLE */

            #ifdef CAN2_ENABLE

                if( this == &can2 )
                {
                    m_mdrCan = MDR_CAN2;
                    m_irqn = CAN2_IRQn;

                    switch( rxPin )
                    {
                        case RxPins::CAN2_RX_PC14:
                            m_rxMdrPort = MDR_PORTC;
                            m_rxMdrPin = PORT_Pin_14;
                            m_rxMdrPinFunc = PORT_FUNC_OVERRID;
                            break;
                        case RxPins::CAN2_RX_PD15:
                            m_rxMdrPort = MDR_PORTD;
                            m_rxMdrPin = PORT_Pin_15;
                            m_rxMdrPinFunc = PORT_FUNC_MAIN;
                            break;
                        case RxPins::CAN2_RX_PE6:
                            m_rxMdrPort = MDR_PORTE;
                            m_rxMdrPin = PORT_Pin_6;
                            m_rxMdrPinFunc = PORT_FUNC_ALTER;
                            break;
                        case RxPins::CAN2_RX_PF2:
                            m_rxMdrPort = MDR_PORTF;
                            m_rxMdrPin = PORT_Pin_2;
                            m_rxMdrPinFunc = PORT_FUNC_OVERRID;
                            break;
                        default:
                            UMBA_ASSERT_FAIL();
                    }

                    switch( txPin )
                    {
                        case TxPins::CAN2_TX_PC15:
                            m_txMdrPort = MDR_PORTC;
                            m_txMdrPin = PORT_Pin_15;
                            m_txMdrPinFunc = PORT_FUNC_OVERRID;
                            break;
                        case TxPins::CAN2_TX_PD9:
                            m_txMdrPort = MDR_PORTD;
                            m_txMdrPin = PORT_Pin_9;
                            m_txMdrPinFunc = PORT_FUNC_MAIN;
                            break;
                        case TxPins::CAN2_TX_PE7:
                            m_txMdrPort = MDR_PORTE;
                            m_txMdrPin = PORT_Pin_7;
                            m_txMdrPinFunc = PORT_FUNC_ALTER;
                            break;
                        case TxPins::CAN2_TX_PF3:
                            m_txMdrPort = MDR_PORTF;
                            m_txMdrPin = PORT_Pin_3;
                            m_txMdrPinFunc = PORT_FUNC_OVERRID;
                            break;
                        default:
                            UMBA_ASSERT_FAIL();
                    }
                } // if (this == &can2 )

            #endif /* CAN2_ENABLE */
        }

    #endif

    /**************************************************************************************************
    Описание:  Инициализация пинов
    Аргументы: -
    Возврат:   -
    Замечания: -
    **************************************************************************************************/
    void Handle::initPins()
    {
        PORT_InitTypeDef portStruct;
        PORT_StructInit( &portStruct );

        portStruct.PORT_PULL_UP = PORT_PULL_UP_OFF;
        portStruct.PORT_PULL_DOWN = PORT_PULL_DOWN_OFF;
        portStruct.PORT_PD_SHM = PORT_PD_SHM_OFF;
        portStruct.PORT_PD = PORT_PD_DRIVER;
        portStruct.PORT_GFEN = PORT_GFEN_OFF;
        portStruct.PORT_SPEED = PORT_SPEED_MAXFAST;
        portStruct.PORT_MODE = PORT_MODE_DIGITAL;

        // Rx
        RST_CLK_PCLKcmd( PCLK_BIT( m_rxMdrPort ), ENABLE );
        portStruct.PORT_Pin = m_rxMdrPin;
        portStruct.PORT_FUNC = m_rxMdrPinFunc;
        portStruct.PORT_OE = PORT_OE_IN;
        PORT_Init( m_rxMdrPort, &portStruct );

        // Tx
        RST_CLK_PCLKcmd( PCLK_BIT( m_txMdrPort ), ENABLE );
        portStruct.PORT_Pin = m_txMdrPin;
        portStruct.PORT_FUNC = m_txMdrPinFunc;
        portStruct.PORT_OE = PORT_OE_OUT;
        PORT_Init( m_txMdrPort, &portStruct );
    }

    /**************************************************************************************************
    Описание:  Сброс пинов в исходное состояние
    Аргументы: -
    Возврат:   -
    Замечания: -
     **************************************************************************************************/
    void Handle::deInitPins()
    {
        PORT_InitTypeDef portStruct;
        PORT_StructInit( &portStruct );

        portStruct.PORT_Pin = m_rxMdrPin;
        PORT_Init( m_rxMdrPort, &portStruct );

        portStruct.PORT_Pin = m_txMdrPin;
        PORT_Init( m_txMdrPort, &portStruct );
    }


    /**************************************************************************************************
    Описание:  Инициализация модуля can
    Аргументы: -
    Возврат:   -
    Замечания: -
    **************************************************************************************************/
    void Handle :: initMdrCan()
    {
        RST_CLK_PCLKcmd( PCLK_BIT( m_mdrCan ), ENABLE );
        CAN_BRGInit( m_mdrCan, CAN_HCLKdiv1 );

        CAN_DeInit( m_mdrCan );

        CAN_InitTypeDef canStruct;
        CAN_StructInit( &canStruct );

        // -V::525 - allow similar blocks of code
        canStruct.CAN_ROP = DISABLE;            // Own packets reception
        canStruct.CAN_SAP = DISABLE;            // Sending ACK on own packets
        canStruct.CAN_STM = DISABLE;            // Self Test mode
        canStruct.CAN_ROM = DISABLE;            // Read Only mode
        
        canStruct.CAN_PSEG = CAN_PSEG_Mul_4TQ;  // Propagation time
        canStruct.CAN_SEG1 = CAN_SEG1_Mul_1TQ;  // Phase Segment 1 time
        canStruct.CAN_SEG2 = CAN_SEG2_Mul_2TQ;  // Phase Segment 2 time
        canStruct.CAN_SJW = CAN_SJW_Mul_1TQ;    // Synchronizations jump width time
        // При настройке CAN_SEG1, CAN_SEG2 и CAN_SJW необходимо учитывать ошибку
        // "Остановка CAN при подстройке момента семплирования", описанную в errat'ах.
        // для 1986ВЕ91 - 0017 - хотя должно быть исправлено в ревизии 3
        // для 1986ВЕ1 - 0015 - все еще не исправлено

        // Суть: для корректной подстройки без зависаний обеспечить SJW < CAN_SEG2
        canStruct.CAN_SB = CAN_SB_3_SAMPLE;     // Sampling mode
        // Расчет CAN_SB на основе бодрейта:
        // System Clock Prescaler TQ(microsec) = (BRP + 1)/CLK(MHz)
        // Nominal Bit Time = 1TQ (Sync) + 4TQ (PSEG) + 1TQ (SEG1) + 2TQ (SEG2) = 8TQ = 8 * (BRP + 1) / CLK = 1 / BAUD
        // BRP = ( CLK / ( BAUD * 8) ) - 1
        canStruct.CAN_BRP = ( SystemCoreClock / ( m_baudrate * 8 ) ) - 1;
        CAN_Init( m_mdrCan, &canStruct );
    }

    /**************************************************************************************************
    Описание:  Инициализация приемных и передающих буферов
    Аргументы: -
    Возврат:   -
    Замечания: -
    **************************************************************************************************/
    void Handle :: initBuffers()
    {
        // Начальное состояние фильтров - не примимать ничего
        CAN_FilterInitTypeDef mdrFilter;
        mdrFilter.Filter_ID = rx_filter_null;
        mdrFilter.Mask_ID = rx_mask_null;

        // Приемные буферы: включить, настроить на прием, настроить прерывание, сбросить фильтр в начальное состояние
        for (uint32_t bufN = rx_buf_min; bufN <= rx_buf_max; bufN++)
        {
            CAN_RxITConfig(m_mdrCan, (1 << bufN), ENABLE);
            CAN_Receive(m_mdrCan, bufN, DISABLE);
            CAN_FilterInit(m_mdrCan, bufN, &mdrFilter);
        }

        // Передающие буферы: включить, настроить на передачу
        for (uint32_t bufN = tx_buf_min; bufN <= tx_buf_max; bufN++)
        {
            m_mdrCan->BUF_CON[bufN] |= CAN_STATUS_EN;
            m_mdrCan->BUF_CON[bufN] &= ~CAN_BUF_CON_RX_TXN;
        }
    }

    /**************************************************************************************************
    Описание:  Инициализация прерывания
    Аргументы: -
    Возврат:   -
    Замечания: -
    **************************************************************************************************/
    void Handle::initIrq( const uint32_t irqPrio )
    {
        NVIC_SetPriority( m_irqn, irqPrio );
        NVIC_EnableIRQ (m_irqn);
        CAN_ITConfig( m_mdrCan, CAN_IT_GLBINTEN | CAN_IT_RXINTEN | CAN_IT_ERRINTEN | CAN_IT_ERROVERINTEN, ENABLE );
    }

} // namespace can

extern "C"
{

    #ifdef CAN1_ENABLE
        void CAN1_IRQHandler(void)
        {
            can::can1.irqHandler();
        }
    #endif

    #ifdef CAN2_ENABLE
        void CAN2_IRQHandler(void)
        {
            can::can2.irqHandler();
        }
    #endif
}

#endif

#endif
