#pragma once

#ifdef USE_UMBA_MM

    #include "umba/umba.h"
    #include "periph/periph.h"
     
    #if defined(STM32F1_SERIES)
     
        #include "can_handle_stm32f1.h"
     
    #elif defined(STM32F3_SERIES)
     
        #include "can_handle_stm32f3.h"
     
    #elif defined(STM32F4_SERIES)
     
        #include "can_handle_stm32f4.h"
     
    #elif defined(MILANDR)
     
        #include "can_handle_mdr.h"
     
    #endif

#else

    #include "project_config.h"

    #if defined (STM32F10X_LD) || defined (STM32F10X_LD_VL) || defined (STM32F10X_MD) ||    \
        defined (STM32F10X_MD_VL) || defined (STM32F10X_HD) || defined (STM32F10X_HD_VL) || \
        defined (STM32F10X_XL) || defined (STM32F10X_CL)
        
        #include "misc.h"
        #include "can_handle_stm32f1.h"
        
    #elif defined (STM32F303xC) || defined (STM32F334x8) || defined (STM32F302x8) || defined (STM32F303xE)

        #include "stm32f30x_misc.h"
        #include "can_handle_stm32f3.h"
        
    #elif defined(STM32F4XX)       || defined(STM32F40_41xxx) || defined(STM32F427_437xx) || \
          defined(STM32F429_439xx) || defined(STM32F401xx)    || defined(STM32F410xx)     || \
          defined(STM32F411xE)     || defined(STM32F412xG)    || defined(STM32F413_423xx) || \
          defined(STM32F446xx)     || defined(STM32F469_479xx)

        #include "misc.h"
        #include "spl/inc/stm32f4xx_can.h"
        #include "can_handle_stm32f4.h"
        
    #elif defined USE_MDR1986VE1T || defined USE_MDR1986VE9x

        #include "can_handle_mdr.h"
        
    #else

        #error "not supported yet"
        
    #endif
#endif
