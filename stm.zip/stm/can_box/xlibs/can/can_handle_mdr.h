#pragma once

#if defined (USE_MDR1986VE1T) || defined (USE_MDR1986VE9x)

#include "circular_buffer/blocking_circular_buffer.h"
#include "i_can.h"
#include "can_config.h"


namespace can
{       
//    const uint32_t max_baud_rate = 500000;      // бит в сек - предельный бодрейт can
//
//    const uint32_t min_baud_rate = 3000;        // бит в сек - предельный бодрейт can
//
//    const uint8_t num_of_rx_fifo = 2;           // кол-во фифо приемных
//
//    const uint8_t max_num_of_rx_filters = 14;   // предельное кол-во фильтров при использовании 32 бит
//

    
    // Пины

#if defined USE_MDR1986VE1T

    STRONG_ENUM( RxPins, CAN1_RX_PC9,  CAN1_RX_PE11,
                         CAN2_RX_PC11, CAN2_RX_PE13 );

    STRONG_ENUM( TxPins, CAN1_TX_PC10,   CAN1_TX_PE12,
                         CAN2_TX_PC12, CAN2_TX_PE14 );

#elif defined USE_MDR1986VE9x

    STRONG_ENUM( RxPins, CAN1_RX_PA7,  CAN1_RX_PB3,  CAN1_RX_PC9, CAN1_RX_PD14, CAN1_RX_PE0,
                         CAN2_RX_PC14, CAN2_RX_PD15, CAN2_RX_PE6, CAN2_RX_PF2);

    STRONG_ENUM( TxPins, CAN1_TX_PA6,  CAN1_TX_PB2,  CAN1_TX_PC8, CAN1_TX_PD13, CAN1_TX_PE1,
                         CAN2_TX_PC15, CAN2_TX_PD9,  CAN2_TX_PE7, CAN2_TX_PF3);
    
#endif
    
    class Handle : public ICan
    {
        public:
            
            Handle();

            virtual ~Handle()
            {
                UMBA_ASSERT_FAIL();
            }

            
            // инициализация простая
            void init( const RxPins rxPin,
                       const TxPins txPin,
                       const uint32_t baudrate,
                       const FrameFormat format,
                       const uint32_t irqPrio = IRQ_PRIORITY_LEVEL_LOWEST );


            // добавочка про буферы
            virtual void addFilter( const CanFilter & filterParams, const uint32_t num ) override;
            
            virtual uint32_t getFilterCapacity() const override
            {
                return total_rx_buffers_num;
            }
                       

            ReturnState forceSendMsg( const CanMessage & msg );

            virtual void deInit() override;

            virtual bool isInited() override
            {
                return m_isInited;
            }
            
            bool isRxFormatErr()
            {
                return m_isRxFormatErr;
            }

            void clearRxIdTypeErr()
            {
                m_isRxFormatErr = false;
            }

            // передача
            virtual ReturnState transmitMessage( const CanMessage & msg ) override;
            virtual bool isReadyToTransmit() override;

            virtual bool areAllTransmitsComplete() override;

            // прием
            virtual bool tryToReceive( CanMessage & msg ) override;

            virtual void clearError() override
            {
                m_errorCode = 0;
            }
            
            virtual CanErr getErrorState() override;

            virtual uint32_t getPlatformSpecificError() override;

            // "мьютекс"
            virtual bool isLocked() override;
            virtual void lock() override;
            virtual void unLock() override;

            void irqHandler();

        private:

            // копировать нельзя
            Handle( const Handle & that ) = delete;

            // присваивать тоже нельзя
            Handle & operator=( Handle & that ) = delete;

            void initIrq( const uint32_t irqPrio );

            void initPins();
            void initMdrCan();
            void initBuffers();

            void selectHardware( const RxPins rxPin, const TxPins txPin );

            void deInitPins();

            // счетчик, не позволяющий создавать экземпляры этого класса
            // помимо тех, которые уже созданы для работы с канами
            static uint8_t handlesCounter;

            bool m_isInited = false;

            bool m_isLocked = false;

            bool m_isRxQueueOverflow = false;
            bool m_isRxFormatErr = false;

            uint32_t m_baudrate = 0;
            FrameFormat m_format = FrameFormat::STANDART;

            // приемный буфер
            BlockingCircularBuffer< CanMessage, rx_buffer_size > m_rxBuffer {};

            // платформозависимые вещи
            MDR_CAN_TypeDef * m_mdrCan = nullptr;

            MDR_PORT_TypeDef * m_rxMdrPort = nullptr;
            uint16_t m_rxMdrPin = 0;
            PORT_FUNC_TypeDef m_rxMdrPinFunc = PORT_FUNC_PORT;

            MDR_PORT_TypeDef * m_txMdrPort = nullptr;
            uint16_t m_txMdrPin = 0;
            PORT_FUNC_TypeDef m_txMdrPinFunc = PORT_FUNC_PORT;

            IRQn_Type m_irqn = HardFault_IRQn;

            static constexpr uint32_t total_rx_buffers_num = rx_buf_max - rx_buf_min + 1;
                
            uint32_t m_errorCode = 0;

    };


    #ifdef CAN1_ENABLE
        extern Handle can1;
    #endif
    
    #ifdef CAN2_ENABLE
        extern Handle can2;
    #endif

}

#endif