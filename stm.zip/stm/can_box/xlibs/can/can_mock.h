#pragma once

#include "i_can.h"

namespace can
{
    class Mock : public ICan
    {
        // затычка can
        public:
        
        // предельное кол-во фильтров определяет размер массива, поэтому констекспр
        static constexpr uint8_t max_num_of_rx_filters = 14;

        virtual void addFilter( const CanFilter & filterParams, const uint32_t num ) override
        {
            UMBA_ASSERT( num < getFilterCapacity() ); // Тут без ассерта никак(
            m_filterParams[num] = filterParams;
        }
        virtual uint32_t getFilterCapacity() const override
        {
            return m_filterCapacity;
        }
     
     
     
        virtual void deInit( void ) override
        {
            m_isInitDone = false;
            m_baudRate = 0;
            m_lastErrCode = 0;
            m_errState = CanErr::NO_ERROR;
            m_transmitCnt = 0;
        }



        // проверка - инициализирован ли?
        virtual bool isInited( void ) override
        {
            return m_isInitDone;
        }        

        
        
        // отправка
        virtual ReturnState transmitMessage( const CanMessage & msg ) override
        {
            if( ( msg.length > msg_len_max ) ||
                ( getErrorState() == CanErr::BUS_OFF ) )
            {
                // не инициализирован can или размер неправильный или шина упала
                return ReturnState::ERROR;
            }
            m_transmitCnt++;
            m_currTx = msg;
            return ReturnState::OK;
        }

        bool wasMessageTransmitted()
        {
            if( m_transmitCnt == m_prevTransmitCnt )
            {
                return false;
            }
            
            m_prevTransmitCnt = m_transmitCnt;
            return true;
        }
       
       
        // прием
        virtual bool tryToReceive( CanMessage & msg ) override
        {
            if( getErrorState() == CanErr::BUS_OFF)
            {
                return false;
            }
            
            if( m_rxBuffer.isEmpty() == true )
            {
                // буфер пустой
                return false;
            }
            else
            {
                // в буфере чот есть, забрать
                msg = m_rxBuffer.readTail();
                return true;
            }
        }
        
        
        
        // проверка на ошибку
        virtual CanErr getErrorState( void ) override
        {
            return m_errState;
        }
        
        
        virtual void clearError( void ) override
        {
            m_errState = CanErr::NO_ERROR;
            m_deviceSpecificError = 0;
        }
        
        virtual uint32_t getPlatformSpecificError( void ) override
        {
            return m_deviceSpecificError;
        }
        
        // мьютекс
        virtual bool isLocked( void ) override
        {
            return m_isLocked;
        }

        virtual void lock( void ) override
        {
            m_isLocked = true;
        }

        virtual void unLock( void ) override
        {
            m_isLocked = false;
        }
                
        
        // проверка на готовность передавать
        virtual bool isReadyToTransmit( void ) override
        {
            return m_isReadyToTransmit;
        }
        


        // проверка на завершенность передач
        virtual bool areAllTransmitsComplete( void ) override
        {
            return m_areAllTransmitsComplete;

        }
        
        uint8_t m_filterCapacity = max_num_of_rx_filters;
        
        // подставное место для передачи
        CanMessage m_currTx = {};
        uint32_t m_transmitCnt = 0;
        uint32_t m_prevTransmitCnt = 0;
        
        // буфер приема. публичен, чтоб туда можно было что-то кинуть извне
        BlockingCircularBuffer< CanMessage, rx_buffer_size > m_rxBuffer = {};        
   
        // все публичное, чтоб можно было потрогать
        
        // вспомогательные шняги
        bool m_isInitDone = false; 

        // текущий бодрейт
        uint32_t m_baudRate = 0;
    
        // код последней ошибки 
        uint8_t m_lastErrCode = CAN_ErrorCode_NoErr;
    
        // наличие ошибки
        CanErr m_errState = CanErr::NO_ERROR;
        uint32_t m_deviceSpecificError = 0;
        
        bool m_isReadyToTransmit = true;
        bool m_areAllTransmitsComplete = true;
    
        // для потокобезопасности типа
        bool m_isLocked = false;

        uint32_t m_emptyFilterNum = max_num_of_rx_filters;
        CanFilter m_filterParams[max_num_of_rx_filters];
    };
}

