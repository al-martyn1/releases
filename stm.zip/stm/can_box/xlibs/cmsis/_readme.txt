Ядро CMSIS
Требуется для MCU Support Package