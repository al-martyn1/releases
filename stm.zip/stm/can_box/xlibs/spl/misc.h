#pragma once

#include "stm32.h"

#if defined(STM32F1_SERIES)

    #include "stm32f1xx/misc.h"

#elif defined(STM32F3_SERIES)

    #include "stm32f3xx/stm32f30x_misc.h"

#elif defined(STM32F4_SERIES)

    #include "stm32f4xx/misc.h"
    
#elif defined(STM32L1_SERIES)

    #include "stm32l1xx/misc.h"

#elif defined(MILANDR)

    //#include "milandr/misc.h"

#endif

