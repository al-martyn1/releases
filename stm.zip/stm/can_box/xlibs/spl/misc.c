#include "misc.h"

#if defined(STM32F1_SERIES)

    #include "stm32f1xx/misc.c"

#elif defined(STM32F3_SERIES)

    #include "stm32f3xx/stm32f30x_misc.c"

#elif defined(STM32F4_SERIES)

    #include "stm32f4xx/misc.c"
    
#elif defined(STM32L1_SERIES)

    #include "stm32l1xx/misc.c"

#elif defined(MILANDR)

    //#include "milandr/misc.h"

#endif

