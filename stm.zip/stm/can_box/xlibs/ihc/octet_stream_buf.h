#pragma once

#include "i_octet_stream.h"
#include "umba/i_char_writer.h"


#include <utility>
#include <string.h>


#define IHC_OCTET_STREAM_BUF_H


namespace umba{
namespace ihc{

struct IOctetOStreamImplBufPtr : UMBA_IMPLEMENTS IOctetOStream
{

    UMBA_BEGIN_INTERFACE_MAP_EX( IOctetOStream )
         //UMBA_IMPLEMENT_INTERFACE( IDriverPrivate )
    UMBA_END_INTERFACE_MAP()


    IOctetOStreamImplBufPtr( char *pBuf, size_t bufSize )
    : m_pBuf   (pBuf)
    , m_bufSize(bufSize)
    , m_written(0)
    {
        UMBA_ASSERT(m_pBuf != 0);
        UMBA_ASSERT(m_bufSize != 0);

        clear();
    }

    size_t capacity() const
    {
        return m_bufSize - 1;
    }

    size_t size() const
    {
        return m_written;
    }

    const char* c_str() const
    {
        return m_pBuf;
    }

    virtual
    bool canWrite(StreamSize nOctets) override
    {
        return true;
    }

    virtual
    umba::Result<StreamSize> write( const StreamOctetType *pData, StreamSize nOctets) override
    {
        UMBA_ASSERT(pData != 0);
        if (!nOctets)
            return;

        size_t nAvail = capacity() - size();

        size_t nCopy = std::min( nAvail, (size_t)nOctets);

        memcpy( &m_pBuf[m_written], pData, nCopy );

        m_written += nCopy;

        m_pBuf[m_written] = 0; // keep zero terminated

        return nCopy;
    }

    virtual
    umba::Result<StreamSize> write( const char *pData, size_t dataSize ) override
    {
        //UMBA_ASSERT( dataSize >= 0 );
        return write( (const StreamOctetType *)pData, (StreamSize)dataSize);
    }

    virtual
    umba::Error flush( ) override
    {
        return umba::errors::ok;
    }


    IOctetOStream* clear()
    {
        m_written = 0;
        m_pBuf[0] = 0;
        return this;
    }

    IOctetOStream* clearEx()
    {
        static const char* noData = "<No data>";
        m_written = 0;
        write( noData, strlen(noData) );
        m_written = 0;
        return this;
    }


protected:

    char    *m_pBuf;
    size_t   m_bufSize;
    size_t   m_written;

}; // IOctetOStreamImplBufPtr



template< size_t BufSize >
struct IOctetOStreamImplBuf : public IOctetOStreamImplBufPtr
{
    IOctetOStreamImplBuf()
    : IOctetOStreamImplBufPtr(&m_buf[0], BufSize)
    {}

protected:

    char m_buf[BufSize];

}; // IOctetOStreamImplBuf


struct IhcOctetStreamCharWriter : public ICharWriter
{

    IhcOctetStreamCharWriter(IOctetOStream *pStream = 0)
    : m_pStream(pStream)
    {
        //UMBA_ASSERT(m_pStream);
    }

    virtual
    void writeChar( char ch ) override
    {
        UMBA_ASSERT(m_pStream);
        m_pStream->write( (const StreamOctetType*)&ch, (StreamSize)sizeof(ch));
    }

    virtual
    void flush() override {}

    void setStream(IOctetOStream *pStream)
    {
        m_pStream = pStream;
    }

protected:

    IOctetOStream *m_pStream;
};




} // namespace ihc 
} // namespace umba





