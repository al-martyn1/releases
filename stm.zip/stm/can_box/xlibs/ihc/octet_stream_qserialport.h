/*! \file
\brief Реализация потока для QSerialPort
*/

#pragma once

#include "i_octet_stream.h"
#include <exception>
#include <stdexcept>
#include <QSerialPort>
#include <QTest>


namespace umba{

namespace ihc{




struct IOctetIOStreamImplQSerialPort : UMBA_IMPLEMENTS IOctetIOStream
{

    UMBA_BEGIN_INTERFACE_MAP_EX( IOctetOStream )
         UMBA_IMPLEMENT_INTERFACE( IOctetIOStream )
         UMBA_IMPLEMENT_INTERFACE( IOctetIStream )
    UMBA_END_INTERFACE_MAP()

    IOctetIOStreamImplQSerialPort( QSerialPort &qsp ) 
    : m_serialPort( qsp )
    {
    }

    virtual
    bool canRead() override
    {
        char data;
        if (m_serialPort.peek( &data, 1 )==1)
            return true;
        return false;
    }

    virtual
    umba::Result<StreamSize> read( StreamOctetType *pBuf, StreamSize bufSize ) override
    {
        QTest::qWait(0); // allow Qt to run some internal code
        // If in main loop (console app, as sample) no calls to 
        // QCoreApplication::processEvents();
        // the serial port always read zero count bytes

        auto bytesReaded = m_serialPort.read( (char*)pBuf, bufSize );
        if (bytesReaded==(qint64)-1)
        {
            //throw std::runtime_error("Serial port read failed");
            return QSerialPortErrorToUmbaError( m_serialPort.error() );
        }

        return (StreamSize)bytesReaded;
    }

    virtual
    void prefetch( StreamSize bufSize ) override
    {
    }


    virtual
    bool canWrite(StreamSize nOctets) override
    {
        return true; // Любой разумный объем можно отправить
    }

    virtual
    umba::Result<StreamSize> write( const StreamOctetType *pData, StreamSize nOctets) override
    {
        auto bytesWritten = m_serialPort.write( (const char*)pData, nOctets );
        if (bytesWritten==(qint64)-1)
        {
            //throw std::runtime_error("Serial port write failed");
            return QSerialPortErrorToUmbaError( m_serialPort.error() );
        }

        if (nOctets!=(StreamSize)bytesWritten)
        {
            //return QSerialPortErrorToUmbaError( m_serialPort.error() );
            //throw std::runtime_error("Serial port write failed - not all data written");
        }

        return bytesWritten;
    }

    virtual
    umba::Result<StreamSize> write( const char *pData, size_t dataSize ) override
    {
        //UMBA_ASSERT( dataSize >= 0 );
        return write( (const StreamOctetType *)pData, (StreamSize)dataSize);
    }

    virtual
    umba::Error flush( ) override
    {
        return umba::errors::ok;
    }


protected:

    QSerialPort &m_serialPort;

    umba::Error QSerialPortErrorToUmbaError( QSerialPort::SerialPortError err )
    {
        switch( err )
        {
            case QSerialPort::NoError            : return umba::errors::ok ; // No error occurred.
            case QSerialPort::DeviceNotFoundError: return umba::errors::not_found ; // An error occurred while attempting to open an non-existing device.
            case QSerialPort::PermissionError    : return umba::errors::permission_denied ; // An error occurred while attempting to open an already opened device by another process or a user not having enough permission and credentials to open.
            case QSerialPort::OpenError          : return umba::errors::already ; // An error occurred while attempting to open an already opened device in this object.
            case QSerialPort::NotOpenError       : return umba::errors::device_not_opened ; // This error occurs when an operation is executed that can only be successfully performed if the device is open. This value was introduced in QtSerialPort 5.2.
            case QSerialPort::ParityError        : return umba::errors::crc_error ; // Parity error detected by the hardware while reading data. This value is obsolete. We strongly advise against using it in new code. 
            case QSerialPort::FramingError       : return umba::errors::temporary_failure ; // Framing error detected by the hardware while reading data. This value is obsolete. We strongly advise against using it in new code.
            case QSerialPort::BreakConditionError: return umba::errors::temporary_failure ; // Break condition detected by the hardware on the input line. This value is obsolete. We strongly advise against using it in new code. 
            case QSerialPort::WriteError         : return umba::errors::write_failed ; // An I/O error occurred while writing the data.
            case QSerialPort::ReadError          : return umba::errors::read_failed ; // An I/O error occurred while reading the data.
            case QSerialPort::ResourceError      : return umba::errors::device_removed ; // An I/O error occurred when a resource becomes unavailable, e.g. when the device is unexpectedly removed from the system.
            case QSerialPort::TimeoutError       : return umba::errors::would_block ; // A timeout error occurred. This value was introduced in QtSerialPort 5.2.
            case QSerialPort::UnsupportedOperationError: return umba::errors::not_supported ; // The requested device operation is not supported or prohibited by the running operating system.
            default: return umba::errors::fail;
            //case QSerialPort::UnknownError       : return umba::errors:: ; // An unidentified error occurred.
        }

    }


}; // struct IOctetIOStreamImplQSerialPort

} // namespace ihc 

} // namespace umba

