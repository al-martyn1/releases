/*! \file
\brief Реализация потока для классического UART
*/

#pragma once

#include "uart/uart.h"
#include "i_octet_stream.h"


namespace umba{

namespace ihc{


struct IOctetIOStreamImplLegacyUart : UMBA_IMPLEMENTS IOctetIOStream
{

    UMBA_BEGIN_INTERFACE_MAP_EX( IOctetOStream )
         UMBA_IMPLEMENT_INTERFACE( IOctetIOStream )
         UMBA_IMPLEMENT_INTERFACE( IOctetIStream )
    UMBA_END_INTERFACE_MAP()

#ifdef UMBA_FREERTOS_USED


    IOctetIOStreamImplLegacyUart( uart::IUartHandle &uart ) 
    : m_transmitComplete(uart.getTransmitCompleteSemHandle())
    , m_queue           (uart.getQueueHandle()              )
    , m_ownerMutex      (uart.getOwnerMutexHandle()         )
    , m_uart            (uart)
    {
        BaseType_t mutexResult  = osSemaphoreTake(m_ownerMutex, 3000/portTICK_PERIOD_MS);
        UMBA_ASSERT(mutexResult == pdTRUE);
    }

    virtual
    bool canRead() override
    {
        uint8_t buf;
        BaseType_t queueResult = osQueuePeek(m_queue, &buf, 0 / portTICK_PERIOD_MS);
        
        // байт не пришел - все плохо
        if( queueResult != pdTRUE)
            return false;

        return true;
    }

    virtual
    StreamSize read( StreamOctetType *pBuf, StreamSize bufSize ) override
    {
        if (!bufSize)
            return 0;

        UMBA_ASSERT(pBuf != 0);
        
        BaseType_t queueResult = osQueueReceive(m_queue, pBuf, 10000 / portTICK_PERIOD_MS);
        
        // байт не пришел - все плохо
        if( queueResult != pdTRUE)
            return 0;

        return 1;
    }

    virtual
    void fetch( StreamSize bufSize ) override
    {
    }


    virtual
    bool canWrite(StreamSize nOctets) override
    {
        if (nOctets>max_packet_size) // максимально возможная порцайка
            return false;

        // ждем окончания текущей передачи
        if ( osSemaphoreTake(transmitComplete, 0/portTICK_PERIOD_MS) != true )
            return false;

        return true;
    }

    virtual
    void write( const StreamOctetType *pData, StreamSize nOctets) override
    {
        UMBA_ASSERT(pData != 0);

        while(nOctets>max_packet_size)
        {
            m_uart.sendLocalArray( pData, max_packet_size );
            nOctets -= max_packet_size;
            pData   += max_packet_size;
            if ( osSemaphoreTake(transmitComplete, 1000/portTICK_PERIOD_MS) != true )
                return; // всё обосралось, но сделать ничего не можем
        }

        m_uart.sendLocalArray( pData, nOctets );
        // В последнюю отправку не ждем окончания передачи
    }

    virtual
    void write( const char *pData, size_t dataSize ) override
    {
        UMBA_ASSERT( dataSize >= 0 );
        write( (const StreamOctetType *)pData, (StreamSize)dataSize);
    }

    virtual
    void flush( ) override
    {
    }


protected:

    SemaphoreHandle_t  m_transmitComplete;
    QueueHandle_t      m_queue;
    SemaphoreHandle_t  m_ownerMutex;


#else /* MCU no OS  */

    IOctetIOStreamImplLegacyUart( uart::IUartHandle &uart ) 
    : m_uart            (uart)
    {
    }


    virtual
    bool canRead() override
    {
        return m_pUart.isNewByte();
    }

    virtual
    StreamSize read( StreamOctetType *pBuf, StreamSize bufSize ) override
    {
        if (!bufSize)
            return 0;

        UMBA_ASSERT(pBuf != 0);

        while(!m_pUart.isNewByte()) {}
        *pBuf = m_pUart->getByte();
        return 1;
    }

    virtual
    void fetch( StreamSize bufSize ) override
    {
    }

    virtual
    bool canWrite(StreamSize nOctets) override
    {
        if (nOctets>max_packet_size) // максимально возможная порцайка
            return false;
        if (!m_uart.isTransmitComplete())
            return false;
        return true;
    }

    virtual
    void write( const StreamOctetType *pData, StreamSize nOctets) override
    {
        UMBA_ASSERT(pData != 0);

        while(nOctets>max_packet_size)
        {
            m_uart.sendLocalArray( pData, max_packet_size );
            nOctets -= max_packet_size;
            pData   += max_packet_size;
            //if ( osSemaphoreTake(transmitComplete, 1000/portTICK_PERIOD_MS) != true )
            //    return; // всё обосралось, но сделать ничего не можем
            while (!m_uart.isTransmitComplete()) {} // тут теоретически можем зависнуть
        }

        m_uart.sendLocalArray( pData, nOctets );
        // В последнюю отправку не ждем окончания передачи
    }

    virtual
    void flush( ) override
    {
    }

protected:

    SemaphoreHandle_t  m_transmitComplete;
    QueueHandle_t      m_queue;
    SemaphoreHandle_t  m_ownerMutex;


#endif


    uart::IUartHandle &m_uart;
    StreamSize         max_packet_size = 255u;


}; // struct IOctetIOStreamImplLegacyUart

} // namespace ihc 

} // namespace umba

