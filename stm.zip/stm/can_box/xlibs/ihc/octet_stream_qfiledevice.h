/*! \file
\brief Реализация потока для QSerialPort
*/

#pragma once

#include "i_octet_stream.h"
#include <exception>
#include <stdexcept>
#include <QSerialPort>
#include <QTest>


namespace umba{

namespace ihc{




struct IOctetIOStreamImplQFileDevice : UMBA_IMPLEMENTS IOctetIOStream
{

    UMBA_BEGIN_INTERFACE_MAP_EX( IOctetOStream )
         UMBA_IMPLEMENT_INTERFACE( IOctetIOStream )
         UMBA_IMPLEMENT_INTERFACE( IOctetIStream )
    UMBA_END_INTERFACE_MAP()

    IOctetIOStreamImplQFileDevice( QFileDevice &qfd ) 
    : m_fileDevice( qfd )
    {
    }

    virtual
    bool canRead() override
    {
        //qint64 fileSize = m_fileDevice.size();
        //qint64 curPos   = m_fileDevice.pos();
        //char data;
        //eof_reached
        //if (!m_fileDevice.atEnd())
        //if (m_fileDevice.peek( &data, 1 )==1)
        //    return true;
        //return false;
        return true;
    }

    virtual
    umba::Result<StreamSize> read( StreamOctetType *pBuf, StreamSize bufSize ) override
    {
        QTest::qWait(0); // Нужно ли это для файловых девайсов?

        if (m_fileDevice.atEnd())
            return umba::Error(umba::errors::eof_reached);

        auto bytesReaded = m_fileDevice.read( (char*)pBuf, bufSize );
        if (bytesReaded==(qint64)-1)
        {
            //throw std::runtime_error("Serial port read failed");
            
            if (m_fileDevice.error()==QFileDevice::ReadError)
            {
                // Возможно, просто не смогли прочитать кусок целиком, но есть еще хвост
                qint64 fileSize = m_fileDevice.size();
                qint64 curPos   = m_fileDevice.pos();
                if (curPos>=fileSize)
                    return QFileDeviceErrorToUmbaError( m_fileDevice.error() );

                qint64 numBytesAvailToRead = fileSize - curPos;
                if ((StreamSize)numBytesAvailToRead>=bufSize)
                {
                    // странно - доступно больше или столько же, сколько запрошено, 
                    // но почему-то всё равно ошибка.
                    // Значит, дело в чём-то другом
                    return QFileDeviceErrorToUmbaError( m_fileDevice.error() );
                }

                if (numBytesAvailToRead==0)
                {
                    return umba::Error(umba::errors::eof_reached);
                }

                // Пробуем запросить ровно столько, сколько осталось
                bytesReaded = m_fileDevice.read( (char*)pBuf, numBytesAvailToRead );

                if (bytesReaded==(qint64)-1)
                    return QFileDeviceErrorToUmbaError( m_fileDevice.error() ); // Всё равно - ошибка
            }
        }

        return (StreamSize)bytesReaded;
    }

    virtual
    void prefetch( StreamSize bufSize ) override
    {
    }


    virtual
    bool canWrite(StreamSize nOctets) override
    {
        return true; // Любой разумный объем можно отправить
    }

    virtual
    umba::Result<StreamSize> write( const StreamOctetType *pData, StreamSize nOctets) override
    {
        auto bytesWritten = m_fileDevice.write( (const char*)pData, nOctets );
        if (bytesWritten==(qint64)-1)
        {
            //throw std::runtime_error("Serial port write failed");
            return QFileDeviceErrorToUmbaError( m_fileDevice.error() );
        }

        if (nOctets!=(StreamSize)bytesWritten)
        {
            //return QSerialPortErrorToUmbaError( m_serialPort.error() );
            //throw std::runtime_error("Serial port write failed - not all data written");
        }

        return bytesWritten;
    }

    virtual
    umba::Result<StreamSize> write( const char *pData, size_t dataSize ) override
    {
        //UMBA_ASSERT( dataSize >= 0 );
        return write( (const StreamOctetType *)pData, (StreamSize)dataSize);
    }

    virtual
    umba::Error flush( ) override
    {
        return m_fileDevice.flush() ? umba::errors::ok : umba::errors::fail;
    }


protected:

    QFileDevice &m_fileDevice;

    umba::Error QFileDeviceErrorToUmbaError( QFileDevice::FileError err )
    {
        switch( err )
        {
            case QFileDevice::NoError         : return umba::errors::ok ; // No error occurred.
            case QFileDevice::ReadError       : return umba::errors::read_failed ; // An error occurred when reading from the file. 
            case QFileDevice::WriteError      : return umba::errors::write_failed ; // An error occurred when writing to the file.
            case QFileDevice::ResourceError   : return umba::errors::too_many_opened ; // Out of resources (e.g., too many open files, out of memory, etc.)
            case QFileDevice::OpenError       : return umba::errors::open_error ; // The file could not be opened.
            case QFileDevice::AbortError      : return umba::errors::error_aborted ; // The operation was aborted. 
            case QFileDevice::TimeOutError    : return umba::errors::timed_out ; // A timeout occurred.
            case QFileDevice::RemoveError     : return umba::errors::file_operation_error ; // The file could not be removed.
            case QFileDevice::RenameError     : return umba::errors::file_operation_error ; // The file could not be renamed.
            case QFileDevice::PositionError   : return umba::errors::not_seekable ; // The position in the file could not be changed.
            case QFileDevice::ResizeError     : return umba::errors::resize_error ; // The file could not be resized.
            case QFileDevice::PermissionsError: return umba::errors::permission_denied ; // The file could not be accessed.
            case QFileDevice::CopyError       : return umba::errors::file_operation_error ; // The file could not be copied.
            //case QFileDevice::FatalError      : return umba::errors:: ; // A fatal error occurred. 
            //case QFileDevice::UnspecifiedError: return umba::errors:: ; // An unspecified error occurred.
            default: return umba::errors::fail;
            //case QSerialPort::UnknownError       : return umba::errors:: ; // An unidentified error occurred.
        }

    }


}; // struct IOctetIOStreamImplQFile

} // namespace ihc 

} // namespace umba

